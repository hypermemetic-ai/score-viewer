# Fingering editor assistance

Pure personal measure memory and physical-contact travel advice for score editors.
The application owns interface, persistence, musical projections, and effective assignments.

The root exports the memory and travel APIs only. Internal modules are not public entry points.
The private static keyboard geometry preserves its source identity and hash. It is factual
contact geometry, with no measurement collection workflow or route calculation implementation.

This package is assembled from byte-identical emitted modules in fingering-calculator.
See provenance.json for the exact source revision, module paths, and payload SHA-256 hashes.

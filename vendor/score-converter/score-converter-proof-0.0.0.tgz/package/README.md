# Score converter

An independent pipeline for converting musical scores into an established interchange format. **MusicXML 4.0 is the first reference output**; the current proof emits plain `.musicxml`. Compressed `.mxl` packaging remains part of the intended interchange contract. Other notation systems and applications should be able to use the result without ISO notation or a TUNA viewer.

This private repository under `hypermemetic-ai` contains the initial research and decisions carried over from ISO notation on 2026-10-07. **The experimental Guitar Pro converter supports bounded GP3–GP8 fretted profiles through one private package with Node API/CLI and an additive public WebView Worker entry.** Both hosts share the same musical admission and MusicXML output. Original fixtures and an unchanged rights-cleared GP8 guitar score exercise conversion; precise feature limits and producer-evidence gaps remain in the [proof record](docs/guitar-pro-proof.md). The [WebView contract](docs/guitar-pro-webview-entry.md) distinguishes converter package checks from consumer hosting and platform acceptance. An independent native MuseScore reader is being implemented separately and is not delivered by this GP increment. The repository name is provisional. Each component repository gets its own Paseo project and local workspace when created; that operational registration is separate from this documentation seed.

## Direction

- Start with structured musical inputs, then generated digital PDFs, then scanned scores.
- Support many useful input routes rather than requiring everyone to export MusicXML first.
- Keep pitches, written timing, voices, ties, phrasing and other recoverable musical information distinct from inferred or editorial choices.
- Allow useful conversions with explicit omissions and uncertainty; never present invented facts as source markings.
- Preserve recoverable information even when the current ISO renderer cannot display it.
- Carry supported tuning and source string/fret choices through the single default output, independently of a consumer's notes or TAB presentation.
- Produce ordinary MusicXML without mandatory proprietary extensions. The project does not own the interchange standard or the music in its outputs.
- Select dependencies compatible with the intended source-available, free-personal/paid-commercial product model. Final licensing terms are still pending.

## Start here

| Document | Purpose |
| --- | --- |
| [Decisions](docs/decisions.md) | Accepted direction, proposals and unresolved choices |
| [Architecture](docs/architecture.md) | Product boundaries, stages and viewer integration |
| [Input-format research](docs/research/formats.md) | Candidate families, app exports and evidence limits |
| [Bass display handoff](docs/bass-display-handoff.md) | Approved common consumer model/C2 display, implemented stem policy and remaining delivery checks |
| [Guitar Pro reader proof](docs/guitar-pro-proof.md) | Exercised private harness, exact profile, local usage and remaining acceptance gates |
| [Guitar Pro public API](docs/guitar-pro-api.md) | Private package imports, source-track inspection/selection, output identities, errors and cancellation |
| [Guitar Pro WebView entry](docs/guitar-pro-webview-entry.md) | Public async GP Worker entry, local assets, shared admission and host resource policy |
| [Fretted information contract](docs/fretted-information-contract.md) | Single-output tuning/string preservation and the downstream retention boundary |
| [Guitar Pro local conversion](docs/research/guitar-pro.md) | Pinned reader findings, preservation gaps and a bounded bass-oriented proving plan |
| [Guitar Pro family trials](docs/research/guitar-pro-family-trials.md) | Exercised GP3–8 recognition/reader trials, specimen provenance and the GP3–GP8 coverage plan |
| [MuseScore native-conversion proof](docs/research/musescore-automatic-import.md) | Pinned local MSCX/MSCZ-to-MusicXML trial, preserved miniature facts and proposed integration |
| [Sibelius and Dorico feasibility](docs/research/native-sib-dorico.md) | Native input routes that remain unproven |
| [Digital PDF and scan research](docs/research/digital-pdf-scans.md) | Deferred acquisition tiers and evaluation criteria |
| [Licensing screening](docs/research/licensing.md) | Business constraints and bounded dependency findings |
| [Existing ISO foundations](docs/research/existing-foundations.md) | Code-audited starting points and extraction gaps |
| [Initial roadmap](docs/roadmap.md) | A proposed first proving slice and later work |

## Relationship to ISO notation

The intended viewer Import action will invoke this reusable converter, then pass the MusicXML result to ISO score tools to prepare a `.tuna` score. ISO notation's meaning, TUNA specification, editorial workspace, engraving, pagination and publication remain a separate downstream project. A human-review frontend may combine both projects; the converter core must remain independently usable.

Existing MusicXML already has the destination representation. Its import, including `.mxl` unpacking, belongs to the consumer and is outside this converter task. Current implementation work covers GP3–GP8 and an independent native MuseScore reader; Finale remains research. The converter owns correct conversion and a tested usable public contract. Consumers own integration and presentation. Candidate-reader trials and native-format research do not themselves expand admitted formats.

The user approved replacing the legacy piano-only model across all active ISO/Viewer consumers with common pitched/unpitched events, with instrument policy applied late. Shared C2 bass engraving and additive reading-package admission are implemented downstream. The selected presentation uses curved H/P connections with labels and outward stem preference, with rhythmic groups intact across C2 and genuine piano hand authority preserved. The [consumer handoff](docs/bass-display-handoff.md) records exact source checkpoints, verification, landing and delivery state. General legibility optimization and replacement pagination remain separate work. No downstream code is copied into this converter.

The fingering calculator is a separate project. Calculated piano fingerings are a requirement of our viewer experience, not a universal prerequisite for producing valid MusicXML. The learning app has its own application and release lifecycle and does not need the whole conversion pipeline.

## Research and rights status

Links identify primary sources and the scope of each finding. Documentation claims, source-code inspection and actual conversion trials are different evidence. The initial seed used read-only research. The private converter incorporates a pinned bounded reader component, tests original miniature fixtures, exercises an authorized local bass input and includes two explicitly attributed CC-BY-4.0 Guitar Pro specimens. Other acquired scores, generated repertoire and private validation receipts are excluded from Git. See the proof for exercised behavior and limits.

Source availability is the intended eventual policy. This private seed does not grant a software or documentation license, approve a dependency for distribution, finalize commercial terms, or change existing third-party rights. See [licensing screening](docs/research/licensing.md) before selecting an implementation dependency.

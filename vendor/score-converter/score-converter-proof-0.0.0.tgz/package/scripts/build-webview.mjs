/** Standard esbuild browser build. No private bundler, codec or consumer integration. */
import { build, version } from 'esbuild';
import { readFile, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';

if (version !== '0.25.11') throw new Error('WebView build requires the reviewed exact esbuild 0.25.11.');
const result = await build({
    entryPoints: { index: 'src/webview/index.ts', 'guitar-pro.worker': 'src/webview/guitar-pro.worker.ts' },
    outdir: 'dist/webview', bundle: true, platform: 'browser', format: 'esm', target: 'es2022',
    legalComments: 'linked', metafile: true, sourcemap: false, minify: false,
    banner: { js: '/*! Private score-converter package. alphaTab 1.8.4: Copyright Daniel Kuschny and Contributors; covered Source Code Form is under Mozilla Public License 2.0. Exact covered source/inventory/patches: ../../third_party/alphatab. Runtime licenses: ./NOTICE.txt. */' }
});
const inputs = Object.keys(result.metafile.inputs).sort();
if (inputs.some(path => /(?:^|\/)(?:zip|convert|inspect)\.ts$/.test(path) && /adapters\/guitar-pro/.test(path) || /src\/(?:index|worker|cli)\.ts$/.test(path) || /musescore|node:/.test(path))) throw new Error('Node/native host leaked into the GP WebView runtime graph.');
for (const [path, output] of Object.entries(result.metafile.outputs)) {
    if (output.imports.length) throw new Error(`External runtime import in ${path}.`);
    const source = await readFile(path, 'utf8');
    if (/from\s*['"]node:|import\s*\(\s*['"]node:|require\s*\(\s*['"](?:node:|(?:crypto|zlib|worker_threads)['"])/.test(source)) throw new Error(`Node runtime reference in ${path}.`);
}
await writeFile('dist/webview/NOTICE.txt', 'Private score-converter GP WebView bundle. Project licensing remains undecided; no public publication is authorized.\n\nalphaTab 1.8.4, pinned source 022a45c8e42370f9e12e68949d11eada370da83d. Copyright Daniel Kuschny and Contributors. This covered Source Code Form is subject to Mozilla Public License 2.0. Exact source, license, inventory/hashes and modifications ship at ../../third_party/alphatab. No alphaTab renderer/audio/fonts/assets/full libraries are bundled.\n\n' + await readFile('third_party/alphatab/LICENSE', 'utf8') + '\n\nsaxes 6.0.0 (bundled XML parser):\n' + await readFile('third_party/notices/saxes-6.0.0-LICENSE', 'utf8') + '\n\nxmlchars 2.2.0 (bundled XML character checks):\n' + await readFile('node_modules/xmlchars/LICENSE', 'utf8'));
const digest = bytes => createHash('sha256').update(bytes).digest('hex');
const sources = await Promise.all(inputs.map(async path => ({ path, sha256: digest(await readFile(path)) })));
const assets = await Promise.all([...Object.keys(result.metafile.outputs), 'dist/webview/NOTICE.txt'].sort().map(async path => ({ path, bytes: (await readFile(path)).length, sha256: digest(await readFile(path)) })));
await writeFile('dist/webview/runtime-graph.json', JSON.stringify({ schema: 'score-converter-webview-runtime/1', build: { tool: 'esbuild', version, platform: 'browser', target: 'es2022' }, publicImport: 'score-converter-proof/guitar-pro/webview', publicEntry: 'dist/webview/index.js', worker: 'dist/webview/guitar-pro.worker.js', sources, assets, metafile: result.metafile }, null, 2) + '\n');

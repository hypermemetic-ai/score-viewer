import { parentPort, workerData } from 'node:worker_threads';
import { convertInWorker } from './adapters/guitar-pro/convert.js';
import { inspectInWorker } from './adapters/guitar-pro/inspect.js';
const result = workerData.operation === 'inspect' ? inspectInWorker(workerData.bytes as Uint8Array) : convertInWorker(workerData.bytes as Uint8Array, { trackIds: workerData.trackIds });
parentPort!.postMessage({ requestId: workerData.requestId, operation: workerData.operation, result });

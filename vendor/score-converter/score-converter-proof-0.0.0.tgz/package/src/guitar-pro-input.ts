import { limits } from './adapters/guitar-pro/limits.js';

// Capture platform intrinsics once. Caller properties/iteration do not define byte identity.
const apply = Reflect.apply, descriptor = Object.getOwnPropertyDescriptor, isArray = Array.isArray;
const ByteArray = Uint8Array, typedArray = Object.getPrototypeOf(ByteArray.prototype);
const tag = descriptor(typedArray, Symbol.toStringTag)!.get!;
const buffer = descriptor(typedArray, 'buffer')!.get!;
const byteOffset = descriptor(typedArray, 'byteOffset')!.get!;
const byteLength = descriptor(typedArray, 'byteLength')!.get!;
const arrayBufferLength = descriptor(ArrayBuffer.prototype, 'byteLength')!.get!;
const set = ByteArray.prototype.set;

interface InputView { readonly buffer: ArrayBuffer; readonly byteOffset: number; readonly byteLength: number }

/** Validate internal slots and the true cap before allocating or inspecting caller scope. */
export function inputView(bytes: unknown): InputView {
    if (apply(tag, bytes, []) !== 'Uint8Array') throw new TypeError('Expected a Uint8Array input view.');
    const length = apply(byteLength, bytes, []) as number;
    if (length > limits.inputBytes) throw new RangeError('GP input exceeds 8 MiB; no snapshot, digest, worker or decoding started.');
    const storage = apply(buffer, bytes, []) as ArrayBuffer;
    // Shared storage cannot promise a coherent snapshot while another agent writes it.
    try { apply(arrayBufferLength, storage, []); }
    catch { throw new TypeError('Expected a Uint8Array with non-shared backing storage.'); }
    return { buffer: storage, byteOffset: apply(byteOffset, bytes, []) as number, byteLength: length };
}

/** Only bounded own data entries are source IDs; caller array methods are never invoked. */
export function snapshotTrackIds(ids: unknown): string[] | undefined {
    if (ids === undefined) return undefined;
    if (!isArray(ids)) throw new TypeError('Expected 1–8 bounded source track ID strings.');
    const length = descriptor(ids, 'length')?.value as unknown;
    if (typeof length !== 'number' || !Number.isInteger(length) || length < 1 || length > limits.tracks) throw new TypeError('Expected 1–8 bounded source track ID strings.');
    const result: string[] = [];
    for (let i = 0; i < length; i++) {
        const entry = descriptor(ids, String(i));
        if (!entry || !('value' in entry) || typeof entry.value !== 'string' || !/^\d{1,6}$/.test(entry.value)) throw new TypeError('Expected 1–8 bounded own source track ID strings.');
        result[i] = entry.value;
    }
    return result;
}

/** Copy the captured range through internal typed-array slots, never iterator/species/methods. */
export function snapshotInput(view: InputView): Uint8Array<ArrayBuffer> {
    const source = new ByteArray(view.buffer, view.byteOffset, view.byteLength);
    const result = new ByteArray(view.byteLength);
    apply(set, result, [source]);
    return result;
}

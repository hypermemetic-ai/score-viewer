#!/usr/bin/env node
import { open, mkdtemp, rename, rm, writeFile } from 'node:fs/promises';
import { resolve, dirname, basename, join } from 'node:path';
import { convertGuitarPro } from './index.js';
import { limits } from './adapters/guitar-pro/limits.js';

const [input, destination, selector, ...extra] = process.argv.slice(2);
if (!input || !destination || extra.length || selector && !/^--tracks=\d+(?:,\d+)*$/.test(selector)) {
    console.error('Usage: npm run convert -- local-file.gp new-output-directory [--tracks=source-id,...]');
    process.exitCode = 2;
} else {
    const controller = new AbortController();
    const cancel = () => controller.abort(new Error('Conversion cancelled.'));
    process.once('SIGINT', cancel); process.once('SIGTERM', cancel);
    let temporary: string | undefined;
    try {
        const file = await open(resolve(input), 'r');
        let bytes: Buffer;
        try {
            const stat = await file.stat();
            if (!stat.isFile() || stat.size > limits.inputBytes) throw new Error('Input must be a regular file no larger than 8 MiB.');
            bytes = Buffer.alloc(limits.inputBytes + 1);
            let length = 0;
            while (length < bytes.length) {
                const read = await file.read(bytes, length, bytes.length - length, null);
                if (!read.bytesRead) break;
                length += read.bytesRead;
            }
            if (length > limits.inputBytes) throw new Error('Input grew beyond the 8 MiB bound.');
            bytes = bytes.subarray(0, length);
        } finally { await file.close(); }
        const result = await convertGuitarPro(bytes!, { signal: controller.signal, ...(selector ? { trackIds: selector.slice('--tracks='.length).split(',') } : {}) });
        const target = resolve(destination);
        // A new directory is the atomic result boundary; never overwrite previous results.
        const lock = await open(target + '.conversion-lock', 'wx');
        try {
            const { lstat } = await import('node:fs/promises');
            try { await lstat(target); throw new Error('Output directory already exists.'); } catch (e) {
                if ((e as NodeJS.ErrnoException).code !== 'ENOENT') throw e;
            }
            temporary = await mkdtemp(join(dirname(target), `.${basename(target)}-`));
            await writeFile(join(temporary, 'report.json'), JSON.stringify(result.report, null, 2) + '\n', { mode: 0o600 });
            if (result.ok) {
                await writeFile(join(temporary, 'score.musicxml'), result.musicxml!, { mode: 0o600 });
                await writeFile(join(temporary, 'source-capture.json'), JSON.stringify({ inputSource: result.inputSource, source: result.source,
                    binarySource: result.binarySource, gpxSource: result.gpxSource, containerSource: result.containerSource, occurrences: result.occurrences }, null, 2) + '\n', { mode: 0o600 });
            }
            if (controller.signal.aborted) throw controller.signal.reason;
            await rename(temporary, target); temporary = undefined;
        } finally { await lock.close(); await rm(target + '.conversion-lock', { force: true }); }
        console.log(result.ok ? `Converted locally: ${destination}/score.musicxml` : `Conversion refused: ${destination}/report.json`);
        if (!result.ok) process.exitCode = 1;
    } catch (e) {
        console.error(e instanceof Error ? e.message : 'Conversion failed.'); process.exitCode = 1;
    } finally {
        if (temporary) await rm(temporary, { recursive: true, force: true });
        process.removeListener('SIGINT', cancel); process.removeListener('SIGTERM', cancel);
    }
}

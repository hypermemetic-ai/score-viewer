import { inflateRawSync, type InflateRaw } from 'node:zlib';
import { Bytes } from './bytes.js';
import { limits } from './limits.js';
import { scanContainer, checkMember, finishContainer, zipFail, type ZipMembers } from './zip-core.js';

/** Node host for the shared strict container admission. */
export function readContainer(bytes: Uint8Array): ZipMembers {
    const result: ZipMembers = new Map<string, Bytes>(), entries = scanContainer(bytes);
    result.zipDescriptors = entries.flatMap(entry => entry.descriptor ? [entry.descriptor] : []);
    for (const entry of entries) {
        const payload = bytes.subarray(entry.dataStart, entry.dataStart + entry.compressed);
        let decoded: Uint8Array;
        try {
            if (entry.method === 8) {
                const value = inflateRawSync(payload, { maxOutputLength: Math.min(limits.memberBytes, entry.decoded + 1), info: true }) as unknown as { buffer: Buffer; engine: InflateRaw };
                if (value.engine.bytesWritten !== entry.compressed) zipFail('Trailing or incomplete compressed member data.');
                decoded = value.buffer;
            } else decoded = payload.slice();
        } catch { zipFail(`Unable to decode ${entry.name} within its bound.`); }
        result.set(entry.name, checkMember(entry, decoded!));
    }
    return finishContainer(result);
}

import { limits } from './limits.js';
import { Refusal, refuse } from '../../core/report.js';
import { scanContainer, checkMember, finishContainer, zipFail, type ZipMembers } from './zip-core.js';

/** A small framing gate detects known nonconforming engines; it is not a general codec or
 * allocation certificate. Cache by exact native constructor, inside each dedicated Worker. */
const framing = new WeakMap<typeof DecompressionStream, Promise<boolean>>();
async function supportsFraming(ctor: typeof DecompressionStream, deadline: number): Promise<boolean> {
    let checked = framing.get(ctor);
    if (!checked) {
        checked = (async () => {
            // Original literal raw-DEFLATE of ASCII "7.0". The final byte completes the
            // stream although truncated decoding may already have emitted all three bytes.
            const valid = Uint8Array.of(0x33, 0xd7, 0x33, 0, 0);
            try {
                const output = await inflate(ctor, valid, 3, deadline);
                if (output.length !== 3 || output[0] !== 55 || output[1] !== 46 || output[2] !== 48) return false;
                for (const negative of [valid.subarray(0, 4), Uint8Array.of(...valid, 0)]) {
                    let rejected = false;
                    try { await inflate(ctor, negative, 3, deadline); }
                    catch (error) { if (error instanceof Refusal) throw error; rejected = true; }
                    if (!rejected) return false;
                }
                return true;
            } catch (error) { if (error instanceof Refusal) throw error; return false; }
        })();
        framing.set(ctor, checked);
    }
    return checked;
}
function checkWork(deadline: number): void {
    if (performance.now() >= deadline) refuse('work-budget', 'Worker exceeded 5 seconds; no musical output is admitted.', { member: 'container' });
}
/** One native pump for the tiny gate and actual members. Count before retention/concat;
 * both read/flush and write/close must succeed. Opaque native allocations are not capped. */
async function inflate(ctor: typeof DecompressionStream, payload: Uint8Array, maximum: number, deadline: number): Promise<Uint8Array> {
    checkWork(deadline);
    const stream = new ctor('deflate-raw'), writer = stream.writable.getWriter(), reader = stream.readable.getReader();
    const pieces: Uint8Array[] = [];
    let total = 0, timer: ReturnType<typeof setTimeout> | undefined;
    const reading = (async () => {
        for (;;) {
            const { done, value } = await reader.read(); checkWork(deadline);
            if (done) break;
            total += value.byteLength;
            if (total > maximum) throw new Error('Native decoded size exceeds its retained-data bound.');
            pieces.push(value);
        }
    })();
    const writing = (async () => {
        // One pending <=16-byte write, concurrently drained; no assertion of empty native queues.
        for (let offset = 0; offset < payload.length; offset += 16) {
            checkWork(deadline);
            await writer.write(Uint8Array.from(payload.subarray(offset, offset + 16)));
        }
        await writer.close();
    })();
    try {
        await Promise.race([Promise.all([reading, writing]), new Promise<never>((_, reject) => {
            timer = setTimeout(() => reject(new Refusal('work-budget', 'Native stream exceeded the Worker deadline.', { member: 'container' })), Math.max(0, deadline - performance.now()));
        })]);
        checkWork(deadline);
        const output = new Uint8Array(total); let offset = 0;
        for (const piece of pieces) { output.set(piece, offset); offset += piece.byteLength; }
        return output;
    } catch (error) {
        await Promise.allSettled([reader.cancel(error), writer.abort(error), reading, writing]);
        throw error;
    } finally { clearTimeout(timer); reader.releaseLock(); writer.releaseLock(); }
}

/** Native stream host, not a second ZIP parser. A post-read bound is not an allocation ceiling. */
export async function readWebViewContainer(bytes: Uint8Array, deadline: number): Promise<ZipMembers> {
    const entries = scanContainer(bytes), result: ZipMembers = new Map();
    result.zipDescriptors = entries.flatMap(entry => entry.descriptor ? [entry.descriptor] : []);
    let retained = 0;
    for (const entry of entries) {
        checkWork(deadline);
        const payload = bytes.subarray(entry.dataStart, entry.dataStart + entry.compressed);
        let decoded: Uint8Array;
        if (entry.method === 0) decoded = payload.slice();
        else {
            const ctor = globalThis.DecompressionStream;
            if (typeof ctor !== 'function' || !await supportsFraming(ctor, deadline)) refuse('runtime-codec', 'Native deflate-raw is missing or fails the bounded exact-output/truncated/trailing framing gate; no compressed input is admitted.', { member: 'container' });
            try { decoded = await inflate(ctor, payload, Math.min(entry.decoded, limits.memberBytes, limits.decodedBytes - retained), deadline); }
            catch (error) { if (error instanceof Refusal) throw error; zipFail(`Unable to decode ${entry.name} within its bound.`); }
        }
        retained += decoded!.byteLength;
        if (retained > limits.decodedBytes) zipFail('Actual total decoded size exceeds its bound.');
        checkWork(deadline);
        result.set(entry.name, checkMember(entry, decoded!));
    }
    return finishContainer(result);
}

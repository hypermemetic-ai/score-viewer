import { Bytes } from './bytes.js';

/** Content routing only. Every selected reader independently validates its entire input. */
export function guitarProEncoding(bytes: Uint8Array): 'binary' | 'gpx' | 'zip' {
    const prefix = Bytes.view(bytes.subarray(0, 32));
    if (/^(?:FICHIER|CLIPBOARD)/.test(prefix.subarray(1).ascii())) return 'binary';
    if (['BCFS', 'BCFZ'].includes(prefix.subarray(0, 4).ascii())) return 'gpx';
    return 'zip';
}

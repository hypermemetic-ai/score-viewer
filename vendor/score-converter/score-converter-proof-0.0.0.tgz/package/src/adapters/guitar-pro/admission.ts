import { refuse, type Location } from '../../core/report.js';
export type InstrumentFamily = 'guitar' | 'bass';
const refs: Record<string, InstrumentFamily> = { bass: 'bass', 'electric-bass': 'bass', electricBass: 'bass', guitar: 'guitar', electricGuitar: 'guitar', 's-gtr6': 'guitar' };
export const observedFamily = (ref: string): InstrumentFamily | undefined => Object.hasOwn(refs, ref) ? refs[ref] : undefined;
/** Reviewed source references, not display labels or tuning-based instrument guesses. */
export function admittedFamily(ref: string, program: number, location: Location): InstrumentFamily {
    const family = observedFamily(ref);
    if (!family || (family === 'bass' ? program < 32 || program > 39 : program < 24 || program > 31))
        refuse('instrument-profile', 'Reviewed source instrument reference and encoded guitar/bass MIDI family must agree; names and tuning alone cannot authorize an instrument.', location);
    return family!;
}

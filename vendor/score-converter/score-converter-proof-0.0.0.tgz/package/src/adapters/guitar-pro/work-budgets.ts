import { refuse, type Finding, type Location } from '../../core/report.js';
import { limits } from './limits.js';

/** Count UTF-8 JSON without an input-sized serialization or encoded copy. */
export function jsonBytes(value: unknown, maximum: number, code = 'message-budget', location?: Location): number {
    let bytes = 0;
    const add = (n: number) => { if ((bytes += n) > maximum) refuse(code, 'Serialized source/report/result exceeds the explicit work budget; no partial output is admitted.', location); };
    const string = (s: string) => {
        add(2);
        for (let i = 0; i < s.length; i++) {
            const c = s.charCodeAt(i);
            if (c === 34 || c === 92 || [8,9,10,12,13].includes(c)) add(2);
            else if (c < 32) add(6);
            else if (c < 128) add(1);
            else if (c < 2048) add(2);
            else if (c >= 0xd800 && c <= 0xdbff && i + 1 < s.length && s.charCodeAt(i + 1) >= 0xdc00 && s.charCodeAt(i + 1) <= 0xdfff) { add(4); i++; }
            else if (c >= 0xd800 && c <= 0xdfff) add(6);
            else add(3);
        }
    };
    const visit = (v: unknown): void => {
        if (typeof v === 'string') string(v);
        else if (v === null || typeof v === 'boolean' || typeof v === 'number') add(typeof v === 'number' && !Number.isFinite(v) ? 4 : String(v).length);
        else if (Array.isArray(v)) { add(2 + Math.max(0, v.length - 1)); for (const item of v) visit(item === undefined ? null : item); }
        else if (v && typeof v === 'object') {
            add(2); let count = 0;
            for (const [key, item] of Object.entries(v)) if (item !== undefined) { if (count++) add(1); string(key); add(1); visit(item); }
        }
    };
    visit(value); return bytes;
}
export class BoundedFindings extends Array<Finding> {
    #bytes = 2;
    override push(...items: Finding[]): number {
        for (const item of items) {
            const bytes = jsonBytes(item, limits.reportBytes - this.#bytes - (this.length ? 1 : 0), 'report-budget', item.location);
            this.#bytes += bytes + (this.length ? 1 : 0);
            super.push(item);
        }
        return this.length;
    }
}

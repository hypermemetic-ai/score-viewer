/** Portable byte representation. Bounds remain the responsibility of each encoding reader. */
export class Bytes extends Uint8Array {
    static view(value: Uint8Array): Bytes { return new Bytes(value.buffer as ArrayBuffer, value.byteOffset, value.byteLength); }
    override subarray(start?: number, end?: number): Bytes { return Bytes.view(super.subarray(start, end)); }
    readUInt32LE(offset = 0): number { return this.data().getUint32(offset, true); }
    readUInt16LE(offset = 0): number { return this.data().getUint16(offset, true); }
    readUInt32BE(offset = 0): number { return this.data().getUint32(offset); }
    readUInt16BE(offset = 0): number { return this.data().getUint16(offset); }
    readInt32BE(offset = 0): number { return this.data().getInt32(offset); }
    readFloatBE(offset = 0): number { return this.data().getFloat32(offset); }
    private data(): DataView { return new DataView(this.buffer, this.byteOffset, this.byteLength); }
    equals(other: Uint8Array): boolean { return this.length === other.length && this.every((v, i) => v === other[i]); }
    copy(target: Uint8Array, at: number, start = 0, end = this.length): void { target.set(this.subarray(start, end), at); }
    text(): string { return new TextDecoder('utf-8', { fatal: true }).decode(this); }
    ascii(): string { return Array.from(this, byte => String.fromCharCode(byte)).join(''); }
    base64(): string {
        const alphabet = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
        const chunks: string[] = [];
        for (let start = 0; start < this.length; start += 12288) {
            let chunk = '';
            for (let i = start; i < Math.min(this.length, start + 12288); i += 3) {
                const a = this[i], b = this[i + 1], c = this[i + 2], n = a << 16 | (b ?? 0) << 8 | (c ?? 0);
                chunk += alphabet[n >>> 18] + alphabet[n >>> 12 & 63] + (i + 1 < this.length ? alphabet[n >>> 6 & 63] : '=') + (i + 2 < this.length ? alphabet[n & 63] : '=');
            }
            chunks.push(chunk);
        }
        return chunks.join('');
    }
}

const shaConstants = new Uint32Array([
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
]);
/** SHA-256 (FIPS 180-4), constant auxiliary memory; no input-sized padded copy. */
export function sha256(bytes: Uint8Array): string {
    const state = new Uint32Array([0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19]);
    const words = new Uint32Array(64), rotate = (n: number, bits: number) => n >>> bits | n << (32 - bits);
    const total = Math.ceil((bytes.length + 9) / 64) * 64, bitLength = bytes.length * 8;
    for (let offset = 0; offset < total; offset += 64) {
        for (let i = 0; i < 16; i++) {
            let word = 0;
            for (let j = 0; j < 4; j++) {
                const p = offset + i * 4 + j;
                const v = p < bytes.length ? bytes[p] : p === bytes.length ? 128 : p >= total - 4 ? Math.floor(bitLength / 2 ** ((total - 1 - p) * 8)) & 255 : p >= total - 8 ? Math.floor(bitLength / 2 ** ((total - 1 - p) * 8)) & 255 : 0;
                word = word << 8 | v;
            }
            words[i] = word;
        }
        for (let i = 16; i < 64; i++) {
            const x = words[i - 15], y = words[i - 2];
            words[i] = words[i - 16] + (rotate(x, 7) ^ rotate(x, 18) ^ x >>> 3) + words[i - 7] + (rotate(y, 17) ^ rotate(y, 19) ^ y >>> 10);
        }
        let [a,b,c,d,e,f,g,h] = state;
        for (let i = 0; i < 64; i++) {
            const t1 = h + (rotate(e, 6) ^ rotate(e, 11) ^ rotate(e, 25)) + (e & f ^ ~e & g) + shaConstants[i] + words[i];
            const t2 = (rotate(a, 2) ^ rotate(a, 13) ^ rotate(a, 22)) + (a & b ^ a & c ^ b & c);
            h=g; g=f; f=e; e=(d+t1)>>>0; d=c; c=b; b=a; a=(t1+t2)>>>0;
        }
        [a,b,c,d,e,f,g,h].forEach((value, i) => { state[i] += value; });
    }
    return [...state].map(value => value.toString(16).padStart(8, '0')).join('');
}

const crcTable = Uint32Array.from({ length: 256 }, (_, i) => {
    let value = i; for (let n = 0; n < 8; n++) value = value & 1 ? 0xedb88320 ^ value >>> 1 : value >>> 1;
    return value >>> 0;
});
export function crc32(bytes: Uint8Array): number {
    let value = 0xffffffff;
    for (const byte of bytes) value = crcTable[(value ^ byte) & 255] ^ value >>> 8;
    return (value ^ 0xffffffff) >>> 0;
}

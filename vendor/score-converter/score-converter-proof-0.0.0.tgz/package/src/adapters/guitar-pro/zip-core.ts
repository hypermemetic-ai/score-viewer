import { Bytes, crc32 } from './bytes.js';
import { limits } from './limits.js';
import { refuse, type Finding } from '../../core/report.js';
import { child, value, type Element } from './xml.js';

/** No extraction, ZIP64, encryption, links or ambiguous names. Every descriptor is checked against central CRC/lengths. */
export function scanContainer(bytes: Uint8Array): ZipEntry[] {
    if (bytes.byteLength > limits.inputBytes) refuse('input-size', 'Input exceeds the 8 MiB profile.');
    const b = Bytes.view(bytes);
    const fail = (message: string): never => refuse('zip', message, { member: 'container' });
    if (b.length < 22 || b.readUInt32LE(0) !== 0x04034b50) fail('Expected a local ZIP container. GP3–6 are separate profiles.');
    let end = -1;
    for (let i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) {
        if (b.readUInt32LE(i) === 0x06054b50 && i + 22 + b.readUInt16LE(i + 20) === b.length) { end = i; break; }
    }
    if (end < 0) fail('Missing or ambiguous ZIP end directory.');
    const count = b.readUInt16LE(end + 10), size = b.readUInt32LE(end + 12), offset = b.readUInt32LE(end + 16);
    if (b.readUInt16LE(end + 4) || b.readUInt16LE(end + 6) || b.readUInt16LE(end + 8) !== count)
        fail('Split archives are unsupported.');
    if (!count || count > limits.entries || offset + size !== end || end + 22 !== b.length)
        fail('Directory bounds, entry count or ZIP comments exceed the profile.');
    let pos = offset, total = 0;
    const entries: ZipEntry[] = [];
    const names = new Map<string, boolean>(), pathSpellings = new Map<string, string>();
    for (let i = 0; i < count; i++) {
        if (pos + 46 > end || b.readUInt32LE(pos) !== 0x02014b50) fail('Malformed central directory.');
        const flags = b.readUInt16LE(pos + 8), method = b.readUInt16LE(pos + 10);
        const crc = b.readUInt32LE(pos + 16), compressed = b.readUInt32LE(pos + 20), decoded = b.readUInt32LE(pos + 24);
        const nl = b.readUInt16LE(pos + 28), xl = b.readUInt16LE(pos + 30), cl = b.readUInt16LE(pos + 32);
        const start = b.readUInt32LE(pos + 42);
        if (pos + 46 + nl + xl + cl > end || flags & ~0x0808 || (method !== 0 && method !== 8) || b.readUInt16LE(pos + 34))
            fail('Unsupported ZIP flags, method, encryption or disk.');
        if (cl) fail('ZIP member comments are outside this profile.');
        // Exercised central-directory extended timestamp: five-byte mtime data.
        // It does not change member identity or decoded musical content.
        if (xl && (xl !== 9 || b.readUInt16LE(pos + 46 + nl) !== 0x5455 || b.readUInt16LE(pos + 48 + nl) !== 5 || ![1, 3].includes(b[pos + 50 + nl])))
            fail('Unreviewed ZIP extra fields; only the exercised central timestamp is admitted.');
        const rawName = b.subarray(pos + 46, pos + 46 + nl);
        const name = rawName.text();
        const directory = name.endsWith('/'), path = directory ? name.slice(0, -1) : name;
        if (!/^[A-Za-z0-9_.\/-]{1,120}$/.test(name) || name.startsWith('/') || path.split('/').some(p => !p || p === '.' || p === '..'))
            fail('Unsafe or ambiguous member path.');
        const folded = path.toLowerCase();
        if (names.has(folded)) fail('Duplicate or case-ambiguous member paths.');
        names.set(folded, directory);
        const components = path.split('/');
        for (let n = 1; n <= components.length; n++) {
            const spelling = components.slice(0, n).join('/'), key = spelling.toLowerCase();
            if (pathSpellings.has(key) && pathSpellings.get(key) !== spelling) fail('Case-ambiguous parent paths.');
            pathSpellings.set(key, spelling);
        }
        const unixType = (b.readUInt32LE(pos + 38) >>> 16) & 0xf000;
        const dosDirectory = !!(b.readUInt32LE(pos + 38) & 0x10);
        if (unixType && unixType !== (directory ? 0x4000 : 0x8000) || dosDirectory && !directory)
            fail('ZIP file/directory type disagrees with its path; links are unsupported.');
        if (directory && (decoded || crc || method === 0 && compressed)) fail('Directories must decode to empty entries with zero CRC.');
        total += decoded;
        if (decoded > limits.memberBytes || total > limits.decodedBytes || decoded > Math.max(1, compressed) * limits.compressionRatio)
            fail('Member/total decoded size or compression work exceeds the profile.');
        if (start + 30 > offset || b.readUInt32LE(start) !== 0x04034b50) fail('Invalid local header offset.');
        const localNl = b.readUInt16LE(start + 26), localXl = b.readUInt16LE(start + 28);
        const dataStart = start + 30 + localNl + localXl, dataEnd = dataStart + compressed;
        const descriptor = !!(flags & 8);
        let descriptorFact: ZipDescriptor | undefined, memberEnd = dataEnd;
        if (descriptor) {
            const candidates: { signed: boolean; reversed: boolean; length: number }[] = [];
            if (dataEnd + 16 <= offset && b.readUInt32LE(dataEnd) === 0x08074b50 && b.readUInt32LE(dataEnd + 4) === crc && b.readUInt32LE(dataEnd + 8) === compressed && b.readUInt32LE(dataEnd + 12) === decoded)
                candidates.push({ signed: true, reversed: false, length: 16 });
            if (dataEnd + 12 <= offset && b.readUInt32LE(dataEnd) === crc) {
                const first = b.readUInt32LE(dataEnd + 4), second = b.readUInt32LE(dataEnd + 8);
                if (first === compressed && second === decoded) candidates.push({ signed: false, reversed: false, length: 12 });
                // Only a candidate here: the exact observed GP source header is validated after bounded decode/parse.
                else if (first === decoded && second === compressed) candidates.push({ signed: false, reversed: true, length: 12 });
            }
            if (candidates.length !== 1) fail('ZIP descriptor framing/CRC/lengths are missing or ambiguous.');
            const candidate = candidates[0]; memberEnd += candidate.length;
            descriptorFact = { member: name, byteOffset: dataEnd, byteLength: candidate.length, signed: candidate.signed, order: candidate.reversed ? 'crc-decoded-compressed' : 'crc-compressed-decoded', crc, compressed, decoded, dataBase64: b.subarray(dataEnd, memberEnd).base64() };
        }
        if (memberEnd > offset) fail('Member or data descriptor exceeds local area.');
        const localCrc = b.readUInt32LE(start + 14), localCompressed = b.readUInt32LE(start + 18), localDecoded = b.readUInt32LE(start + 22);
        const emptyLocal = descriptor && localCrc === 0 && localCompressed === 0 && localDecoded === 0;
        const matchingLocal = localCrc === crc && localCompressed === compressed && localDecoded === decoded;
        if (dataEnd > offset || localXl || localNl !== nl || !b.subarray(start + 30, start + 30 + nl).equals(rawName) ||
            b.readUInt16LE(start + 6) !== flags || b.readUInt16LE(start + 8) !== method || !(emptyLocal || matchingLocal))
            fail('Local and central ZIP identity/length/CRC disagree.');
        entries.push({ name, directory, start, end: memberEnd, dataStart, compressed, decoded, crc, method, ...(descriptorFact ? { descriptor: descriptorFact } : {}) });
        pos += 46 + nl + xl + cl;
    }
    if (pos !== end) fail('Unaccounted central-directory content.');
    for (const [name, directory] of names) if (!directory && [...names.keys()].some(other => other.startsWith(name + '/')))
        fail('A payload file cannot be a parent directory.');
    const spans = entries.slice().sort((a, c) => a.start - c.start);
    let next = 0;
    for (const e of spans) {
        if (e.start !== next) fail('Overlapping or unaccounted local ZIP content.');
        next = e.end;
    }
    if (next !== offset) fail('Unaccounted bytes before ZIP directory.');
    return entries;
}
export interface ZipDescriptor { member: string; byteOffset: number; byteLength: number; signed: boolean; order: 'crc-compressed-decoded' | 'crc-decoded-compressed'; crc: number; compressed: number; decoded: number; dataBase64: string }
export interface ZipEntry { name: string; directory: boolean; start: number; end: number; dataStart: number; compressed: number; decoded: number; crc: number; method: number; descriptor?: ZipDescriptor }
export interface ZipMembers extends Map<string, Bytes> { zipDescriptors?: readonly ZipDescriptor[] }
/** Observed GP8.1.1 alias, not a general relaxation of ZIP descriptor order. */
export function admitDescriptors(members: ZipMembers, root: Element, findings: Finding[]): void {
    const descriptors = members.zipDescriptors ?? [];
    if (descriptors.some(d => d.order === 'crc-decoded-compressed')) {
        const revision = child(root, 'GPRevision')!, encoding = child(root, 'Encoding', false);
        if (value(root, 'GPVersion', false) !== '8.1.1' || revision.text.trim() !== '13007' || revision.attrs.required !== '12024' || revision.attrs.recommended !== '13000' || !encoding || value(encoding, 'EncodingDescription') !== 'GP8')
            refuse('zip-source-profile', 'Reversed unsigned descriptor sizes require the independently observed GP8.1.1/revision13007 source encoding profile.', root.location);
    }
    for (const descriptor of descriptors) findings.push({ disposition: 'preserved', code: descriptor.order === 'crc-decoded-compressed' ? 'zip-source-descriptor-order' : 'zip-descriptor', message: descriptor.order === 'crc-decoded-compressed' ? 'Observed GP8.1.1 unsigned descriptor stores decoded size before compressed size. Exact original bytes/order are retained; central/local spans, CRC and actual decode lengths still agree. This serialization alias does not authenticate a producer or alter music.' : 'Standard signed/unsigned descriptor framing, original bytes, CRC and lengths are retained after exact container validation.', location: { member: 'container', byteOffset: descriptor.byteOffset, byteLength: descriptor.byteLength }, fact: descriptor });
}
export const zipFail = (message: string): never => refuse('zip', message, { member: 'container' });
export function checkMember(entry: ZipEntry, bytes: Uint8Array): Bytes {
    if (bytes.length !== entry.decoded || crc32(bytes) !== entry.crc) zipFail(`Length/CRC failure in ${entry.name}.`);
    return Bytes.view(bytes);
}
export function finishContainer(result: Map<string, Bytes>): Map<string, Bytes> {
    if (!result.has('VERSION') || !result.has('Content/score.gpif') || result.get('VERSION')!.text() !== '7.0')
        zipFail('This profile requires VERSION=7.0 and exactly Content/score.gpif; it makes no suffix-based compatibility claim.');
    if ([...result.keys()].some(n => /score\.gpif$/i.test(n) && n !== 'Content/score.gpif')) zipFail('Ambiguous score.gpif member.');
    return result;
}

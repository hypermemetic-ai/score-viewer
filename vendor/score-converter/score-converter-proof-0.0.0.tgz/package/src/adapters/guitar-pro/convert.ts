import { convertPortable, type ConversionResult } from './convert-core.js';
import { readContainer } from './zip.js';
export type { ConversionResult, ConvertedPart } from './convert-core.js';
/** Internal synchronous Node worker entry. Public conversion runs in a bounded worker. */
export function convertInWorker(bytes: Uint8Array, options: { trackIds?: string[] } = {}): ConversionResult {
    return convertPortable(bytes, options, () => readContainer(bytes));
}

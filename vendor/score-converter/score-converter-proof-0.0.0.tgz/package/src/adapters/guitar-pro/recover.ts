import { GpifParser } from '../../../third_party/alphatab/src/importer/GpifParser.js';
import { Settings } from '../../../third_party/alphatab/src/ReaderSettings.js';
import { Logger } from '../../../third_party/alphatab/src/Logger.js';
import { LogLevel } from '../../../third_party/alphatab/src/LogLevel.js';
import { Note } from '../../../third_party/alphatab/src/model/Note.js';
import { add, decimal, equal, mul, q, type Rational } from '../../core/rational.js';
import { freeze, refuse, type Finding, type Location } from '../../core/report.js';
import type { Event, Measure, NeutralScore, NoteFact, Part, Pitch, Tempo } from '../../core/model.js';
import { child, children, integer, value, type Element } from './xml.js';
import { limits } from './limits.js';
import { admittedFamily } from './admission.js';
import type { GpifMode } from './profile.js';

const values: Record<string, [number, string]> = {
    Whole: [1, 'whole'], Half: [2, 'half'], Quarter: [4, 'quarter'], Eighth: [8, 'eighth'],
    '16th': [16, '16th'], '32nd': [32, '32nd'], '64th': [64, '64th']
};
function idmap(root: Element, group: string, kind: string): Map<string, Element> {
    const result = new Map<string, Element>();
    for (const e of children(child(root, group)!, kind)) {
        const id = e.attrs.id;
        if (!/^[0-9]{1,6}$/.test(id) || result.has(id)) refuse('identity', `Invalid/duplicate ${kind} ID.`, e.location);
        result.set(id, e);
    }
    if (!result.size) refuse('structure', `Empty ${group} are unsupported in this proof.`, root.location);
    return result;
}
function refs(e: Element, name: string, required = true): string[] {
    const s = value(e, name, required);
    if (!s) return [];
    if (!/^[0-9]{1,6}(?:\s+[0-9]{1,6})*$/.test(s)) refuse('reference', `Invalid ${name} reference list; missing placeholder scopes require a separate profile.`, e.location);
    return s.split(/\s+/);
}
function lookup(map: Map<string, Element>, id: string, at: Element): Element {
    const e = map.get(id);
    if (!e) refuse('reference', `Unresolved source ID ${id}.`, at.location);
    return e!;
}
function props(e: Element): Map<string, Element> {
    const result = new Map<string, Element>();
    const group = child(e, 'Properties', false);
    for (const p of group?.children ?? []) {
        if (result.has(p.attrs.name)) refuse('property', 'Duplicate source property.', p.location);
        result.set(p.attrs.name, p);
    }
    return result;
}
function flag(s: string | undefined, at: Element): boolean {
    if (s === undefined) return false;
    if (s !== 'true' && s !== 'false') refuse('boolean', 'Expected true/false.', at.location);
    return s === 'true';
}
const semitones: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
function inferPitch(midi: number): Pitch {
    const steps = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'];
    const step = steps[midi % 12], alter = midi % 12 - semitones[step];
    return { step, alter, octave: Math.floor(midi / 12) - 1, midi, origin: 'inferred' };
}
function pitch(property: Element, expected: number, convention: 'midi-octave' | 'scientific' = 'midi-octave'): Pitch {
    const p = child(property, 'Pitch')!, step = value(p, 'Step'), acc = value(p, 'Accidental');
    const alter = ({ '': 0, '#': 1, b: -1, x: 2, bb: -2 } as Record<string, number>)[acc];
    const octave = integer(value(p, 'Octave'), 0, 10, p);
    if (semitones[step] === undefined || alter === undefined) refuse('pitch', 'Unsupported pitch spelling.', p.location);
    const midi = (octave + (convention === 'scientific' ? 1 : 0)) * 12 + semitones[step] + alter;
    if (midi !== expected) refuse('pitch-conflict', `Encoded pitch ${step}${acc}${octave} (${midi}) disagrees with physical/transposition pitch ${expected}.`, p.location);
    return { step, alter, octave: octave - (convention === 'scientific' ? 0 : 1), midi, origin: 'source' };
}
export interface OccurrenceCapture {
    source: Location; rhythmId: string; noteId: string;
    before: { fret: number; string: number; tieDestination: boolean };
    after: { fret: number; string: number; tieDestination: boolean; soundingMidi: number; playbackTicks: number };
}
export interface Recovery { score: NeutralScore; occurrences: OccurrenceCapture[] }

/** Raw immutable GPIF feeds clocks/spelling; borrowed model is reconciled recovery evidence. */
export function recover(root: Element, xml: string, findings: Finding[], mode: GpifMode = 'constructed'): Recovery {
    const tracks = idmap(root, 'Tracks', 'Track'), bars = idmap(root, 'Bars', 'Bar'), voices = idmap(root, 'Voices', 'Voice');
    const beats = idmap(root, 'Beats', 'Beat'), notes = idmap(root, 'Notes', 'Note'), rhythms = idmap(root, 'Rhythms', 'Rhythm');
    const trackIds = refs(child(root, 'MasterTrack')!, 'Tracks');
    if (trackIds.length !== tracks.size || new Set(trackIds).size !== trackIds.length || trackIds.length > limits.tracks)
        refuse('track-scope', 'Every defined track must occur exactly once in the master track and fit the profile.', root.location);
    const masters = children(child(root, 'MasterBars')!, 'MasterBar');
    if (!masters.length || masters.length > limits.measures) refuse('measure-budget', 'Measure count outside profile.', root.location);
    const used = { bars: new Set<string>(), voices: new Set<string>(), beats: new Set<string>(), notes: new Set<string>(), rhythms: new Set<string>() };
    const expectedOccurrences: { note: NoteFact; event: Event; rhythmId: string }[] = [];
    let eventCount = 0, noteCount = 0;
    const pickup = !!child(child(root, 'MasterTrack')!, 'Anacrusis', false);
    let repeatOpen = false;
    const common = masters.map((master, index) => {
        const time = value(master, 'Time').split('/');
        if (time.length !== 2) refuse('meter', 'Expected n/d meter.', master.location);
        const unit = integer(time[1], 1, 64, master), numerator = integer(time[0], 1, 32, master);
        if (unit & (unit - 1)) refuse('meter', 'Meter denominator must be a power of two.', master.location);
        const key = child(master, 'Key')!, fifths = integer(value(key, 'AccidentalCount'), -7, 7, key), mode = value(key, 'Mode');
        if (!['Major', 'Minor'].includes(mode)) refuse('key', 'Unsupported key mode.', key.location);
        const ids = refs(master, 'Bars');
        if (ids.length !== tracks.size || new Set(ids).size !== ids.length) refuse('bar-scope', 'One unique staff bar per track is required.', master.location);
        const repeat = child(master, 'Repeat', false);
        const start = repeat ? flag(repeat.attrs.start, repeat) : false, end = repeat ? flag(repeat.attrs.end, repeat) : false;
        if (start && repeatOpen) refuse('repeat', 'Nested repeats are not supported.', master.location);
        if (start) repeatOpen = true;
        if (end && !repeatOpen) refuse('repeat', 'An explicit repeat start is required.', master.location);
        const count = end ? integer(repeat!.attrs.count, 2, 8, repeat!) : 0;
        if (repeat?.attrs.count) integer(repeat.attrs.count, 2, 8, repeat);
        if (repeat && !end && repeat.attrs.count) findings.push({ disposition: 'omitted', code: 'inactive-repeat-count', message: 'Inactive repeat count does not specify playback without an end flag; retained in original input (capture delivered only on success).', location: repeat.location, fact: repeat.attrs.count });
        if (end) repeatOpen = false;
        return { time: { beats: numerator, unit }, key: { fifths, mode: mode.toLowerCase() }, duration: q(numerator * 4, unit), ids, start, count, pickup: index === 0 && pickup };
    });
    if (repeatOpen) refuse('repeat', 'Unclosed repeat start.', masters.at(-1)!.location);
    const parts: Part[] = trackIds.map((trackId, trackIndex) => {
        const t = lookup(tracks, trackId, root), properties = props(t), tuningProperty = properties.get('Tuning');
        if (!tuningProperty) refuse('tuning', 'Explicit tuning is required; no instrument-name defaults.', t.location);
        const tuningText = value(tuningProperty!, 'Pitches');
        const tuning = tuningText.split(/\s+/).map(s => integer(s, 12, 108, tuningProperty!));
        if (tuning.length < 4 || tuning.length > 8 || tuning.some((n, i) => i > 0 && n <= tuning[i - 1]))
            refuse('tuning', 'This profile requires 4–8 explicitly ordered ascending strings.', tuningProperty!.location);
        const capo = properties.get('CapoFret');
        if (capo && integer(value(capo, 'Fret'), 0, 24, capo) !== 0) refuse('capo', 'Nonzero/partial capo needs a separately exercised pitch convention.', capo.location);
        const trans = child(t, 'Transpose', false);
        const octaves = trans ? integer(value(trans, 'Octave'), -2, 2, trans) : 0;
        if (trans && integer(value(trans, 'Chromatic'), -12, 12, trans) !== 0) refuse('transpose', 'Only explicitly encoded octave transposition is exercised.', trans.location);
        const midi = child(t, 'GeneralMidi')!;
        if (midi.attrs.table !== 'Instrument') refuse('instrument', 'Non-string/percussion tables require another profile.', midi.location);
        const program = integer(value(midi, 'Program'), 0, 127, midi);
        const instrument = child(t, 'Instrument')!;
        if (!/^[A-Za-z0-9_-]{1,128}$/.test(instrument.attrs.ref ?? '')) refuse('instrument', 'An explicit nonempty instrument reference is required.', instrument.location);
        admittedFamily(instrument.attrs.ref, program, instrument.location);
        if (instrument.attrs.ref === 's-gtr6' && tuning.length !== 6) refuse('instrument-profile', 'The reviewed s-gtr6 source reference requires six explicit strings.', instrument.location);
        let convention: 'midi-octave-written' | 'scientific-physical' | 'absent' = mode === 'gp8-scientific' ? 'scientific-physical' : 'midi-octave-written';
        if (mode === 'gpif-physical') {
            let midiOctave = true, scientific = true, explicit = 0, absent = 0;
            const reachable = new Set<string>();
            for (const c of common) for (const voiceId of refs(lookup(bars, c.ids[trackIndex], t), 'Voices'))
                for (const beatId of refs(lookup(voices, voiceId, t), 'Beats'))
                    for (const noteId of refs(lookup(beats, beatId, t), 'Notes', false)) reachable.add(noteId);
            for (const id of reachable) {
                const n = lookup(notes, id, t), p = props(n), concert = p.get('ConcertPitch'), transposed = p.get('TransposedPitch'), sourceMidi = p.get('Midi');
                if (!concert && !transposed && !sourceMidi) { absent++; continue; }
                if (!concert || !transposed || !sourceMidi) refuse('pitch-corroboration', 'Encoded pitch profile requires complete ConcertPitch/TransposedPitch/Midi triplets, or wholly absent GP6 spelling.', n.location);
                const string = p.get('String'), fret = p.get('Fret');
                if (!string || !fret) refuse('physical-pitch', 'Explicit source string/fret required.', n.location);
                const physical = tuning[integer(value(string!, 'String'), 0, tuning.length - 1, string!)] + integer(value(fret!, 'Fret'), 0, 36, fret!);
                if (integer(value(sourceMidi!, 'Number'), 0, 127, sourceMidi!) !== physical) refuse('pitch-conflict', 'Source MIDI disagrees with physical tuning plus fret.', sourceMidi!.location);
                const raw = (property: Element): number => {
                    const field = child(property, 'Pitch')!, step = value(field, 'Step'), acc = value(field, 'Accidental');
                    const alter = ({ '': 0, '#': 1, b: -1, x: 2, bb: -2 } as Record<string, number>)[acc];
                    if (semitones[step] === undefined || alter === undefined) refuse('pitch', 'Unsupported source spelling.', field.location);
                    return integer(value(field, 'Octave'), 0, 10, field) * 12 + semitones[step] + alter;
                };
                const cp = raw(concert!), tp = raw(transposed!);
                midiOctave &&= cp === physical && tp === physical - octaves * 12;
                scientific &&= cp + 12 === physical && tp + 12 === physical;
                explicit++;
            }
            const gp6 = !value(root, 'GPVersion', false) || /^6(?:\.|$)/.test(value(root, 'GPVersion', false));
            if (absent && (!gp6 || explicit)) refuse('pitch-corroboration', 'Only GP6 wholly absent spelling is admitted; mixed profiles are refused.', t.location);
            if (explicit && midiOctave === scientific) refuse('pitch-conflict', 'All source note tuples must establish one consistent physical pitch convention; version labels do not choose it.', t.location);
            convention = explicit ? midiOctave ? 'midi-octave-written' : 'scientific-physical' : 'absent';
            if (!explicit && !gp6 && reachable.size) refuse('pitch-corroboration', 'GP7/8 physical admission requires complete explicit pitch triplets.', t.location);
            findings.push({ disposition: convention === 'absent' ? 'inferred' : 'preserved', code: 'gpif-pitch-profile', message: 'Pitch encoding profile is established across every reachable source note using physical tuning/fret/MIDI consistency, independently of producer/version labels. Raw pitches remain unchanged.', location: t.location, fact: { convention, explicitNotes: explicit, absentNotes: absent } });
        }
        const measures: Measure[] = common.map((c, measureIndex) => {
            const barId = c.ids[trackIndex], b = lookup(bars, barId, masters[measureIndex]);
            if (used.bars.has(barId)) refuse('bar-reuse', 'Reused staff bar objects require distinct occurrence construction.', b.location);
            used.bars.add(barId);
            const clef = value(b, 'Clef');
            if (!['G2', 'F4', 'C3', 'C4'].includes(clef)) refuse('clef', 'Unsupported clef.', b.location);
            const voiceIds = refs(b, 'Voices');
            if (!voiceIds.length || voiceIds.length > 4 || new Set(voiceIds).size !== voiceIds.length) refuse('voice-scope', 'Expected 1–4 distinct voices.', b.location);
            const recoveredVoices = voiceIds.map((voiceId, voiceIndex) => {
                const v = lookup(voices, voiceId, b);
                if (used.voices.has(voiceId)) refuse('voice-reuse', 'Reused voice objects require a separate reader patch; beat/note reuse is supported.', v.location);
                used.voices.add(voiceId);
                const ids = refs(v, 'Beats');
                if (!ids.length && mode === 'constructed') refuse('empty-voice', 'Represent silence with explicit rhythmic rests.', v.location);
                let position = q(0);
                return ids.map((beatId, beatIndex) => {
                    if (++eventCount > limits.occurrences) refuse('occurrence-budget', 'Expanded occurrence budget exceeded.', v.location);
                    used.beats.add(beatId);
                    const be = lookup(beats, beatId, v), rhythmRef = child(be, 'Rhythm')!.attrs.ref;
                    const r = lookup(rhythms, rhythmRef, be); used.rhythms.add(rhythmRef);
                    const type = value(r, 'NoteValue'), item = values[type];
                    if (!item) refuse('rhythm', 'Written duration outside whole–64th profile.', r.location);
                    const dot = child(r, 'AugmentationDot', false), dots = dot ? integer(dot.attrs.count, 0, 2, dot) : 0;
                    const tuple = child(r, 'PrimaryTuplet', false);
                    const tuplet = tuple ? { actual: integer(tuple.attrs.num, 2, 16, tuple), normal: integer(tuple.attrs.den, 1, 16, tuple) } : undefined;
                    let duration = q(4, item[0]);
                    duration = mul(duration, q(2 ** (dots + 1) - 1, 2 ** dots));
                    if (tuplet) duration = mul(duration, q(tuplet.normal, tuplet.actual));
                    const location = { ...be.location, trackId, measure: measureIndex + 1, voice: voiceIndex + 1, beat: beatIndex + 1 };
                    const noteIds = refs(be, 'Notes', false);
                    if (new Set(noteIds).size !== noteIds.length || noteIds.length > tuning.length) refuse('chord', 'Duplicate/oversized chord.', location);
                    if ((noteCount += noteIds.length) > limits.occurrences) refuse('occurrence-budget', 'Expanded note occurrence budget exceeded.', location);
                    const sourceNotes: NoteFact[] = noteIds.map(noteId => {
                        used.notes.add(noteId); const n = lookup(notes, noteId, be), np = props(n);
                        const stringProp = np.get('String'), fretProp = np.get('Fret');
                        if (!stringProp || !fretProp) refuse('physical-pitch', 'Explicit string and fret are required.', n.location);
                        const stringIndex = integer(value(stringProp!, 'String'), 0, tuning.length - 1, stringProp!);
                        const fret = integer(value(fretProp!, 'Fret'), 0, 36, fretProp!);
                        const soundingMidi = tuning[stringIndex] + fret;
                        const writtenMidi = soundingMidi - octaves * 12;
                        if (soundingMidi > 127 || writtenMidi < 12 || writtenMidi > 127) refuse('pitch-range', 'Pitch outside MIDI/reference range.', n.location);
                        const concert = np.get('ConcertPitch'), transposed = np.get('TransposedPitch');
                        let sounding: Pitch, written: Pitch;
                        if (convention === 'scientific-physical' && mode !== 'constructed') {
                            const sourceMidi = np.get('Midi');
                            if (!concert || !transposed || !sourceMidi) refuse('pitch-corroboration', 'GP8 admission requires both full pitch fields and Midi/Number.', n.location);
                            if (integer(value(sourceMidi!, 'Number'), 0, 127, sourceMidi!) !== soundingMidi)
                                refuse('pitch-conflict', 'Midi/Number differs from independently derived tuning plus fret.', sourceMidi!.location);
                            sounding = pitch(concert!, soundingMidi, 'scientific');
                            const rawDisplay = pitch(transposed!, soundingMidi, 'scientific');
                            if (rawDisplay.step !== sounding.step || rawDisplay.alter !== sounding.alter)
                                refuse('pitch-conflict', 'Both encoded pitch spellings must corroborate the observed sounding-pitch convention.', n.location);
                            written = { ...rawDisplay, midi: writtenMidi, octave: rawDisplay.octave - octaves, origin: 'inferred' };
                            findings.push({ disposition: 'inferred', code: 'gp8-written-register', message: 'Observed raw pitch fields encode sounding register. Written register is calculated from corroborated physical/MIDI pitch and explicit source octave display transpose; raw fields stay untouched (gp8-scientific-physical/0).', location: { ...n.location, ...location, path: n.location.path, id: noteId }, fact: { rawConcert: sounding, rawTransposed: rawDisplay, transposeOctaves: octaves } });
                        } else {
                            sounding = concert ? pitch(concert, soundingMidi) : inferPitch(soundingMidi);
                            written = transposed ? pitch(transposed, writtenMidi) : inferPitch(writtenMidi);
                        }
                        if (mode !== 'constructed' && child(n, 'InstrumentArticulation', false) && integer(value(n, 'InstrumentArticulation'), 0, 127, n) !== 0) refuse('articulation-profile', 'Only default pitched articulation0 is admitted.', n.location);
                        const dead = np.has('Muted');
                        if (dead && !child(np.get('Muted')!, 'Enable', false)) refuse('technique', 'Muted property requires an explicit Enable marker.', n.location);
                        const tie = child(n, 'Tie', false);
                        if (tie && (!('origin' in tie.attrs) || !('destination' in tie.attrs))) refuse('tie', 'Both tie endpoint flags must be explicit.', tie.location);
                        if (!concert || !transposed) findings.push({ disposition: 'inferred', code: 'pitch-spelling', message: 'Absent spelling uses an explicit sharp-based reference spelling; physical pitch and encoded octave transposition are retained.', location: { ...n.location, ...location, path: n.location.path, id: noteId }, fact: { concertPresent: !!concert, transposedPresent: !!transposed } });
                        return { source: { ...location, ...n.location, trackId, measure: measureIndex + 1, voice: voiceIndex + 1, beat: beatIndex + 1 }, id: noteId,
                            string: tuning.length - stringIndex, fret, kind: dead ? 'dead' : 'pitched', sounding: dead ? null : sounding, written,
                            ...(dead ? { referenceSounding: sounding } : {}),
                            ...(np.has('HopoOrigin') ? { sourceHopoOrigin: !!child(np.get('HopoOrigin')!, 'Enable') } : {}),
                            ...(np.has('HopoDestination') ? { sourceHopoDestination: !!child(np.get('HopoDestination')!, 'Enable') } : {}),
                            tieStart: tie ? flag(tie.attrs.origin, tie) : false, tieStop: tie ? flag(tie.attrs.destination, tie) : false };
                    });
                    if (new Set(sourceNotes.map(n => n.string)).size !== sourceNotes.length) refuse('chord-string', 'One chord cannot occupy the same string twice.', location);
                    const event: Event = { source: location, id: beatId, start: position, duration, type: item[1], dots, ...(tuplet ? { tuplet } : {}), notes: sourceNotes,
                        ...(child(be, 'Dynamic', false) ? { dynamic: value(be, 'Dynamic') } : {}),
                        fullMeasureRest: !noteIds.length && ids.length === 1 && equal(duration, c.duration), ...(child(be, 'FreeText', false) ? { text: value(be, 'FreeText') } : {}) };
                    for (const note of sourceNotes) expectedOccurrences.push({ note, event, rhythmId: rhythmRef });
                    position = add(position, duration);
                    return event;
                });
            });
            const totals = recoveredVoices.filter(v => v.length).map(v => v.reduce((s, e) => add(s, e.duration), q(0)));
            if (!totals.length) refuse('empty-measure', 'At least one voice must explicitly encode its silence/music span.', b.location);
            const actualDuration = c.pickup ? totals[0] : c.duration;
            if (!totals.every(t => equal(t, actualDuration)) || c.pickup && actualDuration.n * c.duration.d >= c.duration.n * actualDuration.d)
                refuse('measure-duration', 'Voices must fill the exact common measure span; pickup voices must agree and be shorter than meter.', b.location);
            return { source: { ...b.location, trackId, measure: measureIndex + 1 }, time: c.time, key: c.key, clef,
                pickup: c.pickup, duration: actualDuration, voices: recoveredVoices, repeatStart: c.start, repeatEnd: c.count };
        });
        // Validate source ties before letting alphaTab infer or repair any link.
        const pending = new Map<string, { note: NoteFact; end: Rational }>();
        let absolute = q(0);
        for (const m of measures) {
            for (let vi = 0; vi < m.voices.length; vi++) for (const e of m.voices[vi]) {
                const start = add(absolute, e.start);
                for (const n of e.notes) {
                    const key = `${vi}:${n.string}`, previous = pending.get(key);
                    if (n.kind === 'dead' && (n.tieStart || n.tieStop || n.sourceHopoOrigin || n.sourceHopoDestination)) refuse('dead-relation', 'Dead-note tie/HOPO semantics are outside this profile.', n.source);
                    if (n.tieStop && (!previous || !equal(previous.end, start) || previous.note.sounding?.midi !== n.sounding?.midi || previous.note.written.midi !== n.written.midi || previous.note.fret !== n.fret || previous.note.written.step !== n.written.step || previous.note.written.alter !== n.written.alter))
                        refuse('tie-conflict', 'Tie destination has no contiguous, identical explicit origin; no source pitch/fret repair is permitted.', n.source);
                    if (!n.tieStop && previous) refuse('tie-conflict', 'Explicit tie origin reaches an ordinary attack.', n.source);
                    pending.delete(key);
                    if (n.tieStart) pending.set(key, { note: n, end: add(start, e.duration) });
                }
            }
            absolute = add(absolute, m.duration);
        }
        // Source HOPO flags must pair on the next contiguous beat of the same voice/string.
        for (let vi = 0; vi < Math.max(...measures.map(m => m.voices.length)); vi++) {
            const events: { e: Event; absolute: Rational }[] = [];
            let barStart = q(0);
            for (const m of measures) {
                for (const e of m.voices[vi] ?? []) events.push({ e, absolute: add(barStart, e.start) });
                barStart = add(barStart, m.duration);
            }
            const paired = new Set<NoteFact>();
            for (let ei = 0; ei < events.length; ei++) for (const origin of events[ei].e.notes) {
                if (!origin.sourceHopoOrigin) continue;
                const next = events[ei + 1], target = next?.e.notes.find(n => n.string === origin.string)!;
                if (!next || !target?.sourceHopoDestination || !equal(add(events[ei].absolute, events[ei].e.duration), next.absolute) || target.fret === origin.fret || origin.kind !== 'pitched' || target.kind !== 'pitched')
                    refuse('hopo-conflict', 'HOPO requires explicit paired same-string contiguous endpoints with a changed fret.', origin.source);
                const kind = target.fret > origin.fret ? 'hammer-on' : 'pull-off';
                if (events[ei].e.notes.filter(n => n.sourceHopoOrigin).length > 1) refuse('hopo-polyphony', 'Concurrent same-voice HOPO pairs need additional notation numbering coverage.', origin.source);
                origin.hopoStart = kind; target.hopoStop = kind; origin.hopoNumber = target.hopoNumber = vi + 1; paired.add(target);
                findings.push({ disposition: 'inferred', code: 'hopo-classification', message: 'Paired source HOPO flags classified by same-string fret direction; exported as standard hammer-on/pull-off endpoints with a derived short connection slur. This is performance-connection notation, not separately sourced phrasing (source-hopo/0).', location: origin.source, fact: { kind, destination: target.source } });
            }
            for (const { e } of events) for (const n of e.notes) if (n.sourceHopoDestination && !paired.has(n)) refuse('hopo-conflict', 'Unpaired explicit HOPO destination.', n.source);
        }
        for (const m of measures) for (const v of m.voices) for (const e of v) {
            if (e.dynamic && !['PPP', 'PP', 'P', 'MP', 'MF', 'F', 'FF', 'FFF'].includes(e.dynamic)) refuse('dynamic', 'Unknown dynamic value.', e.source);
            for (const n of e.notes) if (n.kind === 'dead') findings.push({ disposition: 'omitted', code: 'dead-playback-timbre', message: 'Dead note exports as standard unpitched x notehead with dead-note technical meaning and hidden physical guidance. Original reference pitch is retained; playback timbre is not assigned or verified.', location: n.source, fact: { physicalReference: n.referenceSounding } });
        }
        if (pending.size) refuse('tie-conflict', 'Explicit tie origin has no destination.', [...pending.values()][0].note.source);
        return { source: t.location, id: trackId, name: value(t, 'Name'), instrument: instrument.attrs.ref,
            midiProgram: program, tuning, transposeOctaves: octaves, measures };
    });
    if (parts.some(p => !equal(p.measures[0].duration, parts[0].measures[0].duration)))
        refuse('pickup-span', 'All tracks must share one exact master-bar pickup span; no implicit padding.', root.location);
    // Every source musical definition must be reachable; no successful hidden dropping.
    for (const [name, map] of Object.entries({ bars, voices, beats, notes, rhythms })) {
        for (const [id, e] of map) if (!used[name as keyof typeof used].has(id)) refuse('unreferenced', `Unreferenced ${name} source object ${id}.`, e.location);
    }
    const tempos: Tempo[] = [];
    for (const a of child(child(root, 'MasterTrack')!, 'Automations', false)?.children ?? []) {
        if (value(a, 'Type') !== 'Tempo' || flag(value(a, 'Linear'), a)) refuse('automation', 'Only discrete tempo automations are exercised.', a.location);
        const measure = integer(value(a, 'Bar'), 0, masters.length - 1, a);
        const position = decimal(value(a, 'Position'));
        if (position.n >= position.d) refuse('tempo-position', 'Tempo ratio position must be in [0,1).', a.location);
        const partsValue = value(a, 'Value').split(/\s+/);
        if (partsValue.length !== 2) refuse('tempo-reference', 'Original rate plus explicit tempo unit/reference are required.', a.location);
        const rate = decimal(partsValue[0]), reference = integer(partsValue[1], 1, 5, a);
        if (rate.n <= 0 || rate.n > 1000 * rate.d) refuse('tempo-rate', 'Tempo rate outside profile.', a.location);
        const ref = ([null, ['eighth', 0, 0.5], ['quarter', 0, 1], ['quarter', 1, 1.5], ['half', 0, 2], ['half', 1, 3]] as const)[reference]!;
        const actual = parts[0].measures[measure].duration;
        tempos.push({ source: a.location, measure, position: mul(position, actual), rate: partsValue[0], reference,
            unit: ref[0], dots: ref[1], quarterRate: rate.n / rate.d * ref[2], visible: flag(value(a, 'Visible'), a) });
        findings.push({ disposition: 'preserved', code: 'tempo-unit', message: 'Original tempo rate, unit, visibility and exact position preserved.', location: a.location, fact: { rate: partsValue[0], reference, ratioPosition: position, visible: value(a, 'Visible') } });
        if (child(a, 'Text', false)) findings.push({ disposition: 'omitted', code: 'tempo-text', message: 'Tempo annotation text retained in original input (capture delivered only on success); notation export not exercised.', location: child(a, 'Text')!.location, fact: value(a, 'Text') });
    }
    if (!tempos.length) findings.push({ disposition: 'omitted', code: 'no-tempo', message: 'No encoded tempo exists; no upstream playback default is printed.', location: root.location });
    freeze(parts); freeze(tempos);
    const occurrenceKey = (location: Location, noteId: string) => `${location.trackId}:${location.measure}:${location.voice}:${location.beat}:${noteId}`;
    const expectedByKey = new Map(expectedOccurrences.map(e => [occurrenceKey(e.note.source, e.note.id), e]));
    const capturedKeys = new Set<string>();
    const parser = new GpifParser(), captures: OccurrenceCapture[] = [], normalized: Note[] = [];
    const capturedExpected: typeof expectedOccurrences = [];
    // Avoid score-controlled or accidental upstream diagnostic dumps.
    Logger.logLevel = LogLevel.None;
    parser.onNoteOccurrence = (s, note) => {
        const key = `${s.trackId}:${s.measure + 1}:${s.voice + 1}:${s.beat + 1}:${s.noteId}`;
        const expected = expectedByKey.get(key)!;
        if (capturedKeys.has(key)) refuse('reader-identity', 'Duplicate borrowed source occurrence.', root.location);
        capturedKeys.add(key);
        if (!expected || s.noteId !== expected.note.id || s.beatId !== expected.event.id || s.rhythmId !== expected.rhythmId || s.trackId !== expected.note.source.trackId || s.measure + 1 !== expected.note.source.measure || s.voice + 1 !== expected.note.source.voice || s.beat + 1 !== expected.note.source.beat)
            refuse('reader-identity', 'Borrowed reader occurrence identity differs from the complete source traversal.', root.location);
        captures.push({ source: expected.note.source, rhythmId: s.rhythmId, noteId: s.noteId,
            before: freeze({ fret: note.fret, string: note.string, tieDestination: note.isTieDestination }),
            after: { fret: 0, string: 0, tieDestination: false, soundingMidi: 0, playbackTicks: 0 } });
        normalized.push(note); capturedExpected.push(expected);
    };
    try { parser.parseXml(xml, new Settings()); } catch (e) {
        if (e instanceof Error && 'code' in e) throw e;
        refuse('reader', 'Borrowed GPIF reader failed within the admitted profile.', root.location);
    }
    if (captures.length !== expectedOccurrences.length || parser.score.tracks.length !== parts.length)
        refuse('reader-coverage', 'Borrowed reader did not recover the complete requested source scope.', root.location);
    for (let i = 0; i < captures.length; i++) {
        const n = normalized[i], expected = capturedExpected[i];
        captures[i].after = { fret: n.fret, string: n.string, tieDestination: n.isTieDestination, soundingMidi: n.realValue, playbackTicks: n.beat.playbackDuration };
        if (n.realValue !== (expected.note.sounding ?? expected.note.referenceSounding)!.midi || n.fret !== expected.note.fret || n.string !== parts.find(p => p.id === expected.note.source.trackId)!.tuning.length - expected.note.string + 1 || n.isTieDestination !== expected.note.tieStop || n.isDead !== (expected.note.kind === 'dead'))
            refuse('reader-reconciliation', 'Normalized pitch, physical choice or tie disagrees with immutable source facts.', expected.note.source);
    }
    for (let pi = 0; pi < parts.length; pi++) {
        const track = parser.score.tracks[pi];
        if (track.staves.length !== 1 || track.staves[0].bars.length !== masters.length) refuse('reader-scope', 'Borrowed staff/measure scope differs.', parts[pi].source);
        for (let mi = 0; mi < masters.length; mi++) {
            const bar = track.staves[0].bars[mi], measure = parts[pi].measures[mi];
            if (bar.voices.length !== measure.voices.length) refuse('reader-scope', 'Borrowed voice scope differs.', measure.source);
            for (let vi = 0; vi < measure.voices.length; vi++) {
                const voice = bar.voices[vi];
                if (!measure.voices[vi].length && voice.beats.every(beat => beat.isEmpty && !beat.notes.length)) continue;
                if (voice.beats.length !== measure.voices[vi].length) refuse('reader-scope', 'Borrowed beat scope differs.', measure.source);
                for (let bi = 0; bi < voice.beats.length; bi++) {
                    const be = voice.beats[bi], source = measure.voices[vi][bi];
                    if (be.notes.length !== source.notes.length || be.dots !== source.dots || be.duration !== (values[Object.keys(values).find(k => values[k][1] === source.type)!][0]))
                        refuse('reader-rhythm', 'Borrowed written rhythm/chord disagrees with source.', source.source);
                }
            }
        }
    }
    findings.push({ disposition: 'preserved', code: 'source-reconciled', message: 'Complete source definitions, cloned occurrence IDs and normalized pitch/voice/rhythm/tie scope reconciled; exact source clocks replace truncated playback ticks.', location: root.location, fact: { noteOccurrences: captures.length, events: eventCount } });
    return { score: freeze({ title: value(child(root, 'Score')!, 'Title'), parts, tempos }), occurrences: freeze(captures) };
}

import { freeze, refuse, type Finding } from '../../core/report.js';
import { child, children, integer, value, type Element } from './xml.js';
import { limits } from './limits.js';

function rebuilt(e: Element, elements: Element[], text = e.text): Element { return { ...e, text, children: elements }; }
function leaf(e: Element, name: string, text: string, attrs: Record<string, string> = {}): Element { return { name, text, attrs, children: [], location: e.location }; }
function shape(e: Element, allowed: string[], attrs: string[] = [], repeated: string[] = []): void {
    if (allowed.length && e.text.trim()) refuse('mixed-content', 'Mixed structural content is unsupported.', e.location);
    for (const a of Object.keys(e.attrs)) if (!attrs.includes(a)) refuse('unknown-attribute', `Unreviewed ${e.name} attribute ${a}.`, e.location);
    const seen = new Set<string>();
    for (const c of e.children) {
        if (!allowed.includes(c.name)) refuse('unknown-element', `Unreviewed ${e.name}/${c.name} before reader projection.`, c.location);
        if (seen.has(c.name) && !repeated.includes(c.name)) refuse('structure', `Duplicate ${e.name}/${c.name}.`, c.location);
        seen.add(c.name);
    }
}
function scalar(e: Element): void { shape(e, []); }
function marker(e: Element): void { scalar(e); if (e.text.trim()) refuse('marker-content', 'Expected an empty marker.', e.location); }
function defined(root: Element, group: string, kind: string): Map<string, Element> {
    const result = new Map<string, Element>();
    const container = child(root, group)!; shape(container, [kind], [], [kind]);
    for (const e of container.children) {
        for (const a of Object.keys(e.attrs)) if (a !== 'id') refuse('unknown-attribute', `Unreviewed ${kind} attribute ${a}.`, e.location);
        if (!/^\d{1,6}$/.test(e.attrs.id) || result.has(e.attrs.id)) refuse('identity', `Invalid/duplicate ${kind} identity.`, e.location);
        result.set(e.attrs.id, e);
    }
    return result;
}
const ids = (e: Element, name: string, required = true): string[] => {
    const field = child(e, name, required); if (!field) return []; scalar(field);
    return field.text.trim().split(/\s+/).filter(Boolean);
};
function named(e: Element, permitted: string[], findings: Finding[], keep: string[], translated: string[] = []): Element[] {
    shape(e, permitted, ['Track', 'Beat', 'Bar'].includes(e.name) ? ['id'] : []);
    const result: Element[] = [];
    for (const c of e.children) {
        if (!permitted.includes(c.name)) refuse('unknown-element', `Unreviewed ${e.name}/${c.name} in the selected GP8 scope.`, c.location);
        if (keep.includes(c.name)) result.push(c);
        else if (!translated.includes(c.name)) findings.push({ disposition: 'omitted', code: 'gp8-metadata', message: 'Preserved in original source; capture is delivered only on success; layout, view, synth/timbre or non-score metadata is not reapplied to ordinary staff output.', location: c.location });
    }
    return result;
}
function checkDefaultArticulation(track: Element): string {
    const set = child(track, 'InstrumentSet')!;
    shape(set, ['Name', 'Type', 'LineCount', 'Elements']);
    for (const c of set.children.filter(e => e.name !== 'Elements')) scalar(c);
    const type = value(set, 'Type');
    if (!['electricBass', 'electricGuitar'].includes(type) || child(set, 'LineCount', false) && value(set, 'LineCount') !== '5')
        refuse('instrument-profile', 'The fretted source profile admits electricBass/electricGuitar on five ordinary staff lines only.', set.location);
    const container = child(set, 'Elements')!; shape(container, ['Element'], [], ['Element']);
    const elements = container.children;
    if (elements.length !== 1) refuse('articulation-profile', 'One pitched instrument element is required.', set.location);
    const element = elements[0]; shape(element, ['Name', 'Type', 'SoundbankName', 'Articulations']);
    for (const c of element.children.filter(e => e.name !== 'Articulations')) scalar(c);
    if (value(element, 'Type') !== 'pitched') refuse('articulation-profile', 'Only pitched instrument elements are exercised.', element.location);
    const arts = child(element, 'Articulations')!; shape(arts, ['Articulation'], [], ['Articulation']);
    if (arts.children.length !== 1) refuse('articulation-profile', 'One default instrument articulation is required.', arts.location);
    const art = arts.children[0];
    shape(art, ['Name', 'StaffLine', 'Noteheads', 'TechniquePlacement', 'TechniqueSymbol', 'InputMidiNumbers', 'OutputRSESound', 'OutputMidiNumber']);
    for (const c of art.children) scalar(c);
    marker(child(art, 'TechniqueSymbol')!); marker(child(art, 'InputMidiNumbers')!);
    if (value(art, 'OutputMidiNumber') !== '0' || child(art, 'StaffLine', false) && value(art, 'StaffLine') !== '0' ||
        child(art, 'Noteheads', false) && value(art, 'Noteheads') !== 'noteheadBlack noteheadHalf noteheadWhole' ||
        child(art, 'TechniquePlacement', false) && value(art, 'TechniquePlacement') !== 'outside' || value(art, 'OutputRSESound', false))
        refuse('articulation-profile', 'Nondefault instrument articulations need an exercised mapping.', art.location);
    return type;
}

/** GP6 encodes the same physical staff facts directly on Track. */
function prepareDirectTrack(track: Element, findings: Finding[]): Element {
    const keep = named(track, ['Name', 'ShortName', 'Color', 'SystemsDefautLayout', 'SystemsLayout', 'PalmMute', 'PlayingStyle', 'Instrument', 'PartSounding', 'Transpose', 'RSE', 'GeneralMidi', 'PlaybackState', 'Lyrics', 'Properties', 'Automations'], findings, ['Name', 'Instrument'], ['PartSounding', 'Transpose', 'GeneralMidi', 'Properties']);
    const midi = child(track, 'GeneralMidi')!;
    shape(midi, ['Program', 'Port', 'PrimaryChannel', 'SecondaryChannel', 'ForeOneChannelPerString'], ['table']); midi.children.forEach(scalar);
    const program = integer(value(midi, 'Program'), 0, 127, midi);
    if (midi.attrs.table !== 'Instrument' || program < 24 || program > 39) refuse('instrument-profile', 'Selected GP6 staff requires an explicit guitar/bass MIDI program 24–39.', midi.location);
    const playing = child(track, 'PlayingStyle', false), palm = child(track, 'PalmMute', false), state = child(track, 'PlaybackState', false);
    if (playing && !['Default', ...(program < 32 ? ['StringedPick'] : [])].includes(playing.text.trim()) || palm && palm.text.trim() !== '0' || state && state.text.trim() !== 'Default')
        refuse('track-technique', 'Active track-wide playing style, mute or nondefault playback state requires mapping.', track.location);
    if (playing?.text.trim() === 'StringedPick') findings.push({ disposition: 'omitted', code: 'source-playing-style', message: 'Explicit track playing style StringedPick is retained in source but not reapplied as individual note articulations or performing-hand assignments.', location: playing.location, fact: 'StringedPick' });
    for (const name of ['Lyrics', 'Automations']) {
        const field = child(track, name, false);
        if (name === 'Automations' && field?.children.length) refuse('track-automation', 'Selected GP6 track automation requires mapping.', field.location);
        if (name === 'Lyrics' && field) {
            shape(field, ['Line'], ['dispatched'], ['Line']);
            for (const line of field.children) { shape(line, ['Text', 'Offset']); line.children.forEach(scalar); if (value(line, 'Text')) refuse('lyrics', 'Nonempty lyrics need an export mapping.', line.location); }
        }
    }
    const properties = child(track, 'Properties')!; shape(properties, ['Property'], [], ['Property']);
    const canonical: Element[] = [], names = new Set<string>();
    for (const p of properties.children) {
        if (names.has(p.attrs.name)) refuse('structure', 'Duplicate track property.', p.location); names.add(p.attrs.name);
        const name = p.attrs.name;
        if (name === 'Tuning') { shape(p, ['Pitches'], ['name']); scalar(child(p, 'Pitches')!); canonical.push(p); }
        else if (name === 'CapoFret') { shape(p, ['Fret'], ['name']); scalar(child(p, 'Fret')!); canonical.push(p); }
        else if (['DiagramCollection', 'DiagramWorkingSet', 'ChordCollection', 'ChordWorkingSet'].includes(name)) {
            shape(p, ['Items'], ['name']); marker(child(p, 'Items')!);
            findings.push({ disposition: 'omitted', code: 'empty-diagrams', message: 'Empty source diagram collection retained.', location: p.location });
        } else refuse('staff-property', 'Unreviewed GP6 staff property.', p.location);
    }
    const sourceTranspose = child(track, 'Transpose', false), sounding = child(track, 'PartSounding', false);
    if (sourceTranspose && sounding || !sourceTranspose && !sounding) refuse('transpose', 'Exactly one explicit GP6 transposition representation is required.', track.location);
    let trans = sourceTranspose;
    if (sounding) {
        shape(sounding, ['NominalKey', 'TranspositionPitch']); sounding.children.forEach(scalar);
        const amount = integer(value(sounding, 'TranspositionPitch'), -24, 24, sounding);
        if (amount % 12 || value(sounding, 'NominalKey') !== 'C') refuse('transpose', 'Only octave GP6 PartSounding with nominal C is admitted.', sounding.location);
        trans = leaf(sounding, 'Transpose', ''); trans.children = [leaf(child(sounding, 'TranspositionPitch')!, 'Octave', String(amount / 12)), leaf(sounding, 'Chromatic', '0')];
        findings.push({ disposition: 'preserved', code: 'gp6-transpose-alias', message: 'Explicit PartSounding semitone octave is translated to the common octave representation without an additional physical sounding-pitch shift.', location: sounding.location, fact: { encodedSemitones: amount } });
    }
    return rebuilt(track, [...keep, trans!, rebuilt(properties, canonical), rebuilt(midi, [child(midi, 'Program')!])]);
}

/** Common discovery/admission header; producer identity is never inferred from these labels. */
export function validateGpifHeader(root: Element, family: 6 | 7 | 8, findings: Finding[]): void {
    const version = value(root, 'GPVersion', false), revision = child(root, 'GPRevision')!, encoding = child(root, 'Encoding', false);
    if (family === 6 ? version && !/^6(?:\.\d{1,3}){0,2}$/.test(version) : !new RegExp(`^${family}(?:\\.\\d{1,3}){0,2}$`).test(version))
        refuse('version-profile', 'Embedded GPIF version conflicts with the identified GP family.', root.location);
    if (!/^\d{1,5}$/.test(revision.text.trim()) || Number(revision.text.trim()) < 1 || Number(revision.text.trim()) > 13007) refuse('version-profile', 'GPIF revision exceeds the reviewed reader revision ceiling13007 or is invalid.', revision.location);
    for (const name of Object.keys(revision.attrs)) {
        if (!['required', 'recommended'].includes(name)) refuse('version-profile', 'Unknown revision attribute.', revision.location);
        integer(revision.attrs[name], 0, 13007, revision);
    }
    if (encoding && value(encoding, 'EncodingDescription') !== `GP${family}`)
        refuse('version-profile', 'Encoding description conflicts with embedded version; a label alone never establishes pitch semantics.', encoding.location);
    findings.push({ disposition: 'preserved', code: 'gpif-family', message: 'Version/revision/container identifiers are retained separately from strict selected-feature admission and physical pitch corroboration. This does not authenticate a producing application.', location: root.location, fact: { family, version: version || null, revision: revision.text.trim(), encoding: encoding ? value(encoding, 'EncodingDescription') : null } });
}
/** Bounded definition/reference closure, independent of selected instrument or musical certification. */
export function discoverGpifGraph(root: Element) {
    const tracks = defined(root, 'Tracks', 'Track'), bars = defined(root, 'Bars', 'Bar'), voices = defined(root, 'Voices', 'Voice');
    const beats = defined(root, 'Beats', 'Beat'), notes = defined(root, 'Notes', 'Note'), rhythms = defined(root, 'Rhythms', 'Rhythm');
    const masterTrack = child(root, 'MasterTrack')!, order = ids(masterTrack, 'Tracks');
    if (!order.length || order.length > limits.tracks || order.length !== tracks.size || new Set(order).size !== order.length || order.some(id => !tracks.has(id)))
        refuse('track-scope', 'Master track order must exactly identify all defined tracks within the bounded profile.', masterTrack.location);
    const masterBars = child(root, 'MasterBars')!; shape(masterBars, ['MasterBar'], [], ['MasterBar']);
    if (!masterBars.children.length || masterBars.children.length > limits.measures) refuse('measure-budget', 'Measure count outside profile.', masterBars.location);
    const all = { bars: new Set<string>(), voices: new Set<string>(), beats: new Set<string>(), notes: new Set<string>(), rhythms: new Set<string>() };
    for (const master of masterBars.children) {
        const barIds = ids(master, 'Bars');
        if (barIds.length !== order.length) refuse('bar-scope', 'Every master bar must identify each source track.', master.location);
        for (const id of barIds) { if (!bars.has(id)) refuse('reference', 'Unresolved master-bar reference.', master.location); all.bars.add(id); }
    }
    // Validate reference integrity throughout the source, even for deliberately excluded tracks.
    for (const b of bars.values()) for (const id of ids(b, 'Voices')) if (id !== '-1') {
        if (!voices.has(id)) refuse('reference', 'Unresolved voice reference.', b.location);
        if (all.bars.has(b.attrs.id)) all.voices.add(id);
    }
    for (const v of voices.values()) for (const id of ids(v, 'Beats')) {
        if (!beats.has(id)) refuse('reference', 'Unresolved beat reference.', v.location);
        if (all.voices.has(v.attrs.id)) all.beats.add(id);
    }
    for (const b of beats.values()) {
        const ref = child(b, 'Rhythm')!; shape(ref, [], ['ref']); if (ref.text.trim()) refuse('marker-content', 'Rhythm reference must be empty.', ref.location);
        if (!rhythms.has(ref.attrs.ref)) refuse('reference', 'Unresolved rhythm reference.', b.location);
        if (all.beats.has(b.attrs.id)) all.rhythms.add(ref.attrs.ref);
        for (const id of ids(b, 'Notes', false)) {
            if (!notes.has(id)) refuse('reference', 'Unresolved note reference.', b.location);
            if (all.beats.has(b.attrs.id)) all.notes.add(id);
        }
    }
    for (const [name, definitions] of [['bars', bars], ['voices', voices], ['beats', beats], ['notes', notes], ['rhythms', rhythms]] as const)
        if (all[name].size !== definitions.size) refuse('unreferenced', `Orphan ${name} definition outside all declared track scopes.`, child(root, name[0].toUpperCase() + name.slice(1))!.location);
    return { tracks, bars, voices, beats, notes, rhythms, order, all, masterBars };
}

/** Select musical scope without mutating the full immutable source document.
 * The derived reader view translates reviewed structural aliases only.
 */
export function prepareGp8(root: Element, requested: string[] | undefined, findings: Finding[], family: 6 | 7 | 8 = 8): Element {
    validateGpifHeader(root, family, findings);
    const { tracks, bars, voices, beats, notes, rhythms, order, all, masterBars } = discoverGpifGraph(root);
    const masterTrack = child(root, 'MasterTrack')!;
    const selected = requested ?? order;
    if (!selected.length || new Set(selected).size !== selected.length || selected.some(id => !tracks.has(id)))
        refuse('track-selection', 'Select existing unique source track IDs.', masterTrack.location);
    // Stable source order, independent of caller argument order.
    const selectedOrder = order.filter(id => selected.includes(id));
    const trackIndexes = selectedOrder.map(id => order.indexOf(id));
    const kept = { bars: new Set<string>(), voices: new Set<string>(), beats: new Set<string>(), notes: new Set<string>(), rhythms: new Set<string>() };
    const masters = masterBars.children.map(master => {
        const barIds = ids(master, 'Bars');
        if (barIds.length !== order.length) refuse('bar-scope', 'Each master bar must identify every source track.', master.location);
        for (const id of barIds) { if (!bars.has(id)) refuse('reference', 'Unresolved master-bar reference, including excluded tracks.', master.location); all.bars.add(id); }
        const chosen = trackIndexes.map(i => barIds[i]); chosen.forEach(id => kept.bars.add(id));
        const keep = named(master, ['Time', 'Key', 'Bars', 'Repeat', 'XProperties', 'Section'], findings, ['Time', 'Key', 'Repeat'], ['Bars', 'XProperties']);
        if (child(master, 'XProperties', false)) {
            const x = child(master, 'XProperties')!;
            if (value(master, 'Time') !== '4/4') refuse('beaming-profile', 'Explicit eighth grouping is exercised only in 4/4.', x.location);
            const allowed = new Map([['1124139010', '8'], ['1124139264', '2'], ['1124139265', '2'], ['1124139266', '2'], ['1124139267', '2']]);
            shape(x, ['XProperty'], [], ['XProperty']); const seen = new Set<string>();
            for (const p of x.children) {
                shape(p, ['Int'], ['id']); scalar(child(p, 'Int')!);
                if (!allowed.has(p.attrs.id) || seen.has(p.attrs.id) || value(p, 'Int') !== allowed.get(p.attrs.id))
                    refuse('beaming-profile', 'Master-bar beaming override is outside the exercised 4/4 eighth-group profile.', p.location);
                seen.add(p.attrs.id);
            }
            if (seen.size !== allowed.size) refuse('beaming-profile', 'Incomplete source beaming-group tuple.', x.location);
            findings.push({ disposition: 'omitted', code: 'source-beaming', message: 'Explicit source eighth-note grouping observed in source; capture is delivered only on success; MusicXML beam grouping export is not exercised.', location: x.location, fact: { unit: 'eighth', groups: [2, 2, 2, 2] } });
        }
        const key = child(master, 'Key')!;
        const keyFields = named(key, ['AccidentalCount', 'Mode', 'TransposeAs'], findings, ['AccidentalCount', 'Mode'], ['TransposeAs']);
        const keyAlias = child(key, 'TransposeAs', false);
        if (keyAlias) scalar(keyAlias);
        if (keyAlias && !['Sharps', 'Flats'].includes(keyAlias.text.trim())) refuse('key-transpose', 'Unreviewed key spelling preference.', keyAlias.location);
        if (keyAlias) findings.push({ disposition: 'omitted', code: 'key-preference', message: 'Source key spelling preference is retained but not reapplied. Explicit key count/mode and corroborated note spellings are exported; only octave display transpose is admitted.', location: keyAlias.location, fact: keyAlias.text.trim() });
        return rebuilt(master, [...keep.filter(e => e.name !== 'Key'), rebuilt(key, keyFields), leaf(child(master, 'Bars')!, 'Bars', chosen.join(' '))]);
    });
    const preparedBars = [...kept.bars].map(id => {
        const bar = bars.get(id)!, all = ids(bar, 'Voices');
        const firstAbsent = all.indexOf('-1');
        if (firstAbsent >= 0 && all.slice(firstAbsent).some(id => id !== '-1')) refuse('voice-profile', 'Only trailing absent voice slots are exercised.', bar.location);
        const active = all.filter(id => id !== '-1');
        if (!active.length) refuse('voice-profile', 'A selected bar requires an explicit active voice.', bar.location);
        active.forEach(id => kept.voices.add(id));
        if (active.length !== all.length) findings.push({ disposition: 'preserved', code: 'absent-voice-slots', message: 'Trailing -1 slots declare absent voices; no written notes or active voice identities are removed.', location: bar.location, fact: { absent: all.length - active.length } });
        const keep = named(bar, ['Clef', 'Voices'], findings, ['Clef'], ['Voices']);
        return rebuilt(bar, [...keep, leaf(child(bar, 'Voices')!, 'Voices', active.join(' '))]);
    });
    for (const id of kept.voices) ids(voices.get(id)!, 'Beats').forEach(id => kept.beats.add(id));
    for (const id of kept.beats) {
        const b = beats.get(id)!; ids(b, 'Notes', false).forEach(id => kept.notes.add(id)); kept.rhythms.add(child(b, 'Rhythm')!.attrs.ref);
    }
    const preparedTracks = selectedOrder.map(id => {
        const track = tracks.get(id)!;
        if (family === 6) return prepareDirectTrack(track, findings);
        const keep = named(track, ['Name', 'ShortName', 'Color', 'SystemsDefautLayout', 'SystemsLayout', 'AutoBrush', 'AutoAccentuation', 'PalmMute', 'PlayingStyle', 'UseOneChannelPerString', 'IconId', 'InstrumentSet', 'Transpose', 'RSE', 'ForcedSound', 'Sounds', 'MidiConnection', 'PlaybackState', 'AudioEngineState', 'Lyrics', 'Staves', 'Automations'], findings, ['Name', 'Transpose'], ['InstrumentSet', 'Sounds', 'Staves', 'AutoBrush', 'AutoAccentuation', 'PalmMute']);
        const type = checkDefaultArticulation(track);
        const playing = child(track, 'PlayingStyle', false), palm = child(track, 'PalmMute', false), state = child(track, 'PlaybackState', false);
        if (playing && !['Default', ...(type === 'electricGuitar' ? ['StringedPick'] : [])].includes(playing.text.trim()) || state && state.text.trim() !== 'Default') refuse('track-technique', 'Active track-wide style or playback state requires mapping.', track.location);
        for (const parameter of [palm, child(track, 'AutoAccentuation', false)].filter((p): p is Element => !!p)) {
            scalar(parameter);
            if (!/^(?:0(?:\.\d{1,6})?|1(?:\.0{1,6})?)$/.test(parameter.text.trim())) refuse('track-playback', 'Playback interpretation parameter must be a bounded decimal0–1.', parameter.location);
            findings.push({ disposition: 'omitted', code: 'track-playback-interpretation', message: parameter.name === 'PalmMute' ? 'Source palm-mute intensity parameter is retained, not applied. Selected notes with active palm-mute technique still refuse; this parameter alone does not mark notes or performing hands.' : 'Source automatic strong-beat accentuation is retained but playback emphasis is not reproduced or invented as written accents/dynamics. No complete playback equivalence is claimed.', location: { ...parameter.location, trackId: id }, fact: { parameter: parameter.name, value: parameter.text.trim() } });
        }
        const autoBrush = child(track, 'AutoBrush', false);
        if (autoBrush) {
            marker(autoBrush);
            findings.push({ disposition: 'omitted', code: 'source-auto-brush', message: 'Source automatic chord strum delay is retained but not reproduced. Conversion requires no overlapping selected notes across logical voices; written clocks stay exact.', location: { ...autoBrush.location, trackId: id }, fact: { enabled: true } });
        }
        if (playing?.text.trim() === 'StringedPick') findings.push({ disposition: 'omitted', code: 'source-playing-style', message: 'Explicit track playing style StringedPick is retained in source but not reapplied as individual note articulations or performing-hand assignments.', location: playing.location, fact: 'StringedPick' });
        findings.push({ disposition: 'omitted', code: 'instrument-sound-metadata', message: 'Instrument/sound names, labels, bank/timbre metadata and default articulation appearance are observed in source; capture is delivered only on success; exported meaning uses the validated pitched articulation and zero-bank MIDI program, without asserting recorded technique.', location: track.location });
        const automation = child(track, 'Automations', false);
        const lyrics = child(track, 'Lyrics', false);
        if (lyrics) {
            shape(lyrics, ['Line'], ['dispatched'], ['Line']);
            if (lyrics.attrs.dispatched !== undefined && lyrics.attrs.dispatched !== 'true') refuse('lyrics', 'Unreviewed lyric dispatch convention.', lyrics.location);
            for (const line of lyrics.children) {
                shape(line, ['Text', 'Offset']); line.children.forEach(scalar);
                if (value(line, 'Text').trim()) refuse('lyrics', 'Nonempty lyrics require an exercised export mapping.', line.location);
            }
        }
        const staveContainer = child(track, 'Staves')!; shape(staveContainer, ['Staff'], [], ['Staff']);
        const staves = staveContainer.children;
        if (staves.length !== 1) refuse('staff-profile', 'One explicitly fretted staff per selected bass track is required.', track.location);
        shape(staves[0], ['Properties']);
        const properties = child(staves[0], 'Properties')!, canonical: Element[] = [];
        shape(properties, ['Property', 'Name'], [], ['Property']); const propertyNames = new Set<string>();
        for (const property of properties.children) {
            if (property.name === 'Name') { scalar(property); findings.push({ disposition: 'omitted', code: 'staff-name', message: 'Source display name retained; ordinary source staff clef is exported.', location: property.location }); continue; }
            if (property.name !== 'Property') refuse('unknown-property', 'Unknown staff property container.', property.location);
            const name = property.attrs.name;
            if (propertyNames.has(name)) refuse('structure', 'Duplicate staff property identity.', property.location); propertyNames.add(name);
            const fields: Record<string, string[]> = { Tuning: ['Pitches', 'Flat', 'Instrument', 'Label', 'LabelVisible'], TuningFlat: ['Enable'], CapoFret: ['Fret'], PartialCapoFret: ['Fret'], PartialCapoStringFlags: ['Bitset', 'Flags'], FretCount: ['Number'], ChordCollection: ['Items'], ChordWorkingSet: ['Items'], DiagramCollection: ['Items'], DiagramWorkingSet: ['Items'] };
            shape(property, fields[name] ?? [], ['name']); property.children.forEach(scalar);
            if (name === 'Tuning') {
                if (property.children.some(e => !['Pitches', 'Flat', 'Instrument', 'Label', 'LabelVisible'].includes(e.name))) refuse('tuning-property', 'Unreviewed tuning field.', property.location);
                if (child(property, 'Flat', false)) {
                    marker(child(property, 'Flat')!);
                    findings.push({ disposition: 'omitted', code: 'tuning-flat-preference', message: 'Encoded tuning flat-spelling preference is retained separately from MIDI values. Generated MusicXML reference tuning spelling remains explicitly inferred.', location: child(property, 'Flat')!.location });
                }
                const visible = child(property, 'LabelVisible', false);
                if (visible && !['true', 'false'].includes(visible.text.trim())) refuse('tuning-property', 'Tuning label visibility must be explicit boolean.', visible.location);
                canonical.push(rebuilt(property, [child(property, 'Pitches')!]));
            } else if (name === 'TuningFlat') {
                marker(child(property, 'Enable')!);
                findings.push({ disposition: 'omitted', code: 'tuning-flat-preference', message: 'Encoded enabled tuning flat-spelling preference is retained separately from MIDI values. Generated MusicXML reference tuning spelling remains explicitly inferred.', location: property.location });
            } else if (name === 'CapoFret') canonical.push(property);
            else if (name === 'PartialCapoFret' && value(property, 'Fret') === '0' || name === 'PartialCapoStringFlags' && property.children.length === 1 && /^0+$/.test(property.children[0].text.trim())) {
                findings.push({ disposition: 'preserved', code: 'no-partial-capo', message: 'Explicitly inactive partial capo retained.', location: property.location });
            } else if (name === 'FretCount') integer(value(property, 'Number'), 1, 36, property);
            else if (['ChordCollection', 'ChordWorkingSet', 'DiagramCollection', 'DiagramWorkingSet'].includes(name) && !child(property, 'Items')!.children.length) {
                findings.push({ disposition: 'omitted', code: 'empty-diagrams', message: 'Empty diagram container retained; no musical chord data dropped.', location: property.location });
            } else refuse('staff-property', `Staff property ${name} is unsupported or active.`, property.location);
        }
        const soundContainer = child(track, 'Sounds')!; shape(soundContainer, ['Sound'], [], ['Sound']);
        const sounds = soundContainer.children;
        if (sounds.length !== 1) refuse('sound-profile', 'One explicit sound program is required; sound changes are unsupported.', track.location);
        shape(sounds[0], ['Name', 'Label', 'Path', 'Role', 'MIDI', 'RSE']); sounds[0].children.filter(e => !['MIDI', 'RSE'].includes(e.name)).forEach(scalar);
        if (child(sounds[0], 'RSE', false)) findings.push({ disposition: 'omitted', code: 'sound-rse', message: 'Source synth setup is captured but not recreated.', location: child(sounds[0], 'RSE')!.location });
        const midi = child(sounds[0], 'MIDI')!; shape(midi, ['MSB', 'LSB', 'Program']); midi.children.forEach(scalar);
        if (integer(value(midi, 'MSB'), 0, 127, midi) || integer(value(midi, 'LSB'), 0, 127, midi)) refuse('sound-bank', 'Nonzero sound-bank interpretation needs separate coverage.', midi.location);
        const program = child(midi, 'Program')!;
        const programNumber = integer(program.text.trim(), 0, 127, program);
        if (type === 'electricBass' ? programNumber < 32 || programNumber > 39 : programNumber < 24 || programNumber > 31)
            refuse('instrument-profile', 'Encoded instrument family and zero-bank MIDI program disagree.', program.location);
        if (automation) {
            shape(automation, ['Automation'], [], ['Automation']);
            if (automation.children.length > 1) refuse('track-automation', 'Only one initial matching sound declaration is admitted; sound changes require mapping.', automation.location);
            if (automation.children.length) {
                const initial = automation.children[0];
                shape(initial, ['Type', 'Linear', 'Bar', 'Position', 'Visible', 'Value']); initial.children.forEach(scalar);
                const expected = [value(sounds[0], 'Path'), value(sounds[0], 'Name'), value(sounds[0], 'Role')].join(';');
                if (value(initial, 'Type') !== 'Sound' || value(initial, 'Linear') !== 'false' || value(initial, 'Bar') !== '0' || value(initial, 'Position') !== '0' || !['true', 'false'].includes(value(initial, 'Visible')) || value(initial, 'Value') !== expected)
                    refuse('track-automation', 'Initial sound must exactly name the one serialized sound at bar zero/position zero.', initial.location);
                findings.push({ disposition: 'preserved', code: 'initial-sound-alias', message: 'Initial Sound declaration exactly names the sole serialized Path/Name/Role. It selects the already validated source program, not a later sound change; synth timbre remains omitted.', location: initial.location, fact: { path: value(sounds[0], 'Path'), name: value(sounds[0], 'Name'), role: value(sounds[0], 'Role'), program: programNumber } });
            }
        }
        return rebuilt(track, [...keep, leaf(child(track, 'InstrumentSet')!, 'Instrument', '', { ref: type }),
            rebuilt(properties, canonical), { ...midi, name: 'GeneralMidi', attrs: { table: 'Instrument' }, children: [program] }]);
    });
    for (const id of order.filter(id => !selected.includes(id))) findings.push({ disposition: 'excluded-by-scope', code: 'track-excluded', message: 'Track deliberately excluded by the requested source IDs; its facts remain in original source; capture is delivered only on success.', location: { ...tracks.get(id)!.location, trackId: id }, fact: { trackId: id } });
    const preparedBeats = [...kept.beats].map(id => {
        const b = beats.get(id)!;
        const keep = named(b, ['Rhythm', 'Notes', 'Dynamic', 'FreeText', 'Properties', 'TransposedPitchStemOrientation', 'ConcertPitchStemOrientation'], findings, ['Rhythm', 'Notes', 'Dynamic', 'FreeText']);
        const properties = child(b, 'Properties', false); if (properties) shape(properties, ['Property'], [], ['Property']); const names = new Set<string>();
        for (const p of properties?.children ?? []) {
            shape(p, ['Float'], ['name']); scalar(child(p, 'Float')!);
            if (names.has(p.attrs.name)) refuse('structure', 'Duplicate beat pickup-control property.', p.location); names.add(p.attrs.name);
            if (p.name !== 'Property' || !['PrimaryPickupVolume', 'PrimaryPickupTone'].includes(p.attrs.name)) refuse('beat-property', 'Unreviewed selected beat sound property.', p.location);
            const amount = value(p, 'Float');
            if (!/^\d{1,2}(?:\.\d{1,16})?$/.test(amount) || Number(amount) > 10) refuse('pickup-tone', 'Invalid bounded synth pickup control.', p.location);
            findings.push({ disposition: 'omitted', code: 'pickup-tone', message: 'Synth pickup tone/volume observed in source; capture is delivered only on success; instrument timbre recreation is not exercised.', location: p.location });
        }
        return rebuilt(b, keep);
    });
    const score = child(root, 'Score')!;
    const preparedScore = rebuilt(score, named(score, ['Title', 'SubTitle', 'Artist', 'Album', 'Words', 'Music', 'WordsAndMusic', 'Copyright', 'Tabber', 'Instructions', 'Notices', 'FirstPageHeader', 'FirstPageFooter', 'PageHeader', 'PageFooter', 'ScoreSystemsDefaultLayout', 'ScoreSystemsLayout', 'ScoreZoomPolicy', 'ScoreZoom', 'MultiVoice', 'PageSetup'], findings, ['Title']));
    const preparedMaster = rebuilt(masterTrack, named(masterTrack, ['Tracks', 'Automations', 'Anacrusis', 'RSE'], findings, ['Automations', 'Anacrusis'], ['Tracks']).concat(leaf(child(masterTrack, 'Tracks')!, 'Tracks', selectedOrder.join(' '))));
    const audio = child(root, 'AudioTracks', false); if (audio && (audio.children.length || audio.text.trim())) refuse('audio-track', 'Audio tracks require a separate timing/media contract.', audio.location);
    const keep = named(root, ['GPVersion', 'GPRevision', 'Encoding', 'Score', 'MasterTrack', 'Tracks', 'MasterBars', 'Bars', 'Voices', 'Beats', 'Notes', 'Rhythms', 'ScoreViews', 'AudioTracks'], findings, ['GPVersion', 'GPRevision', 'Encoding'], ['Score', 'MasterTrack', 'Tracks', 'MasterBars', 'Bars', 'Voices', 'Beats', 'Notes', 'Rhythms']);
    const group = (name: string, elements: Element[]) => rebuilt(child(root, name)!, elements);
    return freeze(rebuilt(root, [...keep, preparedScore, preparedMaster, group('Tracks', preparedTracks), group('MasterBars', masters),
        group('Bars', preparedBars), group('Voices', [...kept.voices].map(id => voices.get(id)!)), group('Beats', preparedBeats),
        group('Notes', [...kept.notes].map(id => notes.get(id)!)), group('Rhythms', [...kept.rhythms].map(id => rhythms.get(id)!))]));
}
export function serialize(e: Element): string {
    const escape = (s: string) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
    return `<${e.name}${Object.entries(e.attrs).map(([k, v]) => ` ${k}="${escape(v)}"`).join('')}>${escape(e.text)}${e.children.map(serialize).join('')}</${e.name}>`;
}

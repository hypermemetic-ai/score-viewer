import { SaxesParser } from 'saxes';
import { limits } from './limits.js';
import { freeze, refuse, type Location } from '../../core/report.js';

export interface Element {
    name: string; attrs: Record<string, string>; text: string; children: Element[]; location: Location;
}
export function parseXml(bytes: Uint8Array, member = 'Content/score.gpif', expectedRoot = 'GPIF'): { xml: string; root: Element } {
    const xml = new TextDecoder('utf-8', { fatal: true }).decode(bytes);
    const parser = new SaxesParser({ xmlns: false, defaultXMLVersion: '1.0', forceXMLVersion: true });
    let root: Element | undefined, nodes = 0, text = 0, pathChars = 0;
    const stack: Element[] = [], siblings: Map<string, number>[] = [new Map()];
    const fail = (message: string): never => refuse('xml', message, { member, line: parser.line, column: parser.column });
    parser.on('error', e => fail(e.message));
    parser.on('doctype', () => fail('DTD and entities are outside the profile.'));
    parser.on('processinginstruction', () => fail('Processing instructions are unsupported.'));
    parser.on('xmldecl', d => { if (d.version !== '1.0' || d.encoding && d.encoding.toLowerCase() !== 'utf-8') fail('Only XML 1.0 UTF-8 is admitted.'); });
    parser.on('opentagstart', tag => { if (tag.name.length > limits.xmlName) fail('XML name budget exceeded.'); });
    parser.on('attribute', attribute => {
        if (attribute.name.length > limits.xmlName || attribute.value.length > limits.xmlAttributeValue) fail('XML attribute name/value budget exceeded.');
    });
    parser.on('opentag', tag => {
        if (++nodes > limits.xmlNodes || stack.length >= limits.xmlDepth || Object.keys(tag.attributes).length > limits.xmlAttributes)
            fail('XML structure budget exceeded.');
        if (tag.name.includes(':') || Object.keys(tag.attributes).some(n => n.includes(':') || n === 'xmlns')) fail('GPIF namespaces are outside the profile.');
        const counts = siblings.at(-1)!, number = (counts.get(tag.name) ?? 0) + 1;
        counts.set(tag.name, number);
        const parent = stack.at(-1);
        const suffix = `/${tag.name}[${number}]`, pathLength = (parent?.location.path?.length ?? 0) + suffix.length;
        if (pathLength > limits.xmlPath || (pathChars += pathLength) > limits.xmlPathTotal) fail('XML path budget exceeded.');
        const path = (parent?.location.path ?? '') + suffix;
        const node: Element = { name: tag.name, attrs: { ...tag.attributes }, text: '', children: [],
            location: { member, path, line: parser.line, column: parser.column, ...(tag.attributes.id ? { id: String(tag.attributes.id) } : {}) } };
        if (parent) parent.children.push(node); else root = node;
        stack.push(node); siblings.push(new Map());
    });
    const append = (s: string) => {
        text += s.length;
        if (text > limits.xmlText) fail('XML text budget exceeded.');
        if (stack.length) {
            const node = stack.at(-1)!;
            if (node.text.length + s.length > limits.xmlNodeText) fail('XML element text budget exceeded.');
            node.text += s;
        }
    };
    parser.on('text', append); parser.on('cdata', append);
    parser.on('closetag', () => { stack.pop(); siblings.pop(); });
    // Chunking bounds callback latency; the container cap also bounds lexer buffers.
    for (let i = 0; i < xml.length; i += 4096) parser.write(xml.slice(i, i + 4096));
    parser.close();
    if (!root || root.name !== expectedRoot) fail(`Expected exactly one ${expectedRoot} document root.`);
    return { xml, root: freeze(root!) };
}
export const children = (e: Element, name: string): Element[] => e.children.filter(c => c.name === name);
export function child(e: Element, name: string, required = true): Element | undefined {
    const list = children(e, name);
    if (list.length > 1 || required && !list.length) refuse('structure', `Expected ${required ? 'one' : 'at most one'} ${name}.`, e.location);
    return list[0];
}
export const value = (e: Element, name: string, required = true): string => child(e, name, required)?.text.trim() ?? '';
export function integer(s: string, min: number, max: number, e: Element): number {
    if (!/^-?\d{1,6}$/.test(s) || Number(s) < min || Number(s) > max) refuse('number', `Expected an integer in ${min}..${max}.`, e.location);
    return Number(s);
}

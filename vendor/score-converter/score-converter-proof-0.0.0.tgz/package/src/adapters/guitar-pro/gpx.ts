import { Bytes, sha256 } from './bytes.js';
import { GpxFileSystem } from '../../../third_party/alphatab/src/importer/GpxFileSystem.js';
import { ByteBuffer } from '../../../third_party/alphatab/src/io/ByteBuffer.js';
import { freeze, refuse, type Location } from '../../core/report.js';
import { limits } from './limits.js';

export interface GpxMemberCapture {
    source: Location; name: string; declaredBytes: number; sectors: number[];
    bytes: number; sha256: string; dataBase64: string;
}
export interface GpxCapture { format: 'BCFS' | 'BCFZ'; decodedBytes: number; decodedSha256: string; literalBlocks: number; backreferenceBlocks: number; finalZeroPaddingBytes: number; rootDirectorySectors: number[]; members: GpxMemberCapture[] }

/** Validate every expansion step before using the borrowed filesystem on bounded BCFS. */
export function readGpx(input: Uint8Array, captureRaw = true): { members: Map<string, Bytes>; capture: GpxCapture } {
    const b = Bytes.view(input);
    const fail = (message: string, byteOffset = 0): never => refuse('gpx', message, { member: 'container', byteOffset });
    if (b.length > limits.inputBytes || b.length < 4) fail('GPX input size outside the profile.');
    const format = b.subarray(0, 4).ascii();
    let decoded = b, literalBlocks = 0, backreferenceBlocks = 0, finalZeroPaddingBytes = 0;
    if (format === 'BCFZ') {
        if (b.length < 8) fail('Truncated GPX length.');
        const size = b.readUInt32LE(4);
        if (size < 8196 || size > limits.decodedBytes || size > b.length * limits.compressionRatio)
            fail('GPX declared expansion exceeds the decoded-size/work budget.', 4);
        decoded = new Bytes(size);
        let bit = 64, written = 0, blocks = 0;
        const readBit = (): number => {
            if (bit >= b.length * 8) fail('Truncated GPX compressed block.', bit >> 3);
            return (b[bit >> 3] >> (7 - (bit++ % 8))) & 1;
        };
        const readBits = (count: number, reversed = false): number => {
            let value = 0;
            for (let i = 0; i < count; i++) { const next = readBit(); value = reversed ? value | next << i : value * 2 + next; }
            return value;
        };
        while (written < size) {
            if (++blocks > limits.decodedBytes) fail('GPX compressed-block work exceeds the budget.', bit >> 3);
            if (readBit()) {
                const width = readBits(4), offset = readBits(width, true), length = readBits(width, true);
                const count = Math.min(offset, length);
                if (!width || !offset || !length || offset > written || written + count > size)
                    fail('Invalid, zero-progress or overlong GPX backreference.', bit >> 3);
                decoded.copy(decoded, written, written - offset, written - offset + count);
                written += count; backreferenceBlocks++;
            } else {
                const count = readBits(2, true);
                if (!count) fail('Invalid zero-progress GPX literal block.', bit >> 3);
                for (let i = 0; i < count; i++) {
                    const value = readBits(8);
                    if (written < size) decoded[written++] = value;
                    else {
                        if (value || ++finalZeroPaddingBytes > 2) fail('Nonzero or excessive final GPX literal padding.', bit >> 3);
                    }
                }
                literalBlocks++;
            }
        }
        if (Math.ceil(bit / 8) !== b.length) fail('Trailing GPX compressed bytes.', bit >> 3);
        while (bit < b.length * 8) if (readBit()) fail('Nonzero GPX padding bits.', bit >> 3);
    } else if (format !== 'BCFS') fail('Expected BCFS or BCFZ GPX magic.');
    if (decoded.subarray(0, 4).ascii() !== 'BCFS') fail('Compressed GPX must decode to BCFS.');
    const body = decoded.subarray(4), sectorSize = 4096;
    if (decoded.length > limits.decodedBytes || body.length < 8192 || body.length % sectorSize)
        fail('Truncated or oversized GPX sector storage.');
    const sectorCount = body.length / sectorSize, owned = new Set<number>([0]);
    const names = new Set<string>(), members = new Map<string, Bytes>(), captures: GpxMemberCapture[] = [];
    let sector = 1, total = 0;
    let rootDirectorySectors: number[] | undefined;
    const fileDirectories: number[] = [];
    while (sector < sectorCount) {
        if (owned.has(sector)) { sector++; continue; }
        owned.add(sector);
        const at = sector * sectorSize, type = body.readUInt32LE(at);
        if (type === 1) {
            if (rootDirectorySectors || sector !== 1 || body[at + 4] !== 47 || body[at + 5] !== 0) fail('Only one flat GPX root directory is admitted.', at + 4);
            const size = body.readUInt32LE(at + 140), pointer = body.readUInt32LE(at + 148);
            if (!size || size % 4 || size > limits.entries * 4 || pointer <= sector || pointer >= sectorCount || body.readUInt32LE(at + 152) !== 0)
                fail('Invalid GPX root child table.', at + 144);
            owned.add(pointer);
            rootDirectorySectors = [];
            for (let i = 0; i < size / 4; i++) {
                const child = body.readUInt32LE(pointer * sectorSize + i * 4);
                if (child <= sector || child >= sectorCount || owned.has(child) || rootDirectorySectors.includes(child)) fail('Invalid or duplicate GPX root child pointer.', 4 + pointer * sectorSize + i * 4);
                rootDirectorySectors.push(child);
            }
            sector++; continue;
        }
        if (type !== 2) {
            const unused = body.subarray(at, at + sectorSize);
            if (!unused.every(byte => byte === 0) && !unused.every(byte => byte === 255)) fail('Unreviewed GPX directory/sector type.', at + 4);
            sector++; continue;
        }
        if (members.size >= limits.entries) fail('GPX member count exceeds the profile.', at + 4);
        const field = body.subarray(at + 4, at + 131), end = field.indexOf(0);
        if (end < 1) fail('GPX member name lacks a bounded terminator.', at + 8);
        const name = field.subarray(0, end).ascii();
        if (field.subarray(0, end).some(byte => byte > 127) || !/^[A-Za-z0-9_.-]{1,120}$/.test(name) || name === '.' || name === '..' || names.has(name.toLowerCase()))
            fail('Unsafe, duplicate or ambiguous GPX member name.', at + 8);
        fileDirectories.push(sector);
        names.add(name.toLowerCase());
        const bytes = body.readUInt32LE(at + 140);
        total += bytes;
        if (bytes > limits.memberBytes || total > limits.decodedBytes) fail('GPX member/total decoded bytes exceed the profile.', at + 144);
        const count = Math.ceil(bytes / sectorSize);
        if (148 + (count + 1) * 4 > sectorSize) fail('GPX pointer table exceeds its directory sector.', at + 152);
        const pointers: number[] = [];
        let last = sector;
        for (let i = 0; i < count; i++) {
            const pointer = body.readUInt32LE(at + 148 + 4 * i);
            if (pointer <= last || pointer >= sectorCount || owned.has(pointer)) fail('Cyclic, overlapping or out-of-range GPX pointer.', at + 152 + 4 * i);
            // Holes must be unused; the upstream filesystem also resumes after the last data sector.
            for (let gap = last + 1; gap < pointer; gap++) {
                if (owned.has(gap)) continue;
                const unused = body.subarray(gap * sectorSize, (gap + 1) * sectorSize);
                if (!unused.every(byte => byte === 0) && !unused.every(byte => byte === 255)) fail('Unaccounted GPX sectors between data pointers.', 4 + gap * sectorSize);
                owned.add(gap);
            }
            owned.add(pointer); pointers.push(pointer); last = pointer;
        }
        if (body.readUInt32LE(at + 148 + count * 4) !== 0) fail('GPX pointer count differs from declared file length.', at + 152 + count * 4);
        const data = new Bytes(bytes);
        for (let i = 0; i < pointers.length; i++) body.copy(data, i * sectorSize, pointers[i] * sectorSize, pointers[i] * sectorSize + Math.min(sectorSize, bytes - i * sectorSize));
        members.set(name, data);
        if (captureRaw) captures.push({ source: { member: 'decoded:BCFS', byteOffset: at + 4, byteLength: sectorSize, path: name }, name, declaredBytes: bytes,
            sectors: pointers, bytes, sha256: sha256(data), dataBase64: data.base64() });
        sector = last + 1;
    }
    if (rootDirectorySectors && (rootDirectorySectors.length !== fileDirectories.length || rootDirectorySectors.some(pointer => !fileDirectories.includes(pointer)))) fail('GPX root table does not account for every payload directory.');
    if (!members.has('score.gpif') || [...members.keys()].some(name => /score\.gpif$/i.test(name) && name !== 'score.gpif'))
        fail('GPX requires one unambiguous score.gpif member.');
    const reader = new GpxFileSystem();
    reader.load(ByteBuffer.fromBuffer(decoded));
    if (reader.files.length !== members.size || reader.files.some(file => !members.has(file.fileName) || !Bytes.view(file.data ?? new Uint8Array()).equals(members.get(file.fileName)!)))
        fail('Borrowed GPX filesystem differs from independently validated members.');
    const capture = freeze({ format: format as 'BCFS' | 'BCFZ', decodedBytes: decoded.length,
        decodedSha256: captureRaw ? sha256(decoded) : '', literalBlocks, backreferenceBlocks, finalZeroPaddingBytes, rootDirectorySectors: rootDirectorySectors ?? [], members: captures });
    return { members, capture };
}

import { refuse, type Finding } from '../../core/report.js';
import { child, value, type Element } from './xml.js';

const vocabulary: Record<string, string> = {
    GPIF: 'GPVersion GPRevision Encoding Score MasterTrack Tracks MasterBars Bars Voices Beats Notes Rhythms',
    Encoding: 'EncodingDescription',
    Score: 'Title SubTitle Artist Album Words Music WordsAndMusic Copyright Tabber Instructions Notices ScoreSystemsDefaultLayout ScoreSystemsLayout',
    MasterTrack: 'Tracks Automations Anacrusis', Tracks: 'Track',
    Track: 'Name ShortName Instrument GeneralMidi Properties Transpose Color SystemsDefautLayout SystemsLayout',
    GeneralMidi: 'Program Port PrimaryChannel SecondaryChannel', Transpose: 'Chromatic Octave',
    Automations: 'Automation', Automation: 'Type Linear Bar Position Value Visible Text',
    MasterBars: 'MasterBar', MasterBar: 'Time Bars Key Repeat', Key: 'AccidentalCount Mode',
    Bars: 'Bar', Bar: 'Voices Clef', Voices: 'Voice', Voice: 'Beats', Beats: 'Beat',
    Beat: 'Rhythm Notes FreeText', Notes: 'Note', Note: 'Properties Tie',
    Rhythms: 'Rhythm', Rhythm: 'NoteValue AugmentationDot PrimaryTuplet',
    Properties: 'Property', Pitch: 'Step Accidental Octave'
};
const attrs: Record<string, string> = {
    GPRevision: 'required recommended', Track: 'id', GeneralMidi: 'table', Instrument: 'ref',
    Bar: 'id', Voice: 'id', Beat: 'id', Note: 'id', Rhythm: 'id ref',
    Property: 'name', Tie: 'origin destination', Repeat: 'start end count',
    AugmentationDot: 'count', PrimaryTuplet: 'num den'
};
const leaf = new Set(('GPVersion GPRevision EncodingDescription Title SubTitle Artist Album Words Music WordsAndMusic Copyright Tabber Instructions Notices ScoreSystemsDefaultLayout ScoreSystemsLayout Anacrusis Name ShortName Color SystemsDefautLayout SystemsLayout Instrument Program Port PrimaryChannel SecondaryChannel Chromatic Octave Type Linear Position Value Visible Text Time AccidentalCount Mode Clef FreeText NoteValue AugmentationDot PrimaryTuplet Tie Repeat Pitches Fret String Step Accidental').split(' '));
const properties: Record<string, Record<string, string>> = {
    Track: { Tuning: 'Pitches', CapoFret: 'Fret' },
    Note: { String: 'String', Fret: 'Fret', ConcertPitch: 'Pitch', TransposedPitch: 'Pitch' }
};
const techniqueNames = new Set(('Muted PalmMuted Tapped LeftHandTapped HarmonicType HarmonicFret Bended BendOriginValue BendOriginOffset BendMiddleValue BendMiddleOffset1 BendMiddleOffset2 BendDestinationValue BendDestinationOffset HopoOrigin HopoDestination Slide LetRing Trill Vibrato AntiAccent Accent LeftFingering RightFingering GraceNotes Legato Whammy Ottavia Dynamic Tremolo Hairpin Arpeggio Fadding').split(' '));
const metadata = new Set(('SubTitle Artist Album Words Music WordsAndMusic Copyright Tabber Instructions Notices ScoreSystemsDefaultLayout ScoreSystemsLayout Color SystemsDefautLayout SystemsLayout ShortName Port PrimaryChannel SecondaryChannel').split(' '));

/** Reviewed fixture vocabulary; an upstream ignored tag never earns admission. */
export type GpifMode = 'constructed' | 'gp8-scientific' | 'gpif-physical';
export function inventory(root: Element, findings: Finding[], mode: GpifMode = 'constructed'): void {
    const visit = (node: Element, parent?: Element, grandparent?: Element): void => {
        if (node.children.length && node.text.trim()) refuse('mixed-content', 'Mixed GPIF element content is unsupported.', node.location);
        let allowed = vocabulary[node.name]?.split(' ') ?? [];
        if (mode !== 'constructed' && node.name === 'Note') allowed = [...allowed, 'InstrumentArticulation'];
        if (mode !== 'constructed' && node.name === 'Beat') allowed = [...allowed, 'Dynamic'];
        if (node.name === 'Tracks' && parent?.name === 'MasterTrack' || node.name === 'Bars' && parent?.name === 'MasterBar' ||
            node.name === 'Voices' && parent?.name === 'Bar' || node.name === 'Beats' && parent?.name === 'Voice' || node.name === 'Notes' && parent?.name === 'Beat') allowed = [];
        if (node.name === 'Property') {
            const name = node.attrs.name;
            const extra: Record<string, string> = { Midi: 'Number', Muted: 'Enable', HopoOrigin: 'Enable', HopoDestination: 'Enable' };
            const entry = properties[grandparent?.name ?? '']?.[name] ?? (mode !== 'constructed' && grandparent?.name === 'Note' ? extra[name] : undefined);
            if (!entry) refuse(techniqueNames.has(name) ? 'technique' : 'unknown-property', `Property ${name} is outside the exercised musical profile.`, node.location);
            allowed = entry!.split(' ');
        }
        if (['Instrument', 'Anacrusis', 'Tie', 'Repeat', 'AugmentationDot', 'PrimaryTuplet', 'Enable'].includes(node.name) && node.text.trim())
            refuse('marker-content', 'Unexpected scalar content in an encoded marker.', node.location);
        if (mode === 'constructed' && node.name === 'GPRevision' && (node.attrs.required !== '0' || node.attrs.recommended !== '0'))
            refuse('version-profile', 'Only revision0 with required0/recommended0 is exercised.', node.location);
        const permitted = (attrs[node.name] ?? '').split(' ');
        for (const name of Object.keys(node.attrs)) if (!permitted.includes(name)) refuse('unknown-attribute', `Unreviewed attribute ${name}.`, node.location);
        for (const c of node.children) {
            if (!allowed.includes(c.name)) refuse(techniqueNames.has(c.name) ? 'technique' : 'unknown-element', `Element ${c.name} is outside the exercised musical profile.`, c.location);
            visit(c, node, parent);
        }
        if (!vocabulary[node.name] && !leaf.has(node.name) && node.name !== 'Property' && !(mode !== 'constructed' && ['InstrumentArticulation', 'Dynamic', 'Number', 'Enable'].includes(node.name))) refuse('unknown-element', `Unreviewed element ${node.name}.`, node.location);
        if (metadata.has(node.name)) findings.push({ disposition: 'omitted', code: 'metadata', message: 'Retained in original input (capture delivered only on success); not rendered in this MusicXML proof.', location: node.location, fact: node.text });
    };
    visit(root);
    if (mode === 'constructed' && (value(root, 'GPVersion') !== '7.0' || value(root, 'GPRevision') !== '0'))
        refuse('version-profile', 'Only the independently constructed GPIF 7.0/revision 0 fixture profile has been exercised; other producer/header combinations need admission.', root.location);
    const encoding = child(root, 'Encoding', false);
    if (mode === 'constructed' && (!encoding || !value(encoding, 'EncodingDescription'))) refuse('producer', 'Encoding provenance is required for this proof.', root.location);
    findings.push({ disposition: 'preserved', code: 'headers', message: mode === 'constructed' ? 'Container and embedded headers are separate identifiers; fixture profile is not authentic producer acceptance.' : 'GP8 header tuple retained separately from exercised musical feature and scientific-pitch corroboration profile; it does not identify the producing application.', location: root.location,
        fact: { gpVersion: value(root, 'GPVersion', false), revision: value(root, 'GPRevision'), encoding: encoding ? value(encoding, 'EncodingDescription') : undefined, revisionAttributes: child(root, 'GPRevision')!.attrs } });
}

import { Bytes, sha256 } from './bytes.js';
import { guitarProEncoding } from './encoding.js';
import { readBinaryMetadata } from './binary.js';
import { readGpx } from './gpx.js';
import { captureContainer } from './container-facts.js';
import { discoverGpifGraph, validateGpifHeader } from './gp8.js';
import { child, children, value, parseXml, type Element } from './xml.js';
import { limits } from './limits.js';
import { freeze, Refusal, refuse, type Finding, type Location } from '../../core/report.js';
import type { ConversionResult } from './convert-core.js';
import { admitDescriptors } from './zip-core.js';
import { observedFamily } from './admission.js';
import { BoundedFindings, jsonBytes } from './work-budgets.js';

interface TrackDiscovery {
    sourceId: string; sourceLocation: Location;
    sourceName?: { value: string; sourceLocation: Location };
    instrument: { observations: { kind: 'family' | 'ref' | 'midi-program'; value: string | number; sourceLocation: Location; provenance: 'encoded' | 'derived-from-encoded-channel' }[] };
    tuning?: { pitches: number[]; order: 'low-to-high'; stringCount: number; sourceLocation: Location; encodedOrder: 'low-to-high' | 'high-to-low' };
    metadataEligibility: { status: 'eligible' | 'ineligible' | 'unknown'; profile: string; findings: Finding[] };
}
type Immutable<T> = T extends readonly (infer Item)[] ? readonly Immutable<Item>[] : T extends object ? { readonly [Key in keyof T]: Immutable<T[Key]> } : T;
export type SourceTrackInfo = Immutable<TrackDiscovery>;
type InspectionReport = Immutable<Omit<ConversionResult['report'], 'convertedParts'>>;
export type InspectionResult = { readonly ok: true; readonly report: InspectionReport; readonly tracks: readonly SourceTrackInfo[] } | { readonly ok: false; readonly report: InspectionReport; readonly tracks?: never };
const finding = (code: string, message: string, location: Location): Finding => ({ disposition: 'blocking', code, message, location });
function eligibility(program: number | undefined, tuning: TrackDiscovery['tuning'], source: Location, profile: string, ref?: string, binary = false): TrackDiscovery['metadataEligibility'] {
    const findings: Finding[] = [];
    let status: 'eligible' | 'ineligible' | 'unknown' = 'eligible';
    if (program === undefined || !Number.isInteger(program) || program < 0 || program > 127) {
        status = 'unknown'; findings.push(finding('instrument-unknown', 'No unambiguous encoded MIDI program establishes metadata eligibility.', source));
    } else if (program < 24 || program > 39) {
        status = 'ineligible'; findings.push(finding('instrument-profile', 'Observed instrument is outside the currently admitted guitar/bass program24–39 profile.', source));
    } else if (!binary) {
        const family = ref && observedFamily(ref);
        if (!family) { status = 'unknown'; findings.push(finding('instrument-unknown', 'No reviewed encoded family/reference establishes metadata eligibility; labels and tuning cannot authorize one.', source)); }
        else if (family === 'guitar' ? program > 31 : program < 32) { status = 'ineligible'; findings.push(finding('instrument-profile', 'Encoded family/reference and MIDI family disagree.', source)); }
    }
    if (!tuning || tuning.stringCount < 4 || tuning.stringCount > (profile.startsWith('gp3-5') ? 7 : 8) || tuning.pitches.some((p, i) => p < 12 || p > 108 || i > 0 && p <= tuning.pitches[i - 1])) {
        if (status === 'eligible') status = 'ineligible';
        findings.push(finding('tuning-profile', 'A complete strictly ascending4–8string tuning (binary4–7) is required for metadata eligibility.', tuning?.sourceLocation ?? source));
    }
    return { status, profile: program !== undefined && program >= 24 && program <= 31 ? profile.replace('-bass/', '-guitar/') : profile, findings };
}
function scalar(e: Element): void {
    if (e.children.length || Object.keys(e.attrs).length) refuse('structure', `Expected unambiguous scalar ${e.name}.`, e.location);
}
function gpifTrack(track: Element, profile: string): TrackDiscovery {
    const info: TrackDiscovery = { sourceId: track.attrs.id, sourceLocation: { ...track.location, trackId: track.attrs.id }, instrument: { observations: [] }, metadataEligibility: { status: 'unknown', profile, findings: [] } };
    const name = child(track, 'Name', false); if (name) { scalar(name); if (name.text.length > 4096) refuse('metadata-size', 'Source track name exceeds compact inventory bounds.', name.location); info.sourceName = { value: name.text, sourceLocation: name.location }; }
    const ref = child(track, 'Instrument', false);
    if (ref) { if (ref.children.length || ref.text.trim() || Object.keys(ref.attrs).some(key => key !== 'ref')) refuse('structure', 'Ambiguous instrument reference.', ref.location); info.instrument.observations.push({ kind: 'ref', value: ref.attrs.ref ?? '', sourceLocation: ref.location, provenance: 'encoded' }); }
    const set = child(track, 'InstrumentSet', false), type = set && child(set, 'Type', false);
    if (type) { scalar(type); info.instrument.observations.push({ kind: 'family', value: type.text.trim(), sourceLocation: type.location, provenance: 'encoded' }); }
    const directMidi = child(track, 'GeneralMidi', false), sounds = child(track, 'Sounds', false);
    const soundList = sounds ? children(sounds, 'Sound') : [];
    if (directMidi && soundList.length) refuse('instrument-ambiguity', 'Multiple instrument-program encodings prevent useful inventory.', track.location);
    const programNodes = directMidi ? [child(directMidi, 'Program')!] : soundList.map(sound => child(child(sound, 'MIDI')!, 'Program')!);
    const programs = programNodes.map(node => {
        scalar(node); if (!/^\d{1,3}$/.test(node.text.trim()) || Number(node.text.trim()) > 127) refuse('number', 'Malformed MIDI program.', node.location);
        const program = Number(node.text.trim()); info.instrument.observations.push({ kind: 'midi-program', value: program, sourceLocation: node.location, provenance: 'encoded' }); return program;
    });
    const staves = child(track, 'Staves', false), properties = child(track, 'Properties', false);
    if (staves && properties) refuse('staff-ambiguity', 'Competing direct and grouped staff encodings prevent useful inventory.', track.location);
    const propertyGroups = properties ? [properties] : staves ? children(staves, 'Staff').map(staff => child(staff, 'Properties', false)).filter((e): e is Element => !!e) : [];
    const tuningNodes: Element[] = [];
    for (const group of propertyGroups) {
        const names = new Set<string>();
        for (const property of children(group, 'Property')) {
            if (!property.attrs.name || names.has(property.attrs.name)) refuse('structure', 'Ambiguous staff property identity.', property.location); names.add(property.attrs.name);
            if (property.attrs.name === 'Tuning') tuningNodes.push(child(property, 'Pitches')!);
        }
    }
    if (tuningNodes.length > 1) refuse('tuning-ambiguity', 'Multiple source tunings need a separately shaped inventory contract.', track.location);
    if (tuningNodes.length) {
        const node = tuningNodes[0]; scalar(node);
        const fields = node.text.trim().split(/\s+/);
        if (!fields.length || fields.length > 8 || fields.some(p => !/^\d{1,3}$/.test(p) || Number(p) > 127)) refuse('tuning', 'Malformed or oversized source tuning.', node.location);
        info.tuning = { pitches: fields.map(Number), order: 'low-to-high', stringCount: fields.length, sourceLocation: node.location, encodedOrder: 'low-to-high' };
    }
    const program = new Set(programs).size === 1 ? programs[0] : undefined;
    info.metadataEligibility = eligibility(program, info.tuning, info.sourceLocation, profile, type?.text.trim() ?? ref?.attrs.ref);
    if (soundList.length > 1) { info.metadataEligibility.status = 'ineligible'; info.metadataEligibility.findings.push(finding('sound-profile', 'Multiple source sounds require musical sound-change admission.', sounds!.location)); }
    return info;
}

/** Structural discovery is distinct from converting a selected musical graph. No raw graph is returned. */
export function inspectPortable(bytes: Uint8Array, readContainer: () => Map<string, Bytes>): InspectionResult {
    const report: ConversionResult['report'] = { schema: 'score-converter-report/0', inputSha256: sha256(bytes), adapter: 'alphatab-1.8.4-022a45c8+source-hook/1', profile: 'gp-family-inventory/0', requestedScope: 'all-tracks', findings: new BoundedFindings() };
    try {
        if (bytes.length > limits.inputBytes) refuse('input-size', 'Input exceeds8MiB.');
        const encoding = guitarProEncoding(bytes);
        let tracks: TrackDiscovery[];
        if (encoding === 'binary') {
            const source = readBinaryMetadata(bytes, report.findings); report.profile = 'gp3-5-binary-inventory/0';
            tracks = source.tracks.map(t => {
                const tuning: TrackDiscovery['tuning'] = { pitches: t.tuning.slice().reverse(), order: 'low-to-high', encodedOrder: 'high-to-low', stringCount: t.tuning.length, sourceLocation: t.tuningLocation };
                const info: TrackDiscovery = { sourceId: t.sourceId, sourceLocation: t.sourceLocation, sourceName: { value: t.name, sourceLocation: t.nameLocation }, instrument: { observations: [{ kind: 'midi-program', value: t.program, sourceLocation: t.programLocation, provenance: 'derived-from-encoded-channel' }] }, tuning, metadataEligibility: eligibility(t.program, tuning, t.sourceLocation, 'gp3-5-binary-bass/0', undefined, true) };
                if (t.facts['track-flags'] & 0x77 || t.facts.capo || t.facts['automatic-midi'] & ~1 || t.facts['automatic-accent'] || t.facts.humanize || t.facts['sound-bank']) {
                    info.metadataEligibility.status = 'ineligible'; info.metadataEligibility.findings.push(finding('track-profile', 'Encoded percussion/doubled/mute/capo/automatic playback or sound-bank fields exceed selected metadata scope.', t.sourceLocation));
                }
                return info;
            });
            report.findings.push({ disposition: 'preserved', code: 'binary-header', message: 'Encoded binary version/header is observed independently of metadata eligibility.', location: { member: 'input', byteOffset: 0, byteLength: 31 }, fact: { header: source.header, version: source.version } });
        } else {
            const gpx = encoding === 'gpx';
            const members = gpx ? new Map([...readGpx(bytes, false).members].map(([name, data]) => ['Content/' + name, data])) : readContainer();
            const root = parseXml(members.get('Content/score.gpif')!, gpx ? 'score.gpif' : 'Content/score.gpif').root;
            if (!gpx) admitDescriptors(members, root, report.findings);
            const version = value(root, 'GPVersion', false), constructed = version === '7.0' && value(root, 'GPRevision') === '0';
            const family = gpx && !constructed ? 6 : /^8(?:\.|$)/.test(version) ? 8 : 7;
            if (!constructed) validateGpifHeader(root, family, report.findings);
            const graph = discoverGpifGraph(root);
            captureContainer(members, !constructed || gpx, [], false);
            report.profile = constructed ? 'constructed-gpif-inventory/0' : `gp${family}-inventory/0`;
            tracks = graph.order.map(id => gpifTrack(graph.tracks.get(id)!, constructed ? 'constructed-gp7-fretted/0' : `gp${family}-physical-bass/0`));
        }
        report.findings.push({ disposition: 'preserved', code: 'inspection-scope', message: 'Bounded container/header/definition/reference discovery succeeded. Track labels and metadata eligibility do not certify musical constructs; conversion revalidates selected source IDs. No output-part IDs or raw capture are returned.', location: { member: 'input' } });
        const result = { ok: true as const, report, tracks };
        jsonBytes(result, limits.reportBytes);
        return freeze(result);
    } catch (error) {
        const r = error instanceof Refusal ? error : new Refusal('invalid-input', 'Input failed bounded source discovery; no useful inventory is returned.');
        if (r.code === 'report-budget') report.findings = [];
        report.findings.push(finding(r.code, r.message, r.location));
        return freeze({ ok: false, report });
    }
}

import { Gp3To5Importer } from '../../../third_party/alphatab/src/importer/Gp3To5Importer.js';
import { ByteBuffer } from '../../../third_party/alphatab/src/io/ByteBuffer.js';
import { Bytes } from './bytes.js';
import { ThrowingReadable } from '../../../third_party/alphatab/src/io/IReadable.js';
import { Settings } from '../../../third_party/alphatab/src/ReaderSettings.js';
import { Logger } from '../../../third_party/alphatab/src/Logger.js';
import { LogLevel } from '../../../third_party/alphatab/src/LogLevel.js';
import type { Score } from '../../../third_party/alphatab/src/model/Score.js';
import type { Track } from '../../../third_party/alphatab/src/model/Track.js';
import type { Bar } from '../../../third_party/alphatab/src/model/Bar.js';
import type { Voice } from '../../../third_party/alphatab/src/model/Voice.js';
import type { Beat } from '../../../third_party/alphatab/src/model/Beat.js';
import type { Note } from '../../../third_party/alphatab/src/model/Note.js';
import { add, equal, mul, q } from '../../core/rational.js';
import { freeze, refuse, Refusal, type Finding, type Location } from '../../core/report.js';
import type { Event, Measure, NeutralScore, NoteFact, Part, Pitch, Tempo } from '../../core/model.js';
import type { OccurrenceCapture } from './recover.js';
import { limits } from './limits.js';
import { jsonBytes } from './work-budgets.js';

export interface BinaryRecord { kind: string; source: Location; dataBase64: string; facts: Record<string, number> }
export interface BinaryCapture { header: string; version: number; sourceEncoding: string; records: BinaryRecord[] }
interface Frame { source: Location; facts: Record<string, number> }
const headers: Record<string, number> = {
    'FICHIER GUITAR PRO v3.00': 300,
    'FICHIER GUITAR PRO v4.00': 400,
    'FICHIER GUITAR PRO v4.06': 406,
    'FICHIER GUITAR PRO L4.06': 406,
    'FICHIER GUITAR PRO v5.00': 500,
    'FICHIER GUITAR PRO v5.10': 510
};
const rhythmTypes: Record<number, string> = { 1: 'whole', 2: 'half', 4: 'quarter', 8: 'eighth', 16: '16th', 32: '32nd', 64: '64th' };
const dynamics = ['', 'PPP', 'PP', 'P', 'MP', 'MF', 'F', 'FF', 'FFF'];
function inferredPitch(midi: number): Pitch {
    if (midi < 12 || midi > 127) refuse('pitch-range', 'Binary pitch outside the written/reference MIDI profile.');
    const [step, alter] = ([['C', 0], ['C', 1], ['D', 0], ['D', 1], ['E', 0], ['F', 0],
        ['F', 1], ['G', 0], ['G', 1], ['A', 0], ['A', 1], ['B', 0]] as const)[midi % 12];
    return { step, alter, octave: Math.floor(midi / 12) - 1, midi, origin: 'inferred' };
}

/** Throw a located adapter refusal before the borrowed reader can short-read or skip. */
class BoundedInput extends ThrowingReadable {
    constructor(bytes: Bytes, private readonly at: () => Location) { super(ByteBuffer.fromBuffer(bytes)); }
    private require(count: number): void {
        if (!Number.isSafeInteger(count) || count < 0 || count > this.length - this.position) refuse('binary-truncated', 'Read/skip exceeds immutable binary input.', { ...this.at(), byteOffset: this.position });
    }
    override get position(): number { return super.position; }
    override set position(value: number) {
        if (!Number.isSafeInteger(value) || value < 0 || value > this.length) refuse('binary-truncated', 'Binary reader attempted an out-of-range cursor.', { ...this.at(), byteOffset: super.position });
        super.position = value;
    }
    override readByte(): number { this.require(1); return super.readByte(); }
    override read(buffer: Uint8Array, offset: number, count: number): number { this.require(count); return super.read(buffer, offset, count); }
    override skip(count: number): void { this.require(count); super.skip(count); }
}

/** Original adapter: raw spans/flags are captured and gated before borrowed normalization. */
class CapturingReader extends Gp3To5Importer {
    readonly records: BinaryRecord[] = [];
    readonly tracks = new Map<number, Frame>();
    readonly masters: Frame[] = [];
    readonly beats = new Map<Beat, Frame>();
    readonly notes = new Map<Note, Frame>();
    readonly mixes = new Map<Beat, Frame>();
    readonly globals: Record<string, number> = {};
    readonly fieldLocations = new Map<string, Location>();
    private frame: Frame = { source: { member: 'input', path: '/header' }, facts: this.globals };
    private trackOrdinal = 0;
    private masterOrdinal = 0;
    private totalBeats = 0;
    private totalNotes = 0;
    private captureBytes = 2;
    get position(): number { return this.data.position; }
    get location(): Location { return this.frame.source; }
    constructor(readonly bytes: Bytes, readonly version: number, readonly selected: Set<string> | undefined, readonly discovery = false) {
        super();
        this.onSourceField = (name, value, byteOffset, byteLength) => {
            const source = { ...this.frame.source, path: `${this.frame.source.path}/${name}`, byteOffset, byteLength };
            this.frame.facts[name] = value;
            if (this.frame.facts === this.globals || /^\/tracks\/\d$/.test(this.frame.source.path ?? '')) this.fieldLocations.set(source.path!, source);
            if (!discovery) this.record({ kind: 'field', source, dataBase64: bytes.subarray(byteOffset, byteOffset + byteLength).base64(), facts: { value } });
            this.guard(name, value, source);
        };
    }
    private requested(source = this.frame.source): boolean { return !this.discovery && (!this.selected || source.trackId === undefined || this.selected.has(source.trackId)); }
    private record(record: BinaryRecord): void {
        if (this.records.length >= limits.binaryRecords) refuse('capture-budget', 'Binary record count exceeds the source-capture budget.', record.source);
        this.captureBytes += jsonBytes(record, limits.captureBytes - this.captureBytes, 'capture-budget', record.source) + (this.records.length ? 1 : 0);
        this.records.push(record);
    }
    private guard(name: string, value: number, source: Location): void {
        const reject = (message: string, code = 'binary-feature'): never => refuse(code, message, source);
        if (!Number.isSafeInteger(value)) reject('Noninteger binary field.', 'binary-field');
        if (name === 'bar-count' && (value < 1 || value > limits.measures)) reject('Binary measure count exceeds the profile.', 'measure-budget');
        if (name === 'track-count' && (value < 1 || value > limits.tracks)) reject('Binary track count exceeds the profile.', 'track-scope');
        if (name === 'beat-count') {
            if (value < 0 || value > limits.occurrences || (this.totalBeats += value) > limits.occurrences) reject('Binary expanded beat count exceeds the profile.', 'occurrence-budget');
        }
        if (name === 'string-count' && (value < 1 || value > 7)) reject('Binary string count is outside its encoded capacity.', 'tuning');
        if (name === 'channel' && (value < 1 || value > 64)) reject('Unresolved MIDI channel.', 'instrument');
        if (this.discovery) return;
        if (name.startsWith('lyrics-present:') && value && (!this.selected || this.selected.has(String(this.frame.facts['lyrics-track'])))) reject('Nonempty selected-track lyrics require an export mapping.', 'lyrics');
        if (name === 'navigation' && value !== -1) reject('Navigation jumps/targets are outside the simple-repeat profile.');
        if (['global-triplet-feel', 'triplet-feel', 'alternate-endings', 'initial-octave'].includes(name) && value !== 0)
            reject('Swing/endings/global octave interpretation requires an exercised mapping.');
        if (name === 'initial-tempo' && (value < 1 || value > 1000)) reject('Initial quarter tempo outside the profile.', 'tempo-rate');
        if (name === 'initial-key' && (value < -7 || value > 7)) reject('Initial key outside the profile.', 'key');
        if (name === 'key-fifths' && (value < -7 || value > 7) || name === 'key-mode' && ![0, 1].includes(value)) reject('Encoded key outside profile.', 'key');
        if (name === 'hide-tempo' && ![0, 1].includes(value)) reject('Tempo visibility requires an encoded boolean.', 'boolean');
        if (name === 'track-separator' && value) reject('Unreviewed track separator.', 'binary-field');
        if (name === 'bar-line-break' && ![0, 1, 2].includes(value)) reject('Unknown binary layout break.', 'binary-field');
        if (name === 'string-count' && (value < 1 || value > 7)) reject('Binary string count is outside its encoded capacity.', 'tuning');
        if (name === 'channel' && (value < 1 || value > 64)) reject('Unresolved MIDI channel.', 'instrument');
        if (name === 'mix-tempo' && value !== -1 && (value < 1 || value > 1000)) reject('Mixer tempo outside profile.', 'tempo-rate');
        if (name === 'mix-duration' && value !== 0) reject('Global tempo ramp requires a mapping, including in an excluded track.', 'automation');
        if (name === 'mix-hide-tempo' && ![0, 1].includes(value)) reject('Mixer visibility requires a boolean.', 'boolean');
        if (!this.requested(source)) return;
        if (name === 'track-flags' && value & 0x77) reject('Percussion/doubled strings, solo/mute or unknown track flags are outside the bass profile.');
        if (name === 'string-count' && value < 4) reject('Selected bass requires 4–7 explicit strings.', 'tuning');
        if (name === 'capo' && value) reject('Active capo requires a separate pitch convention.', 'capo');
        if (name === 'automatic-midi' && value & ~1) reject('Automatic let-ring/brush changes attacks or sustain.');
        if (['automatic-accent', 'humanize', 'sound-bank'].includes(name) && value) reject('Active automatic accent/humanize or nonzero sound-bank requires a mapping.', 'playback-profile');
        if (name === 'clef-mode' && value !== 0 && value !== 12) reject('Unreviewed encoded clef mode.', 'clef');
        if (name === 'secondary-clef-mode' && value !== this.frame.facts['clef-mode']) reject('Different primary/secondary clefs declare an unadmitted dual-staff layout.', 'clef');
        if (name === 'master-flags' && value & 0x10) reject('Alternate endings are outside the simple-repeat profile.', 'repeat');
        if (name === 'beat-flags' && value & 0x80) reject('Unknown beat flag.');
        if (name === 'beat-status' && value !== 2) reject('Encoded empty/unknown beat status needs explicit silence semantics.');
        if (name === 'duration-exponent' && (value < -2 || value > 4)) reject('Written rhythm outside whole–64th notes.', 'rhythm');
        if (name === 'tuplet' && ![3, 5, 6, 7, 9, 10, 11, 12, 13].includes(value)) reject('Unexercised binary tuplet mapping.', 'rhythm');
        if (name === 'beat-flags2' && value & ~0x200f) reject('Ottava/unknown/secondary-beaming flags require a mapping.');
        if (name === 'note-flags' && (value & ~0x38 || !(value & 0x20))) reject('Source note needs explicit type/fret; override/ghost/accent/fingers are unexercised.');
        if (name === 'note-type' && ![1, 2, 3].includes(value)) reject('Unknown source note type.');
        if (name === 'note-fret' && this.frame.facts['note-type'] !== 2 && (value < 0 || value > 36)) reject('Fret outside the physical profile.', 'physical-pitch');
        if (name === 'note-dynamic' && (value < 1 || value > 8)) reject('Unknown encoded dynamic.', 'dynamic');
        if (name === 'note-flags2' && value) reject('Unknown or unexercised accidental-swap note flag.');
        if (name === 'note-effect-flags' && value & ~2) reject('Unexercised bend/slide/harmonic/mute/grace note effect.', 'technique');
        if (name === 'note-effect-flags2' && value) reject('Unexercised note effect.', 'technique');
        if (name.startsWith('mix-') && ['mix-instrument', 'mix-volume', 'mix-balance', 'mix-chorus', 'mix-reverb', 'mix-phaser', 'mix-tremolo', 'mix-wah'].includes(name) && value !== -1) reject('Active non-tempo mixer changes require a mapping.', 'automation');
        if (name === 'mix-flags' && value & 0xc0) reject('Unreviewed mixer wah/flag convention.', 'automation');
    }
    private scope<T>(kind: string, coordinates: Partial<Location>, body: () => T): { result: T; frame: Frame } {
        const previous = this.frame, start = this.data.position;
        const frame: Frame = { source: { ...previous.source, ...coordinates, byteOffset: start }, facts: {} };
        this.frame = frame;
        try {
            const result = body();
            frame.source.byteLength = this.data.position - start;
            if (!this.discovery) this.record({ kind, source: frame.source, facts: frame.facts,
                dataBase64: this.bytes.subarray(start, this.data.position).base64() });
            return { result, frame };
        } finally { this.frame = previous; }
    }
    override readScoreInformation(): void { this.scope('metadata', { path: '/score-information' }, () => super.readScoreInformation()); }
    override readLyrics(): void { this.scope('metadata', { path: '/lyrics' }, () => super.readLyrics()); }
    override readPageSetup(): void { this.scope('metadata', { path: '/page-setup' }, () => super.readPageSetup()); }
    override readMasterBar(): void {
        const measure = ++this.masterOrdinal;
        const captured = this.scope('master-bar', { path: `/master-bars/${measure}`, measure }, () => super.readMasterBar());
        if (!this.discovery) this.masters.push(captured.frame);
    }
    override readTrack(): void {
        const id = this.trackOrdinal++;
        this.tracks.set(id, this.scope('track', { path: `/tracks/${id}`, trackId: String(id) }, () => super.readTrack()).frame);
    }
    override readBar(track: Track): void {
        this.scope('bar', { path: `/tracks/${track.index}/bars/${track.staves[0].bars.length + 1}`, trackId: String(track.index),
            measure: track.staves[0].bars.length + 1 }, () => super.readBar(track));
    }
    override readVoice(track: Track, bar: Bar): void {
        this.scope('voice', { path: `${this.frame.source.path}/voices/${bar.voices.length + 1}`, voice: bar.voices.length + 1 }, () => super.readVoice(track, bar));
    }
    override readBeat(track: Track, bar: Bar, voice: Voice): void {
        const captured = this.scope('beat', { path: `${this.frame.source.path}/beats/${voice.beats.length + 1}`, beat: voice.beats.length + 1 }, () => super.readBeat(track, bar, voice));
        if (!this.discovery) this.beats.set(voice.beats.at(-1)!, captured.frame);
        const mask = captured.frame.facts['string-mask'], count = bar.staff.stringTuning.tunings.length;
        if (mask & ~(((1 << count) - 1) << (7 - count))) refuse('physical-pitch', 'String mask addresses absent strings.', captured.frame.source);
    }
    override readNote(track: Track, bar: Bar, voice: Voice, beat: Beat, stringIndex: number): Note {
        if (++this.totalNotes > limits.occurrences) refuse('occurrence-budget', 'Expanded binary note count exceeds the profile.', this.frame.source);
        const captured = this.scope('note', { path: `${this.frame.source.path}/strings/${stringIndex + 1}`, id: `${this.frame.source.path}/strings/${stringIndex + 1}` },
            () => super.readNote(track, bar, voice, beat, stringIndex));
        captured.frame.facts['source-string'] = stringIndex + 1;
        if (!this.discovery) this.notes.set(captured.result, captured.frame);
        return captured.result;
    }
    override readBeatEffects(beat: Beat) {
        if (this.requested() && (this.bytes[this.data.position] || this.version >= 400 && this.bytes[this.data.position + 1]))
            refuse('technique', 'Beat-level attack/sustain effects require a mapping.', { ...this.frame.source, byteOffset: this.data.position });
        return this.scope('beat-effects', { path: `${this.frame.source.path}/effects` }, () => super.readBeatEffects(beat)).result;
    }
    override readChord(beat: Beat): void { this.scope('chord-diagram', { path: `${this.frame.source.path}/chord-diagram` }, () => super.readChord(beat)); }
    override readMixTableChange(beat: Beat): void {
        const captured = this.scope('mix-table', { path: `${this.frame.source.path}/mix-table` }, () => super.readMixTableChange(beat));
        if (!this.discovery) this.mixes.set(beat, captured.frame);
    }
}

function recoverBeforeFinish(score: Score, reader: CapturingReader, findings: Finding[]): { score: NeutralScore; expected: { note: Note; fact: NoteFact; event: Event }[] } {
    const expected: { note: Note; fact: NoteFact; event: Event }[] = [];
    let repeatOpen = false;
    for (let mi = 0; mi < score.masterBars.length; mi++) {
        const master = score.masterBars[mi], source = reader.masters[mi].source;
        if (master.isRepeatStart && repeatOpen || master.repeatCount && !repeatOpen && !master.isRepeatStart) refuse('repeat', 'Simple repeats need an explicit unnested start.', source);
        if (master.isRepeatStart) repeatOpen = true;
        if (master.repeatCount) { if (master.repeatCount < 2 || master.repeatCount > 8) refuse('repeat', 'Repeat count outside 2–8.', source); repeatOpen = false; }
        if (master.directions?.size || master.alternateEndings || master.isFreeTime) refuse('repeat', 'Unadmitted navigation/free-time.', source);
    }
    if (repeatOpen) refuse('repeat', 'Unclosed repeat.', reader.masters.at(-1)!.source);
    const parts: Part[] = [];
    const tempos: Tempo[] = [];
    for (const track of score.tracks) {
        const id = String(track.index), frame = reader.tracks.get(track.index)!;
        if (reader.selected && !reader.selected.has(id)) {
            findings.push({ disposition: 'excluded-by-scope', code: 'track-excluded', message: 'Encoded track is excluded from requested output; original bytes and spans remain captured.', location: frame.source, fact: { trackId: id, name: track.name } });
            continue;
        }
        const staff = track.staves[0], highToLow = staff.stringTuning.tunings;
        const program = track.playbackInfo.program;
        if (track.staves.length !== 1 || staff.isPercussion || program < 24 || program > 39) refuse('instrument', 'Binary admission requires an explicit fretted guitar/bass MIDI program 24–39.', frame.source);
        if (highToLow.length < 4 || highToLow.length > 7 || highToLow.some((pitch, i) => pitch < 12 || pitch > 108 || i > 0 && pitch >= highToLow[i - 1]))
            refuse('tuning', 'Expected complete descending high-to-low binary string tuning.', frame.source);
        const tuning = highToLow.slice().reverse();
        let key = { fifths: reader.globals['initial-key'], mode: 'major' };
        let measureStart = q(0);
        const previousEvents = new Map<number, { event: Event; end: ReturnType<typeof q> }>();
        const measures: Measure[] = staff.bars.map((bar, mi) => {
            const master = score.masterBars[mi], source = { ...reader.masters[mi].source, trackId: id };
            const beats = master.timeSignatureNumerator, unit = master.timeSignatureDenominator;
            if (beats < 1 || beats > 32 || unit < 1 || unit > 64 || unit & (unit - 1)) refuse('meter', 'Binary meter outside profile.', source);
            const span = q(beats * 4, unit);
            const voices = bar.voices.map((voice, vi) => {
                let position = q(0);
                return voice.beats.map(beat => {
                    const raw = reader.beats.get(beat)!;
                    if (!raw || beat.isEmpty) refuse('empty-voice', 'Empty encoded beats need explicit silence semantics.', source);
                    const dots = raw.facts['beat-flags'] & 1 ? 1 : 0;
                    const denominator = 2 ** (raw.facts['duration-exponent'] + 2);
                    const actual = raw.facts.tuplet;
                    const normal = actual === 3 ? 2 : actual && actual <= 7 ? 4 : 8;
                    const tuplet = actual ? { actual, normal } : undefined;
                    const duration = mul(mul(q(4, denominator), q(dots ? 3 : 1, dots ? 2 : 1)), q(tuplet?.normal ?? 1, tuplet?.actual ?? 1));
                    const sourceNotes = beat.notes.map(note => {
                        const rawNote = reader.notes.get(note)!;
                        const string = rawNote.facts['source-string'], placeholder = rawNote.facts['note-fret'];
                        let fret = placeholder;
                        if (rawNote.facts['note-type'] === 2) {
                            const previous = previousEvents.get(vi), origin = previous?.event.notes.find(n => n.string === string);
                            if (!origin || origin.kind !== 'pitched' || !equal(previous!.end, add(measureStart, position))) refuse('tie-conflict', 'Binary tie destination needs an immediately preceding contiguous same-string pitched source origin.', rawNote.source);
                            fret = origin!.fret;
                            findings.push({ disposition: 'preserved', code: 'binary-tie-fret', message: 'Binary note-type2 inherits the preceding same-string effective fret; its serialized signed-byte fret is an unused placeholder, retained unchanged. This derives source encoding semantics, not a musical repair.', location: rawNote.source, fact: { rawPlaceholder: placeholder, effectiveFret: fret, origin: origin!.source } });
                        }
                        const midi = highToLow[string - 1] + fret;
                        const reference = inferredPitch(midi), written = inferredPitch(midi + 12);
                        const dead = rawNote.facts['note-type'] === 3;
                        const fact: NoteFact = { source: rawNote.source, id: rawNote.source.id!, string, fret, kind: dead ? 'dead' : 'pitched',
                            sounding: dead ? null : reference, written, ...(dead ? { referenceSounding: reference } : {}), tieStart: false,
                            tieStop: rawNote.facts['note-type'] === 2,
                            ...(rawNote.facts['note-effect-flags'] & 2 ? { sourceHopoOrigin: true } : {}) };
                        return { note, fact, dynamic: rawNote.facts['note-dynamic'] };
                    });
                    const levels = [...new Set(sourceNotes.map(note => note.dynamic).filter(value => value !== undefined))];
                    if (levels.length > 1) refuse('dynamic', 'Conflicting per-note chord dynamics cannot become one mark.', raw.source);
                    const event: Event = { source: raw.source, id: raw.source.path!, start: position, duration, type: rhythmTypes[denominator], dots,
                        ...(tuplet ? { tuplet } : {}), notes: sourceNotes.map(note => note.fact),
                        fullMeasureRest: !sourceNotes.length && voice.beats.length === 1 && equal(duration, span),
                        ...(levels.length ? { dynamic: dynamics[levels[0]] } : {}), ...(beat.text ? { text: beat.text } : {}) };
                    const mix = reader.mixes.get(beat);
                    if (mix && mix.facts['mix-tempo'] >= 0) tempos.push({ source: mix.source, measure: mi, position, rate: String(mix.facts['mix-tempo']), reference: 2, unit: 'quarter', dots: 0, quarterRate: mix.facts['mix-tempo'], visible: !mix.facts['mix-hide-tempo'] });
                    for (const note of sourceNotes) expected.push({ note: note.note, fact: note.fact, event });
                    previousEvents.set(vi, { event, end: add(measureStart, add(position, duration)) });
                    position = add(position, duration);
                    return event;
                });
            });
            const populated = voices.filter(voice => voice.length);
            if (!populated.length) refuse('empty-measure', 'An entirely empty binary measure needs explicit silence admission.', source);
            const totals = populated.map(voice => voice.reduce((sum, event) => add(sum, event.duration), q(0)));
            const pickup = mi === 0 && totals[0].n * span.d < span.n * totals[0].d;
            const duration = pickup ? totals[0] : span;
            if (!totals.every(total => equal(total, duration))) refuse('measure-duration', 'Active binary voices must fill the exact common span.', source);
            const masterFields = reader.masters[mi].facts;
            if (masterFields['key-fifths'] !== undefined) key = { fifths: masterFields['key-fifths'], mode: masterFields['key-mode'] ? 'minor' : 'major' };
            const encodedClef = frame.facts['clef-mode'];
            const clef = encodedClef === 0 ? 'G2' : encodedClef === 12 ? 'F4' : program < 32 ? 'G2' : highToLow.at(-1)! < 35 ? 'F4' : 'G2';
            measureStart = add(measureStart, duration);
            return { source, time: { beats, unit }, key: { ...key },
                clef, pickup, duration, voices, repeatStart: master.isRepeatStart, repeatEnd: master.repeatCount };
        });
        // A binary tie flag marks only its destination. Derive the origin after validating raw physical agreement.
        for (let vi = 0; vi < Math.max(...measures.map(measure => measure.voices.length)); vi++) {
            const timeline: { event: Event; start: ReturnType<typeof q> }[] = [];
            let start = q(0);
            for (const measure of measures) {
                for (const event of measure.voices[vi] ?? []) timeline.push({ event, start: add(start, event.start) });
                start = add(start, measure.duration);
            }
            for (let i = 0; i < timeline.length; i++) {
                const current = timeline[i], previous = timeline[i - 1], next = timeline[i + 1];
                for (const note of current.event.notes) {
                    if (note.kind === 'dead' && (note.tieStop || note.sourceHopoOrigin)) refuse('dead-relation', 'Dead tie/HOPO is outside the profile.', note.source);
                    if (note.tieStop) {
                        const origin = previous?.event.notes.find(candidate => candidate.string === note.string);
                        if (!origin || origin.kind !== 'pitched' || origin.fret !== note.fret || origin.sounding?.midi !== note.sounding?.midi ||
                            !equal(add(previous.start, previous.event.duration), current.start)) refuse('tie-conflict', 'Raw binary tie destination has no matching contiguous physical origin; reader repairs are refused.', note.source);
                        origin!.tieStart = true;
                        findings.push({ disposition: 'inferred', code: 'binary-tie-origin', message: 'Destination-only encoded tie implies the validated contiguous same-string origin; raw destination type/fret bytes remain unchanged.', location: note.source, fact: { origin: origin!.source } });
                    }
                    if (note.sourceHopoOrigin) {
                        const target = next?.event.notes.find(candidate => candidate.string === note.string);
                        if (!target || target.kind !== 'pitched' || target.fret === note.fret || !equal(add(current.start, current.event.duration), next.start) || current.event.notes.filter(candidate => candidate.sourceHopoOrigin).length > 1)
                            refuse('hopo-conflict', 'Binary HOPO origin needs one contiguous same-string changed-fret destination.', note.source);
                        const kind = target!.fret > note.fret ? 'hammer-on' : 'pull-off';
                        note.hopoStart = kind; target!.hopoStop = kind; note.hopoNumber = target!.hopoNumber = vi + 1;
                        findings.push({ disposition: 'inferred', code: 'binary-hopo-endpoint', message: 'Encoded origin-only HOPO supplies a validated next-beat endpoint and fret-direction classification; source flags remain separate.', location: note.source, fact: { destination: target!.source, kind } });
                    }
                }
            }
        }
        const family = program < 32 ? 'guitar' : 'bass', rule = `gp3-5-${family}-register/0`;
        findings.push({ disposition: 'inferred', code: 'binary-written-register', message: `GP3–5 ${family} notation convention writes one octave above physical sounding MIDI, with MusicXML octave transpose -1. This is generated versioned representation (${rule}), not encoded chromatic transpose or another actual-pitch shift; producer display fidelity remains unverified.`, location: frame.source, fact: { program, transposeOctaves: -1, rule } });
        findings.push({ disposition: 'inferred', code: 'binary-pitch-spelling', message: 'Binary tuning/fret supplies sounding MIDI, not full spelling. Sharp-based written/reference spelling is generated; raw key and clef fields remain separate.', location: frame.source });
        if (reader.version < 500) findings.push({ disposition: 'inferred', code: 'binary-clef', message: 'No explicit main clef field is encoded in this profile; guitar uses conventional treble, while bass uses a located low-tuning reference-clef rule. It is not source staff/hand identity.', location: frame.source, fact: { family } });
        findings.push({ disposition: 'preserved', code: 'binary-voice-slots', message: 'Encoded voice slots, including zero-beat secondary voices, are retained without generating rests or attacks.', location: frame.source, fact: { voiceCounts: measures.map(measure => measure.voices.map(voice => voice.length)) } });
        parts.push({ source: frame.source, id, name: track.name, instrument: family, midiProgram: program, tuning, transposeOctaves: -1, measures });
    }
    if (!parts.length || reader.selected && [...reader.selected].some(id => !reader.tracks.has(Number(id)))) refuse('track-selection', 'Requested binary track ID is absent.', { member: 'input' });
    if (parts.some(part => !equal(part.measures[0].duration, parts[0].measures[0].duration))) refuse('pickup-span', 'Selected tracks need one exact pickup span.', { member: 'input' });
    // Tempo is global even when its binary mixer record occurs on an excluded track.
    for (const [beat, mix] of reader.mixes) if (reader.selected && !reader.selected.has(mix.source.trackId!) && mix.facts['mix-tempo'] >= 0) {
        let position = q(0);
        for (const prior of beat.voice.beats) {
            if (prior === beat) break;
            const raw = reader.beats.get(prior)!, exponent = raw.facts['duration-exponent'], actual = raw.facts.tuplet;
            if (!raw || prior.isEmpty || exponent < -2 || exponent > 4 || actual && ![3,5,6,7,9,10,11,12,13].includes(actual)) refuse('tempo-source-clock', 'Excluded track global tempo needs an admitted exact written prefix clock.', mix.source);
            const normal = actual === 3 ? 2 : actual && actual <= 7 ? 4 : 8;
            position = add(position, mul(mul(q(4, 2 ** (exponent + 2)), q(raw.facts['beat-flags'] & 1 ? 3 : 1, raw.facts['beat-flags'] & 1 ? 2 : 1)), q(actual ? normal : 1, actual ?? 1)));
        }
        const measure = mix.source.measure! - 1, span = parts[0].measures[measure].duration;
        if (position.n * span.d >= span.n * position.d) refuse('tempo-position', 'Global tempo in excluded track lies outside the selected common measure.', mix.source);
        tempos.push({ source: mix.source, measure, position, rate: String(mix.facts['mix-tempo']), reference: 2, unit: 'quarter', dots: 0, quarterRate: mix.facts['mix-tempo'], visible: !mix.facts['mix-hide-tempo'] });
        findings.push({ disposition: 'preserved', code: 'binary-excluded-global-tempo', message: 'Global tempo is retained even though its containing track is excluded from musical output; position is reconstructed from original written prefix fields.', location: mix.source });
    }
    const tempo = reader.globals['initial-tempo'];
    const initial: Tempo = { source: reader.records.find(record => record.source.path === '/header/initial-tempo')!.source,
        measure: 0, position: q(0), rate: String(tempo), reference: 2, unit: 'quarter', dots: 0, quarterRate: tempo, visible: !reader.globals['hide-tempo'] };
    const unique = new Map<string, Tempo>();
    for (const change of [initial, ...tempos]) {
        const key = `${change.measure}:${change.position.n}/${change.position.d}`, previous = unique.get(key);
        if (previous && previous.rate !== change.rate) {
            if (previous !== initial) refuse('tempo-conflict', 'Concurrent source tracks encode conflicting common tempo.', change.source);
        }
        if (previous && previous !== initial && previous.visible !== change.visible) refuse('tempo-conflict', 'Concurrent tempo records disagree about visibility.', change.source);
        unique.set(key, change);
    }
    const neutral = { title: score.title, parts, tempos: [...unique.values()].sort((a, b) => a.measure - b.measure || a.position.n * b.position.d - b.position.n * a.position.d) };
    return { score: neutral, expected };
}

function loadBinary(input: Uint8Array, findings: Finding[], trackIds?: string[], discovery = false) {
    const bytes = Bytes.view(input);
    if (bytes.length < 31 || bytes[0] > 30) refuse('binary-header', 'Expected a complete fixed-width Guitar Pro header.', { member: 'input', byteOffset: 0 });
    const header = bytes.subarray(1, 1 + bytes[0]).ascii(), version = headers[header];
    if (!version) refuse('version-profile', 'Only documented whole-score GP3.00/GP4.00/GP4.06/L4.06/GP5.00/GP5.10 binary headers are admitted; clipboard/unknown versions require explicit support.', { member: 'input', byteOffset: 0, byteLength: 31 });
    if (trackIds && (!trackIds.length || new Set(trackIds).size !== trackIds.length || trackIds.some(id => !/^[0-7]$/.test(id)))) refuse('track-selection', 'Expected distinct zero-based encoded track ordinals0–7.');
    const reader = new CapturingReader(bytes, version, trackIds ? new Set(trackIds) : undefined, discovery);
    reader.init(new BoundedInput(bytes, () => reader.location), new Settings());
    let prepared: ReturnType<typeof recoverBeforeFinish> | undefined;
    let rawScore: Score | undefined;
    reader.onBeforeFinish = score => { rawScore = score; if (discovery) throw new DiscoveryComplete(); prepared = recoverBeforeFinish(score, reader, findings); };
    Logger.logLevel = LogLevel.None;
    try { reader.readScore(); } catch (error) {
        if (error instanceof DiscoveryComplete) { /* Complete source parsing; normalization is unnecessary for metadata. */ }
        else if (error instanceof Refusal) throw error;
        else refuse('binary-truncated', 'Binary reader encountered truncated or malformed bounded input.', { member: 'input' });
    }
    if (!rawScore || !discovery && !prepared) refuse('reader', 'Binary reader did not provide pre-normalization source capture.');
    if (reader.position > bytes.length) refuse('binary-truncated', 'Reader cursor exceeded binary input.', { member: 'input', byteOffset: bytes.length });
    if (reader.position !== bytes.length) {
        const expectedPadding = version === 300 ? 4 : 0;
        const tail = bytes.subarray(reader.position);
        if (tail.length !== expectedPadding || tail.some(byte => byte !== 0)) refuse('binary-trailing', 'Unaccounted bytes follow the complete binary score.', { member: 'input', byteOffset: reader.position });
        if (!discovery) reader.records.push({ kind: 'serialization-padding', source: { member: 'input', byteOffset: reader.position, byteLength: tail.length }, dataBase64: tail.base64(), facts: {} });
        findings.push({ disposition: 'preserved', code: 'binary-final-padding', message: 'Reviewed zero footer/separator bytes are retained as serialization padding, not musical events.', location: { member: 'input', byteOffset: reader.position, byteLength: tail.length } });
    }
    return { reader, header, version, prepared, rawScore: rawScore! };
}
class DiscoveryComplete {}

export function readBinary(input: Uint8Array, findings: Finding[], trackIds?: string[]): { score: NeutralScore; occurrences: OccurrenceCapture[]; capture: BinaryCapture } {
    const { reader, header, version, prepared } = loadBinary(input, findings, trackIds);
    const occurrences = prepared!.expected.map(({ note, fact, event }) => {
        const reference = fact.sounding ?? fact.referenceSounding!;
        const sourceCount = reader.tracks.get(Number(fact.source.trackId))!.facts['string-count'];
        const beforeString = sourceCount - fact.string + 1;
        if (note.fret !== fact.fret || note.string !== beforeString || note.realValue !== reference.midi || note.isDead !== (fact.kind === 'dead') || note.isTieDestination !== fact.tieStop)
            refuse('reader-reconciliation', 'Normalized binary reader disagrees with immutable physical/type/tie facts.', fact.source);
        return { source: fact.source, rhythmId: event.id + '/rhythm', noteId: fact.id,
            before: { fret: reader.notes.get(note)!.facts['note-fret'], string: beforeString, tieDestination: fact.tieStop },
            after: { fret: note.fret, string: note.string, tieDestination: note.isTieDestination, soundingMidi: reference.midi, playbackTicks: note.beat.playbackDuration } };
    });
    findings.push({ disposition: 'preserved', code: 'binary-source-reconciled', message: 'Original numeric flags/spans are captured before normalization; exact written clocks and physical/type/tie facts reconcile with the borrowed reader. Track IDs are stable encoded ordinals, not inferred performing roles.', location: { member: 'input' }, fact: { header, version, noteOccurrences: occurrences.length } });
    findings.push({ disposition: 'omitted', code: 'binary-metadata-playback', message: 'Original metadata/page/lyrics/chord-diagram and playback setup bytes remain captured. Synth timbre, page appearance and inactive display settings are not reapplied; unknown selected musical meaning is refused.', location: { member: 'input' } });
    return freeze({ score: prepared!.score, occurrences, capture: { header, version, sourceEncoding: 'windows-1252-with-explicit-BOM-detection', records: reader.records } });
}

/** Compact observations from the complete bounded source parse, before model normalization. */
export function readBinaryMetadata(input: Uint8Array, findings: Finding[]) {
    const { reader, header, version, rawScore } = loadBinary(input, findings, undefined, true);
    return { header, version, tracks: rawScore.tracks.map(track => {
        const frame = reader.tracks.get(track.index)!, path = frame.source.path!, channel = frame.facts['channel'] - 1;
        const first = reader.fieldLocations.get(path + '/tuning:0')!;
        return { sourceId: String(track.index), sourceLocation: frame.source,
            name: track.name, nameLocation: reader.fieldLocations.get(path + '/track-name-length')!,
            program: reader.globals['channel-program:' + channel], programLocation: reader.fieldLocations.get('/header/channel-program:' + channel)!,
            tuning: Array.from({ length: frame.facts['string-count'] }, (_, i) => frame.facts['tuning:' + i]),
            tuningLocation: { ...first, byteLength: frame.facts['string-count'] * 4 }, facts: frame.facts };
    }) };
}

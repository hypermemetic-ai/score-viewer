import { inspectPortable, type InspectionResult } from './inspect-core.js';
import { readContainer } from './zip.js';
export type { InspectionResult, SourceTrackInfo } from './inspect-core.js';
export function inspectInWorker(bytes: Uint8Array): InspectionResult { return inspectPortable(bytes, () => readContainer(bytes)); }

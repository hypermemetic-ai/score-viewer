import { freeze } from '../core/report.js';
import type { ConversionResult, InspectionResult } from '../guitar-pro-contract.js';

export const protocol = 'score-converter-gp-worker/1';
export type Operation = 'convert' | 'inspect';
export interface Request {
    protocol: typeof protocol;
    requestId: number;
    operation: Operation;
    inputSha256: string;
    bytes: Uint8Array;
    trackIds?: string[];
}
export type Result = ConversionResult | InspectionResult;
export function hostFailure(operation: Operation, inputSha256: string, trackIds: string[] | undefined, code: string, message: string): Result {
    return freeze({ ok: false, report: {
        schema: 'score-converter-report/0', inputSha256, adapter: 'alphatab-1.8.4-022a45c8+source-hook/1',
        profile: operation === 'inspect' ? 'gp-family-inventory/0' : 'gp-family-fretted/0',
        requestedScope: trackIds ? { trackIds } : 'all-tracks',
        findings: [{ disposition: 'blocking', code, message, location: { member: 'input' } }]
    } });
}

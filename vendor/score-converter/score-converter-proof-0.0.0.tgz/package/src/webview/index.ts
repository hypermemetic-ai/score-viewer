import { freeze } from '../core/report.js';
import { limits } from '../adapters/guitar-pro/limits.js';
import { inputView, snapshotInput, snapshotTrackIds } from '../guitar-pro-input.js';
import { jsonBytes } from '../adapters/guitar-pro/work-budgets.js';
import { protocol, hostFailure, type Operation, type Result } from './protocol.js';
import type { ConversionResult, InspectionResult, GuitarProOptions, GuitarProInspectionOptions } from '../guitar-pro-contract.js';
export type * from '../guitar-pro-contract.js';

let sequence = 0;
const cancellationReason = (signal: AbortSignal): unknown => signal.reason === undefined ? new Error('Conversion cancelled.') : signal.reason;

/** Local module Worker per request; the consumer owns concurrency, hosting and platform acceptance. */
export async function convertGuitarPro(bytes: Uint8Array, options: GuitarProOptions = {}): Promise<ConversionResult> {
    return run('convert', bytes, options) as Promise<ConversionResult>;
}
/** Compact metadata discovery; eligibility never authorizes a musical conversion. */
export async function inspectGuitarPro(bytes: Uint8Array, options: GuitarProInspectionOptions = {}): Promise<InspectionResult> {
    return run('inspect', bytes, options) as Promise<InspectionResult>;
}
async function run(operation: Operation, bytes: Uint8Array, options: GuitarProOptions): Promise<Result> {
    if (!options || typeof options !== 'object' || Array.isArray(options)) throw new TypeError('Expected a conversion options object.');
    const signal = options.signal, requestedTrackIds = options.trackIds;
    if (operation === 'inspect' && requestedTrackIds !== undefined) throw new TypeError('Inspection discovers source tracks; selection belongs to conversion.');
    if (signal !== undefined && (!signal || typeof signal.aborted !== 'boolean' || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) throw new TypeError('Expected an AbortSignal.');
    if (signal?.aborted) throw cancellationReason(signal);
    const view = inputView(bytes), trackIds = snapshotTrackIds(requestedTrackIds);
    if (typeof Worker !== 'function' || typeof globalThis.crypto?.subtle?.digest !== 'function' || typeof globalThis.performance?.now !== 'function') throw new TypeError('This entry requires local module Workers, WebCrypto SHA-256 and a monotonic clock.');
    const inputBytes = view.byteLength;
    const input = snapshotInput(view);
    const requestId = ++sequence, started = performance.now();
    return new Promise((resolve, reject) => {
        let worker: Worker | undefined, done = false, inputSha256: string | undefined;
        const finish = (result?: Result, error?: unknown) => {
            if (done) return;
            let immutable = result === undefined ? undefined : freeze(result);
            // Validation/freezing is synchronous; a delayed timer cannot authorize a late result.
            if (immutable !== undefined && inputSha256 && performance.now() - started >= limits.workerMs) immutable = failure('work-budget', 'Worker request exceeded 5 seconds; no musical output is admitted.');
            done = true; clearTimeout(timer); signal?.removeEventListener('abort', abort);
            if (worker) { worker.onmessage = worker.onerror = worker.onmessageerror = null; worker.terminate(); }
            if (error !== undefined) reject(error); else resolve(immutable!);
        };
        const failure = (code: string, message: string) => hostFailure(operation, inputSha256!, trackIds, code, message);
        const abort = () => finish(undefined, cancellationReason(signal!));
        const expire = () => {
            // A crypto operation cannot be cancelled. Do not invent an unavailable source digest.
            if (!inputSha256) finish(undefined, new Error('GP request exceeded 5 seconds before source hashing completed.'));
            else finish(failure('work-budget', 'Worker request exceeded 5 seconds; no musical output is admitted.'));
        };
        const timer = setTimeout(expire, limits.workerMs);
        signal?.addEventListener('abort', abort, { once: true });
        if (signal?.aborted) { abort(); return; }
        void (async () => {
            try {
                const digest = await globalThis.crypto.subtle.digest('SHA-256', input);
                if (done) return;
                inputSha256 = [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
                if (performance.now() - started >= limits.workerMs) { expire(); return; }
                worker = new Worker(new URL('./guitar-pro.worker.js', import.meta.url), { type: 'module' });
                worker.onmessage = ({ data }) => {
                    if (done) return;
                    if (performance.now() - started >= limits.workerMs) { expire(); return; }
                    try {
                        if (!data || data.protocol !== protocol || data.requestId !== requestId || data.operation !== operation ||
                            data.result?.report?.inputSha256 !== inputSha256 ||
                            typeof data.result.ok !== 'boolean') throw new Error('identity');
                        jsonBytes(data.result, operation === 'inspect' ? limits.reportBytes : limits.resultBytes);
                        const result = data.result, report = result.report, requestedScope = report.requestedScope;
                        if (trackIds ? !requestedScope || typeof requestedScope !== 'object' || Array.isArray(requestedScope) || Object.keys(requestedScope).length !== 1 ||
                            !Array.isArray(requestedScope.trackIds) || requestedScope.trackIds.length !== trackIds.length || requestedScope.trackIds.some((id: unknown, i: number) => id !== trackIds[i]) : requestedScope !== 'all-tracks') throw new Error('scope');
                        if (report.schema !== 'score-converter-report/0' || report.adapter !== 'alphatab-1.8.4-022a45c8+source-hook/1' || typeof report.profile !== 'string' || !Array.isArray(report.findings)) throw new Error('report-shape');
                        if (!result.ok) {
                            if (Object.keys(result).some(key => !['ok', 'report'].includes(key)) || report.convertedParts !== undefined) throw new Error('failure-shape');
                        } else if (operation === 'inspect') {
                            if (!Array.isArray(result.tracks) || Object.keys(result).some(key => !['ok', 'report', 'tracks'].includes(key)) || report.convertedParts !== undefined) throw new Error('inventory-shape');
                        } else if (typeof result.musicxml !== 'string' || !Array.isArray(report.convertedParts) ||
                            !result.score || !Array.isArray(result.score.parts) || !Array.isArray(result.occurrences) || !Array.isArray(result.containerSource) ||
                            !result.inputSource || result.inputSource.bytes !== inputBytes || result.inputSource.sha256 !== inputSha256 || typeof result.inputSource.dataBase64 !== 'string' ||
                            Object.keys(result).some(key => !['ok', 'report', 'musicxml', 'score', 'occurrences', 'containerSource', 'inputSource', 'source', 'binarySource', 'gpxSource'].includes(key)) ||
                            ['source', 'binarySource', 'gpxSource'].some(key => result[key] !== undefined && (!result[key] || typeof result[key] !== 'object' || Array.isArray(result[key])))) throw new Error('conversion-shape');
                        finish(data.result);
                    } catch { finish(failure('worker-identity', 'Worker response does not match the bounded immutable request/result contract.')); }
                };
                worker.onerror = event => { event.preventDefault(); finish(failure('worker-runtime', 'Local module Worker failed; no musical output is admitted.')); };
                worker.onmessageerror = () => finish(failure('worker-message', 'Worker result could not be received; no musical output is admitted.'));
                worker.postMessage({ protocol, requestId, operation, inputSha256, bytes: input, ...(trackIds ? { trackIds } : {}) }, [input.buffer]);
            } catch (error) { if (inputSha256) finish(failure('worker-runtime', 'Local module Worker could not start; no musical output is admitted.')); else finish(undefined, error); }
        })();
    });
}

import { convertPortable } from '../adapters/guitar-pro/convert-core.js';
import { inspectPortable } from '../adapters/guitar-pro/inspect-core.js';
import { guitarProEncoding } from '../adapters/guitar-pro/encoding.js';
import { readWebViewContainer } from '../adapters/guitar-pro/zip-webview.js';
import { sha256, type Bytes } from '../adapters/guitar-pro/bytes.js';
import { limits } from '../adapters/guitar-pro/limits.js';
import { jsonBytes } from '../adapters/guitar-pro/work-budgets.js';
import { protocol, hostFailure, type Request, type Result } from './protocol.js';

// Dedicated to one request. No Node/native adapter or UI synchronous entry is exported.
const scope = globalThis as unknown as { onmessage: ((event: MessageEvent) => void) | null; postMessage(value: unknown): void; close(): void };
let received = false, invalidated = false;
scope.onmessage = async ({ data }: MessageEvent) => {
    if (received) { invalidated = true; scope.close(); return; }
    received = true;
    if (!data || data.protocol !== protocol || !Number.isSafeInteger(data.requestId) || data.requestId < 1 || !['convert', 'inspect'].includes(data.operation) ||
        !(data.bytes instanceof Uint8Array) || !(data.bytes.buffer instanceof ArrayBuffer) || data.bytes.byteOffset !== 0 || data.bytes.buffer.byteLength !== data.bytes.byteLength || data.bytes.byteLength > limits.inputBytes || !/^[a-f0-9]{64}$/.test(data.inputSha256) ||
        Object.keys(data).some(key => !['protocol', 'requestId', 'operation', 'inputSha256', 'bytes', 'trackIds'].includes(key)) ||
        data.trackIds !== undefined && (data.operation !== 'convert' || !Array.isArray(data.trackIds) || !data.trackIds.length || data.trackIds.length > limits.tracks || data.trackIds.some((id: unknown) => typeof id !== 'string' || !/^\d{1,6}$/.test(id)))) {
        scope.close(); return; // An unbound request never gets useful inventory, source or XML.
    }
    const request = data as Request, deadline = performance.now() + limits.workerMs;
    const digest = sha256(request.bytes);
    if (digest !== request.inputSha256) { scope.close(); return; }
    let members: Map<string, Bytes> | undefined, decodeError: unknown;
    if (guitarProEncoding(request.bytes) === 'zip') {
        try { members = await readWebViewContainer(request.bytes, deadline); }
        catch (error) { decodeError = error; }
    }
    // Native stream promises may drain entirely through microtasks. Give queued duplicate
    // message tasks a turn before source recovery and before publishing useful output.
    await new Promise(resolve => setTimeout(resolve, 0));
    if (invalidated) return;
    const container = () => { if (decodeError) throw decodeError; return members!; };
    let result: Result = (request.operation === 'inspect' ? inspectPortable(request.bytes, container) : convertPortable(request.bytes, { trackIds: request.trackIds }, container)) as Result;
    if (performance.now() >= deadline) result = hostFailure(request.operation, digest, request.trackIds, 'work-budget', 'Worker exceeded 5 seconds; no musical output is admitted.');
    try { jsonBytes(result, request.operation === 'inspect' ? limits.reportBytes : limits.resultBytes); }
    catch { result = hostFailure(request.operation, digest, request.trackIds, 'message-budget', 'Worker result exceeds its public message budget; no output is admitted.'); }
    await new Promise(resolve => setTimeout(resolve, 0));
    if (!invalidated) scope.postMessage({ protocol, requestId: request.requestId, operation: request.operation, result });
    scope.close();
};

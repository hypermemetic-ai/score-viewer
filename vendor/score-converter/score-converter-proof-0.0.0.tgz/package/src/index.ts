import { Worker } from 'node:worker_threads';
import { createHash } from 'node:crypto';
import { freeze } from './core/report.js';
import { limits } from './adapters/guitar-pro/limits.js';
import { inputView, snapshotInput, snapshotTrackIds } from './guitar-pro-input.js';
import type { ConversionResult as InternalConversionResult } from './adapters/guitar-pro/convert.js';
import type { InspectionResult } from './adapters/guitar-pro/inspect.js';
export type * from './guitar-pro-contract.js';
import type { ConversionResult, GuitarProOptions, GuitarProInspectionOptions } from './guitar-pro-contract.js';

let sequence = 0;
const cancellationReason = (signal: AbortSignal): unknown => { const reason = signal.reason; return reason === undefined ? new Error('Conversion cancelled.') : reason; };

/** One local worker per caller invocation. The caller owns concurrency. No filesystem/network score access. */
export async function convertGuitarPro(bytes: Uint8Array, options: GuitarProOptions = {}): Promise<ConversionResult> {
    return runGuitarPro<ConversionResult>('convert', bytes, options);
}
/** Metadata-only inventory; conversion independently admits each selected musical graph. */
export async function inspectGuitarPro(bytes: Uint8Array, options: GuitarProInspectionOptions = {}): Promise<InspectionResult> {
    return runGuitarPro<InspectionResult>('inspect', bytes, options);
}
async function runGuitarPro<T extends InternalConversionResult | InspectionResult>(operation: 'convert' | 'inspect', bytes: Uint8Array, options: GuitarProOptions): Promise<T> {
    if (!options || typeof options !== 'object' || Array.isArray(options)) throw new TypeError('Expected a conversion options object.');
    const signal = options.signal, requestedTrackIds = options.trackIds;
    if (operation === 'inspect' && requestedTrackIds !== undefined) throw new TypeError('Inspection discovers source tracks; selection belongs to conversion.');
    if (signal !== undefined && (!signal || typeof signal.aborted !== 'boolean' || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) throw new TypeError('Expected an AbortSignal.');
    if (signal?.aborted) throw cancellationReason(signal);
    const view = inputView(bytes), trackIds = snapshotTrackIds(requestedTrackIds);
    // Copy exactly the caller's view before yielding; subsequent caller mutations cannot change source identity.
    const input = snapshotInput(view);
    const inputSha256 = createHash('sha256').update(input).digest('hex');
    const failure = (code: string, message: string): T => freeze({ ok: false, report: {
        schema: 'score-converter-report/0', inputSha256, adapter: 'alphatab-1.8.4-022a45c8+source-hook/1',
        profile: operation === 'inspect' ? 'gp-family-inventory/0' : 'gp-family-fretted/0', requestedScope: trackIds ? { trackIds } : 'all-tracks', findings: [{ disposition: 'blocking', code, message, location: { member: 'input' } }]
    } } as T);
    const requestId = ++sequence;
    const worker = new Worker(new URL('./worker.js', import.meta.url), { workerData: { bytes: input, trackIds, operation, requestId },
        execArgv: [], // Compiled reader needs no parent eval/test/V8 or preload flags.
        resourceLimits: { maxOldGenerationSizeMb: limits.workerHeapMb, maxYoungGenerationSizeMb: 16, stackSizeMb: 4 } });
    return new Promise((resolve, reject) => {
        let done = false;
        const finish = async (result?: T, error?: unknown) => {
            if (done) return;
            done = true; clearTimeout(timer); signal?.removeEventListener('abort', abort);
            await worker.terminate();
            if (error !== undefined) reject(error); else resolve(freeze(result!));
        };
        const abort = () => { void finish(undefined, cancellationReason(signal!)); };
        const timer = setTimeout(() => { void finish(failure('work-budget', 'Worker exceeded 5 seconds; no musical output is admitted.')); }, limits.workerMs);
        signal?.addEventListener('abort', abort, { once: true });
        if (signal?.aborted) { abort(); return; }
        worker.once('message', response => {
            if (response?.requestId !== requestId || response?.operation !== operation || response?.result?.report?.inputSha256 !== inputSha256) void finish(failure('worker-identity', 'Worker response does not match the immutable input request.'));
            else void finish(response.result as T);
        });
        worker.once('error', () => { void finish(failure('worker-budget', 'Worker failed or exceeded memory limits; no musical output is admitted.')); });
        worker.once('exit', () => { if (!done) void finish(failure('worker-exit', 'Worker exited before delivering a result.')); });
    });
}

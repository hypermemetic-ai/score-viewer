import type { Rational } from './rational.js';
import type { Location } from './report.js';
export interface Pitch { step: string; alter: number; octave: number; midi: number; origin: 'source' | 'inferred' }
export interface NoteFact {
    source: Location; id: string; string: number; fret: number;
    kind: 'pitched' | 'dead';
    sounding: Pitch | null; written: Pitch;
    /** For dead notes, written is display guidance and sounding is deliberately null. */
    referenceSounding?: Pitch;
    tieStart: boolean; tieStop: boolean;
    hopoStart?: 'hammer-on' | 'pull-off'; hopoStop?: 'hammer-on' | 'pull-off'; hopoNumber?: number;
    sourceHopoOrigin?: boolean; sourceHopoDestination?: boolean;
}
export interface Event {
    source: Location; id: string; start: Rational; duration: Rational;
    type: string; dots: number; tuplet?: { actual: number; normal: number };
    notes: NoteFact[]; fullMeasureRest: boolean; text?: string; dynamic?: string;
}
export interface Measure {
    source: Location; time: { beats: number; unit: number }; key: { fifths: number; mode: string };
    clef: string; pickup: boolean; duration: Rational; voices: Event[][];
    repeatStart: boolean; repeatEnd: number;
}
export interface Tempo {
    source: Location; measure: number; position: Rational; rate: string; reference: number;
    unit: string; dots: number; quarterRate: number; visible: boolean;
}
export interface Part {
    source: Location; id: string; name: string; instrument: string; midiProgram: number;
    tuning: number[]; transposeOctaves: number; measures: Measure[];
}
export interface NeutralScore { title: string; parts: Part[]; tempos: Tempo[] }

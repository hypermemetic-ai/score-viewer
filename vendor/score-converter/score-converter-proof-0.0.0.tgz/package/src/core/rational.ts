import { refuse } from './report.js';
export interface Rational { n: number; d: number }
export function gcd(a: number, b: number): number {
    while (b) [a, b] = [b, a % b];
    return Math.abs(a);
}
export function q(n: number, d = 1): Rational {
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d) || d <= 0 || Math.abs(n) > 1e12 || d > 1e9)
        refuse('clock-budget', 'Exact rational arithmetic exceeds the proving profile budget.');
    const g = gcd(n, d);
    return { n: n / g, d: d / g };
}
export const add = (a: Rational, b: Rational): Rational => q(a.n * b.d + b.n * a.d, a.d * b.d);
export const mul = (a: Rational, b: Rational): Rational => q(a.n * b.n, a.d * b.d);
export const equal = (a: Rational, b: Rational): boolean => a.n * b.d === b.n * a.d;
export function decimal(s: string): Rational {
    if (!/^\d{1,4}(?:\.\d{1,6})?$/.test(s)) refuse('number', 'Expected a bounded nonnegative decimal.');
    const [whole, fraction = ''] = s.split('.');
    return q(Number(whole + fraction), 10 ** fraction.length);
}
export function divisions(clocks: Rational[]): number {
    let d = 1;
    for (const c of clocks) {
        d = d / gcd(d, c.d) * c.d;
        if (d > 65536) refuse('divisions-budget', 'Exact MusicXML divisions exceed 65536; timing will not be rounded.');
    }
    return d;
}

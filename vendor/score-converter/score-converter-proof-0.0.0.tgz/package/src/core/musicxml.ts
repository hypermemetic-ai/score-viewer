import type { NeutralScore, Pitch } from './model.js';
import { divisions, type Rational } from './rational.js';
import { refuse } from './report.js';
const esc = (s: string) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
const tag = (name: string, value: string | number) => `<${name}>${esc(String(value))}</${name}>`;
function pitchXml(p: Pitch): string { return tag('step', p.step) + (p.alter ? tag('alter', p.alter) : '') + tag('octave', p.octave); }
/** Source tuning supplies MIDI pitches, not spelling; use a reported sharp reference spelling. */
function tuningXml(midi: number): string {
    const [step, alter] = ([['C', 0], ['C', 1], ['D', 0], ['D', 1], ['E', 0], ['F', 0],
        ['F', 1], ['G', 0], ['G', 1], ['A', 0], ['A', 1], ['B', 0]] as const)[midi % 12];
    return tag('tuning-step', step) + (alter ? tag('tuning-alter', alter) : '') + tag('tuning-octave', Math.floor(midi / 12) - 1);
}
/** Plain MusicXML 4.0 partwise; no mandatory private musical elements. */
export function writeMusicXml(score: NeutralScore, display = { hideDynamics: false, hideTempo: false }, onPartAssigned?: (sourcePartId: string, musicxmlPartId: string) => void, writerLimits?: { outputBytes: number }): string {
    const partIds = score.parts.map((part, i) => { const id = `P${i + 1}`; onPartAssigned?.(part.id, id); return id; });
    const clocks: Rational[] = [];
    for (const p of score.parts) for (const m of p.measures) {
        clocks.push(m.duration);
        for (const v of m.voices) for (const e of v) clocks.push(e.start, e.duration);
    }
    for (const t of score.tempos) clocks.push(t.position);
    const d = divisions(clocks);
    const ticks = (r: Rational) => {
        const n = r.n * d / r.d;
        if (!Number.isSafeInteger(n)) refuse('writer-clock', 'Unable to represent exact clock in MusicXML.');
        return n;
    };
    let out = '', outputBytes = 0;
    const emit = (value: string) => {
        if (writerLimits) {
            let bytes = value.length;
            for (let i = 0; i < value.length; i++) {
                const c = value.charCodeAt(i);
                if (c >= 0xd800 && c <= 0xdbff && i + 1 < value.length && value.charCodeAt(i + 1) >= 0xdc00 && value.charCodeAt(i + 1) <= 0xdfff) { bytes += 2; i++; }
                else if (c >= 0x800) bytes += 2; else if (c >= 0x80) bytes++;
            }
            outputBytes += bytes;
            if (outputBytes > writerLimits.outputBytes) refuse('writer-output-size', 'MusicXML output exceeds the adapter byte budget; no output admitted.');
        }
        out += value;
    };
    emit('<?xml version="1.0" encoding="utf-8"?>\n<score-partwise version="4.0">');
    emit(`<work>${tag('work-title', score.title)}</work><identification><encoding><software>score-converter proving slice</software></encoding></identification><part-list>`);
    for (let i = 0; i < score.parts.length; i++) {
        const p = score.parts[i];
        emit(`<score-part id="${partIds[i]}">${tag('part-name', p.name)}<score-instrument id="I${i + 1}">${tag('instrument-name', p.instrument)}</score-instrument><midi-instrument id="I${i + 1}">${tag('midi-program', p.midiProgram + 1)}</midi-instrument></score-part>`);
    }
    emit('</part-list>');
    for (let pi = 0; pi < score.parts.length; pi++) {
        const p = score.parts[pi];
        emit(`<part id="${partIds[pi]}">`);
        for (let mi = 0; mi < p.measures.length; mi++) {
            const m = p.measures[mi];
            emit(`<measure number="${mi + 1}"${m.pickup ? ' implicit="yes"' : ''}><attributes>${tag('divisions', d)}<key>${tag('fifths', m.key.fifths)}${tag('mode', m.key.mode)}</key><time>${tag('beats', m.time.beats)}${tag('beat-type', m.time.unit)}</time>`);
            const [sign, line] = ({ G2: ['G', 2], F4: ['F', 4], C3: ['C', 3], C4: ['C', 4] } as const)[m.clef as 'G2' | 'F4' | 'C3' | 'C4'];
            if (mi === 0) emit(tag('staves', 2));
            emit(`<clef number="1">${tag('sign', sign)}${tag('line', line)}</clef>`);
            if (mi === 0) {
                // An empty, nonprinting alternate TAB staff carries complete physical tuning.
                // Source notes occur only on staff 1; this is not a source staff or retuning mark.
                emit('<clef number="2" print-object="no"><sign>TAB</sign></clef>');
                emit(`<staff-details number="2" print-object="no" print-spacing="no"><staff-type>alternate</staff-type>${tag('staff-lines', p.tuning.length)}`);
                for (let i = 0; i < p.tuning.length; i++) emit(`<staff-tuning line="${i + 1}">${tuningXml(p.tuning[i])}</staff-tuning>`);
                emit('</staff-details>');
                if (p.transposeOctaves) emit(`<transpose>${tag('diatonic', 0)}${tag('chromatic', 0)}${tag('octave-change', p.transposeOctaves)}</transpose>`);
            }
            emit('</attributes>');
            if (m.repeatStart) emit('<barline location="left"><repeat direction="forward"/></barline>');
            for (const tempo of score.tempos.filter(t => t.measure === mi)) {
                emit(`<direction><direction-type><metronome${tempo.visible && !display.hideTempo ? '' : ' print-object="no"'}>${tag('beat-unit', tempo.unit)}${'<beat-unit-dot/>'.repeat(tempo.dots)}${tag('per-minute', tempo.rate)}</metronome></direction-type><offset sound="yes">${ticks(tempo.position)}</offset><staff>1</staff><sound tempo="${tempo.quarterRate}"/></direction>`);
            }
            let wroteVoice = false;
            for (let vi = 0; vi < m.voices.length; vi++) {
                if (!m.voices[vi].length) continue;
                if (wroteVoice) emit(`<backup>${tag('duration', ticks(m.duration))}</backup>`);
                wroteVoice = true;
                for (const e of m.voices[vi]) {
                    if (e.dynamic && !display.hideDynamics) emit(`<direction><direction-type><dynamics><${e.dynamic.toLowerCase()}/></dynamics></direction-type>${tag('voice', vi + 1)}<staff>1</staff></direction>`);
                    if (e.text) emit(`<direction><direction-type>${tag('words', e.text)}</direction-type>${tag('voice', vi + 1)}<staff>1</staff></direction>`);
                    const notes = e.notes.length ? e.notes : [undefined];
                    for (let ni = 0; ni < notes.length; ni++) {
                        const n = notes[ni];
                        emit('<note>' + (ni ? '<chord/>' : ''));
                        emit(n ? (n.kind === 'dead' ? `<unpitched>${tag('display-step', n.written.step)}${tag('display-octave', n.written.octave)}</unpitched>` : `<pitch>${pitchXml(n.written)}</pitch>`) : `<rest${e.fullMeasureRest ? ' measure="yes"' : ''}/>`);
                        emit(tag('duration', ticks(e.duration)));
                        if (n?.tieStop) emit('<tie type="stop"/>');
                        if (n?.tieStart) emit('<tie type="start"/>');
                        emit(tag('voice', vi + 1) + tag('type', e.type) + '<dot/>'.repeat(e.dots));
                        if (e.tuplet) emit(`<time-modification>${tag('actual-notes', e.tuplet.actual)}${tag('normal-notes', e.tuplet.normal)}</time-modification>`);
                        if (n?.kind === 'dead') emit('<notehead>x</notehead>');
                        emit('<staff>1</staff>');
                        if (e.dynamic && display.hideDynamics && ni === 0) emit(`<notations print-object="no"><dynamics><${e.dynamic.toLowerCase()}/></dynamics></notations>`);
                        if (n) {
                            if (n.tieStop || n.tieStart || n.hopoStart || n.hopoStop) {
                                emit('<notations>');
                                if (n.tieStop) emit('<tied type="stop"/>');
                                if (n.tieStart) emit('<tied type="start"/>');
                                if (n.hopoStop) emit(`<slur type="stop" number="${n.hopoNumber}"/>`);
                                if (n.hopoStart) emit(`<slur type="start" number="${n.hopoNumber}"/>`);
                                if (n.hopoStart || n.hopoStop) {
                                    emit('<technical>');
                                    if (n.hopoStop) emit(`<${n.hopoStop} type="stop" number="${n.hopoNumber}"/>`);
                                    if (n.hopoStart) emit(`<${n.hopoStart} type="start" number="${n.hopoNumber}">${n.hopoStart === 'hammer-on' ? 'H' : 'P'}</${n.hopoStart}>`);
                                    emit('</technical>');
                                }
                                emit('</notations>');
                            }
                            emit(`<notations print-object="no"><technical>${tag('string', n.string)}${tag('fret', n.fret)}${n.kind === 'dead' ? '<other-technical>dead note</other-technical>' : ''}</technical></notations>`);
                        }
                        emit('</note>');
                    }
                }
            }
            if (m.repeatEnd) emit(`<barline location="right"><repeat direction="backward" times="${m.repeatEnd}"/></barline>`);
            emit('</measure>');
        }
        emit('</part>');
    }
    emit('</score-partwise>\n');
    return out;
}

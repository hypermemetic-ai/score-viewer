export interface Location {
    member: string;
    path?: string;
    line?: number;
    column?: number;
    id?: string;
    trackId?: string;
    measure?: number;
    voice?: number;
    beat?: number;
    byteOffset?: number;
    byteLength?: number;
}
export interface Finding {
    disposition: 'preserved' | 'inferred' | 'omitted' | 'excluded-by-scope' | 'blocking';
    code: string;
    message: string;
    location: Location;
    fact?: unknown;
}
export class Refusal extends Error {
    constructor(readonly code: string, message: string, readonly location: Location = { member: 'input' }) {
        super(message);
    }
}
export const refuse = (code: string, message: string, location?: Location): never => {
    throw new Refusal(code, message, location);
};
export function freeze<T>(value: T): T {
    if (value && typeof value === 'object' && !Object.isFrozen(value)) {
        Object.freeze(value);
        for (const item of Object.values(value)) freeze(item);
    }
    return value;
}

# Initial roadmap

Status: initial sequencing, 2026-10-07, reconciled with authorized consumer work on 2026-10-08. The initial repository seed implemented phase zero; the [reader proof](guitar-pro-proof.md) now exercises original Guitar Pro profiles and an authorized GP8 bass scope. Common pitched/unpitched ISO/Viewer model replacement and shared bass engraving are approved and have draft source implementations. The [consumer handoff](bass-display-handoff.md) records remaining visual/admission gates; general adapter coverage and independent notation-app audio acceptance remain separate increments. This is not a queued deployment or repository-split operation.

## Phase zero — retain the project direction

- Create the private independent repository under `hypermemetic-ai`.
- Carry over decisions, architecture, candidate formats, native feasibility and licensing constraints.
- Pin the code-audited ISO baseline and identify useful foundations without moving code.
- Deliver a reviewable documentation PR.

No implementation language, dependency, product license, API, OpenSpec setup or release workflow is selected merely to finish this phase.

## Guitar Pro milestone proposed 2026-10-08

The user's local-file bass use case motivates a concrete [Guitar Pro proving plan](research/guitar-pro.md), proposed ahead of the earlier MusicXML/MIDI comparison. MusicXML 4.0 remains the output contract; changing the proposed input sequence does not require ISO extraction or consumer changes.

1. Confirm an authorized representative file's version, or start with original GP7 miniatures while that file is unavailable.
2. Evaluate an in-repository alphaTab 1.8.4 reader/model source component: prove its dependency closure and narrow entry/settings, then bounded container/XML intake and source capture before normalization. Select runtime/dependencies only in the implementation task.
3. Prove raw source identities, tuning/string/fret, written/sounding pitch, exact clocks, voices, written ties, beams/phrasing, repeats and original tempo units against normalized reader data.
4. Implement and validate a narrow plain MusicXML writer and located omission/refusal report. Techniques must retain their meaning or block affected scope.
5. Exercise original fixtures, malformed inputs and independent notation-app interpretation; deliver the coverage and dependency findings before deciding adoption and further versions/MXL packaging.

Implementation normally runs in a child agent after its scope is agreed, with decisions and follow-up here. The private bass-only conversion has passed schema and independent source-to-output checks; see the proof contract for scope and omissions. Subsequent common ISO/Viewer model and engraving work is authorized in those repositories. Bass fingering, catalog publication and public release remain outside that scope. This document schedules no automatic work and selects no shipping reader.

## Phase one — define a bounded MusicXML contract

Choose an implementation design around the simplest useful structured route:

1. Define source identity, recovered facts, conversion decisions and report/result boundaries.
2. Identify the initial MusicXML input version/construct profile, including plain partwise/timewise forms and MXL container behavior. These can be delivered in named increments rather than claiming universal coverage.
3. Define standard MusicXML 4.0 output conventions and validation scope. Plain `.musicxml` and compressed `.mxl` are the intended interchange deliverables; no private extension is needed to interpret the music.
4. Separate the existing private-PDF intake from a reusable converter boundary. Preserve provenance/correction principles without making every structured source require a PDF or ISO renderer.
5. Choose implementation/runtime and dependencies after technical and rights screening.

The concrete profile should include representative supported facts and one intentional unsupported/uncertain case so the report is meaningful. Do not write a promise of full MusicXML coverage before those constructs are implemented and exercised.

## Phase two — prove rich and sparse routes

Proposed first comparison: a rights-cleared miniature or short score exported both as MusicXML and MIDI. Its source/export permissions and producer version must be known. Existing paid/private scores are not a default repository fixture.

MusicXML proves faithful structured recovery and standard output. MIDI proves useful inferred notation with honest limitations. Check preserved facts, inferred choices, omissions, output validity and human correction effort using the same musical reference where meaningful.

Include exact pitches/register, rational clocks, written values versus sounding spans, independent voices, ties/slurs and source fingers when present. The first slice may have a narrow musical vocabulary; identify its boundary explicitly.

A successful proving slice produces:

- A valid, independently readable MusicXML result.
- A report locating omissions, uncertainty and inferred/editorial decisions.
- Focused semantic regression coverage and a comparison in a real notation application when available.
- Clear cancellation/failure behavior without half-installing an output.
- Exact dependency/license inventory for anything proposed to ship.

Schema validity, a matching MIDI performance and readable engraving are separate checks. None alone proves faithful written notation.

## Phase three — integrate consumers without merging products

The viewer Import path can compose:

```text
pick input
    → converter
    → MusicXML + report
    → ISO score preparation
    → musical admission + optional physical capabilities
    → review or install .tuna
```

The consuming viewer needs actionable decisions and clear limitations, not backend status dumps. Common pitched/unpitched admission and shared engraving now have an approved implementation scope; see the handoff for source checkpoints. Keep personal fingers and source/calculated layers distinct. An unavailable fingering result must not silently produce an apparently complete piano score in our viewer. Non-piano musical admission must not invent hands or grant piano physical capabilities.

Human review can use the ISO engraving rig through a frontend that depends on both products. Keep ISO notation-specific editorial/geometry work downstream. Another customer should be able to use the converter with a different renderer and no TUNA dependency.

Extract shared TUNA publication and other viewer-owned library contracts before moving the viewer repository. That migration is a separate project from implementing this converter and must preserve working builds and saved user state.

## Phase four — add adapters from evidence

After the first slice, rank candidates by musical coverage, user benefit, correction effort, implementation effort, deployment fit and compatible rights. Possibilities include native MuseScore, MEI, ABC, Humdrum, Guitar Pro and MUSX when its exact dependency/data rights are cleared. A list of candidates is not an order already selected.

For `.sib`/`.dorico`, first authorize the [miniature feasibility experiment](research/native-sib-dorico.md) and establish note/timing decoding or an appropriately licensed host/service route. Metadata/container discovery does not qualify as musical support.

For LilyPond, support only an explicit static subset if that route proves useful. Never run acquired Scheme or compile imported sources to avoid implementing a reader.

## Phase five — graphical recovery and later intelligent decisions

Generated PDFs precede scans. Evaluate graphical reconstruction/OMR using [the retained research criteria](research/digital-pdf-scans.md), with exact model/tool/data terms and measured correction effort.

Only add model/agent decisions when deterministic processing and ordinary user decisions demonstrate a concrete gap. Make their changes inspectable and source-bound; retain uncertainty and review authority. A generic autonomous orchestrator is not a prerequisite for starting.

## Product milestones to decide separately

- Final source-available/commercial license and contribution rights.
- Commercial eligibility, business-size measurement and permissible conversion/hosting/OEM uses.
- Public source publication, documentation license and distribution.
- Platform packaging and release responsibilities for reusable libraries versus consuming applications.
- Per-adapter support claims and maintenance/version compatibility commitments.

The current seed has no scheduled release or commitment that all candidate formats will ship.

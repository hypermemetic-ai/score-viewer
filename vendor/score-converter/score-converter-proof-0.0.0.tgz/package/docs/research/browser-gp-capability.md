# Portable GP capability probe

This is an engine investigation, not an accepted browser conversion SDK. The existing Node API remains the product conversion host. The GP byte/hash/XML/container core is separated from its Node worker and ZIP-inflation host so the musical reader and ordinary MusicXML output can be reused without importing Node runtime modules.

The receiving Viewer uses local ES-module workers inside Windows WebView2 and Mac WKWebView. Actual tests in both receiving engines remain required. Linux Chromium results do not establish either receiving engine's acceptance. Android and iPad are possible future consumers, not tested targets here.

## Reproduce

Run `npm run build`, then serve these local assets under one origin:

- [probe worker](../../scripts/research/browser-inflate-probe.worker.mjs)
- [portable byte/hash helper](../../src/adapters/guitar-pro/bytes.ts), compiled as `dist/src/adapters/guitar-pro/bytes.js`
- [original vector module](../../test/fixtures/browser-inflate-cases.mjs), reproducible with [the generator](../../scripts/research/generate-browser-inflate-cases.mjs)

The [local host function](../../scripts/research/browser-inflate-probe.mjs) imports the fixed vectors as an ES module and starts a module Worker through a relative URL, with request/case validation, deadline and abort/error termination. It needs no fetch, remote code or CSP change. The [artifact packer](../../scripts/research/package-browser-capability.mjs) emits a self-contained archive outside the repository, with direct import instructions and exact source/runtime digests; its historical v3 handoff is capability evidence, not the Node package.

Send `{ requestId: 1, cases }` to a fresh module Worker. Require the same request ID and exactly one result for each vector. Terminate the Worker after completion, error, cancellation or a five-second deadline. The probe's vectors are fixed local study data; this is not a public arbitrary-payload decoder API.

An optional [self-cleaning runner](../../scripts/research/run-browser-inflate-probe.mjs) uses an already installed Chromium executable, a temporary profile and a loopback server. It requires `CHROME_BINARY`; it installs nothing. Run it through `qq-job`. Its twenty-second overall deadline covers browser/CDP/page startup and completion. The runner closes pending requests, its browser and server and removes its temporary profile.

## What the probe establishes

The probe requests native `DecompressionStream('deflate-raw')`. It permits one compressed write at a time, with at most sixteen bytes per write, while a concurrent read task drains emitted output. It records input progress, observed read counts and writable desired-size signals at every write boundary. Readable and native decoder queues remain opaque: these observations do **not** prove queue emptiness before each following write.

Useful output requires successful write/close **and** complete read/flush. The actual cumulative emitted count is checked before retaining each output piece; final decoded size, independently encoded CRC and SHA-256 must match. Errors and the active-cancellation vector cancel/abort and settle both tasks. The over-budget declared-size case starts no decoder. Error settlement and the caller's worker termination are separate responsibilities.

The [WHATWG Compression Streams specification](https://compression.spec.whatwg.org/#supported-formats) requires rejection of nonconforming raw DEFLATE and additional input after its final block. Engine behavior is exercised directly; a complete decoded prefix alone is insufficient to accept a truncated input.

Linux Chromium 151 passed the original successful, empty, malformed-block, truncated, trailing-input, incorrect-CRC, short/long declared-size, misdeclared-expansion and pre-allocation-size cases. Truncation rejected at close even after all 4,096 expected bytes had been emitted; trailing input rejected during write. With sixteen-byte compressed writes, the largest observed successful emitted piece was 6,708 bytes in the 63,488-byte repeated-text case. These are observations, not universal decoder-allocation limits.

The earlier eleven-case sampled whole-browser process-tree PSS increased from approximately 297 MB at `about:blank` to 348 MB across navigation, module-worker startup and trials. Summed RSS increased from approximately 914 MB to 1.16 GB and counts shared pages repeatedly; page heap was approximately 0.77 MB. The updated twelve-case run also exercised active cancellation after one compressed write and host termination; all cases passed, with PSS approximately 300→349 MB and page heap approximately 0.90 MB. Samples every 25 ms can miss peaks, and page heap excludes Worker/native-engine allocations. Startup, browser processes and shared pages dominate these measurements; they do not isolate decoder cost.

## Remaining safety and delivery decision

A browser Worker provides termination and a five-second deadline, but no configurable V8 heap cap. The native decompressor exposes no absolute output-allocation ceiling. Post-read limits constrain retained output, not allocations already made by the engine. Small writes and the observed emitted chunks do not by themselves establish a hard native allocation bound for adversarial DEFLATE. A forged declared size must therefore remain part of the resource review.

No additional DEFLATE token parser, runtime codec dependency or native helper is selected. Compare native streaming, the receiver's exact locked `fflate` 0.8.3 and a bounded native decoder before claiming full cross-platform acceptance. A future private SDK needs a Node-free bundle closure, source/tree/archive digests, concrete covered-source/MPL notices, input snapshots, bounded messages/captures, deterministic admission/report/output, selection and active cancellation tests, and actual receiving-engine musical tests. This small capability artifact satisfies none of those release gates by implication.

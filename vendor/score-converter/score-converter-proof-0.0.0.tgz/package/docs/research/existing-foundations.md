# Existing ISO code foundations

This is a read-only code audit at ISO revision **`3e8f0f9af93cf4231ebda230045a6d85a0fd0953`**, carried over on 2026-10-07. Later main revisions may differ. The source remains in [hypermemetic-ai/iso-notation](https://github.com/hypermemetic-ai/iso-notation); **no code is moved or copied by this seed**. Repository links are private and require existing organization access.

Source paths below are historical extraction anchors, not dependencies installed in this repository. The separate live/released applications and private score inputs are unchanged.

## Bounded MusicXML intake

The existing shared modules are [`src/import/musicxml/`](https://github.com/hypermemetic-ai/iso-notation/tree/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/src/import/musicxml), with a CLI in [`scripts/import-musicxml.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/scripts/import-musicxml.ts).

| Existing behavior | Important limit |
| --- | --- |
| Exact rational written clocks; explicit pitch spelling/register, parts, staff/voice/chord identities | Not a complete MusicXML reader |
| Written values/dots, sounding ties versus written ties, numbered beams and measure rests | Enumerated written durations; unsupported duration/type/dot combinations fail |
| Words, simple metronome directions, selected dynamics and octave-shift facts | No general hairpin/ornament/expression support; dotted metronome units rejected by this reader |
| Source slurs and explicit pedal start/stop/change marks | Pedal lines and most other notations are outside the subset |
| One explicit unnested repeat and derived performed occurrences | Nested/multiple repeats, endings/jumps and crossing-repeat continuation/state cases need separate interpretation |
| XML locations, source digests, correction records and optional MIDI cross-check | Source retention is not whole-score fidelity certification |
| Explicit part/staff-to-hand projection policy | Staff/voice is retained separately; mapping to a hand is editorial policy, not a composer fact |

The input reader accepts **uncompressed `score-partwise` only**. Timewise/MXL wrappers are not implemented. Its note/notation whitelist excludes grace notes, time-modification/tuplets, printed fingering/technical marks, articulations, fermatas, ornaments and arpeggios. Its attribute handling does not establish transposing-instrument support. A source feature outside the bounded vocabulary currently fails rather than becoming a partial conversion report.

[`private-intake.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/src/import/musicxml/private-intake.ts) requires a private manifest with pinned PDF and XML inputs, optional MIDI, evidence-bearing corrections and hand policies. Inputs must stay outside the checkout. It imports Node filesystem/path/crypto; the parser also uses Node crypto. This is useful provenance machinery for the previous score-intake workflow, **not a neutral viewer-callable product API**.

[`project.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/src/import/musicxml/project.ts) projects directly into ISO's `QuantizedGridScore`, using its pitch/model rules and a fixed quarter-note grid for supported material. The independent converter needs a boundary that can export richer MusicXML without requiring that ISO projection. A structured import must not require the user to supply a PDF simply because the historical private intake did.

Older prose in `docs/musicxml-intake.md` predates supported slur/pedal/repeat work. Use exact source and focused tests as implementation evidence instead of carrying forward an obsolete blanket rejection claim.

## Importer gaps are not automatically notation gaps

[`src/model/types.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/src/model/types.ts) already includes a `GraceGroup` model with members, host ownership, written values and source location, plus `QuantizedGridScore.graceGroups`. The real engine contains grace layout and bounding/crop machinery in [`src/render/janko/engine.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/src/render/janko/engine.ts).

An articulation enum exists in the model, but a type field is not proof that every articulation is parsed, drawn, played, planned or editable. Likewise, do not claim complete tuplet support from rational clocks alone. Capability inventory must distinguish read → store → render → practice/performance → fingering calculation.

## Legacy MIDI reader

[`src/model/midi.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/src/model/midi.ts) uses `@tonejs/midi` through `parseMidiToScore`.

It is a parsing foundation, not an accepted product-quality notation-inference path:

- Hand choice uses track-name heuristics, two-track ordering, or a one-track middle-C split.
- Only the first time signature is used; absence defaults to 4/4.
- Missing tempo becomes 100 in this legacy function.
- It scales ticks to 48 only when note clocks remain exact; otherwise it retains the input PPQ. It rounds stored note clocks and tempo values.
- It does not reconstruct written spelling/ties/voices/phrases/dynamics/pedal as source facts.

Do not promote these heuristics to truthful source markings or copy their defaults blindly. The converter's MIDI result must identify inferred and missing facts, including a separately chosen working/reference tempo when necessary.

## Viewer readiness and current coupling

The current browser picker accepts `.tuna`/`.isoscore` in [`score-viewer/src/host.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/score-viewer/src/host.ts). [`main.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/score-viewer/src/main.ts) admits packages through `importPackageForReading`; this does not establish an existing structured-format Import button.

[`piano-readiness.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/score-viewer/src/piano-readiness.ts) already coordinates piano planning, source identity/calculation context, rendering and complete editable assignments. It distinguishes ready/editable results from needs-data, unsupported, exhausted, cancelled and conflict states. An explicit reference tempo is part of planning context. Reuse that consumer readiness responsibility instead of making a successful MusicXML export imply a playable piano package.

Current finger choices are `Calculated` and `Yours` in [`state.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/score-viewer/src/state.ts). `Stock` is a newly agreed source-fingering choice, not an existing implemented viewer option at this baseline.

Two extraction issues are especially relevant:

1. [`scripts/export-tuna.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/scripts/export-tuna.ts) imports package/publication code from `score-viewer/src`. Shared TUNA publication must move to the ISO score-tools boundary before a viewer extraction can leave that dependency clean.
2. [`score-viewer/src/package.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/score-viewer/src/package.ts) combines archive admission, planner validators and rendering-recipe checks. Separate the file contract from implementation-specific preparation without weakening existing identity or preservation checks.

The converter must not acquire a dependency on the viewer merely to parse or publish musical information. Viewer state, devices, native packaging and practice progress stay in that application.

## Learning and fingering boundaries

The current learning app's [`interval-engraving.ts`](https://github.com/hypermemetic-ai/iso-notation/blob/3e8f0f9af93cf4231ebda230045a6d85a0fd0953/interval-app/interval-engraving.ts) directly uses ISO model/pitch, engine/style/staff and geometry. It is an independent application and release lifecycle, **not already independent of engraving support**. It does not need to own or consume the entire converter.

The fingering calculator is substantial existing machinery, including instrument/layout models and separate planning strategies. Its eventual extraction should preserve exact musical/source context and versioned results. This seed does not move it or assume that piano planning applies to every instrument.

## What this audit does not establish

There was no build, source test run, conversion trial, migration or new native release for this documentation task. Existing tests are possible extraction references, not newly passing evidence. No private input, source score, generated encoding, installed state, operational receipt or cancelled-study content is copied into this repository.

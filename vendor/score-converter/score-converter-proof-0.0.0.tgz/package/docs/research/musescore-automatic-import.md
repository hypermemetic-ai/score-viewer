# MuseScore automatic-import feasibility

Investigated locally on 2026-10-09. **Automatic native MSCX/MSCZ → MusicXML conversion works with a pinned temporary official MuseScore build on two original miniatures.** This is a bounded research proof, not an implemented converter adapter, dependency admission, native-version coverage promise or downstream Viewer feature. MusicXML is the destination. Existing MusicXML input and consumer handling are outside this converter task.

## Exact tool and runtime

The official [v4.7.5 release](https://github.com/musescore/MuseScore/releases/tag/v4.7.5), published 2026-09-08, supplies `MuseScore-Studio-4.7.5.260831071-x86_64.AppImage`, 194,411,000 bytes. Its advertised and locally verified SHA-256 is `a31b2da2dbcc2191bcc98beb7be5c15f2f517bedb3444def96fe3088b74d3a1e`. The release tag identifies source commit `3654226c2e99289916916953a98e585a3d3b315a`. Executing `--version` returned `MuseScore4 4.7.5`; the generated native score format is `4.70`, distinct from the producing application's version.

The AppImage was downloaded into temporary storage and extracted with `--appimage-extract`; no installation, application build or existing user configuration was changed. The extracted tree occupied approximately 566 MiB and includes Qt libraries, fonts, templates and a soundfont. The trial used existing host `bwrap`, `xvfb-run`, Python and the repository's optional lxml 6.0.2 schema-validation environment. No new npm or shipping dependency was installed.

Every application invocation ran through `qq-job`, with networking disabled, the host filesystem mounted read-only, a writable temporary working directory and isolated `XDG_CONFIG_HOME`, `XDG_DATA_HOME` and `XDG_CACHE_HOME`. `DBUS_SESSION_BUS_ADDRESS` was empty. Existing Xvfb supplied a temporary display: this official artifact failed with an offscreen-only invocation because GTK still expected a display. The actual binary rejected the handbook's `--no-synthesizer`, `--no-midi` and `--no-webview` options; they were removed. Local logs showed soundfont/audio initialization even in conversion mode. A production adapter must budget the application process rather than assume a small parser runtime.

In the final successful run, generating the two original native archives took 0.96 seconds with 221,824 KiB maximum RSS reported by `time`; exporting all four native input variants took 0.48 seconds with 220,908 KiB maximum RSS. These are small local trials, not a throughput benchmark, total process-tree peak or adversarial budget test.

## Original miniature evidence

The two [source fixtures](../../test/fixtures/musescore/README.md) were independently authored for this investigation, containing no acquired repertoire. The pinned application imported them and wrote genuine MSCZ archives. The plain MSCX variants were exact root-score members extracted from those archives, not unrelated independently produced native scores. The [research runner](../../scripts/research/musescore-proof.mjs) then automatically exported both forms.

| Miniature | Explicit exercised facts | Result for both MSCX and MSCZ |
| --- | --- | --- |
| Piano plus B-flat clarinet, two measures | Two parts; two piano staves and simultaneous voices; chord/rest meaning; C/E/D/F pitches, B-flat and D-flat spelling; written/sounding clarinet transpose; exact 3:2 eighth triplets; dotted duration; ties and slur endpoints; source fingering and staccato; quarter = 92, mf and pedal start/stop | 19 notes/rests per output, with asserted exact musical-event equality after explicit voice-label mapping |
| Four-string bass TAB, one measure | Complete D1/A1/D2/G2 tuning, including an unused string; C2 at source string/fret 4/10 and 3/3; open D1; a pitched x-headed note | Four notes per output; ordered tuning pitches and every source string/fret match exactly. The x head remains pitched; no dead-note playback interpretation was tested |

The verifier asserts output MusicXML version 4.0, exact expected part counts, rational onset/duration by integer arithmetic, written spelling/register, sounding transpose, chord/rest semantics, stable staff/voice relationships, ties/slurs, pitched-note type text/dots, tuplet ratios, fingering/staccato/x head, complete tuning and string/fret. Rest dots and full-measure-rest type text are deliberately excluded from comparison; preservation of those displayed rest spellings is not established. Other explicit rest type text is compared. It also asserts tempo/pedal/dynamics equality. Six documents—the two authored sources and four exported outputs—pass the existing pinned official MusicXML 4.0 XSD through offline lxml 6.0.2.

MuseScore renumbers the piano's source staff-2 voice `3` to output voice `5`; source staff-1 voices `1` and `2` remain `1` and `2`. The report retains both raw label maps. Musical comparison maps populated voices consistently across each entire part, so a voice's disappearance, reappearance or exchange between measures cannot be hidden by fresh per-measure numbering. This is a disclosed comparison mapping, not preservation of literal source labels.

These checks establish a useful original MusicXML → tool-authored native → MusicXML roundtrip. They do not independently prove how arbitrary native constructs are decoded, validate the whole native format, establish older producer acceptance or show that every detail of the initial interchange source was retained. Source facts that an importing application had already dropped before writing the native score cannot be recovered by a later adapter.

## Reproduce the bounded trial

Acquire the exact release artifact above into a temporary directory, mark it executable and run `--appimage-extract` there. Then run the proof against the acquired artifact and extracted directory:

```sh
/home/qqp/.local/bin/qq-job -- env \
  SCORE_CONVERTER_SCHEMA_PYTHON=/tmp/score-converter-schema-validation/bin/python \
  node scripts/research/musescore-proof.mjs \
  /temporary/path/MuseScore.AppImage /temporary/path/squashfs-root
```

The runner checks the artifact digest/size and application version. It uses verified `-j job.json` jobs with scalar input/output paths: first to produce original MSCZ, then to export generated native inputs to `.musicxml`. For one source the equivalent automatic operation is `AppRun -o output.musicxml input.mscz`, inside the same runtime isolation. It adds no `--force`, extension/plugin invocation, source-update or migration setting. The runner removes its original native files, app output/config/logs and temporary work directory on completion. The caller removes the separately acquired AppImage/extracted tree after investigation. No native files, receipts or app artifacts are committed.

## Practical designs

| Route | Practical advantage | Boundary and remaining work |
| --- | --- | --- |
| Optional pinned native MuseScore helper | Proven automatic conversion; existing native readers, migrations and MusicXML writer handle several instrument families without a new universal converter model | Full application/runtime footprint; filesystem/process isolation; explicit local tool discovery/configuration; source-bound coverage inventory and musical reconciliation still required. An installed helper must never silently inherit user plugins/settings or ignore version/corruption warnings |
| MuseScore-derived WASM/native libraries | Could run through a worker with owned input/output bytes; existing `webmscore` advertises Node/browser MSCZ and MusicXML export | Implementation remains MuseScore-derived. The inspected [webmscore source](https://github.com/LibreScore/webmscore/tree/78db5eb5437ccf1d17e0c4820374ee12f8862ce9) is a 2023 branch snapshot with package version 1.2.1 and GPL declaration; current native-format acceptance, exact bundled assets and memory were not exercised. No small separately permissive reader was established |
| Independent versioned MSCX/MSCZ reader | Fits the current bounded byte-input/worker design and enables source-owned reports, IDs and omissions | More recovery work: version migrations, separate container/style files, rational rhythms/tuplets, voices and spanners, written/sounding pitch, tuning/positions, linked staves/excerpts and native-only expression. Reading the format independently is different from copying GPL implementation code |

The official reader and writer source files carry `GPL-3.0-only`, and the full AppImage carries additional third-party libraries/assets. The native helper, a linked library and WASM redistribution have different integration boundaries; none has been selected or commercially cleared. The current [licensing screen](licensing.md) applies. This proof ran the unmodified temporary official application and incorporated no application source, assets or runtime into the converter.

For an eventual adapter, a generic conversion result can carry MusicXML, the common source-bound report and an untouched native source capture, with an adapter-specific optional facts payload. It does not need to put piano/orchestral input into the current required-string/tuning fretted proof model. The helper's MusicXML goes to the same external interchange boundary; ISO/Viewer owns subsequent consumer interpretation. Existing `convertGuitarPro` callers remain compatible. This result/API design is proposed, not implemented.

## Proposed version floor and next proof

**Propose MuseScore 3.0 as the minimum native source version, with a continuous compatibility target through every newer released version.** Do not advertise disjoint accepted producer snapshots. This proposed floor is not exercised acceptance: the actual local trial used only application 4.7.5 / native 4.70.

The pinned [reader registration](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/rw/rwregister.cpp) selects reader families below 4.00, 4.00–4.09, 4.10–4.59 and 4.60 upward. That establishes existing version-handling code, not preservation across those intervals. Producer `programVersion`, native `<museScore version>` and the exact invoked helper version must be recorded separately. A future native format must trigger a compatibility trial/update before a preservation claim, rather than being accepted solely because its number exceeds the floor.

The smallest next implementation proposal is a bounded optional local-helper adapter, if the product selects that deployment boundary. First extend the original producer evidence across the proposed continuous range and native reader transitions; explicitly inventory the admitted native feature vocabulary and check output against independently recovered source clocks/pitches/relationships/physical facts. Keep the proof's piano/transposing/fretted cases and add native-authored spanners, linked staves/excerpts and container/style cases only as selected features. Refuse or report unsupported meaning in context; successful application exit and XSD validity alone are insufficient. An independent reader can later use the pinned helper as a comparison route without incorporating its implementation.

Unexercised boundaries include older versions/migration fidelity, independent native-source fact recovery, corrupt/ambiguous archives, unknown native constructs, external assets, microtones, arbitrary tuplets/spanners, instrument changes, concert-score modes, linked parts, playback, graphical appearance and ISO/Viewer acceptance. No shipping adapter implementation was selected by this investigation.

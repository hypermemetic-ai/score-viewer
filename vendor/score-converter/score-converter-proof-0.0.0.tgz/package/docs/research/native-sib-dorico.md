# Native Sibelius and Dorico feasibility

Status: bounded documentation/source research carried over on 2026-10-07. **Standalone recovery of notes and rational timing from `.sib` or `.dorico` has not been established.** No sample project was acquired, app installed, account created or remote conversion performed for this seed.

## Sibelius `.sib`

### Routes actually found

| Route | Evidence | Limit |
| --- | --- | --- |
| Export from Sibelius | Avid documents native projects and MusicXML export | Needs an appropriate licensed app/edition and an export step; not direct native decoding by our product |
| SibMEI plugin | The plugin exports MEI from Sibelius; repository license is MIT | Runs inside Sibelius. Plugin permissions do not supply host/app automation or redistribution rights |
| ManuScript exporter examples | A discovered exporter accesses `Sibelius.ActiveScore` | Host-bound traversal is not an embeddable `.sib` decoder |
| Avid Cloud | Official service documents accepting `.sib`/`.sco`, MusicXML and PDF | A service accepting files for publishing does not establish a portable note-level decoder. Required terms, cost, access and canonical semantic export endpoint are not cleared |

Sources: [Avid export/product comparison](https://www.avid.com/sibelius/comparison), [ManuScript guide](https://resources.avid.com/SupportFiles/Sibelius/2024.8/ManuScript_Language_Guide.pdf), [SibMEI](https://github.com/music-encoding/sibmei), [SibMEI license](https://raw.githubusercontent.com/music-encoding/sibmei/master/LICENSE), [host-dependent exporter](https://github.com/temp1011/sibexport/blob/master/Sib2XML.plg), [Avid Cloud introduction](https://api.sibelius.avid.com/docs/introduction), [score-library guide](https://api.sibelius.avid.com/docs/guides/score-library).

The research did not establish a suitable public native decoder or an authorized shared-service route. That is an unresolved result, not proof that independent decoding is impossible. Supporting MusicXML exported from Sibelius remains practical while native feasibility is studied separately.

## Dorico `.dorico`

### Routes actually found

| Route | Evidence | Limit |
| --- | --- | --- |
| Export from Dorico | Steinberg documents MusicXML export | Native app is the exporter; export coverage still needs source comparison |
| DoricoMaestro project reader | The inspected Python module reads ZIP member `supplementary_data/scoreinfo/scoreinfo.xml`; its own comment names Dorico 5.1.60/6.2.30 verification | Extracts title/composer/flows/players and other metadata, not a semantic note/timing decoder |
| Steinberg DoReMi dataset | Public project provides native files and associated ground truth for research | A dataset is not a supported parsing library or permission to redistribute arbitrary projects |
| Historical developer/forum comments | Format described as proprietary/undocumented in older threads | Dated statements do not prove current impossibility or establish current rights |

Sources: [Steinberg MusicXML export](https://www.steinberg.help/r/dorico-pro/6.1/en/dorico/topics/project_file_handling/project_file_handling_export_musicxml_dialog_r.html?contentId=phzRyYpvQd8AqpiNCTt_9A), [DoricoMaestro source](https://raw.githubusercontent.com/romanstark/dorico-maestro/main/src/dorico_maestro/project_file.py), [DoricoMaestro project](https://github.com/romanstark/dorico-maestro), [DoReMi](https://github.com/steinbergmedia/DoReMi), [2016 format discussion](https://forums.steinberg.net/t/file-format-encrypted/664912), [2022 algorithmic-composition discussion](https://forums.steinberg.net/t/enabling-algorithmic-composition-in-dorico/800857).

Opening a ZIP container or reading metadata does not establish decoding of notes, written rhythm, voices or relations. The initial finding supports only a metadata route. It must not be advertised as `.dorico` musical import support.

## Proposed first feasibility experiment

This experiment is **not authorized or performed by the repository seed**:

1. Obtain or create a miniature native project with explicit permission and record its app/version.
2. Export MusicXML and an inspectable page from that same project as comparison evidence. Native data and export are not assumed equivalent.
3. Identify the container/version and recover only pitches and exact onsets/durations without relying on the original app.
4. Compare those recovered facts against the authorized project/export, record uncertainty and assess reader/license provenance.
5. Expand to voices, ties and phrasing only after semantic decoding is demonstrated.

A future positive result should state exact versions and coverage. A negative result should identify the specific missing decoder/data boundary, not permanently ban the extension or speculate that encryption is the cause.

Host automation and cloud services are alternative routes that require explicit commercial/deployment permission. Do not bypass vendor licenses or silently upload native scores while investigating them.

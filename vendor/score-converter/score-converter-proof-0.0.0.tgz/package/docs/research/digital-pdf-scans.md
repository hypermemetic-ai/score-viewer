# Generated PDFs and scanned-score research

Current priority remains structured inputs. This note retains conversion-relevant findings from the 2026-10-01 ISO digitization investigation, with targeted source checks during the 2026-10-07 seed. Earlier proposal/tasks were not implementation acceptance and are not revived here. No PDF/scan payload, recognizer installation or local benchmark is included.

## Acquisition tiers

| Tier | Input | What recovery must do |
| --- | --- | --- |
| 1 | Semantic score formats | Read musical identities and structure from encoded data, or use a compatible semantic converter |
| 2 | Generated digital PDF/SVG | Interpret fonts/glyphs, vector geometry, placement and relationships as music |
| 3 | Scanned PDF/images | Recognize symbols and relationships from pixels, then reconstruct musical structure |

A generated PDF can have precise digital glyphs and geometry while still lacking semantic notes, durations or voice ownership. It is often a better reconstruction source than a scan, but it is not automatically a lossless musical representation. PDF provenance should guide route selection instead of treating every PDF as identical.

## Earlier digital-PDF route

PDFtoMusic Pro was the previously investigated generated-PDF tool. It is not a selected pipeline dependency: its published command-line documentation restricts that route to personal use and excludes automated systems serving third parties. A personal trial/export does not authorize incorporation in our shared or commercial pipeline. [Myriad command-line documentation](https://www.myriad-online.com/resources/docs/pdftomusicpro/english/printable.htm).

An independently implemented graphical recovery route remains a possible future project. This note does not authorize reverse engineering, acquisition of proprietary source, bypass of license restrictions, or a claim that independent reconstruction is straightforward. Its rights and technical feasibility require a separate scoped investigation.

## Retained scan findings

| Candidate | Documentation/literature finding | What remains unproved here |
| --- | --- | --- |
| Audiveris | PDF/image intake, MusicXML output and interactive correction; official project is AGPLv3 | Actual piano-feature coverage, correction effort and compatible integration boundary |
| Modern full-page piano OMR | Output vocabulary and domain adaptation materially affect musical coverage | Exact runnable model/weights, permitted data, local fidelity, deployment cost and terms |
| Multimodal models | Possible transcription or cross-checking route | Reliable structure, omitted marks, inspectable evidence and reduced correction effort |
| Soundslice | Documented PDF recognition review and MusicXML export | Exact service permissions, actual output coverage and usefulness on our inputs |
| Manual transcription/correction | Valid fallback and comparison baseline | Measured effort for the same authorized material |

Audiveris provides correction examples for misattached curves and false dots, and documents limitations. These are workflow evidence, not an error-rate estimate for our scores. [Handbook](https://audiveris.github.io/audiveris/_pages/handbook/), [loading](https://audiveris.github.io/audiveris/_pages/tutorials/quick/load/), [limitations](https://audiveris.github.io/audiveris/_pages/reference/limitations/), [correction example](https://audiveris.github.io/audiveris/_pages/guides/ui/ui_examples/trinitas/README/).

The 2024 OLiMPiC piano study distinguishes real scanned material from easier synthetic cases. Its reported structured-output errors must not be restated as a percentage of wrong notes. Its linearized vocabulary omits some musical marks, including dynamics, pedal and fingerings, so a good benchmark score can coexist with important missing expression. [Paper](https://arxiv.org/html/2403.13763v1), [vocabulary](https://github.com/ufal/olimpic-icdar24/blob/master/docs/linearized-musicxml.md).

The later full-page piano study reports corpus- and adaptation-dependent symbol error rates and a Humdrum kern output route. Those encoding metrics do not predict accuracy on a different score or prove expression completeness. The discovered Zeus project is also a research candidate, not a verified drop-in grand-staff pipeline. [Full-page piano study](https://link.springer.com/article/10.1007/s11263-025-02654-6), [Zeus](https://github.com/OmniOMR/zeus).

Soundslice documents a review/edit workflow and MusicXML export, with a feature table that includes limitations. That is relevant product-design evidence; it is not a purchase recommendation, a local comparison or authorization to upload user scores. [Supported notation](https://www.soundslice.com/help/en/creating/pdf-import/294/supported-notations/), [review](https://www.soundslice.com/help/en/creating/pdf-import/344/reviewing/), [export](https://www.soundslice.com/help/en/creating/slice-manager/161/exporting/).

## Evaluate the complete route

Recognition errors, importer omissions and edition disagreements are different problems:

- If a musical mark is already encoded and an importer drops it, repair or extend that importer.
- If an encoding represents another edition, reconcile editions explicitly; do not fix geometry until source authority is resolved.
- If no musical encoding exists, recognition/manual transcription must recover and verify it.

A future comparison should use the same permitted passages and complete pages, with an inspected reference inventory. Record tool/model/version, native output vocabulary, preprocessing, runtime/cost, output losses, correction actions and total correction time. Compare end-to-end preparation against a manual baseline.

Check pitches/register, exact timing and written rhythm, independent voices, staff versus hand, ties versus slurs and endpoints, articulations versus augmentation dots, dynamics/pedal, pickups/repeats/endings and missing material. A model that never outputs pedals cannot earn complete expression coverage merely by finding all noteheads. Aggregate SER/TEDn values complement these checks; they do not replace them. [Evaluation research](https://arxiv.org/html/2506.10488v1).

Selection should follow evidence that the route reduces effort at the needed fidelity. If it does not, keep manual intake as an honest outcome. Do not force an OMR tool into production because its family was on the research list.

## Rights and review

Implementation code, model weights, training/evaluation data, fonts/mapping resources and hosted-service terms need separate review. Permission to possess a score, permission to submit it to a provider and permission to distribute the resulting edition are also distinct.

No claim of whole-score fidelity follows from inspecting a sample. Coverage must name the pages/features actually reviewed and all unresolved issues. ISO-specific engraving work and earlier cancelled studies remain outside this converter seed.

# Licensing requirements and dependency screening

Recorded 2026-10-07. This is a procurement/design screen, **not a legal opinion, final EULA, ownership audit or shipping clearance**. No project license is granted by this document. Final terms need software/IP counsel and confirmation of the rights we can actually grant.

## Product direction

The intended converter is source-available, with free personal/community use and a commercial license for applicable business use. Business-size criteria, eligibility/pricing thresholds and precisely bounded competitive-use restrictions remain to be defined. A commercial license may permit specified paid-conversion activities while reserving OEM/hosting/repackaging or other competing-product uses; these activities must not be conflated.

Donation support with project perks is treated as commercial for conservative dependency screening. This is our screening policy, not a universal legal conclusion that every donation is commercial under every license.

Restrictions on using our converter do not establish ownership of input/output scores, underlying compositions, the MusicXML format or independently implemented competing software. Score contributors' rights and any catalog participation agreement are separate matters and are not seeded into this software project.

Source-available is the owner's chosen direction. Terms that restrict commercial fields of use are not OSI open-source terms; distributing an application at no charge does not change that distinction. [Open Source Definition](https://opensource.org/osd).

The repository currently stays private under `hypermemetic-ai`. Public source visibility, contributor grants and product/documentation licensing require explicit decisions. Existing upstream grants cannot be erased by our own product terms, and previously issued grants/history need review before relicensing existing code.

## Compatible obligations, not zero obligations

Permissive code can generally be incorporated into a product under different terms while retaining its license/notices and satisfying its conditions. That does not transfer ownership of the dependency to us. [MIT](https://opensource.org/license/mit), [Apache 2.0](https://www.apache.org/licenses/LICENSE-2.0).

MPL 2.0 can support a larger proprietary/source-available work while imposing source and notice obligations on covered files. Those source rights cannot be restricted by our executable terms. Client-side/minified JavaScript distribution still matters. Exact packaging and modifications need review. [MPL license](https://www.mozilla.org/en-US/MPL/2.0/), [Mozilla FAQ](https://www.mozilla.org/en-US/MPL/2.0/FAQ/).

GPL/AGPL permit commercial use. The concern is incorporating, distributing or providing a covered/combined work while attempting to impose additional commercial or competitive-use restrictions. A process boundary is not automatic clearance; examine the actual interaction and deployment. Independently reading a format is different from reusing a GPL implementation. [GNU license FAQ](https://www.gnu.org/licenses/gpl-faq.en.html), [GPLv3](https://www.gnu.org/licenses/gpl.en.html), [AGPLv3](https://www.gnu.org/licenses/agpl-3.0.en.html).

Noncommercial, personal-only, research-only, evaluation-only and unverified grants need specific review for this product. A license label on a repository is not proof that every included file, resource or dependency has the same rights.

## Bounded candidate findings

| Candidate | Checked primary evidence | Preliminary disposition |
| --- | --- | --- |
| abcjs | [MIT license](https://raw.githubusercontent.com/paulrosen/abcjs/main/LICENSE.md) | Promising permissive reader; exact shipped package/assets/transitives still need inventory |
| humlib | [Two-clause BSD-style license](https://raw.githubusercontent.com/craigsapp/humlib/master/LICENSE.txt) | Promising permissive library; preserve notices and inspect exact build |
| alphaTab | [MPL 2.0 license](https://raw.githubusercontent.com/CoderLine/alphaTab/develop/LICENSE) | Potentially compatible with covered-file source/notice obligations; not blanket clearance for every package/font/asset |
| Denigma | [Core MIT license](https://raw.githubusercontent.com/openmusx/denigma/main/LICENSE), declared build dependencies and mapping provenance | Concrete MUSX candidate, but exact distributable is not cleared; see below |
| MuseScore | [GPL implementation license](https://raw.githubusercontent.com/musescore/MuseScore/main/LICENSE.txt) | Incorporation requires integration/licensing review. Independent MSCX/MSCZ support is a separate route, not barred by the app license |
| LilyPond | [Project software license](https://lilypond.org/gpl.html) | GPL implementation use/redistribution needs review. A static independent reader is separate; no acquired source execution |
| SibMEI | [MIT plugin license](https://raw.githubusercontent.com/music-encoding/sibmei/master/LICENSE) | Plugin code permissive; Sibelius host license and automation terms remain separate |
| Avid Cloud | [Official API documentation](https://api.sibelius.avid.com/docs/introduction) | Hosting/access/export/commercial terms not established; no approved dependency |
| Audiveris | [Official handbook identifies AGPLv3](https://audiveris.github.io/audiveris/_pages/handbook/) | Scan candidate requiring exact integration/service review, not a shipping selection |
| PDFtoMusic Pro | [Command-line terms](https://www.myriad-online.com/resources/docs/pdftomusicpro/english/printable.htm) | Published personal-use/third-party automation restriction makes the historical command-line route unsuitable for this shared pipeline |

### Denigma: code license is not complete data clearance

The initial audit checked Denigma's core license and selected declared dependencies/resource repositories. It did not build an exact shipping artifact, audit every transitive file or establish conversion fidelity.

The inspected `smufl-mapping` notice at commit `0d40955ab3d7acf7b171026d7fc15befd6d5b830` distinguishes its MIT-covered original work from reproduced upstream resources. In particular, it describes a MakeMusic application-resource file reproduced from Finale and says the font's SIL Open Font License does not extend to that resource. Some legacy mapping data also has Finale-origin provenance. [Pinned provenance notice](https://raw.githubusercontent.com/openmusx/smufl-mapping/0d40955ab3d7acf7b171026d7fc15befd6d5b830/NOTICE.md).

That creates a concrete rights question for the exact distributed data. It is **not evidence of a newly established noncommercial restriction**, and this seed does not decide whether an independent/interoperability justification clears those resources. Before adoption, determine exactly which files are included or required and obtain an appropriate rights assessment or an independently cleared replacement. Do not call the full Denigma package commercially cleared because the core license is MIT.

## Evidence limits

- The dated review covers linked license/notice files, selected declared dependency records and public tool documentation, not a full dependency-tree certification.
- Branch-based links may change. Select and archive exact source/build versions with notices before actual incorporation; the pinned mapping notice is the specific exception recorded above.
- Models, weights, corpora, examples, fonts, application resources and generated data can have different rights from library code.
- The current ISO snapshot has no top-level project license field/file establishing a new product grant. That observation is not proof of sole ownership or an exhaustive historical/contributor audit.
- Our commercial policy, upstream permissions, format/specification permissions and score copyright are separate reviews. None substitutes for another.

## Proposed adapter admission record

Before shipping an adapter, record its exact version/commit, incorporated files/assets, direct and transitive dependencies, licenses/notices, distribution/service boundary, obligations, unresolved issues and approval scope. Keep technical coverage and rights disposition separate so a technically successful trial is not mistaken for legal clearance.

The 2026-10-08 [Guitar Pro screening](guitar-pro.md#exact-inspected-artifact-and-dependency-boundary) pins alphaTab 1.8.4 and verifies its published archive integrity. No runtime npm dependencies are declared, but integrated libraries and bundled font/soundfont assets have separate notices. It also records PyGuitarPro 0.11's LGPL-3.0-only declaration as a narrower GP3–5 alternative. These findings support an evaluation recommendation, not shipping clearance or a change to our source-available product direction.

Selecting a dependency with compatible conditions is acceptable. Do not implement a license bypass, silently replace attribution or claim a permission that was not established.

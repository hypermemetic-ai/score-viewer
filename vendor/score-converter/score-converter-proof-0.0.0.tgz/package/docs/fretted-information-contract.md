# Single-output fretted information contract

Accepted direction, 2026-10-09: enrich the existing conversion path so its normal output carries supported source facts for both pitched notation and tablature. Preservation is automatic and independent of a consumer's selected presentation. [Decision D27](decisions.md) records this refinement of the initial notes-only bass display scope.

This contract covers admitted fretted profiles, now including bounded GP3–GP8 encoding support and genuine Guitar source evidence. Complete tuning/string count accompanies string/fret, written/sounding pitches, exact timing, voices and supported techniques. Version support does not admit every construct; further techniques/nonzero capo remain outside scope. The [proof](guitar-pro-proof.md) records implementation/validation; the [public API](guitar-pro-api.md) defines inspection, selection and successful source-to-XML identities. Consumers own retention, presentation and integration.

## One interchange output

The public API and CLI use one default MusicXML exporter. Consumers do not request a notes or TAB export profile, and displaying ordinary notes must not discard physical source facts. Musical meaning remains understandable through standard MusicXML without ISO extensions or a required private report.

The recovered model already holds source tuning as ascending open-string MIDI pitches. Its length is the string count, including unused strings. Notes retain their source playing positions using MusicXML string numbers, with 1 referring to the highest string. A pitch can have several valid positions; import must preserve the encoded position rather than calculate a replacement from pitch.

## Standard tuning representation

MusicXML defines [staff-tuning](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/staff-tuning/) as the open tuning of TAB staff lines. Putting those line tunings on the existing ordinary five-line staff would confuse physical string count with notation geometry. The selected representation uses a hidden alternate TAB staff within the same part:

| Structure | Meaning |
| --- | --- |
| `staves=2`, ordinary clef on staff 1 | Existing ordinary notation remains the musical event stream |
| Hidden TAB clef and `staff-details` on staff 2 | Standard carrier for fretted-instrument tuning |
| `staff-type=alternate` | Alternate display of the prior staff's music; excluded from playback |
| `print-object=no`, `print-spacing=no` | The carrier requests no printed staff or reserved spacing |
| `staff-lines=N`, `staff-tuning line=1..N` | Complete string count and open tuning, ordered bottom-to-top |
| Source notes, rests and directions on staff 1 | Each written event occurs once; staff 2 introduces no duplicate attacks or rhythm |

The [alternate staff definition](https://www.w3.org/2021/06/musicxml40/musicxml-reference/data-types/staff-type/) explicitly includes standard notation and tablature as two displays of the same music. [Staff details](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/staff-details/) and [clef](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/clef/) support the visibility declarations used here. The alternate staff is generated output structure, not an assertion that the source contained a second musical staff or a performing-hand assignment.

Tuning entries describe sounding open-string pitches. Written-to-sounding note transpose does not shift them. Because this proof's source tuning supplies MIDI numbers rather than spelled pitches, deterministic spelling for the tuning entries is reported as inference. The report separately identifies preserved tuning and generated serialization choices. Existing hidden per-note technical string/fret data remains source physical guidance.

## Consumer handoff

| Owner | Work required |
| --- | --- |
| Converter | Emit complete tuning/string count through the normal output; preserve source positions, clocks, pitches and admitted relations; report generated representation |
| ISO preparation and TUNA contract | Read the alternate staff's complete tuning, associate it with the same part/instrument, and retain it with per-event source positions without treating the generated carrier as a second performance voice or hand |
| Viewer | Store the enriched prepared score and choose notes, TAB or both from the same musical events; add presentation/admission support through the shared ISO contract |

The ISO reader inspected on 2026-10-09 at `7205da0d6b62a4a023eda5f2f5d66bdec4fa6493` accepts `staves`, `clef` and `staff-details` at the attributes boundary but does not retain the tuning. Its note projection already retains technical string/fret as `physicalSource`, and Viewer reading-package assembly stores that score. This converter increment closes the export omission; downstream tuning retention is still required before a TAB view can use it. It does not implement a viewer display control or direct Guitar Pro import dialog.

## Verification boundary

Acceptance requires independently reconstructing every tuning MIDI pitch and string count from the standard XML, including altered tuning and unused strings; preserving different source positions for the same pitch; and proving each part keeps its own tuning. Original fixtures must also preserve exact clocks, voices, written/sounding relationships, chord/rest/dead-note semantics, ties and H/P endpoints without adding event copies. Validate richer outputs against the pinned unmodified MusicXML 4.0 schema.

Schema validity and source preservation establish the interchange contract. Visual behavior, third-party notation-app portability, ISO tuning storage and Viewer TAB acceptance need their own evidence. The requested default remains ordinary notes; the hidden carrier's behavior in an independent notation application is not yet certified.

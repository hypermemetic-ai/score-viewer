# Architecture and project boundaries

Status: initial design direction, 2026-10-07, with a bounded bass reader added 2026-10-08, continuous GP3–GP8 encoding support and an additive public GP WebView Worker entry implemented 2026-10-09. The diagrams describe product direction; the [proof record](guitar-pro-proof.md), [public API](guitar-pro-api.md) and [WebView contract](guitar-pro-webview-entry.md) define exercised implementation and remaining integration gates.

## Product flow

```text
Structured formats / generated PDFs / scans
                     |
                     v
          Independent conversion pipeline
                     |
                     v
       MusicXML 4.0 + conversion report
              /                    \
             v                      v
Other notation tools          ISO score tools
                               |          |
                          .tuna output    PDF
                               |
                               v
                             Viewer
```

MusicXML is the first exchange output because it is an established open interchange format maintained by the W3C Music Notation Community Group. It is a Community Group report, not a W3C Recommendation or a standard controlled by this project. The format distinguishes written notation from performance-oriented information. [Specification](https://www.w3.org/2021/06/musicxml40/), [notation basics](https://www.w3.org/2021/06/musicxml40/tutorial/notation-basics/).

The converter owns recovery from other source formats, MusicXML output fidelity and a tested usable public package/CLI contract. Existing MusicXML input, `.mxl` unpacking and consumer interpretation/admission are downstream responsibilities. GP3–GP8 has an implemented bounded route; the independent native MuseScore reader remains in implementation and repertoire validation. Finale remains research. Consumers own integration, hosting and presentation. The converter's acceptance checks exercise its public contract without requiring a particular consumer application.

GP uses one portable musical/admission core with separate Node and dedicated Web Worker hosts. The package root retains the Node API/CLI; `score-converter-proof/guitar-pro/webview` supplies the same asynchronous inspection/conversion contract with an adjacent bundled ES-module Worker. ZIP structure, identities, physical source facts, recovery and MusicXML remain shared; inflation is a host codec boundary. The WebView host selects native `DecompressionStream('deflate-raw')` with strict complete settlement, size and CRC checks. Missing or unadmitted codec capability produces an explicit refusal for affected compressed inputs. This entry adds no standalone browser product or native MuseScore route.

Both GP hosts enforce input/decode/structure/output/message/work guards and a five-second deadline with Worker termination. Node additionally configures V8 Worker resource limits. WebView guards bound accepted/retained data and finite work; they do not establish a hard native decoder/queue allocation ceiling or configurable Worker heap cap. Converter package tests and sampled observations are separate from actual consumer WebView/CSP/asset/memory and platform acceptance. The [WebView contract](guitar-pro-webview-entry.md) records this selected policy and exact local package surface; Viewer owns integration and native delivery.

Standard output must work in other applications without TUNA or a proprietary report. A separate report can preserve conversion evidence and unresolved decisions that are not portable musical notation. It must not conceal omissions by forcing ordinary readers to understand private extensions.

## Repository responsibilities

| Project | Owns | Relationship to this converter |
| --- | --- | --- |
| Converter | Input adapters, recovered facts, conversion-specific validation, semantic correction decisions, uncertainty and interchange export | This repository |
| ISO notation / score tools | Notation meaning/principles, TUNA contract, ISO editorial workspace, review studio, engraving, pagination, PDF/TUNA publication | Downstream consumer; may supply rendering to a combined review frontend |
| Viewer | Library, reading, devices, performance, score practice, personal edits and desktop releases | Import invokes the converter, then shared ISO preparation and scope-specific admission; piano physical capabilities retain their own requirements |
| Fingering calculator | Physical instrument/layout models, hand/finger planning and diagnostics | Separate optional enrichment here; required calculated piano fingers in our viewer |
| Learning app | Curriculum, listening/notation exercises, learner state and platform lifecycle | Independent application; existing engraving reuse does not imply converter dependence |

These are responsibility boundaries, not a completed repository migration. A repository may publish several packages so clients can use a renderer or a parser without loading an entire application. The existing ISO code is coupled in ways recorded in [existing foundations](research/existing-foundations.md).

The core dependency direction is converter output → ISO preparation → TUNA. A review shell can depend on both converter and renderer. Making the neutral conversion core depend on ISO rendering would unnecessarily impose an ISO-only runtime on other customers; the shell is the proposed place to combine them.

## Conversion stages

1. **Identify the input and route.** Detect format/container and version, record input identity and the known adapter profile. Do not assume a `.xml` file is MusicXML or a `.pdf` is a scan.
2. **Read or recover musical facts.** Preserve identities and source locations with exact rational clocks where the source provides them. PDF/OMR routes recover hypotheses instead of pretending to read a semantic source.
3. **Validate and inventory coverage.** Track preserved facts, inference candidates, unsupported constructs, ambiguities and missing material. Source file validity, adapter coverage and output validity are separate findings.
4. **Resolve necessary decisions.** Apply deterministic rules when justified; allow user review or later model-assisted proposals. Record before/after facts, reason, evidence, scope and decision authority.
5. **Export MusicXML.** Preserve the supported musical result in the established format. Validate syntax/schema where appropriate, rational timing, musical relations and portable interpretation; schema validity alone is insufficient.
6. **Return output and report.** The consuming application decides whether its own instrument/rendering/practice requirements are met. Install or replace a viewer score only after that consumer's checks succeed.

Stages may need resumable work when a later route becomes expensive. Start with a small inspectable result and decision boundary; do not build a generic worker/task framework before a route demonstrates that need.

## Information that must not be conflated

| Distinction | Example |
| --- | --- |
| Written pitch and sounding pitch | An octave-transposing instrument or an octave-shift marking |
| Written duration and sounding span | Several tied notes versus one long MIDI note |
| Source staff, logical voice and performing hand | A cross-staff phrase is not a hand change merely because it changes staff |
| Phrase and pitch tie | A curve connecting different pitches cannot silently become a tie |
| Written measure and performed occurrence | Repeats reuse written material with separate playback occurrences |
| Printed tempo and working reference tempo | A user-selected practice reference is not an arranger's tempo marking |
| Stock, calculated and personal fingers | A printed piano fingering versus an instrument-specific solver result versus a player's override |
| Absent and unrecovered information | MIDI supplies no ordinary slur; OMR may have failed to recover a printed one |
| Importer omission and source disagreement | A dropped encoded mark differs from two editions containing different marks |

Tempo should preserve its duration unit and rate, such as quarter notes per minute. Converting rates for internal scheduling must not turn a chosen reference into a printed score fact or strip a dotted/other duration unit.

## Partial conversion and extensibility

Support is per input and feature combination, not a claim that every file with a recognized suffix converts completely. A notation-rich source and a sparse MIDI may both produce a useful output, with very different evidence and limits.

Recoverable MusicXML constructs must not be dropped because TUNA currently lacks an importer or renderer for them. A bounded conversion route can export a defined musical scope without implementing every possible MusicXML construct. Inventory unsupported source constructs and their concrete consequences; never silently claim lossless conversion. Existing MusicXML input belongs to the consumer's reader coverage, independently of the converter's export scope.

Source adapters should not bake in piano-only hand assignment. A fingering adapter may enrich a specific instrument/layout later. The viewer's complete/editable piano-fingering guarantee belongs to its admission/preparation path, not to MusicXML validity.

For the implemented [Guitar Pro route](guitar-pro-proof.md), retain source tuning/string/fret, written and sounding pitch forms, original rhythm and tempo units, explicit techniques and source IDs before a reader normalizes them. A third-party playback/rendering model is a recovery aid, not automatically a lossless neutral model. Inventory original source features and reconcile normalized occurrences so ignored properties cannot disappear from the report. Fretting and plucking roles may coexist on a bass note; neither staff identity nor source physical choices imply a complete calculated fingering.

The [single-output fretted information contract](fretted-information-contract.md) makes complete tuning and string count part of the normal interchange output. A hidden standard MusicXML alternate TAB staff carries its string lines and ordered open tunings; the ordinary staff retains the sole musical event stream and hidden source string/fret markings. The alternate staff is generated serialization structure, separately reported from the original source staff. Consumers preserve these facts before applying notes/TAB presentation. ISO import/storage and Viewer rendering remain separate downstream work; a successful richer export does not establish those features.

The alphaTab-derived reader is a clearly marked source component with its own applicable licenses, upstream baseline, notices and scoped modifications. An original adapter connects its recovered facts and coverage findings to the converter's proof model/report boundary; the common exporter produces MusicXML. Keep reader-specific classes and normalization inside that boundary. Covered files and files containing copied MPL code retain MPL rights; separation makes obligations inspectable rather than changing them. The [reader proof](guitar-pro-proof.md) exercises source capture and ordinary MusicXML output across bounded GP3–GP8 profiles, including genuine Guitar evidence. Its fretted model remains distinct from a universal instrument model. Written/sounding pitch relations stay distinct; actual-pitch display and the accepted C2 bass center belong to downstream consumers.

The accepted architectural direction is late instrument branching. Instrument identity, voices, written/sounding relationships and event meanings remain common facts; consumer preparation resolves small instrument policy/data, with specialized behavior invoked only at use sites that require it; common importer, event processing and layout stay shared. Physical-role/fingering overlays remain optional layers. The current fretted proof model is not a universal instrument-neutral API.

Late presentation semantics must distinguish visual stem direction from direction that encodes a performing hand. Legibility optimization requires positive visual authority; missing hand facts or an instrument name alone do not authorize flips. Performing-hand direction remains a hard constraint. The conservative ISO reading-v1 guard rejects hand-bearing combinations through preparation and direct rendering while preserving those source facts and ordinary piano authority; a future visual policy that also preserves independent physical roles needs its own explicit contract.

The user approved full replacement of the legacy model across all active ISO/Viewer consumers with one common pitched/unpitched event union, rather than retaining a parallel pitched-only model. The downstream implementation passes common reading and retained piano archive/Worker/practice checks, with both ISO and Viewer source merged. Pitched events have a canonical actual pitch; unpitched events have no definite sounding pitch and retain a separate notation reference. Source transpose resolves once; C2 is shared mapping data. Piano fingering, keyboard contacts and practice require actual piano capabilities at their use sites rather than constraining all musical admission. Passive legacy archive normalization preserves original bytes and identities. Native delivery and later performance, keyboard, Score Options and full metrical count-in work remain solely with the Viewer parent.

Viewer's additive v3 reading package uses the shared ISO engine, source-owned events and regenerated notation/owner/layout admission. It carries no invented physical piano seats or bass fingering recipe. Legacy v1/v2 package versions remain compatible at the serialization boundary. Existing per-score piano chromatic transposition is separate from the instrument's written-to-sounding relation and the fixed bass display anchor; extending transposition to common reading is not implemented by this increment. The [consumer handoff](bass-display-handoff.md) tracks exact source pins, admission evidence, landing and native delivery separately from human visual acceptance. No ISO model or engraving code is moved into this repository.

Outward stem preference is the selected production default for visual instrument reading. The versioned reading policy supplies this preference to common group solving, preserving fixed note spacing, source facts, ownership and genuine piano hand authority. Source-owned groups retain one coherent direction, with solved clearance as a constraint. Prepared packages identify the policy and engine explicitly so an older layout is not silently reinterpreted under a new default. General legibility optimization and replacement pagination remain separate work.

```text
Local Guitar Pro file
    → alphaTab-derived reader + source capture
    → adapter / neutral facts + coverage findings
    → common MusicXML 4.0 exporter + report
    → ordinary notation tools / ISO preparation
```

## Human and model-assisted oversight

Conversion review concerns missing/incorrect musical facts and documented editorial decisions. ISO visual editing concerns how the accepted music appears in that notation. A combined UI can show both, but a geometry adjustment cannot repair a missing source slur or settle an edition disagreement.

Model or agent proposals must identify their input scope, candidate change, evidence and uncertainty. A confidence score is not source verification. Preserve the original interpretation and reviewed changes rather than replacing facts with an opaque regenerated score.

Optional remote recognition/model services require separate permission to upload user material and compatible provider/data terms. Their existence is not authority to send scores anywhere.

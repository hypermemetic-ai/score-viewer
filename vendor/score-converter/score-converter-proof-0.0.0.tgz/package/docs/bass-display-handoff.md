# Instrument policy and bass display handoff

Consumer handoff, 2026-10-08, with the production outward-stem decision and source landing recorded 2026-10-09. The selected common reading presentation uses outward stem preference, curved H/P connections with labels and stable actual-pitch C2 centering. Full common pitched/unpitched model replacement across all active ISO/Viewer consumers, late instrument branching and C1/C2/C3 guides are approved. Converter, ISO and Viewer source is merged. Source fidelity, geometry, package admission, human visual acceptance and installed behavior remain separate states. The Viewer parent owns coordinated native delivery. See the [proof contract](guitar-pro-proof.md) for exercised interchange coverage.

## Accepted boundary and pitch contract

Keep parts/voices, instrument identity, written/sounding pitch, rational timing, pitched/unpitched events, musical relations and provenance common as far downstream as useful. Source adapters interpret source semantics and feature admission; they do not select ISO geometry. Optional physical-role/fingering facts remain separate. Staff/voice identity does not invent a piano hand or fingers.

The user chose full replacement rather than phased migration with a persistent pitched-only projection. Active consumers use one common event union. Pitched events have a canonical actual pitch. Unpitched events have no definite sounding pitch; a separate reference guides notation and must never become a pitched playback attack. Legacy serialized archives normalize at passive admission while retaining original bytes, hashes and personal identities. Genuine piano hand/physical requirements apply at physical use sites, rather than restricting all musical admission.

Preparation resolves small instrument policy/data for shared mapping/layout. Specialized behavior runs only where needed; common importer, event processing, layout and ink stay shared. C2 is mapping data, not a separate `BassScore`/`BassRenderer` pipeline. MusicXML remains the external converter contract. The converter's `src/core/model.ts` **`NeutralScore` remains a fretted-string proof API**, with required tuning/string/fret and direct dead/HOPO fields; it is not the universal consumer model. No ISO model or renderer code is extracted into this repository.

```text
source adapter → recovered facts → MusicXML
                                     ↓
common consumer facts → policy data → shared layout/ink → view
```

For bass, actual/sounding pitched notes use:

```text
y = centerY - (soundingMidi - 36) * semitoneScale
```

C2 = MIDI 36 stays the anchor across systems/songs; `centerY` moves with its system on the page. Guides are MIDI 24/36/48 (C1/C2/C3). Use literal actual pitch with no automatic octave folding. Do not recenter from song range, source tuning or written bass octave; centering changes neither source nor playback pitch. ISO linear pitch is `MIDI - 12`: anchor 24, guides 12/24/36. Resolve written-to-sounding pitch once: written C3/MIDI 48 with `octave-change=-1` becomes sounding C2/MIDI 36, then linear 24.

User chromatic transposition is a separate reversible consumer transformation. Existing piano transposition remains supported; extending it to common instrument reading is later work. It must preserve original score facts, timing/repeats and owner identities while regenerating complete notation and any applicable physical plan. A fixed display anchor does not itself transpose music.

## Implemented downstream scope and delivery state

ISO [PR #339](https://github.com/hypermemetic-ai/iso-notation/pull/339) is merged at `42ac072da5af34de00b2fe8096cc434210ef05e9`, tree `518b31e993c481b580adbe777fb4986e17e72b4d`, identical to the reviewed production source below. It implements the common union across active importer, engraving and other consumers, including instrument/transpose/unpitched/technique facts, owner-linked layout and shared C2 preparation. Viewer [PR #26](https://github.com/hypermemetic-ai/score-viewer/pull/26) is merged at `7473fdadbbd1c9c94bde5feea3145b013f178ed0`, tree `516ef7ff683de0bacb486fd91561636f6adea1dc`, identical to reviewed `f8a9debddc64101bba6018e73902626186b7d13c`. It retains that exact merged ISO pin/provenance. It implements additive v3 reading-package admission and capability checks, and includes the merged piano-transposition, personal-state and practice repairs from PRs #25/#27/#29. The Viewer parent solely owns later performance, keyboard, Score Options, full metrical count-in and native work. Native delivery is pending; these source merges have not changed the installed release.

Viewer's v3 package uses the shared ISO engine with explicit source owners and resolved policy/options. Admission regenerates and compares notation, owner and layout data before library write. It supplies no invented physical seats, keyboard/finger descriptors or bass solver. Physical editing/practice/calculation remain gated by actual capabilities. Legacy v1/v2 packages retain their byte and identity compatibility at the boundary.

Relevant ISO paths are `src/model/{types,musical-event}.ts`, `src/import/musicxml/{types,parse,project}.ts` and `src/render/janko/{instrument-reading,geometry,engine,technique-reading,tuplet-reading}.ts`. Viewer uses `src/{package,reading-package,score-capabilities,score-serialization}.ts`. Exact dependency pins and production/private-input separation must be verified in their own repositories; successful MusicXML recovery alone does not establish a usable archive.

### Production outward checkpoint

Reviewed and pushed ISO `0c0892d5163c2fe5e8594a9ee4a47fcc34df63e5` uses engine identity `janko-real-engine-instrument-reading-v3-outward`. The actual part has ten pages, 39 systems, 211 intact beams, 1,013 owners, 1,026 written heads and nine source-owned H/P curves, with zero geometry violations or warnings. Only the reading policy changes in the musical source; source endpoints/clocks, owner facts, every head's x/literal-pitch y and native beam membership remain exact. The display-direction guard rejects malformed overrides and overrides of genuine performing-hand authority. No note-spacing alteration or automatic inward fallback is implemented; blocked geometry refuses explicitly.

Historical ISO `c23f52081290ad0753e6e16da146f2f951facf29` and Viewer `ac58db00612d4dbb5f982f87a5463e77b8eb3029` used a square prototype. Its bytes remain intact and its unsupported engine identity is refused rather than silently reinterpreted. Historical curved/register replay remains explicit and passes at the final pin. The new outward archive cold-admits with ten pages, 1,013 owners, nine curves, no physical seats and zero geometry violations/warnings.

## Verification and its limits

An independent private source → MusicXML → common-model comparison checks 1,040 written events, 1,013 canonical owners, 14 rests, 13 tie chains and nine H/P relationships across 179 written and 184 performed bars. It verifies pitches, exact clocks, source endpoints, ownership and written/performed distinctions. It proves fidelity to the admitted transcription, not accuracy against the recording or an author-certified edition.

The production outward ISO source passes 66 focused checks, 74 mandatory fast tests, configured types, strict canonical/specimen geometry and private-safe production build. The actual-beam/real-flag negative lint check passes. Literal v1/register replay preserves all ten pages, owners and layout; original piano serialization is restored exactly, including the retained six-page Zelda source and receipt case. The broad research gate retains 30 independently reproduced baseline failures, including five prior wider-linter cases; no new all-green broad run is claimed.

Viewer's final combined source passes all 502 tests and production build. At the exact merged ISO pin, cold admission passes the new outward bass, historical curved replay and four untouched original/+1 piano archives across two keyboards, preserving journals and library bytes. The actual outward-bass browser probe verifies below/above stem paint, x heads and nine H/P curves with zero page errors. Four real Worker/receiving-cold/practice-lifecycle cases pass, preserving original archive/state identity with zero drift. These checks establish source and browser behavior; they do not certify the recording, independent notation-app audio or native installation.

Independent Viewer-parent acceptance adds 71 focused tests with zero failures, skips or cancellations, strict OpenSpec validation 9/9, and acceptance of all four retained archives, the new bass and 18 controls. This verifies the merged source handoff; it does not report native activation.

The converter's final pre-landing build and 21/21 original-material tests pass. Its earlier six original MusicXML schema checks and independent private source/interchange comparisons remain applicable. Planning PR #2 is merged, and reader [PR #3](https://github.com/hypermemetic-ai/score-converter/pull/3) is merged at `e36eb113bbf4e543f80a5de34bc8872d732ee92e`, from reviewed `6df3219062a1798902d20a7bdae17dc76039ab8b`, tree `5ed92fde83c570bfe393b80d22b5eb6ccbc032f1`. This status reconciliation adds no converter code.

Private source files, generated MusicXML/TUNA/SVG, individual source hashes, upload paths, manifests, captures and receipts remain outside Git. Only aggregate findings and repository commit/PR identities are recorded here. Source landing does not publish the catalog, release the source publicly or select product licensing. Native activation is reported separately by its delivery owner.

## Production display contract

Accepted presentation facts are ordinary actual-pitch notes, durations and source articulation; x heads for unpitched dead events; curves with H/P labels; no visible frets, TAB or invented fingers. Source written dots/rests and exact tuplet clocks remain intact. The demonstrated common layout infers metrical beams when XML beam tags are absent, hides C letters/beat grid and ends barlines at the outer guides. Source beams and musical relations remain distinguishable from inferred presentation.

Rhythmic groups remain intact across C2. The production contract is `instrument-reading-v2`, with `stemPolicy: 'outward'` and `stemDirectionSemantics: 'visual'`, under engine identity `janko-real-engine-instrument-reading-v3-outward`. Below-center visible heads vote down, above-center heads vote up and exact-center heads abstain. Each complete group uses the majority; equal votes may retain immediately contiguous same-part/staff/voice direction, then use mean register and a stable down tie-breaker for an exact-center tie. Geometry remains a hard acceptance gate. The default changes presentation preference while retaining source grouping, pitch, timing and piano roles.

Stem-direction freedom requires positively known visual presentation authority. Missing hands or an instrument name alone do not authorize visual flips. Performing-hand direction is a hard constraint. Conservative `instrument-reading-v1` rejects hand-bearing combinations through preparation and direct rendering, including handed provenance and silences; ordinary piano RH-up/LH-down authority is preserved. A visual policy that also retains independent physical roles needs its own explicit contract.

The user selected outward preference for ordinary production reading. The earlier inward register-majority/minimum-departure baseline remains historical comparison/replay evidence, not the current choice. A bounded manual source-owned legibility comparison removes three attention hits without moving heads or changing system height, while retaining a residual relationship; its attention metric is not perceptually validated. A general legibility optimizer, weights and equivalence tolerance remain separate work and do not defer the selected outward default.

Shared pagination is also an investigation. The current layout caps pages at four systems and distributes residual vertical space above, between and below them. Actual-engine six/eight/twelve-row caps produce seven pages instead of ten, with at most six rows, unchanged source/groups/scale and zero geometry violations/warnings. The user requested a higher first system and more systems per page while prioritizing legibility. These measured alternatives do not establish a replacement page policy.

## Further validation and delivery

1. Complete coordinated native delivery under the Viewer parent's separately authorized work, recording actual completion separately from the merged source/browser checks.
2. Independent notation-app display/audio and perceptual validation remain separate evidence; they do not defer the selected outward default or authorized source landing.
3. Evaluate general legibility optimization and pagination with actual-engine bounds and readable full systems/pages. Keep the production outward default, source facts and groups intact.
4. Retain source/owner/clock equality, legacy byte compatibility, genuine piano direction/capabilities, existing piano transposition and explicit baseline failures through later changes.

This reconciliation changes score-converter Markdown only. Converter, ISO and Viewer source landing is complete; the Viewer parent owns subsequent Viewer work and coordinated native delivery. Catalog publication, public source release, product licensing and bass fingering remain outside this conversion handoff.

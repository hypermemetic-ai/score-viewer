# MusicXML 4.0 validation schemas

Unmodified `musicxml.xsd`, `xml.xsd` and `xlink.xsd` from the MusicXML v4.0 tag, pinned commit `799e2defb2ece0ae7bafe08dcbcac25b2c631d53` in <https://github.com/w3c-cg/musicxml>. `inventory.json` records original paths and SHA-256 hashes.

The MusicXML and XLink schemas retain their original copyright and [W3C Community Final Specification Agreement](https://www.w3.org/community/about/agreements/final/) notices. These schemas are validation material, not a standard controlled by this project or a grant to users' scores. The original XML namespace schema is included unchanged for the imported namespace.

`scripts/validate-musicxml.py` resolves only these local schema files, without network, DTD or entity loading. The source schema's URL import declarations remain unchanged. Schema success is distinct from musical semantics, notation-app readability and human acceptance.

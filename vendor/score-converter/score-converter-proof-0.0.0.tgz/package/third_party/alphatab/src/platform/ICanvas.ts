/**
 * This public enum lists all different text alignments
 * @public
 */
export enum TextAlign {
    /**
     * Text is left aligned.
     */
    Left = 0,
    /**
     * Text is centered.
     */
    Center = 1,
    /**
     * Text is right aligned.
     */
    Right = 2
}


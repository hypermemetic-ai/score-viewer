/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */
import { NotationMode } from './NotationSettings.js';

/** Deliberately narrow settings boundary for the headless GPIF reader.
 * No caller transposition, display slicing, SongBook normalization or assets.
 */
export class Settings {
    readonly importer = { encoding: 'windows-1252', maxDecodingBufferSize: 65536, beatTextAsLyrics: false };
    readonly notation = {
        notationMode: NotationMode.GuitarPro,
        transpositionPitches: [] as number[],
        displayTranspositionPitches: [] as number[]
    };
    readonly display = { startBar: 1, barCount: -1 };
}

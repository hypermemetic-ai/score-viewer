# Bundled runtime notices

The existing `saxes` 6.0.0 npm artifact declares ISC but omits its upstream LICENSE file. The WebView bundle ships that notice from the [v6.0.0 source commit](https://github.com/lddubeau/saxes/blob/211fa0ebec9b628affc09219199639887174bfc3/LICENSE), including its inherited sax notice. This is license text only, not another runtime component or dependency. The build combines it with the installed pinned `xmlchars` 2.2.0 MIT notice and the covered [alphaTab license/source](../alphatab/README.md) in `dist/webview/NOTICE.txt`.

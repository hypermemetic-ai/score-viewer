# Stretch calibration contract and Viewer handoff

Viewer handoff revision 2, agreed 2026-10-12 under [playing philosophy version 23](playing-philosophy.md). The core collection remains `stretch-calibration-protocol-v1` / `stretch-calibration-session-v1`; this revision adds optional `effective-curl-refinements-v1` companion evidence rather than changing old session meanings. The calculator package exports the descriptors, six grade labels, geometry seed and TypeScript wire types through the root API. The Viewer implements the collection screen, adaptive queue, input handling, validation, storage and export against this contract. The older fixed-frame collection functions remain available for historical sessions; they do not implement this protocol.

The collection records relative fingertip reach, static pair stretch and conditional triple boundaries. It does not require effort judgments, trills, timed tapping, fixed wrists or a forced five-finger maximum. The lowest stretch band describes a range of relaxed arrangements. A photographed or reported whole-hand placement can illustrate that range without receiving a privileged score.

## First collection

Use one hand at one declared central location. Preserve the player, hand, seating reference, body midline, instrument identity and immutable geometry snapshot. A second hand is a separate collection with separate observations. Mirroring may be a model hypothesis; it is not a second measured hand. Additional arm locations are later validation coverage, rather than a mandatory repetition of this first run.

The sequence is four relative fingertip readings, ten progressive pair sweeps, then ten conditional triple slots. A sweep contains several judgments and stops adaptively. These are not 24 individual trials, a fixed total, or a proved sufficient minimum.

The Viewer should show completed readings, completed/omitted sweeps, recorded/omitted triple slots and the judgments actually entered. Do not display an invented total number of remaining pair judgments. Untested contacts remain unknown; omissions and limits are explicit.

The optional curl refinement editor is outside this sequence and progress count. It can be omitted entirely while completing the collection. The new cost design requires no fatigue/recovery judgments, endurance/tapping tests, compulsory motion-speed tests or player-supplied movement weights. Static observations constrain personal geometry; the architect supplies and tests the movement metric and cost normalization separately.

## Geometry and physical identity

Use `STRETCH_CALIBRATION_KEYBOARD_PROFILE` or its byte-identical packaged [JSON seed](calibration-keyboard-profile-v2.json). The seed is the regularized RR/Jankó reconstruction accepted on 2026-10-12. It retains designed slopes, steps and four mounting forms while removing individual installation offsets. It is a separate profile from the previous nominal flat-surface descriptor.

Coordinates are millimetres: x toward higher pitch, depth away from the player, height upward. A measured tenth, 0 → next 0 in the same row, spans 165 mm. The regular lattice therefore uses 13.75 mm per semitone step and 27.5 mm between neighbours of the same parity. The usable flat transverse width is 9 mm; the 10 mm body envelope includes estimated 0.5 mm shoulders. Form 4 length is 152.4 mm. Fitted depths, slopes, odd-key heights and mounting silhouettes retain their separate provenance in the seed. The previous local 5 mm gap is not imposed on every neighbour.

For admitted MIDI pitch p, translate its form by `(p - originMidiPitch) * 13.75` in x. Assign one actuator ID to that pitch and one body solid to that actuator. Create two distinct playable surface IDs: odd pitches use rows 1/3; even pitches use rows 2/4. The seed supplies each row's depth interval and affine height. Copy the form's complete top and mounting profiles for collision/display geometry. Do not create a separate actuator for each row copy.

The two large even-key terraces are **rows 2 and 4**. The short flat front tongue is **not intended to be played**. Keep the tongue, risers and rear tails in the body solid and exclude them from the playable patch list. Row numbers describe physical depth order, not a universal height ladder: both even terrace crests are at the same fitted height. The reported 15 mm rise is mapped to the front tongue/crest silhouette as a fitting assumption, not a measured height difference between rows 2 and 4.

Do not invent an instrument range: instantiate only the Viewer/operator-admitted MIDI range. The seed's origin at MIDI 60 defines coordinates, not a new pitch numbering system. Five-seven/classic display colors change no physical identity, trial ID or rating.

The ideal model uses a **common estimated 10 mm depression**, carried from the previously agreed nominal held-state reference. Its estimated rigid transform translates every surface of an actuator downward together. The seed also preserves the operator's earlier travel report: odd white keys close 75% of the gap to neighbouring even resting surfaces, even blacks travel 25% less than even whites, and odd blacks 25% more than odd whites. Those class differences describe the installation being regularized; do not put them back into the uniform ideal model or discard their provenance.

The common 10 mm value is the declared nominal reference, rather than a numerical empirical mean derived from the relative observations. Exact pivot/full-stroke motion remains unmeasured. `pressedMotion` distinguishes an estimated rigid transform, a measured rigid transform and unknown motion. Transform arrays are row-major 4×4 matrices acting on `[x, depth, height, 1]`; the seed's estimate has height translation −10 mm. Retain the reference and uncertainty status. A later measured transform does not certify a continuous motion or timing law, and the video alone supplies no mechanical bottom-stop measurement.

The geometry snapshot has its own identity and SHA-256. Recursively sort object keys with ECMAScript string ordering, preserve array order, serialize the result with ECMAScript `JSON.stringify` and encode UTF-8 without a BOM. Reject nonfinite numbers. Exclude `snapshotSha256` itself from the hash. `profileSha256` identifies the exact packaged seed bytes. A changed snapshot/setup starts new evidence rather than remapping old contacts.

## Four relative fingertip readings

Record pairs **1–2, 2–3, 3–4 and 4–5** with flat fingers in one declared forward reference frame. The signed value is the second fingertip's forward coordinate minus the first's. These effective reach differences are not bone lengths. All other relative forward differences can be derived by summing the adjacent differences in that same frame.

Keep the raw entry and its method. A millimetre difference can be recorded directly. A slider/window entry retains both fractions, window identity, reference and physical axis endpoints. Unknown endpoints remain null; percentages cannot become millimetres until that window is mapped. Do not mix differently oriented frames or turn a percentage into a finger length. Existing salvaged readings can be imported only with their original window/frame provenance and an explicitly verified mapping; otherwise retain them as unresolved historical evidence.

## Ten progressive pair sweeps

Pairs are 1–2, 1–3, 1–4, 1–5, 2–3, 2–4, 2–5, 3–4, 3–5 and 4–5. Measure each chosen arrangement once. Do not duplicate anatomically equivalent tests at translated row heights, both anchor roles or every parity copy.

Use flat fingers and a short static contact with **both keys depressed**. Let the player rotate/reposition the arm and hand between trials so the fingertip line is parallel to the keyboard. The pair trial has no held third contact and does not freeze the wrist or elbow. No trilling, repeated taps or travel rating is required. Retain the actual depressed key state in each contact; the resting mesh alone does not attest pressing.

For **every pair, including thumb pairs**, use same-parity keys on one shared physical row, chosen from rows 1 or 2. Record `rowPolicy: 'same-row'`, the exact chosen surfaces and the depressed key states, and keep the row consistent within that sweep. The former thumb-near/other-far rule is superseded for new collection. Its `thumb-near-other-far` tag and the prior `nonthumb-same-row` tag remain available for historical records; do not rewrite them as new same-row evidence. Opposite-parity playable surfaces do not share a height at the same front-to-back depth in this geometry. Do not demand parallel alignment by using a non-playable tongue.

Establish a **reachable starting arrangement before the outward sweep**. Suggest the smallest available same-parity span at least as large as the absolute pair reach difference derived from the four signed adjacent readings in their common frame. With 27.5 mm same-parity spacing, the initial semitone-step count is `max(2, 2 * ceil(abs(differenceMm) / 27.5))`, with no extra margin. For example, a 40 mm difference suggests four steps (55 mm). If known measurement uncertainty crosses a span boundary, include the shorter candidate by applying the rule to the smallest supported absolute difference. An unresolved reading supplies no millimetre cutoff; offer the player a setup choice rather than inventing a derived value.

This cutoff is a conservative setup estimate, not a guaranteed comfortable pose or an observed reach limit. Let the player widen the starting span until flat fingertips align comfortably on the chosen row with both keys depressed. Do not demand a bent finger or an extreme depth merely to close an implausibly narrow gap. The rated outward sweep begins only after that reachable baseline is established. Skipped narrower spans remain **untested**, not unavailable; setup difficulty must not create a grade-5 terminal or stop an outward sweep before its baseline.

Show increasing physical separations available on those surfaces. Preserve exact key/row identities and the actual signed pitch direction. RH finger order moves toward higher pitch and LH mirrors it toward lower pitch. Display interval counts in duodecimal; stored MIDI pitches and integer semitone-step fields retain their API encoding. “Next” means the next admissible target in the chosen arrangement, not a demand to test missing or duplicate geometry.

Rate **stretch**, with these six choices:

| Grade | Label | Meaning |
| --- | --- | --- |
| 0 | None or barely detectable | No stretch, or too little to distinguish meaningfully from relaxed fit. |
| 1 | A little | A small, noticeable stretch. |
| 2 | Moderate | Clearly stretched, with useful room remaining. |
| 3 | Large — little room left | A large stretch approaching the usable limit; this is the pair condition used for triple readings. |
| 4 | Only just reachable | Technically reachable, with essentially no useful margin. |
| 5 | Unavailable | The contact cannot be reached under the displayed test conditions. |

The grades are ordinal; they are not equally spaced costs. Grade 4 is reachable. The legacy effort grade 4 remains unavailable under its old protocol. Never transfer a grade by its number alone.

Offer an explicit **mark my maximum** action after a reachable result. End that sweep on the declaration or the first grade 5. Grade 4 alone does not silently claim that the next discrete target is unavailable. Save a terminal entry referencing the last reachable report and any actually observed first unavailable report. An operator stop or instrument/window edge is a different terminal reason. No termination fills the untested tail with grade 5.

## Contact regions and realizations

Each contact names a physical actuator, MIDI pitch, row, surface and key state. MIDI identifies neither the row copy nor contact depth. Use surface-local normalized u/v coordinates: u is left-to-right across usable width; v is near-to-far along that terrace.

The normal low-burden entry identifies the usable surface region the player actually tested. An optional displayed fiducial can retain its u/v location and player attestation; a measured point additionally retains its method and uncertainty. Do not relabel a displayed marker or an unmeasured region as a measured strike point. Do not force the player to supply point coordinates for every trial.

A reachable region-based rating means the player found a realization somewhere in the declared regions. It does not assign that grade to every point in them. Give that physical pair realization a stable identity. A grade-5 report has `realization: null`; its attempted contacts remain in the declared trial, without claiming that the player reached them. When a triple reuses a reachable pair's two anchor points, reuse that realization identity even if their precise coordinates are unknown. A fitter must tie those latent points across the records; it cannot choose fresh best-case anchor points independently for each triple. Precise points permit a precise contact triangle; region-only records constrain possible triangles.

Retain local contact coordinates and key state. A world point computed with the nominal pressed transform is modeled, with estimated motion provenance; it is not a measured pressed point or wrist angle. Unknown motion supplies no world pressed coordinate.

## Ten conditional triple slots

Triples are 1–2–3, 1–2–4, 1–2–5, 1–3–4, 1–3–5, 1–4–5, 2–3–4, 2–3–5, 2–4–5 and 3–4–5.

For sorted fingers `[a,b,c]`, select an actual grade-3 report from pair `[a,b]`. Reproduce that pair and its contact points, keep a/b at those same physical points, and move c outward on the pinky side to its last usable contact. Mirror pitch direction for LH. The anchors constrain the shared hand pose without introducing the old fixed-wrist rule. Do not slide either anchor to make the third contact available.

Declare each slot's searched row/surface window explicitly in `searchSurfaceIds`. Search that scope in the outward direction and save one boundary report: source pair observation ID, anchor realization ID and the remaining finger's last usable contact. An endpoint at the edge of the admitted window is `coverage-edge`, rather than an anatomical limit. A genuine reported usable limit is `usable-limit`. An optional actual grade for the whole configuration can be retained; the endpoint itself does not manufacture that grade or assume the source pair stays grade 3 after adding the third finger. No second inward-boundary trial or forced five-finger maximum is part of this run.

If the player tests the grade-3 anchor arrangement and finds no usable outward third contact in that window, record `conditional-triple-unavailable` with `no-usable-outward-contact` and the actual attempted contacts. This is an observed conditional result, not an omission or a fabricated reachable endpoint. Its scope is the declared window and tested arrangement; it is not a universal prohibition on the triple.

If the required pair never received grade 3, mark the slot `no-rated-anchor`. The Viewer may offer a focused pair recheck or placement adjustment and record it as another pair report. Do not substitute grade 2/4, interpolate a fictional grade 3 or silently add another triple slot. A skipped or unresolvable slot remains visible.

“Nearest anchor defines local stretch” remains a fitting hypothesis. The full held set constrains one common pose. Pair reaches cannot be optimized with incompatible rotations and then assembled as though jointly available. A boundary also does not certify every interior contact or configuration.

## Optional effective curl refinement

The [accepted hand model](hand-model-design.md) uses one effective PIP curl hinge for each non-thumb finger. Import `EFFECTIVE_CURL_REFINEMENT_CONTRACT` and the `EffectiveCurl*` types from the supported root package. Store an `EffectiveCurlRefinementDocument` separately from the stretch session, binding it to the same `playerId` and declared `hand`. This personal evidence can remain independent of keyboard placement; fitted defaults retain their actual source session identities. Do not insert new fields or phases into `stretch-calibration-session-v1`, interpret old notes as structured ruler readings, or collect a thumb hinge length.

Show a supplied hinge-to-tip assumption in millimetres as an **estimate**, including its basis and endpoint convention. `EffectiveCurlHingeAssumption` supports population-proportion, anatomical-template and fitted-geometry provenance. The population case records the actual external base-to-tip length, its measured/assumed/fitted status, proportion, optional proportion SD and source reference. Its denominator is specifically proximal-flexion-crease-to-fingertip; its hinge is a PIP-crease proxy. Other fitted/template assumptions identify their effective internal-hinge interpretation. These records are not personal measurements or proof of a joint centre.

An empty `assumptions` array means no estimate is available yet. A Viewer can build and complete the core collection before the fitter supplies one. The four relative fingertip differences are not absolute finger lengths and must not be used as the denominator of a population proportion. Do not fabricate a millimetre default to fill the editor. Accept an optional personal ruler reading even without a displayed estimate.

For fingers **2, 3, 4 and 5**, record an `effective-curl-length` entry with its stable ID/date, finger, positive finite `hingeToTipMm`, method, nullable uncertainty and the ID of the immutable assumption displayed at entry time, if any. The versioned method descriptor distinguishes:

| Method | Retained endpoints | Meaning |
| --- | --- | --- |
| `bent-section-effective` | External effective bend endpoint → fingertip | Bend at the middle knuckle and flatten the outer section against a surface or another finger before measuring. This is an effective external length. |
| `pip-crease-to-tip` | Visible PIP flexion crease → fingertip | Retain the crease-based convention; it is not silently converted into the bent-section method or an internal joint-centre measurement. |

This is an optional geometric refinement, not another stretch judgment. Save personal readings and supplied assumptions separately. Assumptions and entries are append-only: a new fitted default gets a new assumption ID; a new personal reading gets a new entry ID. A retraction references an earlier measurement entry, not an assumption, retraction or future entry. The original measurement and displayed assumption remain in the document. Retractions themselves are immutable. The latest nonretracted measurement in ledger order for a finger is its current personal override; otherwise use the latest supplied assumption for that finger in assumptions-array order, or report the estimate as unavailable. These orders are authoritative even when import order differs from `recordedAt` order.

Companion admission checks the document and every assumption version, nonempty IDs/player binding, `LH`/`RH`, fingers 2–5, finite positive lengths, supported method/basis tags, valid dates, global uniqueness of assumption/entry IDs and earlier-measurement retraction targets. A non-null `displayedAssumptionId` must identify the same finger's supplied assumption, recorded no later than that reading. Supplied default lengths and external base lengths must be positive finite values; proportions are finite and strictly between 0 and 1. Known uncertainties/SDs are finite and nonnegative; null retains unknown precision. Preserve fitted/template/source references. Never relabel an assumed or fitted value as measured. Geometry fitting interprets these endpoint-specific observations; the Viewer does not silently relocate an internal pivot.

Authored JSON example, not an operator reading:

```json
{
  "version": "effective-curl-refinements-v1",
  "id": "example-curl-evidence",
  "playerId": "example-player",
  "hand": "RH",
  "assumptions": [],
  "entries": [
    {
      "kind": "effective-curl-length",
      "id": "example-index-reading",
      "recordedAt": "2026-10-12T00:00:00Z",
      "finger": 2,
      "hingeToTipMm": 43,
      "method": "bent-section-effective",
      "uncertaintyMm": null,
      "displayedAssumptionId": null
    }
  ]
}
```

## Wire format, input and persistence

Import `STRETCH_CALIBRATION_PROTOCOL`, `STRETCH_CALIBRATION_GRADES`, `STRETCH_CALIBRATION_KEYBOARD_PROFILE`, `STRETCH_CALIBRATION_PROFILE_SHA256` and the `StretchCalibration*`/observation types from the supported root package. `StretchCalibrationSession` is the wire format: immutable plan/setup/geometry, incrementally registered pair targets, append-only entries and a cursor.

The new descriptor/types/seed are shipped. A new adaptive collector, six-grade input router and runtime session validator are **not** exported by this handoff. The Viewer builds those operations against this contract; do not call an old validator/router with the new session or falsely import a proposed function. Calculator fitting can subsequently admit the same wire format without a Viewer-specific translation.

The optional companion descriptor and wire types are also shipped. No companion validator, assumption generator or hand fitter is exported. Supplied assumptions may come from a later calculator fit or an explicitly documented template; current absence of fitting output must not block collection. The installed package includes this contract, its geometry seed and the referenced hand/cost/philosophy documents.

Six on-screen choices, `Digit0..Digit5` and `Numpad0..Numpad5` enter the same grades. When MIDI is connected, computer and screen input remain available. A new MIDI handler can use complete control blocks at pitch classes **0, 2, 4, 6, 8, A**, mapping to grades 0–5. Its whole 0..A range must be on the admitted instrument and outside the tested span, including anchors and source contacts. This is separate from the five-control legacy router. Test-note events remain ignored and are not playing evidence.

One down event commits at most one judgment. Require all held controls to release before advancing again; OS repeats, repeated note-ons and simultaneous control chords cannot rate subsequent targets. Velocity-zero note-on is release. Channels remain 0–15 in the wire format. Gate input while persistence is pending and commit against the current trial ID. Persist before showing the next target. Keep input state across advances; reset it on disconnect, focus loss or session replacement.

Resume restores entries and progress but asks the player to reproduce the current test contacts before continuing. Retractions reference stable entry IDs, retain dates/reasons and preserve the original reports. Retractions themselves are immutable and cannot be retracted; a new replacement report/terminal/omission restores the intended effective state. The latest nonretracted pair report in ledger order for a `trialId` is its effective rating. A later report for that trial is a revision, even if its grade is unchanged. It retains the trial's fingers, actuators, surfaces and key states; the realized location may narrow the declared target region without silently changing the tested contacts.

Triple admission checks **structural validity** against the linked original pair entry: it existed, actually reported grade 3 and supplied the named anchor realization. Current applicability is a separate ledger calculation. If that source report is retracted, derive `basis-withdrawn`; if a later effective report revises that trial, derive `basis-revised`. The old triple must still load and retain its original link, with its basis flagged for review. Do not silently relink it or delete historical evidence. Editing a sweep maximum reopens only its actual unfinished targets and does not rewrite unknowns as results.

Viewer admission must check versions, finite numbers, dates, unique IDs, hash/geometry binding, surface and actuator references, valid u/v ranges, finger order, two distinct intended contacts per pair, row policy, scale/input agreement, current-trial binding, terminal references, searched triple scope and the original grade-3 dependency. Retraction targets must be earlier reports, terminals or omissions, never retractions or future entries. Reject the tongue as a fingertip contact. A deliberate omission is not unavailable. An incomplete ledger is a valid saved session with incomplete coverage.

## Viewer delivery and export

The existing Viewer session owns this screen and its persistence. Its build should deliver the following:

1. Instantiate the admitted regularized keyboard geometry, preserve hash/setup/player/hand binding and display the actual tested surfaces.
2. Collect the four common-frame relative readings, adaptive pair sweeps and linked conditional triple slots with the scale, terminal reasons and ledger semantics above.
3. Keep screen/manual input available alongside MIDI; release-gate controls, save before advancing, and reproduce contacts on resume.
4. Offer the optional refinement editor with honest estimate availability, method selection, separate companion persistence and reversible personal readings.
5. Show actual completion/omission/coverage states and export the complete `StretchCalibrationSession` JSON. If a companion exists, export its `EffectiveCurlRefinementDocument` JSON as a separate document for the same player and hand. Include raw observations, references, geometry snapshot and history; do not export only a fitted summary or remap into a score format.

The delivery order is **updated contract → Viewer collection → operator values → personal fitting and new calculator proposal → operator tries refingered Schumann 14**. Schumann 14 is the agreed first practical validation target. New readings do not make the compatibility planner an implementation of the accepted model; the architect develops and validates the new metrics/search in parallel. Preserve source fingers, calculated proposals and personal corrections throughout.

## What calculator work can start now

Work can start on sloped surface mathematics, contact/actuator identity, calibration admission and lookup interfaces, a joint hand/finger/contact state, bounded gesture search, source duration/hold/timing preservation, release representation, travel calculations and honest diagnostics. Synthetic calibration fixtures can exercise those boundaries without pretending to describe the player's hand.

The player's measurements are needed to fit and validate the personal relaxed/stretch model and its rankings. The static collection does not establish a movement-speed law or the numerical exchange between stretch and travel. The [route cost design](route-cost-design.md) records the accepted starting choices: distinct local departure over required time, shared hand motion, economical execution and adjustable `4S + 3kM` weights. Automatic ranking excludes inferred fatigue/recovery and repetition-driven rest redistribution. Keep fitting, reference scales and directional/rotational movement metrics explicit and revisable; do not use equally spaced grade numbers or inherited planner heuristics as a shortcut. Real predictions should then be checked on withheld shapes/transitions, with a visible candidate hand/keyboard pose when a failure needs explanation.

This contract does not change the shipped calculation request, calculated fingers, score formats, saved personal corrections or the Viewer's dependency. The Viewer implementation is the next separate change.

# Accepted initial hand model

Agreed 2026-10-12, reconciled with [playing philosophy version 23](playing-philosophy.md), the sole active authority. This design records the initial geometry and fitting architecture; it is not an exported implementation, a new calibration wire format or a personal hand already fitted from observations.

## Shared geometry and combined reach

Use one compact effective articulated hand per declared hand/setup. Its personal geometry includes finger attachment locations and effective reaches. Its changing configuration includes opening and curling, under one shared palm position and orientation. An anatomical template initializes geometric quantities that the observations leave unresolved; it does not add a preference for commonly photographed poses or restrict candidates to a fixed set of grasp shapes.

For finger i, the geometric relationship is:

```text
world fingertip i = palm translation
                  + shared rotation × local fingertip i(configuration; personal geometry)
```

All required contacts must be satisfied by that same configuration and rotation on the admitted playable keyboard surfaces, with their actual key state and motion provenance. The geometry and the permitted combinations of finger arrangements are separate model components. A geometric skeleton with independent per-finger limits does not by itself establish a realistic combined reach.

Opening a straight flat finger changes its forward projection as well as its transverse position. Preserve that effect in the geometry. The reference forward differences must not be frozen across opening or interpreted as measured segment lengths.

The nearest-anchor idea supplies the initial local departure assessment. The full required contact set constrains which local arrangements can coexist. A third or fourth contact may remove a rotation that would make an isolated pair comfortable. Do not assemble independently optimized pair configurations into a purported whole hand.

Held fingertips constrain contact points, not a frozen wrist or palm. Compatible palm translation, rotation and internal shape changes may continue while those contacts remain fixed. Retain multiple compatible arrangements when they offer different preparation opportunities for the following notes. Each candidate carries its contacts, configuration and corresponding departures together.

## Joint fitting of the reduced readings

Admit observations through the existing [stretch calibration contract](calibration-contract.md), retaining its setup, hand, geometry snapshot, surface regions, key states and append-only evidence identities.

| Input | Role in the fit |
| --- | --- |
| Four signed relative fingertip readings | Constrain forward differences in the declared reference arrangement, up to a common offset. |
| Ten progressive pair sweeps | Constrain realized pair separations and ordinal stretch bands under the displayed arrangement and free useful alignment. |
| Ten conditional triple slots | Constrain the remaining finger's sampled outward boundary under the source pair's two fixed physical anchor points. |

Fit these together rather than choosing fresh personal geometry for every observation. Region entries retain latent contact points inside the recorded regions. Linked pair and triple observations share the same anchor points, including when their coordinates remain latent. Their internal configurations and rotations may differ; adding the third finger does not automatically preserve the original pair's grade 3.

A region-based rating attests a realization, not the same grade at every point in that region. An unavailable report supplies no reached realization. Coverage-edge endpoints, omitted slots and retracted or revised evidence retain the meanings of the wire contract. Do not fit a searched-window edge as an anatomical maximum or synthesize unavailable tails.

The lowest stretch band defines a relaxed range. Ordinal grades are not equally spaced numerical costs. Preserve materially different fitted explanations when they change predicted fingering choices. Larger-group and additional-location predictions are validation cases, not measured coverage inferred from the existence of this model.

## Initial curling approximation

Use one effective internal curl hinge at the PIP of each non-thumb finger. The PIP is the first of the two interphalangeal joints when moving outward from the palm, commonly called the middle knuckle. The distal portion is one effective segment. Treat the thumb as a unit whose base can orient it. Other anatomical joints exist; the first model omits their independent internal articulation.

Bending coordinates implement the contact geometry needed by an assignment. They do not prescribe the pianist's key-depression technique or introduce a separate qualitative penalty for curling.

Initialize the effective hinge with a documented proportional estimate or fitted geometry, show that assumption, and permit a direct personal hinge-to-tip override. The operator agrees that ordinary uncertainty should first be handled as an optional refinement, with the effect on actual predictions checked before requiring more readings.

### Population evidence and endpoints

[Li et al. (2019), Table 2](https://faculty.sustech.edu.cn/wp-content/uploads/2024/02/2024022216315442.pdf) reports segment ratios in 261 participants aged 5–70. Its external finger length is measured from the proximal flexion crease to the fingertip. Its proximal segment ends at the middle flexion crease, used here as a PIP proxy. Complementing the reported proximal fractions gives:

| Finger | PIP crease-to-tip / external finger length | SD of that fraction |
| --- | --- | --- |
| Index | 0.614 | 0.028 |
| Middle | 0.620 | 0.027 |
| Ring | 0.638 | 0.031 |
| Little | 0.634 | 0.034 |

These are calculated complements of reported mean ratios, with their unchanged SDs. For a 70 mm index finger under those endpoints, the estimate is 42.98 mm; the ratio SD corresponds to 1.96 mm at that length. This is not a reported conditional regression error or a guaranteed individual error bound.

[Hamilton and Dunsmuir (2002)](https://pubmed.ncbi.nlm.nih.gov/12475513/) instead reports an approximately 1:1 relationship between MCP–PIP and PIP–tip distances using anatomical joint-centre information. Retain that separate endpoint convention. The visible base crease is not the anatomical MCP centre, so the two proportions must not be interchanged.

These findings support a proportional starting approximation, not a directly established Pearson correlation for our prediction. A crease-to-tip ratio is not a precise measurement of the internal rotation centre. The four relative fingertip-offset readings also do not provide the absolute length required to apply an external base-to-tip ratio. Defaults must retain their length definition and source; fitted absolute geometry remains inferred geometry.

### Optional personal measurement

Show the estimated effective hinge-to-tip length in millimetres and identify it as an assumption. Allow the player to supply an alternative millimetre value and retain the measurement method and endpoints. A personal value refines the fitted geometry; it does not silently rewrite the original pair/triple observations.

The operator proposes bending at the PIP and straightening the outer section against a flat surface or another finger, then measuring that section's straight effective extent. This helps the player identify the endpoint through the bend instead of estimating it from a crease on a fully straight finger. The operator also observes a possible difference of a few millimetres between that effective endpoint and the main visible crease. Record this as operator observation, not a population bias estimate or proof that the bent endpoint locates the internal joint centre.

The first design does not require these extra readings. A bent-section reading and a crease-to-tip reading retain different method provenance; neither is relabeled as an exact internal joint-centre measurement.

The `stretch-calibration-session-v1` remains unchanged. The root-exported `EFFECTIVE_CURL_REFINEMENT_CONTRACT` and `EffectiveCurlRefinementDocument` now provide optional, separately versioned personal evidence with supplied assumptions, ruler-method provenance and measurement/retraction history. The [Viewer handoff](calibration-contract.md) specifies its editor, validation and persistence. Existing session notes must not be silently reinterpreted as structured anatomical measurements. No fitter/companion validator or override screen is supplied by these types, and no new mandatory Viewer trial is added.

## One route through time

Stretch cost accrues over its necessarily maintained duration through distinct required local contributions. Do not count one thumb departure separately through every widened pair distance. The numerical mapping from observed bands to local rates remains to be fitted; provisional endurance anchors do not establish that mapping. Opening and closing also require movement and time, assessed within the same route as hand transport and required finger travel.

Shared palm transport/rotation is one common movement requirement, with required local changes assessed relative to that moving palm. A carried finger can reach its target without additional local repositioning. Conversely, a stationary fingertip may need compensatory local motion when the palm moves. Keep these effects inside the shared representation rather than adding a named position-change cost. Shared motion can preserve a stretched shape, so preserving internal geometry does not erase existing departure.

The operator's arpeggio example motivates a shared timeline: prepare approaching contacts through partial expansion, travel onward while relaxing that spread, then prepare the following span. Keep those changing configurations together. Do not charge the entire future span as a continuously held static spread or combine stretch and travel minima requiring incompatible schedules.

Preparation must respect genuine holds, admitted releases and future attack deadlines. An unused finger's exact trajectory remains free unless the route relies on a particular preparation. A release needed to enable movement retains the playing philosophy's musical admission rule and performer obligation. Internal candidate poses support feasibility and comparison; they are not an exact movement schedule imposed on the pianist.

Compare economical feasible realizations, including relaxation and reopening during a usable gap when saved departure cost outweighs added movement. Those phases may overlap with transport. Do not inflate a fingering's required cost because a player might voluntarily maintain unnecessary stretch. Do not add inferred fatigue/recovery state or repetition-driven rest redistribution to fitting, automatic ranking or feasibility. The [route cost design](route-cost-design.md) records the accepted accounting, release policy, numerical starting choices and remaining mathematical work.

## Implementation and validation boundaries

Personal fitting needs the player's new observations. Geometry admission, shared-pose solving and consistency checks can be developed with synthetic readings first. No reduced-data sufficiency theorem, unique skeleton or continuous-motion certificate is established here.

The first implementation should expose the inferred geometry, hinge assumptions and observation binding; solve required contact sets consistently; retain their departures and alternative compatible arrangements; and permit separately recorded personal hinge refinements. It must preserve the distinction between observations, population defaults and fitted parameters.

Check predictions on comfortable configurations withheld from fitting, including larger groups and arrangements that stress different rotations. Vary hinge estimates within realistic source uncertainty to determine whether extra precision changes the predicted route. Investigate a consequential failure with a visible hypothetical hand and keyboard: distinguish geometry error, missing combined-reach constraints, incorrect costs and search coverage. Any extra measurement should resolve an identified consequential uncertainty rather than silently extend mandatory calibration.

The remaining technical work is the local departure-rate mapping, reference scales, directional/rotational movement law, subdivision-consistent route functional, release-policy binding and bounded route search. The playing principles and release default are agreed. Personal parameters need the new calibration observations; predictions and computational performance remain to be fitted and validated. Existing calculator behavior, APIs, source facts, Viewer dependencies and calibration sessions remain unchanged.

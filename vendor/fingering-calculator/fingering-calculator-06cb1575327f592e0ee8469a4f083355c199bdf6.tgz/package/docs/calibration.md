# Geometric calibration core and viewer handoff

For the next collection, use the [stretch calibration contract](calibration-contract.md). Its six-choice stretch scale, static progressive sweeps, conditional triples and sloping geometry have distinct identities. The package supplies that wire contract; the Viewer implementation follows separately. The [bounded fixed-frame pilot](calibration-pilot.md) and unrestricted v1 API below remain historical collection APIs with their original grades and validators. Do not relabel their saved observations or use their five-choice router for the new protocol.

The unrestricted generator below can describe millions of human judgments. Paging bounds computation, not the player's workload. Do not use it as the default calibration schedule. Its historical grade wording, free wrist-adjustment cue and uniform-surface interpretation do not describe the fixed-frame exploratory protocol.

The root package supplies a separate, versioned data-collection API under the [playing philosophy](playing-philosophy.md). It does not feed these ratings into either shipped compatibility calculator. The Score Viewer owns its existing calibration screen, MIDI connection, rendering, persistence and application activation.

## Measurement boundary

Assign one of five ordered work grades to each tested configuration: **0** perfect relaxed alignment; **1** not perfect; **2** possible if necessary but unwanted; **3** hope never to need; **4** never an option in this tested context. These are categories, not equally spaced costs. Untested configurations remain unknown. A grade 4 does not prohibit every use of that finger pair elsewhere.

The model provisionally applies the measured grade equally throughout each key's declared usable surface. A zero means the pianist found a relaxed realization. Surface contact locations are left to the pianist. `calibrationWorkAt` reports that assumption and refuses queries outside usable patches; it does not infer anatomical exclusions. `calibrationSurfaceDistance` returns the optimistic minimum distance between surfaces, including resting/held height. Independent pairwise minima do not certify a jointly realizable trajectory across a gesture.

Retain the hand, station, physical keyboard identity/provenance, actual keys and rows, starting contacts, anchors, active finger group, test patterns, anchor behavior and pace. Unused fingers acquire no invented starting contact. Group grades are measured directly, not assembled from pair grades. Combined pressing means tested contacts are pressed together. With `anchorBehavior: 'held-throughout'`, anchors remain down during the trill/tapping pattern: one active finger taps repeatedly; multiple active fingers alternate. Set `participate-in-trill` explicitly when anchors alternate with active contacts. These are distinct trial identities, not interchangeable evidence of a held-anchor transition. The player judges the displayed configuration and reports the completed patterns. MIDI serves only as rating input; test-note messages are ignored and never collected as evidence.

## Stations and provisional endpoints

`createCalibrationStations(hand, crossBodyXmm, outwardXmm)` produces four positions: two measured endpoints and two equal subdivisions between them. The RH cross-body endpoint lies left of its outward endpoint; LH mirrors that order. Neither endpoint is fixed at middle C. Preserve body-midline/setup provenance and keep the hands separate. Interior positions are interpolated; work grades are not inferred or numerically interpolated by this collection API.

Endpoint selection is **provisional**. `CalibrationEndpointEvidence` records exact reference contacts and levels, a description of the selection activity, and any actual reports of neutral wrist, forward-facing torso or comfort. The API does not insist on a universal thumb–index pair, equal references at both ends, or a certified reach boundary. Cues ask the pianist to begin with the hand aligned to the forearm and torso facing forward, avoid strain or excessive reach, and allow tested combinations to demand departure from that starting alignment. Absent optional reports are not manufactured as `true`.

After collecting raw data, investigate:

- Which level-specific Jankó or conventional white/black reference tests define useful endpoints, and what those endpoints tell us.
- Which redundant or obvious no-go trials can be omitted without losing useful information.
- Whether a fitted hand model predicts proximity limits, direction-sensitive limitations and within-key excluded regions from existing measurements.
- Whether interpolated regions need inexpensive disambiguation drills.

No anatomical pruning, automatic group exclusions, fitted model, grade interpolation or extra disambiguation phase is implemented yet.

## Physical geometry and trial pages

Coordinates use millimetres and MIDI pitches, independently of legacy normalized coordinates/pitch numbering. The new `CalibrationKeyboard` must not replace the old `CalculationRequest` keyboard selection. Changed geometry/setup needs a distinct identity and new evidence; historical RR observations are not remapped.

`createIdealJankoCalibrationKeyboard` builds an ideal uniform four-row instrument from declared dimensions. Physical rows retain established near-to-far numbering: odd pitches in rows **1/3**, even pitches in **2/4**; each pitch has lower and upper copies. Initial width estimates are **9 mm usable**, **0.5 mm margin per side**, **10 mm body**, and a **5 mm body gap horizontally to the nearest opposite-parity neighbour**. That gap convention implies a 15 mm nearest opposite-parity centre offset. Row depths/heights, usable depth and key travel are explicit profile inputs. There are no hidden RR tape, key-specific height or activation-depth adjustments. Supplied dimensions are labelled nominal, not measurements. `createConventionalCalibrationKeyboard` builds conventional front/back surface patches from declared dimensions. A caller may instead supply a validated measured descriptor with actual usable patches.

`calibrationKeyboardScene` supplies usable surfaces, nominal body-top footprints, resting/held heights, pitch, identity, row/level and color. Body margins support display/clearance descriptions and do not enlarge the playable surface. Jankó defaults to five-seven and supports classic colors; conventional always uses classic. Colors change no identity or work grade. Render enough surrounding keys for visual orientation and overlay anchor/active indicators on the corresponding surfaces. No exact strike point is prescribed.

Each plan lists four stations per included hand and a neighborhood at every station. An origin is the physical key nearest the requested horizontal coordinate. Jankó origins must include both levels of the same pitch, as must each neighborhood pitch. Neighborhoods define sampling coverage, not universal reach restrictions. The generator enumerates every finger's anchor role, multiple anchors, every nonanchored active subset, and distinct key assignments in the window. It includes unanchored baseline groups. Anchored trials contain the origin under each possible pivot finger. Their starting contacts are anchors; extra actual starting contacts can be supplied in a separately identified explicit trial.

The complete product can be large. `calibrationTrialCount` returns an exact decimal-string count. `calibrationTrialPage` seeks directly by decimal-string offset and returns at most 1,000 trials. It neither materializes the product nor replays preceding pages. Save `nextOffset` with the viewer queue. Null page offset means enumeration ended; null session current trial means the registered queue was rated. Neither proves all human measurements completed. `appendCalibrationTrials` deduplicates identities.

## Viewer integration

Import only from `@hypermemetic-ai/fingering-calculator` and pin the reviewed Git revision. Built JS/declarations ship without install scripts or runtime dependencies. Build the plan from the admitted profile, provisional endpoints and sampling windows. Record endpoint evidence before creating the session:

```ts
import {
  createCalibrationSession, appendCalibrationTrials, calibrationTrialPage,
  createCalibrationInputRouter, recordCalibrationObservation,
  validateCalibrationSession, navigateCalibrationTrial,
  type CalibrationPlan, type CalibrationProvenance,
} from '@hypermemetic-ai/fingering-calculator';

declare const plan: CalibrationPlan; // admitted geometry, four stations, neighborhoods
declare const provenance: CalibrationProvenance; // setup and provisional endpoint evidence
let session = createCalibrationSession('personal-calibration-1', provenance, plan);
const page = calibrationTrialPage(plan, { offset: '0', limit: 32 });
session = appendCalibrationTrials(session, page.trials);
const router = createCalibrationInputRouter();
const current = session.trials.find(t => t.id === session.currentTrialId) ?? null;
const result = router.route(
  { kind: 'manual', type: 'key-down', code: 'Digit0' },
  { keyboard: plan.keyboard, trial: current, midiConnected: false },
);
if (result.kind === 'rating') {
  session = recordCalibrationObservation(session, {
    trialId: result.trialId, grade: result.grade,
    recordedAt: new Date().toISOString(), input: result.input,
    // Attest patterns actually performed; grade 4 may have no completed patterns.
    evidence: { patternsPerformed: current!.task.patterns },
  });
}
const saved = JSON.stringify({ session, nextOffset: page.nextOffset });
session = validateCalibrationSession(JSON.parse(saved).session);
session = navigateCalibrationTrial(session, session.trials[0]!.id);
```

Connected input accepts **any** C–G♯ block on the declared instrument whose entire `0..8` range does not intersect the tested contact span. No register is armed or reserved. MIDI pitch classes **0, 2, 4, 6, 8** map to grades **0, 1, 2, 3, 4**. The span includes starting, anchor and target contacts. A block between widely separated tested contacts is excluded even when its notes are not struck. A helper may enter ratings above or below the tested hand. Physical duplicates share MIDI pitch, so both copies are excluded as controls for a tested note.

Computer codes `Digit0..Digit4` or `Numpad0..Numpad4` are **always accepted**, with identical rating/advance behavior. When MIDI is connected, both MIDI and computer-keyboard ratings remain available concurrently; connection must not disable keyboard entry or select an exclusive input mode. When disconnected, only MIDI entry is unavailable. Manual entry never synthesizes piano events. This applies to both keyboard types.

One control key-down accepts one judgment. All held controls must be released before another rating advances the queue. Repeated control note-ons, OS repeats and simultaneous control chords cannot silently grade following trials. MIDI velocity-zero note-on means release. The router returns only `rating` or `ignored`. Test-note events and other nonrating messages are ignored; no playing timeline, attack/release measurement or MIDI note evidence is stored. Channels are zero-based **0..15**. Only the entered judgment carries its recording date.

Keep the router alive across auto-advances; do not recreate it per trial. Call `reset()` on disconnect, focus loss or session replacement to clear lost key-up state. The viewer handles keyboard focus/text-field shortcuts before calling it. Commit against the returned trial ID; stale commits are refused. MIDI listeners, storage I/O and rendering belong to the viewer. The core installs no browser globals, listeners, server, device connection or storage implementation.

`recordCalibrationObservation` appends history and advances to an unrated registered trial. `navigateCalibrationTrial` revisits earlier results. `retractCalibrationObservation` undoes a rating with an auditable reason and restores a prior judgment or unknown. `validateCalibrationSession` admits saved data and returns a detached copy. Public session operations preserve caller data. `calibrationCoverage` distinguishes registered/rated/untested counts, revisions/retractions and the exact larger planned product; it reports no inference.

This first pass preserves raw data. No new scalar fingering objective, release policy, TUNA format, planner migration or Viewer dependency change is included. Written durations, genuine physical holds, and agreed listening/release criteria remain source/planning concerns, not invented calibration observations.

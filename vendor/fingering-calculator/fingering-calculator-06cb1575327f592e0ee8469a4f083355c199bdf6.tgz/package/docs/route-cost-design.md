# Accepted route cost principles and technical follow-up

Agreed 2026-10-12 under [playing philosophy version 23](playing-philosophy.md), the sole active authority. This document records confirmed accounting and numerical starting choices, recovered release policy, independent search research and remaining architect-owned work. It does not implement a replacement planner, extend calibration wire types or change the Viewer. The [hand model design](hand-model-design.md) supplies the accepted shared geometry and fitting assumptions.

## Economical execution of one coherent route

For a fundamental hand/finger/physical-contact assignment `A`, the mathematical target is:

```text
J*(A) = infimum over feasible coherent routes gamma of
        4 * S[gamma] + 3 * k * M[gamma]
```

Feasibility includes the source musical obligations, actual keyboard surfaces/key states, coupled hand geometry, admitted physical releases, genuine holds, repeated-attack reset and attack deadlines. The same route determines stretch and movement. Preceding contacts and following preparation remain relevant across notation boundaries.

This target assumes economical execution. A player who preserves an unnecessary spread through a usable gap does not thereby make that fingering intrinsically more demanding. Compare maintaining the spread with relaxing, transporting and reopening, allowing the phases to overlap. A long gap can make the latter cheaper; tight timing can favor preserving the spread. Internal witnesses establish available realizations rather than an exact technique imposed on the performer. Selected movement-required releases remain performer obligations.

## Whole-hand aggregation

`S` sums distinct required local departure rates over their necessarily maintained durations. The nearest held anchor supplies an initial local relationship, while one compatible whole-hand configuration and the entire contact set determine the required departure. Pair/triple ratings constrain that fit; they are not independent costs to sum over every pair. With central fingers anchored, one outward thumb departure is not duplicated by each widened thumb-to-other-finger distance. A distinct outward little-finger departure adds its own contribution.

`M` assesses shared hand transport/rotation once and adds required finger changes relative to that moving hand, conditioned on direction, held contacts and available time. For thumb and middle attacking together, releasing and then reaching contacts shifted by one compatible diagonal displacement, the shared transport can carry both. The middle then has no additional local repositioning cost. A ring initially over the destination cannot be treated as stationary and free if the same palm movement requires it to compensate locally.

Pure shared transport preserves internal geometry; that geometry can already be stretched. Shared rotation incurs movement, and any actual departure from relaxed geometry/alignment incurs `S`. Static freely aligned pair trials establish neither the dynamic turning price nor a universal wrist-rotation penalty. The movement metric must account for angular as well as translational requirements without multiplying common motion by the number of carried fingertips.

A comfortably prepared middle can avoid index relocation. When the middle would require stretch, a sufficiently unhurried relaxed-hand relocation can instead be cheaper. Neither zero movement nor zero stretch alone decides the assignment. Distinct outcomes follow from the combined cost on the complete route, not a finger-preservation or position-change tie-break.

Exact local rate inference, rotation/translation reference scales and residual-motion aggregation remain to be formalized and validated. Geometric compatibility must survive this accounting; independently optimized pair poses cannot be assembled into a purported hand.

## Numerical starting choices

Use `4S + 3kM` as the provisional combination after establishing comparable reference scales. At `k = 1`, movement receives 75% of the stretch coefficient. A positive `k` represents the player's current controllable movement and stays fixed across every candidate in a calculation. Adjust it against observed problems; do not assign it from a universal beginner/expert label or predicted exhaustion. Its value is a model preference, not a measured physiological conversion.

[Fuglevand et al. (1993)](https://pmc.ncbi.nlm.nih.gov/articles/PMC1175228/) measured resisted index-finger abduction at 20%, 35% and 65% of maximum voluntary force, with mean endurance of 534, 246 and 66 seconds. Reciprocal endurance normalized to the first condition gives `1:2.1707:8.0909`. The operator accepts the simple provisional rounding `1:2:8`. These are three experimental load anchors, not numerical values assigned automatically to the five geometric stretch bands. Mapping geometric departure to this proxy curve remains a visible assumption; the source does not equate span with force or establish the normalization of `S` against `M`.

Automatic calculation excludes predicted fatigue, recovery debt, repetitive attack-count burden and speculative redistribution for rest. The operator's rationale is that an incorrect exhaustion assumption can impose unneeded fingering changes with learning, memory and reliability burden. Personal edits can manage actual endurance limitations. This boundary does not add a fingering-change penalty. Necessary stretch still incurs cost over required time, and physical key actions/releases/resets remain genuine obligations. Research on local fatigue and recovery is retained as evidence, not an active ranking model.

## Admitted release timing

The operator's 2026-10-11 listening decision, made after philosophy version 20, settles the ordinary full-held/no-intended-pedal default: permit movement-required release after 75% of the relevant attack-to-attack connection interval, at all speeds. This is an admitted practical policy under the generally attentive listener criterion, not a universal psychoacoustic threshold.

Supported articulation can shorten required holding. Intended pedal connection can permit release after a brief actual activation. Explicit physical-hold requirements, written durations, ties, independent voices and physical reset constraints remain intact. Bind each connection to its appropriate source timing rather than selecting an unrelated next event in another voice. The selected route may rely on a particular admitted release, which the performer must honor.

The physical activation floor and articulation-specific reductions need explicit technical values. Earlier illustrative fractions were not adopted as defaults. No new auditory classifier or extra mandatory player trial is required by this decision. This capture changes no shipped hold behavior or source format.

Recovery provenance: parent thread `24d62cbd-885e-4589-a558-9104d1ea19bb`, operator items `migration:v1:turn-item:4f49aa4c-dea4-4d2f-a74b-dc2358fa32a8` (75% at all speeds) and `migration:v1:turn-item:62337b00-4065-4b76-9ab5-f2a414fc5525` (attack-gap, articulation and intended-pedal clarification). The numerical decision followed the version-20 revision; later documentation had omitted it rather than revoked it.

## Mathematical search research

Two independent read-only investigations considered event-boundary search and continuous-motion approximation. Their results are recommendations and conditional proofs; they are not a delivered solver or a global physical-optimality claim. The architect's starting direction is a bounded search over prepared configurations, connected by coherent continuously validated segments, using joint trajectory optimization to generate and improve witnesses.

Contact identity alone is not sufficient state. Retain active source obligations/assignments, actual prepared shared/internal configurations, consequential contact points, key/action state and reset clocks, and any additional memory required by the chosen movement functional or continuation constraints. Inferred fatigue/recovery state is excluded. Unused fingers remain free where their paths are not relied upon; internal preparation states do not authorize imaginary compulsory motion charges.

A more expensive prefix reaching a better preparation can have a cheaper feasible suffix. Similarly, the locally cheapest interval realization can leave an inferior endpoint configuration. An interval interface must therefore retain endpoint-state/cost alternatives or a value function conditioned on those states, rather than return one scalar minimum for an assignment. Lower accumulated cost dominates only when continuation-relevant state is identical, or when a separate valid dominance proof applies.

Shared contact constraints must hold throughout a segment. Individually feasible endpoint poses do not establish a feasible interpolation. A held fingertip may permit the palm to rotate along an arc while forbidding the straight chord between endpoints. Continuous connectors and validation must preserve holds, coupled reach, exact attacks and reset obligations.

The same physical route must receive the same cost when an artificial sample boundary is inserted. Primitive state flows and costs need the composition rule:

```text
flow_ab(x) = flow_b(flow_a(x))
cost_ab(x) = cost_a(x) + cost_b(flow_a(x))
```

An arbitrary per-sample sum of `distance / sample_duration` fails this condition: splitting a constant-speed motion into `n` equal pieces multiplies its score by `n`. Use a declared additive route density, or retain the actual movement episode in state without treating numerical subdivisions as new reaches. For a state-independent constant-speed density, a subdivision-consistent endpoint expression has the form `T * psi(distance / T)`. The illustrative `distance^2 / T` corresponds to integrated squared speed; it is not a selected physical cost law. Preserve the empirical distance/time consideration while making the chosen accounting compositional.

For `k > 0`, independently minimized stretch and movement provide a valid lower bound:

```text
inf_gamma (4S[gamma] + 3kM[gamma])
    >= 4 * inf_gamma S[gamma] + 3k * inf_gamma M[gamma]
```

The two minima may require incompatible routes, so that bound is not an achievable combined route. Conversely, a continuously validated feasible witness supplies an upper bound on the necessary assignment cost. A local trajectory optimizer does not supply a global lower bound. Comparing witness scores alone leaves optimization uncertainty; `upper_A < lower_B` establishes a comparison only under the declared model and bound scope.

A best-first branch-and-bound search can retain an incumbent upper bound and lower bounds covering every unresolved represented alternative. If coverage is preserved, their gap bounds suboptimality in that represented problem. Discarded beam entries, unsolved connectors, omitted pose regions and release-time samples must not silently disappear from the certificate. Continuous optimality additionally needs valid coverage/bounds over omitted continuous regions. The foundational graph-search formulation is [Hart, Nilsson and Raphael (1968)](https://ai.stanford.edu/~nilsson/OnlinePubs-Nils/PublishedPapers/astar.pdf); continuous connector and transcription issues are treated by [LaValle, differential constraints](https://lavalle.pl/planning/node755.html) and [Kelly (2017)](https://epubs.siam.org/doi/10.1137/16M1062569).

Refinement claims are conditional on regular contact representations, exact attack/contact satisfaction, suitable movement dynamics, continuous cost laws, timing/slack assumptions and exhaustive covered alternatives. Coordinate buckets are not equivalent states without an error/dominance proof. A capped or failed search proves neither physical unplayability nor completion outside its represented domain.

## Responsibilities and next work

The operator has supplied the playing principles. The next contributions are the reduced calibration readings collected by the existing Viewer session and practical feedback on actual proposals at intended tempi and musical connections. Request additional measurements only when an observed failure identifies consequential missing evidence. No population-level fatigue test or complete anatomical survey is needed to start.

The architect owns these technical tasks:

1. Fit distinct local departure rates from the supplied pair/triple evidence while retaining coupled geometry and uncertainty.
2. Define shared transport/rotation and residual movement against actual available time, with explicit common reference scales and subdivision-consistent cost.
3. Bind the admitted release policy and physical activation/reset constraints to source connections; preserve written/source facts and communicate necessary releases.
4. Build a synthetic-data mathematical prototype exercising shared thumb/middle transport, ring compensation, prepared-finger versus unhurried relocation, and relaxation/reopening between consecutive tenths.
5. Choose bounded preparation search and continuous validation with explicit lower/upper-bound and coverage semantics; test counterexamples for state merging, endpoint-only holds and sample-dependent costs.
6. Validate predictions against withheld comfortable cases and observed operator corrections before proposing a reviewed runtime replacement and Viewer migration.

Planning and documentation do not authorize changing the extracted compatibility baseline, APIs, calculated fingers, calibration wire contract or Viewer dependency. Those remain separate implementation/migration work.

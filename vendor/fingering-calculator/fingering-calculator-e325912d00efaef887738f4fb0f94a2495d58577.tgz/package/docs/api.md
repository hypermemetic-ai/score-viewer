# Calculator package contract

This document describes the shipped compatibility API and its current implementation. New fingering design follows only the [playing philosophy](playing-philosophy.md); the existing objective, presets and replay model are not competing design authority. The new geometric model requires a separately reviewed implementation and migration before this runtime contract changes.

The supported entry is `@hypermemetic-ai/fingering-calculator`. Only the root is exported. This package contains no score parser, notation renderer, viewer state, native integration or third-party runtime dependency. It consumes ordinary normalized source-bar planning data and owns physical calculation/admission. It ships reproducible JavaScript and declarations, so a full-SHA Git installation with `--ignore-scripts` works without a build hook.

```ts
import {
  calculateTemporal, calculateAssignments, validateKnownLayer,
  SUPPORTED_PROFILES, type CalculationRequest,
} from '@hypermemetic-ai/fingering-calculator';

const request: CalculationRequest = {
  contract: 'piano-calculation-request-v1',
  source: { sourceSha256, revision }, // two 64-hex content digests, not a Git SHA
  input, // immutable ordinary source bars, not an already subdivided temporal input
  keyboard: 'janko-four-row',
  profile: SUPPORTED_PROFILES['janko-four-row'],
};
const result = await calculateTemporal(request, { maxExpansions: 2_000_000 });
await validateKnownLayer(result.layer, request, {
  candidateId: 'piano-source-temporal:janko-four-row',
  effectiveHands: Object.fromEntries(result.assignments.map(a => [a.id, a.hand])),
});
```

`calculateTemporal(request, control?)` retains the conventional action-v2 or RR temporal contact-replay result. `calculateAssignments(request, guardedChoices?, control?)` is a distinct static calculation: its layer explicitly says `execution.status: "not-certified"`. Both retain the accepted nested payload, fingerprint serialization and named preset. Neither changes fingers based on score title or imported staff. Neither silently invokes the other. The viewer owns its fallback policy and must retain its barriers for missing tempo, unsupported source data and cancellation.

`CalculationControl` supports `maxExpansions`, a cooperative `{ aborted }` signal and `onProgress({ completed, total, expanded })`. Search domains, arithmetic, objective, candidate ordering, default budget and profile values are unchanged. The temporal solver may execute synchronously inside a worker; callers own worker termination and late-result rejection. No instantaneous cancellation guarantee is introduced.

The ordinary `HandPlanningInput` retains owner inventory order, each owner's absolute pitch/onset/duration/release/voice, opaque detached JSON provenance, source-bar gestures and sorted physical aliases, carried contacts, phrase IDs, full traversal, one supported unnested repeat, canonical explicit reference tempo and guarded source hand requirements. Input validation reconstructs physical aliases, unequal holds, complete source bars and repeat traversal from owner facts. It validates without rebuilding the accepted payload: source field order used by fingerprints survives. A temporal subdivision or contradictory/missing owner, carry, traversal or source instruction is refused. The package makes a detached working copy; caller data is not mutated.

ISO's source adapter remains responsible for pitch coordinates, written tie normalization, voice/staff provenance, source occurrence clocks and canonical semantic tempo, and for rejecting grace and unsupported repeat forms **before** evidence could be dropped during projection. In-memory planning is not a new interchange format. Clock validation in the package is a defensive guard for physical arithmetic, not ownership of score import policy. `bpm` and the accepted rational whole-note `beat` remain serialized unchanged.

Only the current `SUPPORTED_PROFILES[keyboard]` is admitted for calculation. Profile property order is immaterial; exact ID/version and allowed fields matter. Conventional contacts refer to physical key zones; Jankó rows refer to duplicate physical rows. Public structural/contact/constraint/layer types are available from the root; physical enumerators, profile injection and internal search helpers are not public APIs.

`validateKnownLayer(value, request, binding)` performs existing strict reconstruction and replay/static checks, rather than trusting a hash or optimizer cost. Binding carries the original source identity and caller-admitted `effectiveHands`. Optional `binding.sourceHash` carries an independently admitted 64-character lowercase layer/source digest when it differs from the request byte digest; omission defaults to `request.source.sourceSha256`. The byte binding always remains `request.source.sourceSha256`, and admission never infers authority from an untrusted layer hash; RR temporal data also requires a caller-admitted `candidateId`. Unknown contract versions and corrupted contacts, clocks, owner aliases, holds or fabricated certification are refused. `LEGACY_CONVENTIONAL_PROFILE` plus explicit `binding.allowLegacy: true` allows archival conventional v1 planner admission under its original unmeasured default. This never enables that preset for new calculations. Legacy admission requires the original source-bar input and prohibits temporal planning, as before.

Source, calculated, editorial and personal choices remain distinct. `GuardedChoiceConstraint` requires owner identity, original pitch/start/duration guard and an operator/editorial provenance kind. Source-authored hand requirements remain hard; conflicts and stale guards fail. Complete calculation failure is not a fingerless success, and a model span limitation is not a finding that the music is unplayable.

The calculator chooses performing hands jointly with fingers and physical contacts. Independent source voices and printed staff placement remain source facts. Imported, editorial or calculated hand readings carried in opaque `sourceProvenance` do not become search locks. Only explicit `sourceHandRequirements` or supplied guarded choices constrain hands. A supplied `editorial-hand-retention` constraint is still honored for that request; identifying and removing automatic retention constraints belongs to the caller's reviewed preparation-policy migration, rather than a silent calculator override. Genuine source/operator choices must retain their owner guards.

Newly authored root-API regressions admit both an all-LH accompaniment and a RH-thumb shared accompaniment under a held RH melody on conventional piano and four-row Jankó. They preserve every independent owner and release, without asserting a preferred route or specific melody fingers. These are static comparison proposals with `execution.status: "not-certified"`. Their activation still requires ISO's complete compatible engraving and the Viewer's guarded admission/edition installation, as coordinated by [ISO's reviewed calculated-hand engraving plan](https://github.com/hypermemetic-ai/iso-notation/pull/327).

The root exports the three compatibility calculation/admission operations, preset identity selectors, `PianoCalculationError`, their supporting types, and the separately named [calibration collection API](calibration.md). For current collection, the [bounded exploratory pair protocol](calibration-pilot.md) supplies a finite one-hand/one-location plan, explicit fixed-frame conditions and grade meanings, setup-gated observations, save/resume, revision/retraction and honest finite progress. Shared millimetre geometry and the interchangeable MIDI/manual rating router remain available. Historical unrestricted v1 stations and paged finger/anchor/group enumeration retain their compatibility contracts; paging is not a practical human measurement schedule. The exploratory observations do not alter compatibility calculations or consume the viewer's historical span calibration. The root exports no all-module barrel. The older viewer calibration/seed planner continues under its existing pin until a separately reviewed migration.

No license grant or public registry publication is established by this private extraction. Production consumers must pin the reviewed merged Git revision explicitly; the development tarball is test evidence only.

# Exploratory pair calibration

Use the bounded exploratory protocol for the first collection round. It supplies a finite queue and a resumable observation ledger through the supported calculator root API. The Score Viewer owns the screen, physical-key display, device connection and durable storage. These observations do not change shipped fingering calculations or become a fitted hand profile automatically.

## Collection scope

Collect **one hand at one operator-selected central location** first. Choose the reference anchor pitch on the actual instrument before starting. The two pairs are thumb–index and index–middle; each finger takes the anchor role in turn. Test the moving finger only on its usual side in finger order, mirrored for the left hand.

For each role, test distances **1 through 11 duodecimal semitone steps**, inclusive. The implementation stores these as decimal integers 1 through 13. The interval convention does not change finger IDs, row IDs or measurement counts.

| Instrument | Anchor choices | Targets per block | Blocks | Judgments |
| --- | --- | --- | --- | --- |
| Four-row Jankó | One pitch, both physical levels | 13 pitches × both target levels | 8 | **208** |
| Conventional | One reference pitch | 13 pitches, one physical key each | 4 | **52** |
| Conventional, optional extra reference | Two explicitly chosen reference pitches | 13 pitches, one physical key each | 8 | **104** |

The optional second conventional reference can test a black-key anchor as well as a white-key anchor. It is extra declared coverage, not a duplicate lower/upper copy. Jankó origins and targets use their actual lower/upper copies: odd pitches in physical rows **1/3**, even pitches in **2/4**, from near to far.

The order groups trials by pair, anchor role and physical anchor copy. Within a block, pitch distance increases and Jankó target levels alternate lower then upper. This minimizes anchor resets while preserving both levels at every distance. All 208 judgments are collected directly; a run of grade 4 never silently prunes later trials.

The instrument descriptor must contain every required target. A reference too near an instrument edge is rejected before collection; missing keys are not rated unavailable. Show the exact count before the player starts. A second hand is a separate session: both hands would mean **416 Jankó judgments**, rather than a hidden expansion of the first round.

This pilot omits crossing-side targets, additional finger pairs, two-anchor configurations, groups of moving fingers, other arm locations and measured transition timing. Omission is not a ban or a measured grade. The larger nearest-anchor assumption is not validated by this single-anchor pilot. The distance window is collection coverage, not a maximum human reach or repertoire restriction.

## Setup once per block

Keep the body facing forward at the declared seating reference. Place the arm comfortably for the selected location, begin with the wrist aligned with the forearm, and choose a relaxed reference setup for the anchor. Repeat the setup at each new anchor block and after a break.

The prominent instruction must remain next to the rating controls throughout the block:

> **Keep your wrist in place. Keep your hand pointing the same way.**
>
> Keep the anchored finger at its original contact point. Let the tested finger adjust.

Keep the arm's starting position, wrist position and hand direction steady. Do not slide or swivel the whole hand, rotate the forearm, move the elbow or lean to improve a target's grade. Keep the setup relaxed rather than bracing it rigidly. Ordinary small movement accompanying a key press is allowed.

The tested finger may bend, extend and spread. It may choose a front-to-back point on the selected physical key's usable surface. All contacts aim at the **left-to-right center of the usable width at that depth**; this does not prescribe the front-to-back midpoint. On conventional white keys, the narrowed rear surface may have a different horizontal midpoint from the wider front surface. Any finger deformation needed to reach the chosen point contributes to the judgment. The anchor does not slide to a new point between targets.

Show a brief visual example of finger adjustment and whole-hand swivelling before collection. Emphasis alone should not carry this distinction. Mark the anchor and tested finger on the physical keyboard, with enough surrounding keys and the correct colors to identify the location. Jankó defaults to the five-seven color layout and may toggle classic colors without changing key identity. Conventional uses its usual colors.

Highlight the usable surface and its horizontal center guidance, rather than drawing a dot that prescribes a front-to-back strike point. The chosen anchor depth is unmeasured; its marker identifies the anchored physical key, not a claimed measured contact coordinate.

The reference setup and anchor point are operator-declared conditions. This round does not metrically capture wrist pose or the chosen front-to-back contact. It must not manufacture those coordinates from a comfortable grade.

## Short physical task

At the displayed contact points, press both fingers together. Then keep the anchor down while the tested finger taps several times. The shared task calls these patterns `combined` and `trill`; with a held anchor, the latter means repeated tested-finger taps, not alternating or releasing the anchor. Use a self-selected pace; there is no timed-performance test.

Judge the extra arrangement effort required by the more demanding part of this short task, relative to ordinary key pressing. If the two parts expose an important difference, retain an optional note. The core stores the player's report of performed patterns, not a MIDI-derived performance certificate.

A grade 0–3 attests that the player performed both parts. Grade 4 may have no completed patterns. Do not add two per-trial confirmation checkboxes or a performance recorder: the rating itself is the player's report. Rate the displayed contact task rather than the incidental travel between consecutive calibration targets.

## Five ordered grades

Ask:

> **Under those conditions, how much extra effort does pressing this key require?**

| Grade | Label | Meaning |
| --- | --- | --- |
| **0** | Natural fit | The relaxed fingers already fit these contacts, within a small tolerance. |
| **1** | Easy adjustment | A small finger adjustment with no appreciable sustained resistance. |
| **2** | Working stretch | Clear additional effort to maintain the arrangement, while pressing remains comfortable and controlled. |
| **3** | Near the usable limit | Maintaining the arrangement is demanding; controlled pressing remains possible, with little room for further deformation. |
| **4** | Unavailable | The task cannot be performed with normal control under this setup. A contact, anchor or alignment would have to change. |

The categories are ordinal and are not equally spaced numerical costs. Grade 4 excludes only the tested realization; another physical copy, finger assignment or alignment remains a separate possibility. An untested or uncertain result is unknown, never grade 4. Identify the usable-action boundary without attempting to overpower a damaging anatomical limit.

The 0/1 boundary comes from relaxed fit, not a target frequency of equally populated buckets. Finger recoil after removing contact support may help reveal departure from that fit, but it is not a numerical measurement of holding effort or stored energy.

## Input and durable progress

Accept computer `Digit0..Digit4` and `Numpad0..Numpad4` throughout collection, including when MIDI is connected. MIDI availability must not select an exclusive input mode.

MIDI rating commands are pitch classes **0, 2, 4, 6, 8** in any complete C–G♯ block whose `0..8` span does not overlap the current trial's tested contact span. There is no armed or reserved register. Both Jankó copies of a pitch share its control exclusion. A helper can enter ratings above or below the tested hand. The eligibility rule is per trial, not an additional ban over the whole pilot's coverage.

Use the shared input router continuously across auto-advances. Held controls, repeated note-ons, OS key repeats and simultaneous control chords must not grade later trials. Reset its edge state on disconnect, focus loss or session replacement. Tested-note traffic does not create observations, timed evidence or stored MIDI events.

Each block needs a setup acknowledgment before ratings become active. Display the first target while setup is pending, but pass `trial: null` to the router until setup is ready. The acknowledgment confirms the displayed setup instructions; it does not certify measured pose coordinates. Moving to a different block clears readiness. Resuming a saved session also clears readiness and preserves its current target, ratings and history.

Persist the complete versioned session after setup, each rating, navigation and undo. Publish an accepted advancement after a successful durable write; while a write is pending, prevent a second input from rating an unseen target. Support closing and resuming, revisiting earlier targets, correcting a grade and retracting an accidental observation. Retain prior observations rather than overwriting history. Export the complete session JSON for analysis, and preserve invalid or older-format bytes for inspection instead of converting them into a fresh successful session.

The ledger distinguishes completed judgments, unrated targets, revisions and retractions. Finishing the queue means this finite collection round is complete. It does not prove a complete hand model, a continuous trajectory or the correctness of interpolation.

## Integration boundary

Import the new exploratory API only from `@hypermemetic-ai/fingering-calculator`. Do not call the unrestricted `calibrationTrialPage` to start this pilot, fabricate four stations or collect endpoint measurements that this one-location round does not use. The exploratory plan and session have their own versioned contracts; admit historical unrestricted data separately.

The renderer can use `calibrationKeyboardScene` with the plan's declared geometry and overlay the block's anchor and current target. Geometry provenance must distinguish nominal dimensions from measurements. The trial selects keys and levels; it does not prescribe a measured front-to-back strike coordinate.

The Viewer must route rating input before practice/performance observers while the pilot is active. Existing source pitch representations may be offset from MIDI: convert to the core's actual MIDI pitch numbers before routing. Let the instrument's normal sound path remain usable, while the calibration path ignores playing telemetry.

Use a separate versioned storage entry for the pilot rather than admitting it through the legacy thumb–pinky evidence validator. Add that entry to the Viewer's managed-file allowlists where required. Keep this evidence outside source fingers, calculated proposals, personal corrections, legacy span profiles and ordinary calculation requests.

### Supported root operations

`EXPLORATORY_CALIBRATION_PROTOCOL` supplies the versioned conditions, instructions, task and finite coverage. Keep its short `prominentInstruction` visible; show its fuller `setupInstruction`, `contactInstruction` and `patternInstructions` at setup. `EXPLORATORY_CALIBRATION_GRADES` supplies the five labels and descriptions. Both metadata values are read-only.

`createExploratoryCalibrationPlan({ keyboard, hand, anchorMidiPitches })` builds the whole finite sequence. Choose exactly one anchor pitch for Jankó, and one or two for conventional piano. `validateExploratoryCalibrationPlan(value)` admits the canonical blocks, roles, copies, order and protocol metadata, rather than trusting a supplied trial count.

`createExploratoryCalibrationSession(id, provenance, plan)` starts unrated with setup pending. Provenance contains `playerId`, `setupId`, `bodyMidlineXmm` and the declared `reference`. It contains no invented endpoint tests.

`exploratoryCalibrationCurrent(session)` returns `{ trial, block, needsSetup }`. `prepareExploratoryCalibrationBlock(session, { blockId, recordedAt, notes? })` records the displayed setup attestation for the current block. A rating without that preparation is refused.

`recordExploratoryCalibrationObservation(session, observation)` accepts the shared `CalibrationObservation` shape, attaches the current setup-history index internally, retains the judgment and advances to an unrated target. `navigateExploratoryCalibrationTrial(session, trialId)` revisits a target. `retractExploratoryCalibrationObservation(session, observationIndex, recordedAt, reason)` retracts an accidental entry and restores the corresponding current target while retaining history.

`validateExploratoryCalibrationSession(value)` checks all saved data and returns a detached copy. `resumeExploratoryCalibrationSession(value)` also clears setup readiness so returning from a break requires a reset. Use the resume operation when reopening, not validation alone.

`exploratoryCalibrationProgress(session)` reports the finite total, measured and remaining targets, each block's progress, revisions/retractions, setup requirement and `inference: 'none'`. `exploratoryCalibrationWorkAt(session, trialId)` reports unknown or the latest unretracted judgment, scoped to its attested fixed block. Its best-tested-front-to-back interpretation does not assign that grade to every surface point or supply an unmeasured strike coordinate.

All mutations return detached session data. These functions install no listener, browser global, storage operation or device connection.

```ts
import {
  createExploratoryCalibrationPlan, createExploratoryCalibrationSession,
  exploratoryCalibrationCurrent, prepareExploratoryCalibrationBlock,
  createCalibrationInputRouter, recordExploratoryCalibrationObservation,
  resumeExploratoryCalibrationSession,
} from '@hypermemetic-ai/fingering-calculator';

const plan = createExploratoryCalibrationPlan({
  keyboard: admittedGeometry,
  hand: 'RH',
  anchorMidiPitches: [60], // example: operator-selected central C, not an inferred endpoint
});
let session = createExploratoryCalibrationSession('pair-pilot-1', {
  playerId, setupId, bodyMidlineXmm, reference: declaredSeatingReference,
}, plan);
const router = createCalibrationInputRouter();

// On the player's block-setup acknowledgment; persist before publishing.
const current = exploratoryCalibrationCurrent(session);
const prepared = prepareExploratoryCalibrationBlock(session, {
  blockId: current.block!.id,
  recordedAt: new Date().toISOString(),
});
await persist(JSON.stringify(prepared));
session = prepared;

// While handling an input event; keep the router across advances.
const view = exploratoryCalibrationCurrent(session);
const result = router.route(event, {
  keyboard: session.plan.keyboard,
  trial: view.needsSetup || writePending ? null : view.trial,
  midiConnected,
});
if (result.kind === 'rating') {
  const next = recordExploratoryCalibrationObservation(session, {
    trialId: result.trialId, grade: result.grade, input: result.input,
    recordedAt: new Date().toISOString(),
    evidence: {
      patternsPerformed: result.grade === 4 ? [] : [...view.trial!.task.patterns],
    },
  });
  // The caller sets its write gate before awaiting and clears it on success/failure.
  await persist(JSON.stringify(next));
  session = next;
}

// On reopening or returning after a break.
session = resumeExploratoryCalibrationSession(JSON.parse(savedSession));
router.reset();
```

## What the first data should answer

Compare repeated or geometrically related observations before reducing future collection. Investigate whether relative fingertip reach, comfortable spans and actual key geometry explain the grade boundaries, including lower/upper differences. A prediction failure should identify what calibration activity could have exposed the missing condition before adding restrictions to the core model.

The fixed setup prevents an unrecorded whole-hand adjustment from silently improving a rating. These observations may be sufficient to explain necessary adjustments when combined with the other measurements, or may expose missing information. This collection API does not assume either outcome, fit costs or prescribe the pianist's execution.

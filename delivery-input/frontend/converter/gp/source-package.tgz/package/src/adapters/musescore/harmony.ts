import { createHarmonyNaming } from './harmony-naming.js';
import { child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { refuse, type Location } from '../../core/report.js';
import type { ChordFrame, ChordHarmony, Direction } from '../../core/model.js';
import type { NativeBudget } from './budget.js';

const qualities: Readonly<Record<string, string>> = { '': 'major', m: 'minor', min: 'minor', '-': 'minor', '=': 'minor', '+': 'augmented', aug: 'augmented', dim: 'diminished', o: 'diminished', '7': 'dominant', maj7: 'major-seventh', M7: 'major-seventh', m7: 'minor-seventh', min7: 'minor-seventh', dim7: 'diminished-seventh', o7: 'diminished-seventh', m7b5: 'half-diminished', 'ø': 'half-diminished', 'ø7': 'half-diminished', 'm(maj7)': 'major-minor', '6': 'major-sixth', m6: 'minor-sixth', '9': 'dominant-ninth', maj9: 'major-ninth', m9: 'minor-ninth', '11': 'dominant-11th', maj11: 'major-11th', m11: 'minor-11th', '13': 'dominant-13th', maj13: 'major-13th', m13: 'minor-13th', sus2: 'suspended-second', sus4: 'suspended-fourth', sus: 'suspended-fourth', '5': 'power' };

type At = Pick<Direction, 'position' | 'staff' | 'voiceId'>;
interface NativeHarmonyContext {
    get: (owner: Element, name: string, required?: boolean) => string;
    use: (element: Element) => unknown;
    consume: (element: Element) => unknown;
    omit: (element: Element, reason: string) => void;
    budget: NativeBudget;
    readColor: (element: Element) => Direction['sourceColor'];
    plainText: (element: Element) => string;
    decoration: (element: Element) => void;
    applyPresentation?: (element: Element, direction: Direction) => void;
    performanceGap: (code: string, source: Location, message: string, disposition?: 'omitted' | 'inferred' | 'preserved') => void;
    styles?: readonly Element[];
    chordList?: Element;
    nativeVersion?: string;
}

/** Independent native spelling/diagram recovery. The caller owns clocks, source accounting and limits. */
export function createNativeHarmonyReader(context: NativeHarmonyContext) {
    const { use, consume, omit, budget, readColor, decoration, performanceGap } = context;
    const plain = (e: Element, attributes: string[] = []): void => {
        if (e.children.length || Object.keys(e.attrs).some(a => !attributes.includes(a))) refuse('native-harmony-field', 'Harmony data must have its declared plain source shape.', e.location);
        consume(e);
    };
    const scalar = (owner: Element, name: string): string | undefined => {
        const e = child(owner, name); if (!e) return undefined;
        plain(e); return e.text.trim();
    };
    const bounded = (owner: Element, name: string, min: number, max: number, fallback?: number): number => {
        const value = scalar(owner, name);
        if (value === undefined && fallback !== undefined) return fallback;
        return integer(value ?? '', min, max, child(owner, name)?.location ?? owner.location);
    };
    const present = (e: Element, at: At): Direction => {
        const visible = scalar(e, 'visible'), placement = scalar(e, 'placement'), sourceColor = readColor(e);
        if (placement && !['above', 'below'].includes(placement)) refuse('native-harmony-placement', 'Unknown harmony placement.', e.location);
        return { source: e.location, ...at, kind: 'harmony', ...(visible !== undefined ? { printObject: integer(visible, 0, 1, e.location) === 1 } : {}), ...(placement ? { placement: placement as 'above' | 'below' } : {}), ...(sourceColor ? { sourceColor } : {}) };
    };
    const tone = (e: Element, name: string): ChordHarmony['root'] => {
        const value = scalar(e, name); if (value === undefined) return undefined;
        const tpc = integer(value, -1, 33, child(e, name)!.location);
        return { step: ['F', 'C', 'G', 'D', 'A', 'E', 'B'][(tpc + 1) % 7], alter: Math.floor((tpc + 1) / 7) - 2 };
    };
    const naming = createHarmonyNaming(context.styles ?? [], context.nativeVersion ?? '4.70', consume);
    const degreeList = (owner: Element): ChordHarmony['degrees'] => {
        const degrees = children(owner, 'degree'); if (!degrees.length) return undefined;
        return degrees.map(degree => {
            if (degree.text.trim() || degree.children.some(c => !['degree-value', 'degree-alter', 'degree-type'].includes(c.name))) refuse('native-harmony-degree', 'Uninterpreted source chord degree.', degree.location);
            use(degree); budget.add('markings', 1, degree.location);
            const type = scalar(degree, 'degree-type');
            if (!['add', 'alter', 'subtract'].includes(type ?? '')) refuse('native-harmony-degree', 'Unknown chord-degree operation.', degree.location);
            return { source: degree.location, value: bounded(degree, 'degree-value', 1, 13), alter: bounded(degree, 'degree-alter', -2, 2), type: type as 'add' | 'alter' | 'subtract' };
        });
    };
    const playback = (owner: Element): void => {
        for (const field of owner.children) if (['play', 'harmonyVoiceLiteral', 'harmonyVoicing', 'harmonyDuration'].includes(field.name)) { plain(field); omit(field, 'Playback-only chord realization'); }
    };
    const catalogChord = (extension: string | undefined, name: string): { name?: string; kind?: string; degrees?: ChordHarmony['degrees'] } | undefined => {
        if (!context.chordList) return undefined;
        const entries = children(context.chordList, 'chord').filter(entry => extension ? entry.attrs.id === extension : children(entry, 'name').some(n => n.text === name));
        if (entries.length > 1) refuse('native-harmony-catalog', 'Multiple source chord definitions match the same symbol.', context.chordList.location);
        const entry = entries[0]; if (!entry) return undefined;
        if (entry.text.trim() || Object.keys(entry.attrs).some(a => a !== 'id')) refuse('native-harmony-catalog', 'Uninterpreted source chord definition.', entry.location);
        consume(context.chordList); consume(entry);
        const names = children(entry, 'name'); for (const field of names) plain(field);
        const kind = scalar(entry, 'xml');
        const degrees = children(entry, 'degree').map(field => {
            plain(field); const match = /^(add|alt|sub)(bb|##|b|#)?([1-9]|1[0-3])$/.exec(field.text.trim());
            if (!match) return refuse('native-harmony-catalog-degree', 'Uninterpreted source catalog degree.', field.location);
            return { source: field.location, value: Number(match[3]), alter: match[2]?.startsWith('b') ? -match[2].length : match[2]?.length ?? 0, type: ({ add: 'add', alt: 'alter', sub: 'subtract' } as const)[match[1] as 'add' | 'alt' | 'sub'] };
        });
        for (const field of entry.children) if (['render', 'voicing'].includes(field.name)) { plain(field); omit(field, field.name === 'render' ? 'Native chord glyph positioning; source label is preserved' : 'Playback-only chord realization'); }
        return { ...(names.length ? { name: names[0].text } : {}), ...(kind ? { kind } : {}), ...(degrees.length ? { degrees } : {}) };
    };
    const readHarmony = (e: Element, at: At): Direction | undefined => {
        use(e); budget.add('markings', 1, e.location);
        if (e.text.trim()) refuse('native-harmony', 'Harmony wrapper has uninterpreted own text.', e.location);
        const infos = children(e, 'harmonyInfo');
        if (infos.length > 32) refuse('native-harmony-budget', 'Too many chord components at one clock.', e.location);
        const info = infos[0], owner = info ?? e;
        if (info) { use(info); if (info.text.trim()) refuse('native-harmony', 'Chord information has uninterpreted own text.', info.location); }
        const root = tone(owner, 'root'), base = tone(owner, 'base'), bass = tone(owner, 'bass');
        if (base && bass) refuse('native-harmony-bass', 'Multiple encoded bass identities are not merged.', owner.location);
        scalar(owner, 'name');
        let name = child(owner, 'name')?.text ?? '';
        const extension = scalar(owner, 'extension');
        let degrees = degreeList(e);
        const catalog = catalogChord(extension, name);
        if (!child(owner, 'name') && catalog?.name !== undefined) name = catalog.name;
        if (catalog?.degrees) degrees = [...catalog.degrees, ...(degrees ?? [])];
        if (name.length > 256) refuse('native-harmony', 'Chord label exceeds the bounded source profile.', owner.location);
        if (extension !== undefined) integer(extension, 1, 65535, child(owner, 'extension')!.location);
        const direction = present(e, at), harmonyType = bounded(e, 'harmonyType', 0, 2, 0), functionLabel = scalar(e, 'function');
        const quality = catalog ? catalog.kind : qualities[name.trim()];
        const rootCase = bounded(e, 'rootCase', -1, 2, 0), bassCase = bounded(e, child(e, 'bassCase') ? 'bassCase' : 'baseCase', -1, 2, 0);
        const names = naming(e, root, bass ?? base, catalog?.name ?? name, rootCase, bassCase);
        const rootLabel = names.root?.label ?? '', bassLabel = names.bass?.label ?? '';
        const value = root ? rootLabel + name.replace(/^=/, 'm') + (bassLabel ? '/' + bassLabel : '') : name;
        if (!root && !base && !bass && !degrees?.length && !extension && /^[IVXivx]{1,16}$/.test(value.trim())) {
            direction.harmony = { source: child(owner, 'name')!.location, value: name, role: 'literal-function' };
        } else if (root) {
            direction.harmony = { source: owner.location, role: 'chord-symbol', value, root, sourceNoteNaming: names.sourceNoteNaming, ...(names.root?.text !== undefined ? { rootText: names.root.text } : {}), ...(names.bass?.text !== undefined ? { bassText: names.bass.text } : {}), ...(names.root?.hideAlter ? { rootAlterPrintObject: false } : {}), ...(names.bass?.hideAlter ? { bassAlterPrintObject: false } : {}), ...(bass ?? base ? { bass: (bass ?? base)! } : {}), ...(quality ? { kind: quality, kindText: name.replace(/^=/, 'm') } : {}), ...(degrees ? { degrees } : {}) };
            if (extension !== undefined && !name && !catalog?.kind && (extension !== '1' || (context.styles ?? []).some(style => children(style, 'chordDescriptionFile').some(field => !['chords.xml', 'chords_std.xml', 'chords_jazz.xml'].includes(field.text.trim()))))) refuse('native-harmony-catalog', 'A catalog-only chord quality requires its source chord definition; major is not guessed from a numeric identifier.', owner.location);
        } else {
            if (base || bass || degrees?.length || extension) refuse('native-harmony-root', 'Rootless structured chord requires a qualified source representation.', owner.location);
            direction.harmony = { source: owner.location, value: functionLabel || value, role: 'chord-symbol' };
        }
        if (harmonyType !== 0 || functionLabel) {
            // Authored Nashville/functional analysis remains literal; no key-dependent root is invented.
            direction.harmony = { ...direction.harmony, source: owner.location, role: 'chord-symbol', value: functionLabel || value };
            delete direction.harmony.kind;
        }
        if (infos.length > 1) {
            if (direction.harmony.role !== 'chord-symbol') refuse('native-harmony-polychord', 'Literal analysis cannot own a structured polychord.', e.location);
            (direction.harmony as ChordHarmony).additional = infos.slice(1).map(info => {
                const wrapper: Element = { ...e, children: [info, ...e.children.filter(c => ['rootCase', 'bassCase', 'baseCase'].includes(c.name))], text: '' };
                const next = readHarmony(wrapper, at)?.harmony;
                if (!next || next.role !== 'chord-symbol') return refuse('native-harmony-polychord', 'Polychord requires independent chord components.', info.location);
                return next;
            });
        }
        for (const field of children(e, 'leftParen').concat(children(e, 'rightParen'))) {
            plain(field); if (field.text.trim()) refuse('native-harmony-parenthesis', 'Chord parenthesis must be an empty source flag.', field.location);
        }
        if (child(e, 'leftParen') || child(e, 'rightParen')) {
            direction.harmony.value = (child(e, 'leftParen') ? '(' : '') + direction.harmony.value + (child(e, 'rightParen') ? ')' : '');
            if (direction.harmony.role === 'chord-symbol') delete direction.harmony.kind;
            else direction.harmony = { source: direction.harmony.source, role: 'chord-symbol', value: direction.harmony.value };
        }
        context.applyPresentation?.(e, direction);
        playback(e); decoration(e); if (info) decoration(info);
        if (!direction.harmony.value && direction.harmony.role === 'chord-symbol' && !direction.harmony.root) {
            performanceGap('native-empty-harmony', e.location, 'Empty source harmony contains no performer label or tonal facts.'); return undefined;
        }
        return direction;
    };
    const setting = (e: Element, name: string, styleName: string, min: number, max: number, fallback: number): number => {
        if (child(e, name)) return bounded(e, name, min, max);
        let result = fallback;
        for (const style of context.styles ?? []) if (child(style, styleName)) result = bounded(style, styleName, min, max);
        return result;
    };
    const readFretDiagram = (e: Element, at: At): Direction | undefined => {
        use(e); budget.add('markings', 1, e.location);
        if (e.text.trim()) refuse('native-frame', 'Fret diagram has uninterpreted own text.', e.location);
        const strings = setting(e, 'strings', 'fretStrings', 1, 32, 6), frets = setting(e, 'frets', 'fretFrets', 1, 48, 4), offset = bounded(e, 'fretOffset', 0, 47, 0);
        if (offset + frets > 48) refuse('native-frame-range', 'Diagram frets exceed the bounded instrument range.', e.location);
        const modern = child(e, 'fretDiagram'), owner = modern ?? e;
        if (modern) { use(modern); if (modern.text.trim()) refuse('native-frame', 'Fret diagram data has uninterpreted own text.', modern.location); }
        const markers: NonNullable<ChordFrame['markers']> = [];
        const notes: ChordFrame['notes'] = [], muted = new Set<number>(), occupied = new Set<number>();
        const addNote = (source: Location, string: number, fret: number, fingering?: string, barre?: 'start' | 'stop') => {
            if (notes.length >= 256) refuse('native-frame-budget', 'Too many diagram positions.', source);
            budget.add('markings', 1, source); notes.push({ source, string, fret, ...(fingering ? { fingering } : {}), ...(barre ? { barre } : {}) }); occupied.add(string);
        };
        const seen = new Set<number>();
        const fingers = new Map<number, { source: Location; value: string }>();
        for (const string of children(owner, 'string')) {
            if (string.text.trim() || Object.keys(string.attrs).join(',') !== 'no') refuse('native-frame-string', 'Diagram string needs one bounded source index.', string.location);
            const index = integer(string.attrs.no, 0, strings - 1, string.location), number = strings - index;
            if (seen.has(index)) refuse('native-frame-string', 'Duplicate diagram string ownership.', string.location);
            seen.add(index); consume(string);
            const marker = scalar(string, 'marker'), fingering = scalar(string, 'fingering');
            if (fingering && !/^[0-5T]$/.test(fingering)) refuse('native-frame-fingering', 'Unknown explicit diagram fingering.', string.location);
            if (fingering) fingers.set(number, { source: child(string, 'fingering')!.location, value: fingering });
            if (marker !== undefined) {
                if (modern ? marker === 'cross' : marker === '88') { muted.add(number); markers.push({ source: child(string, 'marker')!.location, string: number, kind: 'muted' }); }
                else if (modern ? marker === 'circle' : marker === '79') { addNote(child(string, 'marker')!.location, number, 0); markers.push({ source: child(string, 'marker')!.location, string: number, kind: 'open' }); }
                else if (marker !== 'none') refuse('native-frame-marker', 'Unknown diagram string marker.', string.location);
                else markers.push({ source: child(string, 'marker')!.location, string: number, kind: 'none' });
            }
            for (const dot of children(string, 'dot')) {
                plain(dot, modern ? ['fret'] : []);
                const fret = integer(modern ? dot.attrs.fret : dot.text.trim(), 1, frets, dot.location);
                if (modern && !['normal', 'cross', 'square', 'triangle'].includes(dot.text.trim())) refuse('native-frame-dot', 'Unknown source dot shape.', dot.location);
                if (modern && dot.text.trim() !== 'normal') performanceGap('native-frame-dot-shape', dot.location, 'MusicXML frame-note has no dot-shape vocabulary; string, fret and source shape remain captured.');
                addNote(dot.location, number, offset + fret, fingering);
            }
            if (muted.has(number) && occupied.has(number)) refuse('native-frame-conflict', 'A diagram string cannot be both explicitly muted and sounded.', string.location);
        }
        const barres = children(owner, 'barre');
        for (const barre of barres) {
            if (!modern) {
                plain(barre); if (integer(barre.text.trim(), 0, 1, barre.location) === 0) continue;
                const first = [...notes].filter(n => n.fret > 0).sort((a, b) => b.string - a.string)[0];
                if (!first) refuse('native-frame-barre', 'Legacy barre has no encoded starting dot.', barre.location);
                addNote(barre.location, first.string, first.fret, undefined, 'start'); addNote(barre.location, 1, first.fret, undefined, 'stop');
                for (let number = 2; number < first.string; number++) if (!occupied.has(number)) addNote(barre.location, number, first.fret);
            } else {
                plain(barre, ['start', 'end']);
                const start = integer(barre.attrs.start, 0, strings - 1, barre.location), end = integer(barre.attrs.end, -1, strings - 1, barre.location), fret = integer(barre.text.trim(), 1, frets, barre.location);
                const last = end === -1 ? strings - 1 : end;
                if (last <= start) refuse('native-frame-barre', 'Barre requires two ordered distinct strings.', barre.location);
                for (let index = start; index <= last; index++) if (muted.has(strings - index)) refuse('native-frame-conflict', 'Barre crosses an explicitly muted string.', barre.location);
                addNote(barre.location, strings - start, offset + fret, undefined, 'start'); addNote(barre.location, strings - last, offset + fret, undefined, 'stop');
                for (let index = start + 1; index < last; index++) if (!occupied.has(strings - index)) addNote(barre.location, strings - index, offset + fret);
            }
        }
        const fingeringVector = scalar(e, 'fretFingering');
        const showFingerings = setting(e, 'fretShowFingering', 'fretShowFingerings', 0, 1, 0) === 1;
        if (fingeringVector !== undefined) {
            const values = fingeringVector.split(',');
            if (values.length !== strings) refuse('native-frame-fingering', 'Fingering vector must identify every diagram string in native high-to-low order.', e.location);
            for (const [index, value] of values.entries()) {
                const finger = integer(value.trim(), 0, 5, child(e, 'fretFingering')!.location);
                if (!finger) continue;
                const previous = fingers.get(index + 1);
                if (previous && previous.value !== String(finger)) refuse('native-frame-fingering', 'Conflicting source diagram fingerings.', previous.source);
                fingers.set(index + 1, { source: child(e, 'fretFingering')!.location, value: String(finger) });
            }
        }
        const framePresentation = present(e, at);
        const annotations: NonNullable<ChordHarmony['annotations']> = [];
        for (const [number, finger] of fingers) {
            const targets = notes.filter(note => note.string === number);
            if (targets.length) for (const note of targets) { note.fingering = finger.value; note.fingeringVisible = showFingerings; }
            else annotations.push({ source: finger.source, value: `string ${number}: finger ${finger.value}`, printObject: showFingerings && framePresentation.printObject !== false, ...(framePresentation.sourceColor ? { sourceColor: framePresentation.sourceColor } : {}) });
        }
        if (modern) for (const field of e.children) if (['string', 'barre'].includes(field.name)) omit(field, 'Native legacy frame compatibility duplicate; lowercase fretDiagram is authoritative');
        if (!notes.length) {
            performanceGap('native-frame-empty', e.location, 'MusicXML requires at least one played frame note; empty or wholly muted frame geometry has no faithful standard frame representation. Explicit muted-string instructions are retained as ordinary text.');
            const nested = child(e, 'Harmony'), direction = nested ? readHarmony(nested, at) : undefined;
            decoration(e);
            if (!muted.size && !annotations.length) return direction;
            if (muted.size) annotations.push({ source: e.location, value: 'mute strings ' + [...muted].sort((a, b) => a - b).join(', '), printObject: framePresentation.printObject, sourceColor: framePresentation.sourceColor });
            const result = direction ?? framePresentation;
            const previous = result.harmony;
            result.harmony = { ...previous, source: previous?.source ?? e.location, role: 'chord-symbol', value: previous?.value ?? '', annotations };
            return result;
        }
        const missing = Array.from({ length: strings }, (_, i) => i + 1).filter(number => !occupied.has(number));
        const unplayed = muted.size && missing.every(number => muted.has(number)) ? 'x' : '';
        for (const number of missing) if (!muted.has(number) && !markers.some(marker => marker.string === number)) markers.push({ source: e.location, string: number, kind: 'none' });
        const frame: ChordFrame = { source: e.location, strings, frets, firstFret: offset + 1, unplayed, notes, markers };
        if (framePresentation.printObject !== undefined) frame.printObject = framePresentation.printObject;
        if (framePresentation.sourceColor) frame.sourceColor = framePresentation.sourceColor;
        const nested = child(e, 'Harmony'), harmony = nested ? readHarmony(nested, at) : undefined;
        const direction = harmony ?? present(e, at);
        if (direction.harmony?.role === 'literal-function') direction.harmony = { ...direction.harmony, role: 'chord-symbol' };
        direction.harmony = { ...(direction.harmony ?? { source: e.location, role: 'chord-symbol' as const, value: '' }), frame, ...(annotations.length ? { annotations } : {}) };
        for (const name of ['showNut', 'orientation', 'mag', 'fretNumPos', 'excludeFromVerticalAlign']) {
            const field = child(e, name); if (field) { plain(field); omit(field, 'Native frame appearance; portable MusicXML frame repaginates'); }
        }
        decoration(e);
        return direction;
    };
    return { readHarmony, readFretDiagram };
}

import { freeze, refuse, type Finding } from '../../core/report.js';
import type { MusicalPart, MusicalRelation, MusicalScore } from '../../core/model.js';
import { child, integer, value, type Element } from './xml.js';
import { arrangementTrack, discoverArrangementGraph, mergeStaffParts, projectSourceStaff, sourceIds, type ArrangementTrack } from './arrangements.js';
import { prepareGp8, serialize } from './gp8.js';
import { inventory } from './profile.js';
import { recover, type Recovery, type OccurrenceCapture } from './recover.js';
import { limits } from './limits.js';
import { createPitchedArticulations } from './pitched-articulations.js';
import { createGpHarmony } from './harmony.js';
import { createTrackAutomations } from './track-automations.js';
import { applyGpifBeams } from './gpif-beams.js';
import { materializeStaffOccurrences } from './source-occurrences.js';
import { expandMeasureRepeats } from './measure-repeats.js';
import { percussionCatalog, sourcePercussion } from './percussion.js';

/** The borrowed parser reads Octave/Tone for traditional notes, while native GP7+ also writes full pitch tuples.
 * This source-bound alias supplies no new pitch: recovery separately checks both authored spellings and MIDI. */
function readerPitchAliases(root: Element, descriptor: ArrangementTrack, findings: Finding[]): Element {
    const percussion = descriptor.percussion;
    const notes = child(root, 'Notes')!;
    const replacement = notes.children.map(note => {
        const properties = child(note, 'Properties', false);
        if (!properties) return note;
        let values = properties.children;
        let sourceNote = note;
        if (percussion && !child(note, 'InstrumentArticulation', false)) {
            const resolved = sourcePercussion(note, [], descriptor.id, findings, descriptor.reference);
            sourceNote = { ...note, children: [...note.children, { name: 'InstrumentArticulation', attrs: {}, text: String(resolved.articulation), children: [], location: note.location }] };
            values = values.filter(p => !['Element','Variation'].includes(p.attrs.name));
        }
        if (percussion) values = values.filter(p => !['String', 'Fret'].includes(p.attrs.name));
        else if (!values.some(p => p.attrs.name === 'String')) {
            const midi = values.find(p => p.attrs.name === 'Midi');
            if (midi && !values.some(p => ['Octave','Tone'].includes(p.attrs.name))) {
                const number = integer(value(midi, 'Number'), 0, 127, midi);
                const alias = (name: string, field: string, text: number): Element => ({ ...midi, attrs: { name }, children: [{ name: field, attrs: {}, children: [], text: String(text), location: midi.location }] });
                values = [...values, alias('Octave', 'Number', Math.floor(number / 12)), alias('Tone', 'Step', number % 12)];
                findings.push({ disposition: 'preserved', code: 'traditional-pitch-reader-alias', message: 'Encoded MIDI is split into the borrowed reader\'s Octave/Tone fields. Complete source pitch tuples independently determine output spelling and transposition; no physical string or fret is supplied.', location: midi.location, fact: { midi: number } });
            }
        }
        return { ...sourceNote, children: sourceNote.children.map(e => e === properties ? { ...e, children: values } : e) };
    });
    return { ...root, children: root.children.map(e => e === notes ? { ...e, children: replacement } : e) };
}
export function recoverArrangement(root: Element, requested: string[] | undefined, findings: Finding[], family: 6 | 7 | 8): Recovery {
    const graph = discoverArrangementGraph(root), selected = requested ?? graph.order;
    if (!selected.length || new Set(selected).size !== selected.length || selected.some(id => !graph.tracks.has(id))) refuse('track-selection', 'Select existing unique source track IDs.', root.location);
    let expandedEvents=0,expandedNotes=0;
    for(const master of graph.masterBars.children) for(const [slot,id] of sourceIds(master,'Bars').entries()) if(selected.includes(graph.slots[slot].trackId)) {
        const bar=graph.bars.get(id)!;
        for(const voiceId of sourceIds(bar,'Voices').filter(id=>id!=='-1')) for(const beatId of sourceIds(graph.voices.get(voiceId)!,'Beats')) {
            expandedEvents++; expandedNotes+=sourceIds(graph.beats.get(beatId)!,'Notes',false).length;
            if(expandedEvents>limits.occurrences||expandedNotes>limits.occurrences) refuse('occurrence-budget','Complete selected arrangement exceeds the shared expanded occurrence budget.',bar.location);
        }
    }
    const parts: MusicalPart[] = [], occurrences: OccurrenceCapture[] = [], relations: MusicalRelation[] = [];
    let first: MusicalScore | undefined, eventCount = 0;
    for (const trackId of graph.order) {
        if (!selected.includes(trackId)) { findings.push({ disposition: 'excluded-by-scope', code: 'track-excluded', message: 'Source track deliberately excluded by selected IDs.', location: { ...graph.tracks.get(trackId)!.location, trackId }, fact: { trackId } }); continue; }
        const sourceTrack = graph.tracks.get(trackId)!, descriptor = arrangementTrack(sourceTrack), percussion = descriptor.percussion ? percussionCatalog(sourceTrack) : [];
        const pitchedArticulations = !descriptor.percussion ? createPitchedArticulations(sourceTrack, findings) : undefined;
        const staffParts: MusicalPart[] = [];
        for (let si = 0; si < descriptor.staves.length; si++) {
            const harmony = createGpHarmony(sourceTrack, descriptor.staves[si], findings);
            const repeatProjection = expandMeasureRepeats(materializeStaffOccurrences(projectSourceStaff(root, graph, trackId, si + 1), findings), findings);
            const projection = repeatProjection.root;
            const prepared = readerPitchAliases(prepareGp8(projection, undefined, findings, family, { harmony }), descriptor, findings);
            inventory(prepared, findings, 'gpif-physical');
            const recovered = recover(prepared, serialize(prepared), findings, 'gpif-physical', { track: descriptor, percussion, staffNumber: si + 1, sourceNotes: graph.notes });
            eventCount += recovered.score.parts[0].measures.reduce((total,measure) => total + measure.voices.reduce((sum,voice) => sum + voice.length,0),0);
            if (eventCount > limits.occurrences || occurrences.length + recovered.occurrences.length > limits.occurrences) refuse('occurrence-budget', 'Complete selected arrangement exceeds the shared expanded occurrence budget.', sourceTrack.location);
            first ??= recovered.score;
            const part = structuredClone(recovered.score.parts[0]);
            repeatProjection.apply(part);
            const tuning = child(descriptor.staves[si], 'Properties', false)?.children.find(p => p.name === 'Property' && p.attrs.name === 'Tuning'), label = tuning && child(tuning, 'Label', false);
            if (label?.text.trim()) (part.measures[0].directions ??= []).push({ source: label.location, kind: 'words', staff: 1, position: { n: 0, d: 1 }, text: label.text, printObject: !tuning || value(tuning, 'LabelVisible', false) !== 'false' });
            const projectedGraph = discoverArrangementGraph(projection);
            for (const [mi, measure] of part.measures.entries()) {
                const sourceBar = projectedGraph.bars.get(sourceIds(projectedGraph.masterBars.children[mi], 'Bars')[0])!;
                const sourceSlots = sourceIds(sourceBar, 'Voices');
                const lastPresent = sourceSlots.reduce((last, id, i) => id !== '-1' ? i : last, -1);
                measure.voices = measure.voices.slice(0, Math.max(1, lastPresent + 1));
            }
            applyGpifBeams(part, { masterBars: projectedGraph.masterBars.children, bars: [...projectedGraph.bars.values()], beats: projectedGraph.beats, rhythms: projectedGraph.rhythms }, findings);
            for (const measure of part.measures) for (const [vi, voice] of measure.voices.entries()) for (const event of voice) {
                for (const note of event.notes) pitchedArticulations?.apply(note, graph.notes.get(note.source.id!)!, event.type);
                const direction = harmony.readBeat(graph.beats.get(event.source.id!)!, { position: event.start, staff: 1, voiceId: String(vi + 1) });
                if (direction) (measure.directions ??= []).push(direction);
            }
            const relationIds = new Map((recovered.score.relations ?? []).map(r => [r.id, `${r.id}:staff:${si + 1}`]));
            const remap = (input: unknown): void => { if (!input || typeof input !== 'object') return; if (Array.isArray(input)) { input.forEach(remap); return; } const item = input as Record<string, unknown>; if (typeof item.relationId === 'string' && relationIds.has(item.relationId)) item.relationId = relationIds.get(item.relationId)!; Object.values(item).forEach(remap); };
            remap(part);
            staffParts.push(part); occurrences.push(...recovered.occurrences);
            for (const original of recovered.score.relations ?? []) {
                const relation = structuredClone(original); relation.id = relationIds.get(relation.id)!;
                for (const endpoint of [relation.start, relation.end]) { endpoint.staff = si + 1; endpoint.voiceId = String(si * 4 + Number(endpoint.voiceId ?? 1)); }
                relations.push(relation);
            }
        }
        const merged = mergeStaffParts(staffParts, descriptor);
        createTrackAutomations(sourceTrack, findings).apply(merged);
        parts.push(merged);
    }
    for (const part of parts) for (let mi=0;mi<part.measures.length;mi++) { const a=part.measures[mi].duration,b=parts[0].measures[mi].duration; if(a.n*b.d!==b.n*a.d) refuse('arrangement-span','All selected physical staves must agree on each exact master-bar span.',part.measures[mi].source); }
    const auxiliary = findings.filter(f => ['source-interpretation-field', 'partial-capo', 'source-playing-style', 'linear-tempo', 'pitched-articulation-source', 'written-key-transposition', 'key-preference', 'source-irregular-measure', 'unassigned-percussion-source'].includes(f.code)).map((f,index) => ({ source: f.location!, name: `gp-source:${f.code}:${index+1}`, value: JSON.stringify(f.fact) }));
    return { score: freeze({ ...first!, metadata: [...(first!.metadata ?? []), ...auxiliary], parts, ...(relations.length ? { relations } : {}) }), occurrences: freeze(occurrences) };
}

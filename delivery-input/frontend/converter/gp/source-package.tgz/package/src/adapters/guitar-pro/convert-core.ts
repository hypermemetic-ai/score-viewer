import { Bytes, sha256 } from './bytes.js';
import { guitarProEncoding } from './encoding.js';
import { writeMusicXml } from '../../core/musicxml.js';
import { freeze, Refusal, type Finding, type Location } from '../../core/report.js';
import type { MusicalScore } from '../../core/model.js';
import { limits } from './limits.js';
import { parseXml, type Element } from './xml.js';
import { prepareGp8, serialize } from './gp8.js';
import { captureContainer, type ContainerFact } from './container-facts.js';
import { inventory } from './profile.js';
import { recover, type OccurrenceCapture } from './recover.js';
import { readBinary, type BinaryCapture } from './binary.js';
import { readGpx, type GpxCapture } from './gpx.js';
import { BoundedFindings, jsonBytes } from './work-budgets.js';
import { recoverArrangement } from './arrange-recovery.js';
import { isFrettedScore } from './arrangements.js';
import { admittedFamily, type InstrumentFamily } from './admission.js';
import { admitDescriptors } from './zip-core.js';

export interface ConvertedPart {
    readonly sourceTrackId: string;
    readonly sourceLocation: Readonly<Location>;
    readonly musicxmlPartId: string;
    readonly admission: { readonly instrumentFamily: InstrumentFamily; readonly profile: string; readonly evidenceFindingIndices: readonly number[] };
}

export interface ConversionResult {
    ok: boolean;
    musicxml?: string;
    report: { schema: 'score-converter-report/0'; inputSha256: string; adapter: string; profile: string; requestedScope: 'all-tracks' | { trackIds: string[] }; findings: Finding[]; convertedParts?: readonly ConvertedPart[] };
    source?: Element;
    containerSource?: ContainerFact[];
    occurrences?: OccurrenceCapture[];
    score?: MusicalScore;
    scoreKind?: 'fretted' | 'arrangement';
    inputSource?: { bytes: number; sha256: string; dataBase64: string };
    binarySource?: BinaryCapture;
    gpxSource?: GpxCapture;
}
/** Internal synchronous worker entry. Public conversion runs in a bounded worker. */
export function convertPortable(bytes: Uint8Array, options: { trackIds?: string[] }, readContainer: () => Map<string, Bytes>): ConversionResult {
    const report: ConversionResult['report'] = {
        schema: 'score-converter-report/0', inputSha256: sha256(bytes),
        adapter: 'alphatab-1.8.4-022a45c8+source-hook/1', profile: 'gp-family-fretted/0', requestedScope: options.trackIds ? { trackIds: options.trackIds } : 'all-tracks', findings: new BoundedFindings()
    };
    try {
        if (bytes.length > limits.inputBytes) throw new Refusal('input-size', 'Input exceeds 8 MiB.');
        const encoding = guitarProEncoding(bytes);
        const binary = encoding === 'binary', gpx = encoding === 'gpx';
        let source: Element | undefined, binarySource: BinaryCapture | undefined, gpxSource: GpxCapture | undefined;
        let container = { facts: [] as ContainerFact[], display: { hideDynamics: false, hideTempo: false } };
        let recovery: { score: MusicalScore; occurrences: OccurrenceCapture[] };
        if (binary) {
            report.profile = 'gp3-5-binary-fretted/0';
            const recovered = readBinary(bytes, report.findings, options.trackIds);
            binarySource = recovered.capture; recovery = recovered;
        } else {
            let members: Map<string, Bytes>;
            if (gpx) {
                const decoded = readGpx(bytes);
                gpxSource = decoded.capture;
                members = new Map([...decoded.members].map(([name, data]) => ['Content/' + name, data]));
                report.findings.push({ disposition: 'inferred', code: 'gpx-reader-member-alias', message: 'Flat GPX member names receive a generated Content/ prefix only in the shared reader view. GPX capture retains original names and decoded BCFS offsets; those offsets do not address compressed input bytes.', location: { member: 'container' }, fact: { aliases: [...decoded.members.keys()].map(name => ({ source: name, reader: 'Content/' + name })) } });
                if (decoded.capture.omittedSectorPaddingBytes || decoded.capture.incompleteFinalLiteralPaddingBits !== undefined) report.findings.push({ disposition: 'inferred', code: 'gpx-terminal-sector-padding', message: 'The source encoder ends in unused terminal sector/literal padding. Filesystem ownership and an independent decoder establish every member byte; only unused zeros complete the sector buffer, whose normalized hash is separate from the exact input hash.', location: { member: 'container' }, fact: { omittedSectorPaddingBytes: decoded.capture.omittedSectorPaddingBytes ?? 0, incompleteFinalLiteralPaddingBits: decoded.capture.incompleteFinalLiteralPaddingBits ?? 0 } });
                if (decoded.capture.finalZeroPaddingBytes) report.findings.push({ disposition: 'preserved', code: 'gpx-final-zero-padding', message: 'The final literal atom contains at most two zero bytes beyond declared decoded length. These are validated serialization padding, retained in original input but excluded from the decoded filesystem; no missing bytes are synthesized.', location: { member: 'container' }, fact: { bytes: decoded.capture.finalZeroPaddingBytes } });
            } else members = readContainer();
            const { xml, root } = parseXml(members.get('Content/score.gpif')!, gpx ? 'score.gpif' : 'Content/score.gpif');
            if (!gpx) admitDescriptors(members, root, report.findings);
            source = root;
            const version = root.children.find(e => e.name === 'GPVersion')?.text.trim();
            const constructed = version === '7.0' && root.children.find(e => e.name === 'GPRevision')?.text.trim() === '0';
            const family = gpx && !constructed ? 6 : /^8(?:\.|$)/.test(version ?? '') ? 8 : 7;
            report.profile = constructed ? (gpx ? 'gpx-constructed-gpif7-fretted/0' : 'constructed-gp7-fretted/0') : `gp${family}-physical-fretted/0`;
            container = captureContainer(members, !constructed || gpx, report.findings);
            if (constructed && options.trackIds) throw new Refusal('track-selection', 'Track selection requires a source family profile.', root.location);
            if (constructed) { inventory(root, report.findings, 'constructed'); recovery = recover(root, xml, report.findings, 'constructed'); }
            else recovery = recoverArrangement(root, options.trackIds, report.findings, family);
            if (family === 8 && isFrettedScore(recovery.score) && report.findings.some(f => f.code === 'gpif-pitch-profile') && report.findings.filter(f => f.code === 'gpif-pitch-profile').every(f => (f.fact as { convention: string }).convention === 'scientific-physical')) report.profile = 'gp8-scientific-physical/0';
        }
        const families = new Map(recovery.score.parts.map(part => [part.id, part.staves?.some(staff => staff.kind === 'percussion') ? 'percussion' as const : admittedFamily(part.instrument, part.midiProgram, part.source)]));
        if (!isFrettedScore(recovery.score)) report.profile = report.profile.replace(/-(?:physical-)?fretted\//, '-arrangement/');
        if (!report.profile.includes('constructed')) {
            if ([...families.values()].every(family => family === 'guitar')) report.profile = report.profile.replace('-fretted/', '-guitar/');
            else if ([...families.values()].every(family => family === 'bass')) report.profile = report.profile.replace('-fretted/', '-bass/');
        }
        for (const part of recovery.score.parts) {
            report.findings.push({ disposition: 'preserved', code: 'instrument-admitted', message: 'Encoded instrument identity, notation role and the selected source musical graph passed admission and reader reconciliation. This is conversion admission, independent of labels or metadata eligibility.', location: part.source, fact: { sourceTrackId: part.id, instrumentReference: part.instrument, midiProgram: part.midiProgram, instrumentFamily: families.get(part.id), profile: report.profile } });
            if (!part.tuning) continue;
            report.findings.push({ disposition: 'preserved', code: 'tuning-export', message: part.tuning.some(midi => midi < 12) ? 'Complete ordered source tuning is retained in the model and exact auxiliary metadata. MusicXML cannot encode tuning octaves below zero; readable standard words preserve those pitches and representable entries remain staff-tuning.' : 'Complete ordered source open-string MIDI tuning and string count are retained as standard staff-lines/staff-tuning on a hidden alternate TAB staff. Tuning remains sounding pitch, independent of written octave transpose.', location: part.source, fact: { tuning: part.tuning, stringCount: part.tuning.length, sourceOrder: 'source-string-order', musicxmlLineOrder: 'bottom-to-top' } });
            report.findings.push({ disposition: 'inferred', code: 'tuning-spelling', message: 'Source tuning encodes MIDI values, not note spelling. MusicXML tuning step/alter/octave uses generated sharp-based reference spelling (midi-sharp-reference/0); the source MIDI values remain unchanged.', location: part.source, fact: { tuning: part.tuning, rule: 'midi-sharp-reference/0' } });
            report.findings.push({ disposition: 'inferred', code: 'tuning-carrier-staff', message: 'A nonprinting alternate TAB staff is generated only to serialize tuning and string count. It shares the ordinary staff music and is excluded from playback; no notes/rests are copied to it. It is not a source staff, performing hand or retuning instruction.', location: part.source, fact: { ordinaryStaff: 1, tuningStaff: 2, staffType: 'alternate', printObject: false, printSpacing: false } });
            report.findings.push({ disposition: 'preserved', code: 'hidden-physical-guidance', message: 'Standard MusicXML string/fret facts are retained in hidden technical notations; the score displays ordinary notes without TAB or physical numbers.', location: part.source });
        }
        const assigned: { sourceTrackId: string; musicxmlPartId: string }[] = [];
        const musicxml = writeMusicXml(recovery.score, container.display, (sourceTrackId, musicxmlPartId) => assigned.push({ sourceTrackId, musicxmlPartId }), { outputBytes: limits.resultBytes });
        if (assigned.length !== recovery.score.parts.length || new Set(assigned.map(a => a.sourceTrackId)).size !== assigned.length || new Set(assigned.map(a => a.musicxmlPartId)).size !== assigned.length) throw new Refusal('writer-identity', 'Writer did not assign one distinct identity to every admitted source part.');
        report.convertedParts = assigned.map(a => {
            const part = recovery.score.parts.find(p => p.id === a.sourceTrackId)!;
            const evidenceFindingIndices = report.findings.flatMap((f, i) => ['instrument-admitted', 'gpif-pitch-profile', 'binary-written-register'].includes(f.code) && (f.location.trackId ?? f.location.id) === part.id ? [i] : []);
            return { ...a, sourceLocation: part.source, admission: { instrumentFamily: families.get(part.id)!, profile: report.profile, evidenceFindingIndices } };
        });
        const result = { ok: true, musicxml, report, ...(source ? { source } : {}), containerSource: container.facts, occurrences: recovery.occurrences, score: recovery.score, scoreKind: isFrettedScore(recovery.score) ? 'fretted' as const : 'arrangement' as const,
            inputSource: { bytes: bytes.length, sha256: report.inputSha256, dataBase64: Bytes.view(bytes).base64() },
            ...(binarySource ? { binarySource } : {}), ...(gpxSource ? { gpxSource } : {}) };
        jsonBytes(result, limits.resultBytes);
        return freeze(result);
    } catch (e) {
        delete report.convertedParts;
        const r = e instanceof Refusal ? e : new Refusal('invalid-input', 'Input failed bounded conversion; no musical output was produced.');
        if (r.code === 'report-budget') report.findings = [];
        report.findings.push({ disposition: 'blocking', code: r.code, message: r.message, location: r.location });
        return freeze({ ok: false, report });
    }
}

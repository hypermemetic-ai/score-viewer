import {child,integer,type SourceElement as Element} from '../../core/source-xml.js';
import type {MusicalScore} from '../../core/model.js';
import {refuse,type Location} from '../../core/report.js';
import type {NativeCapture} from './capture-core.js';
import {readImageResource} from './image-resource.js';
export type SourceImage=NonNullable<MusicalScore['sourceImages']>[number];
export type ImageOwner=Pick<SourceImage,'partId'|'staff'|'beforeMeasure'|'frame'|'attachment'|'viewSource'|'placement'> & {hiddenSource?:Location};
interface Context {
 nativeVersion:string;members:NativeCapture['members'];use:(node:Element)=>unknown;consume:(node:Element)=>void;
 get:(node:Element,name:string,required?:boolean)=>string;scalar:(value:string,node:Element)=>number;
 decoration:(node:Element)=>void;mark:(source:Location)=>void;
 gap:(code:string,source:Location,message:string,disposition?:'omitted'|'inferred'|'preserved')=>void;
}
/** Image bytes are resolved solely from the admitted archive. Geometry remains source facts. */
export function createNativeImageReader(ctx:Context){
 return (node:Element,owner:ImageOwner):SourceImage|undefined=>{
  ctx.use(node);const path=child(node,'path'),linkPath=child(node,'linkPath'),size=child(node,'size');
  if(!path)return refuse('native-image','Image requires an explicit path identity.',node.location);
  if(node.text.trim()||Object.keys(node.attrs).length||path.children.length||Object.keys(path.attrs).length||linkPath&&(linkPath.children.length||Object.keys(linkPath.attrs).length))refuse('native-image','Malformed image identity.',node.location);
  if(path.text.length>2048||(linkPath?.text.length??0)>2048)refuse('native-image-budget','Image resource identity exceeds its bounded profile.',node.location);
  ctx.use(path);if(linkPath)ctx.use(linkPath);
  let imageSize:SourceImage['size'],offset:SourceImage['offset'];
  if(size){if(size.children.length||size.text.trim()||Object.keys(size.attrs).some(k=>!['w','h'].includes(k))||!size.attrs.w||!size.attrs.h)refuse('native-image','Malformed image dimensions.',size.location);imageSize={source:size.location,width:ctx.scalar(size.attrs.w,size),height:ctx.scalar(size.attrs.h,size)};ctx.consume(size);}
  const position=child(node,'offset');if(position){if(position.children.length||position.text.trim()||Object.keys(position.attrs).some(k=>!['x','y'].includes(k)))refuse('native-image','Malformed image offset.',position.location);offset={source:position.location,x:ctx.scalar(position.attrs.x??'0',position),y:ctx.scalar(position.attrs.y??'0',position)};ctx.consume(position);}
  const appearance:NonNullable<SourceImage['appearance']>=[];let automatic:SourceImage['autoScale'];
  for(const name of ['autoScale','lockAspectRatio','sizeIsSpatium','systemFlag','visible']){const field=child(node,name);if(!field)continue;if(field.children.length||Object.keys(field.attrs).length)refuse('native-image','Image boolean requires a plain source value.',field.location);const value=integer(ctx.get(node,name,true),0,1,field.location);if(name==='autoScale')automatic={source:field.location,value:value===1};else if(name!=='visible')appearance.push({source:field.location,name,value:field.text});}
  const visible=child(node,'visible')?.text.trim();
  const eid=child(node,'eid');if(eid&&(eid.children.length||Object.keys(eid.attrs).length||!eid.text.trim()||eid.text.length>256))refuse('native-identity-budget','Image identity requires a bounded scalar.',eid.location);
  for(const field of node.children)if(!['path','linkPath','size','offset','autoScale','lockAspectRatio','sizeIsSpatium','systemFlag','visible','Image','Symbol','FSymbol'].includes(field.name))appearance.push({source:field.location,name:field.name,value:JSON.stringify({text:field.text,attrs:field.attrs})});
  const obsolete=child(node,'subtype');if(obsolete&&Number(ctx.nativeVersion)<=4){if(obsolete.children.length||Object.keys(obsolete.attrs).length||obsolete.text.length>256)refuse('native-image','Obsolete image subtype must remain a bounded scalar.',obsolete.location);ctx.use(obsolete);}
  const track=child(node,'track');if(track){if(track.children.length||Object.keys(track.attrs).length)refuse('native-image','Image source track requires a scalar.',track.location);integer(ctx.get(node,'track',true),0,1023,track.location);}
  ctx.decoration(node);
  if(!path.text.trim()&&!linkPath?.text.trim()&&(!imageSize||imageSize.width<=0&&imageSize.height<=0)){ctx.gap('native-empty-image-placeholder',node.location,'The source image has no path, linked resource or positive image geometry. Its exact empty shell remains captured without fabricated content.');return;}
  ctx.mark(node.location);const resource=readImageResource(ctx.members,path.text,node.location),retained=resource.status!=='unavailable',projected=resource.status==='supported'&&!owner.viewSource&&!owner.hiddenSource&&visible!=='0';
  const {hiddenSource,...identity}=owner;
  const image:SourceImage={source:node.location,...identity,path:{source:path.location,value:path.text},...(linkPath?{linkPath:{source:linkPath.location,value:linkPath.text}}:{}),...(imageSize?{size:imageSize}:{}),...(offset?{offset}:{}),...(automatic?{autoScale:automatic}:{}),...(appearance.length?{appearance}:{}),...(hiddenSource||visible==='0'?{printObject:false}:visible==='1'?{printObject:true}:{}),...(resource.status==='supported'?{resource:resource.resource}:{}),contentStatus:projected?'embedded-standard':retained?'retained-member-unprojected':'unavailable'};
  if(!projected){if(owner.viewSource)ctx.gap('native-image-alternate-view',node.location,'Alternate-view image and exact available archive resource remain separate from selected output.','preserved');else if(resource.status==='supported')ctx.gap('native-image-hidden-standard-limit',node.location,'The hidden image remains retained. MusicXML image has no print-object switch, so its resource is auxiliary rather than made visible.');else if(resource.status==='unprojected')ctx.gap(`native-image-${resource.reason}`,node.location,'The archive member remains retained without an unqualified or active-resource image projection.');else ctx.gap('native-image-unavailable',node.location,'The resource is absent from the admitted package. No ambient path is read or replacement image invented.');}
  return image;
 };
}

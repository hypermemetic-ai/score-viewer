import { encodeBase64 } from '../../core/portable-bytes.js';
import { captureXml, child, children, text, type SourceElement } from '../../core/source-xml.js';
import { freeze, refuse } from '../../core/report.js';
import { nativeAdapter, nativeLimits } from './limits.js';
export { nativeAdapter, nativeLimits } from './limits.js';
/** Host capabilities outside the portable reader. Node and WebView hosts must return identical facts. */
export interface NativeHost {
    /** Lowercase hexadecimal SHA-256 of exactly these bytes. */
    readonly sha256: (bytes: Uint8Array) => string;
    /** Strictly admitted, decoded ZIP members in directory order; refusals are thrown. */
    readonly zipMembers: (bytes: Uint8Array) => Map<string, Uint8Array>;
    /** Process peak RSS in KiB where the host exposes it; omitted from telemetry otherwise. */
    readonly peakRssKiB?: () => number;
}
export interface NativeCapture {
    schema: 'score-converter-musescore-source/0'; inputBase64: string; inputSha256: string;
    container: 'xml' | 'zip'; primaryMember: string;
    members: { name: string; sha256: string; base64: string }[];
    root: Pick<SourceElement, 'name' | 'attrs' | 'location'>; nativeVersion: string; producerVersion: string; producerRevision: string;
    adapterVersion: string;
}
/** The full syntactic tree is transient decoder state, not another worker/result payload. */
export interface ParsedNativeCapture extends NativeCapture { root: SourceElement; styleRoot?: SourceElement }
export function compactCapture(capture: ParsedNativeCapture): NativeCapture {
    const { styleRoot: _transientStyle, ...source } = capture;
    return freeze({ ...source, root: { name: capture.root.name, attrs: capture.root.attrs, location: capture.root.location } });
}
// Embedded part scores repeat the primary music. Whole-score conversion reads
// only their headers, staff links, measure counts and frames, so their voice
// contents are counted for the inventory without being retained.
const nestedViewVoice = (ancestors: readonly SourceElement[], name: string): boolean => name === 'voice' && ancestors.length === 5
    && ancestors[0].name === 'museScore' && ancestors[1].name === 'Score' && ancestors[2].name === 'Score' && ancestors[3].name === 'Staff' && ancestors[4].name === 'Measure';
export function captureNative(bytes: Uint8Array, host: NativeHost, options: { retainViewMusic?: boolean } = {}): ParsedNativeCapture {
    if (bytes.length > nativeLimits.inputBytes) refuse('input-size', 'Native input exceeds 32 MiB; no decoding started.');
    const zip = bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && bytes[2] === 0x03 && bytes[3] === 0x04;
    const members = zip ? host.zipMembers(bytes) : new Map([['input.mscx', new Uint8Array(bytes)]]);
    let primary = 'input.mscx', styleName: string | undefined;
    if (zip) {
        const declarations = members.get('META-INF/container.xml');
        if (!declarations) return refuse('native-container', 'MSCZ requires its primary-score declaration; suffix guessing is not admitted.');
        const container = captureXml(declarations, 'META-INF/container.xml');
        if (container.name !== 'container' || Object.keys(container.attrs).length || container.children.some(e => e.name !== 'rootfiles')) refuse('native-container', 'Unsupported native container declaration.', container.location);
        const files = child(container, 'rootfiles', true)!;
        const names = files.children.map(e => {
            if (e.name !== 'rootfile' || Object.keys(e.attrs).some(k => k !== 'full-path') || !e.attrs['full-path'] || e.children.length || e.text.trim()) refuse('native-container', 'Malformed rootfile declaration.', e.location);
            if (!members.has(e.attrs['full-path'])) refuse('native-container', 'Declared member is missing.', e.location);
            return e.attrs['full-path'];
        });
        if (new Set(names).size !== names.length) refuse('native-container', 'Duplicate native rootfile declarations.', files.location);
        const scores = names.filter(n => n.endsWith('.mscx') && !n.includes('/'));
        if (scores.length !== 1 || [...members.keys()].some(n => n.endsWith('.mscx') && !n.includes('/') && !scores.includes(n))) refuse('native-container', 'Expected exactly one declared primary root score.', files.location);
        primary = scores[0];
        if (names.includes('score_style.mss')) styleName = 'score_style.mss';
    }
    const root = captureXml(members.get(primary)!, primary, options.retainViewMusic === false ? { prune: nestedViewVoice } : {});
    if (root.name !== 'museScore' || Object.keys(root.attrs).some(k => k !== 'version') || children(root, 'Score').length !== 1) refuse('native-root', 'Expected one museScore document with one primary Score.', root.location);
    if (styleName && members.get(styleName)!.length > nativeLimits.styleBytes) refuse('native-style-budget', 'Declared native style exceeds its independent 1 MiB inert-data budget.', { member: styleName });
    const styleRoot = styleName ? captureXml(members.get(styleName)!, styleName) : undefined;
    if (styleRoot && (styleRoot.name !== 'museScore' || styleRoot.attrs.version !== root.attrs.version || Object.keys(styleRoot.attrs).some(k => k !== 'version') || styleRoot.children.length !== 1 || styleRoot.children[0].name !== 'Style')) refuse('native-style-root', 'Declared native score style needs one inert matching-version Style document.', styleRoot.location);
    const inputBase64 = encodeBase64(bytes);
    const captureBytes = inputBase64.length + [...members.values()].reduce((n, value) => n + 4 * Math.ceil(value.length / 3), 0);
    if (captureBytes > nativeLimits.captureBytes - 4 * 1024 * 1024) refuse('native-capture-budget', 'Byte-exact source capture exceeds the bounded packet budget.');
    return freeze({ schema: 'score-converter-musescore-source/0', inputBase64,
        inputSha256: host.sha256(bytes), container: zip ? 'zip' : 'xml', primaryMember: primary,
        members: [...members].map(([name, value]) => ({ name, sha256: host.sha256(value), base64: !zip && name === primary ? inputBase64 : encodeBase64(value) })),
        root, ...(styleRoot ? { styleRoot } : {}), nativeVersion: root.attrs.version ?? '', producerVersion: text(root, 'programVersion'), producerRevision: text(root, 'programRevision'), adapterVersion: nativeAdapter });
}

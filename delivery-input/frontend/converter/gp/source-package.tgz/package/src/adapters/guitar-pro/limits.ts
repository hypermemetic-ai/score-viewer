export const limits = Object.freeze({
    inputBytes: 8 * 1024 * 1024, entries: 32, memberBytes: 4 * 1024 * 1024,
    decodedBytes: 8 * 1024 * 1024, compressionRatio: 100,
    xmlDepth: 48, xmlNodes: 100_000, xmlText: 2 * 1024 * 1024,
    xmlAttributes: 16, xmlName: 80, xmlAttributeValue: 4096, xmlNodeText: 65536,
    xmlPath: 4096, xmlPathTotal: 8 * 1024 * 1024,
    tracks: 32, measures: 512, occurrences: 20_000,
    binaryRecords: 200_000, captureBytes: 24 * 1024 * 1024,
    reportBytes: 8 * 1024 * 1024, resultBytes: 32 * 1024 * 1024,
    workerMs: 5000, workerHeapMb: 96
});

import { child, value, type Element } from './xml.js';
import { discoverArrangementGraph, sourceIds } from './arrangements.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import type { MusicalPart } from '../../core/model.js';

/** MusicXML needs the performed music underneath a measure-repeat notation style.
 * Native GPIF may encode that music solely as a SimileMark and absent voice slots. */
export function expandMeasureRepeats(root: Element, findings: Finding[]) {
    const graph = discoverArrangementGraph(root);
    if (graph.slots.length !== 1) refuse('measure-repeat-scope', 'Measure-repeat recovery operates on one original physical staff.', root.location);
    const ordered = graph.masterBars.children.map(master => graph.bars.get(sourceIds(master, 'Bars')[0])!);
    const definitions = new Map(graph.voices), recoveredBars: Element[] = [];
    const groups: ({ source: Location; count: 1 | 2; from: number; derived: boolean } | undefined)[] = [];
    let nextId = 0;
    for (const [index, bar] of ordered.entries()) {
        const mark = child(bar, 'SimileMark', false);
        if (!mark) { recoveredBars.push(bar); groups.push(undefined); continue; }
        if (mark.children.length || Object.keys(mark.attrs).length) refuse('measure-repeat', 'Simile mark requires a plain source subtype.', mark.location);
        const kind = mark.text.trim(), count = kind === 'Simple' ? 1 : 2;
        if (!['Simple', 'FirstOfDouble', 'SecondOfDouble'].includes(kind)) refuse('measure-repeat', 'Unknown source measure-repeat mark.', mark.location);
        if (kind === 'FirstOfDouble' && (index < 2 || value(ordered[index + 1] ?? bar, 'SimileMark', false) !== 'SecondOfDouble') || kind === 'SecondOfDouble' && (index < 3 || value(ordered[index - 1], 'SimileMark', false) !== 'FirstOfDouble') || index < count)
            refuse('measure-repeat', 'Measure-repeat group requires the complete previous source pattern and matching double-mark endpoints.', mark.location);
        const from = index - count;
        const sameMeter = (i: number) => value(graph.masterBars.children[i], 'Time');
        if (sameMeter(index) !== sameMeter(from)) refuse('measure-repeat-meter', 'A repeated source pattern cannot silently acquire a different measure duration.', mark.location);
        const slots = sourceIds(bar, 'Voices'), hasMusic = slots.filter(id => id !== '-1').some(id => sourceIds(definitions.get(id)!, 'Beats').length);
        groups.push({ source: mark.location, count, from, derived: !hasMusic });
        if (hasMusic) { recoveredBars.push(bar); continue; }
        const pattern = recoveredBars[from];
        const voices = sourceIds(pattern, 'Voices').map(id => {
            if (id === '-1') return id;
            while (definitions.has(String(nextId))) nextId++;
            if (nextId > 999999) refuse('identity-budget', 'No bounded voice identity remains for source repeat expansion.', mark.location);
            const original = definitions.get(id)!, alias = String(nextId++);
            definitions.set(alias, { ...original, attrs: { ...original.attrs, id: alias } });
            return alias;
        });
        recoveredBars.push({ ...bar, children: bar.children.map(field => field.name === 'Voices' ? { ...field, text: voices.join(' ') } : field) });
        findings.push({ disposition: 'inferred', code: 'source-measure-repeat-expansion', message: 'An explicit source simile mark repeats the previous one/two-bar pattern. Its MusicXML projection includes that performed music and a standard measure-repeat style; no new authored attacks are claimed.', location: mark.location, fact: { fromMeasure: from + 1, targetMeasure: index + 1, count } });
    }
    const usedVoices = new Set(recoveredBars.flatMap(bar => sourceIds(bar, 'Voices').filter(id => id !== '-1')));
    const projected = { ...root, children: root.children.map(container => container.name === 'Bars' ? { ...container, children: recoveredBars } : container.name === 'Voices' ? { ...container, children: [...usedVoices].map(id => definitions.get(id)!) } : container) };
    return {
        root: projected,
        apply(part: MusicalPart): void {
            let previous: 1 | 2 | undefined;
            for (const [index, measure] of part.measures.entries()) {
                const group = groups[index], count = group?.count;
                if (group && !group.derived) {
                    const signature = (m: typeof measure) => JSON.stringify(m.voices.map(voice => voice.map(event => [event.start, event.duration, event.type, event.dots, event.notes.map(note => [note.kind, note.written ? [note.written.step,note.written.alter,note.written.octave] : undefined, note.sounding?.midi, note.string, note.fret, note.tieStart, note.tieStop, note.kind === 'unpitched' ? note.unpitched.midi : undefined])])));
                    if (signature(measure) !== signature(part.measures[group.from])) refuse('measure-repeat-conflict', 'Explicit underlying music contradicts the source repeat pattern.', group.source);
                }
                if (previous !== count) {
                    if (previous) (measure.measureRepeats ??= []).push({ source: group?.source ?? ordered[index].location, staff: 1, type: 'stop', count: previous });
                    if (group) (measure.measureRepeats ??= []).push({ source: group.source, staff: 1, type: 'start', count: group.count, slashes: group.count });
                }
                if (group?.derived) for (const voice of measure.voices) for (const event of voice) event.measureRepeatProjection = { source: group.source, sourceMeasure: group.from + 1 };
                previous = count;
            }
        }
    };
}

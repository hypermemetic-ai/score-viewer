const single: Record<string, string> = { Staccato: 'staccato', Tenuto: 'tenuto', Accent: 'accent', Marcato: 'strong-accent',
        Staccatissimo: 'staccatissimo', StaccatissimoWedge: 'staccatissimo', StaccatissimoStroke: 'spiccato',
        TenutoStaccato: 'detached-legato', SoftAccent: 'soft-accent', Stress: 'stress', Unstress: 'unstress' };
const combinations = new Set(['AccentStaccato', 'MarcatoStaccato', 'TenutoAccent', 'MarcatoTenuto',
        'SoftAccentStaccato', 'SoftAccentTenuto', 'SoftAccentTenutoStaccato']);
/** Finite native symbol facts, normalized independently into standard musical signs. */
export function articulationNames(symbol: string): string[] | undefined {
    const shape = /^artic([A-Za-z]+)(?:Above|Below)$/.exec(symbol)?.[1];
    if (!shape) return undefined;
    if (Object.hasOwn(single, shape)) return [single[shape]];
    // Only registered compound signs enter this decomposition; arbitrary identifiers do not.
    if (!combinations.has(shape)) return undefined;
    const tokens = shape.match(/SoftAccent|TenutoStaccato|Accent|Staccato|Marcato|Tenuto/g)!;
    return tokens.map(token => single[token]);
}

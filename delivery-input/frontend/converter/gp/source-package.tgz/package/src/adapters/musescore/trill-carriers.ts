/** Private source-qualified positive Trill carrier selection. Logical endpoints stay separate. */
import {child,children,hasCommentOrCdata,type SourceElement as Element} from '../../core/source-xml.js';
import {add,compare,equal,mul,q,type Rational} from '../../core/rational.js';
import type {MusicalEvent,Meter,MusicalMeasure,TrillNotationAttachment} from '../../core/model.js';
// Only a complete source-qualified CR pool supplies this private carrier index.
// It does not inspect public output or infer source clocks.
export interface SourceTrillCarrierPoint { event:MusicalEvent; measure:number; track:number; clock:Rational }
const key=(clock:Rational)=>clock.n+'/'+clock.d;
const onTick=(r:Rational)=>Number.isSafeInteger(r.n)&&Number.isSafeInteger(r.d)&&r.d>0&&Number.isSafeInteger(r.n*480)&&r.n*480%r.d===0;
export interface SourceTrillCarrierIndex { starts:Map<string,SourceTrillCarrierPoint[]>; measures:Map<number,SourceTrillCarrierPoint[]>; ends:Map<string,SourceTrillCarrierPoint|null> }
export function indexNativeTrillCarriers(points: readonly SourceTrillCarrierPoint[]):SourceTrillCarrierIndex|undefined {
    const starts=new Map<string,SourceTrillCarrierPoint[]>(),measures=new Map<number,SourceTrillCarrierPoint[]>(),seen=new Set<string>();
    for(const p of points){if(p.event.grace)continue;const intrinsic=p.measure+':'+p.track+':'+key(p.clock);
        if(!Number.isInteger(p.track)||p.track<0||p.track>3||seen.has(intrinsic)||!onTick(p.clock)||!onTick(p.event.duration)||compare(p.event.duration,q(0))<=0)return;
        seen.add(intrinsic);const s=starts.get(key(p.clock))??[];s.push(p);starts.set(key(p.clock),s);const m=measures.get(p.measure)??[];m.push(p);measures.set(p.measure,m);
    }
    for(const s of starts.values())s.sort((a,b)=>a.track-b.track);
    for(const m of measures.values())m.sort((a,b)=>compare(a.clock,b.clock)||a.track-b.track);
    return {starts,measures,ends:new Map()};
}
export function selectNativeTrillCarriers(startIndex:SourceTrillCarrierIndex,endIndex:SourceTrillCarrierIndex,partId:string,staff:number,start:Rational,end:Rational,endMeasure:number):{start:TrillNotationAttachment;end:TrillNotationAttachment}|undefined {
    if(compare(start,end)>=0||!onTick(start)||!onTick(end))return;
    const first=startIndex.starts.get(key(start))?.[0],endKey=endMeasure+':'+key(end);let last=endIndex.ends.get(endKey);
    if(last===undefined){let release=q(-1);last=null;const limit=add(end,q(-1,480));
        for(const p of endIndex.measures.get(endMeasure)??[]){if(compare(p.clock,limit)>0)break;const r=add(p.clock,p.event.duration);
            if(compare(r,release)>=0&&compare(r,end)<=0){last=p;release=r;}}
        endIndex.ends.set(endKey,last);
    }
    if(!first||!last||!equal(add(last.clock,last.event.duration),end)||compare(last.clock,start)<0)return;
    const attachment=(p:SourceTrillCarrierPoint):TrillNotationAttachment=>({source:p.event.source,origin:'native-segment-anchor',partId,measure:p.measure,position:p.event.start,staff,voiceId:p.event.voiceId!,eventId:p.event.id});
    if([first,last].some(p=>!p.event.voiceId||p.event.staff!==staff))return;
    return {start:attachment(first),end:attachment(last)};
}
// Reader source qualification. All rows and clock contexts below are
// registered by the existing reader while decoding the same captured source.
const whitespace=(e:Element)=>/^[ \t\r\n]*$/.test(e.text)&&!hasCommentOrCdata(e);
const plain=(e:Element)=>!Object.keys(e.attrs).length&&!e.children.length&&!hasCommentOrCdata(e);
const container=(e:Element)=>!Object.keys(e.attrs).length&&whitespace(e);
const scalar=(e:Element,name:string,values:readonly(string|undefined)[])=>{const xs=children(e,name);return xs.length===0?values.includes(undefined):xs.length===1&&plain(xs[0])&&values.includes(xs[0].text);};
const unique=(e:Element,names:readonly string[])=>names.every(n=>children(e,n).length<=1);
const emptyMain=(e:Element)=>scalar(e,'linkedMain',[undefined,'']);
const graceNames=['appoggiatura','acciaccatura','grace4','grace16','grace32','grace8after','grace16after','grace32after'];
const lastOrdinaryOwner=(nodes:Element[])=>{for(let i=nodes.length-1;i>=0;i--)if((nodes[i].name==='Chord'||nodes[i].name==='Rest')&&!nodes[i].children.some(c=>graceNames.includes(c.name)))return i;return -1;};
const ordinaryTypes=['whole','half','quarter','eighth','16th','32nd','64th','128th'];
const noteFields=new Set(['pitch','tpc','tpc2','visible','play','linkedMain','Accidental']);
const chordFields=new Set(['durationType','dots','visible','small','noStem','play','StemDirection','linkedMain','Note','Articulation','Spanner',...graceNames]);
const restFields=new Set(['durationType','dots','visible','linkedMain','NoteDot']);
const voiceFields=new Set(['Chord','Rest','TimeSig','Clef','KeySig','Dynamic','Tempo','RehearsalMark','StaffText','SystemText','Expression','Breath','Fermata','Harmony','Symbol','BarLine','Spanner','location']);
export interface SourceTrillCursorClock {node:Element;fraction:Element;voice:number;before:Rational;delta:Rational;after:Rational}
export interface SourceTrillTupletClock {node:Element;actual:number;normal:number;voice:number;end:Element|undefined}
export interface SourceTrillPairClock {
 source:Element;voice:number;displayed:Rational;tuplet?:SourceTrillTupletClock;
 first:{node:Element;event:MusicalEvent;elapsed:{node:Element;value:Rational}};
 second?:{node:Element;event:MusicalEvent;elapsed:{node:Element;value:Rational}};
}
export interface SourceTrillNeutralClock {node:Element;owner:Element;voice?:number;role:'repeat'|'segment-spacing'|'hook-drawing'|'beam-distribution'|'beam-autoplace'|'barline'}
export interface SourceTrillRow extends SourceTrillCarrierPoint { node:Element; voice:number; clockTuplets?:SourceTrillTupletClock[]; clockPair?:SourceTrillPairClock; encodedFullRest?:{node:Element;duration:Rational} }
export interface SourceTrillBar {
 node:Element; voices:Element[]; initialTime:Meter; initialTimeSource:Element|undefined;
 model:MusicalMeasure; start:Rational; rows:SourceTrillRow[];
 declaredDuration?:Rational; tuplets?:SourceTrillTupletClock[]; cursors?:SourceTrillCursorClock[];
 pairs?:SourceTrillPairClock[];neutralClocks?:SourceTrillNeutralClock[];
}
// Every 3.x/4.x writer anchors a trill at its first chord/rest and ends it on
// the last chord/rest ending at tick2; the producer build does not change that.
export const trillCarrierProfile=(root:Element,primaryNode:Element,scoreNode:Element,division:number)=>
 root.name==='museScore'&&Object.keys(root.attrs).join(',')==='version'&&/^(?:3\.0[12]|4\.[0-7]0)$/.test(root.attrs.version)&&whitespace(root)
 &&scoreNode===primaryNode&&children(root,'Score').length===1&&children(root,'Score')[0]===scoreNode&&container(scoreNode)
 &&division===480&&scalar(scoreNode,'Division',[undefined,'480'])
 &&children(root,'programVersion').every(plain)&&children(root,'programRevision').every(plain);
export function trillMeterClock(e:Element|undefined,time:Meter):boolean {
 if(!e||!container(e)||!scalar(e,'sigN',[String(time.beats)])||!scalar(e,'sigD',[String(time.unit)])
  ||!scalar(e,'stretchN',[undefined,'1'])||!scalar(e,'stretchD',[undefined,'1'])||!scalar(e,'isCourtesy',[undefined,'0'])||!emptyMain(e))return false;
 // Display text/symbol/Groups do not change the selected own numeric fraction.
 return unique(e,['sigN','sigD','stretchN','stretchD','isCourtesy','visible','subtype','textN','textD','linkedMain','Groups'])
  &&e.children.every(c=>c.name==='Groups'?container(c)&&c.children.every(n=>n.name==='Node'&&!n.children.length&&whitespace(n)&&Object.keys(n.attrs).sort().join(',')==='action,pos'&&Object.values(n.attrs).every(v=>/^\d+$/.test(v))):['sigN','sigD','stretchN','stretchD','isCourtesy','visible','subtype','textN','textD','linkedMain'].includes(c.name)&&plain(c));
}
export function trillMeasureClock(bar:SourceTrillBar,prefix=false,neutral?:ReadonlySet<Element>):boolean {
 const finiteLen=prefix&&Object.keys(bar.node.attrs).join(',')==='len'&&/^[1-9]\d*\/[1-9]\d*$/.test(bar.node.attrs.len)&&bar.node.attrs.len.length<=64&&whitespace(bar.node);
 const nominal=q(bar.initialTime.beats*4,bar.initialTime.unit);let durationKnown=equal(bar.model.duration,nominal);
 if(prefix&&bar.declaredDuration)durationKnown=equal(bar.declaredDuration,nominal)&&equal(bar.model.duration,bar.declaredDuration);
 if(finiteLen){const [n,d]=bar.node.attrs.len.split('/').map(Number),span=bar.declaredDuration;
  durationKnown=!!span&&compare(span,q(0))>0&&[n,d,n*4,(span?.n??0)*d,n*4*(span?.d??0)].every(Number.isSafeInteger)
   &&span.n*d===n*4*span.d&&equal(bar.model.duration,span);}
 if(!(container(bar.node)||finiteLen)||!bar.node.children.every(c=>['voice','LayoutBreak','BarLine'].includes(c.name)||prefix&&(neutral?.has(c)||c.name==='irregular'&&plain(c)&&['0','1'].includes(c.text)))||children(bar.node,'irregular').length>1||bar.voices.length<1||bar.voices.length>4
  ||!trillMeterClock(bar.initialTimeSource,bar.initialTime)||!durationKnown)return false;
 for(const [vi,v]of bar.voices.entries()){
  if(!container(v)||!v.children.every(c=>voiceFields.has(c.name)||prefix&&(neutral?.has(c)||['Tuplet','endTuplet','Beam'].includes(c.name))))return false;
  const first=v.children.findIndex(c=>c.name==='Chord'||c.name==='Rest');
  for(const [i,n]of v.children.entries())if(n.name==='TimeSig'&&(vi!==0||first>=0&&i>=first||n!==bar.initialTimeSource||!trillMeterClock(n,bar.initialTime)))return false;
 }
 return true;
}
const noteOwner=(n:Element)=>container(n)&&emptyMain(n)&&unique(n,['pitch','tpc','tpc2','visible','play','linkedMain','Accidental'])
 &&children(n,'pitch').length===1&&children(n,'tpc').length===1&&scalar(n,'visible',[undefined,'0','1'])&&scalar(n,'play',[undefined,'0','1'])
 &&n.children.every(c=>noteFields.has(c.name)&&(c.name==='Accidental'?container(c)&&unique(c,['subtype','visible','role','small','placement','bracket','linkedMain'])&&c.children.every(plain):plain(c)));
const chordSlur=(s:Element)=>s.name==='Spanner'&&Object.keys(s.attrs).length===1&&s.attrs.type==='Slur'&&whitespace(s);
const owner=(n:Element)=>container(n)&&emptyMain(n)&&unique(n,['durationType','dots','visible','small','noStem','play','StemDirection','linkedMain',...graceNames])
 &&scalar(n,'dots',[undefined,'0','1','2','3'])&&scalar(n,'visible',[undefined,'0','1'])
 &&scalar(n,'durationType',n.name==='Rest'?[...ordinaryTypes,'measure']:ordinaryTypes)
 &&(n.name==='Chord'?scalar(n,'small',[undefined,'0','1'])&&scalar(n,'noStem',[undefined,'0','1'])&&scalar(n,'play',[undefined,'0','1'])&&scalar(n,'StemDirection',[undefined,'auto','up','down'])&&n.children.every(c=>chordFields.has(c.name)&&(c.name==='Note'?noteOwner(c):c.name==='Spanner'?chordSlur(c):c.name==='Articulation'?container(c):plain(c))):n.name==='Rest'&&n.children.every(c=>restFields.has(c.name)&&(c.name==='NoteDot'?container(c)&&scalar(c,'visible',[undefined,'0','1'])&&c.children.every(f=>f.name==='visible'&&plain(f)):plain(c))));
const sameLocation=(a:MusicalEvent['source'],b:Element['location'])=>Object.keys(a).length===Object.keys(b).length&&Object.keys(a).every(k=>a[k as keyof typeof a]===b[k as keyof typeof b]);
export function trillSourcePool(bar:SourceTrillBar,staff:number):SourceTrillRow[]|undefined {
 if(!trillMeasureClock(bar))return;
 const byNode=new Map(bar.rows.map(r=>[r.node,r]));if(byNode.size!==bar.rows.length)return;
 const ids=new Map<string,SourceTrillRow>();for(const row of bar.rows){if(ids.has(row.event.id))return;ids.set(row.event.id,row);}
 let count=0;
 for(const [vi,voice]of bar.voices.entries()){
  const pending:SourceTrillRow[]=[];
  const last=lastOrdinaryOwner(voice.children);
  for(const [i,node]of voice.children.entries()){
   if(node.name==='location'){
    // Existing reciprocal-only cursor rewinds after the last timed CR do not
    // change any native segment owner. Earlier or intervening cursors hold.
    if(i<last||!container(node)||!unique(node,['fractions'])||node.children.length!==1||!scalar(node,'fractions',children(node,'fractions').map(c=>c.text))||!/^[-+]?\d+\/[1-9]\d*$/.test(child(node,'fractions')!.text)
      ||voice.children.slice(i+1).some(n=>n.name!=='Spanner'))return;
   }
   if(node.name!=='Chord'&&node.name!=='Rest')continue;count++;
   const r=byNode.get(node);if(!r||r.track!==vi||r.voice!==vi||r.event.staff!==staff||r.event.voiceId!==String((staff-1)*4+vi+1)||!sameLocation(r.event.source,node.location)||!owner(node)
     ||!equal(r.clock,add(bar.start,r.event.start))||children(node,'Note').length!==r.event.notes.length||children(node,'Note').some((n,ni)=>!sameLocation(r.event.notes[ni].source,n.location)))return;
   const gs=node.children.filter(c=>graceNames.includes(c.name));if(gs.length>1)return;
   if(gs.length){const g=r.event.grace,host=g?ids.get(g.hostId):undefined;
    if(!g||!host||host.event.grace||host.node.name!=='Chord'||host.voice!==vi||host.measure!==r.measure
     ||!equal(g.before?host.event.start:add(host.event.start,host.event.duration),r.event.start)
     ||!equal(r.event.duration,q(0))||!r.event.writtenDuration||compare(r.event.writtenDuration,q(0))<=0
     ||g.before===gs[0].name.endsWith('after')||!sameLocation(g.source,gs[0].location)||!plain(gs[0])||gs[0].text!==''||!Number.isInteger(g.index)||g.index<0)return;
    pending.push(r);
   }else{
    if(r.event.grace||r.event.durationOverride||r.event.tuplet||r.event.timeModification||r.event.staffTiming)return;
    // Source creation order supplies one contiguous host group. Grace index is
    // over ALL pending before/after markers, not over each display side.
    if(pending.some((g,i)=>g.event.grace!.hostId!==r.event.id||g.event.grace!.index!==i))return;
    pending.length=0;
   }
  }
  if(pending.length)return;
 }
 return count===bar.rows.length?bar.rows:undefined;
}
const prefixTempo=(e:Element)=>e.name==='Tempo'&&container(e)&&emptyMain(e)&&unique(e,['tempo','followText','linkedMain','visible','minDistance','offset','text'])
 &&children(e,'tempo').length===1&&scalar(e,'followText',[undefined,'0','1'])&&scalar(e,'visible',[undefined,'0','1'])
 &&e.children.every(n=>n.name==='text'?!Object.keys(n.attrs).length&&!hasCommentOrCdata(n):n.name==='offset'?!n.children.length&&whitespace(n)&&Object.keys(n.attrs).sort().join(',')==='x,y'&&Object.values(n.attrs).every(v=>/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(v)&&Number.isFinite(Number(v))):['tempo','followText','linkedMain','visible','minDistance'].includes(n.name)&&plain(n))
 &&Number(child(e,'tempo')!.text)>0&&/^[+]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(child(e,'tempo')!.text);
const reciprocalClockSpanner=(node:Element)=>node.name==='Spanner'&&whitespace(node)&&Object.keys(node.attrs).join(',')==='type'
 &&['Trill','Slur','Tie','HairPin','Pedal','Ottava','TextLine','NoteLine'].includes(node.attrs.type)&&node.children.length===1
 &&['next','prev'].includes(node.children[0].name)&&trillLocation(node.children[0]);
const clockNeutralOwnerFields=new Set(['Note','Articulation','Spanner','Ornament','Stem','StemDirection','BeamMode','visible','small','noStem','play','linkedMain','autoplace','offset','NoteDot']);
// These finite native roles are registered only after their existing source
// handler succeeds. They prove preceding clock neutrality, never carrier facts.
export function trillNeutralClockRole(node:Element,role:SourceTrillNeutralClock['role']):boolean {
 if(role==='repeat')return plain(node)&&(node.name==='startRepeat'&&node.text===''||node.name==='endRepeat'&&/^\d{1,3}$/.test(node.text)&&Number(node.text)<=128);
 if(!container(node)||!emptyMain(node))return false;
 if(role==='segment-spacing')return node.name==='Segment'&&node.children.length===1&&child(node,'leadingSpace')!==undefined&&plain(node.children[0])&&/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(node.children[0].text)&&Number.isFinite(Number(node.children[0].text));
 if(role==='hook-drawing')return node.name==='Hook'&&unique(node,['name','autoplace'])&&scalar(node,'name',['flag8thUp','flag8thDown','flag16thUp','flag16thDown'])&&scalar(node,'autoplace',[undefined,'0','1'])&&node.children.every(c=>['name','autoplace'].includes(c.name)&&plain(c));
 if(role==='beam-distribution')return node.name==='Beam'&&node.children.length===1&&scalar(node,'distribute',['0','1']);
 if(role==='beam-autoplace')return node.name==='Beam'&&node.children.length===1&&scalar(node,'autoplace',['0','1']);
 return role==='barline'&&node.name==='BarLine'&&unique(node,['subtype','span','visible','linkedMain'])&&scalar(node,'subtype',[undefined,'normal','end','double','broken','dashed','dotted'])&&scalar(node,'span',[undefined,'0','1'])&&scalar(node,'visible',[undefined,'0','1'])&&node.children.every(c=>['subtype','span','visible','linkedMain'].includes(c.name)&&plain(c));
}
const neutralClockNodes=(bar:SourceTrillBar):Set<Element>|undefined=>{
 if(!bar.neutralClocks?.length)return new Set();
 const owners=new Map<Element,{owner:Element;voice?:number}>();
 for(const node of bar.node.children)owners.set(node,{owner:bar.node});
 for(const [voice,v]of bar.voices.entries())for(const node of v.children){owners.set(node,{owner:v,voice});if(node.name==='Chord'||node.name==='Rest')for(const field of node.children)owners.set(field,{owner:node,voice});}
 const result=new Set<Element>();
 for(const proof of bar.neutralClocks??[]){const actual=owners.get(proof.node);
  if(result.has(proof.node)||!actual||actual.owner!==proof.owner||actual.voice!==proof.voice||!trillNeutralClockRole(proof.node,proof.role)
   ||proof.role==='repeat'&&proof.owner!==bar.node||proof.role==='hook-drawing'&&proof.owner.name!=='Chord'
   ||!['repeat','hook-drawing'].includes(proof.role)&&proof.owner!==bar.voices[proof.voice!])return;
  result.add(proof.node);
 }
 return result;
};
// Source clock prefix is separate from carrier pitch/display ownership. It
// inspects known duration/grace/cursor roles only, without re-reading notes.
export function trillSourceClockPrefix(bar:SourceTrillBar,neutralBeam:(e:Element)=>boolean=()=>false):boolean {
 const neutral=neutralClockNodes(bar);if(!neutral||!trillMeasureClock(bar,true,neutral))return false;
 const byNode=new Map(bar.rows.map(r=>[r.node,r]));if(byNode.size!==bar.rows.length)return false;

 const cursors=new Map((bar.cursors??[]).map(c=>[c.node,c]));if(cursors.size!==(bar.cursors??[]).length)return false;
 const tuplets=new Map((bar.tuplets??[]).map(t=>[t.node,t])),ends=new Map((bar.tuplets??[]).filter(t=>t.end).map(t=>[t.end!,t]));
 const ownerVoice=new Map(bar.voices.flatMap((voice,vi)=>voice.children.map(node=>[node,vi] as const)));
 const sourceOrder=new Map<Element,{index:number;cuts:number}>();
 for(const voice of bar.voices){let cuts=0;for(const [index,node]of voice.children.entries()){sourceOrder.set(node,{index,cuts});if(['Chord','Rest','TimeSig','Tuplet','endTuplet','location','track','tick','stretch'].includes(node.name))cuts++;}}
 if(tuplets.size!==(bar.tuplets??[]).length||ends.size!==tuplets.size)return false;
 const pairs=new Map<Element,SourceTrillPairClock>();
 for(const pair of bar.pairs??[]){const a=pair.first,b=pair.second,voice=bar.voices[pair.voice],t=pair.tuplet;
  if(t&&(tuplets.get(t.node)!==t||t.voice!==pair.voice||ownerVoice.get(t.node)!==pair.voice||!t.end||ownerVoice.get(t.end)!==pair.voice
   ||!Number.isInteger(t.actual)||!Number.isInteger(t.normal)||t.actual<1||t.actual>128||t.normal<1||t.normal>128))return false;
  const scaling=t?q(t.normal,t.actual):q(1),combined=mul(q(1,2),scaling);
  if(!b||!voice||pairs.has(a.node)||pairs.has(b.node)||a.node===b.node||a.node.name!=='Chord'||b.node.name!=='Chord'
   ||ownerVoice.get(a.node)!==pair.voice||ownerVoice.get(b.node)!==pair.voice||child(a.node,'Tremolo')!==pair.source||children(a.node,'Tremolo').length!==1||children(b.node,'Tremolo').length
   ||!container(pair.source)||!emptyMain(pair.source)||!unique(pair.source,['subtype','strokeStyle','visible','linkedMain'])||!scalar(pair.source,'subtype',['c8','c16','c32','c64'])
   ||!scalar(pair.source,'strokeStyle',[undefined,'0','1','2'])||!scalar(pair.source,'visible',[undefined,'0','1'])||pair.source.children.some(n=>!['subtype','strokeStyle','visible','linkedMain'].includes(n.name)||!plain(n)))return false;
  const ai=sourceOrder.get(a.node),bi=sourceOrder.get(b.node);
  if(!ai||!bi||bi.index<=ai.index||bi.cuts-ai.cuts!==1)return false;
  const ti=t?sourceOrder.get(t.node):undefined,ei=t?sourceOrder.get(t.end!):undefined;
  if(t&&(!ti||!ei||ti.index>=ai.index||ei.index<=bi.index))return false;
  for(const [point,type]of [[a,'start'],[b,'stop']]as const){const row=byNode.get(point.node),e=point.event,elapsed=point.elapsed,ornament=e.ornaments?.find(o=>o.kind==='tremolo'&&o.type===type);
   if(!row||row.event!==e||row.voice!==pair.voice||row.clockPair!==pair||e.grace||e.fullMeasureRest||e.staffTiming
    ||(t?(row.clockTuplets?.length!==1||row.clockTuplets[0]!==t||(e.tupletBoundary??[]).some(marker=>marker.number!==1||marker.actual!==t.actual||marker.normal!==t.normal||!marker.source||!sameLocation(marker.source,t.node.location))):!!row.clockTuplets?.length||!!e.tupletBoundary)
    ||child(point.node,'duration')!==elapsed.node||children(point.node,'duration').length!==1||!plain(elapsed.node)||!/^\d+\/[1-9]\d*$/.test(elapsed.node.text)||elapsed.node.text.length>64
    ||compare(elapsed.value,q(0))<=0||!onTick(elapsed.value)||!equal(e.duration,mul(elapsed.value,scaling))||!equal(mul(elapsed.value,q(2)),pair.displayed)
    ||!e.writtenDuration||!equal(e.writtenDuration,pair.displayed)||!e.durationOverride||!sameLocation(e.durationOverride.source,elapsed.node.location)||!equal(e.durationOverride.encoded,elapsed.value)||!equal(e.durationOverride.displayed,pair.displayed)
    ||e.tuplet?.actual!==combined.d||e.tuplet.normal!==combined.n||e.timeModification&&(e.timeModification.actual!==combined.d||e.timeModification.normal!==combined.n)
    ||!ornament||!sameLocation(ornament.source,pair.source.location))return false;
   pairs.set(point.node,pair);
  }
  if(!equal(b.event.start,add(a.event.start,a.event.duration)))return false;
 }
 for(const [vi,voice]of bar.voices.entries()){
  const last=lastOrdinaryOwner(voice.children),first=voice.children.findIndex(n=>n.name==='Chord'||n.name==='Rest');
  const leadingCount=voice.children.reduce((count,n,i)=>count+Number(n.name==='location'&&i<first),0);
  const reciprocalSuffix:boolean[]=new Array(voice.children.length+1).fill(false),clockSuffix:boolean[]=new Array(voice.children.length+1).fill(false);reciprocalSuffix[voice.children.length]=clockSuffix[voice.children.length]=true;
  let lastRaw=-1;
  for(let i=voice.children.length-1;i>=0;i--){const n=voice.children[i];if(lastRaw<0&&(n.name==='Chord'||n.name==='Rest'))lastRaw=i;reciprocalSuffix[i]=n.name==='Spanner'&&reciprocalSuffix[i+1];clockSuffix[i]=(reciprocalClockSpanner(n)||prefixTempo(n)||neutral.has(n)&&['BarLine','Segment'].includes(n.name)||n.name==='location'&&cursors.has(n))&&clockSuffix[i+1];}
  let previousCursor:Rational|undefined;
  const pending:SourceTrillRow[]=[];
  for(const [index,node]of voice.children.entries()){
   if(node.name==='location'){
    if(index<first){
     const cursor=cursors.get(node),fraction=child(node,'fractions'),firstRow=byNode.get(voice.children[first]);
     // Leading source cursor only. The existing decoder owns its exact before,
     // delta and after; no fraction or clock is decoded again here.
     if(leadingCount!==1||!container(node)||node.children.length!==1||!fraction||!plain(fraction)||!/^[-]?\d{1,9}\/[1-9]\d{0,8}$/.test(fraction.text)
      ||!cursor||cursor.voice!==vi||cursor.fraction!==fraction||!equal(cursor.before,q(0))||compare(cursor.delta,q(0))<0||!equal(add(cursor.before,cursor.delta),cursor.after)
      ||!firstRow||firstRow.voice!==vi||firstRow.event.grace||firstRow.clockTuplets?.length||!equal(firstRow.event.start,cursor.after)
      ||voice.children.slice(0,index).some(n=>n.name==='Tuplet'||n.name==='endTuplet')||voice.children.slice(index+1,first).some(n=>n.name==='TimeSig'))return false;
    }else if(index<last||!container(node)||node.children.length!==1||!scalar(node,'fractions',children(node,'fractions').map(c=>c.text))
      ||!/^[-+]?\d+\/[1-9]\d*$/.test(child(node,'fractions')?.text??''))return false;
    else if(!reciprocalSuffix[index+1]||previousCursor){
     const cursor=cursors.get(node),fraction=child(node,'fractions'),row=byNode.get(voice.children[lastRaw]);
     // The existing decode owns each final cursor. Compose it once through a
     // native-neutral suffix; no later musical owner or second decoder exists.
     if(index<=lastRaw||!row||row.event.grace||!fraction||!plain(fraction)||!/^[-]?\d{1,9}\/[1-9]\d{0,8}$/.test(fraction.text)
      ||!cursor||cursor.voice!==vi||cursor.fraction!==fraction||!equal(cursor.before,previousCursor??add(row.event.start,row.event.duration))
      ||!onTick(cursor.before)||!onTick(cursor.delta)||!onTick(cursor.after)||compare(cursor.before,q(0))<0||compare(cursor.before,bar.model.duration)>0
      ||compare(cursor.after,q(0))<0||compare(cursor.after,bar.model.duration)>0||!equal(add(cursor.before,cursor.delta),cursor.after)||!clockSuffix[index+1])return false;
     previousCursor=cursor.after;
    }
   }
   if(node.name==='Beam'){if((!neutral.has(node)&&!neutralBeam(node))||!whitespace(node))return false;continue;}
   if(node.name==='Tuplet'){
    const t=tuplets.get(node);if(!t||t.voice!==vi||!t.end||ownerVoice.get(t.end)!==vi||!Number.isInteger(t.actual)||!Number.isInteger(t.normal)||t.actual<1||t.actual>128||t.normal<1||t.normal>128||!container(node)||!emptyMain(node)
     ||!unique(node,['normalNotes','actualNotes','baseNote','Number','linkedMain','visible','direction','numberType','bracketType','offset'])
     ||!scalar(node,'normalNotes',[String(t.normal)])||!scalar(node,'actualNotes',[String(t.actual)])||!scalar(node,'baseNote',ordinaryTypes)
     ||node.children.some(n=>!['normalNotes','actualNotes','baseNote','Number','linkedMain','visible','direction','numberType','bracketType','offset'].includes(n.name)))return false;continue;
   }
   if(node.name==='endTuplet'){if(!plain(node)||node.text!==''||ends.get(node)?.voice!==vi)return false;continue;}
   if(node.name!=='Chord'&&node.name!=='Rest')continue;
   const row=byNode.get(node),pair=pairs.get(node);
   if(!row||row.voice!==vi||!container(node)||!unique(node,['durationType','dots',...graceNames])
    ||!scalar(node,'durationType',node.name==='Rest'?[...ordinaryTypes,'measure']:ordinaryTypes)||!scalar(node,'dots',[undefined,'0','1','2','3'])
    ||node.children.some(n=>!['durationType','dots',...graceNames].includes(n.name)&&!clockNeutralOwnerFields.has(n.name)&&!neutral.has(n)&&!(pair&&(n===pair.source||n===pair.first.elapsed.node||n===pair.second!.elapsed.node))
      &&!(n.name==='duration'&&node.name==='Rest'&&row.event.fullMeasureRest&&row.encodedFullRest?.node===n&&plain(n)&&/^\d+\/[1-9]\d*$/.test(n.text)&&n.text.length<=64&&equal(row.encodedFullRest.duration,bar.model.duration)))
    ||!pair&&(row.event.durationOverride||row.event.timeModification)||row.event.staffTiming)return false;
   const membership=row.clockTuplets??[];if(membership.length>1||row.event.fullMeasureRest&&membership.length||membership.some(t=>tuplets.get(t.node)!==t||t.voice!==vi||!t.end))return false;
   const ratio=membership.reduce((r,t)=>mul(r,q(t.normal,t.actual)),pair?q(1,2):q(1));
   if(membership.length?(!row.event.tuplet||row.event.tuplet.actual!==ratio.d||row.event.tuplet.normal!==ratio.n):!pair&&(!!row.event.tuplet||!!row.event.tupletBoundary))return false;
   const markers=node.children.filter(n=>graceNames.includes(n.name));if(markers.length>1)return false;
   if(markers.length){
    const marker=markers[0],g=row.event.grace;
    if(!g||!plain(marker)||marker.text!==''||g.before===marker.name.endsWith('after')||!sameLocation(g.source,marker.location)
      ||g.index!==pending.length||!equal(row.event.duration,q(0))||!row.event.writtenDuration||compare(row.event.writtenDuration,q(0))<=0)return false;
    pending.push(row);
   }else{
    if(row.event.grace||compare(row.event.duration,q(0))<=0)return false;
    if(pending.some(r=>r.event.grace!.hostId!==row.event.id||!equal(r.event.start,r.event.grace!.before?row.event.start:add(row.event.start,row.event.duration))))return false;
    pending.length=0;
   }
  }
  if(pending.length)return false;
 }
 return true;
}
export const trillLocation=(branch:Element)=>container(branch)&&branch.children.length===1&&child(branch,'location')!==undefined&&container(child(branch,'location')!)
 &&unique(child(branch,'location')!,['measures','fractions'])
 &&child(branch,'location')!.children.every(c=>plain(c)&&(c.name==='measures'?/^[+-]?\d+$/.test(c.text)&&Number.isSafeInteger(Number(c.text))&&Math.abs(Number(c.text))<=100000
  :c.name==='fractions'&&/^[-+]?\d+\/[1-9]\d*$/.test(c.text)&&c.text.length<=64&&c.text.split('/').every(v=>Number.isSafeInteger(Number(v)))));
export const trillSegment=(e:Element)=>container(e)&&unique(e,['subtype','offset','off2'])&&scalar(e,'subtype',['0'])&&e.children.every(c=>c.name==='subtype'?plain(c):['offset','off2'].includes(c.name)&&!c.children.length&&whitespace(c)&&Object.keys(c.attrs).sort().join(',')==='x,y'&&Object.values(c.attrs).every(v=>/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+-]?\d+)?$/i.test(v)&&Number.isFinite(Number(v))));
export function trillSourceHeader(node:Element,next:Element):boolean {
 const body=child(node,'Trill');return Object.keys(node.attrs).length===1&&node.attrs.type==='Trill'&&whitespace(node)&&node.children.length===2&&!!body&&container(body)&&trillLocation(next)
  &&unique(body,['subtype','visible','lineWidth','linkedMain','Segment','Accidental','Ornament'])&&emptyMain(body)&&scalar(body,'subtype',[undefined,'0','trill','prallprall'])&&scalar(body,'visible',[undefined,'0','1'])
  &&body.children.every(c=>c.name==='Segment'?trillSegment(c):['Accidental','Ornament'].includes(c.name)?container(c):['subtype','visible','lineWidth','linkedMain'].includes(c.name)&&plain(c));
}

import type { BendFact, MusicalNote, MusicalRelation, RelationEndpoint, SourceColor } from '../../core/model.js';
import { add, compare, q } from '../../core/rational.js';
import { refuse } from '../../core/report.js';
import { modernBendPitchDifference, resolveModernBend, type NativeModernBend } from './modern-bend.js';
export interface NativeBendRecord {
    shape: NativeModernBend; start: MusicalNote; end: MusicalNote;
    endpoints: { start: RelationEndpoint; end: RelationEndpoint }; printObject?: boolean; sourceColor?: SourceColor;
}
const bar = (shape: NativeModernBend) => ['dive','pre-dive','dip','scoop'].includes(shape.type);
const chain = (shape: NativeModernBend) => !['slight-bend','dip','scoop'].includes(shape.type);
/** Native bendBack prefers a fretted bend, while diveBack selects only bar curves. */
export function createNativeBendPredecessorLookup(records: readonly NativeBendRecord[], ties: ReadonlyMap<MusicalNote,MusicalNote>, context?: {
    previousChord(record:NativeBendRecord,start:MusicalNote):readonly MusicalNote[]|undefined;
}): (record:NativeBendRecord)=>NativeBendRecord|undefined {
    const incoming=new Map<MusicalNote,NativeBendRecord[]>(), outgoing=new Map<MusicalNote,NativeBendRecord[]>(), back=new Map<MusicalNote,MusicalNote>();
    for(const [start,end] of ties)back.set(end,start);
    for(const record of records){const before=incoming.get(record.end)??[];before.push(record);incoming.set(record.end,before);const after=outgoing.get(record.start)??[];after.push(record);outgoing.set(record.start,after);}
    const tiedStart=(note:MusicalNote)=>{const seen=new Set<MusicalNote>();while(back.has(note)){if(seen.has(note))refuse('native-bend-cycle','A preceding bend cannot traverse a cyclic tie.',note.source);seen.add(note);note=back.get(note)!;}return note;};
    const sourceBack=(note:MusicalNote,dive:boolean)=>{const candidates=(incoming.get(note)??[]).filter(r=>dive?bar(r.shape)&&r.shape.type!=='dip':!['slight-bend','dip'].includes(r.shape.type));return dive?candidates[0]:candidates.find(r=>!bar(r.shape))??candidates[0];};
    const overlaps=(r:NativeBendRecord)=>outgoing.get(r.start)?.some(peer=>peer!==r&&bar(peer.shape)!==bar(r.shape)&&peer.end===r.end);
    const terminal=(r:NativeBendRecord)=>{const fact=r.start[bar(r.shape)?'whammy':'bend'];return fact?.terminalState?.semitones??fact?.points.at(-1)?.semitones;};
    return record=>{
        let note=tiedStart(record.start), opposite=sourceBack(note,!bar(record.shape));const seen=new Set<NativeBendRecord>();
        while(opposite&&bar(opposite.shape)!==bar(record.shape)&&chain(opposite.shape)&&!overlaps(opposite)){
            if(seen.has(opposite))refuse('native-bend-cycle','A preceding bend cannot cycle through opposite-role curves.',record.shape.source);seen.add(opposite);note=opposite.start;opposite=sourceBack(note,!bar(record.shape));
        }
        const previous=sourceBack(note,bar(record.shape));
        if(previous&&previous!==record&&bar(previous.shape)===bar(record.shape)&&chain(previous.shape))return previous;
        if(['pre-bend','pre-dive'].includes(record.shape.type))for(const component of context?.previousChord(record,note)??[]){
            const candidate=sourceBack(tiedStart(component),false), amount=terminal(record);
            if(candidate&&bar(candidate.shape)===bar(record.shape)&&chain(candidate.shape)&&amount&&terminal(candidate)&&compare(terminal(candidate)!,amount)===0&&(bar(record.shape)||candidate.start.string===record.start.string&&candidate.start.fret===record.start.fret))return candidate;
        }
        return undefined;
    };
}
/** Source note/tie ownership determines independent bend and bar chains. */
export function recoverNativeBendCurves(records: NativeBendRecord[], ties: ReadonlyMap<MusicalNote, MusicalNote>): void {
    const outgoing=new Map<MusicalNote,NativeBendRecord[]>();
    for(const record of records) {
        const peers=outgoing.get(record.start)??[];
        if(peers.some(peer=>bar(peer.shape)===bar(record.shape)))refuse('native-bend-owner','One note cannot replace competing source curves for the same technique.',record.shape.source);
        peers.push(record);outgoing.set(record.start,peers);
    }
    const overlap=(record:NativeBendRecord)=>outgoing.get(record.start)?.find(peer=>peer!==record && bar(peer.shape)!==bar(record.shape) && peer.end===record.end);
    const previous=createNativeBendPredecessorLookup(records,ties);
    const resolved=new Map<NativeBendRecord,BendFact>();
    const recover=(record:NativeBendRecord):BendFact=>{
        const existing=resolved.get(record);if(existing)return existing;
        const {shape}=record, peer=overlap(record), prior=chain(shape)?previous(record):undefined, priorFact=prior?resolved.get(prior):undefined;
        let fact:BendFact;
        if(shape.slack?.value || priorFact?.qualitative?.value==='slack') {
            if(!bar(shape))refuse('native-bend-slack','Slack is a bar technique, not an inferred fretted interval.',shape.source);
            fact={source:shape.source,sourceBendType:{source:shape.source,value:shape.type},points:[],withBar:{source:shape.source},qualitative:{source:shape.slack?.source??priorFact!.qualitative!.source,value:shape.slack?.value?'slack':'release-from-slack'}};
            if(!shape.slack?.value)fact.terminalState={source:shape.source,semitones:modernBendPitchDifference(prior!.start,record.end)};
        } else {
            const initial=priorFact && !['pre-bend','pre-dive'].includes(shape.type) ? {source:priorFact.source,semitones:priorFact.terminalState?.semitones??priorFact.points.at(-1)?.semitones??q(0),origin:'preceding-bend' as const}:undefined;
            let delta=shape.type==='dip'?shape.amount:undefined;
            if(peer) {
                const dive=bar(shape)?record:peer;
                const diveAmount=dive.shape.amount??refuse('native-bend-overlap','Overlapping native dive requires its encoded independent amount.',dive.shape.source);
                if(bar(shape))delta=diveAmount;
                else {
                    const combined=resolveModernBend(shape,record.start,record.end).points.at(-1)!.semitones;
                    delta=add(combined,q(-diveAmount.n,diveAmount.d));
                }
            }
            fact=resolveModernBend(shape,record.start,record.end,initial,delta);
        }
        fact.sourceEndpoints=record.endpoints;
        if(shape.labels)fact.labels=shape.labels;
        if(shape.holdMode)fact.sourceHoldMode=shape.holdMode;
        if(shape.vibrato)fact.sourceVibrato=shape.vibrato;
        if(record.printObject!==undefined)fact.printObject=record.printObject;
        if(record.sourceColor)fact.sourceColor=record.sourceColor;
        const property=bar(shape)?'whammy':'bend';
        if(record.start[property])refuse('native-bend-owner','Modern source technique conflicts with another note-owned curve.',shape.source);
        record.start[property]=fact;resolved.set(record,fact);return fact;
    };
    for(const record of records) {
        const pending:NativeBendRecord[]=[], seen=new Set<NativeBendRecord>();let current:NativeBendRecord|undefined=record;
        while(current&&!resolved.has(current)) {if(seen.has(current))refuse('native-bend-cycle','Bend continuation cannot cycle through source notes.',current.shape.source);seen.add(current);pending.push(current);current=chain(current.shape)?previous(current):undefined;}
        for(let i=pending.length-1;i>=0;i--)recover(pending[i]);
    }
}

export interface NativeBendHoldContext {
    endpoint(note:MusicalNote):RelationEndpoint;
    isTab(note:MusicalNote):boolean;
    isTop(note:MusicalNote):boolean|undefined;
    uncertainTop?(record:NativeBendRecord):void;
    nextChord(note:MusicalNote,record:NativeBendRecord):readonly MusicalNote[]|undefined;
}
/** Hold extent follows actual tied components and connected opposite-role curves. */
export function recoverNativeBendHolds(records:NativeBendRecord[],ties:ReadonlyMap<MusicalNote,MusicalNote>,context:NativeBendHoldContext):MusicalRelation[] {
    const relations:MusicalRelation[]=[], outgoing=new Map<MusicalNote,NativeBendRecord[]>();
    for(const r of records){const list=outgoing.get(r.start)??[];list.push(r);outgoing.set(r.start,list);}
    const tiedEnd=(note:MusicalNote)=>{const seen=new Set<MusicalNote>();while(ties.has(note)){if(seen.has(note))return refuse('native-bend-cycle','A hold cannot follow a cyclic tie.',note.source);seen.add(note);note=ties.get(note)!;}return note;};
    const fact=(r:NativeBendRecord)=>r.start[bar(r.shape)?'whammy':'bend']!;
    const terminal=(r:NativeBendRecord)=>fact(r).terminalState?.semitones??fact(r).points.at(-1)?.semitones;
    const overlaps=(r:NativeBendRecord)=>outgoing.get(r.start)?.some(other=>other!==r&&bar(other.shape)!==bar(r.shape)&&other.end===r.end);
    for(const record of records){
        const {shape}=record, value=fact(record), vibrato=shape.type==='dip'&&(shape.vibrato?.value??-1)!==-1;
        if(vibrato){const wide=shape.vibrato!.value===1||shape.vibrato!.value===3;(record.start.gestures??=[]).push({source:shape.vibrato!.source,kind:wide?'wide-vibrato':'vibrato',text:shape.vibrato!.value>=2?wide?'wide sawtooth bar vibrato':'sawtooth bar vibrato':wide?'wide bar vibrato':'bar vibrato',...(record.printObject!==undefined?{printObject:record.printObject}:{}),...(record.sourceColor?{sourceColor:record.sourceColor}:{})});}
        const fullRelease=!!value.initialState && value.initialState.semitones.n>0 && terminal(record)?.n===0;
        if(!(vibrato || context.isTab(record.start)&&!fullRelease&&!['scoop','dip'].includes(shape.type)))continue;
        if(bar(shape)){
            const top=context.isTop(record.start);
            if(top===undefined){value.holdProjection={source:shape.source,reason:'system-dependent-top-note'};context.uncertainTop?.(record);continue;}
            if(!top)continue;
        }
        const start=record.end;let end=tiedEnd(start);
        // A following pre-bend at the same displacement can continue the hold.
        const next=context.nextChord(end,record);
        const following=next?.map(note=>outgoing.get(tiedEnd(note))??[]).flat().find(other=>bar(other.shape)===bar(shape)&&['pre-bend','pre-dive'].includes(other.shape.type)&&terminal(record)&&terminal(other)&&compare(terminal(record)!,terminal(other)!)===0&&(bar(shape)||other.start.string===record.start.string&&other.start.fret===record.start.fret));
        if(following)end=following.start;
        const seen=new Set<MusicalNote>();
        while(!seen.has(end)){seen.add(end);const opposite=outgoing.get(end)?.find(other=>bar(other.shape)!==bar(shape)&&!overlaps(other)&&other.end!==end);if(!opposite)break;end=opposite.end;}
        if(!vibrato && ((shape.holdMode?.value??0)===2 || (shape.holdMode?.value??0)===0&&end===start))continue;
        const visible=shape.hold?.printObject??record.printObject, color=shape.hold?.sourceColor??record.sourceColor, source=shape.hold?.source??shape.holdMode?.source??shape.source;
        if(end===start){(start.gestures??=[]).push({source,kind:bar(shape)?'whammy':'let-ring',text:bar(shape)?'hold bar position':'hold bend',...(visible!==undefined?{printObject:visible}:{}),...(color?{sourceColor:color}:{})});continue;}
        const lineType=vibrato?'wavy':shape.hold?.lineType??'solid';
        relations.push({source,id:`native-bend-hold-${relations.length+1}`,kind:'text-line',line:lineType==='dashed'?'dashes':'bracket',lineType,beginText:bar(shape)?'hold bar position':'hold bend',start:context.endpoint(start),end:context.endpoint(end),...(visible!==undefined?{printObject:visible}:{}),...(color?{sourceColor:color}:{})});
    }
    return relations;
}

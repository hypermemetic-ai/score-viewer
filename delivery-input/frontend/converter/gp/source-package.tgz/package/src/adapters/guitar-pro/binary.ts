import { Gp3To5Importer } from '../../../third_party/alphatab/src/importer/Gp3To5Importer.js';
import { ByteBuffer } from '../../../third_party/alphatab/src/io/ByteBuffer.js';
import { Bytes } from './bytes.js';
import { ThrowingReadable } from '../../../third_party/alphatab/src/io/IReadable.js';
import { Settings } from '../../../third_party/alphatab/src/ReaderSettings.js';
import { Logger } from '../../../third_party/alphatab/src/Logger.js';
import { LogLevel } from '../../../third_party/alphatab/src/LogLevel.js';
import type { Score } from '../../../third_party/alphatab/src/model/Score.js';
import type { Track } from '../../../third_party/alphatab/src/model/Track.js';
import type { Bar } from '../../../third_party/alphatab/src/model/Bar.js';
import type { Voice } from '../../../third_party/alphatab/src/model/Voice.js';
import type { Beat } from '../../../third_party/alphatab/src/model/Beat.js';
import type { Note } from '../../../third_party/alphatab/src/model/Note.js';
import { add, equal, mul, q } from '../../core/rational.js';
import { freeze, refuse, Refusal, type Finding, type Location } from '../../core/report.js';
import type { Event, Measure, NeutralScore, NoteFact, Part, Pitch, Tempo, MusicalRelation, MusicalScore, MusicalPart, MusicalEvent, MusicalNote } from '../../core/model.js';
import { binaryPercussion, reconcileBinaryDrums, type BinaryDrumExpectation } from './binary-percussion.js';
import { midiFamily } from './admission.js';
import {emptyAnnotationAnchor,binaryEmptyAnnotations} from './binary-empty-annotations.js';
import {binaryEmptySlot} from './binary-empty-slots.js';
import {binaryCaption,binaryMix} from './binary-mix.js';
import {binaryTies} from './binary-ties.js';
import {binaryNoteDurations,binaryNoteValue} from './binary-note-durations.js';
import {binaryBeams,binaryTuplets,binaryOttavas} from './binary-engraving.js';
import { binaryMasterStructure, binaryScoreTexts, binaryLyrics, binaryChord, binaryMeasureExtent } from './binary-structure.js';
import {binaryHopo} from './binary-hopo.js';
import { binaryHarmonic, binaryTrill, binaryBeatTechniques, binaryGraces, binaryUnfrettedDeadGraces } from './binary-performer.js';
import { binaryTechniques, connectSlides, connectSustainMarks, numberHopo } from './techniques.js';
import type { OccurrenceCapture } from './recover.js';
import { limits } from './limits.js';
import { jsonBytes } from './work-budgets.js';

export interface BinaryRecord { kind: string; source: Location; dataBase64: string; facts: Record<string, number> }
export interface BinaryCapture { header: string; version: number; sourceEncoding: string; records: BinaryRecord[] }
interface Frame { source: Location; facts: Record<string, number> }
const headers: Record<string, number> = {
    'FICHIER GUITAR PRO v3.00': 300,
    'FICHIER GUITAR PRO v4.00': 400,
    'FICHIER GUITAR PRO v4.06': 406,
    'FICHIER GUITAR PRO L4.06': 406,
    'FICHIER GUITAR PRO v5.00': 500,
    'FICHIER GUITAR PRO v5.10': 510
};
const rhythmTypes: Record<number, string> = { 1: 'whole', 2: 'half', 4: 'quarter', 8: 'eighth', 16: '16th', 32: '32nd', 64: '64th' };
const dynamics = ['', 'PPP', 'PP', 'P', 'MP', 'MF', 'F', 'FF', 'FFF'];
function inferredPitch(midi: number, fifths=0, swap=false): Pitch {
    if (!Number.isInteger(midi)||midi<0||midi>255) refuse('pitch-range','Binary source pitch exceeds the bounded numeric domain.');
    const natural:Record<string,number>={C:0,D:2,E:4,F:5,G:7,A:9,B:11},signature:Record<string,number>={};
    for(const step of (fifths<0?'BEADGCF':'FCGDAEB').slice(0,Math.abs(fifths)))signature[step]=Math.sign(fifths);
    const pc=midi%12,diatonic=Object.entries(natural).find(([step,value])=>(value+(signature[step]??0)+12)%12===pc);
    let step:string,alter:number;
    if(diatonic){step=diatonic[0];alter=signature[step]??0;}
    else [step,alter]=(fifths<0?[['C',0],['D',-1],['D',0],['E',-1],['E',0],['F',0],['G',-1],['G',0],['A',-1],['A',0],['B',-1],['B',0]]:[['C',0],['C',1],['D',0],['D',1],['E',0],['F',0],['F',1],['G',0],['G',1],['A',0],['A',1],['B',0]])[pc] as [string,number];
    if(swap&&alter!==0) {
        const opposite=Object.entries(natural).find(([,value])=>(value-alter+12)%12===pc);
        if(opposite){step=opposite[0];alter=-alter;}
        else {const unaltered=Object.entries(natural).find(([,value])=>value===pc);if(unaltered){step=unaltered[0];alter=0;}}
    }
    return { step, alter, octave:(midi-natural[step]-alter)/12-1, midi, origin: 'inferred' };
}

/** Throw a located adapter refusal before the borrowed reader can short-read or skip. */
class BoundedInput extends ThrowingReadable {
    constructor(bytes: Bytes, private readonly at: () => Location) { super(ByteBuffer.fromBuffer(bytes)); }
    private require(count: number): void {
        if (!Number.isSafeInteger(count) || count < 0 || count > this.length - this.position) refuse('binary-truncated', 'Read/skip exceeds immutable binary input.', { ...this.at(), byteOffset: this.position });
    }
    override get position(): number { return super.position; }
    override set position(value: number) {
        if (!Number.isSafeInteger(value) || value < 0 || value > this.length) refuse('binary-truncated', 'Binary reader attempted an out-of-range cursor.', { ...this.at(), byteOffset: super.position });
        super.position = value;
    }
    override readByte(): number { this.require(1); return super.readByte(); }
    override read(buffer: Uint8Array, offset: number, count: number): number { this.require(count); return super.read(buffer, offset, count); }
    override skip(count: number): void { this.require(count); super.skip(count); }
}

/** Original adapter: raw spans/flags are captured and gated before borrowed normalization. */
class CapturingReader extends Gp3To5Importer {
    readonly records: BinaryRecord[] = [];
    readonly tracks = new Map<number, Frame>();
    readonly masters: Frame[] = [];
    readonly beats = new Map<Beat, Frame>();
    readonly notes = new Map<Note, Frame>();
    readonly mixes = new Map<Beat, Frame>();
    readonly effects = new Map<Beat, Frame>();
    readonly chords = new Map<Beat, Frame>();
    lyricsFrame?: Frame;
    readonly globals: Record<string, number> = {};
    readonly fieldLocations = new Map<string, Location>();
    private frame: Frame = { source: { member: 'input', path: '/header' }, facts: this.globals };
    private trackOrdinal = 0;
    private masterOrdinal = 0;
    private totalBeats = 0;
    private totalNotes = 0;
    private readonly beatOrdinals = new WeakMap<Voice,number>();
    private captureBytes = 2;
    private initialTempoNameStart?:number;
    get position(): number { return this.data.position; }
    get location(): Location { return this.frame.source; }
    constructor(readonly bytes: Bytes, readonly version: number, readonly selected: Set<string> | undefined, readonly discovery = false) {
        super();
        this.onSourceField = (name, value, byteOffset, byteLength) => {
            const source = { ...this.frame.source, path: `${this.frame.source.path}/${name}`, byteOffset, byteLength };
            this.frame.facts[name] = value;
            this.fieldLocations.set(source.path!, source);
            if (!discovery) this.record({ kind: 'field', source, dataBase64: bytes.subarray(byteOffset, byteOffset + byteLength).base64(), facts: { value } });
            this.guard(name, value, source);
            if(name==='initial-tempo'&&this.initialTempoNameStart!==undefined)this.onSourceField?.('initial-tempo-name',byteOffset-this.initialTempoNameStart,this.initialTempoNameStart,byteOffset-this.initialTempoNameStart);
        };
    }
    private requested(source = this.frame.source): boolean { return !this.discovery && (!this.selected || source.trackId === undefined || this.selected.has(source.trackId)); }
    private record(record: BinaryRecord): void {
        if (this.records.length >= limits.binaryRecords) refuse('capture-budget', 'Binary record count exceeds the source-capture budget.', record.source);
        this.captureBytes += jsonBytes(record, limits.captureBytes - this.captureBytes, 'capture-budget', record.source) + (this.records.length ? 1 : 0);
        this.records.push(record);
    }
    private guard(name: string, value: number, source: Location): void {
        const reject = (message: string, code = 'binary-feature'): never => refuse(code, message, source);
        if (!Number.isSafeInteger(value)) reject('Noninteger binary field.', 'binary-field');
        if (name === 'bar-count' && (value < 1 || value > limits.measures)) reject('Binary measure count exceeds the profile.', 'measure-budget');
        if (name === 'track-count' && (value < 1 || value > limits.tracks)) reject('Binary track count exceeds the profile.', 'track-scope');
        if (name === 'beat-count') {
            if (value < 0 || value > limits.occurrences || (this.totalBeats += value) > limits.occurrences) reject('Binary expanded beat count exceeds the profile.', 'occurrence-budget');
        }
        if (name === 'string-count' && (value < 1 || value > 7)) reject('Binary string count is outside its encoded capacity.', 'tuning');
        if (name === 'channel' && (value < 1 || value > 64)) reject('Unresolved MIDI channel.', 'instrument');
        if (this.discovery) return;
        if (name === 'global-triplet-feel' && ![0,1].includes(value) || name === 'triplet-feel' && ![0,1,2].includes(value)) reject('Unknown encoded rhythmic feel.', 'rhythmic-feel');
        if (name === 'initial-tempo' && (value < 1 || value > 1000)) reject('Initial quarter tempo outside the profile.', 'tempo-rate');
        if (name === 'initial-key' && (value < -7 || value > 7)) reject('Initial key outside the profile.', 'key');
        if (name === 'key-fifths' && (value < -7 || value > 7) || name === 'key-mode' && ![0, 1].includes(value)) reject('Encoded key outside profile.', 'key');
        if (name === 'hide-tempo' && ![0, 1].includes(value)) reject('Tempo visibility requires an encoded boolean.', 'boolean');
        if (name === 'track-separator' && value) reject('Unreviewed track separator.', 'binary-field');
        if (name === 'bar-line-break' && ![0, 1, 2].includes(value)) reject('Unknown binary layout break.', 'binary-field');
        if (name === 'string-count' && (value < 1 || value > 7)) reject('Binary string count is outside its encoded capacity.', 'tuning');
        if (name === 'channel' && (value < 1 || value > 64)) reject('Unresolved MIDI channel.', 'instrument');
        if (name === 'mix-tempo' && value !== -1 && (value < 1 || value > 1000)) reject('Mixer tempo outside profile.', 'tempo-rate');
        if (name === 'mix-duration' && value < 0) reject('Negative mixer transition duration.', 'automation');
        if (name === 'mix-hide-tempo' && ![0, 1].includes(value)) reject('Mixer visibility requires a boolean.', 'boolean');
        if (!this.requested(source)) return;
        if (name === 'track-flags' && value & (this.version>=500?0:0x40)) reject('Short-string banjo or unknown track flags need their explicit physical mapping.');

        if (name === 'capo' && value < 0) reject('Full capo fret must be nonnegative.', 'capo');
        if (name === 'automatic-midi' && value & ~7) reject('Unknown automatic-MIDI flag; the documented playback let-ring/brush bits are already admitted.');
        if (name === 'automatic-accent' && value > 5 || name === 'humanize' && value > 100) reject('Invalid playback interpretation parameter.', 'playback-profile');
        if (name === 'beat-flags' && value & 0x80) reject('Unknown beat flag.');
        if (name === 'beat-status' && ![0,2].includes(value)) reject('Unknown encoded beat status.');
        if (name === 'duration-exponent' && (value < -2 || value > 4)) reject('Written rhythm outside whole–64th notes.', 'rhythm');
        if (name === 'tuplet' && ![3, 5, 6, 7, 9, 10, 11, 12, 13].includes(value)) reject('Unexercised binary tuplet mapping.', 'rhythm');
        if (name === 'beat-flags2' && value & ~0x3f7f) reject('Unknown secondary beat flags require a mapping.');
        if (name === 'note-type' && ![1, 2, 3].includes(value)) reject('Unknown source note type.');
        if (name === 'note-fret' && this.frame.facts['note-type'] !== 2 && !(this.frame.facts['note-type']===3&&value===-1) && (value < 0 || value > 127)) reject('Source fret must be a nonnegative signed-byte value.', 'physical-pitch');
        if (name === 'note-dynamic' && (value < 1 || value > 8)) reject('Unknown encoded dynamic.', 'dynamic');
        if (name === 'note-flags2' && value&~2) reject('Unknown source note spelling flag.');
        if (name === 'note-effect-flags' && value & ~31) reject('Unknown note effect.', 'technique');
        if (name === 'note-effect-flags2' && value & ~0x7f) reject('Unknown note effect.', 'technique');
        if (name==='mix-instrument' && (value < -1 || value > 127)) reject('Invalid mixer instrument program.', 'instrument');
        if (name==='mix-wah' && (value < -2 || value > 100)) reject('Unknown source Wah position.', 'technique');
        if (name === 'mix-flags' && value & (this.version>=500?0:0xc0)) reject('Unreviewed mixer wah/flag convention.', 'automation');
    }
    private scope<T>(kind: string, coordinates: Partial<Location>, body: () => T): { result: T; frame: Frame } {
        const previous = this.frame, start = this.data.position;
        const frame: Frame = { source: { ...previous.source, ...coordinates, byteOffset: start }, facts: {} };
        this.frame = frame;
        try {
            const result = body();
            frame.source.byteLength = this.data.position - start;
            if (!this.discovery) this.record({ kind, source: frame.source, facts: frame.facts,
                dataBase64: this.bytes.subarray(start, this.data.position).base64() });
            return { result, frame };
        } finally { this.frame = previous; }
    }
    override readScoreInformation(): void { this.scope('metadata', { path: '/score-information' }, () => super.readScoreInformation()); }
    override readLyrics(): void { this.lyricsFrame=this.scope('metadata', { path: '/lyrics' }, () => super.readLyrics()).frame; }
    override readPageSetup(): void { this.scope('metadata', { path: '/page-setup' }, () => super.readPageSetup());this.initialTempoNameStart=this.position; }
    override readMasterBar(): void {
        const measure = ++this.masterOrdinal;
        const captured = this.scope('master-bar', { path: `/master-bars/${measure}`, measure }, () => super.readMasterBar());
        if (!this.discovery) this.masters.push(captured.frame);
    }
    override readTrack(): void {
        const id = this.trackOrdinal++;
        this.tracks.set(id, this.scope('track', { path: `/tracks/${id}`, trackId: String(id) }, () => super.readTrack()).frame);
    }
    override readBar(track: Track): void {
        this.scope('bar', { path: `/tracks/${track.index}/bars/${track.staves[0].bars.length + 1}`, trackId: String(track.index),
            measure: track.staves[0].bars.length + 1 }, () => super.readBar(track));
    }
    override readVoice(track: Track, bar: Bar): void {
        this.scope('voice', { path: `${this.frame.source.path}/voices/${bar.voices.length + 1}`, voice: bar.voices.length + 1 }, () => super.readVoice(track, bar));
    }
    override readBeat(track: Track, bar: Bar, voice: Voice): void {
        const ordinal=(this.beatOrdinals.get(voice)??0)+1;this.beatOrdinals.set(voice,ordinal);
        const captured = this.scope('beat', { path: `${this.frame.source.path}/beats/${ordinal}`, beat: ordinal }, () => super.readBeat(track, bar, voice));
        if (!this.discovery) this.beats.set(voice.beats.at(-1)!, captured.frame);
        const mask = captured.frame.facts['string-mask'], count = bar.staff.stringTuning.tunings.length;
        if (mask & ~(((1 << count) - 1) << (7 - count))) refuse('physical-pitch', 'String mask addresses absent strings.', captured.frame.source);
    }
    override readNote(track: Track, bar: Bar, voice: Voice, beat: Beat, stringIndex: number): Note {
        if (++this.totalNotes > limits.occurrences) refuse('occurrence-budget', 'Expanded binary note count exceeds the profile.', this.frame.source);
        const captured = this.scope('note', { path: `${this.frame.source.path}/strings/${stringIndex + 1}`, id: `${this.frame.source.path}/strings/${stringIndex + 1}` },
            () => {
                const result=super.readNote(track,bar,voice,beat,stringIndex);
                if(this.version<500&&this.frame.facts['note-flags']&1) {
                    const offset=this.fieldLocations.get(this.frame.source.path+'/note-flags')!.byteOffset!+1+((this.frame.facts['note-flags']&0x20)?1:0);
                    for(const [name,index] of [['independent-duration-exponent',0],['independent-duration-tuplet',1]] as const){const byte=this.bytes[offset+index];this.onSourceField?.(name,byte>127?byte-256:byte,offset+index,1);}
                }
                return result;
            });
        captured.frame.facts['source-string'] = stringIndex + 1;
        if (!this.discovery) this.notes.set(captured.result, captured.frame);
        return captured.result;
    }
    override readBeatEffects(beat: Beat) {
        const captured = this.scope('beat-effects', { path: `${this.frame.source.path}/effects` }, () => super.readBeatEffects(beat));
        if (!this.discovery) this.effects.set(beat, captured.frame);
        return captured.result;
    }
    override readChord(beat: Beat): void { const captured=this.scope('chord-diagram', { path: `${this.frame.source.path}/chord-diagram` }, () => super.readChord(beat)); if(!this.discovery)this.chords.set(beat,captured.frame); }
    override readMixTableChange(beat: Beat): void {
        const captured = this.scope('mix-table', { path: `${this.frame.source.path}/mix-table` }, () => {super.readMixTableChange(beat);if(this.version>=500){const start=this.fieldLocations.get(this.frame.source.path+'/mix-tremolo')!.byteOffset!+1,end=this.fieldLocations.get(this.frame.source.path+'/mix-tempo')!.byteOffset!;this.onSourceField?.('mix-tempo-name',end-start,start,end-start);}});
        if (!this.discovery) this.mixes.set(beat, captured.frame);
    }
}

function recoverBeforeFinish(score: Score, reader: CapturingReader, findings: Finding[]): { score: MusicalScore; expected: { note: Note; fact: NoteFact; event: Event }[]; drums:BinaryDrumExpectation[]; dead:{note:Note;fact:MusicalNote;event:Event}[] } {
    const expected: { note: Note; fact: NoteFact; event: Event }[] = [];
    const dead:{note:Note;fact:MusicalNote;event:Event}[]=[],deadNotes=new Map<string,MusicalNote[]>();
    const slideOrigins = new Map<MusicalNote, number>(), relations: MusicalRelation[] = [];
    let repeatOpen = 0;
    const emptyEvents=new Map<Beat,MusicalEvent>();
    const sourceEvents = new Map<Beat,MusicalEvent>(), drums:BinaryDrumExpectation[]=[];
    const deadGraces=new Map<string,MusicalEvent[]>();
    for (let mi = 0; mi < score.masterBars.length; mi++) {
        const master = score.masterBars[mi], source = reader.masters[mi].source;
        if (master.isRepeatStart) repeatOpen++;
        if (master.repeatCount) { if (master.repeatCount < 1 || master.repeatCount > 256) refuse('repeat', 'Repeat count exceeds the exact encoded byte convention.', source); repeatOpen=Math.max(0,repeatOpen-1); }
        if (master.isFreeTime) refuse('meter', 'Binary free-time requires an encoded source marker.', source);
    }
    if (repeatOpen) refuse('repeat', 'Unclosed repeat.', reader.masters.at(-1)!.source);
    const parts: MusicalPart[] = [];
    const tempos: Tempo[] = [];
    for (const track of score.tracks) {
        const id = String(track.index), frame = reader.tracks.get(track.index)!;
        if (reader.selected && !reader.selected.has(id)) {
            findings.push({ disposition: 'excluded-by-scope', code: 'track-excluded', message: 'Encoded track is excluded from requested output; original bytes and spans remain captured.', location: frame.source, fact: { trackId: id, name: track.name } });
            continue;
        }
        if(frame.facts['track-flags']&2)findings.push({disposition:'excluded-by-scope',code:'binary-twelve-string-simulation',message:'The source twelve-string sound simulation flag remains captured; its encoded tuning vector is preserved without inventing doubled physical courses.',location:reader.fieldLocations.get(frame.source.path+'/track-flags')??frame.source});
        if(reader.version>=500&&frame.facts['track-flags']&64)findings.push({disposition:'excluded-by-scope',code:'binary-rse-playback',message:'Encoded RSE synthesis selection remains captured; source instrument and performer notation are preserved independently.',location:reader.fieldLocations.get(frame.source.path+'/track-flags')??frame.source});
        if(frame.facts['track-flags']&1) {
            const recovered=binaryPercussion(track,score,frame,{version:reader.version,beats:reader.beats,notes:reader.notes,masters:reader.masters,fieldLocations:reader.fieldLocations,sourceEvents,emptyEvents,effects:reader.effects,chords:reader.chords},findings);parts.push(recovered.part);drums.push(...recovered.expected);continue;
        }
        const staff = track.staves[0], highToLow = staff.stringTuning.tunings;
        const program = track.playbackInfo.program;
        if (track.staves.length !== 1 || staff.isPercussion || program < 0 || program > 127) refuse('instrument', 'Binary pitched admission requires one source staff and an explicit MIDI program.', frame.source);
        const banjo=!!(frame.facts['track-flags']&4);if(banjo&&highToLow.length!==5)refuse('banjo-strings','The source short-fifth-string flag requires five encoded strings.',frame.source);
        const family=banjo?'banjo':midiFamily(program), fretted=banjo||family==='guitar'||family==='bass',writtenShift=fretted?12:0;
        if (highToLow.length < 1 || highToLow.length > 7 || highToLow.some(pitch => pitch < 0 || pitch > 127))
            refuse('tuning', 'Expected complete binary tuning in its encoded string order.', frame.source);
        const tuning = highToLow.slice().reverse();
        const capo = { source: reader.fieldLocations.get(frame.source.path + '/capo')!, fret: frame.facts.capo };
        if(fretted)findings.push({ disposition: 'preserved', code: 'full-capo', message: 'Full capo is retained separately from non-capo open-string tuning and capo-relative source fret. Its semitone shift is applied once to physical pitch, independently of written octave transposition.', location: capo.source, fact: { fret: capo.fret } });
        let key = { fifths: reader.globals['initial-key'], mode: 'major' };
        let measureStart = q(0);
        const previousEvents = new Map<number, { event: Event; end: ReturnType<typeof q> }>();
        const previousStrings=new Map<string,{note:MusicalNote;borrowed:Note;end:ReturnType<typeof q>}>(),sourceNoteDurations=new Map<NoteFact,ReturnType<typeof q>>();
        const measures: Measure[] = staff.bars.map((bar, mi) => {
            const master = score.masterBars[mi], source = { ...reader.masters[mi].source, trackId: id };
            const masterFields = reader.masters[mi].facts;
            if (masterFields['key-fifths'] !== undefined) key = { fifths: masterFields['key-fifths'], mode: masterFields['key-mode'] ? 'minor' : 'major' };
            const beats = master.timeSignatureNumerator, unit = master.timeSignatureDenominator;
            if (beats < 1 || beats > 255 || unit < 1 || unit > 128 || unit & (unit - 1)) refuse('meter', 'Binary meter outside profile.', source);
            const span = q(beats * 4, unit);
            const voices = bar.voices.map((voice, vi) => {
                let position = q(0);
                const encoded=voice.beats.filter(beat=>reader.beats.has(beat));
                if(encoded.length&&encoded.every(beat=>reader.beats.get(beat)!.facts['beat-status']===0)) {
                    if(encoded.some(beat=>beat.notes.length))refuse('empty-voice','Empty source voice contains note attacks.',source);
                    for(const beat of encoded){const event=emptyAnnotationAnchor(reader.beats.get(beat)!.source,beat.text);emptyEvents.set(beat,event);sourceEvents.set(beat,event);}
                    findings.push({disposition:'preserved',code:'binary-empty-voice',message:'Encoded empty beat placeholders preserve a silent voice slot without creating rhythmic attacks.',location:reader.beats.get(encoded[0])!.source});return [];
                }
                return voice.beats.filter(beat => reader.beats.has(beat)).flatMap(beat => {
                    const raw = reader.beats.get(beat)!;
                    if (!raw || beat.isEmpty&&beat.notes.length) refuse('empty-voice', 'Empty source beat contradicts its encoded notes.', source);
                    const dots = raw.facts['beat-flags'] & 1 ? 1 : 0;
                    const denominator = 2 ** (raw.facts['duration-exponent'] + 2);
                    const actual = raw.facts.tuplet;
                    const normal = actual === 3 ? 2 : actual && actual <= 7 ? 4 : 8;
                    const tuplet = actual ? { actual, normal } : undefined;
                    const duration = mul(mul(q(4, denominator), q(dots ? 3 : 1, dots ? 2 : 1)), q(tuplet?.normal ?? 1, tuplet?.actual ?? 1));
                    const deadSlots=beat.notes.filter(note=>{const facts=reader.notes.get(note)!.facts;return facts['note-type']===3&&facts['note-fret']===-1;});
                    const emptySlots=beat.notes.filter(note=>!(reader.notes.get(note)!.facts['note-flags']&0x20));
                    const sourceNotes = beat.notes.filter(note=>!emptySlots.includes(note)&&!deadSlots.includes(note)).map(note => {
                        const rawNote = reader.notes.get(note)!;
                        const string = rawNote.facts['source-string'], placeholder = rawNote.facts['note-fret'];
                        let fret = placeholder;
                        if (rawNote.facts['note-type'] === 2) {
                            const prior=previousStrings.get(`${vi}:${string}`),origin=prior?.note;
                            if (!origin || origin.kind !== 'pitched' || origin.fret === undefined) refuse('tie-conflict', 'Binary tie destination needs a prior same-string pitched source origin.', rawNote.source);
                            fret = origin!.fret!;
                            // The source rule searches prior same-string attacks, independently of a reader's search-window heuristic.
                            note.tieOrigin=prior!.borrowed;
                            findings.push({ disposition: 'preserved', code: 'binary-tie-fret', message: 'Binary note-type2 inherits the preceding same-string effective fret; its serialized signed-byte fret is an unused placeholder, retained unchanged. This derives source encoding semantics, not a musical repair.', location: rawNote.source, fact: { rawPlaceholder: placeholder, effectiveFret: fret, origin: origin!.source } });
                        }
                        const midi = highToLow[string - 1] + capo.fret + fret;

                        const reference = inferredPitch(midi), written = inferredPitch(midi + writtenShift,key.fifths);
                        const dead = rawNote.facts['note-type'] === 3;
                        const fact: NoteFact = { source: rawNote.source, id: rawNote.source.id!, string, fret, kind: dead ? 'dead' : 'pitched',
                            sounding: dead ? null : reference, written, ...(dead ? { referenceSounding: reference } : {}), tieStart: false,
                            tieStop: rawNote.facts['note-type'] === 2,
                            ...(rawNote.facts['note-effect-flags'] & 2 ? { sourceHopoOrigin: true } : {}) };
                        const slide = binaryTechniques(rawNote.facts, rawNote.source, fact, reader.version, name => reader.fieldLocations.get(rawNote.source.path + '/' + name) ?? rawNote.source);
                        if (slide) slideOrigins.set(fact, slide);
                        const locate = (name: string) => reader.fieldLocations.get(rawNote.source.path + '/' + name) ?? rawNote.source;
                        binaryHarmonic(rawNote.facts, fact, reader.version, highToLow[string - 1] + capo.fret, inferredPitch, locate, findings, reader.effects.get(beat)?.facts['beat-effect-flags'],writtenShift);
                        const swap=!!(rawNote.facts['note-flags2']&2);fact.written=inferredPitch(fact.written.midi,key.fifths,swap);
                        if(swap){if(fact.written.alter){fact.accidental=fact.written.alter<0?'flat':'sharp';fact.accidentalRole='user';}findings.push({disposition:'inferred',code:'binary-accidental-swap',message:'The encoded sharp/flat swap is applied to the generated key-aware spelling without changing pitch, physical fret, or tuning. The literal flag remains in source capture.',location:locate('note-flags2'),fact:{keyFifths:key.fifths,written:fact.written}});}
                        binaryTrill(rawNote.facts, fact, highToLow[string - 1] + capo.fret, inferredPitch, locate,writtenShift);
                        if(fact.written.octave<0||fact.written.octave>9) {findings.push({disposition:'preserved',code:'source-pitch-format-limit-facts',message:'Exact source pitch facts exceed the MusicXML4 octave0–9 domain; they are not clipped or folded.',location:rawNote.source,fact:{tuning:highToLow[string-1],capo:capo.fret,fret,soundingMidi:fact.sounding?.midi,written:fact.written}});refuse('source-pitch-format-limit',`Source written ${fact.written.step}${fact.written.alter?' altered '+fact.written.alter:''}${fact.written.octave} (MIDI ${fact.written.midi}) exceeds MusicXML4 octave0–9.`,rawNote.source);}
                        return { note, fact, dynamic: rawNote.facts['note-dynamic'] };
                    });
                    const levels = [...new Set(beat.notes.filter(note=>!emptySlots.includes(note)).map(note=>reader.notes.get(note)!.facts['note-dynamic']).filter(value => value !== undefined))];
                    if(levels.length>1)for(const {fact,dynamic} of sourceNotes)if(dynamic!==undefined)fact.dynamic={source:reader.fieldLocations.get(fact.source.path+'/note-dynamic')??fact.source,value:dynamics[dynamic].toLowerCase()};
                    const event: Event = { source: raw.source, id: raw.source.path!, start: position, duration, type: rhythmTypes[denominator], dots,
                        ...(tuplet ? { tuplet } : {}), ...(raw.facts['beat-status']===0?{printObject:false}:{}), notes: sourceNotes.map(note => note.fact),
                        fullMeasureRest: !sourceNotes.length && voice.beats.length === 1 && equal(duration, span),
                        ...(levels.length===1 ? { dynamic: dynamics[levels[0]] } : {}), ...(beat.text ? { text: beat.text } : {}) };
                    sourceEvents.set(beat,event);
                    for(const note of deadSlots){const slot=reader.notes.get(note)!,string=slot.facts['source-string'],fact:MusicalNote={source:slot.source,id:slot.source.id!,string,kind:'dead',written:inferredPitch(highToLow[string-1]+capo.fret+writtenShift,key.fifths),sounding:null,sourceDead:{source:reader.fieldLocations.get(slot.source.path+'/note-type')!,value:true},tieStart:false,tieStop:false};
                        const locate=(name:string)=>reader.fieldLocations.get(slot.source.path+'/'+name)??slot.source;
                        const slide=binaryTechniques(slot.facts,slot.source,fact,reader.version,locate);if(slide)slideOrigins.set(fact,slide);
                        if(fact.bend)delete fact.bend;
                        if(levels.length>1&&slot.facts['note-dynamic']!==undefined)fact.dynamic={source:locate('note-dynamic'),value:dynamics[slot.facts['note-dynamic']].toLowerCase()};
                        previousStrings.set(`${vi}:${string}`,{note:fact,borrowed:note,end:add(measureStart,add(position,duration))});
                        const pending=deadNotes.get(event.id)??[];pending.push(fact);deadNotes.set(event.id,pending);dead.push({note,fact,event});event.fullMeasureRest=false;
                        findings.push({disposition:'inferred',code:'binary-unfretted-dead-placement',message:'Explicit dead type with fret−1 is a dead attack without physical fret or sounding pitch. Source string is retained; the declared open-string register supplies only derived staff placement.',location:slot.source});
                    }
                    for (const note of sourceNotes) {
                        const rawNote = reader.notes.get(note.note)!, marks = rawNote.facts['tremolo-marks'];
                        if (marks !== undefined) {
                            if (marks < 1 || marks > 3) refuse('tremolo', 'Unknown binary tremolo picking value.', rawNote.source);
                            if (event.ornaments?.some(o => o.kind === 'tremolo' && o.strokes !== marks)) refuse('tremolo', 'Conflicting chord tremolo values.', rawNote.source);
                            if (!event.ornaments?.length) event.ornaments = [{ source: reader.fieldLocations.get(rawNote.source.path + '/tremolo-marks')!, kind: 'tremolo', type: 'single', strokes: marks }];
                        }
                    }
                    const effects = reader.effects.get(beat);
                    if (effects) binaryBeatTechniques(effects.facts, event, reader.version, name => reader.fieldLocations.get(effects.source.path + '/' + name) ?? effects.source);
                    const mix = reader.mixes.get(beat);
                    if (mix && mix.facts['mix-tempo'] >= 0) tempos.push({ source: mix.source, measure: mi, position, rate: String(mix.facts['mix-tempo']), reference: 2, unit: 'quarter', dots: 0, quarterRate: mix.facts['mix-tempo'], visible: !mix.facts['mix-hide-tempo'] });
                    for (const note of sourceNotes) expected.push({ note: note.note, fact: note.fact, event });
                    previousEvents.set(vi, { event, end: add(measureStart, add(position, duration)) });
                    for(const {note,fact} of sourceNotes){const frame=reader.notes.get(note)!,own=reader.version<500&&(frame.facts['note-flags']&3)?binaryNoteValue(frame,event).duration:duration;sourceNoteDurations.set(fact,own);previousStrings.set(`${vi}:${fact.string}`,{note:fact,borrowed:note,end:add(measureStart,add(position,own))});}
                    const graceOwners=sourceNotes.map(({note,fact})=>({fact,facts:reader.notes.get(note)!.facts,locate:(name:string)=>reader.fieldLocations.get(reader.notes.get(note)!.source.path+'/'+name)??reader.notes.get(note)!.source}));
                    const unknownDead=graceOwners.filter(owner=>reader.version<500&&owner.facts['grace-fret']===-1);
                    const slotGraces=[...emptySlots,...deadSlots].flatMap(note=>{const slot=reader.notes.get(note)!;return binaryEmptySlot(slot,event,reader.version,name=>reader.fieldLocations.get(slot.source.path+'/'+name)??slot.source,findings,(fret,dead,source)=>{
                        const string=slot.facts['source-string'],reference=inferredPitch(highToLow[string-1]+capo.fret+(fret??0)),written=inferredPitch(reference.midi+writtenShift,key.fifths);
                        if(written.octave<0||written.octave>9)refuse('source-pitch-format-limit','Source grace pitch exceeds MusicXML4 octave0–9.',source);
                        return {source,id:source.id!,string,...(fret!==undefined?{fret}:{}),kind:dead?'dead':'pitched',written,sounding:dead?null:reference,...(dead&&fret!==undefined?{referenceSounding:reference}:{}),tieStart:false,tieStop:false};
                    },deadSlots.includes(note));});
                    const genericGraces=[...binaryUnfrettedDeadGraces(unknownDead,event,findings),...slotGraces];if(genericGraces.length)deadGraces.set(event.id,genericGraces);
                    const graces=binaryGraces(graceOwners.filter(owner=>!unknownDead.includes(owner)),event,reader.version,string=>highToLow[string-1]+capo.fret,inferredPitch,relations,findings,writtenShift);
                    position = add(position, duration);
                    return [...graces,event];
                });
            });
            const populated = voices.filter(voice => voice.length);
            if (!populated.length) {const event:Event={source,id:`${id}:${mi}:empty-measure`,start:q(0),duration:span,type:'whole',dots:0,notes:[],fullMeasureRest:true};voices[0]=[event];populated.push(voices[0]);findings.push({disposition:'inferred',code:'binary-empty-measure-rest',message:'An entirely empty encoded measure is projected as one standard measure rest; silent source voice slots remain separate.',location:source});}
            const totals = populated.map(voice => voice.reduce((sum, event) => add(sum, event.duration), q(0)));
            const {pickup,duration}=binaryMeasureExtent(totals,span,mi,staff.bars.length,source,findings);
            const encodedClef = frame.facts['clef-mode'];
            const clef = encodedClef === 0 ? 'G2' : encodedClef === 12 ? 'F4' : program < 32 ? 'G2' : highToLow.at(-1)! < 35 ? 'F4' : 'G2';
            measureStart = add(measureStart, duration);
            return { source, time: { beats, unit }, key: { ...key },
                clef, pickup, duration, voices, repeatStart: master.isRepeatStart, repeatEnd: master.repeatCount };
        });
        const rule = `gp3-5-${family}-register/0`;
        findings.push({ disposition: 'inferred', code: 'binary-written-register', message: `GP3–5 ${family} notation convention writes ${writtenShift} semitones above the encoded pitch grid, with corresponding MusicXML octave transpose. This is generated versioned representation (${rule}), not encoded chromatic transpose or another actual-pitch shift; producer display fidelity remains unverified.`, location: frame.source, fact: { program, transposeOctaves: -writtenShift/12, rule } });
        findings.push({ disposition: 'inferred', code: 'binary-pitch-spelling', message: 'Binary tuning/fret supplies pitch, not complete written spelling. Written spelling follows the active source key, with conventional chromatic sharps in nonflat keys and flats in flat keys; an encoded swap reverses that chromatic spelling. Physical reference spelling is generated separately.', location: frame.source });
        if (reader.version < 500) findings.push({ disposition: 'inferred', code: 'binary-clef', message: 'No explicit main clef field is encoded in this profile; guitar uses conventional treble, while bass uses a located low-tuning reference-clef rule. It is not source staff/hand identity.', location: frame.source, fact: { family } });
        findings.push({ disposition: 'preserved', code: 'binary-voice-slots', message: 'Encoded voice slots, including zero-beat secondary voices, are retained without generating rests or attacks.', location: frame.source, fact: { voiceCounts: measures.map(measure => measure.voices.map(voice => voice.length)) } });
        const recoveredPart:Part={ source: frame.source, id, name: track.name, instrument: family==='other'?`gm-program-${program}`:family, midiProgram: program, tuning, capo, transposeOctaves: -writtenShift/12, measures };
        // Fretless dead attacks participate in string topology before connection inference.
        // Their source type prevents pitched H/P arithmetic; no fake fret is supplied.
        for(const measure of recoveredPart.measures)for(const voice of measure.voices)for(const event of voice){const pending=deadNotes.get(event.id);if(pending)(event as MusicalEvent).notes.push(...pending);}
        binaryTies(recoveredPart,sourceNoteDurations,relations,findings);
        binaryHopo(recoveredPart,relations,findings);connectSlides(recoveredPart,slideOrigins,relations);connectSustainMarks(recoveredPart,relations);numberHopo(recoveredPart);parts.push(recoveredPart);
    }
    if (!parts.length || reader.selected && [...reader.selected].some(id => !reader.tracks.has(Number(id)))) refuse('track-selection', 'Requested binary track ID is absent.', { member: 'input' });
    for(let index=0;index<parts[0].measures.length;index++)if(parts.some(part => !equal(part.measures[index].duration, parts[0].measures[index].duration))) refuse(index===0?'pickup-span':'measure-duration', 'Selected tracks need one exact common encoded measure span.', { member: 'input',measure:index });
    const mixClocks=new Map<Beat,{measure:number;position:ReturnType<typeof q>}>();
    for(const [beat,event] of sourceEvents)mixClocks.set(beat,{measure:event.source.measure!-1,position:event.start});
    // Tempo is global even when its binary mixer record occurs on an excluded track.
    for (const [beat, mix] of reader.mixes) if ((!sourceEvents.has(beat)||emptyEvents.has(beat)||reader.selected && !reader.selected.has(mix.source.trackId!)) && (mix.facts['mix-tempo'] >= 0 || !reader.selected || reader.selected.has(mix.source.trackId!))) {
        let position = q(0);
        for (const prior of beat.voice.beats) {
            if (prior === beat) break;
            if(!reader.beats.has(prior)||emptyEvents.has(prior))continue;
            const raw = reader.beats.get(prior)!, exponent = raw.facts['duration-exponent'], actual = raw.facts.tuplet;
            if (!raw || prior.isEmpty || exponent < -2 || exponent > 4 || actual && ![3,5,6,7,9,10,11,12,13].includes(actual)) refuse('tempo-source-clock', 'Excluded track global tempo needs an admitted exact written prefix clock.', mix.source);
            const normal = actual === 3 ? 2 : actual && actual <= 7 ? 4 : 8;
            position = add(position, mul(mul(q(4, 2 ** (exponent + 2)), q(raw.facts['beat-flags'] & 1 ? 3 : 1, raw.facts['beat-flags'] & 1 ? 2 : 1)), q(actual ? normal : 1, actual ?? 1)));
        }
        const measure = mix.source.measure! - 1, span = parts[0].measures[measure].duration;
        if (position.n * span.d >= span.n * position.d) refuse('tempo-position', 'Global tempo in excluded track lies outside the selected common measure.', mix.source);
        mixClocks.set(beat,{measure,position});
        if(mix.facts['mix-tempo']>=0)tempos.push({ source: mix.source, measure, position, rate: String(mix.facts['mix-tempo']), reference: 2, unit: 'quarter', dots: 0, quarterRate: mix.facts['mix-tempo'], visible: !mix.facts['mix-hide-tempo'] });
        if(mix.facts['mix-tempo']>=0)findings.push({ disposition: 'preserved', code: 'binary-excluded-global-tempo', message: 'Global tempo is retained even when its containing track is excluded or its voice has no printed attacks; position is reconstructed from original written prefix fields.', location: mix.source });
    }
    for(const [beat,event] of sourceEvents)if(!emptyEvents.has(beat)&&parts.find(part=>part.id===event.source.trackId)?.instrument==='percussion') {
        const effects=reader.effects.get(beat);if(effects)binaryBeatTechniques(effects.facts,event,reader.version,name=>reader.fieldLocations.get(effects.source.path+'/'+name)??effects.source);
        const mix=reader.mixes.get(beat);if(mix&&mix.facts['mix-tempo']>=0)tempos.push({source:mix.source,measure:event.source.measure!-1,position:event.start,rate:String(mix.facts['mix-tempo']),reference:2,unit:'quarter',dots:0,quarterRate:mix.facts['mix-tempo'],visible:!mix.facts['mix-hide-tempo']});
    }
    binaryMasterStructure(score,reader.masters,reader.globals,reader.fieldLocations,parts,relations,reader.version);
    if(reader.lyricsFrame&&Object.entries(reader.lyricsFrame.facts).some(([name,value])=>name.startsWith('lyrics-present:')&&value)&&!reader.tracks.has(reader.lyricsFrame.facts['lyrics-track']))refuse('lyrics','Active lyrics name an absent source track.',reader.lyricsFrame.source);
    binaryLyrics(reader.bytes,reader.lyricsFrame,reader.fieldLocations,parts);
    // Strong fretted relations above only inspect actual known-fret components.
    // Append generic dead strokes after that pass, without weakening its contract.
    for(const part of parts)for(const measure of part.measures)measure.voices=measure.voices.map(voice=>{
        const output:MusicalEvent[]=[];
        for(const event of voice) {
            const extra=deadGraces.get(event.id);
            if(extra) {
                for(const grace of extra) {
                    const match=output.find(previous=>previous.grace?.hostId===event.id&&previous.grace.before===grace.grace!.before&&previous.type===grace.type&&previous.dynamic===grace.dynamic);
                    if(match)match.notes.push(...grace.notes);else output.push(grace);
                }
                const groups=output.filter(previous=>previous.grace?.hostId===event.id);
                if(groups.length>1){groups.forEach((grace,index)=>grace.voiceId=`${event.source.voice}:grace-projection:${index+1}`);findings.push({disposition:'inferred',code:'grace-parallel-projection',message:'Unlike simultaneous dead/pitched grace groups use derived serialization lanes at their common source host clock.',location:event.source});}
            }
            output.push(event);
        }
        return output;
    });
    for(const [beat,frame] of reader.chords) {const event=sourceEvents.get(beat),part=parts.find(part=>part.id===frame.source.trackId);if(event&&part)binaryChord(reader.bytes,reader.version,frame,event,part,frame.source.measure!-1,reader.fieldLocations,findings,reader.tracks.get(Number(part.id))!.facts['string-count']);}
    const emptyMetadata=[...emptyEvents].flatMap(([beat,event])=>binaryEmptyAnnotations(parts.find(part=>part.id===event.source.trackId)!,event,reader.version,reader.effects.get(beat),reader.fieldLocations,findings));
    const engravingBeats=[...sourceEvents].map(([beat,event])=>({event,...reader.beats.get(beat)!}));
    binaryBeams(parts,engravingBeats,reader.masters,reader.fieldLocations,findings);
    const unknownEngravingMetadata=engravingBeats.filter(({facts})=>facts['beat-flags2']&0x1000&&(!(facts['beat-flags2']&0x800)||facts.tuplet)).map(({source,facts})=>{const at=reader.fieldLocations.get(source.path+'/beat-flags2')??source;findings.push({disposition:'preserved' as const,code:'binary-unqualified-tuplet-display',message:'The exact secondary-tuplet display flag remains source metadata. Its bracket role is not independently qualified; no nested ratio, timing change or performer wording is invented.',location:at,fact:{flags:facts['beat-flags2'],tuplet:facts.tuplet??null}});return {source:at,name:'source-unqualified-tuplet-display:'+source.path,value:JSON.stringify({flags:facts['beat-flags2'],tuplet:facts.tuplet??null})};});
    const durationMetadata=reader.version<500?binaryNoteDurations(parts,[...reader.notes.values()],relations,findings):[];
    binaryTuplets(parts,engravingBeats,reader.fieldLocations,findings);
    binaryOttavas(parts,engravingBeats,reader.fieldLocations,relations,findings);
    const tempo = reader.globals['initial-tempo'];
    const initial: Tempo = { source: reader.records.find(record => record.source.path === '/header/initial-tempo')!.source,
        measure: 0, position: q(0), rate: String(tempo), reference: 2, unit: 'quarter', dots: 0, quarterRate: tempo, visible: !reader.globals['hide-tempo'] };
    const unique = new Map<string, Tempo>();
    for (const change of [initial, ...tempos]) {
        const key = `${change.measure}:${change.position.n}/${change.position.d}`, previous = unique.get(key);
        if (previous && previous.rate !== change.rate) {
            if (previous !== initial) refuse('tempo-conflict', 'Concurrent source tracks encode conflicting common tempo.', change.source);
        }
        if (previous && previous !== initial && previous.visible !== change.visible) refuse('tempo-conflict', 'Concurrent tempo records disagree about visibility.', change.source);
        unique.set(key, change);
    }
    const mixMetadata=binaryMix(parts,[...reader.mixes].flatMap(([beat,frame])=>{const clock=mixClocks.get(beat);return clock?[{...frame,...clock}]:[];}),reader.bytes,reader.fieldLocations,findings);
    const initialCaptionSource=reader.fieldLocations.get('/header/initial-tempo-name');
    if(initialCaptionSource){const text=binaryCaption(reader.bytes,initialCaptionSource);if(text){(parts[0].measures[0].directions??=[]).push({source:initialCaptionSource,kind:'words',staff:1,position:q(0),text,printObject:initial.visible});mixMetadata.push({source:initialCaptionSource,name:'source-initial-tempo-caption',value:text});}}
    const reservedMetadata:NonNullable<MusicalScore['metadata']>=[];
    const reserve=(source:Location,name:string,value:number)=>{reservedMetadata.push({source,name,value:String(value)});findings.push({disposition:'preserved',code:'binary-reserved-context',message:'The exact reserved or unqualified source context is retained without inventing transposition, a staff or a printed instruction.',location:source,fact:{name,value}});};
    const selectedIds=new Set(parts.map(part=>part.id));
    for(const frame of reader.effects.values()) if(selectedIds.has(frame.source.trackId!)) {
        for(const [name,mask] of [['beat-effect-flags',reader.version<400?0x80:0x8d],['beat-effect-flags2',0xf8]] as const) {
            const value=frame.facts[name];if(value!==undefined && value&mask)
                reserve(reader.fieldLocations.get(frame.source.path+'/'+name)??frame.source,`source-reserved-${name}:${frame.source.path}`,value);
        }
    }
    if(reader.globals['initial-octave'])reserve(reader.fieldLocations.get('/header/initial-octave')!,'source-reserved-initial-octave',reader.globals['initial-octave']);
    for(const part of parts){const frame=reader.tracks.get(Number(part.id))!;for(const name of ['clef-mode','secondary-clef-mode'])if(frame.facts[name]!==undefined&&(![0,12].includes(frame.facts[name])||name==='secondary-clef-mode'&&frame.facts[name]!==frame.facts['clef-mode']))reserve(reader.fieldLocations.get(frame.source.path+'/'+name)!,`source-unqualified-${name}:${part.id}`,frame.facts[name]);}
    const texts=binaryScoreTexts(score,reader.records.find(record=>record.source.path==='/score-information')!.source,parts[0].id);
    const neutral = { title: score.title, ...texts, metadata:[...(texts.metadata??[]),...durationMetadata,...mixMetadata,...unknownEngravingMetadata,...reservedMetadata,...emptyMetadata], parts, tempos: [...unique.values()].sort((a, b) => a.measure - b.measure || a.position.n * b.position.d - b.position.n * a.position.d), ...(relations.length ? { relations } : {}) };
    for(const part of parts)for(const measure of part.measures)for(const event of measure.voices.flat())for(const note of event.notes)if(note.kind!=='unpitched'){
        const shift=-(part.transposeOctaves??0)*12;
        const pitches=[{role:'written',pitch:note.written},...Object.entries(note.harmonic??{}).filter(([role])=>['base','touch','result'].includes(role)).map(([role,pitch])=>({role,pitch:{...(pitch as Pitch),octave:(pitch as Pitch).octave+shift/12,midi:(pitch as Pitch).midi+shift}}))];
        for(const {role,pitch} of pitches)if(pitch.octave<0||pitch.octave>9){findings.push({disposition:'preserved',code:'source-pitch-format-limit-facts',message:'Exact note role exceeds the MusicXML4 octave0–9 domain.',location:note.source,fact:{role,written:pitch}});refuse('source-pitch-format-limit',`Source ${role} role at octave${pitch.octave} (MIDI${pitch.midi}) exceeds MusicXML4 octave0–9.`,note.source);}
    }
    return { score: neutral, expected, drums, dead };
}

function loadBinary(input: Uint8Array, findings: Finding[], trackIds?: string[], discovery = false) {
    const bytes = Bytes.view(input);
    if (bytes.length < 31 || bytes[0] > 30) refuse('binary-header', 'Expected a complete fixed-width Guitar Pro header.', { member: 'input', byteOffset: 0 });
    const header = bytes.subarray(1, 1 + bytes[0]).ascii(), version = headers[header];
    if (!version) refuse('version-profile', 'Only documented whole-score GP3.00/GP4.00/GP4.06/L4.06/GP5.00/GP5.10 binary headers are admitted; clipboard/unknown versions require explicit support.', { member: 'input', byteOffset: 0, byteLength: 31 });
    if (trackIds && (!trackIds.length || new Set(trackIds).size !== trackIds.length || trackIds.some(id => !/^(?:0|[1-9][0-9]*)$/.test(id)||!Number.isSafeInteger(Number(id))||Number(id)>=limits.tracks))) refuse('track-selection', 'Expected distinct canonical encoded track ordinals within the track resource budget.');
    const reader = new CapturingReader(bytes, version, trackIds ? new Set(trackIds) : undefined, discovery);
    reader.init(new BoundedInput(bytes, () => reader.location), new Settings());
    let prepared: ReturnType<typeof recoverBeforeFinish> | undefined;
    let rawScore: Score | undefined;
    reader.onBeforeFinish = score => { rawScore = score; if (discovery) throw new DiscoveryComplete(); prepared = recoverBeforeFinish(score, reader, findings); };
    Logger.logLevel = LogLevel.None;
    try { reader.readScore(); } catch (error) {
        if (error instanceof DiscoveryComplete) { /* Complete source parsing; normalization is unnecessary for metadata. */ }
        else if (error instanceof Refusal) throw error;
        else refuse('binary-truncated', 'Binary reader encountered truncated or malformed bounded input.', { member: 'input' });
    }
    if (!rawScore || !discovery && !prepared) refuse('reader', 'Binary reader did not provide pre-normalization source capture.');
    if (!discovery && version>=500) for (const frame of reader.notes.values()) if (frame.facts['note-flags']&1) {
        const next=reader.fieldLocations.get(frame.source.path+'/note-flags2')!;
        findings.push({ disposition: 'excluded-by-scope', code: 'binary-playback-duration', message: 'The eight source bytes for GP5 playback-duration scaling remain captured without interpreting the playback multiplier. Written rhythm and performer instructions are unchanged.', location:{...next,path:frame.source.path+'/playback-duration',byteOffset:next.byteOffset!-8,byteLength:8} });
    }
    if (!discovery) for (const [path, location] of reader.fieldLocations) if (path.endsWith('/final-layout-absent')) findings.push({ disposition: 'excluded-by-scope', code: 'final-layout-absent', message: 'The complete GP5 score omits only its terminal page-layout byte; no byte or musical fact was synthesized.', location });
    if (reader.position > bytes.length) refuse('binary-truncated', 'Reader cursor exceeded binary input.', { member: 'input', byteOffset: bytes.length });
    if (reader.position !== bytes.length) {
        const expectedPadding = version < 500 ? 4 : 0;
        const tail = bytes.subarray(reader.position);
        if (tail.length !== expectedPadding || tail.some(byte => byte !== 0)) refuse('binary-trailing', 'Unaccounted bytes follow the complete binary score.', { member: 'input', byteOffset: reader.position });
        if (!discovery) reader.records.push({ kind: 'serialization-padding', source: { member: 'input', byteOffset: reader.position, byteLength: tail.length }, dataBase64: tail.base64(), facts: {} });
        findings.push({ disposition: 'preserved', code: 'binary-final-padding', message: 'Reviewed zero footer/separator bytes are retained as serialization padding, not musical events.', location: { member: 'input', byteOffset: reader.position, byteLength: tail.length } });
    }
    return { reader, header, version, prepared, rawScore: rawScore! };
}
class DiscoveryComplete {}

export function readBinary(input: Uint8Array, findings: Finding[], trackIds?: string[]): { score: MusicalScore; occurrences: OccurrenceCapture[]; capture: BinaryCapture } {
    const { reader, header, version, prepared } = loadBinary(input, findings, trackIds);
    const occurrences:OccurrenceCapture[] = prepared!.expected.map(({ note, fact, event }) => {
        const reference = fact.sounding ?? fact.referenceSounding ?? fact.harmonic?.base!;
        const sourceCount = reader.tracks.get(Number(fact.source.trackId))!.facts['string-count'];
        const beforeString = sourceCount - fact.string + 1;
        if (note.fret !== fact.fret || note.string !== beforeString || (fact.harmonic ? note.realValueWithoutHarmonic !== note.stringTuning + fact.fret : note.realValue !== reference.midi) || note.isDead !== (fact.kind === 'dead') || note.isTieDestination !== fact.tieStop)
            refuse('reader-reconciliation', 'Normalized binary reader disagrees with immutable physical/type/tie facts.', fact.source);
        const family=midiFamily(prepared!.score.parts.find(part=>part.id===fact.source.trackId)!.midiProgram!);
        if(prepared!.score.parts.find(part=>part.id===fact.source.trackId)!.instrument!=='banjo'&&family!=='guitar'&&family!=='bass')return {kind:'pitched',source:fact.source,rhythmId:event.id+'/rhythm',noteId:fact.id,before:{soundingMidi:reference.midi,writtenMidi:fact.written.midi,tieDestination:fact.tieStop},after:{soundingMidi:reference.midi,tieDestination:note.isTieDestination,playbackTicks:note.beat.playbackDuration}};
        return { source: fact.source, rhythmId: event.id + '/rhythm', noteId: fact.id,
            before: { fret: reader.notes.get(note)!.facts['note-fret'], string: beforeString, tieDestination: fact.tieStop },
            after: { fret: note.fret, string: note.string, tieDestination: note.isTieDestination, soundingMidi: reference.midi, playbackTicks: note.beat.playbackDuration } };
    });
    occurrences.push(...reconcileBinaryDrums(prepared!.drums));
    for(const {note,fact,event} of prepared!.dead){const count=reader.tracks.get(Number(fact.source.trackId))!.facts['string-count'],string=count-fact.string!+1;
        if(note.fret!==-1||note.string!==string||!note.isDead||note.isTieDestination)refuse('reader-reconciliation','Reader disagrees with explicit fretless dead stroke.',fact.source);
        occurrences.push({kind:'dead',source:fact.source,noteId:fact.id,rhythmId:event.id+'/rhythm',before:{string,rawFret:-1,tieDestination:false},after:{string,rawFret:-1,tieDestination:false,playbackTicks:note.beat.playbackDuration}});
    }
    const score:MusicalScore={...prepared!.score,parts:prepared!.score.parts.map((part):MusicalPart=>{
        if(part.instrument==='banjo'){const source=reader.fieldLocations.get(part.source.path+'/track-flags')!;findings.push({disposition:'inferred',code:'binary-banjo-short-string',message:'The source fifth string uses local-nut fret coordinates. Its pitch keeps encoded tuning plus source fret and capo; positive displayed fret adds the established five-fret nut offset. Raw chord-frame coordinates remain their independent literal source fields.',location:source,fact:{string:5,startFret:5}});return {...part,measures:part.measures.map(measure=>({...measure,voices:measure.voices.map(voice=>voice.map(event=>({...event,notes:event.notes.map(note=>note.string===5&&note.fret!==undefined?{...note,fretDisplay:{source,value:note.fret===0?0:note.fret+5,startFret:5,origin:'short-string-notation' as const}}:note)})))}))};}
        const family=midiFamily(part.midiProgram!);if(part.instrument==='percussion'||family==='guitar'||family==='bass')return part;
        const {tuning,capo,...pitched}=part;
        findings.push({disposition:'preserved',code:'binary-pitched-editor-grid',message:'Source MIDI program identifies a nonfretted pitched part. Encoded string/fret input slots remain captured but do not become physical performer guidance or a TAB staff.',location:part.source,fact:{program:part.midiProgram,sourceTuning:tuning,sourceCapo:capo}});
        return {...pitched,measures:pitched.measures.map(measure=>({...measure,voices:measure.voices.map(voice=>voice.map(event=>({...event,notes:event.notes.map(note=>{const {string,fret,...pitchedNote}=note;return pitchedNote;})})))}))};
    })};
    findings.push({ disposition: 'preserved', code: 'binary-source-reconciled', message: 'Original numeric flags/spans are captured before normalization; beat spacing and physical/type/tie facts reconcile with the borrowed reader. Legacy independent note duration remains separately source-authoritative. Track IDs are stable encoded ordinals, not inferred performing roles.', location: { member: 'input' }, fact: { header, version, noteOccurrences: occurrences.length } });
    findings.push({ disposition: 'omitted', code: 'binary-metadata-playback', message: 'Original page and playback setup bytes remain captured. Musical metadata, lyrics and chord instructions are projected separately; synth timbre and exact native page geometry are not reapplied.', location: { member: 'input' } });
    return freeze({ score, occurrences, capture: { header, version, sourceEncoding: 'windows-1252-with-explicit-BOM-detection', records: reader.records } });
}

/** Compact observations from the complete bounded source parse, before model normalization. */
export function readBinaryMetadata(input: Uint8Array, findings: Finding[]) {
    const { reader, header, version, rawScore } = loadBinary(input, findings, undefined, true);
    return { header, version, tracks: rawScore.tracks.map(track => {
        const frame = reader.tracks.get(track.index)!, path = frame.source.path!, channel = frame.facts['channel'] - 1;
        const first = reader.fieldLocations.get(path + '/tuning:0')!;
        return { sourceId: String(track.index), sourceLocation: frame.source,
            name: track.name, nameLocation: reader.fieldLocations.get(path + '/track-name-length')!,
            program: reader.globals['channel-program:' + channel], programLocation: reader.fieldLocations.get('/header/channel-program:' + channel)!,
            tuning: Array.from({ length: frame.facts['string-count'] }, (_, i) => frame.facts['tuning:' + i]),
            tuningLocation: { ...first, byteLength: frame.facts['string-count'] * 4 }, capoLocation: reader.fieldLocations.get(path + '/capo')!, facts: frame.facts };
    }) };
}

import type { GlyphFact, SourceColor } from '../../core/model.js';
import { canonicalSymbolVocabulary } from '../../core/canonical-symbols.js';
import { xmlCharacter, literalFontFamily } from '../../core/font-character.js';
import { refuse, type Location } from '../../core/report.js';
import { child, integer, type SourceElement as Element } from '../../core/source-xml.js';
import type { NativeBudget } from './budget.js';
import { createNativeStaffSpaceResolver, type NativeTextScaleContext } from './text-size.js';

interface NativeGlyphContext {
    nativeVersion: string;
    budget: NativeBudget;
    use: (node: Element) => unknown;
    get: (node: Element, name: string, required?: boolean) => string;
    readColor: (node: Element) => SourceColor | undefined;
    decoration: (node: Element) => void;
    performanceGap: (code: string, source: Location, message: string, disposition?: 'omitted' | 'inferred' | 'preserved') => void;
    styleScopes?: readonly Element[];
}
const decimal = (value: string, field: Element): number => {
    if (!/^-?\d{1,6}(?:\.\d{1,20})?$/.test(value) || !Number.isFinite(Number(value)) || Math.abs(Number(value)) > 10000)
        refuse('native-symbol-number', 'Glyph appearance needs a bounded finite decimal.', field.location);
    return Number(value);
};
/** SMuFL scoring-font em is four staff spaces; native magnification is multiplicative. */
export function createNativeGlyphSizeProjector(scopes: readonly Element[], nativeVersion: string, use?: (node: Element)=>unknown) {
    const space = createNativeStaffSpaceResolver(scopes,nativeVersion,use);
    return (node: Element, multiplier: number, context?: NativeTextScaleContext): GlyphFact['fontSize'] => {
        const sourceSpace = space(node,context); if(!sourceSpace || !Number.isFinite(multiplier) || multiplier<=0)return undefined;
        const millimeters=sourceSpace.scoreSpatium.millimeters,staffFactor=sourceSpace.staff.factor;
        const points=4*millimeters*staffFactor*72/25.4*multiplier;
        if(!Number.isFinite(points)||points<=0||points>10000)return undefined;
        return {source:node.location,points,origin:'source-staff-space',millimeters,staffFactor,multiplier,sourceSpace};
    };
}
/** Bare source glyph identity has no implied articulation, navigation or playback role. */
export function createNativeGlyphReader({ nativeVersion, budget, use, get, readColor, decoration, performanceGap, styleScopes = [] }: NativeGlyphContext) {
    let ordinal = 0;
    const pointSize=createNativeGlyphSizeProjector(styleScopes,nativeVersion,use);
    const readGlyphs = (node: Element, parentId?: string, hidden = false, result: GlyphFact[] = [], context?: NativeTextScaleContext): GlyphFact[] => {
        use(node); budget.add('markings', 1, node.location);
        const fontCharacter = node.name === 'FSymbol';
        for(const property of fontCharacter ? ['visible','font','fontsize','code'] : ['name','visible','font','size','symbolsSize','symbolAngle']) {
            const field=child(node,property);
            if(field && (field.children.length || Object.keys(field.attrs).length))refuse('native-symbol-field','Glyph identity and appearance require plain scalar fields.',field.location);
        }
        const name = fontCharacter ? 'FSymbol' : get(node, 'name', true);
        if (!name || name.length > 256) refuse('native-symbol', 'Source glyph name must be nonempty and bounded.', child(node, 'name', true)!.location);
        const visibility = get(node, 'visible'), visible = visibility ? integer(visibility, 0, 1, node.location) === 1 : undefined;
        const fact: GlyphFact = { source: node.location, id: `native-glyph:${ordinal++}`, name,
            ...(parentId ? { parentId } : {}), ...(hidden || visible === false ? { printObject: false } : visible === true ? { printObject: true } : {}) };
        if (fontCharacter) {
            const field = child(node,'code'), raw = get(node,'code');
            if (field && (!/^-?\d{1,10}$/.test(raw) || Number(raw) < -2147483648 || Number(raw) > 2147483647)) refuse('native-font-character-code','Font character code requires a source signed 32-bit integer.',field.location);
            const code = field ? Number(raw) : 0, text = xmlCharacter(code);
            fact.projection = 'font-character';
            fact.fontCharacter = {source:field?.location ?? node.location,code,origin:field ? 'source-property' : 'native-default',...(text === undefined ? {} : {text})};
            performanceGap('native-font-character-preservation',node.location,'Literal font-character fields and their serialized owner are preserved as standard annotations without inferred musical semantics. Native owner reload is not asserted: modern native readers can parse this legacy object but discard it when attaching it.','preserved');
            const fontField=child(node,'font');get(node,'font');
            if(fontField) {
                if(fontField.text.length>256)refuse('native-symbol-font','Source glyph font label exceeds its bounded profile.',fontField.location);
                fact.sourceFont={source:fontField.location,value:fontField.text};
                if(!literalFontFamily(fontField.text))performanceGap('native-font-character-family',fontField.location,'The literal font family cannot be represented as an unambiguous standard font-family list. Exact source text remains auxiliary; no replacement font is inferred.');
            }
            const sizeField=child(node,'fontsize');
            if(sizeField) {
                const rawValue=get(node,'fontsize'),value=decimal(rawValue,sizeField);
                fact.fontCharacter.pointSize={source:sizeField.location,rawValue,value};
                if(value<=0)performanceGap('native-font-character-size',sizeField.location,'A nonpositive stored font point size does not establish a portable effective font size. The exact field remains auxiliary without substituting a font default.');
            }
            const color=readColor(node);if(color)fact.sourceColor=color;
            if(text===undefined)performanceGap('native-font-character-xml-limit',fact.fontCharacter.source,'The source character code is not an XML 1.0 Unicode scalar. Exact code, font and ownership survive in auxiliary facts and a hidden standard annotation; no visible replacement character is invented.');
            result.push(fact);
            const nested=node.children.filter(e=>e.name==='Symbol'||e.name==='FSymbol');
            for(const symbol of nested)readGlyphs(symbol,fact.id,fact.printObject===false,result,context);
            if(nested.length)performanceGap('native-symbol-group-geometry',node.location,'Exact source glyph group and parent identities survive. Standard annotations preserve order and ownership without promising native nested spatial offsets.');
            decoration(node);return result;
        }
        if (name === 'noSym') fact.projection = 'empty';
        else if (!canonicalSymbolVocabulary.has(name)) {
            fact.projection = 'source-name';
            performanceGap('native-symbol-name-preservation', node.location, 'The source glyph identifier has no verified canonical SMuFL equivalent. Standard other-direction/other-notation retains the literal identifier and ownership, with exact auxiliary source facts; its native glyph appearance is not asserted.', 'preserved');
        }
        const color = readColor(node); if (color) fact.sourceColor = color;
        const font = get(node, 'font');
        if (font) {
            if (font.length > 256) refuse('native-symbol-font', 'Source glyph font label exceeds its bounded profile.', node.location);
            fact.sourceFont = { source: child(node,'font')!.location, value: font };
            performanceGap('native-symbol-font', node.location, 'The original glyph font label remains an exact auxiliary fact. Canonical glyph identity is portable; no font is loaded, shipped or claimed metrically identical.');
        }
        for (const name of ['size','symbolsSize','symbolAngle'] as const) {
            const field = child(node,name); if (!field) continue;
            const value = decimal(get(node,name),field);
            (fact.sourceAppearance ??= []).push({ source: field.location, name, value });
            if (name === 'symbolsSize' && Number(nativeVersion) >= 4.1 && font) {
                if (value <= 0) refuse('native-symbol-size','Source glyph magnification must be positive.',field.location);
                fact.fontSize = pointSize(node,value,context);
                if (!fact.fontSize) performanceGap('native-symbol-size-context', field.location, 'Source relative glyph magnification is retained exactly; the source staff-space context needed for standard point size is not established.');
            } else if (name === 'symbolAngle' && Number(nativeVersion) >= 4.1 && font) fact.rotation = { source: field.location, degrees: ((value + 180) % 360 + 360) % 360 - 180 };
            else performanceGap('native-symbol-unqualified-size', field.location, 'This source appearance field has no qualified glyph-size law in this native version. Its exact value remains auxiliary; it is not mislabeled as point size.');
        }
        if (!child(node,'symbolsSize') || Number(nativeVersion) < 4.1 || !font) fact.fontSize=pointSize(node,1,context);
        if (fact.rotation && fact.projection === 'source-name') performanceGap('native-symbol-rotation-carrier',fact.rotation.source,'MusicXML other-direction has no rotation attribute for noncanonical identifier text. Exact source rotation remains auxiliary; native glyph appearance has no verified standard identity.');
        else if(fact.rotation && fact.rotation.degrees && /\/(?:Note|Chord|Rest)\[/.test(node.location.path ?? '')) performanceGap('native-symbol-rotated-note-carrier',fact.rotation.source,'The rotated canonical glyph uses one standard symbol direction at its exact event clock, staff and voice; a hidden other-notation and auxiliary facts retain the source note/rest attachment.','preserved');
        result.push(fact);
        const nested = node.children.filter(e=>e.name==='Symbol'||e.name==='FSymbol');
        for (const symbol of nested) readGlyphs(symbol,fact.id,fact.printObject === false,result,context);
        if (nested.length) performanceGap('native-symbol-group-geometry',node.location,'Exact source glyph group and parent identities survive. Standard annotations preserve order and ownership without promising native nested spatial offsets.');
        decoration(node); return result;
    };
    return readGlyphs;
}

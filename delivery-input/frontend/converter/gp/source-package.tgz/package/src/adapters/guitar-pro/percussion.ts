import { PercussionMapper } from '../../../third_party/alphatab/src/model/PercussionMapper.js';
import { MusicFontSymbol } from '../../../third_party/alphatab/src/model/MusicFontSymbol.js';
import { child, children, integer, value, type Element } from './xml.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import type { MusicalPart, NoteDetails, UnpitchedNote } from '../../core/model.js';
import { sourceProperties } from './arrangements.js';
import { gp6LocalPercussion } from './gp6-percussion.js';

export interface SourcePercussion {
    source: Location; id: string; name: string; midi: number; line: number; heads: string[]; technique?: string;
}
function shape(e: Element, allowed: string[], repeated: string[] = []): void {
    if (Object.keys(e.attrs).length || e.text.trim()) refuse('percussion-field', 'Malformed percussion structure.', e.location);
    const seen = new Set<string>();
    for (const field of e.children) { if (!allowed.includes(field.name) || seen.has(field.name) && !repeated.includes(field.name)) refuse('percussion-field', 'Uninterpreted or duplicate percussion field.', field.location); seen.add(field.name); }
}
const plain = (e: Element): void => { if (e.children.length || Object.keys(e.attrs).length) refuse('percussion-field', 'Percussion field requires plain source data.', e.location); };
/** Explicit GP7+ articulation order and source NotationPatch jointly own drum identity and staff appearance. */
export function percussionCatalog(track: Element): SourcePercussion[] {
    const set = child(track, 'InstrumentSet', false); if (!set) return [];
    const elements = child(set, 'Elements')!, results: SourcePercussion[] = [], identities = new Map<string, SourcePercussion>();
    shape(elements, ['Element'], ['Element']);
    for (const element of children(elements, 'Element')) {
        shape(element, ['Name','Type','SoundbankName','Articulations']);
        for (const e of element.children.filter(e => e.name !== 'Articulations')) plain(e);
        shape(child(element, 'Articulations')!, ['Articulation'], ['Articulation']);
        const elementName = value(element, 'Name');
        for (const articulation of children(child(element, 'Articulations')!, 'Articulation')) {
            shape(articulation, ['Name', 'StaffLine', 'Noteheads', 'TechniquePlacement', 'TechniqueSymbol', 'InputMidiNumbers', 'OutputRSESound', 'OutputMidiNumber']);
            if (results.length >= 256) refuse('percussion-budget', 'Too many source instrument articulations.', articulation.location);
            for (const field of articulation.children) { if (!['Name', 'StaffLine', 'Noteheads', 'TechniquePlacement', 'TechniqueSymbol', 'InputMidiNumbers', 'OutputRSESound', 'OutputMidiNumber'].includes(field.name)) refuse('percussion-field', 'Uninterpreted source drum articulation.', field.location); plain(field); }
            const name = value(articulation, 'Name'), key = `${elementName}\0${name}`;
            if (identities.has(key)) refuse('percussion-identity', 'Ambiguous source articulation identity.', articulation.location);
            const heads = value(articulation, 'Noteheads').split(/\s+/);
            if (heads.length !== 3 || heads.some(name => !/^notehead[A-Za-z0-9]+$/.test(name))) refuse('percussion-notehead', 'Explicit default/half/whole drum heads are required.', articulation.location);
            const fact: SourcePercussion = { source: articulation.location, id: `gp-drum:${track.attrs.id}:${results.length}`, name: name ? `${elementName}: ${name}` : elementName, midi: integer(value(articulation, 'OutputMidiNumber'), 0, 127, articulation), line: integer(value(articulation, 'StaffLine'), -32, 48, articulation), heads, ...(value(articulation, 'TechniqueSymbol', false) ? { technique: value(articulation, 'TechniqueSymbol') } : {}) };
            results.push(fact); identities.set(key, fact);
        }
    }
    const patch = child(track, 'NotationPatch', false);
    if (patch) {
        shape(patch, ['Name','LineCount','Elements']);
        for (const field of patch.children.filter(e => e.name !== 'Elements')) plain(field);
        if (child(patch,'LineCount',false) && value(patch,'LineCount') !== '5') refuse('percussion-lines','Percussion notation patch must declare the supported five-line source coordinate system.',patch.location); shape(child(patch, 'Elements')!, ['Element'], ['Element']);
        const patched = new Set<string>();
        for (const element of children(child(patch, 'Elements')!, 'Element')) {
            shape(element, ['Name','Articulations']); plain(child(element,'Name')!); shape(child(element,'Articulations')!,['Articulation'],['Articulation']);
            const elementName = value(element, 'Name');
            for (const articulation of children(child(element, 'Articulations')!, 'Articulation')) {
                shape(articulation, ['Name','StaffLine']);
                const key = `${elementName}\0${value(articulation, 'Name')}`, target = identities.get(key);
                if (!target || patched.has(key)) refuse('percussion-patch', 'Notation patch must target one unique declared drum articulation.', articulation.location);
                patched.add(key);
                for (const field of articulation.children) { if (!['Name', 'StaffLine'].includes(field.name)) refuse('percussion-patch', 'Uninterpreted source notation override.', field.location); plain(field); }
                target!.line = integer(value(articulation, 'StaffLine'), -32, 48, articulation);
            }
        }
    }
    return results;
}
/** Only exact pinned native articulation entries are allowed. An unknown number never becomes a default snare. */
export function nativePercussion(number: number, source: Location, trackId: string): SourcePercussion {
    const native = PercussionMapper.getArticulationById(number);
    if (!native) return refuse('percussion-identity', 'Encoded percussion identity has no verified native definition; no GM/default pitch is substituted.', source);
    const name = (symbol: MusicFontSymbol): string => { const text = MusicFontSymbol[symbol]; if (!text || text === 'None') return 'noteheadBlack'; return text[0].toLowerCase() + text.slice(1); };
    return { source, id: `gp-drum:${trackId}:${number}`, name: native.elementType, midi: native.outputMidiNumber, line: native.staffLine,
        heads: [name(native.noteHeadDefault), name(native.noteHeadHalf), name(native.noteHeadWhole)], ...(native.techniqueSymbol !== MusicFontSymbol.None ? { technique: name(native.techniqueSymbol) } : {}) };
}
export function sourcePercussion(source: Element, catalog: SourcePercussion[], trackId: string, findings: Finding[], instrumentReference = 'drmkt'): { fact: SourcePercussion; articulation: number } {
    const encoded = child(source, 'InstrumentArticulation', false), properties = sourceProperties(source);
    const element = properties.get('Element'), variation = properties.get('Variation');
    if (encoded) {
        const index = integer(encoded.text.trim(), 0, 255, encoded);
        if (element || variation) refuse('percussion-identity', 'Conflicting indexed and element/variation percussion encodings.', source.location);
        if (!catalog[index]) refuse('percussion-unresolved-articulation', 'The positive source articulation index has no established catalog entry; its identity remains an unresolved source capability.', encoded.location);
        return { fact: catalog[index], articulation: index };
    }
    if (!element || !variation) return refuse('percussion-identity', 'GP6 percussion requires both encoded element and variation.', source.location);
    const elementNumber = integer(value(element, 'Element'), 0, 16, element), variationNumber = integer(value(variation, 'Variation'), 0, 4, variation);
    const kit = ['drmkt','drumKit','percussion'].includes(instrumentReference);
    if (kit && variationNumber > 2) refuse('percussion-identity', 'Drum-kit variation is outside the verified selector table.', variation.location);
    const articulation = kit ? PercussionMapper.articulationFromElementVariation(elementNumber, variationNumber) : gp6LocalPercussion(instrumentReference, elementNumber, variationNumber, source.location);
    const fact = nativePercussion(articulation, source.location, trackId);
    // Native GP6 identity is retained. The borrowed table's GM substitute is not authored output.
    fact.midi = articulation;
    findings.push({ disposition: 'inferred', code: 'gp6-percussion-definition', message: 'Encoded GP6 element/variation selects an exact pinned native drum definition; its notation is a format default, not an inferred definite pitch.', location: source.location, fact: { element: elementNumber, variation: variationNumber, articulation, midi: fact.midi, line: fact.line } });
    return { fact, articulation };
}
export function percussionNote(fact: SourcePercussion, identity: Pick<NoteDetails, 'source' | 'id' | 'tieStart' | 'tieStop'>, type: string): UnpitchedNote {
    // Renderer steps are measured from the top line at zero, despite the older upstream prose saying one.
    const diatonic = 38 - fact.line, octave = Math.floor(diatonic / 7);
    if (octave < 0 || octave > 9) refuse('percussion-register', 'Encoded drum staff position exceeds MusicXML display register.', fact.source);
    const note: UnpitchedNote = { ...identity, kind: 'unpitched', sounding: null, unpitched: { displayStep: 'CDEFGAB'[((diatonic % 7) + 7) % 7], displayOctave: octave, midi: fact.midi, instrumentId: fact.id } };
    const head = fact.heads[type === 'whole' ? 2 : type === 'half' ? 1 : 0];
    if (['noteheadBlack', 'noteheadHalf', 'noteheadWhole'].includes(head)) { note.notehead = 'normal'; note.noteheadFilled = head === 'noteheadBlack'; }
    else if (/^noteheadX(?:Black|Half|Whole)$/.test(head)) { note.notehead = 'x'; note.noteheadFilled = head === 'noteheadXBlack'; }
    else if (/^noteheadTriangleUp(?:Black|Half|Whole)$/.test(head)) { note.notehead = 'triangle'; note.noteheadFilled = head.endsWith('Black'); }
    else if (['noteheadDiamondWhite', 'noteheadDiamondWhiteWide', 'noteheadDiamondBlackWide'].includes(head)) { note.notehead = 'diamond'; note.noteheadFilled = head === 'noteheadDiamondBlackWide'; }
    else if (head === 'noteheadCircleX') note.notehead = 'circle-x';
    else if (head === 'noteheadNull') note.notehead = 'none';
    else { note.notehead = 'other'; note.noteheadSmufl = { source: fact.source, name: head }; }
    note.sourceNotehead = { source: fact.source, value: head };
    if (fact.technique === 'articStaccatoAbove') note.articulations = ['staccato'];
    else if (fact.technique === 'stringsUpBow' || fact.technique === 'stringsDownBow') note.technical = [{ source: fact.source, kind: fact.technique === 'stringsUpBow' ? 'up-bow' : 'down-bow' }];
    else if (fact.technique === 'noteheadParenthesis') note.noteheadParentheses = { source: fact.source, value: true, origin: 'source' };
    else if (fact.technique) note.symbols = [{ source: fact.source, id: `${identity.id}:percussion-technique`, name: fact.technique }];
    return note;
}
export function percussionInstrument(fact: SourcePercussion): NonNullable<MusicalPart['percussionInstruments']>[number] {
    return { source: fact.source, id: fact.id, name: fact.name, midi: fact.midi, line: fact.line, notehead: 'normal', defaultVoice: 1 };
}

import { readPartialCapo } from './partial-capo.js';
import { Bytes, sha256 } from './bytes.js';
import { guitarProEncoding } from './encoding.js';
import { readBinaryMetadata } from './binary.js';
import { readGpx } from './gpx.js';
import { captureContainer } from './container-facts.js';
import { validateGpifHeader } from './gp8.js';
import { child, children, value, parseXml, type Element } from './xml.js';
import { limits } from './limits.js';
import { freeze, Refusal, refuse, type Finding, type Location } from '../../core/report.js';
import type { ConversionResult } from './convert-core.js';
import { admitDescriptors } from './zip-core.js';
import { admittedFamily, isFrettedReference, midiFamily, type InstrumentFamily } from './admission.js';
import { discoverArrangementGraph, sourceStaves } from './arrangements.js';
import { BoundedFindings, jsonBytes } from './work-budgets.js';

interface TrackDiscovery {
    sourceId: string; sourceLocation: Location;
    sourceName?: { value: string; sourceLocation: Location };
    instrument: { family?: InstrumentFamily; observations: { kind: 'family' | 'ref' | 'midi-program'; value: string | number; sourceLocation: Location; provenance: 'encoded' | 'derived-from-encoded-channel' }[] };
    tuning?: { pitches: number[]; order: 'low-to-high'; stringCount: number; sourceLocation: Location; encodedOrder: 'low-to-high' | 'high-to-low' };
    capo?: { fret: number; sourceLocation: Location };
    staves?: { number: number; sourceLocation: Location; tuning?: TrackDiscovery['tuning']; capo?: TrackDiscovery['capo'] }[];
    metadataEligibility: { status: 'eligible' | 'ineligible' | 'unknown'; profile: string; findings: Finding[] };
}
type Immutable<T> = T extends readonly (infer Item)[] ? readonly Immutable<Item>[] : T extends object ? { readonly [Key in keyof T]: Immutable<T[Key]> } : T;
export type SourceTrackInfo = Immutable<TrackDiscovery>;
type InspectionReport = Immutable<Omit<ConversionResult['report'], 'convertedParts'>>;
export type InspectionResult = { readonly ok: true; readonly report: InspectionReport; readonly tracks: readonly SourceTrackInfo[] } | { readonly ok: false; readonly report: InspectionReport; readonly tracks?: never };
const finding = (code: string, message: string, location: Location): Finding => ({ disposition: 'blocking', code, message, location });
function eligibility(program: number | undefined, tuning: TrackDiscovery['tuning'], source: Location, profile: string, ref?: string, binary = false): TrackDiscovery['metadataEligibility'] {
    const findings: Finding[] = [];
    let status: 'eligible' | 'ineligible' | 'unknown' = 'eligible';
    if (program === undefined || !Number.isInteger(program) || program < 0 || program > 127) {
        status = 'unknown'; findings.push(finding('instrument-unknown', 'No unambiguous encoded MIDI program establishes metadata eligibility.', source));
    } else {
        let family: InstrumentFamily | undefined;
        try { family = binary ? midiFamily(program, ref === 'percussion') : ref ? admittedFamily(ref, program, source) : undefined; }
        catch { status = 'ineligible'; findings.push(finding('instrument-profile', 'Encoded instrument family and MIDI program family disagree.', source)); }
        if (!family && status === 'eligible') { status = 'unknown'; findings.push(finding('instrument-unknown', 'Missing source instrument identity.', source)); }
        if ((family === 'guitar' || family === 'bass' || ref && isFrettedReference(ref)) && (!tuning || tuning.stringCount < 1 || tuning.stringCount > (profile.startsWith('gp3-5') ? 7 : 16) || tuning.pitches.some((p, i) => p < 0 || p > 127))) {
            status = 'ineligible'; findings.push(finding('tuning-profile', 'Fretted source instrument requires complete ordered string tuning.', tuning?.sourceLocation ?? source));
        }
    }
    return { status, profile: program !== undefined && program >= 24 && program <= 31 ? profile.replace('-bass/', '-guitar/') : profile, findings };
}
function scalar(e: Element): void {
    if (e.children.length || Object.keys(e.attrs).length) refuse('structure', `Expected unambiguous scalar ${e.name}.`, e.location);
}
function gpifTrack(track: Element, profile: string): TrackDiscovery {
    const info: TrackDiscovery = { sourceId: track.attrs.id, sourceLocation: { ...track.location, trackId: track.attrs.id }, instrument: { observations: [] }, metadataEligibility: { status: 'unknown', profile, findings: [] } };
    const name = child(track, 'Name', false); if (name) { scalar(name); if (name.text.length > 4096) refuse('metadata-size', 'Source track name exceeds compact inventory bounds.', name.location); info.sourceName = { value: name.text, sourceLocation: name.location }; }
    const ref = child(track, 'Instrument', false);
    if (ref) { if (ref.children.length || ref.text.trim() || Object.keys(ref.attrs).some(key => key !== 'ref')) refuse('structure', 'Ambiguous instrument reference.', ref.location); info.instrument.observations.push({ kind: 'ref', value: ref.attrs.ref ?? '', sourceLocation: ref.location, provenance: 'encoded' }); }
    const set = child(track, 'InstrumentSet', false), type = set && child(set, 'Type', false);
    if (type) { scalar(type); info.instrument.observations.push({ kind: 'family', value: type.text.trim(), sourceLocation: type.location, provenance: 'encoded' }); }
    const directMidi = child(track, 'GeneralMidi', false), sounds = child(track, 'Sounds', false);
    const soundList = sounds ? children(sounds, 'Sound') : [];
    if (directMidi && soundList.length) refuse('instrument-ambiguity', 'Multiple instrument-program encodings prevent useful inventory.', track.location);
    const programNodes = directMidi ? [child(directMidi, 'Program')!] : soundList.map(sound => child(child(sound, 'MIDI')!, 'Program')!);
    const programs = programNodes.map(node => {
        scalar(node); if (!/^\d{1,3}$/.test(node.text.trim()) || Number(node.text.trim()) > 127) refuse('number', 'Malformed MIDI program.', node.location);
        const program = Number(node.text.trim()); info.instrument.observations.push({ kind: 'midi-program', value: program, sourceLocation: node.location, provenance: 'encoded' }); return program;
    });
    const staves = child(track, 'Staves', false), properties = child(track, 'Properties', false);
    if (staves && properties) refuse('staff-ambiguity', 'Competing direct and grouped staff encodings prevent useful inventory.', track.location);
    const propertyGroups = properties ? [properties] : staves ? children(staves, 'Staff').map(staff => child(staff, 'Properties', false) ?? {...staff,children:[]}) : [];
    const tuningNodes: { node: Element; index: number }[] = [];
    const capoNodes: { node: Element; index: number }[] = [];
    for (const [index, group] of propertyGroups.entries()) {
        const names = new Set<string>();
        for (const property of children(group, 'Property')) {
            if (!property.attrs.name || names.has(property.attrs.name)) refuse('structure', 'Ambiguous staff property identity.', property.location); names.add(property.attrs.name);
            if (property.attrs.name === 'Tuning') tuningNodes.push({node:child(property, 'Pitches')!,index});
            if (property.attrs.name === 'CapoFret') capoNodes.push({node:child(property, 'Fret')!,index});
        }
    }
    info.staves = sourceStaves(track).map((staff, index) => ({ number: index + 1, sourceLocation: staff.location }));
    for (const {index,node} of tuningNodes) { scalar(node);
        const fields = node.text.trim().split(/\s+/);
        if (!fields.length || fields.length > 16 || fields.some(p => !/^\d{1,3}$/.test(p) || Number(p) > 127)) refuse('tuning', 'Malformed or oversized source tuning.', node.location);
        const tuning: TrackDiscovery['tuning'] = { pitches: fields.map(Number), order: 'low-to-high', stringCount: fields.length, sourceLocation: node.location, encodedOrder: 'low-to-high' };
        if (info.staves[index]) info.staves[index].tuning = tuning;
        if (tuningNodes.length === 1) info.tuning = tuning;
    }
    const program = programs[0]; // The first encoded sound is the initial palette default, matching source recovery; all programs remain observations.
    info.metadataEligibility = eligibility(program, info.tuning ?? info.staves[0]?.tuning, info.sourceLocation, profile, directMidi?.attrs.table === 'Percussion' ? 'percussion' : type?.text.trim() ?? ref?.attrs.ref);
    if (program !== undefined) { try { info.instrument.family = admittedFamily(directMidi?.attrs.table === 'Percussion' ? 'percussion' : type?.text.trim() ?? ref?.attrs.ref ?? '', program, info.sourceLocation); } catch {} }
    for (const {index,node} of capoNodes) { scalar(node);
        if (!/^-?\d{1,6}$/.test(node.text.trim()) || Number(node.text.trim()) < 0) {
            info.metadataEligibility.status = 'ineligible'; info.metadataEligibility.findings.push(finding('capo', 'Full capo fret must be a nonnegative encoded integer.', node.location));
        } else { const capo = { fret: Number(node.text.trim()), sourceLocation: { ...node.location, trackId: track.attrs.id } }; if (info.staves[index]) info.staves[index].capo = capo; if (capoNodes.length === 1) info.capo = capo; }
    }
    for (const [index, group] of propertyGroups.entries()) {
        try { readPartialCapo(new Map(children(group, 'Property').map(property => [property.attrs.name, property])), info.staves[index]?.tuning?.stringCount ?? 0); }
        catch (error) {
            if (!(error instanceof Refusal)) throw error;
            info.metadataEligibility.status = 'ineligible'; info.metadataEligibility.findings.push(finding(error.code,error.message,error.location));
        }
    }
    if (info.instrument.family && !isFrettedReference(type?.text.trim() ?? ref?.attrs.ref ?? '')) { delete info.tuning; delete info.capo; for (const staff of info.staves ?? []) { delete staff.tuning; delete staff.capo; } }
    return info;
}

/** Structural discovery is distinct from converting a selected musical graph. No raw graph is returned. */
export function inspectPortable(bytes: Uint8Array, readContainer: () => Map<string, Bytes>): InspectionResult {
    const report: ConversionResult['report'] = { schema: 'score-converter-report/0', inputSha256: sha256(bytes), adapter: 'alphatab-1.8.4-022a45c8+source-hook/1', profile: 'gp-family-inventory/0', requestedScope: 'all-tracks', findings: new BoundedFindings() };
    try {
        if (bytes.length > limits.inputBytes) refuse('input-size', 'Input exceeds8MiB.');
        const encoding = guitarProEncoding(bytes);
        let tracks: TrackDiscovery[];
        if (encoding === 'binary') {
            const source = readBinaryMetadata(bytes, report.findings); report.profile = 'gp3-5-binary-inventory/0';
            tracks = source.tracks.map(t => {
                const tuning: TrackDiscovery['tuning'] = { pitches: t.tuning.slice().reverse(), order: 'low-to-high', encodedOrder: 'high-to-low', stringCount: t.tuning.length, sourceLocation: t.tuningLocation };
                const info: TrackDiscovery = { sourceId: t.sourceId, sourceLocation: t.sourceLocation, sourceName: { value: t.name, sourceLocation: t.nameLocation }, instrument: { observations: [{ kind: 'midi-program', value: t.program, sourceLocation: t.programLocation, provenance: 'derived-from-encoded-channel' }] }, tuning, metadataEligibility: eligibility(t.program, tuning, t.sourceLocation, 'gp3-5-binary-bass/0', t.facts['track-flags'] & 1 ? 'percussion' : undefined, true) };
                info.instrument.family = midiFamily(t.program, !!(t.facts['track-flags'] & 1));
                const shortBanjo = !(t.facts['track-flags'] & 1) && !!(t.facts['track-flags'] & 4);
                if (shortBanjo) {
                    info.instrument.observations.push({kind:'ref',value:'banjo',sourceLocation:t.sourceLocation,provenance:'encoded'});
                    if (tuning.stringCount !== 5) { info.metadataEligibility.status='ineligible'; info.metadataEligibility.findings.push(finding('banjo-strings','Short-fifth-string banjo requires five encoded strings.',t.tuningLocation)); }
                }
                if (t.facts.capo < 0) {
                    info.metadataEligibility.status = 'ineligible'; info.metadataEligibility.findings.push(finding('capo', 'Full capo fret must be a nonnegative encoded integer.', t.capoLocation));
                } else info.capo = { fret: t.facts.capo, sourceLocation: t.capoLocation };
                if (source.version < 500 && t.facts['track-flags'] & 0x40 || t.facts['automatic-midi'] & ~7 || t.facts['automatic-accent'] > 5 || t.facts.humanize > 100) {
                    info.metadataEligibility.status = 'ineligible'; info.metadataEligibility.findings.push(finding('track-profile', 'Unknown track flag or invalid playback operand prevents metadata eligibility.', t.sourceLocation));
                }
                if (!shortBanjo && info.instrument.family && !['guitar','bass'].includes(info.instrument.family)) { delete info.tuning; delete info.capo; for (const staff of info.staves ?? []) { delete staff.tuning; delete staff.capo; } }
    return info;
            });
            report.findings.push({ disposition: 'preserved', code: 'binary-header', message: 'Encoded binary version/header is observed independently of metadata eligibility.', location: { member: 'input', byteOffset: 0, byteLength: 31 }, fact: { header: source.header, version: source.version } });
        } else {
            const gpx = encoding === 'gpx';
            const members = gpx ? new Map([...readGpx(bytes, false).members].map(([name, data]) => ['Content/' + name, data])) : readContainer();
            const root = parseXml(members.get('Content/score.gpif')!, gpx ? 'score.gpif' : 'Content/score.gpif').root;
            if (!gpx) admitDescriptors(members, root, report.findings);
            const version = value(root, 'GPVersion', false), constructed = version === '7.0' && value(root, 'GPRevision') === '0';
            const family = gpx && !constructed ? 6 : /^8(?:\.|$)/.test(version) ? 8 : 7;
            if (!constructed) validateGpifHeader(root, family, report.findings);
            const graph = discoverArrangementGraph(root);
            captureContainer(members, !constructed || gpx, [], false);
            report.profile = constructed ? 'constructed-gpif-inventory/0' : `gp${family}-inventory/0`;
            tracks = graph.order.map(id => gpifTrack(graph.tracks.get(id)!, constructed ? 'constructed-gp7-fretted/0' : `gp${family}-physical-bass/0`));
        }
        report.findings.push({ disposition: 'preserved', code: 'inspection-scope', message: 'Bounded container/header/definition/reference discovery succeeded. Track labels and metadata eligibility do not certify musical constructs; conversion revalidates selected source IDs. No output-part IDs or raw capture are returned.', location: { member: 'input' } });
        const result = { ok: true as const, report, tracks };
        jsonBytes(result, limits.reportBytes);
        return freeze(result);
    } catch (error) {
        const r = error instanceof Refusal ? error : new Refusal('invalid-input', 'Input failed bounded source discovery; no useful inventory is returned.');
        if (r.code === 'report-budget') report.findings = [];
        report.findings.push(finding(r.code, r.message, r.location));
        return freeze({ ok: false, report });
    }
}

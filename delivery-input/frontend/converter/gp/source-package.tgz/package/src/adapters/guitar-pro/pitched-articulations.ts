import type { MusicalNote } from '../../core/model.js';
import { symbolVocabulary } from '../../core/symbols.js';
import { refuse, type Finding } from '../../core/report.js';
import { child, integer, value, type Element } from './xml.js';
import { percussionNote, type SourcePercussion } from './percussion.js';
interface PitchedArticulation { source: Element['location']; name: string; heads?: string[]; technique?: string }
function structure(owner:Element,allowed:string[],repeated:string[]=[]):void {
    if(Object.keys(owner.attrs).length||owner.text.trim())refuse('articulation-profile','Malformed instrument articulation structure.',owner.location);
    const seen=new Set<string>();for(const field of owner.children){if(!allowed.includes(field.name)||seen.has(field.name)&&!repeated.includes(field.name))refuse('unknown-element','Unreviewed or duplicate instrument articulation field.',field.location);seen.add(field.name);}
}
function plain(owner:Element):void {if(Object.keys(owner.attrs).length||owner.children.length)refuse('unknown-element','Instrument articulation field must be plain source text.',owner.location);}
/** Pitched catalog entries decorate an independently recovered pitch; their MIDI mappings never replace that pitch. */
export function createPitchedArticulations(track:Element,findings:Finding[]) {
    const set=child(track,'InstrumentSet',false),catalog:PitchedArticulation[]=[];
    if(set){
        const elements=child(set,'Elements')!;structure(elements,['Element'],['Element']);
        for(const element of elements.children){
            structure(element,['Name','Type','SoundbankName','Articulations']);element.children.filter(e=>e.name!=='Articulations').forEach(plain);
            if(value(element,'Type')!=='pitched')refuse('articulation-profile','A pitched instrument must retain explicit pitched catalog elements.',element.location);
            const arts=child(element,'Articulations')!;structure(arts,['Articulation'],['Articulation']);
            for(const art of arts.children){
                structure(art,['Name','StaffLine','Noteheads','TechniquePlacement','TechniqueSymbol','InputMidiNumbers','OutputRSESound','OutputMidiNumber']);art.children.forEach(plain);
                if(catalog.length>=256)refuse('articulation-budget','Pitched articulation catalog exceeds256 entries.',art.location);
                const name=value(art,'Name',false),heads=child(art,'Noteheads',false),technique=value(art,'TechniqueSymbol',false);
                const names=heads?.text.trim().split(/\s+/);if(names&&(names.length!==3||names.some(n=>!/^notehead[A-Za-z0-9]{1,120}$/.test(n))))refuse('articulation-noteheads','Pitched articulation requires three canonical notehead names.',heads!.location);
                if(child(art,'StaffLine',false))integer(value(art,'StaffLine'),-32,48,art);
                if(child(art,'OutputMidiNumber',false))integer(value(art,'OutputMidiNumber'),0,127,art);
                const inputs=value(art,'InputMidiNumbers',false);if(inputs)for(const token of inputs.split(/\s+/))integer(token,0,127,art);
                const placement=value(art,'TechniquePlacement',false);if(placement&&!['inside','outside'].includes(placement))refuse('articulation-placement','Unknown source technique placement.',art.location);
                if(technique&&!/^[a-zA-Z][a-zA-Z0-9]{0,127}$/.test(technique))refuse('articulation-symbol','Malformed source technique glyph name.',art.location);
                catalog.push({source:art.location,name,...(names?{heads:names}:{}),...(technique?{technique}:{})});
                findings.push({disposition:'preserved',code:'pitched-articulation-source',message:'Pitched source catalog appearance is separate from actual note pitch. Literal catalog labels, placement and engine mappings remain auxiliary facts; selected source noteheads and established technique glyphs are projected on their actual notes.',location:art.location,fact:{index:catalog.length-1,fields:Object.fromEntries(art.children.map(c=>[c.name,c.text]))}});
            }
        }
        if(!catalog.length)refuse('articulation-profile','Explicit pitched catalog cannot be empty.',set.location);
        const patch=child(track,'NotationPatch',false);if(patch){
            structure(patch,['Name','LineCount','Elements']);patch.children.filter(c=>c.name!=='Elements').forEach(plain);
            if(child(patch,'LineCount',false)&&value(patch,'LineCount')!=='5')refuse('articulation-lines','Pitched notation patch requires five traditional staff lines.',patch.location);
            const elements=child(patch,'Elements')!;structure(elements,['Element'],['Element']);
            for(const element of elements.children){structure(element,['Name','Articulations']);plain(child(element,'Name')!);const arts=child(element,'Articulations')!;structure(arts,['Articulation'],['Articulation']);for(const art of arts.children){structure(art,['Name','StaffLine']);art.children.forEach(plain);integer(value(art,'StaffLine'),-32,48,art);findings.push({disposition:'preserved',code:'pitched-articulation-source',message:'Pitched notation-patch catalog coordinates remain auxiliary; authored written pitch and clef own pitched note placement.',location:art.location,fact:{element:value(element,'Name'),name:value(art,'Name'),staffLine:value(art,'StaffLine')}});}}
        }
    }
    return { apply(note:MusicalNote,raw:Element,type:string):void {
        const encoded=child(raw,'InstrumentArticulation',false);if(!encoded)return;
        const index=integer(encoded.text.trim(),0,255,encoded),art=catalog[index];
        if(!art)refuse('articulation-profile','Pitched note articulation must resolve within its actual source catalog.',encoded.location);
        const heads=art.heads??['noteheadBlack','noteheadHalf','noteheadWhole'];
        const technique=art.technique;
        const mapped=percussionNote({source:art.source,id:'visual',name:art.name,midi:0,line:0,heads,...(technique&&(['stringsUpBow','stringsDownBow','noteheadParenthesis'].includes(technique)||symbolVocabulary.has(technique))?{technique}:{})} as SourcePercussion,note,type);
        if(heads.some((head,i)=>head!==['noteheadBlack','noteheadHalf','noteheadWhole'][i]))for(const key of ['notehead','noteheadFilled','sourceNotehead','noteheadSmufl'] as const)Object.assign(note,{[key]:mapped[key]});
        if(mapped.articulations)note.articulations=[...(note.articulations??[]),...mapped.articulations];
        if(mapped.technical)note.technical=[...(note.technical??[]),...mapped.technical];
        if(mapped.symbols)note.symbols=[...(note.symbols??[]),...mapped.symbols];
        if(mapped.noteheadParentheses)note.noteheadParentheses=mapped.noteheadParentheses;
    }};
}

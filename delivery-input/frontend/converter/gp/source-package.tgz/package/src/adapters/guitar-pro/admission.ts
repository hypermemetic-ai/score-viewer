import { refuse, type Location } from '../../core/report.js';
export type InstrumentFamily = 'guitar' | 'bass' | 'keyboard' | 'vocal' | 'percussion' | 'other';
const refs: Record<string, InstrumentFamily> = {
    banjo: 'other',
    'e-bass4': 'bass', 'e-bass5': 'bass',
    bass: 'bass', 'electric-bass': 'bass', electricBass: 'bass', acousticBass: 'bass', fretlessBass: 'bass',
    'e-gtr6': 'guitar', 's-gtr7': 'guitar', 'n-gtr6': 'guitar',
    guitar: 'guitar', electricGuitar: 'guitar', steelGuitar: 'guitar', nylonGuitar: 'guitar', acousticGuitar: 'guitar', 's-gtr6': 'guitar',
    'a-piano-gs': 'keyboard', 'a-piano-ss': 'keyboard', 'a-piano': 'keyboard',
    'piano-gs': 'keyboard', 'k-piano': 'keyboard', 'k-piano-gs': 'keyboard', PianoGrandStaff: 'keyboard', acousticPiano: 'keyboard', electricPiano: 'keyboard', piano: 'keyboard', keyboard: 'keyboard', organ: 'keyboard', harpsichord: 'keyboard',
    voice: 'vocal', vocals: 'vocal', choir: 'vocal', vocal: 'vocal', drumKit: 'percussion', percussion: 'percussion'
};
export const observedFamily = (ref: string): InstrumentFamily | undefined => Object.hasOwn(refs, ref) ? refs[ref] : undefined;
export const isFrettedReference = (ref: string): boolean => ['guitar','bass'].includes(observedFamily(ref) ?? '') || ref === 'banjo';
export function midiFamily(program: number, percussion = false): InstrumentFamily {
    return percussion ? 'percussion' : program >= 24 && program <= 31 ? 'guitar' : program >= 32 && program <= 39 ? 'bass' : program <= 7 || program >= 16 && program <= 23 ? 'keyboard' : program >= 52 && program <= 54 ? 'vocal' : 'other';
}
/** Explicit source family/catalog identity is separate from an editor label or a tuning-shaped input grid. */
export function admittedFamily(ref: string, program: number | undefined, location: Location): InstrumentFamily {
    if (!Number.isInteger(program) || program! < 0 || program! > 127 || !/^[A-Za-z0-9_.-]{1,128}$/.test(ref)) return refuse('instrument-profile', 'Instrument admission requires an encoded catalog identity and bounded MIDI program.', location);
    const family = observedFamily(ref), encoded = midiFamily(program!);
    if (!family && (encoded === 'guitar' || encoded === 'bass') && ref !== `gm-program-${program}`) return refuse('instrument-profile', 'A fretted MIDI sound does not establish an unknown source instrument family.', location);
    return family ?? (ref === `gm-program-${program}` && !['guitar','bass'].includes(encoded) ? encoded : 'other');
}

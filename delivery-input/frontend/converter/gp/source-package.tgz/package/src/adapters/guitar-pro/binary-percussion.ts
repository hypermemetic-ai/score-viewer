import type { Track } from '../../../third_party/alphatab/src/model/Track.js';
import type { Score } from '../../../third_party/alphatab/src/model/Score.js';
import type { Note } from '../../../third_party/alphatab/src/model/Note.js';
import type { Beat } from '../../../third_party/alphatab/src/model/Beat.js';
import type { MusicalEvent, MusicalPart, MusicalNote } from '../../core/model.js';
import { add, equal, mul, q } from '../../core/rational.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import { nativePercussion, percussionNote, percussionInstrument, type SourcePercussion } from './percussion.js';
import {binaryEmptySlot} from './binary-empty-slots.js';
import {emptyAnnotationAnchor} from './binary-empty-annotations.js';
import {binaryPercussionTechniques,percussionInstruction} from './binary-percussion-techniques.js';
import { binaryTechniques } from './techniques.js';
import type { OccurrenceCapture } from './recover.js';
import type { BinaryStructureFrame as Frame } from './binary-structure.js';
import {binaryMeasureExtent} from './binary-structure.js';
const names:Record<number,string>={27:'High Q',28:'Slap',29:'Scratch Push',30:'Scratch Pull',31:'Sticks',32:'Square Click',33:'Metronome Click',34:'Metronome Bell',82:'Shaker',83:'Jingle Bell',84:'Bell Tree',85:'Castanets',86:'Mute Surdo',87:'Open Surdo'};
const types:Record<number,string>={1:'whole',2:'half',4:'quarter',8:'eighth',16:'16th',32:'32nd',64:'64th'};
export interface BinaryDrumExpectation { note:Note; fact:MusicalNote; event:MusicalEvent; raw:number; articulation:number; unknownDead?:boolean }
interface Context {version:number; beats:Map<Beat,Frame>;notes:Map<Note,Frame>;masters:Frame[];fieldLocations:Map<string,Location>;sourceEvents:Map<Beat,MusicalEvent>;emptyEvents:Map<Beat,MusicalEvent>;effects:Map<Beat,Frame>;chords:Map<Beat,Frame>}

/** GP3–5 drum frets are MIDI identities; the serialized string slot is not a physical string. */
export function binaryPercussion(track:Track,score:Score,frame:Frame,context:Context,findings:Finding[]):{part:MusicalPart;expected:BinaryDrumExpectation[]} {
    const id=String(track.index),instruments=new Map<number,SourcePercussion>(),expected:BinaryDrumExpectation[]=[],previous=new Map<string,{note:MusicalNote;articulation:number;end:ReturnType<typeof q>}>();
    let absolute=q(0);
    const define=(number:number,source:Location):SourcePercussion=>{
        if(number<27||number>87)refuse('percussion-identity','Legacy drum number is outside the documented source table.',source);
        let fact=instruments.get(number);if(fact)return fact;
        fact=names[number]?{source,id:`gp-legacy-drum:${id}:${number}`,name:names[number],midi:number,line:4,heads:['noteheadBlack','noteheadHalf','noteheadWhole']}:{...nativePercussion(number,source,id),midi:number};
        instruments.set(number,fact);return fact;
    };
    const measures=track.staves[0].bars.map((bar,index)=>{
        const master=score.masterBars[index],source={...context.masters[index].source,trackId:id};
        if(master.timeSignatureNumerator<1||master.timeSignatureNumerator>255||master.timeSignatureDenominator<1||master.timeSignatureDenominator>128||master.timeSignatureDenominator&(master.timeSignatureDenominator-1))refuse('meter','Invalid binary percussion meter.',source);
        const span=q(master.timeSignatureNumerator*4,master.timeSignatureDenominator);
        const voices=bar.voices.map((voice,vi)=>{
            let position=q(0);
            const encoded=voice.beats.filter(beat=>context.beats.has(beat));if(encoded.length&&encoded.every(beat=>context.beats.get(beat)!.facts['beat-status']===0)){if(encoded.some(beat=>beat.notes.length))refuse('empty-voice','Empty source drum voice contains attacks.',source);for(const beat of encoded){const event=emptyAnnotationAnchor(context.beats.get(beat)!.source,beat.text);context.emptyEvents.set(beat,event);context.sourceEvents.set(beat,event);}return [];}
            return voice.beats.filter(beat=>context.beats.has(beat)).flatMap(beat=>{
                const raw=context.beats.get(beat)!,denominator=2**(raw.facts['duration-exponent']+2),actual=raw.facts.tuplet,normal=actual===3?2:actual&&actual<=7?4:8,dots=raw.facts['beat-flags']&1?1:0;
                const duration=mul(mul(q(4,denominator),q(dots?3:1,dots?2:1)),q(actual?normal:1,actual??1));
                const event:MusicalEvent={source:raw.source,id:raw.source.path!,start:position,duration,type:types[denominator],dots,...(raw.facts['beat-status']===0?{printObject:false}:{}),...(actual?{tuplet:{actual,normal}}:{}),notes:[],fullMeasureRest:!beat.notes.length&&equal(duration,span),...(beat.text?{text:beat.text}:{})};
                const dynamics=new Set<number>(),graces=new Map<string,MusicalEvent>();
                for(const note of beat.notes) {
                    const source=context.notes.get(note)!,facts=source.facts,slot=`${vi}:${facts['source-string']}`,prior=previous.get(slot),tie=facts['note-type']===2;
                    const locate=(name:string)=>context.fieldLocations.get(source.source.path+'/'+name)??source.source;
                    const dynamic=facts['note-dynamic'];if(dynamic!==undefined&&(facts['note-flags']&0x20))dynamics.add(dynamic);
                    const ownDynamic=(fact:MusicalNote)=>{if(dynamic!==undefined)fact.dynamic={source:locate('note-dynamic'),value:['','ppp','pp','p','mp','mf','f','ff','fff'][dynamic]};};
                    const slotGrace=(fret:number|undefined,dead:boolean,graceSource:Location):MusicalNote=>{
                        if(fret===undefined)return {source:graceSource,id:graceSource.id!,kind:'dead',written:{step:'B',alter:0,octave:4,midi:71,origin:'inferred'},sounding:null,tieStart:false,tieStop:false};
                        const identity=define(fret,graceSource),fact=percussionNote(identity,{source:graceSource,id:graceSource.id!,tieStart:false,tieStop:false},event.type);if(dead){fact.sourceDead={source:graceSource,value:true};fact.notehead='x';}return fact;
                    };
                    const unknownDead=facts['note-type']===3&&facts['note-fret']===-1;
                    if(!(facts['note-flags']&0x20)||unknownDead) {
                        if(unknownDead){const fact=slotGrace(undefined,true,source.source);fact.sourceDead={source:locate('note-type'),value:true};binaryTechniques(facts,source.source,fact,context.version,locate);delete fact.bend;ownDynamic(fact);event.notes.push(fact);event.fullMeasureRest=false;expected.push({note,fact,event,raw:-1,articulation:-1,unknownDead:true});findings.push({disposition:'inferred',code:'binary-unfretted-dead-placement',message:'A source dead drum stroke omits its drum identity. A middle-line X head preserves the attack with derived placement and no fabricated instrument or pitch.',location:source.source});}
                        const extra=binaryEmptySlot(source,event,context.version,locate,findings,slotGrace,unknownDead,(value,source)=>define(value,source).name);for(const grace of extra)graces.set(grace.id,grace);continue;
                    }
                    const articulation=tie?prior?.articulation:facts['note-fret'];
                    if(articulation===undefined||tie&&!equal(prior!.end,add(absolute,position)))refuse('tie-conflict','Drum tie needs a contiguous matching source input slot.',source.source);
                    const identity=define(articulation!,source.source),fact=percussionNote(identity,{source:source.source,id:source.source.id!,tieStart:false,tieStop:tie},event.type);
                    ownDynamic(fact);if(tie)prior!.note.tieStart=true;
                    const slide=binaryTechniques(facts,source.source,fact,context.version,locate);
                    binaryPercussionTechniques(facts,fact,event,identity.name,context.version,slide,locate,findings,context.effects.get(beat)?.facts['beat-effect-flags']);
                    if(facts['trill-fret']!==undefined){const speed=facts['trill-speed'];if(![1,2,3].includes(speed))refuse('trill','Unknown encoded trill period.',locate('trill-speed'));const target=define(facts['trill-fret'],locate('trill-fret'));fact.trill={source:locate('trill-fret'),speed:['','16th','32nd','64th'][speed]};percussionInstruction(event,locate('trill-fret'),`${identity.name}: trill toward ${target.name} (${fact.trill.speed})`,{noteSource:fact.source,target:target.midi,speed},findings);}
                    const marks=facts['tremolo-marks'];
                    if(marks!==undefined) {if(marks<1||marks>3||event.ornaments?.some(mark=>mark.kind==='tremolo'&&mark.strokes!==marks))refuse('tremolo','Conflicting or unknown drum tremolo value.',source.source);event.ornaments=[{source:locate('tremolo-marks'),kind:'tremolo',type:'single',strokes:marks}];}
                    if(facts['grace-fret']!==undefined) {
                        const code=facts['grace-duration'],flags=facts['grace-flags']??0,dynamic=facts['grace-dynamic'];
                        if(![1,2,3].includes(code)||flags&~3||![0,1,2,3].includes(facts['grace-transition'])||dynamic<1||dynamic>8)refuse('percussion-grace','Unsupported drum grace parameter or pitched transition.',locate('grace-fret'));
                        const graceIdentity=define(facts['grace-fret'],locate('grace-fret')),before=context.version<500||!(flags&2),key=`${before}:${code}:${dynamic}`,graceSource={...locate('grace-fret'),id:fact.id+':grace'};
                        let grace=graces.get(key);
                        if(!grace){grace={source:graceSource,id:event.id+':grace:'+graces.size,start:position,duration:q(0),writtenDuration:q(4,2**(7-code)),type:types[2**(7-code)],dots:0,notes:[],fullMeasureRest:false,grace:{source:graceSource,before,slash:before,index:0,hostId:event.id},dynamic:['','PPP','PP','P','MP','MF','F','FF','FFF'][dynamic]};graces.set(key,grace);}
                        const graceNote=percussionNote(graceIdentity,{source:graceSource,id:graceSource.id,tieStart:false,tieStop:false},grace.type);
                        if(facts['grace-transition']){const transition=facts['grace-transition'];percussionInstruction(grace,locate('grace-transition'),`${graceIdentity.name}: ${['','slide','bend','hammer-on / pull-off'][transition]} to ${identity.name}`,{source:graceSource,target:fact.source,transition},findings);}
                        if(flags&1){graceNote.sourceDead={source:locate('grace-flags'),value:true};graceNote.notehead='x';}grace.notes.push(graceNote);
                    }
                    if(facts['note-type']===3){fact.sourceDead={source:locate('note-type'),value:true};fact.notehead='x';}
                    if(names[articulation!])event.text=[event.text,identity.name].filter(Boolean).join(' — ');
                    if(facts['note-dynamic']!==undefined)dynamics.add(facts['note-dynamic']);
                    event.notes.push(fact);expected.push({note,fact,event,raw:facts['note-fret'],articulation:articulation!});
                    previous.set(slot,{note:fact,articulation:articulation!,end:add(absolute,add(position,duration))});
                }
                if(dynamics.size===1){const mark=['','PPP','PP','P','MP','MF','F','FF','FFF'][[...dynamics][0]];if(event.dynamic&&event.dynamic!==mark)refuse('dynamic','Conflicting empty-slot and drum attack dynamics.',raw.source);event.dynamic=mark;for(const note of event.notes)delete note.dynamic;}
                context.sourceEvents.set(beat,event);position=add(position,duration);const graceEvents=[...graces.values()];if(graceEvents.length>1){graceEvents.forEach((grace,index)=>grace.voiceId=`${vi+1}:grace-projection:${index+1}`);findings.push({disposition:'inferred',code:'grace-parallel-projection',message:'Different simultaneous drum grace values use derived serialization lanes at the common source host clock.',location:event.source});}return [...graceEvents,event];
            });
        });
        const totals=voices.filter(voice=>voice.length).map(voice=>voice.reduce((sum,event)=>add(sum,event.duration),q(0)));
        if(!totals.length){voices[0]=[{source,id:`${id}:${index}:empty-measure`,start:q(0),duration:span,type:'whole',dots:0,notes:[],fullMeasureRest:true}];totals.push(span);findings.push({disposition:'inferred',code:'binary-empty-measure-rest',message:'An empty source drum measure projects one standard measure rest.',location:source});}
        const {pickup,duration}=binaryMeasureExtent(totals,span,index,track.staves[0].bars.length,source,findings);
        absolute=add(absolute,duration);
        return {source,time:{beats:master.timeSignatureNumerator,unit:master.timeSignatureDenominator},key:{fifths:0,mode:'major'},clef:'PERC',pickup,duration,voices,repeatStart:master.isRepeatStart,repeatEnd:master.repeatCount};
    });
    findings.push({disposition:'inferred',code:'binary-percussion-notation',message:'Original legacy MIDI drum numbers select their documented identities without modern-reader substitutions. Standard staff positions and heads use qualified conventional notation; legacy GS identities without established historical glyphs use middle-line notes with explicit instrument labels.',location:frame.source,fact:{identities:[...instruments].map(([raw,fact])=>({raw,name:fact.name,midi:fact.midi,derivedLine:fact.line}))}});
    return {part:{source:frame.source,id,name:track.name,instrument:'percussion',midiProgram:track.playbackInfo.program,transposeOctaves:0,staves:[{source:frame.source,number:1,kind:'percussion',clef:'PERC',lines:5}],percussionInstruments:[...instruments.values()].map(percussionInstrument),measures},expected};
}

export function reconcileBinaryDrums(expected:BinaryDrumExpectation[]):OccurrenceCapture[] {
    return expected.map(({note,fact,event,raw,articulation,unknownDead})=>{
        if(unknownDead){if(!note.isDead||note.isTieDestination||note.fret!==-1)refuse('reader-reconciliation','Reader disagrees with source dead drum stroke.',fact.source);return {kind:'dead',source:fact.source,rhythmId:event.id+'/rhythm',noteId:fact.id,before:{rawFret:-1,tieDestination:false},after:{rawFret:-1,tieDestination:false,playbackTicks:note.beat.playbackDuration}};}

        // The borrowed reader's documented GS aliases are observed, not adopted as source facts.
        const alias=({27:42,28:60,29:29,30:30,32:31} as Record<number,number>)[articulation]??articulation;
        if(note.percussionArticulation!==alias||note.isTieDestination!==fact.tieStop)refuse('reader-reconciliation','Drum reader disagrees with encoded identity and its known normalization boundary.',fact.source);
        return {kind:'unpitched',source:fact.source,rhythmId:event.id+'/rhythm',noteId:fact.id,before:{articulation:raw,tieDestination:fact.tieStop},after:{articulation:note.percussionArticulation,tieDestination:note.isTieDestination,playbackTicks:note.beat.playbackDuration}};
    });
}

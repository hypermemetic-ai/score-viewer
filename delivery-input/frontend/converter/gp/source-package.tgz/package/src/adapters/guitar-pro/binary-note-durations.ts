import type {MusicalEvent,MusicalNote,MusicalPart,MusicalRelation} from '../../core/model.js';
import {add,compare,equal,mul,q,type Rational} from '../../core/rational.js';
import {refuse,type Finding,type Location} from '../../core/report.js';
import {binaryCurveSegment} from './binary-curve-segments.js';
import {limits} from './limits.js';

interface Frame {source:Location;facts:Record<string,number>}
interface Written {duration:Rational;type:string;dots:number;tuplet?:{actual:number;normal:number}}
const types:Record<number,string>={1:'whole',2:'half',4:'quarter',8:'eighth',16:'16th',32:'32nd',64:'64th'};
export function binaryNoteValue(frame:Frame,event:MusicalEvent):Written {
    const exponent=frame.facts['independent-duration-exponent'],actual=frame.facts['independent-duration-tuplet'],dots=frame.facts['note-flags']&2?1:0;
    if(exponent===undefined)return {duration:mul(event.duration,event.dots?q(1):q(3,2)),type:event.type,dots:1,...(event.tuplet?{tuplet:event.tuplet}:{})};
    if(exponent< -2||exponent>4||![0,1,3,5,6,7,9,10,11,12,13].includes(actual))refuse('binary-note-duration','Unknown independent source note duration or tuplet.',frame.source);
    const denominator=2**(exponent+2),normal=actual===3?2:actual<=7?4:8,tuplet=actual>1?{actual,normal}:undefined;
    return {duration:mul(q(4*(dots?3:1),denominator*(dots?2:1)),q(tuplet?.normal??1,tuplet?.actual??1)),type:types[denominator],dots,...(tuplet?{tuplet}:{})};
}
function notation(duration:Rational,original:Written):Written {
    if(equal(duration,original.duration))return original;
    for(const denominator of [1,2,4,8,16,32,64])for(const dots of [0,1,2,3]) {
        const value=mul(q(4*(2**(dots+1)-1),denominator*2**dots),q(original.tuplet?.normal??1,original.tuplet?.actual??1));
        if(equal(value,duration))return {duration,type:types[denominator],dots,...(original.tuplet?{tuplet:original.tuplet}:{})};
    }
    // Exact unusual boundary fragment, explicitly derived notation; never rounded.
    return {duration,type:'quarter',dots:0,tuplet:{actual:duration.d,normal:duration.n}};
}

/** GP3/4 own-note durations predate voice slots. Lanes are a standard serialization, not source voices. */
export function binaryNoteDurations(parts:MusicalPart[],frames:Frame[],relations:MusicalRelation[],findings:Finding[]):{source:Location;name:string;value:string}[] {
    const metadata:{source:Location;name:string;value:string}[]=[];let projectedEvents=0;
    const eventsByNote=new Map(parts.flatMap(part=>part.measures.flatMap(measure=>measure.voices.flatMap(voice=>voice.flatMap(event=>event.notes.map(note=>[note.id,event] as const))))));
    const durations=new Map(frames.filter(frame=>eventsByNote.has(frame.source.id!)&&(frame.facts['independent-duration-exponent']!==undefined||frame.facts['note-flags']&2)).map(original=>{const independent=original.facts['independent-duration-exponent']!==undefined,frame={...original,source:{...original.source,path:original.source.path+(independent?'/independent-duration':'/note-flags'),byteOffset:original.source.byteOffset!+(independent?2:0),byteLength:independent?2:1}};return [frame.source.id!,{frame,written:binaryNoteValue(frame,eventsByNote.get(frame.source.id!)!)}] as const;}));
    if(!durations.size)return metadata;
    for(const part of parts) {
        if(!part.measures.some(measure=>measure.voices.some(voice=>voice.some(event=>event.notes.some(note=>durations.has(note.id))))))continue;
        const offsets:Rational[]=[];let total=q(0);for(const measure of part.measures){offsets.push(total);total=add(total,measure.duration);}
        const original=part.measures.map(measure=>measure.voices),output=part.measures.map(()=>[] as MusicalEvent[][]),noteOwners=new Map<string,{event:MusicalEvent;measure:number;last:MusicalEvent;lastMeasure:number}>(),eventOwners=new Map<string,MusicalEvent>();
        let nextLane=0;
        const originalRelease=new Map<string,{event:MusicalEvent;measure:number;voice:number}>();
        for(let vi=0;vi<Math.max(...original.map(voices=>voices.length));vi++){
            const previous=new Map<number|string,{release:Rational;note:MusicalNote}>();
            for(let mi=0;mi<original.length;mi++)for(const event of original[mi][vi]??[])if(!event.grace)for(const note of event.notes){
                const key=note.string??(note.kind==='unpitched'?note.unpitched.instrumentId??note.id:note.id),start=add(offsets[mi],event.start),duration=durations.get(note.id)?.written.duration??event.duration,prior=previous.get(key);
                if(note.tieStop&&note.tieSound?.stop!==false&&(!prior||!equal(prior.release,start)))refuse('tie-conflict','Independent note duration contradicts the contiguous release required by its source tie destination.',note.source);
                previous.set(key,{release:add(start,duration),note});originalRelease.set(note.id,{event,measure:mi,voice:vi});
            }
        }
        for(let vi=0;vi<Math.max(...original.map(voices=>voices.length));vi++) {
            const lanes:{index:number;end:Rational}[]=[];
            const events=original.flatMap((voices,mi)=>(voices[vi]??[]).filter(event=>!event.grace).map(event=>({event,mi})));
            for(const {event,mi} of events) {
                const groups=new Map<string,{notes:MusicalNote[];written:Written;source?:Location}>();
                for(const note of event.notes) {
                    const fact=durations.get(note.id),value=fact?.written??event,key=`${value.duration.n}/${value.duration.d}:${value.type}:${value.dots}:${value.tuplet?.actual??0}:${value.tuplet?.normal??0}`;
                    let group=groups.get(key);if(!group){group={notes:[],written:value,source:fact?.frame.source};groups.set(key,group);}group.notes.push(note);
                    if(fact)findings.push({disposition:'preserved',code:'binary-independent-note-duration',message:'Legacy source note duration is retained independently from the containing beat spacing. Separate standard serialization lanes are derived only where duration overlap requires them.',location:fact.frame.source,fact:{exponent:fact.frame.facts['independent-duration-exponent'],tuplet:fact.frame.facts['independent-duration-tuplet'],dots:value.dots,noteDuration:value.duration,beatDuration:event.duration,sourceBeat:event.source}});
                }
                if(!groups.size)groups.set('rest',{notes:[],written:event});
                const whammyOwner=event.whammy?[...groups.values()].find(group=>equal(group.written.duration,event.duration)):undefined;
                if(event.whammy&&!whammyOwner){
                    const ratio=(value:Rational)=>value.d===1?String(value.n):`${value.n}/${value.d}`;
                    const text=`Whammy bar over ${ratio(event.duration)} quarter-note beats: `+event.whammy.points.map(point=>`${ratio(point.semitones)} semitones at ${ratio(mul(point.offset,q(100)))}%${point.vibrato?.value?` (${point.vibrato.speed?point.vibrato.speed+' ':''}vibrato)`: ''}`).join('; ');
                    (part.measures[mi].directions??=[]).push({source:event.whammy.source,kind:'words',position:event.start,staff:event.staff??1,text});
                    metadata.push({source:event.whammy.source,name:`source-whammy-independent-beat:${part.id}:${event.id}`,value:JSON.stringify({curve:event.whammy,measure:mi,start:event.start,duration:event.duration})});
                    findings.push({disposition:'inferred',code:'binary-whammy-duration-projection',message:'The beat-owned bar curve has no note with the same independent duration. Standard bend/with-bar timing is note-relative, so a precise ordinary words instruction retains the source beat span and control points; exact curve facts remain auxiliary. No note or rest is invented.',location:event.whammy.source,fact:{beatDuration:event.duration,points:event.whammy.points}});
                }
                let ordinal=0;
                for(const group of groups.values()) {
                    const absolute=add(offsets[mi],event.start),release=add(absolute,group.written.duration);
                    if(compare(release,total)>0)refuse('binary-note-duration','Independent note release exceeds the encoded score extent.',group.source??event.source);
                    let lane=lanes.find(lane=>compare(lane.end,absolute)<=0);if(!lane){lane={index:nextLane++,end:q(0)};lanes.push(lane);if(nextLane*part.measures.length>limits.occurrences)refuse('occurrence-budget','Independent note serialization exceeds the bounded voice-grid budget.',event.source);}lane.end=release;
                    let current=mi,start=event.start,remaining=group.written.duration,segment=0,first:MusicalEvent|undefined,last:MusicalEvent|undefined;
                    while(remaining.n>0) {
                        if(++projectedEvents>limits.occurrences)refuse('occurrence-budget','Independent note continuation expansion exceeds the bounded occurrence budget.',event.source);
                        const available=add(part.measures[current].duration,mul(start,q(-1))),span=compare(remaining,available)<=0?remaining:available;
                        if(span.n<=0)refuse('binary-note-duration','Independent note has no positive serialization span.',event.source);
                        const continues=compare(remaining,span)>0,value=notation(span,group.written),id=ordinal===0&&segment===0?event.id:`${event.id}:duration:${ordinal}:${segment}`;
                        const notes=group.notes.map(note=>segment===0&&!continues?note:{...note,tieNotations:note.tieNotations?.filter(tie=>tie.type==='stop'?segment===0:!continues),id:segment===0?note.id:`${note.id}:duration:${segment}`,tieStop:segment>0||note.tieStop,tieStart:continues||note.tieStart,tieSound:note.tieSound?{reason:note.tieSound.reason,...(!continues&&note.tieSound.start===false?{start:false as const}:{}),...(segment===0&&note.tieSound.stop===false?{stop:false as const}:{})}:undefined,...(segment>0?{articulations:undefined,technical:undefined,fingerings:undefined,gestures:undefined,bend:undefined,bendTransition:undefined,trill:undefined,slides:undefined,hopoStart:undefined,hopoStop:undefined,hopoNotations:undefined}:{})});
                        if(continues||segment)for(let ni=0;ni<notes.length;ni++)if(group.notes[ni].bend){
                            const elapsed=add(group.written.duration,mul(remaining,q(-1))),inverse=q(group.written.duration.d,group.written.duration.n);
                            notes[ni].bend=binaryCurveSegment(group.notes[ni].bend!,mul(elapsed,inverse),mul(add(elapsed,span),inverse));
                        }
                        const piece:MusicalEvent={...event,...value,id,start,voiceId:`${vi+1}:duration:${lane.index+1}`,notes,fullMeasureRest:!notes.length&&event.fullMeasureRest&&equal(span,part.measures[current].duration),tuplet:value.tuplet,beams:undefined,tupletBoundary:undefined,...(ordinal||segment?{text:undefined,dynamic:undefined,lyrics:undefined,whammy:undefined,arpeggio:undefined,ornaments:undefined,slurs:undefined}:{}),whammy:segment===0&&group===whammyOwner?event.whammy:undefined};
                        if(last)for(let ni=0;ni<notes.length;ni++)if(group.notes[ni].tieNotations) {
                            const prior=last.notes[ni],note=notes[ni],relationId=`binary-duration-tie:${note.id}`;
                            (prior.tieNotations??=[]).push({type:'start',relationId});(note.tieNotations??=[]).unshift({type:'stop',relationId});
                            relations.push({kind:'tie',id:relationId,source:note.source,start:{partId:part.id,measure:current-1,position:last.start,staff:last.staff??1,voiceId:last.voiceId,eventId:last.id,noteId:prior.id},end:{partId:part.id,measure:current,position:piece.start,staff:piece.staff??1,voiceId:piece.voiceId,eventId:piece.id,noteId:note.id}});
                        }
                        (output[current][lane.index]??=[]).push(piece);first??=piece;last=piece;
                        remaining=add(remaining,mul(span,q(-1)));if(remaining.n){current++;start=q(0);segment++;}
                    }
                    if(!ordinal)eventOwners.set(event.id,first!);
                    for(const note of group.notes)noteOwners.set(note.id,{event:first!,measure:mi,last:last!,lastMeasure:current});
                    if(segment)for(let measure=mi;measure<=current;measure++)for(const piece of output[measure][lane.index]??[])for(const note of piece.notes)if(note.bend?.sourceCurve&&group.notes.some(original=>note.id===original.id||note.id.startsWith(original.id+':duration:'))){
                        note.bend.sourceEndpoints={start:{partId:part.id,measure:mi,position:event.start,staff:event.staff??1,voiceId:first!.voiceId,eventId:first!.id},end:{partId:part.id,measure:current,position:add(last!.start,last!.duration),staff:event.staff??1,voiceId:last!.voiceId}};
                    }
                    if(segment&&group.notes.some(note=>note.bend))findings.push({disposition:'inferred',code:'binary-duration-bend-segments',message:'Exact linear interpolation divides a source note bend at source bar boundaries. Original control points and the complete note span remain separate from the derived fragment points.',location:group.source??event.source});
                    if(segment)findings.push({disposition:'inferred',code:'binary-note-duration-continuation',message:'An independently notated note crosses source bar boundaries. Exact continuation pieces and ties are calculated without adding an attack or changing its source release.',location:group.source??event.source,fact:{duration:group.written.duration,pieces:segment+1}});
                    ordinal++;
                }
            }
        }
        for(let mi=0;mi<original.length;mi++)for(const voice of original[mi])for(const event of voice.filter(event=>event.grace)) {
            const groups=new Map<MusicalEvent,MusicalNote[]>();for(const note of event.notes){const owner=noteOwners.get(note.id.replace(/:grace$/,''))?.event??eventOwners.get(event.grace!.hostId);if(!owner)refuse('binary-note-duration','Grace host disappeared during duration projection.',event.source);const notes=groups.get(owner!)??[];notes.push(note);groups.set(owner!,notes);}
            let ordinal=0;for(const [owner,notes] of groups){const lane=output[mi].findIndex(events=>events?.includes(owner));const projected={...event,id:ordinal++?`${event.id}:duration:${ordinal}`:event.id,voiceId:owner.voiceId,notes,grace:{...event.grace!,hostId:owner.id}};(output[mi][lane]??=[]).push(projected);eventOwners.set(event.id,projected);for(const note of notes)noteOwners.set(note.id,{event:projected,measure:mi,last:projected,lastMeasure:mi});}
        }
        for(const relation of relations)if(relation.start.partId===part.id&&relation.kind==='text-line'&&/^gp-(?:palm-mute|let-ring):/.test(relation.id)&&relation.start.noteId){
            const first=originalRelease.get(relation.start.noteId),note=first?.event.notes.find(note=>note.id===relation.start.noteId);
            const last=first&&[...originalRelease.entries()].find(([id,owner])=>owner.voice===first.voice&&owner.measure===relation.end.measure&&equal(add(owner.event.start,owner.event.duration),relation.end.position)&&owner.event.notes.find(candidate=>candidate.id===id)?.string===note?.string);
            const owner=last&&noteOwners.get(last[0]);if(owner){relation.end.measure=owner.lastMeasure;relation.end.position=add(owner.last.start,owner.last.duration);relation.end.voiceId=owner.last.voiceId;}
        }
        for(const relation of relations)for(const endpoint of [relation.start,relation.end])if(endpoint.partId===part.id) {
            const owner=endpoint.noteId?noteOwners.get(endpoint.noteId)?.event:endpoint.eventId?eventOwners.get(endpoint.eventId):undefined;
            if(owner){endpoint.eventId=owner.id;endpoint.voiceId=owner.voiceId;}
            if(relation.kind==='tie'&&relation.id.startsWith('binary-tie:')&&endpoint===relation.start&&endpoint.noteId){const pieces=noteOwners.get(endpoint.noteId);if(pieces&&pieces.last!==pieces.event){const lastNote=pieces.last.notes.find(note=>note.id.startsWith(endpoint.noteId!+':duration:'))!;endpoint.noteId=lastNote.id;endpoint.eventId=pieces.last.id;endpoint.voiceId=pieces.last.voiceId;endpoint.measure=pieces.lastMeasure;endpoint.position=pieces.last.start;}}
        }
        for(let mi=0;mi<output.length;mi++)part.measures[mi].voices=Array.from({length:nextLane},(_,lane)=>(output[mi][lane]??[]).sort((a,b)=>compare(a.start,b.start)||Number(!a.grace)-Number(!b.grace)));
        findings.push({disposition:'inferred',code:'binary-note-duration-voices',message:'Legacy independent note values are serialized into nonoverlapping standard voices. These lanes do not claim source voice or performing-hand identity; source beat clocks and raw duration operands remain separately retained.',location:part.source,fact:{lanes:nextLane}});
    }
    return metadata;
}

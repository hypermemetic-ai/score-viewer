import { child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { equal } from '../../core/rational.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import type { GlyphFact, MusicalPart, SourceColor } from '../../core/model.js';
import { nativeLimits } from './capture-core.js';

type Sign = { source:Location; count:1|2|4; printObject?:boolean; sourceColor?:SourceColor; small?:{source:Location;value:boolean}; fontSize?:GlyphFact['fontSize'] };
type Group = Sign & { first:number; from:number; node:Element; signMeasure:number };
const rhythmic = new Set(['Chord','Rest','Tuplet','endTuplet','Beam','location']);
/** Repeat signs supply source music, not new authored attacks. Cloned source
 * locations still point to the actual pattern; model projection facts identify
 * the repeat instruction and its target measure independently. */
export function expandNativeMeasureRepeats(measures: readonly Element[], context:{
    readSign(sign:Element,voice:number):Sign;
    projectSign?(sign:Sign,node:Element,part:MusicalPart,staff:number,measure:number):void;
    consume(node:Element):void;
    use(node:Element):void;
    findings:Finding[];
}): {measures:Element[];apply(part:MusicalPart,staff:number):void} {
    const groups=new Map<number,Group>(), counts=measures.map(m=>{
        const field=child(m,'measureRepeatCount');if(!field)return 0;
        if(field.children.length||Object.keys(field.attrs).length)refuse('native-measure-repeat','Repeat group ordinal must be a plain source integer.',field.location);
        const value=integer(field.text.trim(),0,4,field.location);context.consume(field);return value;
    });
    for(const [index,measure] of measures.entries())for(const [voiceIndex,voice] of children(measure,'voice').entries())for(const node of voice.children){
        if(!['MeasureRepeat','RepeatMeasure'].includes(node.name))continue;
        const sign=context.readSign(node,voiceIndex),ordinal=counts[index]||1,first=index-ordinal+1;
        if(first<sign.count||first+sign.count>measures.length)refuse('native-measure-repeat-pattern','Repeat requires its complete preceding pattern and complete current group.',node.location);
        for(let offset=0;offset<sign.count;offset++){
            const target=first+offset;
            if(sign.count>1&&counts[target]!==offset+1||sign.count===1&&counts[target]>1)refuse('native-measure-repeat-group','Repeat group source ordinals do not establish one complete pattern.',node.location);
            if(groups.has(target))refuse('native-measure-repeat-overlap','Two repeat signs claim the same source measure.',node.location);
            groups.set(target,{...sign,first,from:target-sign.count,node,signMeasure:index});
        }
    }
    for(const [index,count] of counts.entries())if(count&&!groups.has(index))refuse('native-measure-repeat-group','Repeat group ordinal has no matching source sign.',measures[index].location);
    if(!groups.size)return {measures:[...measures],apply:()=>{}};
    let copied=0;
    const copy=(node:Element):Element=>{
        if(++copied>nativeLimits.components)refuse('native-measure-repeat-budget','Expanded repeat source exceeds the bounded node budget.',node.location);
        return {...node,attrs:{...node.attrs},location:{...node.location},children:node.children.map(copy)};
    };
    const recovered:Element[]=[];
    for(const [index,measure] of measures.entries()){
        const group=groups.get(index);if(!group){recovered.push(measure);continue;}
        context.use(measure);
        const pattern=recovered[group.from],sourceVoices=children(pattern,'voice'),targetVoices=children(measure,'voice'),voices:Element[]=[];
        if(!sourceVoices.some(v=>v.children.some(node=>node.name==='Chord'||node.name==='Rest')))refuse('native-measure-repeat-pattern','Repeated source measure has no established rhythmic pattern.',group.source);
        for(let slot=0;slot<Math.max(sourceVoices.length,targetVoices.length);slot++){
            const source=sourceVoices[slot],target=targetVoices[slot],nodes=target?.children??[],markers=nodes.filter(n=>['MeasureRepeat','RepeatMeasure','Rest'].includes(n.name));
            if(nodes.some(n=>['Chord','Tuplet','endTuplet','Beam','location'].includes(n.name))||markers.length>1)refuse('native-measure-repeat-conflict','Repeat target contains competing authored rhythmic content.',target?.location??group.source);
            for(const rest of markers.filter(n=>n.name==='Rest')){
                if(child(rest,'durationType')?.text.trim()!=='measure'||rest.children.some(n=>!['durationType','duration','visible','track','autoplace','eid'].includes(n.name)))refuse('native-measure-repeat-conflict','Repeat group rest must be an ordinary whole-measure placeholder without competing annotations.',rest.location);
                for(const field of rest.children){if(field.children.length||Object.keys(field.attrs).length)refuse('native-measure-repeat-conflict','Repeat placeholder has non-scalar fields.',field.location);
                    if(['visible','autoplace'].includes(field.name))integer(field.text.trim(),0,1,field.location);
                    if(field.name==='track')integer(field.text.trim(),0,1023,field.location);
                    if(field.name==='duration'&&!/^0*[1-9]\d*\/0*[1-9]\d*$/.test(field.text.trim()))refuse('native-measure-repeat-conflict','Repeat placeholder duration must retain a source fraction.',field.location);
                }
                context.consume(rest);
            }
            if(target)context.use(target);
            const markerIndex=nodes.findIndex(n=>markers.includes(n)),before=markerIndex<0?nodes:nodes.slice(0,markerIndex),after=markerIndex<0?[]:nodes.slice(markerIndex+1);
            const music=(source?.children??[]).filter(n=>rhythmic.has(n.name)).map(copy);
            if(!target&&!source)continue;
            voices.push({...target??source!,children:[...before,...music,...after]});
        }
        recovered.push({...measure,children:[...measure.children.filter(n=>n.name!=='voice'),...voices]});
        context.findings.push({disposition:'inferred',code:'native-measure-repeat-expansion',location:group.source,message:'The explicit native repeat sign reuses its preceding source pattern. Standard MusicXML includes the required performed music and measure-repeat style; original pattern locations and derived target ownership remain separate.',fact:{sourceMeasure:group.from+1,targetMeasure:index+1,count:group.count}});
    }
    return {measures:recovered,apply(part,staff){
        const signs=new Map<Element,Group>();
        for(const group of groups.values())if(!signs.has(group.node)){context.projectSign?.(group,group.node,part,staff,group.signMeasure);signs.set(group.node,group);}
        for(const group of groups.values())group.fontSize=signs.get(group.node)!.fontSize;
        let prior:Group|undefined;
        for(const [index,measure] of part.measures.entries()){
            const group=groups.get(index);
            if(group){
                const original=part.measures[group.from];
                if(!original||!equal(original.duration,measure.duration))refuse('native-measure-repeat-meter','Repeated music cannot acquire a different source measure extent.',group.source);
                for(let slot=(staff-1)*4;slot<staff*4;slot++)for(const event of measure.voices[slot]??[])event.measureRepeatProjection={source:group.source,sourceMeasure:group.from+1};
            }
            if(prior?.node!==group?.node){
                if(prior)(measure.measureRepeats??=[]).push({source:group?.source??measure.source,staff,type:'stop',count:prior.count});
                if(group)(measure.measureRepeats??=[]).push({source:group.source,staff,type:'start',count:group.count,slashes:group.count,...(group.printObject!==undefined?{printObject:group.printObject}:{}),...(group.sourceColor?{sourceColor:group.sourceColor}:{}),...(group.small?{small:group.small}:{}),...(group.fontSize?{fontSize:group.fontSize}:{})});
            }
            prior=group;
        }
    }};
}

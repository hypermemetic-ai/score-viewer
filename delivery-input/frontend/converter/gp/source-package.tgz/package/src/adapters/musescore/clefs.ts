import { standardClef, type StandardClef } from '../../core/clefs.js';
import { refuse, type Finding, type Location } from '../../core/report.js';

// Musical register/placement facts independently qualified against ClefInfo
// and serialized TConv tokens, native 3.6.2 and 4.7.5. No font/code payload.
const nativeTokens=new Set(['G','G15mb','G8vb','G8va','G15ma','G8vbo','G8vbp','G1','C1','C2','C3','C4','C5','C_19C','C1_F18C','C3_F18C','C4_F18C','C1_F20C','C3_F20C','C4_F20C','F','F15mb','F8vb','F8va','F15ma','F3','F5','F_F18C','F_19C','PERC','PERC2','TAB','TAB4','TAB2','TAB4_SERIF','C4_8VB','G8vbc']);
const accidentalLines:readonly(readonly number[])[]=[
    [4,0,3,-1,2,5,1,1,5,2,6,3,7,4],
    [5,1,4,0,3,-1,2,2,6,3,7,4,8,5],
    [6,2,5,1,4,0,3,3,0,4,1,5,2,6],
    [0,3,-1,2,5,1,4,4,1,5,2,6,3,7],
    [1,4,0,3,6,2,5,5,2,6,3,7,4,8],
    [2,5,1,4,7,3,6,6,3,7,4,8,5,9],
    [3,6,2,5,1,4,0,0,4,1,5,2,6,3],
];
export interface NativeClefInfo extends StandardClef {pitchOffset:number;nativeLine:number;accidentalLines:readonly number[]}
export function nativeClefInfo(token:string,nativeVersion='4.70'):NativeClefInfo|undefined {
    // Serialized tokens remain exact, not enum spellings or guessed aliases.
    const canonical=token;
    if(!nativeTokens.has(canonical)||Number(nativeVersion)<4&&['C4_8VB','G8vbc'].includes(canonical))return undefined;
    const standard=standardClef(canonical)!;
    const pitchOffset=standard.line!==undefined?({G:49,F:41,C:45}[standard.sign as 'G'|'F'|'C']-2*standard.line+7*(standard.octaveChange??0)):standard.sign==='TAB'&&Number(nativeVersion)<4?0:45;
    return {...standard,pitchOffset,nativeLine:standard.line??(standard.sign==='TAB'?5:2),accidentalLines:accidentalLines[standard.line!==undefined?(pitchOffset%7+7)%7:3]};
}
export function qualifyNativeClef(token:string,source:Location,findings:Finding[],nativeVersion:string):string {
    const info=nativeClefInfo(token,nativeVersion);if(!info)return refuse('native-clef','Unrecognized native serialized clef.',source);
    if(info.appearanceVariant&&token!=='G8vbp')findings.push({disposition:'preserved',code:'native-clef-shape-projection',location:source,
        message:'Standard clef sign, line and octave preserve the source pitch meaning. MusicXML clef has no canonical-glyph override; the exact native glyph selector remains in source facts and standard auxiliary metadata.',
        fact:{token,glyph:info.sourceGlyph,standard:{sign:info.sign,line:info.line,octaveChange:info.octaveChange??0},classification:'standard-format-limit'}});
    return token;
}

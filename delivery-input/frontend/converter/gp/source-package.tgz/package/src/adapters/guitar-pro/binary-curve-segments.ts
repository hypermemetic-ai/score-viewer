import type {BendFact} from '../../core/model.js';
import {add,compare,equal,mul,q,type Rational} from '../../core/rational.js';
import {refuse} from '../../core/report.js';
const subtract=(a:Rational,b:Rational)=>add(a,q(-b.n,b.d));
const divide=(a:Rational,b:Rational)=>mul(a,q(b.d,b.n));
/** Derived linear segment; original source points are retained separately and never relabelled. */
export function binaryCurveSegment(curve:BendFact,start:Rational,end:Rational):BendFact {
    if(compare(start,q(0))<0||compare(end,q(1))>0||compare(start,end)>=0||!curve.points.length)refuse('binary-curve-segment','Invalid exact curve segment.',curve.source);
    const original=curve.points,points=original[0].offset.n===0?original:[{source:curve.source,offset:q(0),semitones:q(0)},...original];
    const at=(offset:Rational):BendFact['points'][number]=>{
        const exact=points.filter(point=>equal(point.offset,offset)).at(-1);if(exact)return exact;
        const after=points.findIndex(point=>compare(point.offset,offset)>0);
        if(after<0)return {source:curve.source,offset,semitones:points.at(-1)!.semitones};
        const left=points[after-1],right=points[after];if(!left)refuse('binary-curve-segment','Curve lacks a qualified initial base.',curve.source);
        const fraction=divide(subtract(offset,left.offset),subtract(right.offset,left.offset));
        return {source:curve.source,offset,semitones:add(left.semitones,mul(subtract(right.semitones,left.semitones),fraction))};
    };
    const selected=[at(start),...points.filter(point=>compare(point.offset,start)>0&&compare(point.offset,end)<0),at(end)],span=subtract(end,start);
    return {...curve,points:selected.map(point=>({...point,offset:divide(subtract(point.offset,start),span)})),sourceCurve:{source:curve.source,points:original,segment:{start,end},origin:'derived-duration-segment'}};
}

import { child, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { add, compare, q, type Rational } from '../../core/rational.js';
import { refuse } from '../../core/report.js';
import type { BendFact, MusicalNote, SourceColor } from '../../core/model.js';

export interface NativeModernBend {
    labels?: BendFact['labels'];
    source: Element['location']; type: NonNullable<BendFact['sourceBendType']>['value'];
    start: Rational; end: Rational; target?: Rational; amount?: Rational;
    slack?: { source: Element['location']; value: boolean };
    vibrato?: { source: Element['location']; value: number };
    holdMode?: { source: Element['location']; value: 0 | 1 | 2 };
    hold?: { source: Element['location']; printObject?: boolean; lineType?: 'solid' | 'dashed' | 'dotted'; sourceColor?: SourceColor };
}
export function readModernBend(element: Element, get: (e: Element, field: string, required?: boolean) => string): NativeModernBend {
    const encoded = get(element, 'guitarBendType', true), index = integer(encoded, 0, 7, element.location);
    const type = (['bend', 'pre-bend', 'grace-bend', 'slight-bend', 'dive', 'pre-dive', 'dip', 'scoop'] as const)[index];
    const time = (name: string, fallback?: Rational): Rational | undefined => {
        const value = get(element, name); if (!value) return fallback;
        if (!/^(?:0(?:\.\d{1,8})?|1(?:\.0{1,8})?)$/.test(value)) refuse('native-bend-clock', 'Modern bend timing requires an exact normalized source decimal.', child(element, name)!.location);
        const scale = 10 ** (value.split('.')[1]?.length ?? 0); return q(Math.round(Number(value) * scale), scale);
    };
    const start = time('bendStartTimeFactor', q(0))!, end = time('bendEndTimeFactor', type === 'dip' ? q(1, 2) : type === 'grace-bend' || type === 'scoop' ? q(1, 4) : q(1))!;
    const target = time('bendTargetTimeFactor', type === 'dip' ? q(1, 4) : undefined);
    if (compare(start, end) >= 0 || target && (compare(start, target) >= 0 || compare(target, end) >= 0)) refuse('native-bend-clock', 'Modern bend factors must retain their ordered source interval.', element.location);
    const amount = get(element, 'guitarBendAmount'), slack=get(element,'guitarDiveIsSlack'), vibrato=get(element,'guitarDipTremoloLine'), hold=get(element,'bendShowHoldLine');
    return { source: element.location, type, start, end,
        ...(slack?{slack:{source:child(element,'guitarDiveIsSlack')!.location,value:integer(slack,0,1,element.location)===1}}:{}),
        ...(vibrato?{vibrato:{source:child(element,'guitarDipTremoloLine')!.location,value:integer(vibrato,-1,3,element.location)}}:{}),
        ...(hold?{holdMode:{source:child(element,'bendShowHoldLine')!.location,value:integer(hold,0,2,element.location) as 0|1|2}}:{}), ...(target ? { target } : {}), ...(amount ? { amount: q(integer(amount, -96, 96, element.location), 2) } : type === 'dip' ? { amount: q(-1) } : {}) };
}
/** Native labels quantize tuning to quarter tones; the original tuning remains separate. */
export function modernBendPitchDifference(start: MusicalNote, end: MusicalNote): Rational {
    if (start.kind !== 'pitched' || end.kind !== 'pitched') return refuse('native-bend-pitch', 'A native bend requires actual pitched source notes.', start.source);
    const quarter = (note: MusicalNote) => {
        const value = note.performance?.tuning?.value ?? 0;
        if(!Number.isFinite(value)) refuse('native-bend-pitch','A native bend requires bounded source tuning.',note.source);
        return Math.sign(value)*Math.floor(Math.abs(value)/50+0.5);
    };
    return q(2 * (end.sounding!.midi - start.sounding!.midi) + quarter(end) - quarter(start), 2);
}
/** Native derived bend labels use the two explicitly connected note pitches and quarter-tone offsets. */
export function resolveModernBend(shape: NativeModernBend, start: MusicalNote, end: MusicalNote, initial?: BendFact['initialState'], deltaOverride?: Rational): BendFact {
    const amount = deltaOverride ?? (shape.type==='dip'?shape.amount:undefined) ?? (shape.type === 'slight-bend' ? q(1, 2) : shape.type === 'scoop' ? q(-1) : modernBendPitchDifference(start,end));
    if (!amount.n) refuse('native-bend-pitch', 'A zero-pitch native bend does not establish a performer bend.', shape.source);
    const point = (offset: Rational, semitones: Rational) => ({ source: shape.source, offset, semitones });
    const pre = shape.type === 'pre-bend' || shape.type === 'pre-dive' || shape.type === 'scoop';
    const baseline=initial?.semitones??q(0), displaced=add(baseline,amount);
    const points = shape.type==='scoop' ? [point(q(0),amount),point(shape.end,q(0))] : pre ? [point(q(0), amount), point(shape.end, amount)] : [point(shape.start, baseline), point(shape.target ?? shape.end, displaced), ...(shape.target ? [point(shape.end, baseline)] : [])];
    return { source: shape.source, sourceBendType: { source: shape.source, value: shape.type }, points, ...(!pre && initial?{initialState:initial}:{}),
        ...(['dive', 'pre-dive', 'dip', 'scoop'].includes(shape.type) ? { withBar: { source: shape.source } } : {}) };
}

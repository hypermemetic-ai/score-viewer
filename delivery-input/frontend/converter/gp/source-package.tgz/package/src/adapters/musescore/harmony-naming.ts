import { child, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { refuse } from '../../core/report.js';
import type { ChordHarmony } from '../../core/model.js';

type Spelling = 'standard' | 'german' | 'germanPure' | 'solfeggio' | 'french';
const aliases: Record<string, Spelling> = { useStandardNoteNames: 'standard', useGermanNoteNames: 'german', useFullGermanNoteNames: 'germanPure', useSolfeggioNoteNames: 'solfeggio', useFrenchNoteNames: 'french' };
const defaults: Record<string, boolean> = { useStandardNoteNames: true, useGermanNoteNames: false, useFullGermanNoteNames: false, useSolfeggioNoteNames: false, useFrenchNoteNames: false, automaticCapitalization: true, lowerCaseMinorChords: false, lowerCaseBassNotes: false, allCapsNoteNames: false };

// Only the source caption's lexical quality controls capitalization. An XML
// catalog kind is tonal export information and may deliberately disagree.
function minorCaption(caption: string): boolean {
    const prefix = caption.split(/[1-9()[\],/\\ ]/, 1)[0];
    const lower = prefix.toLowerCase();
    if (['tristan', 'omit', 'type'].includes(lower)) return false;
    const tokens = ['major', 'minor', 'maj', 'min', 'dim', 'aug', 'ma', 'mi', 'm', '-', '=', 'o', '+', 't', '^'];
    let quality = tokens.filter(token => lower.startsWith(token)).sort((a, b) => b.length - a.length)[0] ?? lower;
    if (lower.startsWith('madd')) quality = 'm';
    if (quality === 'm' && prefix.startsWith('M')) quality = 'major';
    const minor = ['m', 'mi', 'min', 'minor', '-', '=', 'dim', 'o', '0'].includes(quality);
    // A literal diminished modifier also changes the source parser quality.
    return minor || /(?:^|[0-9(), /\\])(dim|o)(?=$|[0-9(), /\\])/.test(caption);
}

export function createHarmonyNaming(styles: readonly Element[], nativeVersion: string, consume: (element: Element) => unknown) {
    const settings = { ...defaults }, fields: NonNullable<ChordHarmony['sourceNoteNaming']>['fields'] = [];
    let spelling: Spelling = 'standard';
    const modern = Number(nativeVersion) >= 4.6;
    for (const style of styles) {
        const seen = new Set<string>();
        for (const field of style.children) {
            if (!(field.name in defaults) && field.name !== 'chordSymbolSpelling') continue;
            if (seen.has(field.name) || field.children.length || Object.keys(field.attrs).length) refuse('native-harmony-naming', 'Harmony naming style requires one plain value per source style.', field.location);
            seen.add(field.name); consume(field);
            const value = field.text.trim(); fields.push({ source: field.location, name: field.name, value });
            if (field.name === 'chordSymbolSpelling') {
                if (!modern || !['standard', 'german', 'germanPure', 'solfeggio', 'french'].includes(value)) refuse('native-harmony-naming', 'Unknown or version-incompatible harmony spelling style.', field.location);
                spelling = value as Spelling;
            } else {
                settings[field.name] = integer(value, 0, 1, field.location) === 1;
                if (modern && settings[field.name] && aliases[field.name]) spelling = aliases[field.name];
            }
        }
    }
    if (!modern) spelling = Object.entries(aliases).find(([name]) => settings[name])?.[1] ?? 'standard';
    return (owner: Element, root: ChordHarmony['root'], bass: ChordHarmony['bass'], caption: string, rootCase: number, bassCase: number) => {
        const sourceFields = [...fields];
        for (const name of ['rootCase', 'bassCase', 'baseCase']) { const field = child(owner, name); if (field) sourceFields.push({ source: field.location, name, value: field.text }); }
        if (settings.automaticCapitalization) {
            rootCase = settings.lowerCaseMinorChords && minorCaption(caption) ? 1 : settings.allCapsNoteNames ? 2 : 0;
            bassCase = settings.lowerCaseBassNotes ? 1 : settings.allCapsNoteNames ? 2 : 0;
        }
        const tone = (pitch: NonNullable<ChordHarmony['root']>, casing: number) => {
            let base = pitch.step;
            if (spelling === 'german' || spelling === 'germanPure') base = pitch.step === 'B' ? pitch.alter === -1 ? 'B' : 'H' : pitch.step;
            if (spelling === 'solfeggio' || spelling === 'french') base = ({ C: 'Do', D: spelling === 'french' ? 'Ré' : 'Re', E: 'Mi', F: 'Fa', G: 'Sol', A: 'La', B: 'Si' } as Record<string, string>)[pitch.step];
            if (casing === 1) base = base.toLowerCase(); else if (casing === 2) base = base.toUpperCase();
            let accidental = pitch.alter < 0 ? 'b'.repeat(-pitch.alter) : '#'.repeat(pitch.alter);
            if (spelling === 'germanPure') {
                accidental = pitch.alter > 0 ? 'is'.repeat(pitch.alter) : pitch.alter === -1 ? pitch.step === 'B' ? '' : ['A', 'E'].includes(pitch.step) ? 's' : 'es' : pitch.alter === -2 ? pitch.step === 'A' ? 'sas' : pitch.step === 'E' ? 'ses' : 'eses' : '';
            }
            const text = spelling === 'germanPure' ? base + accidental : base;
            return { label: base + accidental, text: text === pitch.step ? undefined : text, hideAlter: spelling === 'germanPure' && pitch.alter !== 0 };
        };
        return { root: root ? tone(root, rootCase) : undefined, bass: bass ? tone(bass, bassCase) : undefined, sourceNoteNaming: { nativeVersion, spelling, rootCase, bassCase, fields: sourceFields } };
    };
}

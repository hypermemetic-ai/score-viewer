import type { MusicalEvent, MusicalPart, StaffFact } from '../../core/model.js';
import { child, type SourceElement } from '../../core/source-xml.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import type { NativeBudget } from './budget.js';
import { nativeTextStylePrefix } from './text-style.js';

/** Native TAB duration signs describe written rhythm; they are never tremolo or tempo. */
export function recoverNativeTabRhythm(parts: MusicalPart[], nodes: ReadonlyMap<string, SourceElement>, budget: Pick<NativeBudget,'add'>): Finding[] {
    const findings: Finding[]=[];
    for(const part of parts) {
        const regularPredecessors=new Map<string,{event:MusicalEvent;measure:number}>(),lastRegular=new Map<number,{event:MusicalEvent;measure:number}>();
        for(const [mi,measure] of part.measures.entries())for(const [vi,voice] of measure.voices.entries())for(const event of voice??[])if(!event.grace){const previous=lastRegular.get(vi);if(previous)regularPredecessors.set(event.id,previous);lastRegular.set(vi,{event,measure:mi});}
        const prior=new Map<number,{event:MusicalEvent;measure:number;tuplet:string}>(), activeBeamStem=new Map<number,'up'|'down'>();
        for(const [mi,measure] of part.measures.entries()) {
            const staves=measure.staffs??part.staves??[];
            const hidden=staves.filter(staff=>staff.notation?.showBarlines?.value===false);
            if(hidden.length && (hidden.length!==staves.length || measure.repeatEnd))findings.push({disposition:'omitted',code:'native-staff-barline-limit',location:hidden[0].notation!.showBarlines!.source,message:hidden.length!==staves.length
                ? 'MusicXML barlines are part-wide and have no staff selector. The mixed source staff visibility remains located; shared repeat and boundary meaning is preserved.'
                : 'The source hides the entire end-repeat drawing. MusicXML preserves its repeat and transparent end-bar style, but repeat dots have no independent visibility or color attribute.'});
            // Native TAB hasVoices deliberately considers the whole measure,
            // unlike ordinary-staff overlap tests (Measure::hasVoices).
            const extraVoices=new Set<number>();
            for(const [index,voice] of measure.voices.entries()) if(index%4!==0 && voice.some(event=>{
                if(event.grace||event.printObject===false)return false;
                if(event.notes.length)return event.notes.some(note=>note.printObject!==false)||event.sourceStemVisibility?.value!==false&&!!event.stem;
                return !nodes.get(event.source.path!)?.children.some(field=>field.name==='gap'&&field.text.trim()==='1');
            }))extraVoices.add(Math.floor(index/4)+1);
            for(const [vi,voice] of measure.voices.entries())for(const event of voice??[]) {
                delete event.tabRhythm;
                const logicalStaff=Math.floor(vi/4)+1,staff=staves.find(staff=>staff.number===logicalStaff),tab=staff?.tablature;
                if(staff?.kind!=='tablature'||!tab)continue;
                const raw=nodes.get(event.source.path!),noStem=!!raw&&child(raw,'noStem')?.text.trim()==='1';
                const displayedType=event.crossMeasureValue?.role==='start'?event.crossMeasureValue.type:event.type,displayedDots=event.crossMeasureValue?.role==='continuation'?0:event.crossMeasureValue?.role==='start'?event.crossMeasureValue.dots:event.dots;
                const fact:NonNullable<MusicalEvent['tabRhythm']>={source:tab.source,origin:'native-tab-policy'};
                if(event.notes.length) {
                    if(staff.notation?.stemless?.value || noStem || displayedType==='half'&&tab.minimStyle.value===0)fact.stem='none';
                    else if(!tab.stemsThrough.value) {
                        fact.stem=extraVoices.has(logicalStaff)?(vi%2===0?'up':'down'):tab.stemsDown.value?'down':'up';
                        const primary=event.beams?.find(beam=>beam.number===1)?.value;
                        if(primary==='begin')activeBeamStem.set(vi,fact.stem);
                        else if(primary&&activeBeamStem.has(vi))fact.stem=activeBeamStem.get(vi)!;
                        if(!primary||primary==='end')activeBeamStem.delete(vi);
                    }
                    if(displayedType==='half'&&tab.minimStyle.value===2&&fact.stem!=='none')fact.halfNoteSlashes=true;
                }
                const tuplet=raw?.children.filter(node=>node.name==='Tuplet').map(node=>`${mi}:${node.text.trim()}`).join('/')??'';
                const previous=prior.get(vi),mode=event.beam?.mode??'auto';
                if(event.notes.length && vi%4===0 && tab.durations.value && !noStem && (!event.grace||mode!=='auto')) {
                    const priorType=previous?.event.crossMeasureValue?.role==='start'?previous.event.crossMeasureValue.type:previous?.event.type,priorDots=previous?.event.crossMeasureValue?.role==='continuation'?0:previous?.event.crossMeasureValue?.role==='start'?previous.event.crossMeasureValue.dots:previous?.event.dots;
                    const changed=!previous||mode!=='auto'||priorType!==displayedType||priorDots!==displayedDots||previous.tuplet!==tuplet||!previous.event.notes.length;
                    const repeat=!changed&&(tab.symbolRepeat.value===3 || tab.symbolRepeat.value!==0 && previous.measure!==mi);
                    if(changed||repeat) {
                        fact.durationSymbol={source:tab.durations.source,type:displayedType,dots:displayedDots,repeat,form:['begin','mid','end'].includes(mode)?'grid':'ordinary',
                            ...(repeat&&tab.symbolRepeat.value===1?{condition:'system-start' as const}:{}),...(tab.durationFontName?{fontName:tab.durationFontName.value}:{}),...(tab.durationFontSize?{fontSize:tab.durationFontSize.value}:{})};
                        if(fact.durationSymbol.form==='grid') {
                            const zeroBeamType=tab.durationFontName?.value==='MuseScore Tab Italian'?'whole':'quarter';
                            const types=['maxima','long','breve','whole','half','quarter','eighth','16th','32nd','64th','128th','256th','512th','1024th'];
                            const lines=mode==='begin'?0:Math.max(0,types.indexOf(displayedType)-types.indexOf(zeroBeamType));
                            const priorGrid=regularPredecessors.get(event.grace?.hostId??event.id);
                            fact.durationSymbol.grid={source:event.beam?.source??event.source,zeroBeamType,lines,...(lines&&priorGrid?{previous:{partId:part.id,measure:priorGrid.measure,position:priorGrid.event.start,staff:logicalStaff,voiceId:priorGrid.event.voiceId??String(vi+1),eventId:priorGrid.event.id}}:{})};
                            if(lines&&priorGrid)budget.add('relations',lines,event.source);
                        }
                        if(fact.durationSymbol.condition)findings.push({disposition:'omitted',code:'native-tab-system-duration-limit',location:tab.symbolRepeat.source,message:'The native repeated TAB duration sign is conditional on a future system break. MusicXML retains the located condition and an explicit measure-start duration sign; no original pagination is invented.'});
                    }
                }
                // Grid lines are separate from ordinary note beams. A source
                // staff can request both; only stem suppression removes beams.
                if(fact.stem==='none')delete event.beams;
                if(fact.stem||fact.halfNoteSlashes||fact.durationSymbol){event.tabRhythm=fact;budget.add('markings',1,event.source);}
                // Grace chords are separate ornaments, not the previous ordinary chord/rest.
                if(!event.grace)prior.set(vi,{event,measure:mi,tuplet});
            }
        }
    }
    return findings;
}

/** Built-in preset selectors are names, not arbitrary font-family strings. */
export function nativeTabFretFont(staff: StaffFact, nodes:ReadonlyMap<string,SourceElement>, context:{version:string;styles:readonly (SourceElement|undefined)[];findings:Finding[]}): NonNullable<import('../../core/model.js').MusicalNote['tabFretFont']>|undefined {
    const tab=staff.tablature;if(!tab)return undefined;
    const raw=nodes.get(tab.source.path!);if(!raw)return undefined;
    let family:string|undefined,size:number|undefined,style:number|undefined,source=tab.source;
    let sourceFields:{family?:Location;size?:Location;style?:Location}={};
    const styleFields=new Map<string,SourceElement>();for(const scope of context.styles)for(const field of scope?.children??[])styleFields.set(field.name,field);
    for(const field of raw.children) {
        if(field.name==='fretFontName'||field.name==='fretPresetIdx') {
            const presets=['MuseScore Tab Sans','MuseScore Tab Serif','MuseScore Tab Renaiss','MuseScore Phalèse','MuseScore Bonneuil-de Visée','MuseScore Bonneuil-Gaultier','MuseScore Dowland','MuseScore Lute Didactic'];
            const selected=field.name==='fretPresetIdx'?Number(field.text):presets.indexOf(field.text==='MuseScore Tab Late Renaiss'?'MuseScore Phalèse':field.text),index=selected<0||selected>=presets.length?0:selected;
            // Historic fonts use a private character encoding. Standard physical
            // fret numbers/letters remain the rendering authority for those fonts.
            family=index===0?'FreeSans':index===1?'FreeSerif':undefined;if(Number(context.version)>=4.6){size=index===0||index===1?9:10;style=undefined;delete sourceFields.style;}source=field.location;sourceFields={...sourceFields,family:field.location,...(Number(context.version)>=4.6?{size:field.location}:{})};
            if(index>1)context.findings.push({disposition:'excluded-by-scope',code:'native-tab-font-glyph-design',location:field.location,message:'The source historical fret font selector is retained with physical fret values and numeric/letter notation. Exact privately encoded glyph shapes and font metrics are typography, not different frets; no native font payload is redistributed.'});
        } else if(field.name==='fretFontSize'){size=Number(field.text);source=field.location;sourceFields.size=field.location;}
        else if(field.name==='fretTextStyle'){
            const prefix=nativeTextStylePrefix(field.text,context.version);
            if(!prefix){family=undefined;size=undefined;style=undefined;context.findings.push({disposition:'omitted',code:'native-tab-font-style-binding',location:field.location,message:'This native fret text-style selector needs a qualified property binding; its literal selector remains retained without inventing a default typeface.'});continue;}
            const face=styleFields.get(prefix+'FontFace'),point=styleFields.get(prefix+'FontSize'),emphasis=styleFields.get(prefix+'FontStyle');
            for(const value of [face,point,emphasis])if(value&&(value.children.length||Object.keys(value.attrs).length))refuse('native-tab-font','TAB text-style font properties must be scalars.',value.location);
            family=face?.text??(prefix==='tabFretNumber'?'FreeSans':undefined);size=point?Number(point.text):prefix==='tabFretNumber'?9:undefined;style=emphasis?Number(emphasis.text):0;source=field.location;sourceFields={family:face?.location??field.location,size:point?.location??field.location,style:emphasis?.location??field.location};
            if(!Number.isInteger(style)||style<0||style>15)refuse('native-tab-font','TAB font emphasis requires a known mask.',emphasis?.location??source);
            if(style&12)context.findings.push({disposition:'preserved',code:'native-tab-fret-emphasis-projection',location:emphasis?.location??source,message:'The source fret emphasis uses formatted standard words at its musical clock and string row, with the physical fret retained transparently. No duplicate visible fret or new note is added.'});
        }
    }
    if(size!==undefined&&(!Number.isFinite(size)||size<=0||size>10000))refuse('native-tab-font','TAB fret font needs a positive point size.',source);
    return family||size||style?{source,sourceFields,...(family?{family}:{}),...(size?{size}:{}),...(style!==undefined?{style}:{})}:undefined;
}

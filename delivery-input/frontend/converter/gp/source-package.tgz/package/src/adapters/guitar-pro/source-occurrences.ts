import { type Element } from './xml.js';
import { discoverArrangementGraph, sourceIds } from './arrangements.js';
import { refuse, type Finding } from '../../core/report.js';
/** A source definition may recur; borrowed mutable Bar/Voice instances require distinct occurrence owners. */
export function materializeStaffOccurrences(root: Element, findings: Finding[]): Element {
    const graph = discoverArrangementGraph(root);
    if(graph.slots.length!==1)refuse('occurrence-scope','Occurrence materialization requires one selected physical staff.',root.location);
    const bars=new Map(graph.bars),voices=new Map(graph.voices),seenBars=new Set<string>(),seenVoices=new Set<string>();
    const nextIds=new Map<Map<string,Element>,number>();
    const allocate=(map:Map<string,Element>):string=>{
        let candidate=nextIds.get(map)??0;while(map.has(String(candidate)))candidate++;
        if(candidate>999999)refuse('identity-budget','Source occurrence expansion exceeds bounded definition identities.',root.location);
        nextIds.set(map,candidate+1);return String(candidate);
    };
    const masters=graph.masterBars.children.map(master=>{
        const rawBarId=sourceIds(master,'Bars')[0],rawBar=graph.bars.get(rawBarId)!;
        const barId=seenBars.has(rawBarId)?allocate(bars):rawBarId;seenBars.add(rawBarId);
        if(barId!==rawBarId)bars.set(barId,{...rawBar,attrs:{...rawBar.attrs,id:barId}});
        const rawSlots=sourceIds(rawBar,'Voices');
        if(new Set(rawSlots.filter(id=>id!=='-1')).size!==rawSlots.filter(id=>id!=='-1').length)refuse('voice-profile','One source voice cannot occupy two slots in one bar.',rawBar.location);
        const slots=rawSlots.map(id=>{
            if(id==='-1')return id;
            const raw=graph.voices.get(id)!;
            if(!seenVoices.has(id)){seenVoices.add(id);return id;}
            const generated=allocate(voices);voices.set(generated,{...raw,attrs:{...raw.attrs,id:generated}});
            findings.push({disposition:'preserved',code:'source-definition-occurrence',message:'Repeated immutable source voice is projected into an independent borrowed-reader occurrence; source locations and raw beat/note identities remain unchanged.',location:raw.location,fact:{kind:'voice',sourceId:id,readerId:generated}});
            return generated;
        });
        bars.set(barId,{...rawBar,attrs:{...rawBar.attrs,id:barId},children:rawBar.children.map(c=>c.name==='Voices'?{...c,text:slots.join(' ')}:c)});
        if(barId!==rawBarId)findings.push({disposition:'preserved',code:'source-definition-occurrence',message:'Repeated immutable source bar receives an independent borrowed-reader occurrence while retaining its original source location.',location:rawBar.location,fact:{kind:'bar',sourceId:rawBarId,readerId:barId}});
        return {...master,children:master.children.map(c=>c.name==='Bars'?{...c,text:barId}:c)};
    });
    return {...root,children:root.children.map(c=>c.name==='MasterBars'?{...c,children:masters}:c.name==='Bars'?{...c,children:[...bars.values()]}:c.name==='Voices'?{...c,children:[...voices.values()]}:c)};
}

import { utf8ByteLength } from '../../core/portable-bytes.js';
import { writeMusicXml } from '../../core/musicxml.js';
import type { MusicalScore } from '../../core/model.js';
import { freeze, refuse, Refusal, type Finding, type Location } from '../../core/report.js';
import { captureNative, compactCapture, nativeAdapter, nativeLimits, type NativeCapture, type NativeHost, type ParsedNativeCapture } from './capture-core.js';
import { nativeInventory, readNative, type Construct } from './read.js';
import { boundJson, JsonSizeCache } from './budget.js';
import { inventoryViews, type SourceViewSelection } from './views.js';
import { recoverLinkedViewOttava } from './linked-ottava.js';

export interface MuseScoreReport {
    schema: 'score-converter-report/0'; inputSha256: string; adapter: string; profile: string;
        requestedScope: 'all-parts' | { sourceView: SourceViewSelection }; findings: Finding[]; nativeVersion?: string; producerVersion?: string;
        producerRevision?: string; constructs?: Construct[];
        selectedSourceView?: { id: string; inputSha256: string; identityOrigin: 'source-location'; source: Location; primary: boolean; name?: { source: Location; value: string } };
        convertedParts?: { sourcePartId: string; sourcePartIdentityOrigin: 'encoded-part-id' | 'source-order'; source: Location; musicxmlPartId: string }[];
        metrics: { inputBytes: number; outputBytes: number; nodeCount: number; eventCount: number };
}
/** Observational process timings/RSS are intentionally outside the deterministic conversion report. */
export interface MuseScoreTelemetry { readerMs: number; exportMs: number; peakRssKiB?: number }
export interface MuseScoreSuccess { ok: true; musicxml: string; nativeCapture: NativeCapture; score: MusicalScore; report: MuseScoreReport; telemetry: MuseScoreTelemetry }
export interface MuseScoreFailure { ok: false; musicxml?: never; score?: never; nativeCapture?: NativeCapture; report: MuseScoreReport; telemetry?: MuseScoreTelemetry }
export type MuseScoreResult = MuseScoreSuccess | MuseScoreFailure;
export function convertNative(bytes: Uint8Array, host: NativeHost, options: { sourceView?: SourceViewSelection } = {}): MuseScoreResult {
    if (bytes.length > nativeLimits.inputBytes) throw new RangeError('Native input exceeds 32 MiB before digest or decoding.');
    const start = performance.now();
    const report: MuseScoreResult['report'] = { schema: 'score-converter-report/0', inputSha256: host.sha256(bytes), adapter: nativeAdapter,
        profile: 'musescore-observed-vocabulary/0', requestedScope: options.sourceView ? { sourceView: options.sourceView } : 'all-parts', findings: [],
        metrics: { inputBytes: bytes.length, outputBytes: 0, nodeCount: 0, eventCount: 0 } };
    const telemetry: MuseScoreTelemetry = { readerMs: 0, exportMs: 0, ...(host.peakRssKiB ? { peakRssKiB: 0 } : {}) };
    const sampleRss = () => { if (host.peakRssKiB) telemetry.peakRssKiB = host.peakRssKiB(); };
    const jsonSizes = new JsonSizeCache();
    let nativeCapture: ParsedNativeCapture | undefined;
    let publicCapture: NativeCapture | undefined;
    try {
        nativeCapture = captureNative(bytes, host, { retainViewMusic: !!options.sourceView });
        publicCapture = compactCapture(nativeCapture);
        boundJson(publicCapture, nativeLimits.captureBytes, 'native-capture-budget', jsonSizes);
        report.nativeVersion = nativeCapture.nativeVersion; report.producerVersion = nativeCapture.producerVersion; report.producerRevision = nativeCapture.producerRevision;
        report.constructs = nativeInventory(nativeCapture.root); report.metrics.nodeCount = report.constructs.reduce((n, c) => n + c.count, 0);
        boundJson(report, nativeLimits.reportBytes, 'native-report-budget', jsonSizes);
        let selection: Parameters<typeof readNative>[2];
        if (options.sourceView) {
            if (options.sourceView.inputSha256 !== report.inputSha256) refuse('native-view-input', 'Source view selection does not match these exact original input bytes.', nativeCapture.root.location);
            const inventory = inventoryViews(nativeCapture), entry = inventory.entries.find(entry => entry.info.id === options.sourceView!.id);
            if (!entry) return refuse('native-view-selection', 'Requested view is not an exact inventory identity in this original input.', nativeCapture.root.location);
            selection = { inventory, entry };
        }
        const score = readNative(nativeCapture, report.findings, selection, report.constructs.some(construct => construct.name === 'Lyrics'), report.constructs.some(construct => construct.name === 'Trill'));
        if (selection) recoverLinkedViewOttava(score, selection.inventory, selection.entry, nativeCapture.nativeVersion, report.findings);
        telemetry.readerMs = performance.now() - start;
        report.metrics.eventCount = score.parts.reduce((n, p) => n + p.measures.reduce((n, m) => n + m.voices.reduce((n, v) => n + v.length, 0), 0), 0);
        if (report.metrics.eventCount > nativeLimits.events) refuse('native-event-budget', 'Native event count exceeds the bounded recovery profile.');
        const convertedParts: NonNullable<MuseScoreReport['convertedParts']> = [];
        const partById = new Map(score.parts.map(part => [part.id, part]));
        const exportStart = performance.now(), musicxml = writeMusicXml(score, undefined, selection ? (sourcePartId, musicxmlPartId) => {
            const part = partById.get(sourcePartId)!;
            convertedParts.push({ sourcePartId, sourcePartIdentityOrigin: part.source.id !== undefined ? 'encoded-part-id' : 'source-order', source: part.source, musicxmlPartId });
        } : undefined, { outputBytes: nativeLimits.outputBytes });
        telemetry.exportMs = performance.now() - exportStart; report.metrics.outputBytes = utf8ByteLength(musicxml); sampleRss();
        if (selection) { report.selectedSourceView = { id: selection.entry.info.id, inputSha256: report.inputSha256, identityOrigin: 'source-location', source: selection.entry.info.source, primary: selection.entry.info.primary, ...(selection.entry.info.name ? { name: selection.entry.info.name } : {}) }; report.convertedParts = convertedParts; }
        if (report.findings.length > nativeLimits.findings) refuse('native-report-budget', 'Native report exceeds the bounded finding count.');
        boundJson(report, nativeLimits.reportBytes, 'native-report-budget', jsonSizes);
        const result = { ok: true as const, musicxml, report, nativeCapture: publicCapture, score, telemetry };
        boundJson(result, nativeLimits.messageBytes, 'native-message-budget', jsonSizes);
        return freeze(result);
    } catch (error) {
        delete report.selectedSourceView; delete report.convertedParts;
        const failure = error instanceof Refusal ? error : new Refusal('native-invalid', 'Native input failed bounded conversion; no musical output admitted.');
        report.findings.push({ disposition: 'blocking', code: failure.code, message: failure.message, location: failure.location });
        if (failure.code === 'native-capture-budget') publicCapture = undefined;
        telemetry.readerMs = performance.now() - start; sampleRss();
        try { boundJson(report, nativeLimits.reportBytes, 'native-report-budget', jsonSizes); }
        catch {
            const distinctConstructs = report.constructs?.length; delete report.constructs;
            report.findings = [{ disposition: 'blocking', code: 'native-report-budget', message: 'Full native inventory/report exceeds its byte budget; source bytes remain captured and conversion is refused.', location: failure.location, fact: { originalCode: failure.code, distinctConstructs } }];
        }
        const result = { ok: false as const, report, telemetry, ...(publicCapture ? { nativeCapture: publicCapture } : {}) };
        boundJson(result, nativeLimits.messageBytes, 'native-message-budget', jsonSizes);
        return freeze(result);
    }
}

import type { MusicalPart, NativeHeadScheme, StaffFact } from '../../core/model.js';
import { compare, type Rational } from '../../core/rational.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import type { SourceElement } from '../../core/source-xml.js';
import type { NativeBudget } from './budget.js';

const schemes=new Set<string>(['auto','normal','name-pitch','name-pitch-no-acc','name-pitch-german','name-pitch-german-no-acc','solfege-movable','solfege-fixed','shape-4','shape-7-aikin','shape-7-funk','shape-7-walker']);
export function readNativeHeadScheme(node:SourceElement):NonNullable<StaffFact['noteheadScheme']> {
    const value=node.text.trim();
    if(node.children.length||Object.keys(node.attrs).length||!schemes.has(value))refuse('native-notehead-scheme','A notehead scheme must be one recognized native scalar selector.',node.location);
    return {source:node.location,value:value as NativeHeadScheme};
}

// Independent declarative musical mappings, qualified against native 3.6.2,
// 4.0.2, 4.3.2, 4.4.0 and 4.7.5. No upstream implementation is incorporated.
const syllables:ReadonlyArray<Readonly<Record<number,string>>>=[{0:'Do',1:'Di'},{'-1':'Ra',0:'Re',1:'Ri'},{'-1':'Me',0:'Mi'},{0:'Fa',1:'Fi'},{'-1':'Se',0:'So',1:'Si'},{'-1':'Le',0:'La',1:'Li'},{'-1':'Te',0:'Ti'}];
const shapes=['do','re','mi','fa','so','la','ti'] as const;
const glyphs:Record<string,string>={do:'TriangleUp',re:'Moon',mi:'Diamond',so:'Round',la:'Square',ti:'TriangleRound'};
const variants:Record<string,Readonly<Record<string,string>>>={
    'shape-7-funk':{do:'MoonLeft',re:'ArrowheadLeft',ti:'TriangleRoundLeft'},
    'shape-7-walker':{do:'Keystone',re:'QuarterMoon',ti:'IsoscelesTriangle'},
};
const modulo=(value:number)=>(value%7+7)%7;
type KeyContext={source:Location;fifths:number;origin:'source-key-change'|'source-staff-state'|'native-default'};

/** Source-generated heads change appearance, never pitch, spelling or elapsed value. */
export function recoverNativeHeadSchemes(parts:MusicalPart[],budget:Pick<NativeBudget,'add'>,nativeVersion:string):Finding[] {
    const version=Number(nativeVersion),findings:Finding[]=[];
    for(const part of parts) {
        const precedingKeys=new Map<number,KeyContext>();
        for(const measure of part.measures) {
            const staves=measure.staffs??part.staves??[];
            const keys=new Map<number,{initial:KeyContext;changes:{position:Rational;key:KeyContext}[]}>();
            for(const staff of staves) {
                const snapshot=staff.key?.fifths??measure.key.fifths,previous=precedingKeys.get(staff.number);
                const initial:KeyContext=previous?.fifths===snapshot?previous:{source:staff.source,fifths:snapshot,origin:staff.key?'source-staff-state':'native-default'};
                const changes=(measure.changes??[]).filter(c=>c.staff===staff.number&&c.key&&!c.courtesy).sort((a,b)=>compare(a.position,b.position)).map(c=>({position:c.position,key:{source:c.source,fifths:c.key!.fifths,origin:'source-key-change' as const}}));
                keys.set(staff.number,{initial,changes});precedingKeys.set(staff.number,changes.at(-1)?.key??initial);
            }
            for(const [voiceIndex,voice] of measure.voices.entries())for(const event of voice??[])for(const note of event.notes) {
                delete note.noteheadText;delete note.headSchemeProjection;
                const staffNumber=Math.floor(voiceIndex/4)+1,staff=staves.find(staff=>staff.number===staffNumber);
                const explicit=note.sourceHeadScheme,scheme=explicit?.value!=='auto'&&explicit?explicit:staff?.noteheadScheme;
                if(!scheme||['normal','auto'].includes(scheme.value)||note.kind==='unpitched'||staff?.kind==='tablature')continue;
                const type=note.sourceHeadType?.value??(event.crossMeasureValue?.role==='start'?event.crossMeasureValue.type:event.type);
                const {step,alter}=note.written,letter='CDEFGAB'.indexOf(step);
                if(letter<0)continue;
                const doubleWhole=['breve','long','longa','maxima'].includes(type);
                let text:string|undefined,accidental:'sharp'|'flat'|undefined;
                if(scheme.value.startsWith('name-pitch')) {
                    // No native named glyph for double accidentals. An unsupported
                    // spelling keeps the original head group, not a guessed label.
                    if(![-1,0,1].includes(alter))continue;
                    const german=scheme.value.includes('german'),noAcc=scheme.value.endsWith('no-acc');
                    text=german&&step==='B'&&alter!==-1?'H':step;
                    if(!noAcc&&!(german&&step==='B'&&alter===-1))accidental=alter===1?'sharp':alter===-1?'flat':undefined;
                } else {
                    const timeline=keys.get(staffNumber);
                    let key:KeyContext=timeline?.initial??{source:measure.source,fifths:measure.key.fifths,origin:'native-default'};
                    if(timeline) {
                        let low=0,high=timeline.changes.length;
                        while(low<high){const middle=(low+high)>>>1;if(compare(timeline.changes[middle].position,event.start)<=0)low=middle+1;else high=middle;}
                        if(low)key=timeline.changes[low-1].key;
                    }
                    if(!Number.isInteger(key.fifths)||Math.abs(key.fifths)>7)refuse('native-head-scheme-key','A generated relative head needs the source native key fifths.',key.source);
                    const fixed=scheme.value==='solfege-fixed',degree=fixed?letter:modulo(letter-4*key.fifths);
                    const signature=key.fifths>0?('FCGDAEB'.slice(0,key.fifths).includes(step)?1:0):('BEADGCF'.slice(0,-key.fifths).includes(step)?-1:0);
                    const alteration=alter-(fixed?0:signature);
                    note.headSchemeProjection={source:scheme.source,scheme:scheme.value,nativeVersion,degree,...(!fixed?{key}:{}),alteration,origin:'native-source-rule'};
                    if(scheme.value.startsWith('shape-')) {
                        const shape=scheme.value==='shape-4'?(['fa','so','la','fa','so','la','mi'] as const)[degree]:shapes[degree];
                        const stem=event.stem==='up'||event.stem==='down'?event.stem:undefined;
                        note.notehead=shape==='fa'&&stem==='up'?'fa up':shape;
                        const base=shape==='fa'?(stem==='up'?'TriangleLeft':stem==='down'?'TriangleRight':undefined):variants[scheme.value]?.[shape]??glyphs[shape];
                        delete note.noteheadSmufl;
                        if(base)note.noteheadSmufl={source:scheme.source,name:`noteShape${base}${doubleWhole?'DoubleWhole':['whole','half'].includes(type)?'White':'Black'}`};
                        // An unqualified automatic fa orientation belongs to the
                        // receiving engraver's stem, not an invented source stem.
                        note.noteheadFilled=!doubleWhole&&!['whole','half'].includes(type);
                        budget.add('markings',1,scheme.source);continue;
                    }
                    const diatonic=fixed?(version<4||version>=4.4):version<4;
                    text=diatonic?(fixed?['Do','Re','Mi','Fa','So','La','Si']:['Do','Re','Mi','Fa','So','La','Ti'])[degree]:syllables[degree][alteration];
                    if(!text)continue;
                }
                note.notehead='normal';delete note.noteheadSmufl;
                // Native named-head tables have no double-whole glyph.
                if(doubleWhole)continue;
                note.noteheadText={source:scheme.source,text,...(accidental?{accidental}:{}),origin:scheme.value.startsWith('solfege-')?'native-solfege':'native-pitch-name'};
                budget.add('markings',1,scheme.source);
            }

        }
    }
    return findings;
}

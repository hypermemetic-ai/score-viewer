import { limits } from './limits.js';
import { Refusal, refuse } from '../../core/report.js';
import { scanContainer, checkMember, finishContainer, zipFail, type ZipMembers } from './zip-core.js';
import { checkWork, inflate, supportsFraming, type StreamDeadline } from '../../core/webview-inflate.js';

/** Native stream host, not a second ZIP parser. A post-read bound is not an allocation ceiling. */
export async function readWebViewContainer(bytes: Uint8Array, deadlineAt: number): Promise<ZipMembers> {
    const deadline: StreamDeadline = { at: deadlineAt, work: () => new Refusal('work-budget', 'Worker exceeded 5 seconds; no musical output is admitted.', { member: 'container' }) };
    const entries = scanContainer(bytes), result: ZipMembers = new Map();
    result.zipDescriptors = entries.flatMap(entry => entry.descriptor ? [entry.descriptor] : []);
    let retained = 0;
    for (const entry of entries) {
        checkWork(deadline);
        const payload = bytes.subarray(entry.dataStart, entry.dataStart + entry.compressed);
        let decoded: Uint8Array;
        if (entry.method === 0) decoded = payload.slice();
        else {
            const ctor = globalThis.DecompressionStream;
            if (typeof ctor !== 'function' || !await supportsFraming(ctor, deadline)) refuse('runtime-codec', 'Native deflate-raw is missing or fails the bounded exact-output/truncated/trailing framing gate; no compressed input is admitted.', { member: 'container' });
            try { decoded = await inflate(ctor, payload, Math.min(entry.decoded, limits.memberBytes, limits.decodedBytes - retained), deadline); }
            catch (error) { if (error instanceof Refusal) throw error; zipFail(`Unable to decode ${entry.name} within its bound.`); }
        }
        retained += decoded!.byteLength;
        if (retained > limits.decodedBytes) zipFail('Actual total decoded size exceeds its bound.');
        checkWork(deadline);
        result.set(entry.name, checkMember(entry, decoded!));
    }
    return finishContainer(result);
}

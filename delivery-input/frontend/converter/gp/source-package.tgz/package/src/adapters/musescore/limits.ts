/** Native admission budgets and adapter identity, shared by the reader and its Node/WebView hosts. */
export const nativeLimits = { inputBytes: 32 * 1024 * 1024, outputBytes: 64 * 1024 * 1024,
    styleBytes: 1024 * 1024,
    events: 250_000, chordNotes: 128, components: 250_000, relations: 100_000, timelines: 100_000, markings: 250_000,
    findings: 4096, reportBytes: 4 * 1024 * 1024, captureBytes: 128 * 1024 * 1024, messageBytes: 192 * 1024 * 1024,
    workerHeapMb: 384, workerMs: 20_000 };
export const nativeAdapter = 'independent-mscx/0';

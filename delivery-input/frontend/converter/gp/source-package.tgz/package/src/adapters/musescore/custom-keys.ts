import {child,children,integer,type SourceElement as Element} from '../../core/source-xml.js';
import {refuse,type Finding} from '../../core/report.js';
import type {KeySignature} from '../../core/model.js';
import {nativeAccidental} from './accidentals.js';
// Factual source glyph adjacency; native symInKey uses the first matching identity.
const transpositionGlyphs=[
'noSym',
    'accidentalTripleFlat',
    'accidentalDoubleFlat',
    'accidentalFlat',
    'accidentalNatural',
    'accidentalSharp',
    'accidentalDoubleSharp',
    'accidentalTripleSharp',
    'noSym',
    'accidentalNatural',
    'accidentalNaturalSharp',
    'accidentalSharp',
    'noSym',
    'accidentalDoubleFlat',
    'accidentalNaturalFlat',
    'accidentalNatural',
    'noSym',
    'accidentalSharp',
    'accidentalSharpSharp',
    'accidentalTripleSharp',
    'noSym',
    'accidentalFiveQuarterTonesFlatArrowDown',
    'accidentalThreeQuarterTonesFlatArrowDown',
    'accidentalQuarterToneFlatNaturalArrowDown',
    'accidentalQuarterToneSharpArrowDown',
    'accidentalThreeQuarterTonesSharpArrowDown',
    'accidentalFiveQuarterTonesFlatArrowDown',
    'noSym',
    'accidentalThreeQuarterTonesFlatArrowUp',
    'accidentalQuarterToneFlatArrowUp',
    'accidentalQuarterToneSharpNaturalArrowUp',
    'accidentalThreeQuarterTonesSharpArrowUp',
    'accidentalFiveQuarterTonesSharpArrowUp',
    'noSym',
    'accidentalThreeQuarterTonesFlatZimmermann',
    'accidentalQuarterToneFlatStein',
    'accidentalQuarterToneSharpStein',
    'accidentalThreeQuarterTonesSharpStein',
    'noSym',
    'accidentalNarrowReversedFlatAndFlat',
    'accidentalNarrowReversedFlat',
    'accidentalQuarterToneSharpStein',
    'accidentalDoubleFlatOneArrowDown',
    'accidentalFlatOneArrowDown',
    'accidentalNaturalOneArrowDown',
    'accidentalSharpOneArrowDown',
    'accidentalDoubleSharpOneArrowDown',
    'noSym',
    'accidentalDoubleFlatOneArrowUp',
    'accidentalFlatOneArrowUp',
    'accidentalNaturalOneArrowUp',
    'accidentalSharpOneArrowUp',
    'accidentalDoubleSharpOneArrowUp',
    'noSym',
    'accidentalDoubleFlatTwoArrowsDown',
    'accidentalFlatTwoArrowsDown',
    'accidentalNaturalTwoArrowsDown',
    'accidentalSharpTwoArrowsDown',
    'accidentalDoubleSharpTwoArrowsDown',
    'noSym',
    'accidentalDoubleFlatTwoArrowsUp',
    'accidentalFlatTwoArrowsUp',
    'accidentalNaturalTwoArrowsUp',
    'accidentalSharpTwoArrowsUp',
    'accidentalDoubleSharpTwoArrowsUp',
    'noSym',
    'accidentalDoubleFlatThreeArrowsDown',
    'accidentalFlatThreeArrowsDown',
    'accidentalNaturalThreeArrowsDown',
    'accidentalSharpThreeArrowsDown',
    'accidentalDoubleSharpThreeArrowsDown',
    'noSym',
    'accidentalDoubleFlatThreeArrowsUp',
    'accidentalFlatThreeArrowsUp',
    'accidentalNaturalThreeArrowsUp',
    'accidentalSharpThreeArrowsUp',
    'accidentalDoubleSharpThreeArrowsUp',
    'noSym',
    'accidentalDoubleFlatEqualTempered',
    'accidentalFlatEqualTempered',
    'accidentalNaturalEqualTempered',
    'accidentalSharpEqualTempered',
    'accidentalDoubleSharpEqualTempered',
    'noSym'];
type ClefContext={pitchOffset:number;accidentalLines:readonly number[]};
export function readNativeCustomKey(owner:Element,key:KeySignature,context:{nativeVersion:string;clef:ClefContext;consume(node:Element):void;add(node:Element):void;findings:Finding[]}):void {
    const definitions=owner.children.filter(n=>n.name==='KeySym'||n.name==='CustDef');
    if(!definitions.length){
        if(!key.custom?.value)return;
        // The native loader draws an empty custom signature as atonal. A nonzero
        // encoded key would make standard fifths draw accidentals the source omits.
        if(key.fifths!==0)refuse('native-key','An empty custom signature with a nonzero source key has no qualified standard drawing.',owner.location);
        key.mode='none';return;
    }
    if(!key.custom?.value)refuse('native-custom-key','Custom accidental definitions require an active source custom signature.',owner.location);
    if(definitions.length>128)refuse('native-custom-key-budget','Custom key exceeds the bounded definition count.',owner.location);
    const legacy=Number(context.nativeVersion)<4;
    const readScalar=(node:Element):string=>{if(node.children.length||Object.keys(node.attrs).length||node.text.length>256)refuse('native-custom-key','Custom key scalar must be bounded plain source data.',node.location);context.consume(node);return node.text.trim();};
    const finite=(value:string|undefined,fallback:number,node:Element):number=>{if(value===undefined)return fallback;if(!/^-?(?:\d+(?:\.\d*)?|\.\d+)$/.test(value)||!Number.isFinite(Number(value))||Math.abs(Number(value))>10000)refuse('native-custom-key','Custom key coordinate must be a bounded finite source decimal.',node.location);return Number(value);};
    const parsed=definitions.map(node=>{
        context.add(node);if(node.text.trim()||Object.keys(node.attrs).length)refuse('native-custom-key','Custom key definition has unexpected free content.',node.location);
        if(legacy&&node.name!=='KeySym'||!legacy&&Number(context.nativeVersion)>=4.6&&node.name!=='CustDef')refuse('native-custom-key-version','This custom-key definition belongs to another native serializer family.',node.location);
        const symbol=child(node,'sym',true)!,glyph=readScalar(symbol);nativeAccidental(glyph,context.nativeVersion,symbol.location);
        const def=child(node,'def'),pos=child(node,'pos');if(!!def===!!pos)refuse('native-custom-key','Custom key needs exactly one source degree or legacy position definition.',node.location);
        if(node.children.some(n=>!['sym','def','pos'].includes(n.name))||children(node,'sym').length!==1||children(node,def?'def':'pos').length!==1)refuse('native-custom-key','Custom key definition has duplicate or unknown fields.',node.location);
        const coordinate=(def??pos)!;if(coordinate.children.length||coordinate.text.trim())refuse('native-custom-key','Custom key coordinates cannot contain nested payload.',coordinate.location);
        const allowed=def?['degree','octAlt','xAlt']:['x','y'];if(Object.keys(coordinate.attrs).some(k=>!allowed.includes(k)))refuse('native-custom-key','Unknown custom key coordinate attribute.',coordinate.location);
        let degree:number|undefined,octaveAlteration:number|undefined,xAlteration:number|undefined,position:{x:number;y:number}|undefined;
        if(def){if(legacy)refuse('native-custom-key-version','Legacy key signature has no relative-degree serializer.',def.location);degree=integer(def.attrs.degree??'0',0,6,def.location);octaveAlteration=integer(def.attrs.octAlt??'0',-128,128,def.location);xAlteration=finite(def.attrs.xAlt,0,def);}
        else {position={x:finite(pos!.attrs.x,0,pos!),y:finite(pos!.attrs.y,2,pos!)};if(!legacy){let line=Math.trunc(position.y*2);degree=((3-line)%7+7)%7;line+=glyph.includes('Flat')?-1:1;octaveAlteration=Math.trunc((line-(line>=0?0:6))/7);xAlteration=position.x;}}
        context.consume(coordinate);context.consume(node);return {source:node.location,glyph,...(degree!==undefined?{degree,octaveAlteration,xAlteration}:{}),...(position?{position}:{})};
    });
    key.customDefinitions=parsed;
    if(key.mode==='none'){context.findings.push({disposition:'preserved',code:'native-atonal-custom-definitions',location:owner.location,message:'Source custom definitions remain located, but the explicit atonal mode suppresses their key-signature drawing.'});return;}
    const tones:NonNullable<KeySignature['customTones']>=[],steps='CDEFGAB';
    const absoluteDegree=(degree:number)=>(degree+(key.fifths+7)*4)%7;
    const altered=(degree:number)=>{const order=key.fifths<0?[6,2,5,1,4,0,3]:[3,0,4,1,5,2,6];return order.slice(0,Math.abs(key.fifths)).includes(degree)?Math.sign(key.fifths):0;};
    const emit=(source:Element['location'],glyph:string,degree:number,line:number,components?:{source:Element['location'];name:string}[])=>{
        if(glyph==='noSym')return;const fact=nativeAccidental(glyph,context.nativeVersion,source),octave=Math.floor((context.clef.pitchOffset-line)/7)-1;
        if(fact.cents===undefined)context.findings.push({disposition:'omitted',code:'native-custom-key-cent-authority',location:source,message:'The custom accidental glyph remains exact; its serializer-specific cent default is unqualified. Standard key alteration retains the native nominal accidental value without inventing finer tuning.'});
        if(octave<0||octave>9)context.findings.push({disposition:'omitted',code:'native-custom-key-octave-range',location:source,message:'The exact source custom-key register remains located. Its displayed octave is outside the standard key-octave 0–9 range; pitch-step and accidental meaning remain standard.'});
        tones.push({source,step:steps[degree],alter:components?0:fact.baseAlter+(fact.cents??0)/100,...(components?{nativeStateAlter:0}:{}),accidental:fact.name,...(fact.smufl?{smufl:fact.smufl}:{}),...(octave>=0&&octave<=9?{octave}:{}),...(components?{components}:{})});
    };
    if(legacy){for(const def of [...parsed].sort((a,b)=>a.position!.x-b.position!.x)){const line=Math.trunc(def.position!.y*2),degree=((context.clef.pitchOffset-line)%7+7)%7;emit(def.source,def.glyph,degree,line);}}
    else {
        const replaced=new Set(parsed.map(def=>absoluteDegree(def.degree!))),order=key.fifths<0?[6,2,5,1,4,0,3]:[3,0,4,1,5,2,6];
        for(const [index,degree] of order.slice(0,Math.abs(key.fifths)).entries())if(!replaced.has(degree))emit(owner.location,key.fifths<0?'accidentalFlat':'accidentalSharp',degree,context.clef.accidentalLines[(key.fifths<0?7:0)+index]);
        for(const def of parsed){const degree=absoluteDegree(def.degree!),shift=altered(degree),index=transpositionGlyphs.indexOf(def.glyph);let glyph=key.fifths===0?def.glyph:index<0?'noSym':transpositionGlyphs[index+shift]??'noSym';
            const flat=glyph.includes('Flat'),idx=(degree*2+1)%7,line=context.clef.accidentalLines[flat?13-idx:idx]+def.octaveAlteration!*7;
            if(glyph==='noSym'){const prefix=def.glyph==='accidentalTripleSharp'?'accidentalDoubleSharp':key.fifths<0?'accidentalFlat':'accidentalSharp';glyph=def.glyph==='accidentalTripleSharp'?'accidentalDoubleSharp':def.glyph;key.customProjection='annotated-components';emit(def.source,glyph,degree,line,[{source:def.source,name:prefix},{source:def.source,name:glyph}]);}
            else if(glyph!=='accidentalNatural'||glyph===def.glyph)emit(def.source,glyph,degree,line);
        }
    }
    key.customTones=tones;
    if(key.customProjection)context.findings.push({disposition:'inferred',code:'native-custom-key-components',location:owner.location,message:'A source custom key requires a compound accidental. A located standard key-signature instruction preserves the exact ordered symbol components; the specialized key drawing is hidden to avoid a false single-glyph rendering.'});
}

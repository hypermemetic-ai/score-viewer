import type { Direction, MusicalEvent as Event, MusicalMeasure, MusicalPart, MusicalRelation, MusicalScore, RelationEndpoint } from '../../core/model.js';
import { add, decimal, equal, mul, q } from '../../core/rational.js';
import { refuse } from '../../core/report.js';
import { child, integer, value, type Element } from './xml.js';

export const masterFields = ['Section', 'AlternateEndings', 'Directions', 'TripletFeel', 'DoubleBar', 'FreeTime', 'Fermatas'];
export const scoreTextFields = ['Title','SubTitle','Artist','Album','Words','Music','WordsAndMusic','Copyright','Tabber','Instructions','Notices'];
export const structuralBeatFields = ['Lyrics', 'GraceNotes', 'Legato', 'Hairpin', 'Ottavia', 'Fadding'];

export function scoreTexts(source: Element, partId: string): Pick<MusicalScore, 'metadata' | 'credits'> {
    const metadata: NonNullable<MusicalScore['metadata']> = [], credits: NonNullable<MusicalScore['credits']> = [];
    for (const name of scoreTextFields) {
        const field = child(source, name, false); if (!field?.text.trim()) continue;
        metadata.push({ source: field.location, name, value: field.text });
        const role = ({ Title:'title',SubTitle:'subtitle',Music:'composer',Words:'lyricist' } as const)[name as 'Title'|'SubTitle'|'Music'|'Words'];
        credits.push({ source: field.location, text: field.text, ...(role ? { role } : {}), frame: 'VBox', partId, staff: 1, beforeMeasure: 0 });
    }
    return { metadata, credits };
}

const targets: Record<string, { label: string; kind: Direction['kind']; text?: string }> = {
    Segno: { label: 'segno', kind: 'segno' }, SegnoSegno: { label: 'segno-segno', kind: 'segno', text:'double segno' },
    Coda: { label:'coda',kind:'coda' }, DoubleCoda: {label:'double-coda',kind:'coda',text:'double coda'}, Fine:{label:'fine',kind:'words',text:'Fine'}
};
export function masterStructure(source: Element, measure: MusicalMeasure, part: MusicalPart, index: number, relations: MusicalRelation[]): void {
    const free=child(source,'FreeTime',false);if(free)measure.time={...measure.time,senzaMisura:{source:free.location}};
    const endpoint = (position: ReturnType<typeof q>): RelationEndpoint => ({ partId:part.id,measure:index,position,staff:1 });
    const section = child(source,'Section',false);
    if (section) {
        const letter = value(section,'Letter',false), text = value(section,'Text',false);
        if (letter || text) (measure.directions ??= []).push({ source:section.location,position:q(0),staff:1,kind:'rehearsal',text:[letter,text].filter(Boolean).join(' — '),system:true });
    }
    if (child(source,'DoubleBar',false)) (measure.barlines ??= []).push({ source:child(source,'DoubleBar')!.location,position:measure.duration,location:'right',style:'light-light',origin:'source' });
    const endings = child(source,'AlternateEndings',false);
    if (endings?.text.trim()) {
        const numbers = endings.text.trim().split(/\s+/).map(raw=>integer(raw,1,32,endings));
        if (new Set(numbers).size!==numbers.length) refuse('repeat-ending','Duplicate source ending number.',endings.location);
        const previous=relations.at(-1);
        if(previous?.kind==='ending'&&previous.start.partId===part.id&&!previous.closed&&previous.end.measure===index-1&&previous.numbers.join(',')===numbers.join(',')) {previous.end=endpoint(measure.duration);previous.closed=!!measure.repeatEnd;}
        else relations.push({source:endings.location,id:`gp-ending:${part.id}:${index}`,kind:'ending',numbers,sourceNumbers:{source:endings.location,values:numbers},closed:!!measure.repeatEnd,start:endpoint(q(0)),end:endpoint(measure.duration)});
    }
    const feel = child(source,'TripletFeel',false);
    if (feel && feel.text.trim() !== 'NoTripletFeel') {
        const match = /^(Triplet|Dotted|Scottish)(8th|16th)$/.exec(feel.text.trim());
        if (!match) refuse('rhythmic-feel','Unknown source rhythmic feel.',feel.location);
        (measure.directions ??= []).push({source:feel.location,position:q(0),staff:1,kind:'words',text:`${match![1].toLowerCase()} ${match![2]} feel`,rhythmicFeel:{source:feel.location,kind:match![1].toLowerCase() as 'triplet'|'dotted'|'scottish',unit:match![2]==='8th'?'eighth':'16th'}});
    }
    for (const item of child(source,'Directions',false)?.children ?? []) {
        const name = item.text.trim();
        if (item.name==='Target') {
            const target=targets[name];if(!target)refuse('navigation','Unknown navigation target.',item.location);
            const at=name==='Fine'?measure.duration:q(0);
            (measure.directions ??=[]).push({source:item.location,position:at,staff:1,kind:target.kind,text:target.text,navigation:{source:item.location,kind:'marker',label:target.label,markerType:{source:item.location,value:name}}});
        } else if(item.name==='Jump') {
            const jump=/^(DaCapo|DaSegnoSegno|DaSegno)(AlCoda|AlDoubleCoda|AlFine)?$/.exec(name);
            if (name==='DaCoda'||name==='DaDoubleCoda') {
                const target=name==='DaCoda'?'coda':'double-coda';
                (measure.directions??=[]).push({source:item.location,position:measure.duration,staff:1,kind:'words',text:name==='DaCoda'?'To Coda':'To Double Coda',navigation:{source:item.location,kind:'jump',label:target==='coda'?'to-coda':'to-double-coda',jumpTo:target,targetKind:'coda'}});
            } else {
                if(!jump)refuse('navigation','Unknown navigation jump.',item.location);
                const jumpTo=jump![1]==='DaCapo'?'start':jump![1]==='DaSegno'?'segno':'segno-segno';
                const suffix=jump![2],playUntil=suffix==='AlFine'?'fine':suffix==='AlCoda'?'to-coda':suffix==='AlDoubleCoda'?'to-double-coda':undefined;
                (measure.directions??=[]).push({source:item.location,position:measure.duration,staff:1,kind:'words',text:name.replace(/([a-z])([A-Z])/g,'$1 $2'),navigation:{source:item.location,kind:'jump',jumpTo,...(playUntil?{playUntil}:{}),...(suffix==='AlCoda'?{continueAt:'coda'}:suffix==='AlDoubleCoda'?{continueAt:'double-coda'}:{})}});
            }
        } else refuse('navigation','Unknown source navigation field.',item.location);
    }
    for(const fermata of child(source,'Fermatas',false)?.children??[]) {
        const raw=value(fermata,'Offset').split('/');if(raw.length!==2)refuse('fermata','Expected exact fermata offset.',fermata.location);
        const position=q(integer(raw[0],0,100000,fermata),integer(raw[1],1,100000,fermata));
        const shape=({Short:'angled',Medium:'normal',Long:'square'} as const)[value(fermata,'Type') as 'Short'|'Medium'|'Long'];
        if(!shape)refuse('fermata','Unknown source fermata shape.',fermata.location);
        const hosts=measure.voices.flat().filter(event=>equal(event.start,position)&&!event.grace);
        if(!hosts.length)refuse('fermata','Fermata offset has no printed event owner.',fermata.location);
        for(const event of hosts)event.fermata={source:fermata.location,shape,inverted:false};
    }
}

export function beatStructure(source: Element, event: Event): void {
    const lyrics=child(source,'Lyrics',false);
    if(lyrics)(event.notes[0] ?? event).lyrics=lyrics.children.flatMap((line,index)=>line.text ? [{source:line.location,number:index+1,text:line.text}] : []);
    const fade=child(source,'Fadding',false);
    if(fade){const text=({FadeIn:'fade in',FadeOut:'fade out',VolumeSwell:'volume swell'} as Record<string,string>)[fade.text.trim()];if(!text)refuse('fade','Unknown source volume gesture.',fade.location);event.text=[event.text,text].filter(Boolean).join(' — ');}
}

/** GP lyric controls: spaces advance syllables, + joins words, brackets contain comments. */
export function trackLyrics(source: Element, part: MusicalPart, applyTrack = true): void {
    // Dispatched captions already own a beat; hyphens retain standard syllable semantics in each independent verse/voice.
    const continuingByVoice = new Map<string, boolean>();
    for (const measure of part.measures) for (const [voiceIndex, voice] of measure.voices.entries()) for (const event of voice) {
        for (const lyric of [...(event.lyrics ?? []), ...event.notes.flatMap(note => note.lyrics ?? [])]) {
            const key = `${voiceIndex}:${lyric.number}`, trailing = /-+$/.test(lyric.text), continuing = continuingByVoice.get(key) ?? false;
            lyric.text = lyric.text.replace(/-+$/, '');
            lyric.syllabic = continuing ? trailing ? 'middle' : 'end' : trailing ? 'begin' : 'single';
            if (lyric.text) continuingByVoice.set(key, trailing);
        }
    }
    const lyrics=child(source,'Lyrics',false);if(!lyrics || !applyTrack)return;
    const hasBeatLyrics=part.measures.some(m=>m.voices.some(v=>v.some(e=>e.lyrics?.length||e.notes.some(n=>n.lyrics?.length))));
    if(hasBeatLyrics)return; // Dispatched beat captions carry exact authored placement; raw track text stays captured.
    for(const [index,line] of lyrics.children.entries()) {
        const text=value(line,'Text',false);if(!text.trim())continue;
        const offset=integer(value(line,'Offset'),0,part.measures.length-1,line);
        if(/\[[^\]]*$/.test(text)||/\]/.test(text.replace(/\[[^\]]*\]/g,'')))refuse('lyrics','Unbalanced source lyric comment.',line.location);
        const clean=text.replace(/\[[^\]]*\]/g,'').replace(/[\r\n\t]+/g,' '),chunks:string[]=[];
        let token='';
        for(let i=0;i<clean.length;i++) {
            const character=clean[i];
            if(character===' ') {chunks.push(token);token='';}
            else {token+=character;if(character==='-'){chunks.push(token);token='';if(clean[i+1]===' ')i++;}}
        }
        if(token)chunks.push(token);
        const hosts=part.measures.slice(offset).flatMap(m=>m.voices[0]??[]).filter(e=>e.notes.length&&!e.grace);
        if(chunks.length>hosts.length)refuse('lyrics','Source lyric syllables exceed available written attacks.',line.location);
        let continuing=false;
        chunks.forEach((raw,i)=>{
            const trailing=/-+$/.test(raw),caption=raw.replace(/-+$/,'').replaceAll('+',' ');
            if(!caption)return;
            (hosts[i].notes[0].lyrics??=[]).push({source:line.location,number:index+1,text:caption,syllabic:continuing?trailing?'middle':'end':trailing?'begin':'single'});
            continuing=trailing;
        });
    }
}

/** Encoded per-beat hairpin/ottava runs retain their exact printed span. */
export function beatRelations(part: MusicalPart, sources: Map<string, Element>, relations: MusicalRelation[]): void {
    const maximum=Math.max(...part.measures.map(measure=>measure.voices.length));
    for(let voice=0;voice<maximum;voice++) {
        const events=part.measures.flatMap((measure,mi)=>(measure.voices[voice]??[]).map(event=>({event,mi,source:sources.get(event.source.id ?? event.id)!})));
        const endpoint=(entry:typeof events[number],release=false):RelationEndpoint=>({partId:part.id,measure:entry.mi,position:release?add(entry.event.start,entry.event.duration):entry.event.start,staff:entry.event.staff??1,voiceId:entry.event.voiceId??String(voice+1),...(!release?{eventId:entry.event.id}:{}),...(entry.event.grace?{graceIndex:entry.event.grace.index}:{})});
        for(const name of ['Hairpin','Ottavia'] as const) for(let index=0;index<events.length;index++) {
            const field=child(events[index].source,name,false);if(!field)continue;
            const kind=field.text.trim();let end=index;while(end+1<events.length&&value(events[end+1].source,name,false)===kind)end++;
            const common={source:field.location,id:`gp-${name}:${part.id}:${voice}:${index}`,start:endpoint(events[index]),end:endpoint(events[end],true)};
            if(name==='Hairpin'){if(!['Crescendo','Decrescendo'].includes(kind))refuse('hairpin','Unknown encoded hairpin.',field.location);relations.push({...common,kind:'wedge',diminuendo:kind==='Decrescendo'}); for(const [where,action] of [[common.start,kind==='Decrescendo'?'diminuendo':'crescendo'],[common.end,'stop']] as const) (part.measures[where.measure].directions??=[]).push({source:field.location,position:where.position,staff:where.staff,voiceId:where.voiceId,kind:'wedge',action,relationId:common.id});}
            else {const octaves=({'8va':1,'8vb':-1,'15ma':2,'15mb':-2} as const)[kind as '8va'|'8vb'|'15ma'|'15mb'];if(!octaves)refuse('ottava','Unknown encoded ottava.',field.location);relations.push({...common,kind:'ottava',octaves});}
            index=end;
        }
        let origin:typeof events[number]|undefined, last:typeof events[number]|undefined;
        const finishLegato = () => {
            if (!origin) return;
            if (!last || last === origin) refuse('legato', 'Explicit legato origin has no destination-bearing source event.', origin.source.location);
            const id=`gp-legato:${part.id}:${voice}:${origin.event.id}`;
            relations.push({source:child(origin.source,'Legato')!.location,id,kind:'slur',start:endpoint(origin),end:endpoint(last!)});
            (origin.event.slurs??=[]).push({type:'start',number:1,relationId:id});(last!.event.slurs??=[]).push({type:'stop',number:1,relationId:id});
            origin=undefined;last=undefined;
        };
        for(const entry of events) {
            const legato=child(entry.source,'Legato',false);
            if(!legato) { finishLegato(); continue; }
            for(const flag of Object.values(legato.attrs))if(!['true','false'].includes(flag))refuse('legato','Expected source legato boolean.',legato.location);
            const starts=legato.attrs.origin==='true', arrives=legato.attrs.destination==='true';
            if(arrives) {
                if(!origin)refuse('legato','Unpaired explicit legato destination.',legato.location);
                last=entry;
                if(!starts)finishLegato();
            } else if(starts) { finishLegato(); origin=entry; }
            else finishLegato();
        }
        finishLegato();
    }
}

import type {MusicalPart,MusicalScore} from '../../core/model.js';
import type {Rational} from '../../core/rational.js';
import {refuse,type Finding,type Location} from '../../core/report.js';
import type {Bytes} from './bytes.js';

interface Mix {source:Location;facts:Record<string,number>;measure:number;position:Rational}
const compare=(a:Rational,b:Rational)=>a.n*b.d-b.n*a.d;
/** GP length-prefixed caption: the outer byte length is authoritative, not the redundant one-byte length. */
export function binaryCaption(bytes:Bytes,source:Location):string {
    const start=source.byteOffset!,length=source.byteLength!;
    if(length<5||bytes.readUInt32LE(start)!==length-4)refuse('binary-text','Inconsistent captured caption length.',source);
    const data=bytes.subarray(start+5,start+length);
    return new TextDecoder(data[0]===0xfe&&data[1]===0xff?'utf-16be':data[0]===0xff&&data[1]===0xfe?'utf-16le':'windows-1252').decode(data);
}
/** Mixer patches are timed timbre contexts; they never redefine physical strings, clefs or pitch register. */
export function binaryMix(parts:MusicalPart[],mixes:Mix[],bytes:Bytes,locations:Map<string,Location>,findings:Finding[]):NonNullable<MusicalScore['metadata']> {
    const metadata:NonNullable<MusicalScore['metadata']>=[],patches=new Map<string,NonNullable<MusicalPart['instrumentChanges']>[number]>();
    for(const mix of mixes){
        const at=(name:string)=>locations.get(mix.source.path+'/'+name)??mix.source,part=parts.find(part=>part.id===mix.source.trackId);
        const captionSource=locations.get(mix.source.path+'/mix-tempo-name');
        if(captionSource){const text=binaryCaption(bytes,captionSource);if(text){
            metadata.push({source:captionSource,name:'source-tempo-caption:'+mix.source.path,value:text});
            const tempo=mix.facts['mix-tempo']>=0?{visible:!mix.facts['mix-hide-tempo']}:undefined;
            if(tempo&&parts[0]) (parts[0].measures[mix.measure].directions??=[]).push({source:captionSource,kind:'words',staff:1,position:mix.position,text,printObject:tempo.visible});
        }}
        if(mix.facts['mix-duration']>0){
            metadata.push({source:at('mix-duration'),name:'source-tempo-transition:'+mix.source.path,value:JSON.stringify({beats:mix.facts['mix-duration'],target:mix.facts['mix-tempo'],hidden:!!mix.facts['mix-hide-tempo']})});
            findings.push({disposition:'excluded-by-scope',code:'binary-tempo-playback-transition',message:'Mixer transition length remains exact source metadata in native beats. The printed target and caption retain source visibility; no performer ramp words or linear time curve are invented.',location:at('mix-duration')});
        }
        if(!part)continue;
        const program=mix.facts['mix-instrument'];
        if(program>=0){
            const source=at('mix-instrument'),changes=part.instrumentChanges??=[];
            const key=`${part.id}:${mix.measure}:${mix.position.n}/${mix.position.d}`,previous=patches.get(key);
            if(previous&&previous.midiProgram!==program)refuse('instrument-conflict','Concurrent source voices encode conflicting instrument patches.',source);
            if(!previous){const change={source,id:'binary-mix:'+mix.source.path,measure:mix.measure,position:mix.position,staff:1,midiProgram:program,defaultClefs:[]};changes.push(change);patches.set(key,change);}
        }
        const wah=mix.facts['mix-wah'];
        if(wah!==undefined&&wah!==-1){
            const source=at('mix-wah'),visible=!!(mix.facts['mix-flags']&128);
            metadata.push({source,name:'source-wah:'+mix.source.path,value:JSON.stringify({value:wah,visible})});
            (part.measures[mix.measure].directions??=[]).push({source,kind:'words',staff:1,position:mix.position,text:wah===-2?'Wah off':wah===0?'Wah open':wah===100?'Wah closed':`Wah position ${wah}/100`,printObject:visible});
            findings.push({disposition:'preserved',code:'binary-wah-instruction',message:'Exact source Wah position and display flag retain a standard readable instruction, including hidden source instructions.',location:source});
        }
    }
    for(const part of parts)if(part.instrumentChanges?.length){
        part.instrumentChanges.sort((a,b)=>a.measure-b.measure||compare(a.position,b.position));
        let cursor=0,active:NonNullable<MusicalPart['instrumentChanges']>[number]|undefined;
        for(let measure=0;measure<part.measures.length;measure++)for(const event of part.measures[measure].voices.flat().sort((a,b)=>compare(a.start,b.start))){
            while(cursor<part.instrumentChanges.length){const next=part.instrumentChanges[cursor];if(next.measure>measure||next.measure===measure&&compare(next.position,event.start)>0)break;active=next;cursor++;}
            if(active)event.instrumentContextId=active.id;
        }
        findings.push({disposition:'preserved',code:'binary-instrument-context',message:'Encoded MIDI patches become timed instrument contexts without changing the source performing instrument, strings or written pitch register.',location:part.instrumentChanges[0].source});
    }
    return metadata;
}

import { createNativeMusicTextSize, isMusicTextRun, type NativeMusicTextSizeRun } from './music-text-size.js';
import { createNativeInlinePresentation } from './inline-presentation.js';
import type { MusicalRelation, TextFontSize } from '../../core/model.js';
import type { SourceElement as Element } from '../../core/source-xml.js';
import { applyNativeTextPresentation, type NativeTextPresentation, type NativeTextPresentationContext } from './presentation.js';
import { createNativeTextSizeProjector, nativeTextSizeDependency, type NativeTextScaleContext } from './text-size.js';

type CaptionField = 'beginText' | 'continueText' | 'endText';
export type NativeLinePresentation = Pick<MusicalRelation, CaptionField | 'textFontFamilies' | 'textFontSizes' | 'textMusicFontSizes' | 'textFontStyles' | 'textRuns' | 'system' | 'pedalState'>;
type Dependency = NonNullable<TextFontSize['pointSize']>['spatiumDependent'];
const key = (e: { member?: string; path?: string }) => `${e.member ?? ''}\0${e.path ?? ''}`;

/** TextLineBase copies each endpoint's font into a temporary DEFAULT Text.
 * Its unit dependency is a distinct source property from the line's font size.
 * Call after source caption values/runs are decoded, before creating directions.
 */
export function createNativeLinePresentation(scopes: readonly Element[], context: NativeTextPresentationContext) {
    const styles = new Map(scopes.flatMap(scope => scope.children.map(field => [field.name, field] as const)));
    const inline = createNativeInlinePresentation(scopes, context.nativeVersion, context.use);
    const project = createNativeTextSizeProjector(scopes, context.nativeVersion, context.use);
    const version = Number(context.nativeVersion);
    return (owner: Element, target: NativeLinePresentation, scales: NativeTextScaleContext | Partial<Record<CaptionField, NativeTextScaleContext>>): void => {
        const prefix = owner.name === 'HairPin' ? 'hairpin' : owner.name === 'Pedal' ? 'pedal' : owner.name === 'TextLine' ? target.system ? 'systemTextLine' : 'textLine' : undefined;
        if (!prefix || !(version >= 3 && version < 5)) return;
        const dependency = (fields: readonly Element[], origin: Dependency['origin']): Dependency | undefined => {
            if (!fields.length) return undefined;
            if (fields.some(f => f.children.length || Object.keys(f.attrs).length || !/^[01]$/.test(f.text.trim()) || f.text.trim() !== fields[0].text.trim())) {
                context.gap(fields[0], 'Conflicting or invalid line-caption unit authority remains located without a calculated size.'); return undefined;
            }
            for (const field of fields) context.use(field);
            const field = fields.at(-1)!; return { source: field.location, value: field.text.trim() === '1', origin };
        };
        for (const side of ['begin', 'continue', 'end'] as const) {
            const field: CaptionField = `${side}Text`;
            const scale = 'scope' in scales ? scales : scales[field];
            if (!target[field]) continue;
            const normalized = new Map<Element, Element>(), inherited = new Set<string>(), fields: Element[] = [];
            for (const [suffix, property] of [['FontFace', 'family'], ['FontSize', 'size'], ['FontStyle', 'fontStyle']] as const) {
                const explicit = owner.children.filter(e => e.name === `${side}${suffix}`);
                const sourceFields = explicit.length ? explicit : styles.has(prefix + suffix) ? [styles.get(prefix + suffix)!] : [];
                for (const original of sourceFields) {
                    if (suffix === 'FontStyle' && version < 4 && Number.isInteger(Number(original.text)) && Number(original.text) > 7) {
                        context.gap(original, 'Native 3 line captions have no strike bit; the unsupported mask remains source-owned.'); continue;
                    }
                    const clone = { ...original, name: property }; normalized.set(clone, original); fields.push(clone);
                    if (!explicit.length) inherited.add(key(original.location));
                }
            }
            const inlineRuns = target.textRuns?.[field];
            // Pedal's source-qualified native default is musical markup. Its
            // typed carrier has no authored inline run; use a local role token
            // solely for sizing, never invent a source-markup fact.
            const pedalDefault = owner.name === 'Pedal' && field !== 'continueText' ? target.pedalState?.[field] : undefined;
            // A saved style may repeat that exact default glyph markup.
            const styledDefault = pedalDefault?.origin === 'source-style'
                && styles.get(field === 'beginText' ? 'pedalText' : 'pedalEndText')?.text.trim() === `<sym>${field === 'beginText' ? 'keyboardPedalPed' : 'keyboardPedalUp'}</sym>`;
            const defaultMusic = !inlineRuns?.length && (pedalDefault?.origin === 'native-default' || styledDefault)
                && (field === 'beginText' ? pedalDefault!.value === 'Ped.' : pedalDefault!.value === '*');
            const musicRuns: NativeMusicTextSizeRun[] | undefined = inlineRuns ?? (defaultMusic ? [{ symbolName: field === 'beginText' ? 'keyboardPedalPed' : 'keyboardPedalUp' }] : undefined);
            if (!fields.length && !defaultMusic && !inlineRuns?.some(run => run.textFontSize || run.script || isMusicTextRun(run))) continue;
            const caption = owner.children.find(e => e.name === field);
            if (caption) fields.push({ ...caption, name: 'text' });
            let textDependency: Dependency | undefined, lineDependency: Dependency | undefined, unitUnresolved = false;
            if (defaultMusic || fields.some(f => f.name === 'size') || inlineRuns?.some(run => run.textFontSize || run.script || isMusicTextRun(run))) {
                const defaultField = styles.get('defaultFontSpatiumDependent');
                textDependency = defaultField ? dependency([defaultField], 'source-style') : nativeTextSizeDependency('default', owner);
                if (version >= 4.1) {
                    const explicit = owner.children.filter(f => f.name === 'textSizeIsSpatiumDependent');
                    // Native systemTextLineStyle has no TEXT_SIZE_SPATIUM_DEPENDENT binding;
                    // the value-initialized TextLineBase property remains false.
                    const style = prefix === 'systemTextLine' ? undefined : styles.get(prefix + 'FontSpatiumDependent');
                    lineDependency = explicit.length ? dependency(explicit, 'source-property') : style ? dependency([style], 'source-style') : { source: owner.location, value: prefix !== 'systemTextLine', origin: 'native-default' };
                    unitUnresolved = !lineDependency;
                }
            }
            const recovered: NativeTextPresentation = { ...(target.textRuns?.[field] ? { textRuns: target.textRuns[field] } : {}) };
            applyNativeTextPresentation({ ...owner, name: 'StaffText', children: fields }, recovered, {
                ...context, defaultSizeDependency: textDependency,
                projectFontSize: (element, size, dep) => unitUnresolved || !scale ? undefined : project(element, size, dep, { ...scale, ...(lineDependency ? { lineSpatiumDependent: lineDependency } : {}) }),
                use: field => { context.use(normalized.get(field) ?? field); return field; },
                addMarking: field => context.addMarking(normalized.get(field) ?? field),
                gap: (field, message) => context.gap(normalized.get(field) ?? field, message),
            });
            inline(owner, inlineRuns, recovered.textFontSize, textDependency, !unitUnresolved && scale ? { ...scale, ...(lineDependency ? { lineSpatiumDependent: lineDependency } : {}) } : undefined, 'default');
            // Native modern layout calls setSize after layoutText. Outside edit
            // mode this selects every fragment, using the final cursor size.
            // Keep each original request and locate this later source effect.
            if (lineDependency?.value === false && inlineRuns?.some(run => run.textFontSize?.origin === 'source-markup') && scale) {
                const final = inlineRuns.at(-1)?.textFontSize ?? recovered.textFontSize;
                if (final) {
                    const request = { ...final, pointSize: project({ ...owner, name: 'StaffText', children: [] }, final, textDependency, { ...scale, lineSpatiumDependent: lineDependency }) };
                    if (!request.pointSize) delete request.pointSize;
                    for (const run of inlineRuns) run.lineFontSize = { source: lineDependency.source, origin: 'derived-native-line-reset', request };
                }
            }
            if (musicRuns && scale && !unitUnresolved) {
                const musicOwner = { ...owner, children: owner.children.map(f => f.name === `${side}TextMusicSymbolsSize` ? { ...f, name: 'musicSymbolSize' } : f) };
                const music = createNativeMusicTextSize(scopes, context.nativeVersion, f => context.use(owner.children.find(original => original.location === f.location) ?? f));
                for (const run of musicRuns) {
                    if (!isMusicTextRun(run)) continue;
                    delete run.musicFontSize;
                    music(musicOwner, run, recovered.textFontSize, textDependency, { ...scale, ...(lineDependency ? { lineSpatiumDependent: lineDependency } : {}) }, prefix);
                }
                const glyphSizes = musicRuns.filter(isMusicTextRun).map(run => run.musicFontSize);
                if (glyphSizes[0] && glyphSizes.every(size => size?.pointSize?.value === glyphSizes[0]!.pointSize?.value)) (target.textMusicFontSizes ??= {})[field] = glyphSizes[0];
            }
            if (recovered.textFontFamily) {
                if (inherited.has(key(recovered.textFontFamily.source))) recovered.textFontFamily.origin = 'source-style';
                (target.textFontFamilies ??= {})[field] = recovered.textFontFamily;
            }
            if (recovered.textFontStyle) {
                if (inherited.has(key(recovered.textFontStyle.source))) recovered.textFontStyle.origin = 'source-style';
                (target.textFontStyles ??= {})[field] = recovered.textFontStyle;
            }
            if (recovered.textFontSize) {
                if (inherited.has(key(recovered.textFontSize.source))) recovered.textFontSize.origin = 'source-style';
                (target.textFontSizes ??= {})[field] = recovered.textFontSize;
            }
        }
    };
}

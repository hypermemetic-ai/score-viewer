import { child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { add, compare, equal, mul, q, type Rational } from '../../core/rational.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import type { MusicalScore, Pitch } from '../../core/model.js';
import { NativeBudget } from './budget.js';
import type { NativeViews } from './views.js';

type Entry = NativeViews['entries'][number];
type Octaves = -3 | -2 | -1 | 1 | 2 | 3;
interface Point { staff: Staff; measure: number; voice: number; position: Rational; clock: Rational }
interface Member { node: Element; point: Point }
interface Line { node: Element; point: Point; next?: Element; prev?: Element; octaves?: Octaves; play: boolean }
interface Staff { entry: Entry; node: Element; id: number; starts: Rational[]; durations: Rational[]; members: Member[]; lines: Line[]; parsed: boolean; hasOttava: boolean; hasLinks: boolean }
const key = (source: Location) => `${source.member}#${source.path}`;
const clockKey = (clock: Rational) => `${clock.n}/${clock.d}`;
// Native staff pitch-offset maps use rounded integer ticks (480 per quarter),
// independently of the exact event clock retained in our score and MusicXML.
const nativeTick = (clock: Rational): number => {
    const n = BigInt(clock.n), d = BigInt(clock.d), sign = n < 0n ? -1n : 1n;
    const tick = sign * ((sign * n * 480n + d / 2n) / d);
    if (tick < -2147483648n || tick > 2147483647n) return refuse('native-linked-ottava-clock', 'Foreign native octave map exceeds its signed integer tick representation.');
    return Number(tick);
};
const durations: Record<string, Rational> = { longa: q(16), breve: q(8), whole: q(4), half: q(2), quarter: q(1), eighth: q(1, 2), '16th': q(1, 4), '32nd': q(1, 8), '64th': q(1, 16), '128th': q(1, 32), '256th': q(1, 64), '512th': q(1, 128), '1024th': q(1, 256) };
const graceNames = new Set(['appoggiatura', 'acciaccatura', 'grace4', 'grace16', 'grace32', 'grace8after', 'grace16after', 'grace32after']);
const neutral = new Set(['Clef', 'KeySig', 'Beam', 'BarLine', 'Segment', 'Breath', 'Fermata', 'Harmony', 'FretDiagram', 'TremoloBar', 'Capo', 'InstrumentChange', 'Symbol', 'StaffText', 'SystemText', 'Expression', 'Text', 'RehearsalMark', 'Dynamic', 'Tempo', 'PlayTechAnnotation', 'FiguredBass', 'Sticking', 'Spanner']);
function scalar(owner: Element, name: string): string | undefined {
    const node = child(owner, name);
    if (!node) return;
    if (node.children.length || Object.keys(node.attrs).length) refuse('native-linked-ottava-source', 'Foreign octave dependencies require plain, unique source timing and identity fields.', node.location);
    return node.text.trim();
}
function fraction(value: string, source: Element): Rational {
    if (!/^-?\d{1,9}\/[1-9]\d{0,8}$/.test(value)) refuse('native-linked-ottava-clock', 'Foreign octave dependencies require a bounded exact source fraction.', source.location);
    const [n, d] = value.split('/').map(Number); return q(n, d);
}
function number(owner: Element, name: string, min: number, max: number, fallback: number): number {
    const value = scalar(owner, name); return value === undefined ? fallback : integer(value, min, max, child(owner, name)!.location);
}
const subtree = (root: Element): Element[] => {
    const result: Element[] = [], pending = [root];
    while (pending.length) { const node = pending.pop()!; result.push(node); for (let i = node.children.length - 1; i >= 0; i--) pending.push(node.children[i]); }
    return result;
};

/** Recover only foreign timing/identity dependencies, never foreign pitches or musical admission.
 * Native Note::linkedOttavaPitchOffset consults linked logical staffs at the selected note's clock.
 */
export function recoverLinkedViewOttava(score: MusicalScore, inventory: NativeViews, selected: Entry, version: string, findings: Finding[]): void {
    if (selected.info.primary || Number(version) < 4) return;
    const budget = new NativeBudget(), staffs: Staff[] = [], byStaff = new Map<Entry, Map<number, Staff>>(), sourceOrder = new Map<string, number>();
    for (const entry of inventory.entries) {
        const local = new Map<number, Staff>(); byStaff.set(entry, local);
        for (const node of children(entry.node, 'Staff')) {
            const nodes = subtree(node), id = integer(node.attrs.id, 1, 256, node.location);
            const staff: Staff = { entry, node, id, starts: [], durations: [], members: [], lines: [], parsed: false,
                hasOttava: nodes.some(n => n.name === 'Spanner' && n.attrs.type === 'Ottava'),
                hasLinks: nodes.some(n => ['linkedMain', 'linked', 'linkedTo'].includes(n.name)) };
            staffs.push(staff); local.set(id, staff);
            for (const node of nodes) if (node.name === 'Note') sourceOrder.set(key(node.location), sourceOrder.size);
        }
    }
    if (!staffs.some(staff => staff.hasOttava) || !selected.links.some(link => link.kind === 'Note')) return;
    const parse = (staff: Staff): void => {
        if (staff.parsed) return; staff.parsed = true;
        let clock = q(0), meter = q(4), stretch = q(1);
        const measures = children(staff.node, 'Measure').filter(m => number(m, 'multiMeasureRest', 0, 10000, 0) === 0);
        const signature = (node: Element, position: Rational): void => {
            if (number(node, 'isCourtesy', 0, 1, 0) || Number(version) <= 4 && position.n > 0) return;
            meter = q(number(node, 'sigN', 1, 128, 4) * 4, number(node, 'sigD', 1, 1024, 4));
            stretch = q(number(node, 'stretchN', 1, 100000, 1), number(node, 'stretchD', 1, 100000, 1));
        };
        for (const [mi, measure] of measures.entries()) {
            budget.add('timelines', 1, measure.location);
            const voices = children(measure, 'voice');
            if (!voices.length || voices.length > 4) refuse('native-linked-ottava-clock', 'Foreign octave staff needs one to four explicit source voice slots.', measure.location);
            for (const voice of voices) for (const node of voice.children) {
                if (node.name === 'TimeSig') signature(node, q(0));
                if (['Chord', 'Rest'].includes(node.name) || node.name === 'location' && fraction(scalar(node, 'fractions') ?? '0/1', node).n !== 0) break;
            }
            const initialMeter = meter, initialStretch = stretch;
            const duration = measure.attrs.len ? mul(fraction(measure.attrs.len, measure), q(4)) : mul(meter, q(stretch.d, stretch.n));
            if (duration.n <= 0) refuse('native-linked-ottava-clock', 'Foreign source measure extent must be positive.', measure.location);
            staff.starts.push(clock); staff.durations.push(duration);
            const changes: { position: Rational; meter: Rational; stretch: Rational }[] = [];
            for (const [vi, voice] of voices.entries()) {
                let position = q(0), previousChange = 0, pendingPair = false; const tuplets: Rational[] = [];
                meter = initialMeter; stretch = initialStretch;
                const inherited = changes.slice().sort((a, b) => compare(a.position, b.position));
                const record = (owner: Element): void => {
                    const point: Point = { staff, measure: mi, voice: vi, position, clock: add(clock, position) };
                    for (const node of subtree(owner)) {
                        if (['Chord', 'Rest', 'Note', 'Ottava'].includes(node.name)) {
                            const track = scalar(node, 'track');
                            if (track !== undefined && integer(track, 0, 1023, child(node, 'track')!.location) !== (staff.id - 1) * 4 + vi)
                                refuse('native-linked-ottava-source', 'Foreign source track override conflicts with this timing/identity staff owner.', child(node, 'track')!.location);
                        }
                        if (node.name === 'Note' || child(node, 'linkedMain') || child(node, 'linked') || node.name !== 'Staff' && child(node, 'linkedTo')) {
                            budget.add('components', 1, node.location);
                            staff.members.push({ node, point });
                        }
                        if (node.name === 'Spanner' && node.attrs.type === 'Ottava') {
                            budget.add('relations', 1, node.location);
                            const content = child(node, 'Ottava'), next = child(node, 'next'), prev = child(node, 'prev');
                            const subtype = content ? scalar(content, 'subtype') ?? '0' : undefined;
                            const octaves: Record<string, Octaves> = { '0': 1, '1': -1, '2': 2, '3': -2, '4': 3, '5': -3, '8va': 1, '8vb': -1, '15ma': 2, '15mb': -2, '22ma': 3, '22mb': -3 };
                            if (!next && !prev || next && (!content || subtype === undefined || !Object.hasOwn(octaves, subtype))) refuse('native-linked-ottava-source', 'Foreign octave relation needs a known octave amount and explicit endpoint references.', node.location);
                            staff.lines.push({ node, point, next, prev, ...(subtype !== undefined ? { octaves: octaves[subtype] } : {}), play: !content || number(content, 'play', 0, 1, 1) === 1 });
                        }
                    }
                };
                for (const node of voice.children) {
                    while (previousChange < inherited.length && compare(inherited[previousChange].position, position) <= 0) { ({ meter, stretch } = inherited[previousChange++]); }
                    if (node.name === 'TimeSig') { signature(node, position); changes.push({ position, meter, stretch }); record(node); }
                    else if (node.name === 'location') {
                        if (node.children.some(c => !['fractions', 'timeTick'].includes(c.name))) refuse('native-linked-ottava-clock', 'Foreign voice cursor has unresolved non-time movement.', node.location);
                        position = add(position, mul(fraction(scalar(node, 'fractions') ?? '0/1', node), q(4)));
                        if (position.n < 0) refuse('native-linked-ottava-clock', 'Foreign voice cursor precedes its source measure.', node.location);
                    } else if (node.name === 'Tuplet') {
                        record(node); if (tuplets.length >= 16) refuse('native-linked-ottava-clock', 'Foreign tuplet nesting exceeds the bounded source profile.', node.location);
                        tuplets.push(q(number(node, 'normalNotes', 1, 128, 1), number(node, 'actualNotes', 1, 128, 1)));
                    } else if (node.name === 'endTuplet') { if (!tuplets.pop()) refuse('native-linked-ottava-clock', 'Foreign tuplet clock has an unmatched endpoint.', node.location); }
                    else if (node.name === 'Chord' || node.name === 'Rest' || node.name === 'MeasureRepeat') {
                        budget.add('events', 1, node.location); record(node);
                        if (node.children.some(n => graceNames.has(n.name))) continue;
                        const type = scalar(node, 'durationType'), encoded = scalar(node, 'duration'), dots = number(node, 'dots', 0, 4, 0);
                        const tremolo = node.children.find(n => ['Tremolo', 'TremoloTwoChord'].includes(n.name)), pairStart = !!tremolo && /^c(?:8|16|32|64)$/.test(scalar(tremolo, 'subtype') ?? '');
                        if ((pairStart || pendingPair) && encoded === undefined) refuse('native-linked-ottava-clock', 'Foreign paired tremolo needs its explicit elapsed duration; its displayed note value cannot substitute for elapsed time.', node.location);
                        pendingPair = pairStart;
                        let elapsed = encoded !== undefined ? mul(fraction(encoded, node), q(4)) : type === 'measure' || node.name === 'MeasureRepeat' ? mul(duration, stretch) : type && Object.hasOwn(durations, type) ? mul(durations[type], q(2 ** (dots + 1) - 1, 2 ** dots)) : undefined;
                        if (!elapsed || elapsed.n <= 0) return refuse('native-linked-ottava-clock', 'Foreign event needs an exact encoded or conventional source duration.', node.location);
                        for (const ratio of tuplets) elapsed = mul(elapsed, ratio);
                        position = add(position, mul(elapsed, q(stretch.d, stretch.n)));
                    } else if (neutral.has(node.name)) record(node);
                    else refuse('native-linked-ottava-clock', 'An unresolved foreign voice element may affect the octave dependency clock.', node.location);
                }
                if (tuplets.length) refuse('native-linked-ottava-clock', 'Foreign tuplet clock is unclosed.', voice.location);
                if (pendingPair) refuse('native-linked-ottava-clock', 'Foreign paired tremolo clock is unclosed.', voice.location);
            }
            clock = add(clock, duration);
        }
    };
    // Resolve explicit EID edges without admitting any foreign music. Legacy membership
    // uses the native absolute-time/local-index model, not pitch or note-order guesses.
    const parent = new Map<string, string>();
    const root = (id: string): string => { const path: string[] = []; let current = id; while (parent.has(current)) { path.push(current); current = parent.get(current)!; } for (const part of path) parent.set(part, current); return current; };
    const join = (a: string, b: string): void => { const x = root(a), y = root(b); if (x !== y) parent.set(x, y); };
    const eidLinks = inventory.entries.flatMap(entry => entry.links).filter(link => link.kind === 'Note' && link.targetEid);
    for (const link of eidLinks) {
        const owner = key(link.owner), target = key(link.targetEid!.target);
        if ((sourceOrder.get(target) ?? Infinity) < (sourceOrder.get(owner) ?? -1)) join(owner, target);
        else { budget.add('markings', 1, link.source); findings.push({ disposition: 'preserved', code: 'native-linked-ottava-forward-eid', location: link.source, message: 'The source EID target is not available when the native reader encounters this link. The exact unresolved reference is retained; no linked octave inheritance is invented.' }); }
    }
    const legacy = inventory.entries.some(entry => entry.links.some(link => link.kind === 'Note' && link.form === 'legacy-membership'));
    if (legacy) {
        for (const staff of staffs) if (staff.hasLinks) parse(staff);
        const lists = new Map<string, { items: { owner: Member; location: string }[]; first: Map<string, number> }>(); let previous = '', localIndex = -1;
        const assign = (location: string): number => { localIndex = location === previous ? localIndex + 1 : 0; previous = location; return localIndex; };
        const links = new Map(inventory.entries.flatMap(entry => entry.links).map(link => [key(link.owner), link]));
        for (const staff of staffs) for (const member of staff.members) {
            const main = child(member.node, 'linkedMain'), link = links.get(key(member.node.location));
            if (!main && link?.form !== 'legacy-membership') continue;
            const targetEntry = main || link!.score ? staff.entry : inventory.entries[0];
            const declaration = staff.entry.info.parts.flatMap(part => part.staffs).find(s => s.id === staff.id)!;
            const fields = new Map(link?.coordinates?.fields.map(field => [field.name, field.value]) ?? []);
            const targetStaff = (main ? staff.id : declaration.primaryStaff?.id ?? staff.id) + Number(fields.get('staves') ?? 0);
            const voice = member.point.voice + Number(fields.get('voices') ?? 0), measure = Number(fields.get('measures') ?? 0);
            const clock = add(member.point.clock, fields.has('fractions') ? mul(fraction(fields.get('fractions')!, member.node), q(4)) : q(0));
            const location = `${targetStaff}:${voice}:${measure}:${clockKey(clock)}:${fields.get('grace') ?? 'unset'}:${fields.get('notes') ?? '0'}`;
            // The native index is shared between score contexts; its location does not include score ID.
            const index = assign(location) + (link?.indexDiff?.value ?? 0), scope = `${targetEntry.info.id}:${targetStaff}`, list = lists.get(scope) ?? { items: [], first: new Map<string, number>() };
            if (main) { if (!list.first.has(location)) list.first.set(location, list.items.length); list.items.push({ owner: member, location }); lists.set(scope, list); continue; }
            if (list.items.at(-1)?.location === location) list.items.push(list.items.at(-1)!);
            const first = list.first.get(location), peer = first === undefined || index < 0 ? undefined : list.items[first + index];
            if (peer?.location === location && peer.owner.node.name === member.node.name) join(key(member.node.location), key(peer.owner.node.location));
            else if (member.node.name === 'Note') { budget.add('markings', 1, link!.source); findings.push({ disposition: 'preserved', code: 'native-linked-ottava-unresolved-membership', location: link!.source, message: 'The legacy native membership does not resolve to a same-kind source peer at its exact absolute time and local index. Native link failure contributes no inherited octave; the reference remains captured.' }); }
        }
    }
    const peers = new Map<string, { source: Location; staff: Staff }[]>(), connected = new Set([...parent.keys(), ...parent.values()]);
    for (const entry of inventory.entries) for (const staff of byStaff.get(entry)!.values()) for (const node of subtree(staff.node)) if (node.name === 'Note') {
        const id = key(node.location); if (!connected.has(id)) continue; const group = root(id);
        const list = peers.get(group) ?? []; list.push({ source: node.location, staff }); peers.set(group, list);
    }
    const offsetCache = new Map<Staff, { tick: number; octaves: Octaves | 0; source: Location }[]>();
    const receiversByStaff = new Map<Staff, Map<string, Line[]>>(), endpointCache = new Map<Element, Point>();
    const pointKey = (point: Point) => `${point.voice}:${clockKey(point.clock)}`;
    const offsets = (staff: Staff): { tick: number; octaves: Octaves | 0; source: Location }[] => {
        const cached = offsetCache.get(staff); if (cached) return cached;
        if (!staff.hasOttava) { offsetCache.set(staff, []); return []; }
        parse(staff);
        const target = (line: Line, endpoint: Element): Point => {
            const cached = endpointCache.get(endpoint); if (cached) return cached;
            const location = child(endpoint, 'location', true)!;
            if (location.children.some(c => !['staves', 'voices', 'measures', 'fractions', 'grace', 'notes'].includes(c.name))) refuse('native-linked-ottava-endpoint', 'Foreign octave endpoint contains unresolved relative coordinates.', location.location);
            const destination = byStaff.get(line.point.staff.entry)!.get(line.point.staff.id + number(location, 'staves', -255, 255, 0));
            if (!destination) return refuse('native-linked-ottava-endpoint', 'Foreign octave endpoint leaves declared source staffs.', location.location);
            parse(destination);
            const measure = line.point.measure + number(location, 'measures', -100000, 100000, 0), position = add(line.point.position, mul(fraction(scalar(location, 'fractions') ?? '0/1', location), q(4))), voice = line.point.voice + number(location, 'voices', -3, 3, 0);
            const start = destination.starts[measure];
            if (!start || position.n < 0 || compare(position, destination.durations[measure]) > 0 || voice < 0 || voice > 3) return refuse('native-linked-ottava-endpoint', 'Foreign octave endpoint has no exact source measure/voice clock.', location.location);
            const result = { staff: destination, measure, position, voice, clock: add(start, position) }; endpointCache.set(endpoint, result); return result;
        };
        const samePoint = (a: Point, b: Point): boolean => a.staff === b.staff && a.voice === b.voice && equal(a.clock, b.clock);
        const transitions = new Map<number, { tick: number; octaves: Octaves | 0; source: Location }>();
        const starts = staff.lines.filter(line => line.next).sort((a, b) => nativeTick(a.point.clock) - nativeTick(b.point.clock));
        for (const line of starts) {
            const end = target(line, line.next!); let index = receiversByStaff.get(end.staff);
            if (!index) { index = new Map(); for (const other of end.staff.lines) if (other.prev) { const key = pointKey(other.point), list = index.get(key) ?? []; list.push(other); index.set(key, list); } receiversByStaff.set(end.staff, index); }
            const receivers = (index.get(pointKey(end)) ?? []).filter(other => samePoint(target(other, other.prev!), line.point));
            if (receivers.length !== 1 || compare(end.clock, line.point.clock) < 0) refuse('native-linked-ottava-endpoint', 'Foreign octave dependency requires one reciprocal source endpoint and a nonnegative span.', line.node.location);
            if (!line.play) continue;
            const startTick = nativeTick(line.point.clock), endTick = nativeTick(end.clock);
            transitions.set(startTick, { tick: startTick, octaves: line.octaves!, source: line.node.location });
            transitions.set(endTick, { tick: endTick, octaves: 0, source: receivers[0].node.location });
        }
        const result = [...transitions.values()].sort((a, b) => a.tick - b.tick); offsetCache.set(staff, result); return result;
    };
    const at = (staff: Staff, clock: Rational) => { const timeline = offsets(staff), tick = nativeTick(clock); let lo = 0, hi = timeline.length; while (lo < hi) { const mid = lo + Math.floor((hi - lo) / 2); if (timeline[mid].tick <= tick) lo = mid + 1; else hi = mid; } return timeline[lo - 1]; };
    const shifted = (pitch: Pitch, octaves: Octaves, source: Location): Pitch => {
        const octave = pitch.octave + octaves;
        if (octave < 0 || octave > 9) return refuse('native-linked-ottava-register', 'Source-derived linked octave exceeds the MusicXML pitch octave range.', source);
        return { ...pitch, octave, midi: pitch.midi + octaves * 12, origin: 'inferred' };
    };
    for (const part of score.parts) {
        let clock = q(0);
        for (const measure of part.measures) {
            const events = new Map(measure.voices.flat().map(event => [event.id, event]));
            for (const voice of measure.voices) for (const event of voice) for (const note of event.notes) {
                if (note.kind === 'unpitched' || note.octaveShift) continue;
                const group = peers.get(root(key(note.source))); if (!group) continue;
                const onset = add(clock, event.grace ? events.get(event.grace.hostId)!.start : event.start);
                for (const peer of group) {
                    const inherited = at(peer.staff, onset); if (!inherited?.octaves) continue;
                    budget.add('markings', 1, note.source);
                    note.linkedOctaveShift = { source: inherited.source, peer: peer.source, octaves: inherited.octaves, clock: onset, written: { ...note.written }, ...(note.sounding ? { sounding: { ...note.sounding } } : {}), ...(note.referenceSounding ? { referenceSounding: { ...note.referenceSounding } } : {}) };
                    note.written = shifted(note.written, inherited.octaves, note.source); if (note.sounding) note.sounding = shifted(note.sounding, inherited.octaves, note.source);
                    if (note.referenceSounding) note.referenceSounding = shifted(note.referenceSounding, inherited.octaves, note.source);
                    findings.push({ disposition: 'inferred', code: 'native-linked-ottava-register', location: note.source, message: 'The selected note retains its own source pitch and spelling; its register is derived from the first active linked logical staff at this note clock, as the native reader does. No foreign octave line or peer pitch is copied.', fact: note.linkedOctaveShift });
                    break;
                }
            }
            clock = add(clock, measure.duration);
        }
    }
}

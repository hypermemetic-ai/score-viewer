import { createNativeMusicTextSize, isMusicTextRun } from './music-text-size.js';
import type { TextFontSize, TextRun } from '../../core/model.js';
import type { SourceElement as Element } from '../../core/source-xml.js';
import { createNativeTextSizeProjector, type NativeTextScaleContext } from './text-size.js';

type Dependency = NonNullable<TextFontSize['pointSize']>['spatiumDependent'];
/** Default font requests are supplied only when a script needs an explicit .6
 * point-size ratio. These are native registry facts, not installed font metrics. */
const defaults: Readonly<Record<string, number>> = {
    default: 10, staff: 10, system: 10, expression: 10, lyricsOdd: 10, lyricsEven: 10,
    tempo: 12, metronome: 12, rehearsalMark: 14, fingering: 8, lhGuitarFingering: 8, rhGuitarFingering: 8,
    title: 22, composer: 10, frame: 10, chordSymbolA: 10,
    ...Object.fromEntries(Array.from({ length: 12 }, (_, i) => [`user${i + 1}`, 10])),
};
export function createNativeInlinePresentation(scopes: readonly Element[], nativeVersion?: string, use?: (field: Element) => unknown) {
    const project = createNativeTextSizeProjector(scopes, nativeVersion, use);
    const music = createNativeMusicTextSize(scopes, nativeVersion, use);
    const selector = scopes.flatMap(scope => scope.children).filter(f => f.name === 'defaultsVersion').at(-1);
    const legacy = Number(nativeVersion) < 3.02 || ['114', '206', '301'].includes(selector?.text.trim() ?? '');
    return (owner: Element, runs: TextRun[] | undefined, base: TextFontSize | undefined, dependency: Dependency | undefined, scale: NativeTextScaleContext | undefined, prefix?: string): void => {
        if (!runs) return;
        for (const run of runs) {
            // A canonical/private-use music glyph has a different font law.
            if (isMusicTextRun(run)) continue;
            let size = run.textFontSize;
            if (!size && (run.script || runs.some(isMusicTextRun))) {
                size = base;
                if (!size && prefix && Object.hasOwn(defaults, prefix) && (!selector || !selector.children.length && !Object.keys(selector.attrs).length && ['114', '206', '301', '302', '400', '410', '420', '430', '440', '450', '460', '470'].includes(selector.text.trim()))) {
                    const value = legacy && ['expression', 'lyricsOdd', 'lyricsEven'].includes(prefix) ? 11 : legacy && prefix === 'title' ? 24 : legacy && ['composer', 'frame', 'chordSymbolA'].includes(prefix) ? 12 : prefix === 'chordSymbolA' && Number(nativeVersion) < 4 ? 11 : defaults[prefix];
                    size = { source: selector?.location ?? owner.location, rawValue: String(value), value, origin: 'native-default' };
                }
            }
            if (!size) continue;
            // A run's ordinary role is already established; neighboring symbols
            // do not invalidate its independent ordinary TextFragment size law.
            const ordinary = { ...owner, name: 'StaffText', children: owner.children.filter(f => f.name !== 'text') };
            const projected = { ...size, pointSize: project(ordinary, size, dependency, scale) };
            if (!projected.pointSize) delete projected.pointSize;
            run.textFontSize = projected;
            if (run.script && projected.pointSize) run.script = { ...run.script, projection: { origin: 'derived-readable-layout', relativeY: run.script.value === 'super' ? 6 : run.script.value === 'sub' ? -4 : 0, sizeFactor: run.script.value === 'normal' ? 1 : .6 } };
        }
        for (const run of runs) music(owner, run, base, dependency, scale, prefix);
    };
}

import type {MusicalEvent,MusicalNote} from '../../core/model.js';
import {refuse,type Finding,type Location} from '../../core/report.js';

/** A source gesture on an unpitched instrument is not an encoded musical pitch interval. */
export function percussionInstruction(event:MusicalEvent,source:Location,text:string,native:Record<string,unknown>,findings:Finding[]):void {
    (event.performerInstructions??=[]).push({source,kind:'percussion-technique',text,nativeValue:JSON.stringify(native)});
    findings.push({disposition:'preserved',code:'binary-percussion-technique-instruction',message:'The located source technique retains an instrument-qualified standard instruction without inventing a pitched endpoint, acoustic interval or extra attack.',location:source});
}
export function binaryPercussionTechniques(facts:Record<string,number>,note:MusicalNote,event:MusicalEvent,name:string,version:number,slide:number,locate:(name:string)=>Location,findings:Finding[],beatFlags=0):void {
    if(slide)percussionInstruction(event,locate('slide-type'),`${name}: ${slide===1?'shift':'legato'} slide`,{noteSource:note.source,slide},findings);
    if(facts['note-effect-flags']&2)percussionInstruction(event,locate('note-effect-flags'),`${name}: hammer-on / pull-off`,{noteSource:note.source,hammerPull:true},findings);
    const harmonic=facts['harmonic-type']??(version<400?beatFlags&4?1:beatFlags&8?2:0:0);
    if(harmonic){
        const types:Record<number,NonNullable<MusicalNote['harmonic']>['type']>={1:'natural',2:'artificial',3:'tap',4:'pinch',5:'semi',15:'artificial',17:'artificial',22:'artificial'};
        if(!types[harmonic]||version>=500&&harmonic>5||version>=400&&version<500&&harmonic===2)refuse('harmonic-type','Unknown binary harmonic subtype.',locate('harmonic-type'));
        if(version>=500&&harmonic===2&&(![0,2,4,5,7,9,11].includes(facts['harmonic-tone'])||![255,0,1].includes(facts['harmonic-key'])||![0,1,2].includes(facts['harmonic-octave'])))refuse('harmonic-pitch','Invalid source harmonic tuple.',locate('harmonic-type'));
        if(version>=500&&harmonic===3&&(facts['harmonic-tap-fret']<0||facts['harmonic-tap-fret']>255))refuse('harmonic-fret','Invalid source harmonic touch operand.',locate('harmonic-tap-fret'));
        note.harmonic={source:locate('harmonic-type'),type:types[harmonic]};
        percussionInstruction(event,locate('harmonic-type'),`${name}: ${types[harmonic]} harmonic`,{noteSource:note.source,...Object.fromEntries(Object.entries(facts).filter(([key])=>key.startsWith('harmonic-'))),type:harmonic},findings);
    }
}

import type { StaffFact } from '../../core/model.js';
import { child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { refuse } from '../../core/report.js';
import { readNativeHeadScheme } from './head-schemes.js';

/** A serialized StaffType starts from native defaults; it is not a patch to its predecessor. */
export function readNativeStaffType(type: Element, context: {
    use: (e: Element) => void; omit: (e: Element, reason: string) => void;
    smallMagnification?: { source: Element['location']; value: string };
    readColor: (e: Element) => StaffFact['sourceColor'];
}): Pick<StaffFact, 'kind' | 'lines' | 'staffSize' | 'sourceColor' | 'notation' | 'lineVisibility' | 'tablature' | 'noteheadScheme' | 'percussionStepOffset'> {
    if (type.text.trim() || Object.keys(type.attrs).some(key => key !== 'group') || !['pitched','tablature','percussion'].includes(type.attrs.group))
        refuse('native-staff-type', 'A staff type needs one explicit standard, TAB or percussion group.', type.location);
    const field = (name: string) => {
        const values=children(type,name); if(values.length>1) refuse('native-staff-type','A staff type property must have one source authority.',values[1].location);
        const value=values[0]; if(value && (value.children.length || Object.keys(value.attrs).length)) refuse('native-staff-type','Staff type properties must be plain scalars.',value.location);
        if(value)context.use(value); return value;
    };
    // The caller admits the StaffType group attribute after this validation.
    const name=field('name'); if(name && name.text.length>256) refuse('native-staff-type','Staff type name exceeds its bounded field.',name.location);
    const line=field('lines'), lines=line?integer(line.text,0,16,line.location):5;
    const smallField=field('small'), small=smallField?integer(smallField.text,0,1,smallField.location)===1:false;
    const mag=field('mag'), user=mag?Number(mag.text):1;
    if(!Number.isFinite(user)||user<=0||user>4) refuse('native-staff-type','Staff magnification must be positive and bounded.',mag?.location??type.location);
    const style=context.smallMagnification, magnification={source:style?.source??type.location,value:style?Number(style.value):0.7,origin:style?'source-style' as const:'native-default' as const};
    const notation: NonNullable<StaffFact['notation']>={source:type.location};
    const rawHeadScheme=field('noteheadScheme'),noteheadScheme=rawHeadScheme?readNativeHeadScheme(rawHeadScheme):undefined;
    const flags={stemless:'stemless',clef:'showClef',keysig:'showKeySignature',timesig:'showTimeSignature',barlines:'showBarlines',ledgerlines:'showLedgerLines',showRests:'showRests',showBackTied:'showBackTied',showTabFingering:'showTabFingering',upsideDown:'upsideDown',useNumbers:'useNumbers'} as const;
    if(type.attrs.group==='tablature') for(const [key,value] of Object.entries({showKeySignature:false,showRests:false,showTabFingering:false,showBackTied:true}))
        notation[key as 'showKeySignature'|'showRests'|'showTabFingering'|'showBackTied']={source:type.location,value,origin:'native-default'};
    // Native readers apply this compatibility default in serialized order. An
    // explicit showBackTied before stemless is intentionally replaced by it.
    for(const property of type.children) {
        const key=flags[property.name as keyof typeof flags] ?? (property.name==='slashStyle'?'stemless':undefined); if(!key)continue;
        const encoded=field(property.name)!,value=integer(encoded.text,0,1,encoded.location)===1;
        notation[key]={source:encoded.location,value,origin:'source'};
        if(key==='stemless' && type.attrs.group==='tablature') notation.showBackTied={source:encoded.location,value:!value,origin:'native-stemless-default'};
    }
    let tablature:StaffFact['tablature'];
    if(type.attrs.group==='tablature') {
        const bool=(name:string,fallback:boolean)=>{const raw=field(name);return {source:raw?.location??type.location,value:raw?integer(raw.text,0,1,raw.location)===1:fallback,origin:raw?'source' as const:'native-default' as const};};
        const enumeration=<T extends number>(name:string,maximum:T)=>{const raw=field(name);return {source:raw?.location??type.location,value:(raw?integer(raw.text,0,maximum,raw.location):0) as T,origin:raw?'source' as const:'native-default' as const};};
        tablature={source:type.location,onLines:bool('onLines',true),linesThrough:bool('linesThrough',false),stemsDown:bool('stemsDown',true),stemsThrough:bool('stemsThrough',true),durations:bool('durations',false),minimStyle:enumeration<0|1|2>('minimStyle',2),symbolRepeat:enumeration<0|1|2|3>('symbolRepeat',3)};
        for(const key of ['durationFontName','fretFontName','fretTextStyle'] as const) {const raw=field(key);if(raw){if(!raw.text.trim()||raw.text.length>256)refuse('native-staff-type','TAB font selectors must be bounded nonempty text.',raw.location);tablature[key]={source:raw.location,value:raw.text};}}
        for(const key of ['durationFontSize','fretFontSize'] as const) {const raw=field(key);if(raw){const value=Number(raw.text);if(!Number.isFinite(value)||value<=0||value>1000)refuse('native-staff-type','TAB font size must be positive and bounded.',raw.location);tablature[key]={source:raw.location,value};}}
        const preset=field('fretPresetIdx');if(preset)tablature.fretPresetIdx={source:preset.location,value:integer(preset.text,0,255,preset.location)};
        const textStyle=field('fretUseTextStyle');if(textStyle)tablature.fretUseTextStyle={source:textStyle.location,value:integer(textStyle.text,0,1,textStyle.location)===1};
        for(const key of ['durationFontY','fretFontY']) {const raw=field(key);if(raw){if(!Number.isFinite(Number(raw.text)))refuse('native-staff-type','TAB font placement must be finite.',raw.location);context.omit(raw,'native-staff-type-geometry');}}
    }
    const step = field('stepOffset');
    const percussionStepOffset = type.attrs.group === 'percussion' ? {source:step?.location??type.location,value:step?integer(step.text,-64,64,step.location):0} : undefined;
    if(step && !percussionStepOffset) {if(!Number.isFinite(Number(step.text)))refuse('native-staff-type','Staff geometry must be finite source data.',step.location);context.omit(step,'native-staff-type-geometry');}
    for(const encoded of ['lineDistance','yoffset']) {const value=field(encoded); if(value) {if(!Number.isFinite(Number(value.text)))refuse('native-staff-type','Staff geometry must be finite source data.',value.location);context.omit(value,'native-staff-type-geometry');}}
    const sourceColor=context.readColor(type), invisible=field('invisible');
    const lineVisibility=invisible?{source:invisible.location,value:integer(invisible.text,0,1,invisible.location)!==1}:undefined;
    return {...(percussionStepOffset?{percussionStepOffset}:{}),...(noteheadScheme?{noteheadScheme}:{}),...(tablature?{tablature}:{}),...(lineVisibility?{lineVisibility}:{}),kind:type.attrs.group as StaffFact['kind'],lines,notation,staffSize:{source:smallField?.location??mag?.location??type.location,small,percent:user*(small?magnification.value:1)*100,magnification,...(mag?{userMagnification:{source:mag.location,value:user}}:{})},...(sourceColor?{sourceColor}:{})};
}

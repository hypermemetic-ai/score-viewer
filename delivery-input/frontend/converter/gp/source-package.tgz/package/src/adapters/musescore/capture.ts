import { createHash } from 'node:crypto';
import { captureZip } from '../../core/source-zip-node.js';
import { captureNative as capturePortable, type NativeHost, type ParsedNativeCapture } from './capture-core.js';
export * from './capture-core.js';

/** Node host: native hashing, zlib inflation and process RSS. */
export const nodeHost: NativeHost = {
    sha256: bytes => createHash('sha256').update(bytes).digest('hex'),
    zipMembers: captureZip,
    peakRssKiB: () => process.resourceUsage().maxRSS
};
export function captureNative(bytes: Uint8Array, options: { retainViewMusic?: boolean } = {}): ParsedNativeCapture {
    return capturePortable(bytes, nodeHost, options);
}

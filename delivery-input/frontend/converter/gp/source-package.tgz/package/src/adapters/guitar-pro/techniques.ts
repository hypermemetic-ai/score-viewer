import type { MusicalEvent, MusicalRelation, NoteDetails, Part, Pitch } from '../../core/model.js';
import { add, compare, decimal, equal, mul, q, type Rational } from '../../core/rational.js';
import { refuse, type Location } from '../../core/report.js';
import { child, integer, value, type Element } from './xml.js';

export const noteTechniqueFields: Record<string, string> = {
    ShowStringNumber: 'Enable', Harmonic: 'Enable', PalmMuted: 'Enable', Tapped: 'Enable', LeftHandTapped: 'Enable', HarmonicType: 'HType', HarmonicFret: 'HFret',
    Bended: 'Enable', BendOriginValue: 'Float', BendOriginOffset: 'Float', BendMiddleValue: 'Float',
    BendMiddleOffset1: 'Float', BendMiddleOffset2: 'Float', BendDestinationValue: 'Float', BendDestinationOffset: 'Float', Slide: 'Flags'
};
export const noteTechniqueElements = ['AntiAccent', 'LetRing', 'Accent', 'Vibrato', 'LeftFingering', 'RightFingering', 'Trill', 'Ornament'];
export const beatTechniqueFields: Record<string, string> = {
    BarreFret: 'Fret', BarreString: 'String', Rasgueado: 'Rasgueado',
    Brush: 'Direction', PickStroke: 'Direction', Slapped: 'Enable', Popped: 'Enable', VibratoWTremBar: 'Strength',
    WhammyBar: 'Enable', WhammyBarOriginValue: 'Float', WhammyBarOriginOffset: 'Float', WhammyBarMiddleValue: 'Float',
    WhammyBarMiddleOffset1: 'Float', WhammyBarMiddleOffset2: 'Float', WhammyBarDestinationValue: 'Float', WhammyBarDestinationOffset: 'Float'
};
export const beatTechniqueElements = ['Tremolo', 'Arpeggio', 'Whammy', 'Timer', 'Wah'];
export function propertyMap(e: Element): Map<string, Element> {
    return new Map((child(e, 'Properties', false)?.children ?? []).map(p => [p.attrs.name, p]));
}
export function harmonicKind(source: Element): NonNullable<NoteDetails['harmonic']>['type'] | undefined {
    const property = propertyMap(source).get('HarmonicType'); if (!property) return undefined;
    const type = value(property, 'HType').toLowerCase();
    if (type === 'noharmonic') return undefined;
    if (!['natural', 'artificial', 'pinch', 'tap', 'semi', 'feedback'].includes(type)) refuse('harmonic-type', 'Unknown encoded harmonic type.', property.location);
    return type as NonNullable<NoteDetails['harmonic']>['type'];
}
/** Published GP node labels identify harmonic-series partials, not semitone frets.
 * Corroborated against the official harmonic dialog and an independent GP importer;
 * integer MIDI approximation follows the notated equal-tempered overtone. No default node. */
export function harmonicResult(source: Element, physicalMidi: number, openMidi: number, fret: number): number | undefined {
    const kind = harmonicKind(source); if (!kind) return undefined;
    const hfret = propertyMap(source).get('HarmonicFret');
    const node = hfret ? signedDecimal(value(hfret, 'HFret'), hfret.location) : kind === 'natural' ? q(fret) : undefined;
    if (!node) return undefined;
    const interval = harmonicInterval(node.n / node.d);
    return interval === undefined ? undefined : (kind === 'natural' ? openMidi : physicalMidi) + interval;
}
export function harmonicInterval(node: number): number | undefined {
    const partials: [number, number[]][] = [[2,[12]],[3,[7,19]],[4,[5,24]],[5,[3.9,4,9,16]],[6,[3.2]],[7,[2.7,5.8,9.6,14.7,21.7]],[8,[2.3,2.4,8.2,17]],[9,[2]],[10,[1.8]]];
    const partial = partials.find(([,nodes]) => nodes.includes(node))?.[0];
    if (!partial) return undefined;
    return Math.round(12 * Math.log2(partial));
}
function signedDecimal(text: string, source: Location): Rational {
    if (!/^-?\d{1,4}(?:\.\d{1,6})?$/.test(text)) refuse('technique-number', 'Expected an exact bounded technique decimal.', source);
    return mul(decimal(text.replace(/^-/, '')), q(text.startsWith('-') ? -1 : 1));
}
export function curve(properties: Map<string, Element>, prefix: 'Bend' | 'WhammyBar', owner: Element): NonNullable<NoteDetails['bend']> {
    const amount = (suffix: string, fallback: number) => {
        const p = properties.get(prefix + suffix);
        return p ? signedDecimal(value(p, 'Float'), p.location) : q(fallback);
    };
    const point = (which: string, offsetSuffix: string, fallback: number) => ({
        source: properties.get(prefix + offsetSuffix)?.location ?? properties.get(prefix + which + 'Value')?.location ?? owner.location,
        offset: mul(amount(offsetSuffix, fallback), q(1, 100)), semitones: mul(amount(which + 'Value', 0), q(1, 50))
    });
    const origin = point('Origin', 'OriginOffset', 0), destination = point('Destination', 'DestinationOffset', 100);
    const points = [origin];
    if (properties.has(prefix + 'MiddleValue')) {
        if (properties.has(prefix + 'MiddleOffset1')) points.push(point('Middle', 'MiddleOffset1', 50));
        if (properties.has(prefix + 'MiddleOffset2')) points.push(point('Middle', 'MiddleOffset2', 50));
        if (!properties.has(prefix + 'MiddleOffset1') && !properties.has(prefix + 'MiddleOffset2')) points.push(point('Middle', 'MiddleOffset1', 50));
    }
    // Middle editor handles outside the authored endpoint domain are inactive. Retain
    // all scalar fields separately; do not reinterpret a stale handle as a later bend.
    const active = points.filter((p, index) => index === 0 || compare(p.offset, origin.offset) >= 0 && compare(p.offset, destination.offset) < 0);
    active.push(destination);
    points.splice(0, points.length, ...active);
    for (let i = 0; i < points.length; i++) {
        if (compare(points[i].offset, q(0)) < 0 || compare(points[i].offset, q(1)) > 0 || i && compare(points[i].offset, points[i - 1].offset) < 0)
            refuse('bend-curve', 'Bend offsets must preserve source order within the note.', points[i].source);
    }
    const sourceCurveFields = [...properties].filter(([name]) => name.startsWith(prefix) && name !== 'WhammyBar' && name !== 'Bended').map(([name, field]) => ({ source: field.location, name, value: signedDecimal(value(field, 'Float'), field.location) }));
    return { source: owner.location, points, sourceCurveFields, ...(prefix === 'WhammyBar' ? { withBar: { source: owner.location } } : {}) };
}
export function noteTechniques(source: Element, note: NoteDetails, writtenPitch?: (midi:number)=>Pitch): number {
    const properties = propertyMap(source);
    const shownString = properties.get('ShowStringNumber');
    if (shownString) { child(shownString,'Enable'); if(note.string===undefined)refuse('string-number','An explicit printed string number needs its source physical string.',shownString.location);note.sourceStringNumber={source:shownString.location,value:note.string!}; }
    const harmonicEnabled = properties.get('Harmonic'); if (harmonicEnabled) child(harmonicEnabled, 'Enable');
    const kind = harmonicKind(source), harmonicFret = properties.get('HarmonicFret');
    if (kind && !note.harmonic) refuse('harmonic-pitch', 'Harmonic roles must be recovered before technique projection.', source.location);
    if (harmonicFret) {
        const position = signedDecimal(value(harmonicFret, 'HFret'), harmonicFret.location);
        if ((!note.harmonic && position.n !== 0) || compare(position, q(0)) < 0) refuse('harmonic-fret', 'Touch-node parameter requires a harmonic and a bounded nonnegative coordinate.', harmonicFret.location);
        if (note.harmonic) note.harmonic.harmonicFret = { source: harmonicFret.location, value: position };
    }
    const gesture = (owner: Element, kind: NonNullable<NoteDetails['gestures']>[number]['kind'], hand?: 'left' | 'right') => {
        (note.gestures ??= []).push({ source: owner.location, kind, ...(hand ? { hand } : {}) });
    };
    for (const [name, kind, hand] of [['PalmMuted', 'palm-mute'], ['Tapped', 'tap', 'right'], ['LeftHandTapped', 'tap', 'left']] as const) {
        const p = properties.get(name); if (p) { child(p, 'Enable'); gesture(p, kind, hand); }
    }
    const ring = child(source, 'LetRing', false); if (ring) gesture(ring, 'let-ring');
    const vibrato = child(source, 'Vibrato', false);
    if (vibrato) {
        if (!['None', 'Slight', 'Wide'].includes(vibrato.text.trim())) refuse('vibrato', 'Unknown source vibrato strength.', vibrato.location);
        if (vibrato.text.trim() !== 'None') gesture(vibrato, vibrato.text.trim() === 'Wide' ? 'wide-vibrato' : 'vibrato');
    }
    const ghost = child(source, 'AntiAccent', false);
    if (ghost) { if (ghost.text.trim() !== 'Normal') refuse('ghost-note', 'Unknown anti-accent subtype.', ghost.location); note.noteheadParentheses = { source: ghost.location, value: true, origin: 'source' }; }
    const accent = child(source, 'Accent', false);
    if (accent) {
        const bits = integer(accent.text.trim(), 0, 31, accent);
        if (bits & 2) refuse('accent', 'Unmapped accent flag.', accent.location);
        note.articulations = [[1, 'staccato'], [4, 'strong-accent'], [8, 'accent'], [16, 'tenuto']].filter(([bit]) => bits & Number(bit)).map(([, name]) => String(name));
    }
    for (const [name, hand] of [['LeftFingering', 'left'], ['RightFingering', 'right']] as const) {
        const field = child(source, name, false); if (!field) continue;
        const raw = field.text.trim(), left: Record<string, string> = { P: 'T', I: '1', M: '2', A: '3', C: '4' };
        if (raw === 'Open') { (note.technical ??= []).push({ source: field.location, kind: 'open-string' }); continue; }
        if (!(raw in left)) refuse('fingering', 'Unknown encoded source finger.', field.location);
        (note.fingerings ??= []).push({ source: field.location, hand, value: hand === 'left' ? left[raw] : raw.toLowerCase() });
    }
    const ornament = child(source, 'Ornament', false);
    if (ornament) {
        const kind = ({ Turn: 'turn', InvertedTurn: 'inverted-turn', UpperMordent: 'inverted-mordent', LowerMordent: 'mordent' } as const)[ornament.text.trim() as 'Turn' | 'InvertedTurn' | 'UpperMordent' | 'LowerMordent'];
        if (!kind) refuse('ornament', 'Unknown source ornament.', ornament.location);
        (note.ornaments ??= []).push({ source: ornament.location, kind });
    }
    const trill = child(source,'Trill',false);
    if (trill) { if(!writtenPitch) refuse('trill-pitch','Trill source MIDI requires an explicit written-register context.',trill.location); note.trill={source:trill.location,target:writtenPitch!(integer(trill.text.trim(),0,127,trill))}; }
    const bend = properties.get('Bended');
    if (bend) note.bend = curve(properties, 'Bend', bend);
    else if ([...properties.keys()].some(name => name.startsWith('Bend'))) refuse('bend-curve', 'Bend curve fields lack the source bend marker.', source.location);
    const slide = properties.get('Slide'); if (!slide) return 0;
    const bits = integer(value(slide, 'Flags'), 0, 255, slide);
    if ([bits & 15, bits & 48, bits & 192].some(group => group && (group & (group - 1)))) refuse('slide-flags', 'Conflicting simultaneous source slide subtypes.', slide.location);
    for (const [bit, kind] of [[4, 'out-down'], [8, 'out-up'], [16, 'into-from-below'], [32, 'into-from-above'], [64, 'pick-slide-down'], [128, 'pick-slide-up']] as const)
        if (bits & bit) (note.slides ??= []).push({ source: slide.location, kind });
    return bits & 3;
}

export function beatTechniques(source: Element, event: MusicalEvent): void {
    const properties = propertyMap(source);
    const instruction = (owner: Element, kind: NonNullable<MusicalEvent['performerInstructions']>[number]['kind'], text: string, nativeValue: string) => (event.performerInstructions ??= []).push({ source: owner.location, kind, text, nativeValue });
    const barre = properties.get('BarreFret'), shape = properties.get('BarreString');
    if (barre) {
        const fret = integer(value(barre, 'Fret'), 0, 100, barre), half = shape ? integer(value(shape, 'String'), 0, 1, shape) === 1 : false;
        const roman = (n: number) => { let result = ''; for (const [amount, glyph] of [[100,'C'],[90,'XC'],[50,'L'],[40,'XL'],[10,'X'],[9,'IX'],[5,'V'],[4,'IV'],[1,'I']] as const) while (n >= amount) { result += glyph; n -= amount; } return result || '0'; };
        instruction(barre, 'barre', `${half ? '½B' : 'B'} ${roman(fret)}`, JSON.stringify({ fret, shape: shape ? Number(value(shape, 'String')) : undefined }));
    } else if (shape) refuse('barre', 'Barre shape has no encoded fret.', shape.location);
    const rasgueado = properties.get('Rasgueado');
    if (rasgueado) {
        const motif = value(rasgueado, 'Rasgueado');
        if (!/^(?:ii_1|mi_1|mii_[12]|pmp_[12]|pei_[12]|pai_[12]|ami_[12]|ppp_1|amii_1|amip_1|eami_1|eamii_1|peami_1)$/.test(motif)) refuse('rasgueado', 'Unknown source rasgueado motif.', rasgueado.location);
        instruction(rasgueado, 'rasgueado', `rasg. (${motif})`, motif);
    }
    const wah = child(source, 'Wah', false);
    if (wah) { const state = wah.text.trim(); if (!['Open', 'Closed'].includes(state)) refuse('wah', 'Unknown source wah instruction.', wah.location); instruction(wah, 'wah', `wah ${state.toLowerCase()}`, state); }
    const timer = child(source, 'Timer', false);
    if (timer) { const encoded = integer(timer.text.trim(), 0, 2147483647, timer); instruction(timer, 'timer', `Timer: ${encoded}`, timer.text.trim()); }

    const whammy = properties.get('WhammyBar'); if (whammy) event.whammy = curve(properties, 'WhammyBar', whammy);
    else if ([...properties.keys()].some(name => name.startsWith('WhammyBar'))) refuse('bend-curve', 'Whammy curve lacks its source marker.', source.location);
    const encodedWhammy = child(source,'Whammy',false);
    if(encodedWhammy) {
        const attributes = new Map<string,Element>();
        for(const [name,text] of Object.entries(encodedWhammy.attrs)) attributes.set('WhammyBar'+name[0].toUpperCase()+name.slice(1), {...encodedWhammy,name:'Property',attrs:{name},text:'',children:[{...encodedWhammy,name:'Float',attrs:{},children:[],text}]});
        const mapped=curve(attributes,'WhammyBar',encodedWhammy);
        if(event.whammy?.sourceCurveFields?.length) {
            const signature=(bend:NonNullable<MusicalEvent['whammy']>)=>JSON.stringify(bend.points.map(p=>[p.offset,p.semitones]));
            if(signature(event.whammy)!==signature(mapped))refuse('bend-curve','Competing authored whammy curves disagree.',encodedWhammy.location);
            mapped.sourceCurveFields=[...event.whammy.sourceCurveFields,...(mapped.sourceCurveFields??[])];
        }
        event.whammy=mapped;
    }
    const vibrato = properties.get('VibratoWTremBar');
    if (vibrato) {
        const strength = value(vibrato, 'Strength');
        if (!['Slight', 'Wide'].includes(strength)) refuse('vibrato', 'Unknown bar vibrato strength.', vibrato.location);
        for (const note of event.notes) (note.gestures ??= []).push({ source: vibrato.location, kind: strength === 'Wide' ? 'wide-vibrato' : 'vibrato', text: strength === 'Wide' ? 'wide vibrato with bar' : 'vibrato with bar' });
    }
    const pick = properties.get('PickStroke');
    if (pick) {
        const direction = value(pick, 'Direction');
        if (!['Up', 'Down'].includes(direction)) refuse('pick-stroke', 'Unknown pick direction.', pick.location);
        for (const note of event.notes) (note.technical ??= []).push({ source: pick.location, kind: direction === 'Up' ? 'up-bow' : 'down-bow' });
    }
    for (const [name, kind] of [['Slapped', 'slap'], ['Popped', 'pop']] as const) {
        const p = properties.get(name); if (p) { child(p, 'Enable'); for (const note of event.notes) (note.gestures ??= []).push({ source: p.location, kind }); }
    }
    const brush = properties.get('Brush'), arpeggio = child(source, 'Arpeggio', false);
    if (brush || arpeggio) {
        const owner = arpeggio ?? brush!, direction = arpeggio ? arpeggio.text.trim() : value(brush!, 'Direction');
        if (!['Up', 'Down'].includes(direction)) refuse('arpeggio', 'Unknown source arpeggiation direction.', owner.location);
        event.arpeggio = { source: owner.location, direction: direction === 'Up' ? 'up' : 'down', ...(brush ? { straight: true } : {}) };
    }
    const tremolo = child(source, 'Tremolo', false);
    if (tremolo) {
        const strokes = ({ '1/2': 1, '1/4': 2, '1/8': 3 } as Record<string, number>)[tremolo.text.trim()];
        if (!strokes) refuse('tremolo', 'Unknown source tremolo picking duration.', tremolo.location);
        (event.ornaments ??= []).push({ source: tremolo.location, kind: 'tremolo', type: 'single', strokes });
    }
}

export function connectSlides(part: Part, slides: Map<NoteDetails, number>, relations: MusicalRelation[]): void {
    const maximum = Math.max(...part.measures.map(m => m.voices.length));
    for (let voice = 0; voice < maximum; voice++) {
        let absolute = q(0);
        const events = part.measures.flatMap((measure, index) => {
            const entries = (measure.voices[voice] ?? []).map(event => ({ event, measure: index, absolute: add(absolute, event.start) }));
            absolute = add(absolute, measure.duration); return entries;
        });
        // Implicit slide destinations follow the string, not the next attack in an
        // arpeggio. Resolve backwards once so large arrangements remain linear.
        const destinations = new Map<NoteDetails, { entry: typeof events[number]; note: typeof events[number]['event']['notes'][number] }>();
        const nextByString = new Map<string, { entry: typeof events[number]; note: typeof events[number]['event']['notes'][number] }>();
        for (let index = events.length - 1; index >= 0; index--) {
            const entry = events[index];
            for (const note of entry.event.notes) {
                const key = `${entry.event.staff ?? 1}:${note.string}`;
                const next = nextByString.get(key);
                if (slides.has(note) && next) destinations.set(note, next);
            }
            for (const note of entry.event.notes) if (note.string !== undefined)
                nextByString.set(`${entry.event.staff ?? 1}:${note.string}`, { entry, note });
        }
        for (let index = 0; index < events.length; index++) for (const note of events[index].event.notes) {
            const kind = slides.get(note); if (!kind) continue;
            const current = events[index], destination = destinations.get(note), next = destination?.entry, target = destination?.note;
            if (!next || !target)
                refuse('slide-endpoint', 'Connected slide needs a subsequent source destination on the same voice, staff and string.', note.source);
            const endpoint = (entry: typeof current, n: NoteDetails) => ({ partId: part.id, measure: entry.measure, position: entry.event.start, staff: entry.event.staff ?? 1, voiceId: entry.event.voiceId ?? String(voice + 1), eventId: entry.event.id, noteId: n.id });
            const id = `gp-slide:${part.id}:${voice}:${index}:${note.string}`;
            relations.push({ source: note.source, id, kind: 'glissando', form: 'slide', formFact: { source: note.source, origin: 'source' }, label: { source: note.source, value: '', show: false, origin: 'source' }, slideTechnique: { source: note.source, kind: kind === 2 ? 'legato' : 'shift' }, start: endpoint(current, note), end: endpoint(next!, target!) });
            if (kind === 2) {relations.push({ source: note.source, id: id + ':legato', kind: 'slur', start: endpoint(current, note), end: endpoint(next!, target!) }); (note.slurs??=[]).push({type:'start',number:1,relationId:id+':legato'});(target!.slurs??=[]).push({type:'stop',number:1,relationId:id+':legato'});}
        }
    }
}

/** Explicit contiguous source marks establish a notation span; no playback sustain is invented. */
export function connectSustainMarks(part: Part, relations: MusicalRelation[]): void {
    for (let voice = 0; voice < Math.max(...part.measures.map(m => m.voices.length)); voice++) {
        let absolute = q(0);
        const events = part.measures.flatMap((measure, index) => {
            const list = (measure.voices[voice] ?? []).map(event => ({ event, measure: index, absolute: add(absolute, event.start) }));
            absolute = add(absolute, measure.duration); return list;
        });
        for (const kind of ['palm-mute', 'let-ring'] as const) for (let string = 1; string <= part.tuning.length; string++) {
            let run: { entry: typeof events[number]; note: typeof events[number]['event']['notes'][number] }[] = [];
            const finish = () => {
                if (run.length > 1) {
                    const first = run[0], last = run.at(-1)!;
                    const gesture = first.note.gestures!.find(g => g.kind === kind)!;
                    relations.push({ id: `gp-${kind}:${part.id}:${voice}:${string}:${first.entry.measure}:${first.entry.event.id}`, source: gesture.source,
                        kind: 'text-line', line: 'dashes', lineType: 'dashed', beginText: kind === 'palm-mute' ? 'P.M.' : 'let ring',
                        textFacts: { beginText: { source: gesture.source, value: kind === 'palm-mute' ? 'P.M.' : 'let ring', origin: 'native-default' } },
                        start: { partId: part.id, measure: first.entry.measure, position: first.entry.event.start, staff: 1, voiceId: String(voice + 1), eventId: first.entry.event.id, noteId: first.note.id },
                        end: { partId: part.id, measure: last.entry.measure, position: add(last.entry.event.start, last.entry.event.duration), staff: 1, voiceId: String(voice + 1) } });
                    for (const item of run) item.note.gestures!.find(g => g.kind === kind)!.printObject = false;
                }
                run = [];
            };
            for (const entry of events) {
                const note = entry.event.notes.find(note => note.string === string), marked = note?.gestures?.some(g => g.kind === kind);
                if (!marked || run.length && !equal(add(run.at(-1)!.entry.absolute, run.at(-1)!.entry.event.duration), entry.absolute)) finish();
                if (marked) run.push({ entry, note: note! });
            }
            finish();
        }
    }
}

/** Distinguish simultaneous H/P pairs; a contiguous same-string chain retains its level. */
export function numberHopo(part: Part): void {
    const pairs: { origin: NoteDetails; target: NoteDetails; start: Rational; end: Rational }[] = [];
    for (let voice = 0; voice < Math.max(...part.measures.map(m => m.voices.length)); voice++) {
        let absolute = q(0);
        const events = part.measures.flatMap(measure => {
            const list = (measure.voices[voice] ?? []).map(event => ({ event, absolute: add(absolute, event.start) })); absolute = add(absolute, measure.duration); return list;
        });
        const nextByString = new Map<string, {note: NoteDetails; clock: Rational}>();
        for (let i = events.length - 1; i >= 0; i--) {
            for (const origin of events[i].event.notes) if (origin.hopoStart) {
                const target = nextByString.get(`${events[i].event.staff ?? 1}:${origin.string}`);
                if (!target || target.note.hopoStop !== origin.hopoStart) refuse('hopo-conflict', 'Recovered H/P pair has no destination.', origin.source);
                pairs.push({ origin, target: target!.note, start: events[i].absolute, end: target!.clock });
            }
            for (const note of events[i].event.notes) nextByString.set(`${events[i].event.staff ?? 1}:${note.string}`, {note,clock:events[i].absolute});
        }
    }
    // A grace, its principal and a following attack may share the same clock.
    // Number the entire connected endpoint chain before allocating overlaps so
    // later same-clock pairs cannot overwrite a principal's incoming number.
    const parents = new Map<NoteDetails, NoteDetails>();
    const root = (note: NoteDetails): NoteDetails => {
        if (!parents.has(note)) parents.set(note, note);
        let result = note;
        while (parents.get(result)! !== result) result = parents.get(result)!;
        while (parents.get(note)! !== note) { const next = parents.get(note)!; parents.set(note, result); note = next; }
        return result;
    };
    for (const pair of pairs) parents.set(root(pair.target), root(pair.origin));
    const chains = new Map<NoteDetails, { pairs: typeof pairs; start: Rational; end: Rational }>();
    for (const pair of pairs) {
        const key = root(pair.origin), chain = chains.get(key);
        if (!chain) chains.set(key, { pairs: [pair], start: pair.start, end: pair.end });
        else { chain.pairs.push(pair); if (compare(pair.start, chain.start) < 0) chain.start = pair.start; if (compare(pair.end, chain.end) > 0) chain.end = pair.end; }
    }
    const ordered = [...chains.values()].sort((a,b) => compare(a.start,b.start));
    const active: { end: Rational; number: number }[] = [];
    for (let index = 0; index < ordered.length;) {
        let end = index + 1; while (end < ordered.length && equal(ordered[end].start, ordered[index].start)) end++;
        for (let i = active.length - 1; i >= 0; i--) if (compare(active[i].end, ordered[index].start) <= 0) active.splice(i, 1);
        const used = new Set(active.map(item => item.number));
        for (const chain of ordered.slice(index, end)) {
            const number = Array.from({length:16},(_,i)=>i+1).find(number=>!used.has(number));
            if (!number) refuse('hopo-number-limit', 'Simultaneous H/P relations exceed MusicXML numbered levels.', chain.pairs[0].origin.source);
            for (const pair of chain.pairs) pair.origin.hopoNumber = pair.target.hopoNumber = number!;
            active.push({ end: chain.end, number: number! }); used.add(number!);
        }
        index = end;
    }
}

export function binaryTechniques(facts: Record<string, number>, source: Location, note: NoteDetails, version: number, locate: (name: string) => Location): number {
    const flags = facts['note-flags'] ?? 0, first = facts['note-effect-flags'] ?? 0, second = facts['note-effect-flags2'] ?? 0;
    if (flags & 4) note.noteheadParentheses = { source: locate('note-flags'), value: true, origin: 'source' };
    const articulations = [...(version >= 500 && flags & 2 ? ['strong-accent'] : flags & 64 ? ['accent'] : []), ...(second & 1 ? ['staccato'] : [])];
    if (articulations.length) note.articulations = articulations;
    for (const [active, kind, field] of [[first & 8, 'let-ring', 'note-effect-flags'], [second & 2, 'palm-mute', 'note-effect-flags2'], [second & 64, 'vibrato', 'note-effect-flags2']] as const)
        if (active) (note.gestures ??= []).push({ source: locate(field), kind });
    for (const hand of ['left', 'right'] as const) if (facts[hand + '-fingering'] !== undefined && facts[hand + '-fingering'] !== -1) {
        const finger = facts[hand + '-fingering'];
        if (finger < 0 || finger > 4) refuse('fingering', 'Unknown binary finger value.', locate(hand + '-fingering'));
        (note.fingerings ??= []).push({ source: locate(hand + '-fingering'), hand, value: hand === 'left' ? (finger===0?'T':String(finger)) : ['p', 'i', 'm', 'a', 'c'][finger] });
    }
    if (first & 1) {
        const count = facts['bend-point-count'];
        if (!Number.isSafeInteger(count) || count < 1 || count > 60) refuse('bend-curve', 'A marked bend needs a bounded encoded curve.', source);
        const points = Array.from({ length: count }, (_, i) => {
            const offset = facts[`bend-offset:${i}`], alter = facts[`bend-alter:${i}`], vibrato = facts[`bend-vibrato:${i}`];
            if (offset < 0 || offset > 60 || !Number.isSafeInteger(alter) || ![0,1,2,3].includes(vibrato) || i && offset < facts[`bend-offset:${i - 1}`]) refuse('bend-curve', 'Malformed binary bend point.', locate(`bend-offset:${i}`));
            return { source: locate(`bend-offset:${i}`), offset: q(offset, 60), semitones: q(alter, 50), vibrato: { source: locate(`bend-vibrato:${i}`), value: !!vibrato, ...(vibrato ? {speed: (['fast','average','slow'] as const)[vibrato-1]} : {}) } };
        });
        note.bend = { source: locate('bend-type'), points };
    }
    let slide = facts['slide-type'];
    if (version < 400 && first & 4) slide = 1;
    if (slide === undefined) return 0;
    if (version < 500) {
        const mapped: Record<number, number> = { 0: 0, 1: 1, 2: 2, 3: 4, 4: 8, [-1]: 16, [-2]: 32 };
        if (!(slide in mapped)) refuse('slide-flags', 'Unknown legacy slide subtype.', locate('slide-type'));
        slide = mapped[slide];
    }
    if (slide < 0 || slide > 63 || [slide & 15, slide & 48].some(group => group && (group & (group - 1)))) refuse('slide-flags', 'Contradictory binary slide subtype.', locate('slide-type'));
    for (const [bit, kind] of [[4, 'out-down'], [8, 'out-up'], [16, 'into-from-below'], [32, 'into-from-above']] as const)
        if (slide & bit) (note.slides ??= []).push({ source: locate('slide-type'), kind });
    return slide & 3;
}

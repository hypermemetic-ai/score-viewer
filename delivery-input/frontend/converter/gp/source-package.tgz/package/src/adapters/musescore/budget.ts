import { refuse, type Location } from '../../core/report.js';
import { nativeLimits } from './capture-core.js';

type Payload = 'events' | 'components' | 'relations' | 'timelines' | 'markings';
/** Count facts before creating their model payload; no score-name or instrument-specific exemptions. */
export class NativeBudget {
    private counts: Partial<Record<Payload, number>> = {};
    add(kind: Payload, count: number, location: Location): void {
        const value = (this.counts[kind] ?? 0) + count;
        if (value > nativeLimits[kind]) refuse('native-payload-budget', `Native ${kind} exceed the bounded recovery profile.`, location);
        this.counts[kind] = value;
    }
}

/** Private per-conversion reuse; entries are admitted only after recursively verifying immutable data. */
export class JsonSizeCache {
    private readonly entries = new WeakMap<object, { bytes: number; height: number }>();
    private count = 0;
    get size(): number { return this.count; }
    get(value: object): { bytes: number; height: number } | undefined { return this.entries.get(value); }
    remember(value: object, measured: { bytes: number; height: number }): void {
        if (this.count < 8192) { this.entries.set(value, measured); this.count++; }
    }
}

/** Exact JSON UTF-8 size without allocating a second whole result or serializing a giant diagnostic. */
export function boundJson(value: unknown, maximum: number, code: string, cache?: JsonSizeCache): number {
    let size = 0;
    const add = (bytes: number) => { size += bytes; if (size > maximum) refuse(code, 'Native result exceeds its bounded serialized byte budget.'); };
    const quoted = (text: string) => {
        let bytes = 2;
        for (let i = 0; i < text.length; i++) {
            const c = text.charCodeAt(i);
            if (c === 34 || c === 92) bytes += 2;
            else if (c < 32) bytes += [8, 9, 10, 12, 13].includes(c) ? 2 : 6;
            else if (c >= 0xD800 && c <= 0xDBFF && i + 1 < text.length && text.charCodeAt(i + 1) >= 0xDC00 && text.charCodeAt(i + 1) <= 0xDFFF) { bytes += 4; i++; }
            else if (c >= 0xD800 && c <= 0xDFFF) bytes += 6;
            else bytes += c < 0x80 ? 1 : c < 0x800 ? 2 : 3;
        }
        add(bytes);
    };
    // Signed height+1 avoids allocating per-scalar traversal records; positive means immutable data.
    const scan = (item: unknown, depth: number): number => {
        if (depth > 64) refuse(code, 'Native result exceeds its bounded serialization depth.');
        if (item === null || item === undefined) { add(4); return 1; }
        if (typeof item === 'string') { quoted(item); return 1; }
        if (typeof item === 'number') { add(Number.isFinite(item) ? String(item).length : 4); return 1; }
        if (typeof item === 'boolean') { add(item ? 4 : 5); return 1; }
        if (typeof item !== 'object') refuse(code, 'Native result contains a non-data payload.');
        const prototype = Object.getPrototypeOf(item);
        if (Array.isArray(item) ? prototype !== Array.prototype : prototype !== Object.prototype && prototype !== null)
            refuse(code, 'Native result contains a non-data object prototype.');
        const toJson = Object.getOwnPropertyDescriptor(item, 'toJSON');
        if (toJson && (!('value' in toJson) || typeof toJson.value === 'function')) refuse(code, 'Native result contains a non-data serialization hook.');
        const saved = cache?.get(item);
        if (saved) {
            if (depth + saved.height > 64) refuse(code, 'Native result exceeds its bounded serialization depth.');
            add(saved.bytes); return saved.height + 1;
        }
        const start = size; let height = 0, immutable = Object.isFrozen(item);
        const member = (child: unknown) => { const result = scan(child, depth + 1); height = Math.max(height, Math.abs(result)); immutable &&= result > 0; };
        if (Array.isArray(item)) {
            add(2 + Math.max(0, item.length - 1));
            for (let index = 0; index < item.length; index++) {
                const descriptor = Object.getOwnPropertyDescriptor(item, String(index));
                if (descriptor && !('value' in descriptor) || !descriptor && index in item) refuse(code, 'Native result contains a non-data array accessor or inherited component.');
                if (immutable && !descriptor) immutable = false;
                member(item[index]);
            }
        } else {
            add(2); let count = 0;
            for (const key of Object.keys(item)) {
                const descriptor = Object.getOwnPropertyDescriptor(item, key)!;
                if (!('value' in descriptor)) refuse(code, 'Native result contains a non-data accessor.');
                const child = (item as Record<string, unknown>)[key];
                if (child !== undefined) { if (count++) add(1); quoted(key); add(1); member(child); }
            }
        }
        if (immutable) cache?.remember(item, { bytes: size - start, height });
        return immutable ? height + 1 : -(height + 1);
    };
    scan(value, 0); return size;
}

import { children, hasCommentOrCdata, integer, type SourceElement } from '../../core/source-xml.js';
import { q } from '../../core/rational.js';
import { refuse } from '../../core/report.js';
import type { BendFact } from '../../core/model.js';
import type { NativeBudget } from './budget.js';

export const nativeTechniqueLines = new Set(['PalmMute', 'LetRing', 'HarmonicMark', 'Vibrato', 'WhammyBar']);
export function nativeVibratoCaption(subtype: string, element: SourceElement): string {
    const labels: Record<string, string> = { guitarVibrato: 'vibrato', guitarVibratoWide: 'wide vibrato', vibratoSawtooth: 'sawtooth vibrato', vibratoSawtoothWide: 'wide sawtooth vibrato' };
    if (!Object.hasOwn(labels, subtype)) return refuse('native-vibrato', 'Unknown native vibrato shape.', element.location);
    return labels[subtype];
}

/** Native legacy Bend display units: 100 is the printed "full" (two semitone) bend.
 * Source points are retained in order, including plateaus, pre-bends and releases.
 * This is the notation contract, not the legacy playback scheduler's pitch scale.
 */
export function readLegacyBend(element: SourceElement, budget: NativeBudget, use: (node: SourceElement) => void): BendFact { return readLegacyCurve(element, budget, use, false); }
export function readLegacyTremoloBar(element: SourceElement, budget: NativeBudget, use: (node: SourceElement) => void): BendFact { return { ...readLegacyCurve(element, budget, use, true), withBar: { source: element.location }, sourceKind: 'legacy-tremolo-bar' }; }
function readLegacyCurve(element: SourceElement, budget: NativeBudget, use: (node: SourceElement) => void, bar: boolean): BendFact {
    if (element.name !== (bar ? 'TremoloBar' : 'Bend') || Object.keys(element.attrs).length || element.text.trim() || hasCommentOrCdata(element))
        refuse('native-bend', 'A legacy bend requires a plain source note-owned Bend container.', element.location);
    const points = children(element, 'point');
    if (points.length < 2 || points.length > 256) refuse('native-bend', 'A legacy bend requires a bounded ordered curve with at least two points.', element.location);
    budget.add('markings', points.length + 1, element.location);
    use(element);
    let previous = -1;
    return { source: element.location, points: points.map(point => {
        if (point.children.length || point.text.trim() || hasCommentOrCdata(point)
            || Object.keys(point.attrs).sort().join(',') !== 'pitch,time,vibrato')
            refuse('native-bend-point', 'Bend points require only their explicit time, pitch and vibrato scalar attributes.', point.location);
        const time = integer(point.attrs.time, 0, 60, point.location), pitch = integer(point.attrs.pitch, bar ? -1200 : 0, bar ? 1200 : 300, point.location);
        if (time <= previous || previous === -1 && time !== 0) refuse('native-bend-clock', 'Source bend points must begin at zero and have strictly increasing normalized clocks.', point.location);
        if (!bar && pitch % 25) refuse('native-bend-amount', 'Legacy displayed bend amounts require the source quarter-tone grid; an off-grid label is not guessed.', point.location);
        previous = time; use(point);
        return { source: point.location, offset: q(time, 60), semitones: q(pitch, 50),
            vibrato: { source: point.location, value: integer(point.attrs.vibrato, 0, 1, point.location) === 1 } };
    }) };
}

import { child, children, integer, type SourceElement } from '../../core/source-xml.js';
import { refuse } from '../../core/report.js';
import type { MusicalEvent } from '../../core/model.js';

type Figure = NonNullable<MusicalEvent['figuredBass']>[number];
const modifiers = ['', 'flat-flat', 'flat', 'natural', 'sharp', 'double-sharp', 'plus', 'back-slash', 'slash'];
const symbols = ['', '𝄫', '♭', '♮', '♯', '𝄪', '+', '\\', '/'];
const brackets = ['', '(', ')', '[', ']'];
/** Native enums and five component boundaries are retained independently of standard projection. */
export function readFiguredBassItems(node: SourceElement, consume: (node: SourceElement) => void): Pick<Figure, 'items' | 'parentheses' | 'literalBracketText'> {
    const items: Figure['items'] = [];
    for (const item of children(node, 'FiguredBassItem')) {
        if (items.length >= 64 || item.text.trim() || Object.keys(item.attrs).length || item.children.some(field => !['brackets', 'digit', 'prefix', 'suffix', 'continuationLine'].includes(field.name))) refuse('native-figured-bass', 'Invalid figured-bass item or excessive figure stack.', item.location);
        consume(item);
        const output: Figure['items'][number] = { source: item.location };
        const boundary = child(item, 'brackets');
        if (boundary) {
            if (boundary.children.length || boundary.text.trim() || Object.keys(boundary.attrs).some(key => !/^b[0-4]$/.test(key))) refuse('native-figured-bass', 'Invalid figured-bass bracket positions.', boundary.location);
            consume(boundary); output.brackets = { source: boundary.location, values: Array.from({ length: 5 }, (_, i) => integer(boundary.attrs[`b${i}`] ?? '0', 0, 4, boundary.location)) };
        }
        for (const name of ['digit', 'prefix', 'suffix', 'continuationLine'] as const) {
            const field = child(item, name); if (!field) continue;
            if (field.children.length || Object.keys(field.attrs).length) refuse('native-figured-bass', 'Figure components must be plain source scalars.', field.location);
            consume(field);
            if (name === 'digit') { const value = integer(field.text.trim(), -1, 2147483647, field.location); if (value !== -1) output.digit = { source: field.location, value }; }
            else if (name === 'continuationLine') output.continuation = { source: field.location, value: integer(field.text.trim(), 0, 2, field.location) as 0 | 1 | 2 };
            else { const encoded = integer(field.text.trim(), 0, 8, field.location); output[name] = { source: field.location, encoded, value: modifiers[encoded] }; }
        }
        if (!output.digit && !output.prefix?.encoded && !output.suffix?.encoded && !output.continuation?.value && !output.brackets?.values.some(Boolean)) refuse('native-figured-bass', 'Empty figure item has no performer content.', item.location);
        items.push(output);
    }
    if (!items.length) refuse('native-figured-bass', 'Empty figured-bass content has no performer projection.', node.location);
    const wholeRound = (item: Figure['items'][number]): boolean => {
        const b = item.brackets?.values ?? [0, 0, 0, 0, 0];
        const before = item.prefix?.encoded ? 0 : item.digit ? 1 : item.suffix?.encoded ? 2 : 3;
        const after = item.continuation?.value ? 4 : item.suffix?.encoded ? 3 : item.digit ? 2 : 1;
        return b.filter(Boolean).length === 2 && b[before] === 1 && b[after] === 2;
    };
    if (items.every(wholeRound)) return { items, parentheses: true };
    if (!items.some(item => item.brackets?.values.some(Boolean))) return { items };
    // MusicXML only has one parentheses switch for the entire stack. Literal words preserve
    // mixed/square/partial boundaries; hidden standard figures retain machine-readable values.
    return { items, literalBracketText: items.map(item => {
        const b = (item.brackets?.values ?? [0, 0, 0, 0, 0]).map(value => brackets[value]);
        return `${b[0]}${symbols[item.prefix?.encoded ?? 0]}${b[1]}${item.digit?.value ?? ''}${b[2]}${symbols[item.suffix?.encoded ?? 0]}${b[3]}${item.continuation?.value ? '_' : ''}${b[4]}`;
    }).join('\n') };
}

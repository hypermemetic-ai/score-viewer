import type { ChordFrame, ChordHarmony, Direction } from '../../core/model.js';
import { refuse, type Finding } from '../../core/report.js';
import { child, children, integer, value, type Element } from './xml.js';

const collections = new Set(['ChordCollection', 'DiagramCollection']);
const workingSets = new Set(['ChordWorkingSet', 'DiagramWorkingSet']);
const accidentals: Record<string, number> = { DoubleFlat: -2, Flat: -1, Natural: 0, Sharp: 1, DoubleSharp: 2 };
const intervals: Record<string, number> = { Second: 2, Third: 3, Fourth: 4, Fifth: 5, Sixth: 6, Seventh: 7, Ninth: 9, Eleventh: 11, Thirteenth: 13 };
const fingers: Record<string, string> = { None: '', Thumb: 'T', Index: '1', Middle: '2', Ring: '3', Rank: '3', Pinky: '4' };
function shape(e: Element, fields: string[], attrs: string[], repeated: string[] = []): void {
    if (e.text.trim() || Object.keys(e.attrs).some(a => !attrs.includes(a))) refuse('gp-harmony-shape', 'Uninterpreted chord or diagram structure.', e.location);
    const seen = new Set<string>();
    for (const c of e.children) {
        if (!fields.includes(c.name) || seen.has(c.name) && !repeated.includes(c.name)) refuse('gp-harmony-shape', 'Unknown or duplicate chord field.', c.location);
        seen.add(c.name);
    }
}
function boolean(text: string, e: Element): boolean {
    if (!['true', 'false'].includes(text)) refuse('gp-harmony-boolean', 'Chord visibility must be an explicit boolean.', e.location);
    return text === 'true';
}

/** Collection identity is local to its source staff. Reading a beat never guesses a chord from its notes. */
export function createGpHarmony(track: Element, staff: Element, findings: Finding[]) {
    const items = new Map<string, Element>(), validated = new Set<Element>();
    const validateProperty = (property: Element): void => {
        if (validated.has(property)) return;
        const name = property.attrs.name;
        if (!collections.has(name) && !workingSets.has(name)) refuse('gp-harmony-collection', 'Not a source chord collection.', property.location);
        shape(property, ['Items'], ['name']); const owner = child(property, 'Items')!;
        shape(owner, ['Item'], [], ['Item']);
        if (workingSets.has(name)) {
            findings.push({ disposition: 'omitted', code: 'gp-chord-editor-working-set', message: 'The chord editor working set is retained in source; beat references use the staff chord/diagram collection.', location: property.location });
            validated.add(property); return;
        }
        if (owner.children.length > 2048) refuse('gp-harmony-budget', 'Too many source chord definitions.', owner.location);
        for (const item of owner.children) {
            shape(item, ['Diagram', 'Chord'], ['id', 'name']);
            if (!/^\d{1,6}$/.test(item.attrs.id) || item.attrs.name === undefined) refuse('gp-harmony-identity', 'Chord definition requires a bounded ID and literal source name.', item.location);
            const previous = items.get(item.attrs.id);
            if (previous && previous !== item) refuse('gp-harmony-identity', 'Chord references have conflicting source collection definitions.', item.location);
            items.set(item.attrs.id, item);
        }
        validated.add(property);
    };
    // Modern source staves own their collections; legacy direct tracks have no Staves wrapper.
    const properties = child(staff, 'Properties', false) ?? (staff === track ? child(track, 'Properties', false) : undefined);
    for (const property of properties?.children ?? []) if (collections.has(property.attrs.name) || workingSets.has(property.attrs.name)) validateProperty(property);

    const readBeat = (beat: Element, at: Pick<Direction, 'position' | 'staff' | 'voiceId'>): Direction | undefined => {
        const reference = child(beat, 'Chord', false); if (!reference) return undefined;
        if (reference.children.length || Object.keys(reference.attrs).length) refuse('gp-harmony-reference', 'Beat chord reference must be a plain source ID.', reference.location);
        const item = items.get(value(beat, 'Chord'));
        if (!item) return refuse('gp-harmony-reference', 'Beat references an absent staff chord definition.', reference.location);
        const harmony: ChordHarmony = { source: reference.location, value: item.attrs.name, role: 'chord-symbol' };
        const direction: Direction = { source: reference.location, kind: 'harmony', ...at, harmony };
        const chord = child(item, 'Chord', false);
        if (chord) {
            shape(chord, ['KeyNote', 'BassNote', 'Degree'], [], ['Degree']);
            const tone = (e: Element): NonNullable<ChordHarmony['root']> => {
                shape(e, [], ['step', 'accidental']);
                if (!/^[A-G]$/.test(e.attrs.step) || !Object.hasOwn(accidentals, e.attrs.accidental)) refuse('gp-harmony-pitch', 'Chord pitch requires a source spelling.', e.location);
                return { step: e.attrs.step, alter: accidentals[e.attrs.accidental] };
            };
            const root = child(chord, 'KeyNote', false), bass = child(chord, 'BassNote', false), degrees = children(chord, 'Degree');
            const rootPitch = root && tone(root), bassPitch = bass && tone(bass);
            const values: NonNullable<ChordHarmony['degrees']> = [];
            for (const degree of degrees) {
                shape(degree, [], ['interval', 'alteration', 'omitted']);
                const number = intervals[degree.attrs.interval], perfect = [4, 5, 11].includes(number);
                const alteration = degree.attrs.alteration;
                const alter = alteration === 'Perfect' && perfect || alteration === 'Major' && !perfect ? 0 : alteration === 'Minor' && !perfect ? -1 : alteration === 'Augmented' ? 1 : alteration === 'Diminished' ? perfect ? -1 : -2 : undefined;
                if (!number || alter === undefined || values.some(d => d.value === number)) return refuse('gp-harmony-degree', 'Unknown or repeated explicit chord interval.', degree.location);
                values.push({ source: degree.location, value: number, alter, type: boolean(degree.attrs.omitted, degree) ? 'subtract' : 'add' });
            }
            if (rootPitch && values.length) {
                harmony.root = rootPitch; harmony.rootText = ''; harmony.kind = 'other'; harmony.kindText = item.attrs.name; harmony.degrees = values;
                if (bassPitch && (bassPitch.step !== rootPitch.step || bassPitch.alter !== rootPitch.alter)) { harmony.bass = bassPitch; harmony.bassText = ''; }
            } else if (root || bass) findings.push({ disposition: 'preserved', code: 'gp-unanalysed-chord-label', message: 'A source label without defined intervals remains literal performer text; placeholder catalog root/bass do not establish its analysis.', location: item.location, fact: { label: item.attrs.name, root: rootPitch, bass: bassPitch } });
        }
        const diagram = child(item, 'Diagram', false);
        if (diagram) {
            shape(diagram, ['Fret', 'Fingering', 'Property'], ['stringCount', 'fretCount', 'baseFret', 'barsStates'], ['Fret', 'Property']);
            const strings = integer(diagram.attrs.stringCount, 1, 32, diagram), frets = integer(diagram.attrs.fretCount, 1, 48, diagram), base = integer(diagram.attrs.baseFret ?? '0', 0, 47, diagram);
            let showFrame = true, showFingering = true, showName = true;
            const seenProperties = new Set<string>();
            for (const property of children(diagram, 'Property')) {
                shape(property, [], ['name', 'type', 'value']);
                const name = property.attrs.name;
                if (!['ShowName', 'ShowDiagram', 'ShowFingering'].includes(name) || seenProperties.has(name) || property.attrs.type !== undefined && property.attrs.type !== 'bool') refuse('gp-frame-property', 'Uninterpreted source diagram presentation.', property.location);
                seenProperties.add(name); const enabled = boolean(property.attrs.value, property);
                if (name === 'ShowName') showName = enabled; else if (name === 'ShowDiagram') showFrame = enabled; else showFingering = enabled;
            }
            direction.printObject = showName;
            const notes: ChordFrame['notes'] = [], byString = new Map<number, ChordFrame['notes'][number]>();
            for (const position of children(diagram, 'Fret')) {
                shape(position, [], ['string', 'fret']);
                const string = strings - integer(position.attrs.string, 0, strings - 1, position), fret = integer(position.attrs.fret, 0, frets, position) + base;
                if (fret > 48 || byString.has(string)) refuse('gp-frame-position', 'Invalid or duplicate source diagram position.', position.location);
                const note = { source: position.location, string, fret }; notes.push(note); byString.set(string, note);
            }
            const fingering = child(diagram, 'Fingering', false), barres = new Map<string, ChordFrame['notes']>();
            if (fingering) {
                shape(fingering, ['Position'], [], ['Position']); const seen = new Set<number>();
                for (const position of fingering.children) {
                    shape(position, [], ['finger', 'fret', 'string']);
                    const string = strings - integer(position.attrs.string, 0, strings - 1, position), finger = fingers[position.attrs.finger];
                    if (seen.has(string) || finger === undefined) refuse('gp-frame-fingering', 'Duplicate string or unknown source finger.', position.location);
                    seen.add(string); const note = byString.get(string);
                    if (position.attrs.fret === '4294967295') { if (note || finger) refuse('gp-frame-fingering', 'Muted source fingering contradicts a played position.', position.location); continue; }
                    const fret = integer(position.attrs.fret, 0, frets, position) + base;
                    if (!note || note.fret !== fret) return refuse('gp-frame-fingering', 'Fingering does not match the source diagram position.', position.location);
                    if (finger) {
                        note.fingering = finger; note.fingeringVisible = showFingering;
                        const key = `${finger}:${fret}`, group = barres.get(key) ?? []; group.push(note); barres.set(key, group);
                    }
                }
            }
            for (const group of barres.values()) if (group.length > 1) {
                group.sort((a, b) => b.string - a.string); group[0].barre = 'start'; group.at(-1)!.barre = 'stop';
                findings.push({ disposition: 'inferred', code: 'gp-frame-fingering-barre', message: 'Equal source finger and fret across strings establish a barre between those positions; no additional sounded strings are invented.', location: fingering!.location, fact: { finger: group[0].fingering, fret: group[0].fret, strings: group.map(n => n.string) } });
            }
            const barStates = diagram.attrs.barsStates;
            if (barStates !== undefined && !/^\d{1,3}(?: \d{1,3}){0,47}$/.test(barStates)) refuse('gp-frame-bar-states', 'Diagram bar states require a bounded source scalar list.', diagram.location);
            if (barStates !== undefined) harmony.sourceBarStates = { source: diagram.location, value: barStates };
            if (notes.length) harmony.frame = { source: diagram.location, strings, frets, firstFret: base + 1, unplayed: 'x', printObject: showFrame, notes };
            else findings.push({ disposition: 'omitted', code: 'gp-empty-frame', message: 'An empty diagram has no played frame-note required by MusicXML; the source chord label is preserved without inventing a position.', location: diagram.location });
        }
        return direction;
    };
    return { readBeat, validateProperty };
}

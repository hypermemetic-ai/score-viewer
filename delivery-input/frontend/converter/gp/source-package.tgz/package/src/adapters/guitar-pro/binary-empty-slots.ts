import type {MusicalEvent,MusicalNote,NoteDetails} from '../../core/model.js';
import {q} from '../../core/rational.js';
import {refuse,type Finding,type Location} from '../../core/report.js';
import {binaryTechniques} from './techniques.js';

/** The optional type/fret pair is absent: a string slot is not an open-string attack. */
export function binaryEmptySlot(frame:{source:Location;facts:Record<string,number>},host:MusicalEvent,version:number,locate:(name:string)=>Location,findings:Finding[],makeGrace:(fret:number|undefined,dead:boolean,source:Location)=>MusicalNote,mainDead=false,targetName:(value:number,source:Location)=>string=value=>`fret ${value}`):MusicalEvent[] {
    const {facts,source}=frame;
    if(!mainDead)findings.push({disposition:'preserved',code:'binary-empty-note-slot',message:'The source string slot omits both note type and fret. It supplies no main attack; independently encoded grace and instruction operands remain at the source beat clock. Reader defaults are not source pitches.',location:source,fact:{string:facts['source-string'],flags:facts['note-flags']}});
    const instruction=(text:string,owner=source)=>{(host.performerInstructions??=[]).push({source:owner,kind:'empty-slot-technique',text,nativeValue:JSON.stringify(facts)});};
    // Validate known techniques using the same source rules, without constructing a note.
    const details:NoteDetails={source,id:source.id!,tieStart:false,tieStop:false},slide=binaryTechniques(facts,source,details,version,locate);
    const labels=mainDead?[]:[...(details.articulations??[]),...(details.gestures??[]).map(g=>g.kind),...(details.slides??[]).map(s=>'slide '+s.kind),...(details.fingerings??[]).map(f=>`${f.hand} fingering ${f.value}`)];
    if(!mainDead&&details.noteheadParentheses)labels.push('ghost note');
    if(details.bend)labels.push('bend');
    if(slide&&!mainDead)labels.push(slide===1?'shift slide':'legato slide');
    if(facts['note-effect-flags']&2)labels.push('hammer-on / pull-off');
    const harmonic=facts['harmonic-type'];
    if(harmonic){const names:Record<number,string>={1:'natural',2:'artificial',3:'tapped',4:'pinch',5:'semi',15:'artificial',17:'artificial',22:'artificial'};if(!names[harmonic]||version>=500&&harmonic>5||version>=400&&version<500&&harmonic===2)refuse('harmonic-type','Unknown harmonic on empty source slot.',locate('harmonic-type'));labels.push(names[harmonic]+' harmonic');}
    if(facts['trill-fret']!==undefined){if(![1,2,3].includes(facts['trill-speed']))refuse('trill','Unknown trill speed on empty source slot.',locate('trill-speed'));labels.push(`trill to ${targetName(facts['trill-fret'],locate('trill-fret'))} (${['','16th','32nd','64th'][facts['trill-speed']]})`);}
    if(facts['tremolo-marks']!==undefined){if(![1,2,3].includes(facts['tremolo-marks']))refuse('tremolo','Unknown tremolo value on empty source slot.',locate('tremolo-marks'));labels.push('tremolo picking');}
    if(labels.length)instruction(labels.join('; '));
    if(!mainDead&&facts['note-dynamic']!==undefined){const level=['','PPP','PP','P','MP','MF','F','FF','FFF'][facts['note-dynamic']];if(host.dynamic&&host.dynamic!==level)refuse('dynamic','Conflicting empty-slot and attack dynamics.',locate('note-dynamic'));host.dynamic=level;}
    const fret=facts['grace-fret'];if(fret===undefined)return [];
    const code=facts['grace-duration'],flags=facts['grace-flags']??0,transition=facts['grace-transition'],dynamic=facts['grace-dynamic'];
    if(![1,2,3].includes(code)||flags&~3||![0,1,2,3].includes(transition)||dynamic<1||dynamic>8||fret < (version<500?-1:0)||fret>127)refuse('grace','Invalid grace payload on empty source slot.',locate('grace-fret'));
    const dead=fret===-1||!!(flags&1),graceSource={...locate('grace-fret'),id:source.id+':grace'},before=version<500||!(flags&2);
    const note=makeGrace(fret===-1?undefined:fret,dead,graceSource);if(dead)note.sourceDead={source:locate(fret===-1?'grace-fret':'grace-flags'),value:true};
    if(fret===-1)findings.push({disposition:'inferred',code:'binary-empty-slot-dead-grace-placement',message:note.string!==undefined?'The dead grace has a source string but no fret or pitch. Its staff position uses the declared open-string register only as derived placement; it has no sounding pitch or physical fret.':'The dead grace omits its percussion identity. A middle-line X head provides derived placement without inventing a drum identity or sounding pitch.',location:graceSource});
    const event:MusicalEvent={source:graceSource,id:source.id+':grace-event',start:host.start,duration:q(0),writtenDuration:q(4,2**(7-code)),type:({1:'64th',2:'32nd',3:'16th'} as Record<number,string>)[code],dots:0,notes:[note],fullMeasureRest:false,grace:{source:graceSource,before,slash:before,index:0,hostId:host.id},dynamic:['','PPP','PP','P','MP','MF','F','FF','FFF'][dynamic]};
    if(transition){(event.performerInstructions??=[]).push({source:locate('grace-transition'),kind:'empty-slot-technique',text:['','slide','bend','hammer-on / pull-off'][transition],nativeValue:JSON.stringify({transition,targetSlot:source})});findings.push({disposition:'inferred',code:'binary-empty-slot-grace-transition',message:'A grace transition whose main slot has no pitch retains its literal technique as an instruction. No destination pitch, interval or paired endpoint is invented.',location:locate('grace-transition')});}
    return [event];
}

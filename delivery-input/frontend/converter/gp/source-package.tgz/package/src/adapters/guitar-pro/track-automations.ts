import { child, integer, value, type Element } from './xml.js';
import { refuse, type Finding } from '../../core/report.js';
import { decimal, mul } from '../../core/rational.js';
import type { MusicalPart } from '../../core/model.js';

function shape(owner: Element, names: string[], repeated: string[] = []): void {
    if (Object.keys(owner.attrs).length || owner.text.trim()) refuse('track-automation', 'Malformed source automation structure.', owner.location);
    const seen = new Set<string>();
    for (const field of owner.children) {
        if (!names.includes(field.name) || seen.has(field.name) && !repeated.includes(field.name)) refuse('track-automation', 'Unknown or duplicate source automation field.', field.location);
        seen.add(field.name);
    }
}
function scalar(field: Element): void {
    if (Object.keys(field.attrs).length || field.children.length) refuse('track-automation', 'Automation field requires plain encoded data.', field.location);
}
function boolean(owner: Element, name: string): boolean {
    const text = value(owner, name);
    if (!['true', 'false'].includes(text)) refuse('track-automation', 'Automation visibility and interpolation must be explicit booleans.', owner.location);
    return text === 'true';
}

/** Native sound changes select playback presets; independently authored annotation text and pedal marks are performer data. */
export function createTrackAutomations(track: Element, findings: Finding[]) {
    const sounds = child(track, 'Sounds', false), palette = new Map<string, { source: Element; program: number; caption?: Element }>();
    if (sounds) {
        shape(sounds, ['Sound'], ['Sound']);
        if (!sounds.children.length || sounds.children.length > 256) refuse('sound-profile', 'Source sound palette must contain one to 256 bounded definitions.', sounds.location);
        for (const sound of sounds.children) {
            shape(sound, ['Name', 'Label', 'Path', 'Role', 'MIDI', 'RSE']);
            sound.children.filter(field => !['MIDI', 'RSE'].includes(field.name)).forEach(scalar);
            const midi = child(sound, 'MIDI')!;
            shape(midi, ['MSB', 'LSB', 'Program']); midi.children.forEach(scalar);
            const program = integer(value(midi, 'Program'), 0, 127, midi), msb = integer(value(midi, 'MSB'), 0, 127, midi), lsb = integer(value(midi, 'LSB'), 0, 127, midi);
            const key = ['Path', 'Name', 'Role'].map(name => value(sound, name, false)).join(';');
            if (palette.has(key)) refuse('sound-profile', 'Sound identities must be unique before resolving any change.', sound.location);
            palette.set(key, { source: sound, program, caption: child(sound, 'Label', false) ?? child(sound, 'Name', false) });
            findings.push({ disposition: 'omitted', code: 'source-sound-preset', message: 'Encoded sound-bank and synthesizer preset data remain in source. They do not change the source instrument family or create unencoded performer instructions.', location: sound.location, fact: { key, program, msb, lsb } });
        }
    }
    const container = child(track, 'Automations', false), changes: Element[] = [];
    if (container) {
        shape(container, ['Automation'], ['Automation']);
        if (container.children.length > 4096) refuse('track-automation-budget', 'Too many track automation points.', container.location);
        for (const automation of container.children) {
            shape(automation, ['Type', 'Linear', 'Bar', 'Position', 'Visible', 'Value', 'Text']); automation.children.forEach(scalar);
            const type = value(automation, 'Type');
            if (!['Sound', 'SustainPedal'].includes(type)) refuse('track-automation', 'Track automation type needs an established performer interpretation.', automation.location);
            const linear = boolean(automation, 'Linear'); boolean(automation, 'Visible');
            integer(value(automation, 'Bar'), 0, 511, automation);
            const position = decimal(value(automation, 'Position'));
            if (position.n < 0 || position.n > position.d) refuse('track-automation-position', 'Automation ratio position must be in [0,1].', automation.location);
            if (type === 'Sound') {
                if (!palette.has(value(automation, 'Value'))) refuse('sound-reference', 'A source sound change must resolve its exact Path/Name/Role identity.', automation.location);
                if (value(automation, 'Bar') === '0' && position.n === 0) findings.push({ disposition: 'preserved', code: 'initial-sound-alias', message: 'Initial sound names an exact encoded Path/Name/Role identity; playback preset selection does not invent a performing instruction.', location: automation.location, fact: { sound: value(automation, 'Value') } });
            } else {
                const fields = value(automation, 'Value').split(/\s+/);
                if (linear || fields.length !== 2 || !/^(?:0|1)(?:\.0+)?$/.test(fields[0]) || !['1', '3'].includes(fields[1])) refuse('pedal-value', 'Sustain-pedal points require the source discrete down/up references 1 and 3.', automation.location);
            }
            changes.push(automation);
        }
    }
    return {
        firstSound: sounds?.children[0],
        apply(part: MusicalPart): void {
            const occupied = new Set<string>();
            for (const automation of changes) {
                const index = integer(value(automation, 'Bar'), 0, part.measures.length - 1, automation), measure = part.measures[index];
                const position = mul(decimal(value(automation, 'Position')), measure.duration), visible = boolean(automation, 'Visible'), type = value(automation, 'Type');
                const key = `${type}:${index}:${position.n}/${position.d}`;
                if (occupied.has(key)) refuse('track-automation-conflict', 'Competing automation states occupy the same exact source time.', automation.location);
                occupied.add(key);
                const directions = measure.directions ??= [], source = { ...automation.location, trackId: track.attrs.id, measure: index + 1 };
                if (type === 'SustainPedal') directions.push({ source, position, staff: 1, scope: 'part', kind: 'pedal', action: value(automation, 'Value').split(/\s+/)[1] === '1' ? 'start' : 'stop', line: false, sign: true, printObject: visible });
                else findings.push({ disposition: 'omitted', code: 'source-sound-change', message: 'Source sound change is retained as playback preset data; separately authored annotation text is preserved at the exact score position.', location: source, fact: { sound: value(automation, 'Value'), position, visible } });
                const text = child(automation, 'Text', false);
                if (type === 'Sound') {
                    const caption = palette.get(value(automation, 'Value'))!.caption;
                    if (caption?.text && caption.text !== text?.text) {
                        directions.push({ source: { ...caption.location, trackId: track.attrs.id, measure: index + 1 }, position, staff: 1, scope: 'part', kind: 'words', text: caption.text, printObject: visible });
                        findings.push({ disposition: 'preserved', code: 'source-sound-caption', message: 'The source sound-change score label is preserved as a performer caption, independently of excluded synthesizer settings. An absent Label uses the documented source Name default; an explicit empty Label stays empty.', location: source, fact: { caption: caption.text, captionSource: caption.location, position, visible } });
                    }
                }
                if (text) directions.push({ source: text.location, position, staff: 1, kind: 'words', text: text.text, printObject: visible });
            }
        }
    };
}

import { nodeHost } from './capture.js';
import { inspectNative, type MuseScoreInspectionResult } from './inspect-core.js';
export type * from './inspect-core.js';
export function inspectMuseScoreInWorker(bytes: Uint8Array): MuseScoreInspectionResult { return inspectNative(bytes, nodeHost); }

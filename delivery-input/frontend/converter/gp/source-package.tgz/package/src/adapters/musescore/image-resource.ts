import { SaxesParser } from 'saxes';
import type { NativeCapture } from './capture-core.js';
import type { Location } from '../../core/report.js';
import { refuse } from '../../core/report.js';
import { decodeBase64 } from '../../core/portable-bytes.js';

export interface ImageResource {
    source: Location;
    mime: 'image/png' | 'image/jpeg' | 'image/gif' | 'image/svg+xml';
    base64: string;
    sha256: string;
}
export type ImageResourceResult = { status: 'supported'; resource: ImageResource }
    | { status: 'unavailable' }
    | { status: 'unprojected'; reason: 'unrecognized-image-format' | 'unsafe-or-unexamined-svg' };

// Preserve static source vector bytes without running SVG, following references,
// rewriting drawing commands, or letting embedded scripts become output content.
const svgElements = new Set(['svg', 'g', 'defs', 'symbol', 'use', 'path', 'rect', 'circle', 'ellipse',
    'line', 'polyline', 'polygon', 'text', 'tspan', 'title', 'desc', 'linearGradient', 'radialGradient',
    'stop', 'clipPath', 'mask', 'pattern']);
function staticSvg(bytes: Uint8Array): boolean {
    let root = false, count = 0, safe = true;
    const parser = new SaxesParser({ xmlns: true });
    parser.on('doctype', () => { safe = false; });
    parser.on('processinginstruction', () => { safe = false; });
    parser.on('opentag', tag => {
        if (++count > 250_000) throw new Error('SVG element budget');
        if (!root) { root = true; if (tag.local !== 'svg') safe = false; }
        if (tag.uri !== 'http://www.w3.org/2000/svg' || !svgElements.has(tag.local)) safe = false;
        for (const attribute of Object.values(tag.attributes)) {
            if (attribute.uri === 'http://www.w3.org/2000/xmlns/') continue;
            if (/^on/i.test(attribute.local) || /[\\]|@import|expression\s*\(/i.test(attribute.value)) safe = false;
            if (attribute.local === 'href' && !/^#[A-Za-z_][\w.:-]*$/.test(attribute.value)) safe = false;
            if (/url\s*\(/i.test(attribute.value) && !/^url\(#[A-Za-z_][\w.:-]*\)$/.test(attribute.value)) safe = false;
            if (attribute.uri && !['http://www.w3.org/1999/xlink', 'http://www.w3.org/XML/1998/namespace'].includes(attribute.uri)) safe = false;
            if (attribute.uri === 'http://www.w3.org/XML/1998/namespace' && attribute.local === 'base') safe = false;
        }
    });
    try { parser.write(new TextDecoder('utf-8', { fatal: true }).decode(bytes)).close(); }
    catch { return false; }
    return root && safe;
}

/** Resolve only the source's exact archive identity; never access linkPath or the host filesystem. */
export function readImageResource(members: NativeCapture['members'], path: string, source: Location): ImageResourceResult {
    const matches = members.filter(member => member.name === path || member.name === `Pictures/${path}`);
    if (!matches.length) return { status: 'unavailable' };
    if (matches.length !== 1) refuse('native-image-ambiguity', 'The source image names more than one archive resource; no alternate is guessed.', source);
    const member = matches[0], bytes = decodeBase64(member.base64);
    const startsWith = (signature: readonly number[]) => bytes.length >= signature.length && signature.every((value, i) => bytes[i] === value);
    let mime: ImageResource['mime'] | undefined;
    if (startsWith([137, 80, 78, 71, 13, 10, 26, 10])) mime = 'image/png';
    else if (startsWith([255, 216, 255])) mime = 'image/jpeg';
    else if (startsWith([71, 73, 70, 56, 55, 97]) || startsWith([71, 73, 70, 56, 57, 97])) mime = 'image/gif';
    else if (/^\s*(?:\uFEFF)?\s*</.test(new TextDecoder('utf-8', { ignoreBOM: true }).decode(bytes.subarray(0, 256)))) {
        if (!staticSvg(bytes)) return { status: 'unprojected', reason: 'unsafe-or-unexamined-svg' };
        mime = 'image/svg+xml';
    }
    if (!mime) return { status: 'unprojected', reason: 'unrecognized-image-format' };
    return { status: 'supported', resource: { source: { member: member.name }, mime, base64: member.base64, sha256: member.sha256 } };
}

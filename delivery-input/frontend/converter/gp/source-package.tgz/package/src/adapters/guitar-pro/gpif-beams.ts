import type { MusicalEvent, MusicalPart } from '../../core/model.js';
import { refuse, type Finding } from '../../core/report.js';
import { child, integer, value, type Element } from './xml.js';
import { applyGpBeams, type GpBeamControl, type GpBeamGrouping } from './beams.js';

export interface GpifBeamFields {
    consumed: Set<string>; grouping?: GpBeamGrouping; after?: GpBeamControl;
    stem?: GpBeamControl; invert?: GpBeamControl;
}
/** Recognize only qualified beam fields. Other XProperties remain the caller's responsibility. */
export function readGpifBeamFields(owner: Element): GpifBeamFields {
    const result: GpifBeamFields = { consumed: new Set() }, groups = new Map<number, number>();
    const container = child(owner, 'XProperties', false);
    let unit: number | undefined;
    if (container) for (const property of container.children) {
        const id = property.attrs.id;
        const index = Number(id) - 1124139264;
        const master = owner.name === 'MasterBar' && (id === '1124139010' || index >= 0 && index < 32 && Number.isInteger(index));
        const beat = owner.name === 'Beat' && ['1124204545', '1124204546', '1124204552'].includes(id);
        if (!master && !beat) continue;
        if (result.consumed.has(id)) refuse('gp-beam-property', 'Duplicate source beam property.', property.location);
        if (property.name !== 'XProperty' || Object.keys(property.attrs).some(name => name !== 'id') || property.text.trim()
            || property.children.length !== 1 || property.children[0].name !== 'Int' || property.children[0].children.length || Object.keys(property.children[0].attrs).length)
            refuse('gp-beam-property', 'A source beam property requires one literal Int and its exact identifier.', property.location);
        const number = integer(value(property, 'Int'), 0, master ? 1024 : id === '1124204546' ? 2 : 1, property);
        result.consumed.add(id);
        if (master) {
            if (id === '1124139010') unit = number;
            else groups.set(index, number);
        } else if (id === '1124204545') result.invert = { source: property.location, invertSource: property.location, invert: number === 1 };
        else {
            result.after ??= { source: property.location };
            if (id === '1124204546' && number) { result.after.primary = number === 1 ? 'join' : 'split'; result.after.primarySource = property.location; }
            if (id === '1124204552') { result.after.secondaryBreak = number; result.after.secondarySource = property.location; }
        }
    }
    if (unit !== undefined || groups.size) {
        if (unit === undefined || !groups.size || !unit || unit > 1024 || (unit & (unit - 1)))
            refuse('gp-beam-groups', 'Explicit beam grouping requires both a power-of-two duration unit and source group counts.', container!.location);
        const counts = [...groups].sort(([a], [b]) => a - b);
        if (counts.some(([index, count], at) => index !== at || count > 255)) refuse('gp-beam-groups', 'Explicit beam group indices must be contiguous and counts bounded.', container!.location);
        result.grouping = { source: container!.location, unit: unit!, groups: counts.map(([, count]) => count) };
    }
    const automaticStem = child(owner, 'TransposedPitchStemOrientation', false), userStem = child(owner, 'UserTransposedPitchStemOrientation', false);
    for (const field of [automaticStem,userStem]) if (field && (field.children.length || Object.keys(field.attrs).length || !['Upward','Downward','Automatic','Undefined'].includes(field.text.trim()))) refuse('gp-beam-direction','Unknown explicit source stem orientation.',field.location);
    const stem = userStem && ['Upward','Downward'].includes(userStem.text.trim()) ? userStem : automaticStem;
    if (stem && ['Upward','Downward'].includes(stem.text.trim())) result.stem = { source: stem.location, stemSource: stem.location, stem: stem.text.trim() === 'Upward' ? 'up' : 'down' };
    return result;
}
export interface GpifBeamSource {
    masterBars: Element[]; bars: Element[]; beats: Map<string, Element>; rhythms: Map<string, Element>;
}
/** Called on each actual source staff before part/staff merging. IDs are definition IDs, not occurrence IDs. */
export function applyGpifBeams(part: MusicalPart, source: GpifBeamSource, findings: Finding[]): void {
    const groups = new Map<number, GpBeamGrouping>(), controls = new Map<MusicalEvent, GpBeamControl>();
    let inherited: GpBeamGrouping | undefined;
    for (const [index, measure] of part.measures.entries()) {
        const master = source.masterBars[index];
        if (!master) refuse('gp-beam-source', 'Missing source master bar for beam grouping.', measure.source);
        const fields = readGpifBeamFields(master);
        if (fields.grouping) inherited = fields.grouping;
        if (inherited) groups.set(index, inherited);
        for (const voice of measure.voices) {
            const byGrace = new Map<string, typeof voice>();
            for (const event of voice) {
                const key = event.grace ? `grace:${event.grace.hostId}:${event.grace.before}` : 'ordinary';
                const list = byGrace.get(key) ?? []; list.push(event); byGrace.set(key, list);
            }
            for (const events of byGrace.values()) for (const [eventIndex, event] of events.entries()) {
                const beat = source.beats.get(event.source.id ?? '');
                if (!beat) refuse('gp-beam-source', 'Missing source beat definition for a beam occurrence.', event.source);
                const fields = readGpifBeamFields(beat!);
                const own = fields.stem ?? fields.invert;
                if (own) controls.set(event, { ...controls.get(event), ...own, ...(fields.invert ? { invert: fields.invert.invert, invertSource: fields.invert.invertSource } : {}) });
                if (fields.after) {
                    const next = events[eventIndex + 1];
                    if (next) controls.set(next, { ...controls.get(next), ...fields.after });
                    else findings.push({ disposition: 'preserved', code: 'gp-terminal-beam-boundary', message: 'A source beam edit after the final beat has no following beam member in this source voice.', location: fields.after.source, fact: fields.after });
                }
            }
        }
    }
    applyGpBeams(part, { groups, controls }, findings);
}

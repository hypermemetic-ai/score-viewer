import { refuse, type Location } from '../../core/report.js';

/** Instrument-local selector facts, not GM program guesses. Reviewed against the native
 * producer's named palette and MuseScore 4.6 GPDrumSetResolver; see the proof record. */
const selectors: Record<string, Record<string, number>> = {
    hclap: { '0:0': 39 },
    cngKit: { '0:0': 64, '0:1': 108, '0:2': 109, '1:0': 63, '1:1': 110, '1:2': 62 },
    tmblKit: { '0:0': 66, '1:0': 65 }, agogoKit: { '0:0': 67, '1:0': 68 },
    cbs: { '0:0': 69, '0:1': 69, '0:2': 117 }, mrcs: { '0:0': 70, '0:2': 118 },
    whstlKit: { '0:0': 71, '1:0': 72 },
    bngKit: { '0:0': 61, '0:1': 107, '0:2': 106, '1:0': 60, '1:1': 105, '1:2': 104, '2:0': 64, '2:1': 108, '2:2': 109, '3:0': 63, '3:1': 110, '3:2': 62 },
    vbrslp: { '0:0': 58 }, tmbrn: { '0:0': 54, '0:2': 111, '0:3': 112, '0:4': 113 },
    cuicaKit: { '0:0': 78, '1:0': 79 }, trngl: { '0:0': 81, '0:1': 80 },
    clvs: { '0:0': 75, '5:0': 75 }, shkr: { '0:0': 82, '0:1': 82, '0:2': 122 },
    'jngl-bell': { '0:0': 83 }, 'bell-tree': { '0:0': 84, '0:2': 123 },
    wdblckKit: { '0:0': 76, '1:0': 77 }, guiro: { '0:0': 73, '0:1': 73, '0:2': 74 },
    cstnt: { '0:0': 85 }, surdo: { '0:0': 86, '0:1': 86 },
    snr: { '0:0': 37, '1:0': 38 }, cowbell: { '0:0': 102 },
    africaKit: { '4:0': 63, '2:0': 73, '2:2': 74, '3:2': 109, '4:1': 110 },
    latinoKit: { '2:1': 87, '3:0': 54, '3:1': 54, '3:3': 112 },
    sambaKit: { '0:0': 51, '0:1': 93, '0:2': 53, '1:0': 102, '2:0': 56, '3:0': 99, '4:0': 77, '5:0': 76, '6:0': 66, '7:0': 65 },
    '2Mrcs': { '0:0': 119 }
};
selectors.conbon = selectors.bngKit;
export function gp6LocalPercussion(reference: string, element: number, variation: number, source: Location): number {
    const number = selectors[reference]?.[`${element}:${variation}`];
    if (number === undefined) refuse('gp6-percussion-instrument-profile', 'No verified instrument-local percussion selector exists; a drum-kit or GM fallback would invent identity.', source);
    return number!;
}

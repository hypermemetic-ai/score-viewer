import type {Part, NoteFact, MusicalRelation, RelationEndpoint} from '../../core/model.js';
import type {Finding} from '../../core/report.js';

/** Binary flags encode the combined technique, not an independently encoded H/P direction. */
export function binaryHopo(part:Part,relations:MusicalRelation[],findings:Finding[]):void {
    for(let voice=0;voice<Math.max(...part.measures.map(m=>m.voices.length));voice++) {
        const entries=part.measures.flatMap((measure,index)=>(measure.voices[voice]??[]).map(event=>({event,measure:index})));
        const next=new Map<string,{entry:typeof entries[number];note:NoteFact}>();
        for(let index=entries.length-1;index>=0;index--) {
            const entry=entries[index];
            const endpoint=(item:typeof entry,note:NoteFact):RelationEndpoint=>({partId:part.id,measure:item.measure,position:item.event.start,staff:item.event.staff??1,voiceId:item.event.voiceId??String(voice+1),eventId:item.event.id,noteId:note.id});
            for(const note of entry.event.notes) if(note.sourceHopoOrigin) {
                const target=next.get(`${entry.event.staff??1}:${note.string}`);
                if(target&&note.kind==='pitched'&&target.note.kind==='pitched'&&target.note.fret!==note.fret) {
                    const kind=target.note.fret>note.fret?'hammer-on':'pull-off';
                    note.hopoStart=kind;target.note.hopoStop=kind;
                    findings.push({disposition:'inferred',code:'binary-hopo-endpoint',message:'The combined source H/P flag follows the next note on the same voice, staff and string; direction derives from the physical frets.',location:note.source,fact:{destination:target.note.source,kind}});
                } else {
                    (entry.event.performerInstructions??=[]).push({source:note.source,kind:'hammer-on-pull-off',text:`Hammer-on/pull-off (string ${note.string})`,nativeValue:JSON.stringify({origin:note.source,destination:target?.note.source??null,flag:2})});
                    if(target) {
                        const id=`binary-hopo:${note.id}`;
                        relations.push({source:note.source,id,kind:'slur',sourceTechnique:{source:note.source,kind:'hammer-on-pull-off'},start:endpoint(entry,note),end:endpoint(target.entry,target.note)});
                        (note.slurs??=[]).push({type:'start',number:1,relationId:id});(target.note.slurs??=[]).push({type:'stop',number:1,relationId:id});
                    }
                    findings.push({disposition:'preserved',code:'binary-hopo-undirected',message:'The encoded combined H/P instruction is retained without inventing pitch direction. A known same-string endpoint retains its slur; absent endpoints do not create notes.',location:note.source,fact:{destination:target?.note.source??null,reason:!target?'absent-endpoint':note.kind==='dead'||target.note.kind==='dead'?'dead-stroke':'unchanged-fret'}});
                }
            }
            for(const note of entry.event.notes)next.set(`${entry.event.staff??1}:${note.string}`,{entry,note});
        }
    }
}

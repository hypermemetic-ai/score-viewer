import { child, children, integer, value, type Element } from './xml.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import type { MusicalPart, MusicalScore, NeutralScore, Pitch, StaffFact } from '../../core/model.js';
import { limits } from './limits.js';
import { admittedFamily, isFrettedReference, type InstrumentFamily } from './admission.js';

export const sourceIds = (owner: Element, name: string, required = true): string[] => {
    const field = child(owner, name, required); if (!field) return [];
    if (field.children.length || Object.keys(field.attrs).length || !/^(?:-1|\d{1,6})(?:\s+(?:-1|\d{1,6}))*$/.test(field.text.trim()) && field.text.trim()) refuse('reference', 'Expected an exact bounded source reference list.', field.location);
    return field.text.trim().split(/\s+/).filter(Boolean);
};
export const sourceProperties = (owner: Element): Map<string, Element> => {
    const result = new Map<string, Element>(), group = child(owner, 'Properties', false);
    if (group?.text.trim() || group && Object.keys(group.attrs).length) refuse('property', 'Malformed source property container.', group.location);
    for (const property of group?.children ?? []) {
        if (property.name !== 'Property' || !property.attrs.name || Object.keys(property.attrs).some(key => key !== 'name') || result.has(property.attrs.name)) refuse('property', 'Duplicate or malformed source property.', property.location);
        result.set(property.attrs.name, property);
    }
    return result;
};
export function sourceStaves(track: Element): Element[] {
    const staves = child(track, 'Staves', false);
    if (staves) {
        if (staves.text.trim() || Object.keys(staves.attrs).length || staves.children.some(e => e.name !== 'Staff') || !staves.children.length || staves.children.length > 8) refuse('staff-scope', 'Expected one through eight ordered source staves.', staves.location);
        return staves.children;
    }
    const ref = child(track, 'Instrument', false)?.attrs.ref ?? '';
    return ref.endsWith('-gs') || ref.endsWith('GrandStaff') ? [track, track] : [track];
}
function definitions(root: Element, group: string, kind: string): Map<string, Element> {
    const container = child(root, group)!, map = new Map<string, Element>();
    if (container.text.trim() || Object.keys(container.attrs).length) refuse('structure', 'Invalid source definition container.', container.location);
    for (const e of container.children) {
        if (e.name !== kind || !/^\d{1,6}$/.test(e.attrs.id) || Object.keys(e.attrs).some(key => key !== 'id') || map.has(e.attrs.id)) refuse('identity', 'Invalid or duplicate source definition.', e.location);
        map.set(e.attrs.id, e);
    }
    return map;
}
/** MasterBar/Bars is flattened by source track order, then each track's ordered physical staves. */
export function discoverArrangementGraph(root: Element) {
    const tracks = definitions(root, 'Tracks', 'Track'), bars = definitions(root, 'Bars', 'Bar'), voices = definitions(root, 'Voices', 'Voice'), beats = definitions(root, 'Beats', 'Beat'), notes = definitions(root, 'Notes', 'Note'), rhythms = definitions(root, 'Rhythms', 'Rhythm');
    const order = sourceIds(child(root, 'MasterTrack')!, 'Tracks');
    if (!order.length || order.length > limits.tracks || order.length !== tracks.size || new Set(order).size !== order.length || order.some(id => !tracks.has(id))) refuse('track-scope', 'Master track order must exactly identify defined source tracks.', root.location);
    const slots = order.flatMap(trackId => sourceStaves(tracks.get(trackId)!).map((staff, index) => ({ trackId, staff, number: index + 1 })));
    const masterBars = child(root, 'MasterBars')!;
    if (!masterBars.children.length || masterBars.children.length > limits.measures || masterBars.children.some(e => e.name !== 'MasterBar')) refuse('measure-budget', 'Source measure count or shape is invalid.', masterBars.location);
    const reached = { bars: new Set<string>(), voices: new Set<string>(), beats: new Set<string>(), notes: new Set<string>(), rhythms: new Set<string>() };
    for (const master of masterBars.children) {
        const ids = sourceIds(master, 'Bars');
        if (ids.length !== slots.length || new Set(ids).size !== ids.length) refuse('bar-scope', 'Every master bar must identify one distinct bar for each ordered source staff.', master.location);
        for (const id of ids) { if (!bars.has(id)) refuse('reference', 'Unresolved staff bar.', master.location); reached.bars.add(id); }
    }
    for (const bar of bars.values()) for (const id of sourceIds(bar, 'Voices')) if (id !== '-1') { if (!voices.has(id)) refuse('reference', 'Unresolved source voice.', bar.location); if (reached.bars.has(bar.attrs.id)) reached.voices.add(id); }
    for (const voice of voices.values()) for (const id of sourceIds(voice, 'Beats')) { if (!beats.has(id)) refuse('reference', 'Unresolved source beat.', voice.location); if (reached.voices.has(voice.attrs.id)) reached.beats.add(id); }
    for (const beat of beats.values()) {
        const rhythm = child(beat, 'Rhythm')!;
        if (rhythm.children.length || rhythm.text.trim() || Object.keys(rhythm.attrs).join(',') !== 'ref' || !rhythms.has(rhythm.attrs.ref)) refuse('reference', 'Unresolved or malformed source rhythm.', rhythm.location);
        if (reached.beats.has(beat.attrs.id)) reached.rhythms.add(rhythm.attrs.ref);
        for (const id of sourceIds(beat, 'Notes', false)) { if (!notes.has(id)) refuse('reference', 'Unresolved source note.', beat.location); if (reached.beats.has(beat.attrs.id)) reached.notes.add(id); }
    }
    for (const [name, map] of [['bars', bars], ['voices', voices], ['beats', beats], ['notes', notes], ['rhythms', rhythms]] as const) if (reached[name].size !== map.size) refuse('unreferenced', `Unreferenced ${name} definitions cannot disappear through part selection.`, root.location);
    return { tracks, bars, voices, beats, notes, rhythms, order, slots, masterBars, all: reached };
}
export type ArrangementGraph = ReturnType<typeof discoverArrangementGraph>;
export function projectSourceStaff(root: Element, graph: ArrangementGraph, trackId: string, staffNumber: number): Element {
    const slot = graph.slots.findIndex(s => s.trackId === trackId && s.number === staffNumber);
    if (slot < 0) return refuse('staff-scope', 'Requested source staff is absent.', root.location);
    const rebuild = (e: Element, children: Element[], text = e.text): Element => ({ ...e, children, text });
    const track = graph.tracks.get(trackId)!, source = graph.slots[slot].staff;
    const group = child(track, 'Staves', false);
    const projectedTrack = group ? rebuild(track, track.children.map(e => e === group ? rebuild(group, [source]) : e)) : rebuild(track, track.children.map(e => e.name === 'Instrument' && (e.attrs.ref.endsWith('-gs') || e.attrs.ref.endsWith('GrandStaff')) ? { ...e, attrs: { ...e.attrs, ref: e.attrs.ref.endsWith('GrandStaff') ? e.attrs.ref.slice(0, -10) || 'piano' : e.attrs.ref.slice(0, -3) } } : e));
    const masters = graph.masterBars.children.map(master => rebuild(master, master.children.map(e => e.name === 'Bars' ? rebuild(e, [], sourceIds(master, 'Bars')[slot]) : e)));
    const selectedBars = masters.map(master => graph.bars.get(sourceIds(master, 'Bars')[0])!);
    const voiceIds = new Set(selectedBars.flatMap(bar => sourceIds(bar, 'Voices').filter(id => id !== '-1')));
    const beatIds = new Set([...voiceIds].flatMap(id => sourceIds(graph.voices.get(id)!, 'Beats')));
    const noteIds = new Set([...beatIds].flatMap(id => sourceIds(graph.beats.get(id)!, 'Notes', false)));
    const rhythmIds = new Set([...beatIds].map(id => child(graph.beats.get(id)!, 'Rhythm')!.attrs.ref));
    const groups: Record<string, Element[]> = { Tracks: [projectedTrack], MasterBars: masters, Bars: [...new Map(selectedBars.map(bar => [bar.attrs.id, bar])).values()], Voices: [...voiceIds].map(id => graph.voices.get(id)!), Beats: [...beatIds].map(id => graph.beats.get(id)!), Notes: [...noteIds].map(id => graph.notes.get(id)!), Rhythms: [...rhythmIds].map(id => graph.rhythms.get(id)!) };
    return rebuild(root, root.children.map(e => e.name === 'MasterTrack' ? rebuild(e, e.children.map(field => field.name === 'Tracks' ? rebuild(field, [], trackId) : field)) : groups[e.name] ? rebuild(e, groups[e.name]) : e));
}
export interface ArrangementTrack {
    source: Location; id: string; reference: string; family: InstrumentFamily; program: number; percussion: boolean; fretted: boolean;
    staves: Element[]; octave: number; chromatic: number; nominalKey?: string;
}
export function arrangementTrack(track: Element): ArrangementTrack {
    const source = { ...track.location, trackId: track.attrs.id }, set = child(track, 'InstrumentSet', false), midi = child(track, 'GeneralMidi', false);
    const soundList = children(child(track, 'Sounds', false) ?? { ...track, children: [] }, 'Sound');
    const sound = soundList[0], programOwner = midi ?? (sound ? child(sound, 'MIDI')! : undefined);
    if (!programOwner) return refuse('instrument', 'Instrument needs an encoded MIDI program.', source);
    const program = integer(value(programOwner, 'Program'), 0, 127, programOwner);
    const reference = set ? value(set, 'Type') : child(track, 'Instrument', false)?.attrs.ref ?? (midi?.attrs.table === 'Percussion' ? 'percussion' : midi?.attrs.table === 'Instrument' ? `gm-program-${program}` : '');
    const percussion = reference === 'drumKit' || reference === 'percussion' || midi?.attrs.table === 'Percussion';
    const family = admittedFamily(percussion ? 'percussion' : reference, program, source);
    const trans = child(track, 'Transpose', false), sounding = child(track, 'PartSounding', false);
    if (trans && sounding) refuse('transpose', 'Competing source transpose representations.', source);
    const amount = sounding ? integer(value(sounding, 'TranspositionPitch'), -60, 60, sounding) : undefined;
    const octave = trans ? integer(value(trans, 'Octave'), -4, 4, trans) : amount === undefined ? 0 : Math.trunc(amount / 12);
    const chromatic = trans ? integer(value(trans, 'Chromatic'), -24, 24, trans) : amount === undefined ? 0 : amount - octave * 12;
    return { source, id: track.attrs.id, reference, family, program, percussion, fretted: isFrettedReference(reference), staves: sourceStaves(track), octave, chromatic, ...(sounding ? { nominalKey: value(sounding, 'NominalKey') } : {}) };
}
export function isFrettedScore(score: MusicalScore): score is NeutralScore {
    return score.parts.every(part => part.midiProgram !== undefined && !!part.tuning?.length && part.measures.every(measure => measure.voices.every(voice => voice.every(event => event.notes.every(note => note.kind !== 'unpitched' && note.string !== undefined && note.fret !== undefined)))));
}
export const referencePitch = (midi: number, source: Location): Pitch => {
    if (!Number.isInteger(midi) || midi < 12 || midi > 127) return refuse('pitch-range', 'Source pitch is outside the supported MIDI register.', source);
    const steps = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'], bases: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
    return { step: steps[midi % 12], alter: midi % 12 - bases[steps[midi % 12]], octave: Math.floor(midi / 12) - 1, midi, origin: 'inferred' };
};
/** Bind recovered physical staves into one source part, never infer piano hands from staff order. */
export function mergeStaffParts(parts: MusicalPart[], track: ArrangementTrack): MusicalPart {
    if (!parts.length || parts.length !== track.staves.length) return refuse('staff-scope', 'Recovered source staff count differs.', track.source);
    const part: MusicalPart = { ...parts[0], source: track.source, id: track.id, instrument: track.reference, midiProgram: track.program };
    if (parts.length === 1) return part;
    delete part.tuning; delete part.capo;
    part.staves = parts.map((staffPart, index): StaffFact => ({ source: track.staves[index].location, number: index + 1, kind: track.percussion ? 'percussion' : 'pitched', lines: 5, clef: staffPart.measures[0].clef, ...(staffPart.tuning ? { tuning: staffPart.tuning } : {}), ...(staffPart.capo ? { capo: staffPart.capo } : {}) }));
    part.measures = parts[0].measures.map((measure, index) => {
        const incoming = parts.map(p => p.measures[index]);
        if (incoming.some(m => !m || m.duration.n * measure.duration.d !== measure.duration.n * m.duration.d)) refuse('staff-duration', 'Physical staves disagree about exact measure span.', measure.source);
        return { ...measure, voices: incoming.flatMap((m, si) => m.voices.map((voice, vi) => voice.map(event => ({ ...event, staff: si + 1, voiceId: String(si * 4 + vi + 1) })))),
            measureRepeats: incoming.flatMap((m, si) => (m.measureRepeats ?? []).map(r => ({ ...r, staff: si + 1 }))),
            staffs: incoming.map((m, si) => ({ ...part.staves![si], source: m.source, clef: m.clef })),
            changes: incoming.flatMap((m, si) => (m.changes ?? []).map(a => ({ ...a, staff: si + 1 }))),
            directions: incoming.flatMap((m, si) => (m.directions ?? []).map(d => ({ ...d, staff: si + 1, ...(d.voiceId ? { voiceId: String(si * 4 + Number(d.voiceId)) } : {}) }))) };
    });
    part.capoChanges = parts.flatMap((p, si) => (p.capoChanges ?? []).map(c => ({ ...c, staff: si + 1 })));
    part.percussionInstruments = parts.flatMap(p => p.percussionInstruments ?? []);
    return part;
}

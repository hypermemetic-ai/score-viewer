import { child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { refuse, type Location } from '../../core/report.js';

/** Native read460 Part appends each Staff in declaration order; body IDs are 1-based indices.
 * Older explicit declaration IDs retain their established adapter identity contract.
 */
export function nativeStaffDeclarationId(staff: Element, score: Element, version: string): number {
    if (staff.attrs.id !== undefined) return integer(staff.attrs.id, 1, 256, staff.location);
    if (!['4.60', '4.70'].includes(version)) return refuse('native-view-staff', 'Absent source staff identity has no qualified declaration-order rule for this serialization.', staff.location);
    const declarations = children(score, 'Part').flatMap(part => children(part, 'Staff')), index = declarations.indexOf(staff);
    if (index < 0 || index >= 256) return refuse('native-view-staff', 'Staff identity does not belong to the bounded source declaration sequence.', staff.location);
    // Mixed explicit/implicit identities cannot override the native ordinal interpretation.
    if (declarations.some((declaration, ordinal) => declaration.attrs.id !== undefined && integer(declaration.attrs.id, 1, 256, declaration.location) !== ordinal + 1))
        refuse('native-view-staff', 'Mixed explicit and implicit native staff identities contradict declaration order.', staff.location);
    return index + 1;
}

export function nativePrimaryStaffLink(staff: Element, primary: Element, version: string): { source: Location; id: number; sourceEid?: string } {
    const link = child(staff, 'linkedTo', true)!;
    if (link.children.length || Object.keys(link.attrs).length || !link.text.trim() || link.text.length > 256) refuse('native-view-link', 'Staff membership requires one bounded plain source identity.', link.location);
    const value = link.text.trim();
    if (/^\d+$/.test(value)) return { source: link.location, id: integer(value, 1, 256, link.location) };
    if (!['4.60', '4.70'].includes(version)) return refuse('native-view-link', 'EID staff membership has no qualified source rule for this serialization.', link.location);
    const matches = children(primary, 'Part').flatMap(part => children(part, 'Staff')).filter(declaration => {
        const eid = child(declaration, 'eid');
        if (eid && (eid.children.length || Object.keys(eid.attrs).length || !eid.text.trim() || eid.text.length > 256)) refuse('native-view-link', 'Primary staff EID must be bounded plain source data.', eid.location);
        return eid?.text.trim() === value;
    });
    if (matches.length !== 1) return refuse('native-view-link', 'Staff EID membership does not uniquely resolve to a primary staff declaration.', link.location);
    return { source: link.location, id: nativeStaffDeclarationId(matches[0], primary, version), sourceEid: value };
}

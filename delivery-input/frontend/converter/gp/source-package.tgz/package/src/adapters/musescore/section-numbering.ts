import { child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { refuse, type Location } from '../../core/report.js';
export type NativeSectionStart = { source:Location; restart:boolean; origin:'source'|'native-default' };
/** Section numbering follows the shared measure axis, including intervening frames.
 * Page/system reflow is deliberately not inferred from these source boundaries. */
export function nativeSectionStarts(staffs:readonly Element[], primaryMeasures:(staff:Element)=>readonly Element[]):Map<number,NativeSectionStart>{
    const starts=new Map<number,NativeSectionStart>();
    for(const staff of staffs){
        const primary=new Set(primaryMeasures(staff));let next=0;
        const inspect=(owner:Element):void=>{
            for(const section of children(owner,'LayoutBreak')){
                const subtype=child(section,'subtype');if(subtype?.text.trim()!=='section')continue;
                if(subtype.children.length||Object.keys(subtype.attrs).length)refuse('native-section-numbering','Section subtype must be a plain source scalar.',subtype.location);
                const field=child(section,'startWithMeasureOne');
                if(field&&(field.children.length||Object.keys(field.attrs).length))refuse('native-section-numbering','Section restart must be a plain source boolean.',field.location);
                const restart=field?integer(field.text.trim(),0,1,field.location)===1:true;
                const prior=starts.get(next);if(prior&&prior.restart!==restart)refuse('native-section-numbering','Serialized staff section boundaries disagree on numbering restart.',section.location);
                starts.set(next,{source:field?.location??section.location,restart,origin:field?'source':'native-default'});
            }
            for(const frame of owner.children)if(['VBox','HBox','FBox','TBox'].includes(frame.name))inspect(frame);
        };
        for(const item of staff.children){
            if(item.name==='Measure'){if(!primary.has(item))continue;next++;inspect(item);}
            else if(['VBox','HBox','FBox','TBox'].includes(item.name))inspect(item);
        }
    }
    return starts;
}

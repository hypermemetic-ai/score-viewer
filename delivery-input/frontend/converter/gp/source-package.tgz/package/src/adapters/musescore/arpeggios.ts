import type { MusicalEvent, MusicalPart, MusicalNote } from '../../core/model.js';
import { refuse } from '../../core/report.js';
import type { NativeBudget } from './budget.js';

/** Independently recover simultaneous membership from source-owned track spans, never staff appearance. */
export function recoverArpeggios(parts: MusicalPart[], budget: NativeBudget): void {
    for (const part of parts) for (const measure of part.measures) {
        const atClock = new Map<string, Map<number, MusicalEvent>>(), owners: { event: MusicalEvent; track: number; fact: NonNullable<MusicalEvent['arpeggio']> }[] = [];
        for (let track = 0; track < measure.voices.length; track++) for (const event of measure.voices[track]) {
            if (event.grace) { if (event.arpeggio?.trackSpan !== undefined && event.arpeggio.trackSpan > 1) refuse('native-grace-arpeggio', 'A multi-track grace arpeggio requires independently exercised host/index membership.', event.arpeggio.source); continue; }
            const key = `${event.start.n}/${event.start.d}`, tracks = atClock.get(key) ?? new Map<number, MusicalEvent>();
            if (tracks.has(track)) refuse('native-arpeggio-clock', 'Multiple ordinary source chords occupy one track/onset.', event.source);
            tracks.set(track, event); atClock.set(key, tracks);
            if (event.arpeggio) owners.push({ event, track, fact: event.arpeggio });
        }
        const counts = new Map<string, number>();
        for (const { event, track, fact } of owners) {
            const key = `${event.start.n}/${event.start.d}`, endTrack = track + (fact.trackSpan ?? 1) - 1;
            if (endTrack >= (part.staves?.length ?? 1) * 4) refuse('native-arpeggio-span', 'Authored arpeggio span leaves its source part.', fact.source);
            const members: MusicalEvent[] = [];
            for (let candidate = track; candidate <= endTrack; candidate++) {
                const chord = atClock.get(key)!.get(candidate); if (!chord?.notes.length) continue;
                members.push(chord);
            }
            const number = (counts.get(key) ?? 0) + 1; counts.set(key, number);
            if (number > 16) refuse('native-arpeggio-budget', 'More than 16 independent simultaneous arpeggio groups exceed standard numbering.', fact.source);
            budget.add('markings', members.length, fact.source);
            fact.groupId = `native-arpeggio:${event.id}`; fact.ownerEventId = event.id; fact.memberEventIds = members.map(e => e.id); fact.number = number;
            if (fact.nonArpeggiate) {
                const end = atClock.get(key)!.get(endTrack);
                if (!end?.notes.length) return refuse('native-arpeggio-endpoint', 'A bracket needs a source chord on its exact end track/onset.', fact.source);
                if (members.some(member => member.notes.some(note => note.kind === 'unpitched'))) refuse('native-arpeggio-unpitched', 'Bracket endpoints require independently verified unpitched ordering.', fact.source);
                const diatonic = (note: MusicalNote) => note.kind === 'unpitched' ? undefined : note.written.octave * 7 + 'CDEFGAB'.indexOf(note.written.step);
                const extreme = (notes: MusicalNote[], top: boolean): MusicalNote => {
                    let selected: MusicalNote | undefined, value = 0;
                    for (const note of notes) {
                        const position = diatonic(note);
                        if (position === undefined) return refuse('native-arpeggio-unpitched', 'Bracket endpoints require independently verified unpitched ordering.', fact.source);
                        if (!selected || (top ? position > value : position < value) || position === value && (top ? note.id < selected.id : note.id > selected.id)) { selected = note; value = position; }
                    }
                    return selected!;
                };
                // The source span selects the owner's up-note and the exact end track's
                // down-note, even when another member voice extends beyond that range.
                fact.noteEndpoints = [{ noteId: extreme(event.notes, true).id, type: 'top' }, { noteId: extreme(end.notes, false).id, type: 'bottom' }];
            }
            // Source owners are never overwritten by another group's derived membership.
            for (const member of members) (member.arpeggioGroups ??= []).push(fact);
        }
    }
}

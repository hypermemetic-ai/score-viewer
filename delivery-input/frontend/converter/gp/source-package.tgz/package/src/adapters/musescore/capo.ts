import { child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import type { MusicalPart } from '../../core/model.js';
import { compare, type Rational } from '../../core/rational.js';
import { refuse } from '../../core/report.js';
import type { NativeBudget } from './budget.js';

type Capo = NonNullable<MusicalPart['capoChanges']>[number];
export function sourceStateAt<T extends { measure: number; position: Rational }>(entries: readonly T[], measure: number, position: Rational): T | undefined {
    let low = 0, high = entries.length;
    while (low < high) { const middle = low + Math.floor((high - low) / 2), entry = entries[middle];
        if (entry.measure < measure || entry.measure === measure && compare(entry.position, position) <= 0) low = middle + 1; else high = middle;
    }
    return entries[low - 1];
}
export interface NativeCapoContext {
    budget: NativeBudget; get: (e: Element, field: string, required?: boolean) => string;
    use: (e: Element) => void; consume: (e: Element) => void; plainText: (e: Element) => string;
    decoration: (e: Element) => void;
}
/** Exact physical instruction facts. Native pitch and playback modes remain separate. */
export function readNativeCapo(element: Element, owner: Pick<Capo, 'measure' | 'position' | 'staff'>, ctx: NativeCapoContext): Capo {
    const { get, use, consume, budget } = ctx;
    if (element.text.trim() || Object.keys(element.attrs).length) refuse('native-capo', 'A capo instruction requires its plain source container.', element.location);
    use(element); budget.add('timelines', 1, element.location);
    const active = get(element, 'active'), fret = get(element, 'fretPosition'), mode = get(element, 'transposeMode'), generate = get(element, 'generateText');
    const visible = get(element, 'visible'), text = child(element, 'text');
    const fact: Capo = { source: element.location, ...owner, active: active ? integer(active, 0, 1, element.location) === 1 : true,
        fret: fret ? integer(fret, 0, 24, element.location) : 1,
        transposeMode: { source: child(element, 'transposeMode')?.location ?? element.location, value: ['playback-only', 'standard-only', 'tab-only'][mode ? integer(mode, 0, 2, element.location) : 0] as NonNullable<Capo['transposeMode']>['value'] },
        ...(visible ? { printObject: integer(visible, 0, 1, element.location) === 1 } : {}) };
    const ignored: number[] = [], seen = new Set<number>();
    for (const string of children(element, 'string')) {
        budget.add('markings', 1, string.location);
        if (string.text.trim() || Object.keys(string.attrs).join(',') !== 'no' || string.children.length !== 1 || string.children[0].name !== 'apply')
            refuse('native-capo-string', 'A capo string mask requires an explicit native string number and apply flag.', string.location);
        const number = integer(string.attrs.no, 0, 15, string.location) + 1;
        if (seen.has(number)) refuse('native-capo-string', 'Repeated capo string masks are ambiguous.', string.location);
        seen.add(number); consume(string);
        if (integer(get(string, 'apply', true), 0, 1, string.location) === 0) ignored.push(number);
    }
    if (ignored.length) fact.ignoredStrings = { source: element.location, values: ignored };
    const auto = generate ? integer(generate, 0, 1, element.location) === 1 : true;
    if (text) { const value = ctx.plainText(text); if (!auto) fact.text = value; }
    if (!auto && !text) refuse('native-capo-text', 'A custom capo instruction requires its explicitly encoded caption.', element.location);
    ctx.decoration(element); return fact;
}

export function readLegacyCapo(element: Element, owner: { measure: number; position: Rational; staff: number }, ctx: NativeCapoContext): Capo {
    if (element.children.length || element.text.trim() || Object.keys(element.attrs).join(',') !== 'fretId')
        refuse('native-capo', 'Legacy staff-text capo requires one bounded explicit fretId.', element.location);
    const fret = integer(element.attrs.fretId, 0, 24, element.location);
    ctx.consume(element); ctx.budget.add('timelines', 1, element.location);
    return { source: element.location, ...owner, active: fret > 0, fret,
        transposeMode: { source: element.location, value: 'playback-only' } };
}

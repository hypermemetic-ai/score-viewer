import { captureXml, child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { refuse, type Location } from '../../core/report.js';
import { nativeLimits, type ParsedNativeCapture } from './capture-core.js';
import { nativeStaffDeclarationId, nativePrimaryStaffLink } from './staff-identity.js';

export interface SourceViewSelection { readonly inputSha256: string; readonly id: string }
export interface SourceViewInfo {
    id: string; identityOrigin: 'source-location'; source: Location; primary: boolean;
    name?: { source: Location; value: string };
    metadata: { source: Location; name: string; value: string }[];
    parts: { source: Location; id: string; identityOrigin: 'encoded-part-id' | 'source-order';
        labels: { source: Location; role: 'track' | 'long' | 'short'; value?: string; markup: boolean;
            derivation: 'source-text' | 'inert-inline-text' | 'unavailable-markup'; sourceText?: string }[];
        staffs: { source: Location; id: number; identityOrigin?: 'native-declaration-order'; primaryStaff?: { source: Location; id: number; sourceEid?: string } }[] }[];
    musicalAdmission: 'not-checked';
}
/** Membership references never replace a view's independently encoded musical values. */
export interface ViewObjectLink {
    source: Location; owner: Location; kind: string; form: 'legacy-membership' | 'eid-membership';
    status: 'grammar-checked-membership' | 'located-eid-peer';
    targetEid?: { source: Location; value: string; target: Location };
    score?: { source: Location; value: 'same' };
    indexDiff?: { source: Location; value: number };
    coordinates?: { source: Location; fields: { source: Location; name: string; value: string }[] };
}
export interface NativeViews { primary: Element; entries: { node: Element; info: SourceViewInfo; links: ViewObjectLink[] }[] }
export const nativeVersions = ['3.01', '3.02', '4.00', '4.10', '4.20', '4.30', '4.40', '4.50', '4.60', '4.70'] as const;
export function admitNativeVersion(capture: ParsedNativeCapture): void {
    if (!(nativeVersions as readonly string[]).includes(capture.nativeVersion)) refuse('native-version', 'Native serialization has not been independently exercised by this adapter; producer/profile admission is separate from feature completeness.', capture.root.location);
}
const plain = (e: Element): string => {
    if (e.children.length || Object.keys(e.attrs).length || e.text.length > 65536) refuse('native-view-field', 'Expected a bounded plain view field.', e.location);
    return e.text;
};
const empty = (e: Element): void => {
    if (e.text.trim() || e.children.length || Object.keys(e.attrs).length) refuse('native-view-link', 'Expected an empty source membership marker.', e.location);
};
const membershipOwners = new Set(['Chord', 'Rest', 'Note', 'Articulation', 'Ornament', 'Breath', 'Fermata', 'Dynamic', 'StaffText', 'SystemText', 'Expression', 'Text', 'RehearsalMark', 'Fingering', 'Symbol', 'Tempo', 'Marker', 'Jump', 'Slur', 'Tie', 'HairPin', 'Pedal', 'Ottava', 'TextLine', 'NoteLine', 'Trill', 'Volta', 'BarLine', 'Tuplet', 'Clef', 'KeySig', 'TimeSig', 'Lyrics', 'Arpeggio', 'Glissando', 'Harmony', 'FretDiagram', 'Capo', 'Bend', 'PalmMute', 'LetRing', 'Vibrato', 'HarmonicMark', 'Tapping', 'GuitarBend', 'HammerOnPullOff', 'TremoloBar', 'WhammyBar', 'Tremolo', 'TremoloSingleChord', 'TremoloTwoChord', 'VBox', 'HBox', 'FBox', 'TBox']);
function descriptiveLabel(source: Element): Pick<SourceViewInfo['parts'][number]['labels'][number], 'value' | 'markup' | 'derivation' | 'sourceText'> {
    const markup = source.children.length > 0 || source.text.includes('<');
    if (!markup) return { value: source.text, markup: false, derivation: 'source-text' };
    const unavailable = { markup: true, derivation: 'unavailable-markup' as const, sourceText: source.text };
    try {
        // Reuse the bounded inert XML reader; discovery does not resolve native glyph/font meaning.
        const element = source.children.length ? source : captureXml(new TextEncoder().encode(`<text>${source.text}</text>`), source.location.member);
        let characters = 0;
        const flatten = (node: Element, top = false): string => {
            if (!top && !['b', 'i', 'u', 's', 'sup', 'sub', 'font', 'br'].includes(node.name)) throw new Error('Unqualified label markup.');
            if (Object.keys(node.attrs).some(key => node.name !== 'font' || !['face', 'size'].includes(key))) throw new Error('Unqualified label attributes.');
            characters += node.text.length;
            if (characters > 65536) throw new Error('Label text budget.');
            if (node.name === 'br') { if (node.children.length || node.text.trim()) throw new Error('Malformed label break.'); return '\n'; }
            let value = '', offset = 0;
            if (node.children.length && !node.textOrder) throw new Error('Unordered label markup.');
            for (const insertion of node.textOrder ?? []) {
                value += node.text.slice(offset, insertion.afterText) + flatten(node.children[insertion.child]); offset = insertion.afterText;
            }
            return value + node.text.slice(offset);
        };
        const value = flatten(element, true);
        if (value.length > 65536) return unavailable;
        return { value, markup: true, derivation: 'inert-inline-text', sourceText: source.text };
    } catch { return unavailable; }
}

/** Full bounded source inventory precedes either discovery or selection. It does not admit notes. */
export function inventoryViews(capture: ParsedNativeCapture): NativeViews {
    admitNativeVersion(capture);
    const primary = child(capture.root, 'Score', true)!, nodes = [primary, ...children(primary, 'Score')], nodeSet = new Set(nodes);
    if (nodes.length > nativeLimits.markings) refuse('native-view-budget', 'View inventory exceeds the existing marking budget.', primary.location);
    const entries: NativeViews['entries'] = [], primaryStaffIds = new Set<number>(), primaryPartByStaff = new Map<number, string>();
    let items = 0;
    const count = (e: Element) => { if (++items > nativeLimits.markings) refuse('native-view-budget', 'View and reference inventory exceeds the existing marking budget.', e.location); };
    const eids = new Map<string, { node: Element; view: number }>();
    const pending: { owner: Element; reference: Element; view: number; links: ViewObjectLink[] }[] = [];
    for (const [index, node] of nodes.entries()) {
        count(node);
        if (Object.keys(node.attrs).length || node.text.trim() || index && children(node, 'Score').length) refuse('native-view-structure', 'Expected primary Score and immediate independently serialized part views.', node.location);
        const info: SourceViewInfo = { id: index ? `${node.location.member}#${node.location.path}` : 'main', identityOrigin: 'source-location', source: node.location, primary: index === 0, metadata: [], parts: [], musicalAdmission: 'not-checked' };
        if (info.id.length > 4096) refuse('native-view-identity-budget', 'Opaque view identity exceeds the caller source-location bound.', node.location);
        const name = child(node, 'name'); if (name) { count(name); info.name = { source: name.location, value: plain(name) }; }
        for (const metadata of children(node, 'metaTag')) {
            count(metadata);
            if (Object.keys(metadata.attrs).some(key => key !== 'name') || !metadata.attrs.name || metadata.attrs.name.length > 256 || metadata.children.length || metadata.text.length > 65536) refuse('native-metadata', 'View metadata needs a bounded name and plain value.', metadata.location);
            info.metadata.push({ source: metadata.location, name: metadata.attrs.name, value: metadata.text });
        }
        const staffIds = new Set<number>(), partIds = new Set<string>();
        for (const [partIndex, part] of children(node, 'Part').entries()) {
            count(part); const id = part.attrs.id ?? `native-part-${partIndex + 1}`;
            if (Object.keys(part.attrs).some(key => key !== 'id') || !id || id.length > 256 || partIds.has(id)) refuse('native-part-identity', 'Source view part identities must be bounded and unique.', part.location);
            partIds.add(id);
            const instrument = child(part, 'Instrument', true)!, fact: SourceViewInfo['parts'][number] = { source: part.location, id, identityOrigin: part.attrs.id !== undefined ? 'encoded-part-id' : 'source-order', labels: [], staffs: [] };
            for (const [role, label] of [['track', child(part, 'trackName')], ['long', child(instrument, 'longName')], ['short', child(instrument, 'shortName')]] as const) if (label) {
                count(label);
                if (label.text.length > 65536) refuse('native-view-field', 'View label exceeds the existing field budget.', label.location);
                fact.labels.push({ source: label.location, role, ...descriptiveLabel(label) });
            }
            let linkedPrimaryPart: string | undefined;
            for (const staff of children(part, 'Staff')) {
                count(staff); const id = nativeStaffDeclarationId(staff, node, capture.nativeVersion);
                if (Object.keys(staff.attrs).some(key => key !== 'id') || staffIds.has(id)) refuse('native-view-staff', 'Source view staff declarations must be unique bounded identities.', staff.location);
                staffIds.add(id);
                const linked = child(staff, 'linkedTo');
                if (!index) { if (linked) refuse('native-view-link', 'Primary staff cannot select a nested score through a view link.', linked.location); primaryStaffIds.add(id); primaryPartByStaff.set(id, fact.id); }
                const primaryStaff = linked ? nativePrimaryStaffLink(staff, primary, capture.nativeVersion) : undefined;
                if (index && (!primaryStaff || !primaryStaffIds.has(primaryStaff.id))) refuse('native-view-link', 'Part view staff does not resolve to a declared primary staff.', linked?.location ?? staff.location);
                if (index && primaryStaff) { const owner = primaryPartByStaff.get(primaryStaff.id)!; if (linkedPrimaryPart !== undefined && linkedPrimaryPart !== owner) refuse('native-view-link', 'A view part cannot silently merge independently declared primary parts.', staff.location); linkedPrimaryPart = owner; }
                fact.staffs.push({ source: staff.location, id, ...(staff.attrs.id === undefined ? { identityOrigin: 'native-declaration-order' as const } : {}), ...(primaryStaff ? { primaryStaff } : {}) });
            }
            if (!fact.staffs.length) refuse('native-view-staff', 'Source part has no declared staff.', part.location);
            info.parts.push(fact);
        }
        const bodyIds = new Set<number>();
        for (const staff of children(node, 'Staff')) {
            const id = integer(staff.attrs.id, 1, 256, staff.location);
            if (Object.keys(staff.attrs).some(key => key !== 'id') || !staffIds.has(id) || bodyIds.has(id)) refuse('native-view-staff', 'Every serialized source staff requires one unique declaration.', staff.location);
            bodyIds.add(id);
        }
        if (!info.parts.length || bodyIds.size !== staffIds.size) refuse('native-view-staff', 'Source view declarations and serialized staff bodies disagree.', node.location);
        const links: ViewObjectLink[] = [];
        const stack = [node];
        while (stack.length) {
            const owner = stack.pop()!;
            if (owner !== node && owner.name === 'Score') {
                if (!index && nodeSet.has(owner)) continue;
                refuse('native-view-structure', 'Nested view recursion outside the immediate primary Score is not admitted.', owner.location);
            }
            const eid = child(owner, 'eid');
            if (eid) { count(eid); const value = plain(eid).trim(); if (!value || value.length > 256 || eids.has(value)) refuse('native-view-eid', 'Source editor identities must resolve uniquely before view selection.', eid.location); eids.set(value, { node: owner, view: index }); }
            const marker = child(owner, 'linkedMain'); if (marker) { count(marker); if (!membershipOwners.has(owner.name)) refuse('native-view-link', 'Unknown primary membership owner.', marker.location); empty(marker); }
            const linked = child(owner, 'linked'), to = owner.name === 'Staff' ? undefined : child(owner, 'linkedTo');
            if (linked && to) refuse('native-view-link', 'Conflicting legacy and EID membership forms.', owner.location);
            if (linked || to) { count((linked ?? to)!); if (!membershipOwners.has(owner.name)) refuse('native-view-link', 'Unexercised linked owner kind.', (linked ?? to)!.location); pending.push({ owner, reference: (linked ?? to)!, view: index, links }); }
            for (const element of owner.children) stack.push(element);
        }
        entries.push({ node, info, links });
    }
    for (const { owner, reference, view, links } of pending) {
        if (reference.name === 'linkedTo') {
            const value = plain(reference).trim(), target = eids.get(value);
            if (!value || value.length > 256 || !target || target.node === owner || target.node.name !== owner.name || target.view !== 0 && target.view !== view) return refuse('native-view-link', 'EID membership must resolve uniquely to the same source kind in the primary or owning view.', reference.location);
            links.push({ source: reference.location, owner: owner.location, kind: owner.name, form: 'eid-membership', status: 'located-eid-peer', targetEid: { source: reference.location, value, target: target.node.location } });
            continue;
        }
        if (reference.text.trim() || Object.keys(reference.attrs).length || reference.children.some(e => !['location', 'indexDiff', 'score'].includes(e.name))) refuse('native-view-link', 'Uninterpreted legacy membership fields.', reference.location);
        const fact: ViewObjectLink = { source: reference.location, owner: owner.location, kind: owner.name, form: 'legacy-membership', status: 'grammar-checked-membership' };
        const score = child(reference, 'score'); if (score) { if (plain(score).trim() !== 'same') refuse('native-view-link', 'Unknown legacy membership score context.', score.location); fact.score = { source: score.location, value: 'same' }; }
        const index = child(reference, 'indexDiff'); if (index) fact.indexDiff = { source: index.location, value: integer(plain(index).trim(), -250000, 250000, index.location) };
        const location = child(reference, 'location');
        if (location) {
            if (location.text.trim() || Object.keys(location.attrs).length) refuse('native-view-link', 'Expected inert relative membership coordinates.', location.location);
            const names = new Set<string>(), fields: NonNullable<ViewObjectLink['coordinates']>['fields'] = [];
            for (const field of location.children) {
                count(field); const value = plain(field).trim();
                if (names.has(field.name) || !['staves', 'voices', 'measures', 'fractions', 'grace', 'notes'].includes(field.name)) refuse('native-view-link', 'Unknown or repeated legacy membership coordinate.', field.location);
                names.add(field.name);
                if (field.name === 'fractions') { if (!/^-?\d{1,9}\/[1-9]\d{0,8}$/.test(value)) refuse('native-view-link', 'Expected bounded exact membership fraction.', field.location); }
                else integer(value, -250000, 250000, field.location);
                fields.push({ source: field.location, name: field.name, value });
            }
            fact.coordinates = { source: location.location, fields };
        }
        links.push(fact);
    }
    return { primary, entries };
}

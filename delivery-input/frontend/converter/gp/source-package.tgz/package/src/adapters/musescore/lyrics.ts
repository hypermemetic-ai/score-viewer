import type { MusicalEvent, MusicalPart, NoteDetails } from '../../core/model.js';
import { add, compare, q, type Rational } from '../../core/rational.js';
import { refuse, type Location } from '../../core/report.js';

/** Located source spans are not inferred from the next syllable or the app's start-only export. */
export function recoverLyrics(parts: MusicalPart[], measureClocks: Map<MusicalPart, Rational[]>, gap: (code: string, source: Location, message: string, disposition?: 'preserved') => void, captionSources: ReadonlySet<string> = new Set()): void {
    for (const part of parts) {
        const clocks = measureClocks.get(part)!;
        const voiceCount = part.measures.reduce((n, m) => Math.max(n, m.voices.length), 0);
        for (let vi = 0; vi < voiceCount; vi++) {
            if (!part.measures.some(m => m.voices[vi]?.some(event => (event.notes[0]?.lyrics ?? event.lyrics ?? []).some(lyric => lyric.melisma)))) continue;
            const spans: { lyric: NonNullable<NoteDetails['lyrics']>[number]; clock: Rational; event: MusicalEvent }[] = [];
            const endpoints = new Map<string, { measure: number; event: MusicalEvent }>();
            for (let mi = 0; mi < part.measures.length; mi++) for (const event of part.measures[mi].voices[vi] ?? []) {
                const clock = add(clocks[mi], event.start), key = `${clock.n}/${clock.d}`;
                for (const lyric of event.notes[0]?.lyrics ?? event.lyrics ?? []) if (lyric.melisma) spans.push({ lyric, clock, event });
                if (event.grace) continue;
                if (endpoints.has(key)) refuse('native-lyric-clock', 'Source voice contains ambiguous same-clock ordinary events.', event.source);
                endpoints.set(key, { measure: mi, event });
            }
            const incoming = new Map<string, number>();
            const lane = (clock: Rational, lyric: NonNullable<NoteDetails['lyrics']>[number]): string => `${clock.n}/${clock.d}:${lyric.number}:${lyric.placement ?? 'below'}`;
            for (const { lyric, clock } of spans) if (lyric.melisma!.duration.n > 0 && !lyric.melisma!.editorPlaceholder) {
                const key = lane(add(clock, lyric.melisma!.duration), lyric); incoming.set(key, (incoming.get(key) ?? 0) + 1);
            }
            for (const { lyric, clock, event } of spans) {
                if (lyric.melisma!.projection === 'rest-nbsp-backwards-placeholder') {
                    gap('native-lyric-backwards-placeholder', lyric.melisma!.source, 'The rest-owned NBSP-only backwards placeholder retains its exact signed source span and verse. Independently verified native rendering produces no extension line; MusicXML preserves the text without inventing a forward melisma.'); continue;
                }
                const source = lyric.melisma!.source, endClock = add(clock, lyric.melisma!.duration);
                const last = part.measures.length - 1, scoreEnd = last < 0 ? q(0) : add(clocks[last], part.measures[last].duration);
                if (compare(endClock, scoreEnd) > 0) refuse('native-lyric-endpoint', 'Source lyric span ends beyond the encoded part.', source);
                const endpoint = endpoints.get(`${endClock.n}/${endClock.d}`);
                const captions = endpoint ? (endpoint.event.notes[0]?.lyrics ?? endpoint.event.lyrics ?? []).filter(other => other.number === lyric.number && (other.placement ?? 'below') === (lyric.placement ?? 'below')) : [];
                const collision = captions.length > 0, caption = captions[0];
                const coalesced = endpoint && captions.length === 1 && !event.grace && event.notes.length && endpoint.event.notes.length
                    && lyric.source?.path && captionSources.has(lyric.source.path) && caption.source?.path && captionSources.has(caption.source.path)
                    && !caption.extend && !caption.melisma && (caption.printObject !== false) === (lyric.printObject !== false)
                    && incoming.get(lane(endClock, lyric)) === 1;
                if (endpoint && (!collision || coalesced) && !lyric.melisma!.editorPlaceholder) {
                    lyric.extendTo = { measure: endpoint.measure, position: endpoint.event.start, eventId: endpoint.event.id };
                    if (coalesced) gap('native-lyric-caption-stop', source, 'The examined positive source span attaches to its last Chord. One same-verse and same-placement endpoint caption carries the standard stop without replacing its authored text, duplicating its lyric owner or applying native off-note fixups.', 'preserved');
                } else {
                    let lo = 0, hi = clocks.length;
                    while (lo < hi) { const mid = (lo + hi) >>> 1; if (compare(clocks[mid], endClock) <= 0) lo = mid + 1; else hi = mid; }
                    const measure = Math.max(0, lo - 1), start = clocks[measure];
                    lyric.extendTo = { measure, position: add(endClock, q(-start.n, start.d)) };
                    gap(lyric.melisma!.editorPlaceholder ? 'native-lyric-placeholder' : collision ? 'native-lyric-endpoint-conflict' : 'native-lyric-endpoint-projection', source,
                        lyric.melisma!.editorPlaceholder ? 'The native one-tick initial underscore placeholder remains an exact located span; standard MusicXML retains its start marker without a fabricated next note.'
                            : collision ? 'The exact lyric endpoint coincides with another authored syllable in this verse. Its span remains located; a conflicting additional stop lyric is not invented.'
                                : 'The exact lyric endpoint remains a located source clock. MusicXML exports the start marker; an unresolved note attachment is not invented.');
                }
            }
        }
    }
}

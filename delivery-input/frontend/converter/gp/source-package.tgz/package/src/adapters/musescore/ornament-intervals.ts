import type { MusicalEvent, MusicalNote, MusicalPart, MusicalRelation, OrnamentDetails, OrnamentIntervalFact } from '../../core/model.js';
import { refuse, type Finding } from '../../core/report.js';
import { children, type SourceElement } from '../../core/source-xml.js';
import type { NativeBudget } from './budget.js';
const steps=['unison','second','third','fourth','fifth','sixth','seventh','octave'];
const qualities=['auto','diminished','minor','major','perfect','augmented'];
const usesSide=(subtype:string,side:'above'|'below')=>(side==='above'?['ornamentTrill','ornamentShortTrill','ornamentTurn','ornamentTurnInverted','ornamentTurnSlash','ornamentTremblement','ornamentPrallMordent','ornamentUpPrall','ornamentPrecompMordentUpperPrefix','ornamentUpMordent','ornamentPrallUp']:['ornamentMordent','ornamentTurn','ornamentTurnInverted','ornamentTurnSlash','ornamentTremblement','ornamentPrallMordent','ornamentDownMordent','ornamentPrallDown']).includes(subtype);
/** Native serialized interval tokens; source-defined normalization stays explicit. */
export function readNativeOrnamentInterval(node:SourceElement,subtype:string,side:'above'|'below'):OrnamentIntervalFact {
    const fields=node.text.trim().split(',');
    if(node.children.length||Object.keys(node.attrs).length||fields.length!==2||!steps.includes(fields[0])||!qualities.includes(fields[1]))return refuse('native-ornament-interval','Ornament interval needs exact native step and quality tokens.',node.location);
    const step=fields[0] as OrnamentIntervalFact['step'],encoded=fields[1] as OrnamentIntervalFact['quality'];
    const perfect=['unison','fourth','fifth','octave'].includes(step);
    // Interval::fromOrnamentInterval uses the natural major/perfect baseline
    // for quality tokens not specialized by that diatonic step family.
    const quality=perfect&&['major','minor'].includes(encoded)?'perfect':!perfect&&encoded==='perfect'?'major':encoded;
    const active=usesSide(subtype,side);
    return {source:node.location,step,quality,...(quality!==encoded?{encodedQuality:encoded}:{}),...(!active?{active:false}:{})};
}
/** Presentation policies choose native generated graphics, not another attack. */
export function readNativeOrnamentPolicy(node:SourceElement,details:OrnamentDetails):void {
    if(node.children.length||Object.keys(node.attrs).length)refuse('native-ornament-policy','Ornament presentation policy requires one scalar source token.',node.location);
    const value=node.text.trim();
    if(node.name==='ornamentShowCueNote'&&['auto','on','off'].includes(value))details.cueNote={source:node.location,value:value as 'auto'|'on'|'off'};
    else if(node.name==='ornamentShowAccidental'&&['0','1','2'].includes(value))details.showAccidental={source:node.location,value:(['default','any-alteration','always'] as const)[Number(value)]};
    else refuse('native-ornament-policy','Unknown native ornament presentation policy.',node.location);
}
/** Bind source-defined auxiliary meaning to the actual principal chord component. */
export function recoverNativeOrnamentPresentation(context:{parts:MusicalPart[];relations:MusicalRelation[];styles:readonly (SourceElement|undefined)[];isTop:(note:MusicalNote)=>boolean|undefined;budget:Pick<NativeBudget,'add'>}):Finding[] {
    const {parts,relations,isTop,budget}=context,findings:Finding[]=[];let style:SourceElement|undefined;
    for(const entry of context.styles)if(entry){const nodes=children(entry,'trillAlwaysShowCueNote');if(nodes.length>1)refuse('native-ornament-policy','Duplicate trill cue policy.',nodes[1].location);if(nodes.length)style=nodes[0];}
    if(style&&(style.children.length||Object.keys(style.attrs).length||!['0','1'].includes(style.text.trim())))refuse('native-ornament-policy','Trill cue style needs a source boolean.',style.location);
    const events=new Map<string,MusicalEvent>();for(const part of parts)for(const measure of part.measures)for(const voice of measure.voices)for(const event of voice)events.set(event.id,event);
    const qualify=(details:OrnamentDetails|undefined,event:MusicalEvent|undefined)=>{
        if(!details)return;
        if(style&&details.sourceSubtype==='ornamentTrill')details.alwaysShowTrillCue={source:style.location,value:style.text.trim()==='1'};
        const display=details.cueNote||details.showAccidental||details.alwaysShowTrillCue?.value;
        if(display)for(const [field,side] of [['intervalAbove','above'],['intervalBelow','below']] as const)if(!details[field]&&usesSide(details.sourceSubtype??'',side)){
            details[field]={source:details.source,step:'second',quality:'auto',origin:'native-default'};budget.add('markings',1,details.source);
        }
        if(!details.intervalAbove&&!details.intervalBelow&&!display)return;
        if(!event?.notes.length)return refuse('native-ornament-principal','An auxiliary interval requires its actual source chord.',details.source);
        const principal=event.notes.filter(note=>isTop(note)===true);
        if(principal.length!==1)refuse('native-ornament-principal','The native auxiliary principal depends on an unresolved source component or future system layout.',details.source);
        details.principal={source:principal[0].source,noteId:principal[0].id};budget.add('markings',1,details.source);
        findings.push({disposition:'preserved',code:'native-ornament-interval-text-projection',location:details.source,message:'The source auxiliary interval is a readable standard ornament instruction on its source principal note. Native cue/accidental presentation policy remains located; no generated cue attack is added. AUTO retains the diatonic interval under the exported active key and preceding written accidentals. This is a semantic text representation, not a MusicXML capability exemption.'});
    };
    for(const event of events.values())for(const ornament of event.ornaments??[])qualify(ornament.details,event);
    for(const relation of relations)if(relation.kind==='trill')qualify(relation.ornament,events.get(relation.start.eventId??''));
    return findings;
}

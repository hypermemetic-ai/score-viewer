import { canonicalSymbolVocabulary } from '../../core/canonical-symbols.js';
import type { MusicalEvent, OrnamentDetails } from '../../core/model.js';
type Form={kind:NonNullable<MusicalEvent['ornaments']>[number]['kind'];sign?:Omit<NonNullable<OrnamentDetails['sign']>,'source'>};
/** Musical attributes qualified against native symIdToOrnam; not renderer code. */
const forms:Readonly<Record<string,Form>>={
    ornamentTrill:{kind:'trill-mark'},ornamentShortTrill:{kind:'inverted-mordent'},ornamentMordent:{kind:'mordent'},
    ornamentTurn:{kind:'turn'},ornamentTurnInverted:{kind:'inverted-turn'},ornamentTurnSlash:{kind:'turn',sign:{slash:true}},
    ornamentTurnUp:{kind:'vertical-turn'},ornamentTurnUpS:{kind:'inverted-vertical-turn'},
    ornamentTremblement:{kind:'inverted-mordent',sign:{long:true}},ornamentPrallMordent:{kind:'mordent',sign:{long:true}},
    ornamentUpPrall:{kind:'inverted-mordent',sign:{long:true,approach:'below'}},
    ornamentPrecompMordentUpperPrefix:{kind:'inverted-mordent',sign:{long:true,approach:'above'}},
    ornamentUpMordent:{kind:'mordent',sign:{long:true,approach:'below'}},ornamentDownMordent:{kind:'mordent',sign:{long:true,approach:'above'}},
    ornamentPrallDown:{kind:'inverted-mordent',sign:{long:true,departure:'below'}},ornamentPrallUp:{kind:'inverted-mordent',sign:{long:true,departure:'above'}},
    // MusicXML does not distinguish line-prall from the upper-prefix prall; the
    // exact native subtype remains in the auxiliary ornament record.
    ornamentLinePrall:{kind:'inverted-mordent',sign:{long:true,approach:'above'}},
    ornamentHaydn:{kind:'haydn'},ornamentPrecompSlide:{kind:'schleifer'},
};
export function nativeOrnament(name:string):Form|undefined {
    if(Object.hasOwn(forms,name))return forms[name];
    if(name.startsWith('ornament')&&canonicalSymbolVocabulary.has(name))return {kind:'other-ornament',sign:{smufl:name}};
    return undefined;
}

import type {Part, NoteFact, MusicalRelation, RelationEndpoint} from '../../core/model.js';
import {refuse,type Finding} from '../../core/report.js';

/** Explicit flags corroborate the source reader's same-string / left-tap search order. */
export function gpifHopo(part:Part,relations:MusicalRelation[],findings:Finding[]):void {
    for(let voice=0;voice<Math.max(...part.measures.map(m=>m.voices.length));voice++) {
        const entries=part.measures.flatMap((measure,index)=>(measure.voices[voice]??[]).map(event=>({event,measure:index})));
        const next=new Map<string,{entry:typeof entries[number];note:NoteFact}>(),paired=new Set<NoteFact>();
        for(let index=entries.length-1;index>=0;index--) {
            const entry=entries[index];
            const endpoint=(item:typeof entry,note:NoteFact):RelationEndpoint=>({partId:part.id,measure:item.measure,position:item.event.start,staff:item.event.staff??1,voiceId:item.event.voiceId??String(voice+1),eventId:item.event.id,noteId:note.id});
            for(const origin of entry.event.notes) if(origin.sourceHopoOrigin) {
                const target=next.get(`${entry.event.staff??1}:${origin.string}`);
                if(!target?.note.sourceHopoDestination)return refuse('hopo-conflict','HOPO requires an explicit destination at the next source-ordered same-string or left-tapped candidate in the same voice and staff.',origin.source);
                if(paired.has(target.note))return refuse('hopo-conflict','Multiple H/P origins claim one explicitly marked destination.',target.note.source);
                paired.add(target.note);
                if(target.note.string===origin.string&&target.note.fret!==origin.fret) {
                    const kind=target.note.fret>origin.fret?'hammer-on':'pull-off';
                    origin.hopoStart=kind;target.note.hopoStop=kind;
                    findings.push({disposition:'inferred',code:'hopo-classification',message:'Paired source HOPO flags follow the next same-string attack and are classified by physical fret direction. Standard endpoints and a derived connection slur retain the exact event clocks without inventing phrasing or intervening notes (source-hopo/1).',location:origin.source,fact:{kind,destination:target.note.source}});
                } else {
                    const crossString=target.note.string!==origin.string;
                    (entry.event.performerInstructions??=[]).push({source:origin.source,kind:'hammer-on-pull-off',text:`Hammer-on/pull-off (string ${origin.string}${crossString?` to ${target.note.string}`:''})`,nativeValue:JSON.stringify({origin:origin.source,destination:target.note.source,originFlag:true,destinationFlag:true})});
                    const id=`gpif-hopo:${origin.id}`;
                    relations.push({source:origin.source,id,kind:'slur',sourceTechnique:{source:origin.source,kind:'hammer-on-pull-off'},start:endpoint(entry,origin),end:endpoint(target.entry,target.note)});
                    (origin.slurs??=[]).push({type:'start',number:1,relationId:id});(target.note.slurs??=[]).push({type:'stop',number:1,relationId:id});
                    findings.push({disposition:'preserved',code:'gpif-hopo-undirected',message:'Explicit H/P endpoints establish a connection but not a directional same-string fret change. The combined instruction, connection slur and any left-hand tap survive without inventing a hammer-on or pull-off direction.',location:origin.source,fact:{destination:target.note.source,reason:crossString?'cross-string-left-tap':'unchanged-fret'}});
                }
            }
            const byString=new Map(entry.event.notes.map(note=>[note.string,note]));
            const leftTap=(note:NoteFact)=>note.gestures?.some(g=>g.kind==='tap'&&g.hand==='left');
            for(let string=1;string<=part.tuning.length;string++) {
                let candidate=byString.get(string);
                if(!candidate)for(let lower=string-1;lower>=1;lower--){const note=byString.get(lower);if(note){if(leftTap(note))candidate=note;break;}}
                if(!candidate)for(let higher=string+1;higher<=part.tuning.length;higher++){const note=byString.get(higher);if(note){if(leftTap(note))candidate=note;break;}}
                if(candidate)next.set(`${entry.event.staff??1}:${string}`,{entry,note:candidate});
            }
        }
        for(const {event} of entries)for(const note of event.notes)if(note.sourceHopoDestination&&!paired.has(note))refuse('hopo-conflict','Unpaired explicit HOPO destination.',note.source);
    }
}

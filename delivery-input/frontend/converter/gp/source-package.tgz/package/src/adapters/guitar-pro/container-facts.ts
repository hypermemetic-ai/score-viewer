import { Bytes, sha256 } from './bytes.js';
import { refuse, type Finding } from '../../core/report.js';
import { child, integer, parseXml, value } from './xml.js';
export interface ContainerFact { member: string; kind?: 'directory'; bytes: number; sha256: string; dataBase64: string; records?: Record<string, unknown> }
export interface DisplaySettings { hideDynamics: boolean; hideTempo: boolean }

/** Independent bounded decoding of the documented binary key/value layout, not upstream code reuse. */
function stylesheet(b: Bytes, member: string): Record<string, unknown> {
    let pos = 0;
    const fail = (): never => refuse('stylesheet', 'Malformed/unsupported bounded stylesheet key/value data.', { member });
    const take = (n: number): Bytes => { if (n < 0 || pos + n > b.length) fail(); const r = b.subarray(pos, pos + n); pos += n; return r; };
    const count = take(4).readUInt32BE();
    if (count > 2048) fail();
    const records: Record<string, unknown> = Object.create(null);
    for (let i = 0; i < count; i++) {
        const key = new TextDecoder('utf8', { fatal: true }).decode(take(take(1)[0]));
        if (!/^[A-Za-z0-9_. /-]{1,255}$/.test(key) || key in records) fail();
        const type = take(1)[0]; let value: unknown;
        switch (type) {
            case 0: { const v = take(1)[0]; if (v > 1) fail(); value = !!v; break; }
            case 1: value = take(4).readInt32BE(); break;
            case 2: { const v = take(4).readFloatBE(); if (!Number.isFinite(v)) fail(); value = v; break; }
            case 3: { const length = take(2).readUInt16BE(); if (length > 16384) fail(); value = new TextDecoder('utf8', { fatal: true }).decode(take(length)); break; }
            case 4: case 5: value = [take(4).readInt32BE(), take(4).readInt32BE()]; break;
            case 6: value = [take(4).readInt32BE(), take(4).readInt32BE(), take(4).readInt32BE(), take(4).readInt32BE()]; break;
            case 7: value = [...take(4)]; break;
            default: fail();
        }
        records[key] = value;
    }
    if (pos !== b.length) fail();
    if ('Global/translateTunings' in records && typeof records['Global/translateTunings'] !== 'boolean') refuse('stylesheet', 'Expected boolean Global/translateTunings.', { member });
    if (records['Global/translateTunings'] === true) refuse('stylesheet-pitch', 'Active translated tuning may change displayed pitch; that convention is not exercised.', { member });
    return records;
}
export function captureContainer(members: Map<string, Bytes>, gp8: boolean, findings: Finding[], captureRaw = true): { facts: ContainerFact[]; display: DisplaySettings } {
    const facts: ContainerFact[] = [], display = { hideDynamics: false, hideTempo: false };
    for (const [member, b] of members) {
        if (member === 'Content/score.gpif') continue;
        if (member.endsWith('/')) {
            if (captureRaw) facts.push({ member, kind: 'directory', bytes: 0, sha256: sha256(b), dataBase64: '' });
            findings.push({ disposition: 'preserved', code: 'container-directory', message: 'Validated empty ZIP directory is retained as directory metadata, not a payload file.', location: { member } });
            continue;
        }
        if (member !== 'VERSION' && (!gp8 || !['Content/BinaryStylesheet', 'Content/LayoutConfiguration', 'Content/PartConfiguration', 'Content/Preferences.json', 'Content/misc.xml', 'meta.json'].includes(member) && !/^Content\/(?:ScoreViews\/\d{1,2}\.gpsv|Stylesheets\/(?:score|scoreview\d{1,2})\.gpss)$/.test(member)))
            refuse('container-member', `Unreviewed container member ${member}; assets/protection or unknown musical configuration require admission.`, { member });
        const fact: ContainerFact = { member, bytes: b.length, sha256: captureRaw ? sha256(b) : '', dataBase64: captureRaw ? b.base64() : '' };
        if (member === 'Content/BinaryStylesheet') {
            fact.records = stylesheet(b, member);
            for (const key of ['StandardNotation/hideDynamics', 'Global/hideGlobalTempo']) {
                if (key in fact.records && typeof fact.records[key] !== 'boolean') refuse('stylesheet', `Expected boolean ${key}.`, { member });
            }
            display.hideDynamics = fact.records['StandardNotation/hideDynamics'] === true;
            display.hideTempo = fact.records['Global/hideGlobalTempo'] === true;
            findings.push({ disposition: 'preserved', code: 'source-visibility', message: 'Decoded BinaryStylesheet dynamic/tempo visibility flags are applied independently of musical values; opaque GP8 sidecar overrides are not applied.', location: { member }, fact: display });
        } else if (member === 'Content/misc.xml') {
            const root = parseXml(b, member, 'MISC').root;
            if (root.name !== 'MISC' || root.text.trim() || Object.keys(root.attrs).length || root.children.length !== 1 || root.children[0].name !== 'TracksView') refuse('container-metadata', 'Unreviewed GP6 miscellaneous configuration.', root.location);
            const view = child(root, 'TracksView')!, count = child(view, 'PreferredTrackCount')!;
            if (view.text.trim() || Object.keys(view.attrs).length || view.children.length !== 1 || Object.keys(count.attrs).length || count.children.length) refuse('container-metadata', 'Unreviewed GP6 track-view configuration.', view.location);
            fact.records = { preferredTrackCount: integer(value(view, 'PreferredTrackCount'), 0, 999999, count) };
        } else if (member === 'Content/Preferences.json' || member === 'meta.json') {
            const parsed: unknown = JSON.parse(new TextDecoder('utf8', { fatal: true }).decode(b));
            if (member === 'meta.json' && parsed !== null && !(typeof parsed === 'object' && !Array.isArray(parsed) && Object.keys(parsed).length === 0)) refuse('container-metadata', 'Only empty object/null meta.json is exercised.', { member });
            if (member === 'Content/Preferences.json') {
                if (!parsed || typeof parsed !== 'object' || Array.isArray(parsed) || Object.keys(parsed).some(k => !['tonality', 'tempo', 'view'].includes(k)))
                    refuse('container-preferences', 'Unreviewed preferences require admission.', { member });
                fact.records = parsed as Record<string, unknown>;
            }
        }
        if (captureRaw) facts.push(fact);
        if (member !== 'VERSION') findings.push({ disposition: 'omitted', code: 'container-display-synth', message: 'Original member bytes are observed intact; local capture is delivered only on success. Page/view layout, synth timbre and practice/display preferences are not reapplied; exported musical pitch/rhythm comes from corroborated GPIF facts. Only decoded BinaryStylesheet visibility flags are applied. GP8 .gpss/.gpsv sidecar overrides are unparsed/unapplied and may alter source presentation.', location: { member } });
    }
    return { facts, display };
}

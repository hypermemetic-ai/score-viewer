import type { MusicalPart } from '../../core/model.js';
import { refuse, type Finding } from '../../core/report.js';
import { child, integer, value, type Element } from './xml.js';
export interface PartialCapo { source: Element['location']; fret: number; flags: string }
/** Producer-authored GP7.5 controls establish left-to-right flags in native tuning order. */
export function readPartialCapo(properties: Map<string, Element>, stringCount: number): PartialCapo | undefined {
    const fret = properties.get('PartialCapoFret'), flags = properties.get('PartialCapoStringFlags');
    if (!fret && !flags) return undefined;
    if (fret && !flags && fret.children.length === 1 && value(fret, 'Fret') === '0') return undefined;
    if (!fret && flags && flags.children.length === 1 && ['Bitset','Flags'].includes(flags.children[0].name) && /^0+$/.test(flags.children[0].text.trim())) return undefined;
    // GP7 revision 12020 stores an inactive scalar Flags=0 alongside Fret=0.
    // No active-mask orientation is implied by this empty-state representation.
    if (fret && flags && fret.children.length === 1 && value(fret, 'Fret') === '0' && flags.children.length === 1 && child(flags, 'Flags', false) && value(flags, 'Flags') === '0') return undefined;
    if (!fret || !flags || fret.children.length !== 1 || !child(fret, 'Fret', false) || flags.children.length !== 1 || !child(flags, 'Bitset', false)) refuse('partial-capo', 'Partial capo requires one explicit fret and bitset tuple.', (fret ?? flags)!.location);
    const number = integer(value(fret!, 'Fret'), 0, 999999, fret!), bits = value(flags!, 'Bitset');
    // GP8 serializes an inactive six-bit guitar mask on four-string bass staves.
    // Zero fret plus an all-zero mask has no string-specific effect or active orientation.
    if (number === 0 && /^0{1,16}$/.test(bits)) return undefined;
    if (!/^[01]{1,16}$/.test(bits) || bits.length !== stringCount) refuse('partial-capo', 'Partial capo bitset must match every explicitly ordered source string.', flags!.location);
    return { source: fret!.location, fret: number, flags: bits };
}
export function partialOpenOffset(capo: number, partial: PartialCapo | undefined, stringIndex: number): number {
    return Math.max(capo, partial?.flags[stringIndex] === '1' ? partial.fret : 0);
}
export function physicalFret(capo: number, partial: PartialCapo | undefined, stringIndex: number, fret: number): number {
    return fret === 0 ? partialOpenOffset(capo, partial, stringIndex) : capo + fret;
}
export function partialCapoInstruction(part: MusicalPart, partial: PartialCapo, findings: Finding[]): void {
    const strings = [...partial.flags].flatMap((bit, index) => bit === '1' ? [partial.flags.length - index] : []);
    const source = { ...partial.source, trackId: part.id };
    findings.push({ disposition: 'preserved', code: 'partial-capo', message: 'Source partial capo flags follow native tuning order. Open strings use the higher full/partial capo; positive source frets keep their full-capo reference. The partial capo is a standard performer instruction, not a false full-staff capo or retuning.', location: source, fact: { fret: partial.fret, flags: partial.flags, strings, fullCapo: part.capo?.fret ?? 0 } });
    if (!partial.fret || !strings.length) return;
    (part.capoChanges ??= []).push({ source, measure: 0, position: {n:0,d:1}, staff: 1, active: true, fret: partial.fret,
        ignoredStrings: { source, values: [...partial.flags].flatMap((bit,index) => bit === '0' ? [partial.flags.length-index] : []) },
        text: `Partial capo ${partial.fret} (strings ${strings.join(', ')}; positive frets relative to ${part.capo?.fret ? `full capo ${part.capo.fret}` : 'nut'})` });
}

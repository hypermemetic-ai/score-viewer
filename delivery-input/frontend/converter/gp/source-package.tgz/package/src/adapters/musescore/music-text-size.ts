import type { TextFontSize, TextRun } from '../../core/model.js';
import type { SourceElement as Element } from '../../core/source-xml.js';
import { createNativeTextSizeProjector, type NativeTextScaleContext } from './text-size.js';

type Dependency = NonNullable<TextFontSize['pointSize']>['spatiumDependent'];
const plain = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length;
const defaults: Readonly<Record<string, number>> = { dynamics: 11, pedal: 12, default: 10, staff: 10, system: 10, expression: 10, tempo: 20, metronome: 12, rehearsalMark: 14, fingering: 8, lhGuitarFingering: 8, rhGuitarFingering: 8, title: 22, composer: 10, frame: 10, lyricsOdd: 10, lyricsEven: 10, textLine: 10, systemTextLine: 10, hairpin: 10 };
export type NativeMusicTextSizeRun = Pick<TextRun, 'symbolName' | 'sourceText' | 'sourceFont' | 'textFontSize' | 'lineFontSize' | 'musicFontSize' | 'script'>;
export const isMusicTextRun = (run: NativeMusicTextSizeRun): boolean => !!(run.symbolName || run.sourceText || run.sourceFont?.face === 'ScoreText');

/** TextFragment music fonts have source-version-specific units. In particular,
 * a modern Tempo's symbol size is independent of later ordinary font requests. */
export function createNativeMusicTextSize(scopes: readonly Element[], nativeVersion?: string, use?: (field: Element) => unknown) {
    const version = Number(nativeVersion), fields = scopes.flatMap(scope => scope.children);
    const project = createNativeTextSizeProjector(scopes, nativeVersion, use);
    const field = (name: string) => fields.filter(f => f.name === name).at(-1);
    const selector = field('defaultsVersion');
    const knownDefaults = !selector || plain(selector) && ['114', '206', '301', '302', '400', '410', '420', '430', '440', '450', '460', '470'].includes(selector.text.trim());
    const request = (item: Element | undefined, fallback: number | undefined, owner: Element, origin: TextFontSize['origin']): TextFontSize | undefined => {
        if (!item) return fallback === undefined || !knownDefaults ? undefined : { source: owner.location, rawValue: String(fallback), value: fallback, origin: 'native-default' };
        if (!plain(item) || !/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(item.text.trim()) || !(Number(item.text) > 0 && Number(item.text) <= 10000)) return undefined;
        use?.(item); return { source: item.location, rawValue: item.text, value: Number(item.text), origin };
    };
    return (owner: Element, run: NativeMusicTextSizeRun, base: TextFontSize | undefined, dependency: Dependency | undefined, scale: NativeTextScaleContext | undefined, prefix?: string): void => {
        if (!isMusicTextRun(run) || !prefix || !dependency || !scale || !(version >= 3 && version < 5)) return;
        let size = run.lineFontSize?.request ?? run.textFontSize ?? base
            ?? request(undefined, prefix === 'tempo' ? 12 : prefix === 'dynamics' ? version >= 4 ? 10 : version < 3.02 || ['114', '206', '301'].includes(selector?.text.trim() ?? '') ? 12 : 11 : defaults[prefix], owner, 'native-default');
        let factor = 1, rule: NonNullable<NonNullable<TextFontSize['pointSize']>['music']>['rule'] = 'fragment';
        let context = scale, units = dependency;
        const dynamic = owner.name === 'Dynamic';
        const scaledMusic = dynamic && version >= 4.1 || version >= 4.4 && ['pedal', 'ottava', 'tuplet'].includes(prefix);
        if (scaledMusic) {
            rule = 'smufl-scale'; factor = version >= 4.7 ? 4 * 1.75 * 72 / 25.4 : 20;
            const explicit = owner.children.filter(f => f.name === (version >= 4.7 ? 'musicalSymbolsScale' : dynamic ? 'dynamicsSize' : '')).at(-1);
            const inherited = field(dynamic ? 'dynamicsSize' : `${prefix}MusicalSymbolsScale`);
            size = request(explicit ?? inherited, 1, owner, explicit ? 'source-property' : 'source-style');
            context = { ...scale }; delete context.lineSpatiumDependent;
            if (dynamic && version < 4.7) units = { source: owner.location, value: true, origin: 'native-default' };
        } else if (dynamic && version >= 4) { rule = 'legacy-dynamic'; factor = 2; }
        else if (version >= 4.7 || version >= 4.6 && ['Tempo', 'StaffText', 'SystemText', 'Marker'].includes(owner.name)) {
            rule = 'symbol-size';
            const explicit = owner.children.filter(f => f.name === 'musicSymbolSize').at(-1);
            const inherited = version >= 4.7 ? field(`${prefix === 'staff' || prefix === 'system' ? prefix + 'Text' : prefix}MusicalSymbolSize`) : undefined;
            if (explicit || inherited) size = request(explicit ?? inherited, undefined, owner, explicit ? 'source-property' : 'source-style');
            else if (version < 4.7 && owner.name === 'Tempo') {
                const ordinary = request(field('tempoFontSize'), 12, owner, 'source-style');
                if (ordinary) { size = ordinary; factor = 5 / 3; rule = 'tempo-ratio'; }
                else size = undefined;
            } else size = request(undefined, version < 4.7 ? 18 : defaults[prefix], owner, 'native-default');
            // TextLineBase's later setSize affects the ordinary formatter size,
            // not its independent MUSIC_SYMBOL_SIZE property.
            context = { ...scale }; delete context.lineSpatiumDependent;
        } else if (version >= 4 && owner.name === 'Tempo') { factor = 5 / 3; rule = 'tempo-ratio'; }
        if (!size) return;
        const point = project({ ...owner, name: 'StaffText', children: [] }, size, units, context);
        if (!point || point.value * factor > 10000) return;
        run.musicFontSize = { ...size, pointSize: { ...point, value: point.value * factor, music: { nativeVersion: nativeVersion!, rule, factor } } };
        if (run.script && (rule === 'fragment' || rule === 'tempo-ratio' && version < 4.6)) run.script = { ...run.script, projection: { origin: 'derived-readable-layout', relativeY: run.script.value === 'super' ? 6 : run.script.value === 'sub' ? -4 : 0, sizeFactor: run.script.value === 'normal' ? 1 : .6 } };
    };
}

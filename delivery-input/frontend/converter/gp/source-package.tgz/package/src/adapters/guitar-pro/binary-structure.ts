import type { Score } from '../../../third_party/alphatab/src/model/Score.js';
import type { Beat } from '../../../third_party/alphatab/src/model/Beat.js';
import type { ChordFrame, MusicalEvent as Event, MusicalRelation, MusicalScore, MusicalPart as Part } from '../../core/model.js';
import { refuse, type Location, type Finding } from '../../core/report.js';
import { masterStructure, scoreTexts, trackLyrics } from './structure.js';
import type { Element } from './xml.js';
import { Bytes } from './bytes.js';
import { equal, type Rational } from '../../core/rational.js';

/** An incomplete source bar has exact encoded extent, not an invented trailing rest. */
export function binaryMeasureExtent(totals:Rational[],nominal:Rational,index:number,count:number,source:Location,findings:Finding[]):{duration:Rational;pickup:boolean} {
    if(!totals.length||totals.some(total=>total.n<=0||!equal(total,totals[0])))refuse('measure-duration','Active binary voices must agree about their exact encoded measure extent.',source);
    const short=totals[0].n*nominal.d<nominal.n*totals[0].d,pickup=index===0&&short,final=index===count-1&&short;
    if(final&&!pickup)findings.push({disposition:'inferred',code:'binary-incomplete-final-measure',message:'All active source voices establish a shorter final measure. Exact encoded extent and nominal meter remain separate; no trailing attack or rest is added.',location:source,fact:{nominal,encoded:totals[0]}});
    if(short&&!pickup&&!final)findings.push({disposition:'inferred',code:'binary-incomplete-measure',message:'All active source voices establish the same incomplete interior measure. Exact encoded extent and nominal meter remain separate; it is not labelled a pickup and no trailing attack or rest is added.',location:source,fact:{nominal,encoded:totals[0]}});
    if(!short&&!equal(totals[0],nominal))findings.push({disposition:'inferred',code:'binary-overfull-measure',message:'All active source voices establish the same overfull measure. Its exact encoded extent and nominal meter remain separate without deleting or retiming source notes.',location:source,fact:{nominal,encoded:totals[0]}});
    return {duration:totals[0],pickup};
}

export interface BinaryStructureFrame { source: Location; facts: Record<string, number> }
const node=(name:string,source:Location,text='',children:Element[]=[]):Element=>({name,location:source,text,children,attrs:{}});
const decode=(bytes:Uint8Array)=>new TextDecoder(bytes.length>2&&bytes[0]===0xfe&&bytes[1]===0xff?'utf-16be':bytes.length>2&&bytes[0]===0xff&&bytes[1]===0xfe?'utf-16le':'windows-1252').decode(bytes);
const navigation=['Fine','Segno','SegnoSegno','Coda','DoubleCoda','DaCapo','DaCapoAlCoda','DaCapoAlDoubleCoda','DaCapoAlFine','DaSegno','DaSegnoAlCoda','DaSegnoAlDoubleCoda','DaSegnoAlFine','DaSegnoSegno','DaSegnoSegnoAlCoda','DaSegnoSegnoAlDoubleCoda','DaSegnoSegnoAlFine','DaCoda','DaDoubleCoda'];

/** Reuse musical structure rules; synthetic containers retain actual binary byte locations. */
export function binaryMasterStructure(score:Score,masters:BinaryStructureFrame[],globals:Record<string,number>,locations:Map<string,Location>,parts:Part[],relations:MusicalRelation[],version:number):void {
    const endings:number[]=[],sources:Element[]=[];
    for(let index=0;index<masters.length;index++) {
        const frame=masters[index], fields:Element[]=[],master=score.masterBars[index];
        const at=(name:string)=>locations.get(frame.source.path+'/'+name)??frame.source;
        let mask=frame.facts['alternate-endings']??0;
        const count=frame.facts['alternate-ending-count'];
        if(count!==undefined) {
            if(count<1||count>8)refuse('repeat-ending','Invalid cumulative binary ending count.',at('alternate-ending-count'));
            let used=0;
            for(let previous=index-1;previous>=0;previous--) {
                if(score.masterBars[previous].isRepeatStart || score.masterBars[previous].repeatCount&&previous!==index-1)break;
                used|=endings[previous];
            }
            mask=((1<<count)-1)&~used;
            if(!mask)refuse('repeat-ending','Cumulative binary ending adds no remaining pass.',at('alternate-ending-count'));
        }
        endings.push(mask);
        if(master.alternateEndings!==mask)refuse('repeat-ending','Reader ending interpretation contradicts source fields.',frame.source);
        if(mask)fields.push(node('AlternateEndings',at(count===undefined?'alternate-endings':'alternate-ending-count'),Array.from({length:8},(_,i)=>i+1).filter(i=>mask&(1<<(i-1))).join(' ')));
        const feel=version>=500?frame.facts['triplet-feel']:globals['global-triplet-feel'];
        if(feel)fields.push(node('TripletFeel',version>=500?at('triplet-feel'):locations.get('/header/global-triplet-feel')!,feel===1?'Triplet8th':'Triplet16th'));
        if(master.section)fields.push(node('Section',frame.source,'',[node('Text',frame.source,master.section.text)]));
        if(frame.facts['master-flags']&128)fields.push(node('DoubleBar',at('master-flags')));
        const directions:Element[]=[];
        for(const [key,value] of Object.entries(globals))if(key.startsWith('navigation:')&&value!==-1) {
            const source=locations.get('/header/'+key)!;
            if(value<1||value>masters.length)refuse('navigation','Navigation measure lies outside the encoded score.',source);
            const kind=Number(key.slice(11));
            if(value===index+1)directions.push(node(kind<5?'Target':'Jump',source,navigation[kind]));
        }
        if(directions.length)fields.push(node('Directions',frame.source,'',directions));
        sources.push(node('MasterBar',frame.source,'',fields));
    }
    for(const part of parts)sources.forEach((source,index)=>masterStructure(source,part.measures[index],part,index,relations));
}

export function binaryScoreTexts(score:Score,source:Location,partId:string):Pick<MusicalScore,'metadata'|'credits'> {
    const values:Record<string,string>={Title:score.title,SubTitle:score.subTitle,Artist:score.artist,Album:score.album,Words:score.words,Music:score.music,Copyright:score.copyright,Tabber:score.tab,Instructions:score.instructions,Notices:score.notices};
    return scoreTexts(node('Score',source,'',Object.entries(values).map(([name,text])=>node(name,source,text))),partId);
}

export function binaryLyrics(bytes:Bytes,frame:BinaryStructureFrame|undefined,locations:Map<string,Location>,parts:Part[]):void {
    if(!frame)return;
    const part=parts.find(part=>part.id===String(frame.facts['lyrics-track']));
    if(!part)return;
    const lines:Element[]=[];
    for(let i=0;i<5;i++) {
        const source=locations.get(`/lyrics/lyrics-present:${i}`)!;
        const length=bytes.readUInt32LE(source.byteOffset!);
        if(source.byteLength!==length+4)refuse('lyrics','Lyric byte length contradicts captured field.',source);
        const text=decode(bytes.subarray(source.byteOffset!+4,source.byteOffset!+4+length));
        lines.push(node('Line',source,'',[node('Text',source,text),node('Offset',locations.get(`/lyrics/lyrics-start:${i}`)!,String(frame.facts[`lyrics-start:${i}`]-1))]));
    }
    trackLyrics(node('Track',frame.source,'',[node('Lyrics',frame.source,'',lines)]),part);
}

export function binaryChord(bytes:Bytes,version:number,frame:BinaryStructureFrame,event:Event,part:Part,measure:number,locations:Map<string,Location>,findings:Finding[],sourceStringCount?:number):void {
    const offset=frame.source.byteOffset!,enhanced=version>=500||bytes[offset]!==0;
    const fixed=version>=400?21:22;
    const start=offset+(version>=500?17:enhanced?version>=400?17:26:1);
    const length=enhanced?bytes[start]:bytes.readUInt32LE(start)-1;
    if(length<0||enhanced&&length>fixed)refuse('chord','Invalid encoded chord caption length.',frame.source);
    const textStart=start+(enhanced?1:5);
    const caption=decode(bytes.subarray(textStart,textStart+length));
    const at=(name:string)=>locations.get(frame.source.path+'/'+name)??frame.source;
    const strings=sourceStringCount??part.tuning!.length, first=frame.facts['chord-first-fret'];
    const notes:ChordFrame['notes']=[],markers:NonNullable<ChordFrame['markers']>=[];
    for(let i=0;i<strings;i++) {
        const fret=frame.facts[`chord-fret:${i}`];if(fret===undefined)continue;
        if(!Number.isSafeInteger(fret)||fret< -1)refuse('chord','Diagram fret is outside its encoded nonnegative or muted domain.',at(`chord-fret:${i}`));
        if(fret===-1)markers.push({source:at(`chord-fret:${i}`),string:i+1,kind:'muted'});
        else {
            const finger=frame.facts[`chord-finger:${i}`];
            if(finger!==undefined&&(finger< -2||finger>4))refuse('chord','Unknown source diagram fingering.',at(`chord-finger:${i}`));
            notes.push({source:at(`chord-fret:${i}`),string:i+1,fret,...(finger!==undefined&&finger>=0?{fingering: finger===0?'T':String(finger),fingeringVisible:!!frame.facts['chord-show-fingering']}:{})});
        }
    }
    const barres=frame.facts['chord-barre-count']??0;
    if(barres<0||barres>(version<400?2:5))refuse('chord','Diagram barre count exceeds encoded capacity.',at('chord-barre-count'));
    for(let i=0;i<barres;i++) {
        const fret=frame.facts[`chord-barre-fret:${i}`],a=frame.facts[`chord-barre-start:${i}`],b=frame.facts[`chord-barre-end:${i}`];
        if(!Number.isSafeInteger(fret)||fret<1||a<1||b<1||a>strings||b>strings||a===b)refuse('chord','Invalid source diagram barre endpoints.',at(`chord-barre-fret:${i}`));
        for(const [string,barre] of [[Math.max(a,b),'start'],[Math.min(a,b),'stop']] as const) {const existing=notes.find(note=>note.string===string&&note.fret===fret&&!note.barre);if(existing)existing.barre=barre;else notes.push({source:at(`chord-barre-fret:${i}`),string,fret,barre});}
    }
    const present=notes.length||markers.length;
    if(present&&(!Number.isSafeInteger(first)||first<0))refuse('chord','Invalid diagram first fret.',at('chord-first-fret'));
    if(!notes.length&&markers.length) {
        const text=[caption,`Mute strings ${markers.map(marker=>marker.string).join(', ')}`].filter(Boolean).join(' — ');
        (part.measures[measure].directions??=[]).push({source:frame.source,position:event.start,staff:1,kind:'words',text});
        findings.push({disposition:'preserved',code:'binary-empty-frame-text',message:'MusicXML requires a played frame-note. This all-muted source diagram is preserved as explicit string instructions without inventing a fret.',location:frame.source,fact:{caption,markers}});return;
    }
    const frameFact:ChordFrame|undefined=present?{source:frame.source,strings,firstFret:Math.max(1,first),frets:Math.max(4,...notes.map(note=>note.fret-Math.max(1,first)+1)),notes,markers}:undefined;
    const sourceAnalysis=Object.entries(frame.facts).filter(([name])=>name.startsWith('chord-analysis')||name.startsWith('chord-omission')).map(([name,value])=>({source:at(name),name,value}));
    if(caption||frameFact)(part.measures[measure].directions??=[]).push({source:frame.source,position:event.start,staff:1,kind:'harmony',harmony:{source:frame.source,value:caption,role:'chord-symbol',...(sourceAnalysis.length?{sourceAnalysis}:{}),...(frameFact?{frame:frameFact}:{})}});
}

import type { MusicalPart } from '../../core/model.js';
import { refuse, type Finding } from '../../core/report.js';
/** Master keys are concert keys; written parts use the same independently established instrument interval as their notes. */
export function transposeWrittenKeys(part: MusicalPart, findings: Finding[]): void {
    const interval = part.transpose;
    if (!interval?.chromatic) return;
    const modulo=(n:number,d:number)=>((n%d)+d)%d;
    for (const measure of part.measures) {
        const sourceFifths=measure.key.fifths;
        // Relative major identifies a signature equally for major and minor. Transpose both its pitch class and spelling.
        const targetPitch=modulo(sourceFifths*7-interval.chromatic,12),targetLetter=modulo(sourceFifths*4-interval.diatonic,7);
        const matches=Array.from({length:71},(_,i)=>i-35).filter(f=>modulo(f*7,12)===targetPitch&&modulo(f*4,7)===targetLetter);
        if(matches.length!==1)refuse('key-transpose','Source instrument interval cannot establish one bounded written key signature.',measure.source);
        measure.key={...measure.key,fifths:matches[0]};
        findings.push({disposition:'inferred',code:'written-key-transposition',message:'Concert master key is transposed by the independently established sounding-from-written instrument interval. Source fifths and spelling interval remain separate from the derived standard written key.',location:measure.source,fact:{sourceFifths,writtenFifths:matches[0],mode:measure.key.mode,chromatic:interval.chromatic,diatonic:interval.diatonic}});
    }
}

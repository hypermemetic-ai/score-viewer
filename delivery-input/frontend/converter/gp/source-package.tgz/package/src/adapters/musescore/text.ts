import { captureXml, child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import { refuse, Refusal } from '../../core/report.js';
import type { Direction, TextRun, TextEmphasis } from '../../core/model.js';
import { symbolVocabulary } from '../../core/symbols.js';
import type { ParsedNativeCapture } from './capture-core.js';
import type { NativeBudget } from './budget.js';

interface NativeTextContext {
    capture: Pick<ParsedNativeCapture, 'nativeVersion'>;
    budget: NativeBudget;
    use: (element: Element) => Element;
    omit: (element: Element, reason: string) => void;
    performanceGap: (code: string, source: Element['location'], message: string, disposition?: 'omitted' | 'inferred' | 'preserved') => void;
}

export interface InlineRuns { values: TextRun[]; emphasized: boolean; limits: Set<string>; resets?: TextRun['emphasisResets']; font?: TextRun['sourceFont']; size?: TextRun['textFontSize']; script?: TextRun['script']; nameGlyphs?: boolean; tempoAugmentationDot?: boolean; systemTextGlyphs?: boolean; nativeDynamicPairs?: boolean }

/** Reader-local text recovery; source ownership, budgets and finding order remain with the caller. */
export function createNativeTextReader({ capture, budget, use, omit, performanceGap }: NativeTextContext) {
    const readTextEmphasis = (e: Element): TextEmphasis | undefined => {
        let emphasis: TextEmphasis | undefined;
        for (const name of ['bold', 'italic', 'underline', 'strike'] as const) {
            const field = child(e, name); if (!field) continue;
            // Native 3 TextBase has no strike property or rendering bit. Keep
            // this unknown source field captured for the presentation gap.
            if (name === 'strike' && !capture.nativeVersion?.startsWith('4.')) continue;
            if (field.children.length || Object.keys(field.attrs).length) refuse('native-text-emphasis', 'Authored text emphasis requires one plain boolean property.', field.location);
            const value = integer(field.text.trim(), 0, 1, field.location) === 1;
            use(field); budget.add('markings', 1, field.location);
            (emphasis ??= {})[name] = { source: field.location, value };
        }
        return emphasis;
    };
    // D45: TextBase captions are read by one loader per format family.
    // 3.x (Qt stream reader) expands every nested element to an opening and
    // closing token and keeps root whitespace. 4.00-4.60 (tinyxml2, then pugixml)
    // also writes pairs but drops whitespace-only text. 4.70 writes a
    // self-closing token for an element with no DOM child.
    const nativeTextLoader: 'legacy' | 'paired' | 'current' | undefined = ['3.01', '3.02'].includes(capture.nativeVersion ?? '') ? 'legacy'
        : capture.nativeVersion === '4.70' ? 'current' : /^4\.[0-6]0$/.test(capture.nativeVersion ?? '') ? 'paired' : undefined;
    const ordinaryFamily = (value: string): boolean => !!value && value === value.trim() && value !== 'ScoreText' && !/[,\t\r\n\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(value);
    const readTextFamily = (owner: Element): Direction['textFontFamily'] => {
        const field = child(owner, 'family'); if (!field) return undefined;
        if (field.children.length || Object.keys(field.attrs).length) {
            omit(field, 'native-text-family-unexamined-shape');
            performanceGap('native-text-family-projection', field.location, 'The unexamined encoded family property remains captured; no effective family is guessed.'); return undefined;
        }
        if (field.text.length > 65536) refuse('native-field-budget', 'Native text family exceeds the existing bounded text profile.', field.location);
        use(field); budget.add('markings', 1, field.location);
        if (!ordinaryFamily(field.text)) performanceGap('native-text-family-projection', field.location, 'The exact owner family remains located. Empty/default, symbolic ScoreText or unrepresentable family-list context does not establish an ordinary standard font hint.');
        return { source: field.location, value: field.text, origin: 'source-property' };
    };
    const qualifyTextFamilies = (runs: TextRun[], family: Direction['textFontFamily']): void => {
        let active = family && ordinaryFamily(family.value) ? family.value : undefined, introduced = !!active, unsafeReset = false;
        for (const run of runs) {
            const font = run.sourceFont;
            if (font) {
                if (!font.qualification && ordinaryFamily(font.face)) font.role = 'ordinary-family';
                active = font.role === 'ordinary-family' ? font.face : undefined;
                if (!active) performanceGap('native-text-family-projection', font.source, 'The exact source font token remains located. A symbolic, empty or ambiguous context is not resolved to an ordinary font family.');
            }
            if (!run.symbolName) { if (introduced && !active) unsafeReset = true; introduced ||= !!active; }
        }
        if (unsafeReset) performanceGap('native-text-family-reset', family?.source ?? runs[0].source, 'This caption returns from a qualified family to an unresolved font context. Ordinary family hints are withheld for the caption because MusicXML cannot reset them to an unknown native default without inventing a family. Exact runs and all source family facts remain located.');
    };
    // No MuseScore 3 or 4 symbol table names dynamicPForte; every formatter
    // drops the unknown symbol and prints only the following f.
    const legacyInvalidHairpinCaption = (type: string, subtype: string | undefined, field: string, node: Element | undefined): node is Element =>
        !!nativeTextLoader && type === 'HairPin' && subtype === '1' && field === 'beginText'
        && !!node && !node.children.length && !Object.keys(node.attrs).length && !node.hasComment
        && node.text === '<sym>dynamicPForte</sym><sym>dynamicForte</sym>';
    const emphasisBits = { b: 1, i: 2, u: 4, s: 8 } as const;
    const textBaseProperty = (node: Element): boolean => node.name === 'text'
        && /\/(?:StaffText|SystemText|Expression|Tempo|Dynamic|Lyrics|Text|RehearsalMark|PlayTechAnnotation|Fingering|Marker|Jump|InstrumentChange|MeasureNumber)\[\d+\]\/text\[1\]$/.test(node.location.path ?? '');
    const formatterSelfClosing = (node: Element, textBase: boolean, loader = nativeTextLoader): boolean => {
        if (!textBase || !loader) return node.selfClosing === true;
        // Legacy readXml expands every nested element to an opening/closing
        // pair. Current readXml uses DOM child presence, with comments retained
        // and whitespace-only PCDATA absent. NBSP is not XML whitespace.
        return loader === 'current' && !node.children.length && !node.hasComment && !node.cdata && /^[ \t\r\n]*$/.test(node.text);
    };
    // Before 4.4.3 a comment after an empty element made the reader run past
    // the caption, so 4.00-4.60 comments and CDATA stay unqualified.
    const uncertainTextCharacters = (node: Element, loader = nativeTextLoader): boolean => !!loader && (node.cdata === 'mixed'
        || loader !== 'current' && !!node.cdata || loader === 'paired' && !!node.hasComment
        || !!node.hasComment && (node.children.length > 0 || !/^[ \t\r\n]*$/.test(node.text)));
    // W3C SMuFL f9d12b22 codepoint facts, exercised with explicit native ScoreText.
    const scoreTextGlyphs: Readonly<Record<string, readonly [string, string]>> = { '\uE522': ['dynamicForte', 'f'], '\uE520': ['dynamicPiano', 'p'], '\uE551': ['lyricsElision', '‿'], '\uECA5': ['metNoteQuarterUp', '♩'] };
    const systemTextGlyphs: Readonly<Record<string, readonly [string, string]>> = {
        '\uE048': ['coda', '𝄌'], '\uE1D7': ['note8thUp', '𝅘𝅥𝅮'], '\uE1D9': ['note16thUp', '𝅘𝅥𝅯'],
        '\uE1DB': ['note32ndUp', '𝅘𝅥𝅰'], '\uE1E7': ['augmentationDot', '𝅭'], '\uECA7': ['metNote8thUp', '♪']
    };
    const hasOtherTextRole = (node: Element): boolean => ['sym', 'font', 'sup', 'sub'].includes(node.name)
        || /<(?:sym|font|sup|sub)(?:\s|>|\/)/.test(node.text) || node.children.some(hasOtherTextRole);
    const isOrdinaryCaption = (node: Element, value: string): boolean => !/[\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(value) && !hasOtherTextRole(node);
    const ordinaryTempoShape = (node: Element, root = true): boolean => {
        if (uncertainTextCharacters(node) || Object.keys(node.attrs).length || !root && !['b', 'i', 'u', 's', 'br'].includes(node.name)) return false;
        // MuseScore 3 TextBase has bold/italic/underline; strike arrived in 4.0.
        if (!capture.nativeVersion?.startsWith('4.') && (node.name === 's' || /<\/?s(?:\s|\/|>)/.test(node.text))) return false;
        if (!node.children.length && node.text.includes('<')) {
            const tokens = [...node.text.matchAll(/<[^>]*>/g)];
            // Initial plainText already checks inert grammar and balance. This
            // qualification adds no parser or guessed formatting attributes.
            if (!tokens.length || tokens.some(token => !/^<(?:\/(?:b|i|u|s)\s*|(?:b|i|u|s|br)\s*\/?)>$/.test(token[0]))) return false;
        }
        return node.children.every(child => ordinaryTempoShape(child, false));
    };
    const systemTextGlyphShape = (node: Element, root = true): boolean => {
        if (node.hasComment || node.cdata || node.text.includes('<')) return false;
        if (node.name === 'font') return !node.children.length && /^[ \t\r\n]*$/.test(node.text)
            && Object.keys(node.attrs).length > 0 && Object.keys(node.attrs).every(name => ['face', 'size'].includes(name));
        if (Object.keys(node.attrs).length || !root && !['b', 'i', 'u', 'br', ...(capture.nativeVersion?.startsWith('4.') ? ['s'] : [])].includes(node.name)) return false;
        return node.children.every(child => systemTextGlyphShape(child, false));
    };
    const plainText = (e: Element, encodedSource?: Element['location'], runs?: InlineRuns, emphasis = 0, textBase = textBaseProperty(e), loader = nativeTextLoader): string => {
        use(e);
        if (e.text.length > 65536) refuse('native-text-budget', 'Native musical text exceeds the bounded text profile.', e.location);
        const uncertainCharacters = textBase && uncertainTextCharacters(e, loader);
        if (uncertainCharacters) performanceGap('native-textbase-character-context', encodedSource ?? e.location, 'The exact mixed/comment-separated character syntax remains captured. Its whitespace-token interpretation is not reconstructed from merged text; prior bounded text is retained without certifying native spacing or a new ordinary style projection.');
        const formatterText = (value: string): string => textBase && loader && !uncertainCharacters && /^[ \t\r\n]*$/.test(value)
            && (loader !== 'legacy' || e.name !== 'text')
            && !(loader === 'current' && e.name !== 'text' && e.cdata === 'only') ? '' : value;
        if (runs && ['b', 'i', 'u', 's'].includes(e.name)) {
            if (Object.keys(e.attrs).length) refuse('native-caption-emphasis', 'Inline caption emphasis requires a verified attribute-free wrapper.', encodedSource ?? e.location);
            const selfClosing = formatterSelfClosing(e, textBase, loader);
            if (textBase && !loader && (!e.children.length && /^[ \t\r\n]*$/.test(e.text)))
                performanceGap('native-textbase-loader-context', encodedSource ?? e.location, 'The exact empty wrapper remains captured. This producer loader has no qualified formatter-input interpretation; prior bounded decoding is retained without certifying a native reset or no-op.');
            if (selfClosing) {
                if (e.selfClosing && (e.text || e.children.length)) refuse('native-caption-emphasis', 'A self-closing source emphasis token must be empty.', encodedSource ?? e.location);
                performanceGap('native-self-closing-emphasis', encodedSource ?? e.location, textBase && loader === 'current' && !e.selfClosing
                    ? 'The examined current TextBase loader has no retained DOM child for this empty wrapper and supplies a self-closing formatter token. It changes no displayed emphasis; the original paired syntax and whitespace remain captured.'
                    : textBase && !loader
                        ? 'The exact self-closing TextBase wrapper remains captured. Its producer loader interpretation is unqualified; prior bounded decoding is retained without asserting native displayed emphasis.'
                        : 'The native text formatter recognizes opening and explicit closing emphasis tokens. This self-closing token changes no displayed emphasis; its exact syntactic form remains captured.', textBase && !loader ? 'omitted' : 'inferred');
                return '';
            }
            if (textBase && loader && loader !== 'current' && e.selfClosing)
                performanceGap('native-textbase-formatter-input', encodedSource ?? e.location, 'This TextBase loader expands this literal self-closing wrapper to opening and closing formatter tokens. Its closing emphasis reset is derived from the located wrapper; original source bytes and syntax remain unchanged.', 'inferred');
            runs.emphasized = true;
            emphasis |= emphasisBits[e.name as keyof typeof emphasisBits];
        }
        if (runs && e.name === 'font') {
            // Both native readXml implementations retain attribute order. The
            // formatter recognizes only the first font property and keeps it
            // active after </font>; a second property does not override it.
            const first = Object.keys(e.attrs)[0], source = encodedSource ?? e.location;
            budget.add('markings', 1, source);
            if (first === 'face') runs.font = { source, face: e.attrs.face, origin: 'source-markup' };
            else if (first === 'size') {
                runs.limits.add('font-size');
                const rawValue = e.attrs.size, number = Number(rawValue);
                const value = /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(rawValue.trim()) && number > 0 && number <= 10000 ? number : undefined;
                runs.size = { source, rawValue, ...(value !== undefined ? { value } : {}), origin: 'source-markup' };
                if (value === undefined) runs.limits.add('font-size-invalid');
            } else runs.limits.add('font');
        }
        if (runs && ['sup', 'sub'].includes(e.name)) {
            runs.limits.add(e.name);
            if (Object.keys(e.attrs).length) runs.limits.add(`${e.name}-attributes`);
            else if (!formatterSelfClosing(e, textBase, loader)) runs.script = { source: encodedSource ?? e.location, value: e.name === 'sup' ? 'super' : 'sub', origin: 'source-markup' };
        }
        const appendRun = (value: string, symbolName?: string): string => {
            if (!runs || !value) return value;
            const reset = (runs.resets ?? []).reduce((mask, item) => mask | item.bit, 0), active = emphasis & ~reset;
            const append = (text: string, name?: string, literal?: string): void => {
                const previous = runs.values.at(-1);
                if (!name && !literal && !previous?.symbolName && !previous?.sourceText && previous?.emphasis === active && previous?.emphasisResets === runs.resets && previous?.sourceFont === runs.font && previous?.textFontSize === runs.size && previous?.script === runs.script) previous.text += text;
                else {
                    if (runs.values.length >= 4096) refuse('native-caption-runs-budget', 'Native caption exceeds the bounded inline-run profile.', encodedSource ?? e.location);
                    runs.values.push({ source: encodedSource ?? e.location, text, emphasis: active, origin: 'source-markup', ...(runs.resets?.length ? { emphasisResets: runs.resets } : {}), ...(name ? { symbolName: name } : {}), ...(runs.font ? { sourceFont: runs.font } : {}), ...(runs.size ? { textFontSize: runs.size } : {}), ...(runs.script ? { script: runs.script } : {}), ...(literal ? { sourceText: literal } : {}) });
                }
            };
            if (symbolName) { append(value, symbolName); return value; }
            if (!/[\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(value)) { append(value); return value; }
            // Independently audited SMuFL facts, not a font resolver. Other
            // contexts retain their literal codepoints and a located limit.
            let rendered = '', ordinary = '';
            for (const character of value) {
                const point = character.codePointAt(0)!;
                const privateUse = point >= 0xE000 && point <= 0xF8FF || point >= 0xF0000 && point <= 0xFFFFD || point >= 0x100000 && point <= 0x10FFFD;
                if (!privateUse) { ordinary += character; continue; }
                if (ordinary) { append(ordinary); rendered += ordinary; ordinary = ''; }
                const qualified = runs.nameGlyphs !== false && runs.font?.face === 'ScoreText' && !runs.font.qualification;
                // ECB7 naming is confined to the single dotted-quarter Tempo
                // candidate. It does not extend ordinary caption authority.
                const vocabulary = runs.systemTextGlyphs ? systemTextGlyphs : scoreTextGlyphs;
                const known = qualified ? Object.hasOwn(vocabulary, character) ? vocabulary[character]
                    : !runs.systemTextGlyphs && runs.tempoAugmentationDot && character === '\uECB7' ? ['metAugmentationDot', '·'] as const : undefined : undefined;
                if (known) { append(known[1], known[0], character); rendered += known[1]; }
                else {
                    append(character, undefined, character); rendered += character;
                    performanceGap('native-scoretext-unresolved-glyph', encodedSource ?? e.location, 'The exact private-use codepoint and encoded font context remain located. Only audited codepoints in explicit ScoreText context are named; no unknown or implicit font meaning is guessed.');
                }
            }
            if (ordinary) { append(ordinary); rendered += ordinary; }
            return rendered;
        };
        // Direct line STRING captions supply decoded formatter tokens. Qualified
        // TextBase readXml escapes character data instead of retokenizing it.
        if (!(textBase && loader) && !e.children.length && /<(?:sym|b|i|u|s|font|sup|sub|br)(?:\s|>|\/)/.test(e.text)) {
            const decodeFragment = (fragment: string): string => {
                const fragmentRuns: InlineRuns | undefined = runs ? { values: [], emphasized: false, limits: new Set(), resets: runs.resets, font: runs.font, size: runs.size, script: runs.script, nameGlyphs: runs.nameGlyphs, tempoAugmentationDot: runs.tempoAugmentationDot, systemTextGlyphs: runs.systemTextGlyphs } : undefined;
                const result = plainText(captureXml(new TextEncoder().encode(`<text>${fragment}</text>`), e.location.member), encodedSource ?? e.location, fragmentRuns, emphasis, textBase, loader);
                if (runs && fragmentRuns) {
                    for (const value of fragmentRuns.values) {
                        if (runs.values.length >= 4096) refuse('native-caption-runs-budget', 'Native caption exceeds the bounded inline-run profile.', encodedSource ?? e.location);
                        runs.values.push(value);
                    }
                    runs.emphasized ||= fragmentRuns.emphasized;
                    runs.resets = fragmentRuns.resets;
                    runs.font = fragmentRuns.font; runs.size = fragmentRuns.size; runs.script = fragmentRuns.script;
                    for (const limit of fragmentRuns.limits) runs.limits.add(limit);
                }
                return result;
            };
            try { return decodeFragment(e.text); }
            catch (error) {
                if (!(error instanceof Refusal)) throw error;
                // Repair only missing EOF closures of verified, attribute-free formatting.
                // Appending these leaves every original token intact; the strict inert XML
                // reader still rejects unknown tags/entities, crossed closes and open sym.
                const open: string[] = []; let crossed = false;
                for (const token of e.text.matchAll(/<[^>]*>/g)) {
                    const wrapper = /^<(\/?)(b|i|u|s|sup|sub)\s*>$/.exec(token[0]); if (!wrapper) continue;
                    if (wrapper[1]) { if (open.pop() !== wrapper[2]) { crossed = true; break; } }
                    else open.push(wrapper[2]);
                }
                if (!crossed && open.length && open.length <= 32) {
                    try {
                        const result = decodeFragment(`${e.text}${open.reverse().map(name => `</${name}>`).join('')}`);
                        performanceGap('native-text-formatting-repair', e.location, 'Missing trailing closures of verified formatting-only wrappers were appended in the inert decoding view. The exact authored text and source location remain retained; no musical token or words were removed.', 'inferred');
                        return result;
                    } catch (repairError) { if (!(repairError instanceof Refusal)) throw repairError; }
                }
                return refuse(error.code, error.message, e.location);
            }
        }
        // Native text is markup data, never executable input. Caption callers can
        // retain ordered emphasis without a second parser or a second text stream.
        if (e.name === 'sym') {
            const symbols: Record<string, string> = { metNoteQuarterUp: '♩', metNoteHalfUp: '𝅗𝅥', metNoteWhole: '𝅝', metNote8thUp: '♪',
                metAugmentationDot: '·', accidentalSharp: '♯', accidentalFlat: '♭', accidentalNatural: '♮', accidentalDoubleSharp: '𝄪', accidentalDoubleFlat: '𝄫',
                keyboardPedalPed: 'Ped.', keyboardPedalUp: '*', keyboardPedalSost: 'Sost.', keyboardPedalS: 'S',
                dynamicPiano: 'p', dynamicForte: 'f', dynamicMezzo: 'm', dynamicSforzando: 's', dynamicRinforzando: 'r', dynamicZ: 'z', dynamicNiente: 'n', lyricsElision: '‿',
                ottava: '8', ottavaAlta: '𝄶', space: ' ', segno: '𝄋', segnoSerpent1: '𝄋', coda: '𝄌' };
            const symbol = Object.hasOwn(symbols, e.text.trim()) ? symbols[e.text.trim()] : undefined;
            if (e.text.trim() === 'dynamicPForte' && !e.children.length && !Object.keys(e.attrs).length) {
                performanceGap('native-unresolved-inline-glyph', encodedSource ?? e.location, 'The exact legacy dynamicPForte token is preserved as literal words, as in the pinned own-app export. It is not a verified canonical glyph or inferred pf/fp dynamic; its intended glyph appearance remains unresolved.');
                appendRun('<sym>dynamicPForte</sym>');
                return '<sym>dynamicPForte</sym>';
            }
            if (!symbol || e.children.length) return refuse('native-text-symbol', `Uninterpreted musical text symbol ${e.text.trim()}.`, e.location);
            if (e.text.trim() === 'ottava' || e.text.trim() === 'ottavaAlta') performanceGap('native-inline-octave-glyph', encodedSource ?? e.location, 'The source octave-label glyph remains byte-exact and located. Standard words carry its verified text/Unicode meaning; native font and glyph styling are not reproduced. The relation subtype, rather than the glyph, controls octave playback.');
            appendRun(symbol, symbolVocabulary.has(e.text.trim()) || runs?.tempoAugmentationDot && e.text === 'metAugmentationDot'
                || runs?.nativeDynamicPairs && ['dynamicMezzo', 'dynamicSforzando'].includes(e.text) ? e.text.trim() : undefined);
            return symbol;
        }
        if (e.name === 'br') { if (e.text || e.children.length) refuse('native-text', 'Native line break must be empty.', e.location); appendRun('\n'); return '\n'; }
        let result = '', offset = 0;
        for (const insertion of e.textOrder ?? []) {
            const preceding = e.text.slice(offset, insertion.afterText); result += appendRun(formatterText(preceding)); offset = insertion.afterText;
            const c = e.children[insertion.child];
            if (['b', 'i', 'u', 's', 'font', 'sup', 'sub', 'sym', 'br'].includes(c.name)) {
                const bit = Object.hasOwn(emphasisBits, c.name) ? emphasisBits[c.name as keyof typeof emphasisBits] : undefined;
                const selfClosing = formatterSelfClosing(c, textBase, loader);
                if (runs && bit && !selfClosing) { const remaining = runs.resets?.filter(item => item.bit !== bit); runs.resets = remaining?.length ? remaining : undefined; }
                result += plainText(c, encodedSource, runs, emphasis, textBase, loader);
                if (runs && ['sup', 'sub'].includes(c.name) && !selfClosing) runs.script = { source: encodedSource ?? c.location, value: 'normal', origin: 'source-markup' };
                if (runs && bit && !selfClosing) runs.resets = [...(runs.resets ?? []).filter(item => item.bit !== bit), { source: encodedSource ?? c.location, bit }];
            }
            else refuse('native-text', `Unsupported text element ${c.name}.`, c.location);
            if (result.length > 65536) refuse('native-text-budget', 'Native musical text exceeds the bounded text profile.', e.location);
        }
        if (e.children.length && e.textOrder?.length !== e.children.length) refuse('native-text', 'Inline text order is unavailable.', e.location);
        const trailing = e.text.slice(offset);
        result += appendRun(formatterText(trailing));
        return result;
    };
    return {
        readTextEmphasis, ordinaryFamily, readTextFamily, qualifyTextFamilies, legacyInvalidHairpinCaption,
        nativeTextLoader, hasOtherTextRole, isOrdinaryCaption, ordinaryTempoShape, systemTextGlyphShape, plainText
    };
}

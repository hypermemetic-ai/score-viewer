import type { MusicalPart, Direction } from '../../core/model.js';
import { q } from '../../core/rational.js';
import type { Finding } from '../../core/report.js';

/** Resolve navigation identities independently of the displayed glyph/caption.
 * Native marker.h RIGHT_MARKERS and read400 label -> MarkerType authority.
 * Custom targets are never silently relabelled as segnos. */
export function recoverNativeNavigation(parts: MusicalPart[]): Finding[] {
    const findings: Finding[] = [];
    for (const part of parts) {
        const entries = part.measures.flatMap(measure => (measure.directions ?? []).filter(d => d.navigation).map(direction => ({measure, direction})));
        const markers = new Map<string, Direction[]>();
        const roles = new Map<Direction, string>();
        for (const {measure, direction: d} of entries) {
            const nav = d.navigation!; nav.standardSound = {};
            if (nav.kind !== 'marker') continue;
            const known = new Set(['segno', 'varsegno', 'codab', 'varcoda', 'codetta', 'fine', 'coda', 'codasym', 'dacoda', 'dadblcoda']);
            const role = nav.markerType?.value ?? (known.has(nav.label ?? '') ? nav.label! : nav.glyph?.startsWith('segno') ? 'segno' : nav.glyph === 'coda' ? 'codab' : 'user');
            roles.set(d, role);
            const right = ['fine', 'coda', 'codasym', 'dacoda', 'dadblcoda'].includes(role);
            d.position = right ? measure.duration : q(0); d.positionOrigin = right ? 'native-measure-end' : 'native-measure-start';
            if (nav.label) { const list = markers.get(nav.label) ?? []; list.push(d); markers.set(nav.label, list); }
            if (['segno', 'varsegno'].includes(role)) nav.standardSound.segno = nav.label ?? '1';
            else if (['codab', 'varcoda', 'codetta'].includes(role)) nav.standardSound.coda = nav.label ?? '1';
            else if (role === 'fine') nav.standardSound.fine = 'yes';
        }
        const ambiguousContinuations = new Set<Direction>();
        const target = (label: string | undefined) => { const matches = markers.get(label ?? '') ?? []; return matches.length === 1 ? matches[0] : undefined; };
        for (const {direction: d} of entries) {
            const nav = d.navigation!; if (nav.kind !== 'jump') continue;
            if (nav.jumpTo === 'start') nav.standardSound!.dacapo = 'yes';
            else {
                const to = target(nav.jumpTo), role = to && roles.get(to);
                if (role && ['segno', 'varsegno', 'codab', 'varcoda', 'codetta'].includes(role)) {
                    nav.targetKind = ['segno', 'varsegno'].includes(role) ? 'segno' : 'coda';
                    nav.standardSound![nav.targetKind === 'segno' ? 'dalsegno' : 'tocoda'] = nav.jumpTo!;
                } else findings.push({code:'native-navigation-playback-target',disposition:'excluded-by-scope',location:nav.source,message:'The exact performer caption and source navigation labels are preserved. An absent, ambiguous or user-defined target has no guessed segno/coda playback identity.'});
            }
            // A native D.S./D.C. al Coda specifies its outgoing coda point and
            // continuation destination on the Jump, not on the visible Marker.
            if (nav.continueAt) {
                const from = target(nav.playUntil), to = target(nav.continueAt), role = to && roles.get(to);
                if (from && role && ['codab', 'varcoda', 'codetta'].includes(role)) {
                    const sounds = from.navigation!.standardSound!;
                    if (ambiguousContinuations.has(from)) continue;
                    if (sounds.tocoda && sounds.tocoda !== nav.continueAt) {
                        delete sounds.tocoda; ambiguousContinuations.add(from);
                        findings.push({code:'native-navigation-playback-context',disposition:'excluded-by-scope',location:nav.source,message:'Multiple source jump contexts require different continuation targets at one mark. The performer instructions and all source targets remain; no single unconditional playback route is invented.'});
                    } else sounds.tocoda = nav.continueAt;
                }
            }
        }
    }
    return findings;
}

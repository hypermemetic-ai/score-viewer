import type { Event, MusicalEvent, NoteFact, Pitch, MusicalRelation } from '../../core/model.js';
import { q } from '../../core/rational.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import { harmonicInterval } from './techniques.js';

type Facts = Record<string, number>;
type Locate = (name: string) => Location;
/** Source decoding rules use physical base pitch; normalized harmonic defaults are never authority. */
export function binaryHarmonic(facts: Facts, note: NoteFact, version: number, open: number, infer: (midi: number) => Pitch, locate: Locate, findings: Finding[], beatFlags = 0, writtenShift = 12): void {
    const code = facts['harmonic-type'] ?? (version < 400 ? beatFlags & 4 ? 1 : beatFlags & 8 ? 2 : 0 : 0);
    if (!code) return;
    const kinds: Record<number, NonNullable<NoteFact['harmonic']>['type']> = { 1: 'natural', 2: 'artificial', 3: 'tap', 4: 'pinch', 5: 'semi', 15: 'artificial', 17: 'artificial', 22: 'artificial' };
    if (!kinds[code] || version >= 500 && code > 5 || version >= 400 && version < 500 && code === 2) refuse('harmonic-type', 'Unknown encoded binary harmonic subtype.', locate('harmonic-type'));
    const source = locate('harmonic-type'), physical = open + note.fret, kind = kinds[code];
    let result: number | undefined, touching: number | undefined, node: number | undefined;
    if (kind === 'natural') { node = note.fret; const interval = harmonicInterval(node); if (interval !== undefined) result = open + interval; touching = physical; }
    else if (version >= 500 && code === 2) {
        const tone = facts['harmonic-tone'], rawKey = facts['harmonic-key'], octave = facts['harmonic-octave'];
        if (![0,2,4,5,7,9,11].includes(tone) || ![255,0,1].includes(rawKey) || ![0,1,2].includes(octave)) refuse('harmonic-pitch', 'Invalid explicit artificial harmonic pitch tuple.', source);
        const pitchClass = tone + (rawKey === 255 ? -1 : rawKey), baseClass = physical % 12;
        let interval = pitchClass + octave * 12 - baseClass; if (interval < 0) interval += 12;
        result = physical + interval;
    } else if (version >= 500 && code === 3) {
        const tap = facts['harmonic-tap-fret'];
        if (tap < 0 || tap > 255) refuse('harmonic-fret', 'Tapped harmonic touch fret outside its encoded unsigned-byte range.', source);
        touching = open + tap; node = tap - note.fret;
        const interval = harmonicInterval(node); if (interval !== undefined) result = physical + interval;
    } else if (version >= 400 && version < 500 && [15,17].includes(code)) {
        node = code === 15 ? 5 : 7; touching = physical + node; result = physical + (code === 15 ? 24 : 19);
    } else if (version >= 400 && version < 500 && code === 3 || code === 22) {
        // GP4's explicit tapped convention is twelve frets above the left-hand fret.
        node = 12; touching = physical + 12; result = physical + 12;
    }
    note.harmonic = { source, type: kind, base: infer(kind === 'natural' ? open : physical),
        pitchRole: kind === 'natural' ? result === undefined ? 'touching' : 'sounding' : 'base',
        ...(touching !== undefined ? { touch: infer(touching) } : {}), ...(result !== undefined ? { result: infer(result) } : {}),
        ...(node !== undefined ? { harmonicFret: { source, value: q(node) } } : {}) };
    note.sounding = result === undefined ? null : infer(result);
    if (kind === 'natural' && result !== undefined) note.written = infer(result + writtenShift);
    findings.push({ disposition: result === undefined ? 'preserved' : 'inferred', code: 'binary-harmonic-roles',
        message: result === undefined ? 'Encoded harmonic technique and known base/touch roles are retained; this encoding supplies no independently established definite result. No default octave is invented.' : 'Known harmonic result derives from the explicit pitch tuple or established source node convention; physical fret remains separate.',
        location: source, fact: { code, type: kind, definiteResult: result !== undefined } });
}

export function binaryTrill(facts: Facts, note: NoteFact, open: number, infer: (midi: number) => Pitch, locate: Locate, writtenShift = 12): void {
    if (facts['trill-fret'] === undefined) return;
    const fret = facts['trill-fret'], speed = facts['trill-speed'];
    if (fret < 0 || fret > 255 || ![1,2,3].includes(speed)) refuse('trill', 'Unknown binary trill fret or period.', locate('trill-fret'));
    note.trill = { source: locate('trill-fret'), fret, target: infer(open + fret + writtenShift), speed: ['','16th','32nd','64th'][speed] };
}

export function binaryBeatTechniques(facts: Facts, event: MusicalEvent, version: number, locate: Locate): void {
    const flags = facts['beat-effect-flags'] ?? 0, second = facts['beat-effect-flags2'] ?? 0;
    // Reserved bits have no payload or qualified performer meaning in these
    // versions. The adapter retains their exact bytes separately.
    if (flags & 16) event.text = [event.text, 'fade in'].filter(Boolean).join(' — ');
    if (second & 1) event.text = [event.text, 'rasgueado'].filter(Boolean).join(' — ');
    const tap = facts['slap-pop'];
    if (tap !== undefined && ![0,1,2,3].includes(tap)) refuse('technique', 'Unknown tap/slap/pop value.', locate('slap-pop'));
    const vibrato = !!(flags & 2 || version < 400 && flags & 1);
    for (const note of event.notes) {
        if (tap) (note.gestures ??= []).push({ source: locate('slap-pop'), kind: (['tap','slap','pop'] as const)[tap - 1] });
        if (vibrato) (note.gestures ??= []).push({ source: locate('beat-effect-flags'), kind: 'vibrato' });
        const pick = facts['pick-stroke'];
        if (pick !== undefined && ![0,1,2].includes(pick)) refuse('pick-stroke', 'Unknown encoded pick stroke.', locate('pick-stroke'));
        if (pick) (note.technical ??= []).push({ source: locate('pick-stroke'), kind: pick === 1 ? 'up-bow' : 'down-bow' });
    }
    if (flags & 64) {
        const up = facts.strokeUp, down = facts.strokeDown;
        if (up < 0 || up > 6 || down < 0 || down > 6 || up && down) refuse('arpeggio', 'Contradictory encoded brush directions.', locate('strokeUp'));
        if (up || down) event.arpeggio = { source: locate(up ? 'strokeUp' : 'strokeDown'), direction: up ? 'up' : 'down', straight: true };
    }
    if (second & 4) {
        const count = facts['whammy-point-count'];
        if (!Number.isSafeInteger(count) || count < 1 || count > 60) refuse('bend-curve', 'Whammy marking needs a bounded encoded curve.', event.source);
        event.whammy = { source: locate('whammy-type'), withBar: { source: locate('whammy-type') }, points: Array.from({ length: count }, (_, i) => {
            const offset = facts[`whammy-offset:${i}`], amount = facts[`whammy-alter:${i}`], vibrato = facts[`whammy-vibrato:${i}`];
            if (offset < 0 || offset > 60 || !Number.isSafeInteger(amount) || ![0,1,2,3].includes(vibrato) || i && offset < facts[`whammy-offset:${i-1}`]) refuse('bend-curve', 'Malformed encoded whammy point.', locate(`whammy-offset:${i}`));
            return { source: locate(`whammy-offset:${i}`), offset: q(offset,60), semitones: q(amount,50), vibrato: { source: locate(`whammy-vibrato:${i}`), value: !!vibrato, ...(vibrato ? {speed: (['fast','average','slow'] as const)[vibrato-1]} : {}) } };
        }) };
    }
}

interface GraceOwner { fact: NoteFact; facts: Facts; locate: Locate }
/** Legacy -1 is a dead stroke without a fret, not an open-string pitch. */
export function binaryUnfrettedDeadGraces(owners:GraceOwner[],host:Event,findings:Finding[]):MusicalEvent[] {
    const groups=new Map<string,MusicalEvent>();
    for(const {fact:target,facts,locate} of owners) {
        const code=facts['grace-duration'],dynamic=facts['grace-dynamic'],transition=facts['grace-transition'];
        if(facts['grace-fret']!==-1||![1,2,3].includes(code)||dynamic<1||dynamic>8)refuse('grace','Invalid legacy dead grace.',locate('grace-fret'));
        if(transition!==0)refuse('grace-transition','A fretless dead grace cannot establish a definite pitch transition.',locate('grace-transition'));
        const source={...locate('grace-fret'),id:target.id+':grace'},key=`${code}:${dynamic}`;
        let event=groups.get(key);
        if(!event){event={source,id:host.id+':dead-grace:'+groups.size,start:host.start,duration:q(0),writtenDuration:q(4,2**(7-code)),type:({1:'64th',2:'32nd',3:'16th'} as Record<number,string>)[code],dots:0,notes:[],fullMeasureRest:false,grace:{source,before:true,slash:true,index:0,hostId:host.id},dynamic:['','PPP','PP','P','MP','MF','F','FF','FFF'][dynamic]};groups.set(key,event);}
        event.notes.push({source,id:source.id,string:target.string,kind:'dead',written:{...target.written,origin:'inferred'},sounding:null,sourceDead:{source,value:true},tieStart:false,tieStop:false});
        findings.push({disposition:'inferred',code:'binary-dead-grace-placement',message:'Legacy dead grace encodes a string and dead stroke but no fret or definite pitch. Its X head uses the host note staff position as qualified guidance; source string is retained without an invented fret.',location:source,fact:{sourceFret:-1,string:target.string,referenceHost:target.source}});
    }
    return [...groups.values()];
}
/** Per-note GP grace payloads share the host clock; byte order does not imply successive attacks. */
export function binaryGraces(owners: GraceOwner[], host: Event, version: number, open: (string:number)=>number, infer: (midi:number)=>Pitch, relations: MusicalRelation[], findings: Finding[], writtenShift = 12): Event[] {
    const groups=new Map<string,Event>();
    for(const {fact:target,facts,locate} of owners) {
        if(facts['grace-fret']===undefined)continue;
        const fret=facts['grace-fret'],code=facts['grace-duration'],flags=facts['grace-flags']??0,transition=facts['grace-transition'],dynamic=facts['grace-dynamic'];
        if(fret<0||fret>127)refuse('grace-fret','Dead grace without an encoded physical fret requires generic-note recovery.',locate('grace-fret'));
        if(![1,2,3].includes(code)||flags&~3||![0,1,2,3].includes(transition)||dynamic<1||dynamic>8)refuse('grace','Unknown binary grace parameter.',locate('grace-fret'));
        const before=version<500||!(flags&2),dead=!!(flags&1),source={...locate('grace-fret'),id:target.id+':grace'};
        const pitch=infer(open(target.string)+fret),note:NoteFact={source,id:source.id,string:target.string,fret,kind:dead?'dead':'pitched',written:infer(pitch.midi+writtenShift),sounding:dead?null:pitch,...(dead?{referenceSounding:pitch}:{}),tieStart:false,tieStop:false};
        const key=`${before}:${code}:${dynamic}`,index=groups.size;
        let event=groups.get(key);
        if(!event){event={source,id:host.id+':grace:'+index,start:host.start,duration:q(0),writtenDuration:q(4,2**(7-code)),type:({1:'64th',2:'32nd',3:'16th'} as Record<number,string>)[code],dots:0,notes:[],fullMeasureRest:false,grace:{source,before,slash:before,index:0,hostId:host.id},dynamic:['','PPP','PP','P','MP','MF','F','FF','FFF'][dynamic]};groups.set(key,event);}
        event.notes.push(note);
        const endpoint=(e:Event,n:NoteFact)=>({partId:host.source.trackId!,measure:host.source.measure!-1,position:host.start,staff:1,voiceId:String(host.source.voice),eventId:e.id,noteId:n.id,...(e.grace?{graceIndex:0}:{})});
        const start=endpoint(event,note),end=endpoint(host,target),id=note.id+':transition';
        if(transition&&dead)refuse('grace-transition','Definite pitch transition conflicts with dead grace.',source);
        if(transition===1){relations.push({source:locate('grace-transition'),id,kind:'glissando',form:'slide',formFact:{source:locate('grace-transition'),origin:'source'},label:{source:locate('grace-transition'),value:'',show:false,origin:'source'},slideTechnique:{source:locate('grace-transition'),kind:'legato'},start,end});const slurId=id+':legato';relations.push({source:locate('grace-transition'),id:slurId,kind:'slur',start,end});(note.slurs??=[]).push({type:'start',number:1,relationId:slurId});(target.slurs??=[]).push({type:'stop',number:1,relationId:slurId});}
        if(transition===2){note.bendTransition={source:locate('grace-transition'),semitones:q(target.fret-fret),targetSource:target.source,origin:'derived-source-pitches'};relations.push({source:locate('grace-transition'),id,kind:'slur',sourceTechnique:{source:locate('grace-transition'),kind:'bend-continuation'},start,end});(note.slurs??=[]).push({type:'start',number:1,relationId:id});(target.slurs??=[]).push({type:'stop',number:1,relationId:id});}
        if(transition===3){if(target.fret===fret)refuse('grace-transition','Hammer/pull grace needs changed source fret.',source);const kind=target.fret>fret?'hammer-on':'pull-off';note.hopoStart=kind;target.hopoStop=kind;note.hopoNumber=target.hopoNumber=target.string;}
    }
    const events=[...groups.values()];
    if(events.length>1){events.forEach((event,index)=>{event.voiceId=`${host.source.voice}:grace-projection:${index+1}`;});findings.push({disposition:'inferred',code:'grace-parallel-projection',message:'Different simultaneous per-note grace parameters use independent MusicXML serialization lanes at the same source host clock; these are not additional source performing voices.',location:host.source,fact:{groups:events.length}});}
    return events;
}

import type {MusicalEvent,MusicalPart,MusicalScore} from '../../core/model.js';
import {q} from '../../core/rational.js';
import type {Finding,Location} from '../../core/report.js';
import {binaryBeatTechniques} from './binary-performer.js';
export function emptyAnnotationAnchor(source:Location,text:string|null):MusicalEvent{return {source,id:source.path!,start:q(0),duration:q(0),type:'quarter',dots:0,notes:[],fullMeasureRest:false,...(text?{text}:{})};}
/** A silent placeholder has no note clock. It may still own an instruction at its source measure start. */
export function binaryEmptyAnnotations(part:MusicalPart,event:MusicalEvent,version:number,effects:{source:Location;facts:Record<string,number>}|undefined,locations:Map<string,Location>,findings:Finding[]):NonNullable<MusicalScore['metadata']>{
    const metadata:NonNullable<MusicalScore['metadata']>=[],words:{source:Location;text:string}[]=[];
    if(effects){
        const at=(name:string)=>locations.get(effects.source.path+'/'+name)??effects.source,facts=effects.facts;
        binaryBeatTechniques(facts,event,version,at);
        if(facts['beat-effect-flags']&(version<400?3:2))words.push({source:at('beat-effect-flags'),text:'vibrato'});
        if(facts['slap-pop'])words.push({source:at('slap-pop'),text:['','tap','slap','pop'][facts['slap-pop']]});
        if(facts['pick-stroke'])words.push({source:at('pick-stroke'),text:facts['pick-stroke']===1?'Upstroke':'Downstroke'});
        if(event.arpeggio)words.push({source:event.arpeggio.source,text:`Brush ${event.arpeggio.direction}`});
        if(event.whammy)words.push({source:event.whammy.source,text:'Whammy bar'});
        if(version<400&&facts['beat-effect-flags']&12)words.push({source:at('beat-effect-flags'),text:facts['beat-effect-flags']&4?'Natural harmonic':'Artificial harmonic'});
        metadata.push({source:effects.source,name:'source-empty-beat-effects:'+event.id,value:JSON.stringify(facts)});
    }
    if(event.text)words.unshift({source:event.source,text:event.text});
    for(const word of words)(part.measures[event.source.measure!-1].directions??=[]).push({...word,kind:'words',position:q(0),staff:1,voiceId:String(event.source.voice??1),positionOrigin:'native-measure-start'});
    if(words.length||effects)findings.push({disposition:'inferred',code:'binary-empty-voice-instruction-position',message:'Instructions on an entirely empty source voice retain their source measure start without manufacturing a rhythmic event, attack or additional performing voice. Exact beat-effect operands remain metadata.',location:event.source});
    return metadata;
}

import type { Direction, SourceColor, TextFontSize } from '../../core/model.js';
import type { SourceElement as Element } from '../../core/source-xml.js';
import { refuse } from '../../core/report.js';

export type NativeTextPresentation = Pick<Direction, 'textFontFamily' | 'textFontStyle' | 'textFontSize' | 'musicFontSize' | 'textEmphasis' | 'sourceColor' | 'textEnclosure' | 'textFrameAppearance' | 'textRuns' | 'textAlignment'>;
export interface NativeTextPresentationContext {
    nativeVersion?: string;
    use: (element: Element) => Element;
    addMarking: (element: Element) => void;
    gap: (element: Element, message: string) => void;
    defaultSizeDependency?: NonNullable<TextFontSize['pointSize']>['spatiumDependent'];
    projectFontSize?: (owner: Element, size: TextFontSize, dependency?: NonNullable<TextFontSize['pointSize']>['spatiumDependent']) => TextFontSize['pointSize'];
}
/** Explicit TextBase properties are source facts independently of caption meaning.
 * No absent native defaults, font availability, or private glyph meanings are inferred.
 */
export function readNativeTextPresentation(owner: Element, { use, addMarking, gap, nativeVersion, defaultSizeDependency, projectFontSize }: NativeTextPresentationContext): NativeTextPresentation {
    const result: NativeTextPresentation = {};
    const property = (...names: string[]): Element | undefined => {
        const fields = owner.children.filter(field => names.includes(field.name));
        if (!fields.length) return undefined;
        if (fields.some(field => field.children.length || Object.keys(field.attrs).length)
            || fields.some(field => field.text !== fields[0].text)) {
            gap(fields[0], 'Conflicting or structured source text properties remain captured; no effective scalar is guessed.'); return undefined;
        }
        for (const field of fields) { addMarking(field); use(field); }
        return fields.at(-1);
    };
    const alignment = property('align'), position = property('position');
    if (alignment) {
        const match = /^(left|center|right),(top|center|bottom|baseline)$/.exec(alignment.text);
        if (match) {
            const justify = match[1] as 'left' | 'center' | 'right';
            result.textAlignment = { source: alignment.location, justify, valign: match[2] === 'center' ? 'middle' : match[2] as 'top' | 'bottom' | 'baseline',
                ...(Number(nativeVersion) < 4.7 ? { halign: justify, halignOrigin: 'derived-legacy-align' as const } : {}) };
            if (owner.name === 'Dynamic' && owner.children.find(field => field.name === 'text')?.text.includes('\n')) gap(alignment, 'Source dynamic text justification is retained, but MusicXML dynamics has no multiline justification attribute.');
        } else gap(alignment, 'Unknown source text alignment remains captured without an invented standard value.');
    }
    if (position) {
        if (Number(nativeVersion) >= 4.7 && /^(left|center|right)$/.test(position.text)) {
            const fact = result.textAlignment ??= { source: position.location };
            fact.halign = position.text as 'left' | 'center' | 'right'; fact.halignOrigin = 'source-position'; fact.halignSource = position.location;
        } else gap(position, 'Horizontal text position requires the verified native 4.7 property vocabulary and a known alignment value.');
    }
    if (owner.name === 'Lyrics' && result.textAlignment && (result.textAlignment.valign && result.textAlignment.valign !== 'baseline'
        || result.textAlignment.halign && result.textAlignment.justify && result.textAlignment.halign !== result.textAlignment.justify))
        gap(alignment ?? position!, 'MusicXML lyric preserves justification but has no independent horizontal or vertical block-alignment attributes. These source anchors remain located facts; no coordinates or syllable repositioning are invented.');
    const family = property('family', 'fontFace');
    if (family) {
        if (family.text.length > 65536) refuse('native-text-family-budget', 'Authored text family exceeds the bounded text profile.', family.location);
        result.textFontFamily = { source: family.location, value: family.text, origin: 'source-property' };
    }
    const style = property('fontStyle');
    if (style) {
        if (/^\d+$/.test(style.text.trim()) && Number(style.text) <= (nativeVersion?.startsWith('4.') ? 15 : 7)) result.textFontStyle = { source: style.location, value: Number(style.text), origin: 'source' };
        else gap(style, 'An unknown text emphasis mask remains captured; known bits are not guessed from an unknown enumeration.');
    }
    for (const name of ['bold', 'italic', 'underline', 'strike'] as const) {
        const field = property(name); if (!field) continue;
        if (name === 'strike' && !nativeVersion?.startsWith('4.')) { gap(field, 'Strike formatting requires the native 4 text property vocabulary; the older or unknown source property is retained without asserting its meaning.'); continue; }
        // Source property loading is ordered: a later full mask replaces an
        // earlier individual flag, while a later flag overrides just its bit.
        if (style && result.textFontStyle && owner.children.indexOf(field) < owner.children.indexOf(style)) continue;
        if (/^[01]$/.test(field.text.trim())) (result.textEmphasis ??= {})[name] = { source: field.location, value: field.text.trim() === '1' };
        else gap(field, 'A nonboolean authored text flag remains captured without an invented effective value.');
    }
    const size = property('size', 'fontSize'), dependent = property('sizeIsSpatiumDependent');
    if (size) {
        const numeric = /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(size.text.trim()) ? Number(size.text) : undefined;
        const value = numeric !== undefined && Number.isFinite(numeric) && numeric > 0 && numeric <= 10000 ? numeric : undefined;
        const fact: TextFontSize = { source: size.location, rawValue: size.text, ...(value !== undefined ? { value } : {}), origin: 'source-property' };
        if (value !== undefined && dependent?.text.trim() === '0') fact.pointSize = { value, origin: 'source-context', context: 'musescore-explicit-unscaled-text', spatiumDependent: { source: dependent.location, value: false, origin: 'source-property' } };
        else {
            const dependency = dependent ? /^[01]$/.test(dependent.text.trim()) ? { source: dependent.location, value: dependent.text.trim() === '1', origin: 'source-property' as const } : undefined : defaultSizeDependency;
            fact.pointSize = projectFontSize?.(owner, fact, dependency);
            if (!fact.pointSize) { delete fact.pointSize; gap(size, 'The exact font-size request is retained. Scaled or absent unit authority does not establish a point-size value.'); }
        }
        result.textFontSize = fact;
    }
    const readColor = (name: string): SourceColor | undefined => {
    const colors = owner.children.filter(field => field.name === name);
    if (colors.length) {
        const decoded = colors.map(field => {
            const channels = ['r', 'g', 'b', 'a'] as const;
            if (field.children.length || field.text.trim() || Object.keys(field.attrs).some(name => !channels.includes(name as typeof channels[number])) || channels.some(name => {
                const value = field.attrs[name];
                return name === 'a' && value === undefined ? false : !/^\d+$/.test(value ?? '') || Number(value) > 255;
            }))
                refuse('native-text-color', 'Authored text color requires RGB byte channels and an optional alpha byte.', field.location);
            return channels.map(name => name === 'a' && field.attrs.a === undefined ? 255 : Number(field.attrs[name])) as SourceColor['rgba'];
        });
        if (decoded.some(value => value.some((channel, index) => channel !== decoded[0][index]))) refuse('native-text-color', 'Conflicting authored text colors have no unique owner value.', colors[0].location);
        for (const field of colors) { addMarking(field); use(field); }
        return { source: colors[0].location, rgba: decoded[0], ...(colors[0].attrs.a === undefined ? { alphaOrigin: 'native-default' as const } : {}), ...(colors.length > 1 ? { occurrences: colors.map(field => field.location) } : {}) };
    }
    return undefined;
    };
    const color = readColor('color'); if (color) result.sourceColor = color;
    const frame = property('frameType'), foregroundColor = readColor('frameFgColor'), backgroundColor = readColor('frameBgColor'), width = property('frameWidth');
    if (foregroundColor || backgroundColor || width) {
        result.textFrameAppearance = { source: owner.location, ...(foregroundColor ? { foregroundColor } : {}), ...(backgroundColor ? { backgroundColor } : {}) };
        if (width && /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(width.text.trim()) && Number.isFinite(Number(width.text))) result.textFrameAppearance.width = { source: width.location, value: Number(width.text) };
        if ((foregroundColor || backgroundColor) && frame?.text.trim() !== '0') gap(owner, 'Frame border and background colors are retained independently of text color. MusicXML text enclosure carries shape but has no separate border or background color attributes; these colors are not assigned to the caption.');
    }
    if (frame) {
        const supportedOwner = ['StaffText', 'SystemText', 'Expression', 'RehearsalMark', 'Dynamic', 'Text', 'Harmony', 'MeasureNumber', 'Fingering', 'PlayTechAnnotation'].includes(owner.name);
        if (/^[012]$/.test(frame.text.trim()) && supportedOwner
            && (frame.text.trim() === '0' || (result.textFrameAppearance?.width?.value !== 0 && foregroundColor?.rgba[3] !== 0))) {
            const nativeFrameType = Number(frame.text) as 0 | 1 | 2;
            result.textEnclosure = { source: frame.location, nativeFrameType, value: (['none', 'rectangle', 'circle'] as const)[nativeFrameType], origin: 'source-property' };
        } else gap(frame, 'Exact frame type remains captured. A shared frame across split caption components, suppressed outline or a carrier without enclosure requires a separate standard-capability decision; no per-run replacement box is invented.');
    }
    return result;
}

/** Add explicit facts while retaining stronger existing inline/unit authority. */
export function applyNativeTextPresentation(owner: Element, target: NativeTextPresentation, context: NativeTextPresentationContext): void {
    const facts = readNativeTextPresentation(owner, context);
    if (facts.textFontFamily && target.textFontFamily?.qualification) facts.textFontFamily.qualification = target.textFontFamily.qualification;
    if (facts.textFontFamily && !facts.textFontFamily.qualification && target.textRuns?.some(run => !run.symbolName && run.sourceFont
        && (run.sourceFont.role !== 'ordinary-family' || run.sourceFont.qualification))) {
        facts.textFontFamily.qualification = 'unrepresentable-inline-reset';
        context.gap(owner, 'The source family remains located, but an ordinary caption run enters an unresolved inline font context. Its base hint is withheld while later independently qualified inline families remain available.');
    }
    const caption = owner.children.find(field => field.name === 'text');
    const containsFont = (field: Element): boolean => field.name === 'font' || /<font\b/.test(field.text) || field.children.some(containsFont);
    if (facts.textFontFamily && !facts.textFontFamily.qualification && !target.textRuns && caption && containsFont(caption)) {
        facts.textFontFamily.qualification = 'unverified-inline-context';
        context.gap(caption, 'The source family remains located, but this caption has font changes without a qualified ordered run model. A uniform base-family hint is not applied across those unresolved changes.');
    }
    if (facts.textFontSize && !facts.textFontSize.pointSize && target.textFontSize?.pointSize
        && facts.textFontSize.source.path === target.textFontSize.source.path && facts.textFontSize.source.member === target.textFontSize.source.member) delete facts.textFontSize;
    if (facts.textFontStyle && !facts.textEmphasis) delete target.textEmphasis;
    Object.assign(target, facts);
    if (target.textEnclosure && target.textEnclosure.value !== 'none' && target.textRuns?.length) {
        const formats = new Set(target.textRuns.map(run => JSON.stringify([run.emphasis, run.emphasisResets?.map(r => r.bit), run.sourceFont?.face, run.textFontSize?.value, run.script?.value, !!run.symbolName])));
        if (formats.size > 1 || target.textRuns.some(run => run.symbolName) && target.textRuns.length > 1) {
            target.textEnclosure.inlineProjection = 'whole-caption-format-limit';
            context.gap(owner, 'MusicXML 4.0 does not define a portable shared enclosure across differently formatted words/symbol components (W3C MusicXML issue 519). One complete literal caption and one enclosure are projected; exact ordered run formatting remains in public source facts and standard auxiliary metadata.');
        }
    }
}

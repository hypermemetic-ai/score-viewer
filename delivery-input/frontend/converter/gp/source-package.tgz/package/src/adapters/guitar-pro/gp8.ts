import { freeze, refuse, type Finding } from '../../core/report.js';
import { child, children, integer, value, type Element } from './xml.js';
import { readGpifBeamFields } from './gpif-beams.js';
import { admittedFamily } from './admission.js';
import { createPitchedArticulations } from './pitched-articulations.js';
import { percussionCatalog } from './percussion.js';
import type { createGpHarmony } from './harmony.js';
import { createTrackAutomations } from './track-automations.js';
import { discoverArrangementGraph } from './arrangements.js';
import { masterFields, structuralBeatFields, scoreTextFields } from './structure.js';
import { beatTechniqueFields, beatTechniqueElements } from './techniques.js';

function rebuilt(e: Element, elements: Element[], text = e.text): Element { return { ...e, text, children: elements }; }
function leaf(e: Element, name: string, text: string, attrs: Record<string, string> = {}): Element { return { name, text, attrs, children: [], location: e.location }; }
function shape(e: Element, allowed: string[], attrs: string[] = [], repeated: string[] = []): void {
    if (allowed.length && e.text.trim()) refuse('mixed-content', 'Mixed structural content is unsupported.', e.location);
    for (const a of Object.keys(e.attrs)) if (!attrs.includes(a)) refuse('unknown-attribute', `Unreviewed ${e.name} attribute ${a}.`, e.location);
    const seen = new Set<string>();
    for (const c of e.children) {
        if (!allowed.includes(c.name)) refuse('unknown-element', `Unreviewed ${e.name}/${c.name} before reader projection.`, c.location);
        if (seen.has(c.name) && !repeated.includes(c.name)) refuse('structure', `Duplicate ${e.name}/${c.name}.`, c.location);
        seen.add(c.name);
    }
}
function scalar(e: Element): void { shape(e, []); }
function marker(e: Element): void { scalar(e); if (e.text.trim()) refuse('marker-content', 'Expected an empty marker.', e.location); }
const ids = (e: Element, name: string, required = true): string[] => {
    const field = child(e, name, required); if (!field) return []; scalar(field);
    return field.text.trim().split(/\s+/).filter(Boolean);
};
function named(e: Element, permitted: string[], findings: Finding[], keep: string[], translated: string[] = []): Element[] {
    shape(e, permitted, ['Track', 'Beat', 'Bar'].includes(e.name) ? ['id'] : []);
    const result: Element[] = [];
    for (const c of e.children) {
        if (!permitted.includes(c.name)) refuse('unknown-element', `Unreviewed ${e.name}/${c.name} in the selected GP8 scope.`, c.location);
        if (keep.includes(c.name)) result.push(c);
        else if (!translated.includes(c.name)) findings.push({ disposition: 'omitted', code: 'gp8-metadata', message: 'Preserved in original source; capture is delivered only on success; layout, view, synth/timbre or non-score metadata is not reapplied to ordinary staff output.', location: c.location });
    }
    return result;
}
function beamProperties(owner: Element, findings: Finding[]): Element[] {
    const fields = readGpifBeamFields(owner), container = child(owner, 'XProperties', false);
    if (!container) return [];
    shape(container, ['XProperty'], [], ['XProperty']);
    const kept: Element[] = [], seen = new Set<string>();
    for (const property of container.children) {
        if (seen.has(property.attrs.id)) refuse('structure', 'Duplicate source XProperty identifier.', property.location);
        seen.add(property.attrs.id);
        if (fields.consumed.has(property.attrs.id)) { kept.push(property); continue; }
        const playback = owner.name === 'Beat' && ['687931393','687935489'].includes(property.attrs.id) || owner.name === 'Note' && property.attrs.id === '688062467';
        const auxiliary = owner.name === 'Beat' && ['687931394','687935490'].includes(property.attrs.id) || owner.name === 'Bar' && property.attrs.id === '1124139521';
        if (playback || auxiliary) {
            const field = auxiliary ? owner.name === 'Bar' ? 'Double' : 'Float' : 'Int'; shape(property, [field], ['id']);
            if (property.children.length !== 1) refuse('source-xproperty', 'Source interpretation field requires one scalar.', property.location);
            scalar(property.children[0]); const text = value(property, field);
            if (playback) integer(text, 0, 1048576, property);
            else if (!/^-?\d{1,7}(?:\.\d{1,16})?$/.test(text)) refuse('source-xproperty', 'Invalid bounded source interpretation scalar.', property.location);
            findings.push({ disposition: playback ? 'omitted' : 'preserved', code: 'source-interpretation-field', message: playback ? 'Source arpeggio, brush or trill playback timing is retained as auxiliary data; the separately authored performer notation and written clocks remain unchanged.' : 'Unresolved observed source scalar is preserved exactly as standard auxiliary data without inventing a musical meaning.', location: property.location, fact: { id: property.attrs.id, field, value: text, role: playback ? 'playback-only' : 'unresolved-auxiliary' } });
            continue;
        }

        if (owner.name === 'Bar' && property.attrs.id === '1124139520') {
            shape(property, ['Double', 'Float'], ['id']);
            if (property.children.length !== 1) refuse('layout-scale', 'Display scale needs one source number.', property.location);
            scalar(property.children[0]); const text = property.children[0].text.trim();
            if (!/^\d{1,4}(?:\.\d{1,16})?$/.test(text) || Number(text) <= 0) refuse('layout-scale', 'Invalid source bar display scale.', property.location);
            findings.push({ disposition: 'omitted', code: 'bar-display-scale', message: 'Source bar display scale is exact native page geometry; musical beaming is preserved separately.', location: property.location, fact: text });
        } else refuse('unknown-property', 'Unreviewed source XProperty identifier.', property.location);
    }
    return kept.length ? [rebuilt(container, kept)] : [];
}
function checkDefaultArticulation(track: Element, findings: Finding[]): string {
    const set = child(track, 'InstrumentSet')!;
    shape(set, ['Name', 'Type', 'LineCount', 'Elements']);
    for (const c of set.children.filter(e => e.name !== 'Elements')) scalar(c);
    const type = value(set, 'Type');
    if (!/^[A-Za-z0-9_.-]{1,128}$/.test(type) || child(set, 'LineCount', false) && value(set, 'LineCount') !== '5')
        refuse('instrument-profile', 'The fretted source profile admits electricBass/electricGuitar on five ordinary staff lines only.', set.location);
    if (type === 'drumKit' || type === 'percussion') { percussionCatalog(track); return type; }
    createPitchedArticulations(track, findings);
    return type;
}

/** GP6 encodes the same physical staff facts directly on Track. */
function prepareDirectTrack(track: Element, findings: Finding[], harmony?: ReturnType<typeof createGpHarmony>): Element {
    const keep = named(track, ['Name', 'ShortName', 'Color', 'SystemsDefautLayout', 'SystemsLayout', 'PalmMute', 'PlayingStyle', 'Instrument', 'PartSounding', 'Transpose', 'RSE', 'GeneralMidi', 'PlaybackState', 'Lyrics', 'Properties', 'Automations'], findings, ['Name', 'ShortName', 'Instrument', 'Lyrics'], ['PartSounding', 'Transpose', 'GeneralMidi', 'Properties']);
    const midi = child(track, 'GeneralMidi')!;
    shape(midi, ['Program', 'Port', 'PrimaryChannel', 'SecondaryChannel', 'ForeOneChannelPerString'], ['table']); midi.children.forEach(scalar);
    const program = integer(value(midi, 'Program'), 0, 127, midi);
    if (!['Instrument', 'Percussion'].includes(midi.attrs.table)) refuse('instrument-profile', 'Selected GP6 staff requires an explicit guitar/bass MIDI program 24–39.', midi.location);
    const playing = child(track, 'PlayingStyle', false), palm = child(track, 'PalmMute', false), state = child(track, 'PlaybackState', false);
    if (playing && !['Default', 'StringedPick', 'StringedFinger', 'BassSlap'].includes(playing.text.trim()))
        refuse('track-technique', 'Active track-wide playing style, mute or nondefault playback state requires mapping.', track.location);
    if (playing && playing.text.trim() !== 'Default') findings.push({ disposition: 'omitted', code: 'source-playing-style', message: 'Source track playing style selects automatic engine interpretation; separately notated picking/slapping instructions remain musical facts. The engine preset is not invented as an instruction on every note.', location: playing.location, fact: playing.text.trim() });
    for (const name of ['Lyrics', 'Automations']) {
        const field = child(track, name, false);
        if (name === 'Automations' && field?.children.length) createTrackAutomations(track, findings);
        if (name === 'Lyrics' && field) {
            shape(field, ['Line'], ['dispatched'], ['Line']);
            for (const line of field.children) { shape(line, ['Text', 'Offset']); line.children.forEach(scalar); }
        }
    }
    const properties = child(track, 'Properties', false) ?? leaf(track, 'Properties', ''); shape(properties, ['Property'], [], ['Property']);
    const canonical: Element[] = [], names = new Set<string>();
    for (const p of properties.children) {
        if (names.has(p.attrs.name)) refuse('structure', 'Duplicate track property.', p.location); names.add(p.attrs.name);
        const name = p.attrs.name;
        if (name === 'Tuning') { shape(p, ['Pitches'], ['name']); scalar(child(p, 'Pitches')!); canonical.push(p); }
        else if (name === 'AutoBrush') { shape(p, ['Enable'], ['name']); marker(child(p, 'Enable')!); findings.push({ disposition: 'omitted', code: 'source-auto-brush', message: 'Encoded automatic playback strumming is retained without inventing written arpeggiation.', location: p.location }); }
        else if (name === 'CapoFret') { shape(p, ['Fret'], ['name']); scalar(child(p, 'Fret')!); canonical.push(p); }
        else if (['DiagramCollection', 'DiagramWorkingSet', 'ChordCollection', 'ChordWorkingSet'].includes(name)) {
            if (harmony) { harmony.validateProperty(p); continue; }
            shape(p, ['Items'], ['name']); marker(child(p, 'Items')!);
            findings.push({ disposition: 'omitted', code: 'empty-diagrams', message: 'Empty source diagram collection retained.', location: p.location });
        } else refuse('staff-property', 'Unreviewed GP6 staff property.', p.location);
    }
    const sourceTranspose = child(track, 'Transpose', false), sounding = child(track, 'PartSounding', false);
    if (sourceTranspose && sounding || !sourceTranspose && !sounding && midi.attrs.table !== 'Percussion') refuse('transpose', 'Exactly one explicit GP6 transposition representation is required.', track.location);
    let trans = sourceTranspose;
    if (sounding) {
        shape(sounding, ['NominalKey', 'TranspositionPitch']); sounding.children.forEach(scalar);
        const amount = integer(value(sounding, 'TranspositionPitch'), -24, 24, sounding);
        if (!/^[A-G](?:#|b)?$/.test(value(sounding, 'NominalKey')) && !(midi.attrs.table === 'Percussion' && value(sounding,'NominalKey') === 'Neutral' && amount === 0)) refuse('transpose', 'Invalid encoded nominal key.', sounding.location);
        trans = leaf(sounding, 'Transpose', ''); trans.children = [leaf(child(sounding, 'TranspositionPitch')!, 'Octave', String(Math.trunc(amount / 12))), leaf(sounding, 'Chromatic', String(amount % 12))];
        findings.push({ disposition: 'preserved', code: 'gp6-transpose-alias', message: 'Explicit PartSounding semitone octave is translated to the common octave representation without an additional physical sounding-pitch shift.', location: sounding.location, fact: { encodedSemitones: amount } });
    }
    return rebuilt(track, [...keep, ...(!child(track,'Instrument',false) ? [leaf(midi,'Instrument','',{ref:midi.attrs.table === 'Percussion' ? 'percussion' : `gm-program-${program}`})] : []), ...(trans ? [trans] : []), rebuilt(properties, canonical), rebuilt(midi, [child(midi, 'Program')!])]);
}

/** Common discovery/admission header; producer identity is never inferred from these labels. */
export function validateGpifHeader(root: Element, family: 6 | 7 | 8, findings: Finding[]): void {
    const version = value(root, 'GPVersion', false), revision = child(root, 'GPRevision')!, encoding = child(root, 'Encoding', false);
    if (family === 6 ? version && !/^6(?:\.\d{1,3}){0,2}$/.test(version) : !new RegExp(`^${family}(?:\\.\\d{1,3}){0,2}$`).test(version))
        refuse('version-profile', 'Embedded GPIF version conflicts with the identified GP family.', root.location);
    if (!/^\d{1,5}$/.test(revision.text.trim()) || Number(revision.text.trim()) < 1 || Number(revision.text.trim()) > 13007) refuse('version-profile', 'GPIF revision exceeds the reviewed reader revision ceiling13007 or is invalid.', revision.location);
    for (const name of Object.keys(revision.attrs)) {
        if (!['required', 'recommended'].includes(name)) refuse('version-profile', 'Unknown revision attribute.', revision.location);
        integer(revision.attrs[name], 0, 13007, revision);
    }
    if (encoding && value(encoding, 'EncodingDescription') !== `GP${family}`)
        refuse('version-profile', 'Encoding description conflicts with embedded version; a label alone never establishes pitch semantics.', encoding.location);
    findings.push({ disposition: 'preserved', code: 'gpif-family', message: 'Version/revision/container identifiers are retained separately from strict selected-feature admission and physical pitch corroboration. This does not authenticate a producing application.', location: root.location, fact: { family, version: version || null, revision: revision.text.trim(), encoding: encoding ? value(encoding, 'EncodingDescription') : null } });
}
/** Shared whole-arrangement graph validation; prepared views contain one selected physical staff. */
export const discoverGpifGraph = discoverArrangementGraph;

/** Select musical scope without mutating the full immutable source document.
 * The derived reader view translates reviewed structural aliases only.
 */
export function prepareGp8(root: Element, requested: string[] | undefined, findings: Finding[], family: 6 | 7 | 8 = 8, context?: { harmony?: ReturnType<typeof createGpHarmony> }): Element {
    validateGpifHeader(root, family, findings);
    const { tracks, bars, voices, beats, notes, rhythms, order, all, masterBars } = discoverGpifGraph(root);
    const masterTrack = child(root, 'MasterTrack')!;
    const selected = requested ?? order;
    if (!selected.length || new Set(selected).size !== selected.length || selected.some(id => !tracks.has(id)))
        refuse('track-selection', 'Select existing unique source track IDs.', masterTrack.location);
    // Stable source order, independent of caller argument order.
    const selectedOrder = order.filter(id => selected.includes(id));
    const trackIndexes = selectedOrder.map(id => order.indexOf(id));
    const kept = { bars: new Set<string>(), voices: new Set<string>(), beats: new Set<string>(), notes: new Set<string>(), rhythms: new Set<string>() };
    const masters = masterBars.children.map(master => {
        const barIds = ids(master, 'Bars');
        if (barIds.length !== order.length) refuse('bar-scope', 'Each master bar must identify every source track.', master.location);
        for (const id of barIds) { if (!bars.has(id)) refuse('reference', 'Unresolved master-bar reference, including excluded tracks.', master.location); all.bars.add(id); }
        const chosen = trackIndexes.map(i => barIds[i]); chosen.forEach(id => kept.bars.add(id));
        const keep = named(master, ['Time', 'Key', 'Bars', 'Repeat', 'XProperties', ...masterFields], findings, ['Time', 'Key', 'Repeat', ...masterFields], ['Bars', 'XProperties']);
        keep.push(...beamProperties(master, findings));
        const key = child(master, 'Key')!;
        const keyFields = named(key, ['AccidentalCount', 'Mode', 'TransposeAs'], findings, ['AccidentalCount', 'Mode'], ['TransposeAs']);
        const keyAlias = child(key, 'TransposeAs', false);
        if (keyAlias) scalar(keyAlias);
        if (keyAlias && !['Sharps', 'Flats'].includes(keyAlias.text.trim())) refuse('key-transpose', 'Unreviewed key spelling preference.', keyAlias.location);
        if (keyAlias) findings.push({ disposition: 'preserved', code: 'key-preference', message: 'Source key spelling preference is retained as auxiliary data. Concert key count/mode and the independently established written-pitch interval determine the standard written key.', location: keyAlias.location, fact: keyAlias.text.trim() });
        return rebuilt(master, [...keep.filter(e => e.name !== 'Key'), rebuilt(key, keyFields), leaf(child(master, 'Bars')!, 'Bars', chosen.join(' '))]);
    });
    const slotCount = Math.max(1, ...[...kept.bars].map(id => ids(bars.get(id)!, 'Voices').length));
    const preparedBars = [...kept.bars].map(id => {
        const bar = bars.get(id)!, all = ids(bar, 'Voices');
        if (!all.length || all.length > 4) refuse('voice-profile', 'A source bar requires one to four encoded voice slots.', bar.location);
        const active = all.filter(id => id !== '-1');
        if (new Set(active).size !== active.length) refuse('voice-profile', 'One voice definition cannot occupy multiple slots of the same bar.', bar.location);
        const slots = [...all, ...Array(slotCount - all.length).fill('-1')];
        active.forEach(id => kept.voices.add(id));
        if (active.length !== all.length) findings.push({ disposition: 'preserved', code: 'absent-voice-slots', message: 'Leading and internal absent slots preserve the original voice numbers. Trailing absent slots carry no music; a bounded empty-slot reader padding keeps voice chains stable across bars. An entirely absent staff remains silent for its master-bar span.', location: bar.location, fact: { slots: all } });
        const keep = named(bar, ['Clef', 'Ottavia', 'Voices', 'SimileMark', 'XProperties'], findings, ['Clef', 'Ottavia'], ['Voices', 'XProperties']);
        return rebuilt(bar, [...keep, ...beamProperties(bar, findings), leaf(child(bar, 'Voices')!, 'Voices', slots.join(' '))]);
    });
    for (const id of kept.voices) ids(voices.get(id)!, 'Beats').forEach(id => kept.beats.add(id));
    for (const id of kept.beats) {
        const b = beats.get(id)!; ids(b, 'Notes', false).forEach(id => kept.notes.add(id)); kept.rhythms.add(child(b, 'Rhythm')!.attrs.ref);
    }
    const preparedTracks = selectedOrder.map(id => {
        const track = tracks.get(id)!;
        if (family === 6) return prepareDirectTrack(track, findings, context?.harmony);
        const keep = named(track, ['Name', 'ShortName', 'Color', 'SystemsDefautLayout', 'SystemsLayout', 'AutoBrush', 'AutoAccentuation', 'PalmMute', 'PlayingStyle', 'UseOneChannelPerString', 'IconId', 'InstrumentSet', 'NotationPatch', 'Transpose', 'RSE', 'ForcedSound', 'Sounds', 'MidiConnection', 'PlaybackState', 'AudioEngineState', 'Lyrics', 'Staves', 'Automations'], findings, ['Name', 'ShortName', 'Transpose', 'Lyrics'], ['InstrumentSet', 'NotationPatch', 'Sounds', 'Staves', 'AutoBrush', 'AutoAccentuation', 'PalmMute']);
        const type = checkDefaultArticulation(track, findings);
        const playing = child(track, 'PlayingStyle', false), palm = child(track, 'PalmMute', false), state = child(track, 'PlaybackState', false);
        if (playing && !['Default', 'StringedPick', 'StringedFinger', 'BassSlap'].includes(playing.text.trim())) refuse('track-technique', 'Active track-wide style or playback state requires mapping.', track.location);
        for (const parameter of [palm, child(track, 'AutoAccentuation', false)].filter((p): p is Element => !!p)) {
            scalar(parameter);
            if (!/^(?:0(?:\.\d{1,6})?|1(?:\.0{1,6})?)$/.test(parameter.text.trim())) refuse('track-playback', 'Playback interpretation parameter must be a bounded decimal0–1.', parameter.location);
            findings.push({ disposition: 'omitted', code: 'track-playback-interpretation', message: parameter.name === 'PalmMute' ? 'Source playback palm-mute intensity is retained separately from recovered per-note palm-mute instructions; this parameter alone does not mark notes or performing hands.' : 'Source automatic strong-beat accentuation is retained but playback emphasis is not reproduced or invented as written accents/dynamics. No complete playback equivalence is claimed.', location: { ...parameter.location, trackId: id }, fact: { parameter: parameter.name, value: parameter.text.trim() } });
        }
        const autoBrush = child(track, 'AutoBrush', false);
        if (autoBrush) {
            marker(autoBrush);
            findings.push({ disposition: 'omitted', code: 'source-auto-brush', message: 'Source automatic playback strum delay is retained but not reproduced. Written attacks and clocks stay unchanged; this playback-only setting does not block performer conversion.', location: { ...autoBrush.location, trackId: id }, fact: { enabled: true } });
        }
        if (playing && playing.text.trim() !== 'Default') findings.push({ disposition: 'omitted', code: 'source-playing-style', message: 'Source track playing style selects automatic engine interpretation; separately notated picking/slapping instructions remain musical facts. The engine preset is not invented as an instruction on every note.', location: playing.location, fact: playing.text.trim() });
        findings.push({ disposition: 'omitted', code: 'instrument-sound-metadata', message: 'Instrument/sound catalog and bank/timbre metadata remain source facts. Selected articulation appearance and score-visible sound-change labels are recovered separately; engine settings alone do not assert a performer technique.', location: track.location });
        const automation = child(track, 'Automations', false);
        const lyrics = child(track, 'Lyrics', false);
        if (lyrics) {
            shape(lyrics, ['Line'], ['dispatched'], ['Line']);
            if (lyrics.attrs.dispatched !== undefined && !['true','false'].includes(lyrics.attrs.dispatched)) refuse('lyrics', 'Unreviewed lyric dispatch convention.', lyrics.location);
            for (const line of lyrics.children) {
                shape(line, ['Text', 'Offset']); line.children.forEach(scalar);
            }
        }
        const staveContainer = child(track, 'Staves')!; shape(staveContainer, ['Staff'], [], ['Staff']);
        const staves = staveContainer.children;
        if (staves.length !== 1) refuse('staff-profile', 'One explicitly fretted staff per selected bass track is required.', track.location);
        shape(staves[0], ['Properties']);
        const properties = child(staves[0], 'Properties')!, canonical: Element[] = [];
        shape(properties, ['Property', 'Name'], [], ['Property']); const propertyNames = new Set<string>();
        for (const property of properties.children) {
            if (property.name === 'Name') { scalar(property); findings.push({ disposition: 'omitted', code: 'staff-name', message: 'Source display name retained; ordinary source staff clef is exported.', location: property.location }); continue; }
            if (property.name !== 'Property') refuse('unknown-property', 'Unknown staff property container.', property.location);
            const name = property.attrs.name;
            if (propertyNames.has(name)) refuse('structure', 'Duplicate staff property identity.', property.location); propertyNames.add(name);
            if (context?.harmony && ['DiagramCollection','DiagramWorkingSet','ChordCollection','ChordWorkingSet'].includes(name)) { context.harmony.validateProperty(property); continue; }
            const fields: Record<string, string[]> = { Tuning: ['Pitches', 'Flat', 'Instrument', 'Label', 'LabelVisible'], TuningFlat: ['Enable'], CapoFret: ['Fret'], PartialCapoFret: ['Fret'], PartialCapoStringFlags: ['Bitset', 'Flags'], FretCount: ['Number'], ChordCollection: ['Items'], ChordWorkingSet: ['Items'], DiagramCollection: ['Items'], DiagramWorkingSet: ['Items'] };
            shape(property, fields[name] ?? [], ['name']); property.children.forEach(scalar);
            if (name === 'Tuning') {
                if (property.children.some(e => !['Pitches', 'Flat', 'Instrument', 'Label', 'LabelVisible'].includes(e.name))) refuse('tuning-property', 'Unreviewed tuning field.', property.location);
                if (child(property, 'Flat', false)) {
                    marker(child(property, 'Flat')!);
                    findings.push({ disposition: 'omitted', code: 'tuning-flat-preference', message: 'Encoded tuning flat-spelling preference is retained separately from MIDI values. Generated MusicXML reference tuning spelling remains explicitly inferred.', location: child(property, 'Flat')!.location });
                }
                const visible = child(property, 'LabelVisible', false);
                if (visible && !['true', 'false'].includes(visible.text.trim())) refuse('tuning-property', 'Tuning label visibility must be explicit boolean.', visible.location);
                canonical.push(rebuilt(property, [child(property, 'Pitches')!]));
            } else if (name === 'TuningFlat') {
                marker(child(property, 'Enable')!);
                findings.push({ disposition: 'omitted', code: 'tuning-flat-preference', message: 'Encoded enabled tuning flat-spelling preference is retained separately from MIDI values. Generated MusicXML reference tuning spelling remains explicitly inferred.', location: property.location });
            } else if (name === 'CapoFret') canonical.push(property);
            else if (name === 'PartialCapoFret' || name === 'PartialCapoStringFlags') { canonical.push(property);
            } else if (name === 'FretCount') integer(value(property, 'Number'), 1, 999999, property);
            else if (['ChordCollection', 'ChordWorkingSet', 'DiagramCollection', 'DiagramWorkingSet'].includes(name) && !child(property, 'Items')!.children.length) {
                findings.push({ disposition: 'omitted', code: 'empty-diagrams', message: 'Empty diagram container retained; no musical chord data dropped.', location: property.location });
            } else refuse('staff-property', `Staff property ${name} is unsupported or active.`, property.location);
        }
        const sound = createTrackAutomations(track, findings).firstSound!;
        const midi = child(sound, 'MIDI')!, program = child(midi, 'Program')!;
        admittedFamily(type, integer(program.text.trim(), 0, 127, program), program.location);
        return rebuilt(track, [...keep, leaf(child(track, 'InstrumentSet')!, 'Instrument', '', { ref: type }),
            rebuilt(properties, canonical), { ...midi, name: 'GeneralMidi', attrs: { table: type === 'drumKit' || type === 'percussion' ? 'Percussion' : 'Instrument' }, children: [program] }]);
    });
    for (const id of order.filter(id => !selected.includes(id))) findings.push({ disposition: 'excluded-by-scope', code: 'track-excluded', message: 'Track deliberately excluded by the requested source IDs; its facts remain in original source; capture is delivered only on success.', location: { ...tracks.get(id)!.location, trackId: id }, fact: { trackId: id } });
    const preparedBeats = [...kept.beats].map(id => {
        const b = beats.get(id)!;
        const keep = named(b, ['Rhythm', 'Notes', 'Dynamic', 'FreeText', 'Chord', 'Bank', 'Properties', 'XProperties', 'TransposedPitchStemOrientation', 'UserTransposedPitchStemOrientation', 'ConcertPitchStemOrientation', ...beatTechniqueElements, ...structuralBeatFields], findings, ['Rhythm', 'Notes', 'Dynamic', 'FreeText', 'TransposedPitchStemOrientation', 'UserTransposedPitchStemOrientation', ...beatTechniqueElements, ...structuralBeatFields], ['Properties', 'Chord', 'XProperties']);
        keep.push(...beamProperties(b, findings));
        const bank = child(b, 'Bank', false); if (bank) scalar(bank);
        const properties = child(b, 'Properties', false); if (properties) shape(properties, ['Property'], [], ['Property']); const names = new Set<string>();
        const musical: Element[] = [];
        for (const p of properties?.children ?? []) {
            if (names.has(p.attrs.name)) refuse('structure', 'Duplicate beat property.', p.location); names.add(p.attrs.name);
            if (beatTechniqueFields[p.attrs.name]) { shape(p, beatTechniqueFields[p.attrs.name].split(' '), ['name']); p.children.forEach(scalar); musical.push(p); continue; }
            shape(p, ['Float'], ['name']); scalar(child(p, 'Float')!);
            if (p.name !== 'Property' || !['PrimaryPickupVolume', 'PrimaryPickupTone'].includes(p.attrs.name)) refuse('beat-property', 'Unreviewed selected beat sound property.', p.location);
            const amount = value(p, 'Float');
            if (!/^\d{1,2}(?:\.\d{1,16})?$/.test(amount) || Number(amount) > 10) refuse('pickup-tone', 'Invalid bounded synth pickup control.', p.location);
            findings.push({ disposition: 'omitted', code: 'pickup-tone', message: 'Synth pickup tone/volume observed in source; capture is delivered only on success; instrument timbre recreation is not exercised.', location: p.location });
        }
        if (musical.length) keep.push(rebuilt(properties!, musical));
        return rebuilt(b, keep);
    });
    const score = child(root, 'Score')!;
    const preparedScore = rebuilt(score, named(score, ['Title', 'SubTitle', 'Artist', 'Album', 'Words', 'Music', 'WordsAndMusic', 'Copyright', 'Tabber', 'Instructions', 'Notices', 'FirstPageHeader', 'FirstPageFooter', 'PageHeader', 'PageFooter', 'ScoreSystemsDefaultLayout', 'ScoreSystemsLayout', 'ScoreZoomPolicy', 'ScoreZoom', 'MultiVoice', 'PageSetup'], findings, scoreTextFields));
    const preparedMaster = rebuilt(masterTrack, named(masterTrack, ['Tracks', 'Automations', 'Anacrusis', 'RSE'], findings, ['Automations', 'Anacrusis'], ['Tracks']).concat(leaf(child(masterTrack, 'Tracks')!, 'Tracks', selectedOrder.join(' '))));
    const audio = child(root, 'AudioTracks', false); if (audio && (audio.children.length || audio.text.trim())) refuse('audio-track', 'Audio tracks require a separate timing/media contract.', audio.location);
    const keep = named(root, ['GPVersion', 'GPRevision', 'Encoding', 'Score', 'MasterTrack', 'Tracks', 'MasterBars', 'Bars', 'Voices', 'Beats', 'Notes', 'Rhythms', 'ScoreViews', 'AudioTracks'], findings, ['GPVersion', 'GPRevision', 'Encoding'], ['Score', 'MasterTrack', 'Tracks', 'MasterBars', 'Bars', 'Voices', 'Beats', 'Notes', 'Rhythms']);
    const group = (name: string, elements: Element[]) => rebuilt(child(root, name)!, elements);
    return freeze(rebuilt(root, [...keep, preparedScore, preparedMaster, group('Tracks', preparedTracks), group('MasterBars', masters),
        group('Bars', preparedBars), group('Voices', [...kept.voices].map(id => voices.get(id)!)), group('Beats', preparedBeats),
        group('Notes', [...kept.notes].map(id => { const note = notes.get(id)!; const fields = beamProperties(note, findings); return rebuilt(note, [...note.children.filter(c => c.name !== 'XProperties'), ...fields]); })), group('Rhythms', [...kept.rhythms].map(id => rhythms.get(id)!))]));
}
export function serialize(e: Element): string {
    const escape = (s: string) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
    return `<${e.name}${Object.entries(e.attrs).map(([k, v]) => ` ${k}="${escape(v)}"`).join('')}>${escape(e.text)}${e.children.map(serialize).join('')}</${e.name}>`;
}

import type { MusicalEvent, MusicalMeasure, MusicalPart } from '../../core/model.js';
import { add, compare, equal, q, type Rational } from '../../core/rational.js';
import { refuse, type Finding, type Location } from '../../core/report.js';

/** Source boundary before the event, independent of either GP serialization convention. */
export interface GpBeamControl {
    source: Location; primary?: 'join' | 'split'; secondaryBreak?: number;
    stem?: 'up' | 'down'; invert?: boolean;
    primarySource?: Location; secondarySource?: Location; stemSource?: Location; invertSource?: Location;
}
export interface GpBeamGrouping { source: Location; unit: number; groups: number[] }
export interface GpBeamSource {
    groups?: Map<number, GpBeamGrouping>; controls: Map<MusicalEvent, GpBeamControl>;
}
const levels: Record<string, number> = { eighth: 1, '16th': 2, '32nd': 3, '64th': 4, '128th': 5, '256th': 6, '512th': 7, '1024th': 8 };
const depth = (event: MusicalEvent): number => levels[event.type] ?? 0;

function groupAt(position: Rational, rule: GpBeamGrouping): number {
    let end = q(0);
    for (let index = 0; index < rule.groups.length; index++) {
        end = add(end, q(4 * rule.groups[index], rule.unit));
        if (compare(position, end) < 0) return index;
    }
    // An incomplete authored list does not extend the last group indefinitely.
    const remainder = add(position, q(-end.n, end.d));
    return rule.groups.length + Math.floor(remainder.n * rule.unit / (remainder.d * 4));
}
function defaultGrouping(measure: MusicalMeasure): GpBeamGrouping {
    const { beats, unit } = measure.time;
    if (unit >= 8) {
        const groups = beats % 3 === 0 ? Array.from({ length: beats / 3 }, () => 3)
            : beats === 5 ? [3, 2] : beats === 7 ? [4, 3] : beats === 8 ? [3, 3, 2]
                : Array.from({ length: Math.ceil(beats / 2) }, (_, index) => Math.min(2, beats - 2 * index));
        return { source: measure.source, unit, groups };
    }
    return { source: measure.source, unit, groups: Array.from({ length: beats }, () => 1) };
}
function validateGrouping(group: GpBeamGrouping): void {
    if (!Number.isSafeInteger(group.unit) || group.unit < 1 || group.unit > 1024 || (group.unit & (group.unit - 1)) || !group.groups.length || group.groups.length > 32
        || group.groups.some(value => !Number.isSafeInteger(value) || value < 0 || value > 255))
        refuse('gp-beam-groups', 'Beam grouping requires a power-of-two unit and at most 32 bounded source counts.', group.source);
    // GP pads the fixed binary tuple with zeroes. Interior zeroes do not establish a span.
    while (group.groups.at(-1) === 0) group.groups.pop();
    if (!group.groups.length) refuse('gp-beam-groups', 'An all-zero source tuple does not establish an authored beam-group span.', group.source);
    if (group.groups.some(value => value === 0)) refuse('gp-beam-groups', 'An interior zero does not establish a source beam-group span.', group.source);
}
function tupletOwners(events: MusicalEvent[]): Map<MusicalEvent, number> {
    const result = new Map<MusicalEvent, number>();
    let owner = 0, signature = '', elapsed = q(0), expected = q(0);
    for (const event of events) {
        if (!event.tuplet) { signature = ''; continue; }
        const key = `${event.tuplet.actual}:${event.tuplet.normal}`;
        if (signature !== key || compare(elapsed, expected) >= 0) {
            signature = key; owner++; elapsed = q(0);
            // The first written value defines the encoded GP tuplet's count unit.
            expected = q(4 * event.tuplet.normal, 4 * 2 ** depth(event));
        }
        result.set(event, owner); elapsed = add(elapsed, event.duration);
    }
    return result;
}
function automaticDirection(events: MusicalEvent[], measure: MusicalMeasure, voice: number): 'up' | 'down' | undefined {
    if (voice > 0) return 'down';
    if (measure.voices.some((events, index) => index > 0 && events.some(event => event.notes.length))) return 'up';
    if (events[0].grace) return 'up';
    const clef = measure.clef.replace(/(?:8v[ab]|15m[ab])$/, '');
    let middle = ({ G: 4 * 7 + 6, G2: 4 * 7 + 6, F: 3 * 7 + 1, F4: 3 * 7 + 1, C1: 4 * 7 + 4, C2: 4 * 7 + 2, C3: 4 * 7, C4: 3 * 7 + 5, C5: 3 * 7 + 3, PERC: 4 * 7 + 6 } as Record<string, number>)[clef];
    if (middle === undefined) return undefined;
    if (/8va$/.test(measure.clef)) middle += 7;
    if (/8vb$/.test(measure.clef)) middle -= 7;
    if (/15ma$/.test(measure.clef)) middle += 14;
    if (/15mb$/.test(measure.clef)) middle -= 14;
    if (events.some(event => event.notes.some(note => note.kind === 'unpitched' && note.unpitched.displayStep === undefined))) return undefined;
    const positions = events.flatMap(event => event.notes.map(note => {
        const step = note.kind === 'unpitched' ? note.unpitched.displayStep : note.written.step;
        const octave = note.kind === 'unpitched' ? note.unpitched.displayOctave : note.written.octave;
        return octave! * 7 + 'CDEFGAB'.indexOf(step!);
    }));
    if (!positions.length) return undefined;
    const low = positions.reduce((a, b) => Math.min(a, b)), high = positions.reduce((a, b) => Math.max(a, b));
    return low + high < middle * 2 ? 'up' : 'down';
}

/** Project source groups and boundary edits; ordinary unedited beaming stays renderer-owned. */
export function applyGpBeams(part: MusicalPart, source: GpBeamSource, findings: Finding[]): void {
    for (const [measureIndex, measure] of part.measures.entries()) {
        const supplied = source.groups?.get(measureIndex);
        const rule = supplied ? { ...supplied, groups: [...supplied.groups] } : defaultGrouping(measure);
        validateGrouping(rule);
        for (const [voiceIndex, voice] of measure.voices.entries()) {
            const touched = supplied || voice.some(event => source.controls.has(event));
            if (!touched) continue;
            const buckets = new Map<string, MusicalEvent[]>();
            for (const event of voice) {
                const key = event.grace ? `grace:${event.grace.hostId}:${event.grace.before}` : 'ordinary';
                const bucket = buckets.get(key) ?? []; bucket.push(event); buckets.set(key, bucket);
                const control = source.controls.get(event);
                if (control?.secondaryBreak !== undefined && (!Number.isSafeInteger(control.secondaryBreak) || control.secondaryBreak < 0 || control.secondaryBreak > 8))
                    refuse('gp-beam-control', 'A secondary beam cut must identify a bounded number of levels.', control.source);
                if (control?.stem) {
                    event.sourceStem = { source: control.stemSource ?? control.source, value: control.stem };
                    event.stem = control.stem; event.stemOrigin = { source: control.stemSource ?? control.source, origin: 'source-chord' };
                }
                if (control && (control.primary || control.secondaryBreak)) event.beam = { source: control.source,
                    mode: control.primary === 'split' ? 'begin' : control.primary === 'join' ? 'mid' : control.secondaryBreak ? 'begin16' : 'auto' };
                if (control) findings.push({ disposition: 'preserved', code: 'gp-source-beam-control', message: 'Source boundary and stem controls retained separately from calculated standard beam endpoints.', location: control.source, fact: control });
            }
            for (const events of buckets.values()) {
                events.sort((a, b) => compare(a.start, b.start) || (a.grace?.index ?? 0) - (b.grace?.index ?? 0));
                const tuplets = tupletOwners(events);
                let group: MusicalEvent[] = [];
                const finish = () => {
                    if (!group.length) return;
                    // A rest can lie inside a source beam; a leading/trailing rest is not a stem endpoint.
                    while (group.length && !group[0].notes.length) group.shift();
                    while (group.length && !group.at(-1)!.notes.length) group.pop();
                    if (!group.length) return;
                    const authored = group.find(event => source.controls.get(event)?.stem);
                    const inversion = group.find(event => source.controls.get(event)?.invert);
                    let direction = authored ? source.controls.get(authored)!.stem : undefined;
                    const owner = authored ?? inversion;
                    if (!direction && inversion) {
                        const baseline = automaticDirection(group, measure, voiceIndex);
                        if (!baseline) refuse('gp-beam-direction', 'Relative stem inversion requires a qualified source clef and note placement.', source.controls.get(inversion)!.source);
                        direction = baseline === 'up' ? 'down' : 'up';
                        findings.push({ disposition: 'inferred', code: 'gp-relative-stem-direction', message: 'Absolute stem direction derives from the encoded inversion and source clef, voice, and written staff positions.', location: source.controls.get(inversion)!.invertSource ?? source.controls.get(inversion)!.source, fact: { baseline, direction } });
                    }
                    if (direction && owner) for (const event of group) if (event.notes.length) {
                        event.stem = direction;
                        const control = source.controls.get(owner)!;
                        event.stemOrigin = { source: (authored ? control.stemSource : control.invertSource) ?? control.source, origin: authored === event ? 'source-chord' : 'derived-source-beam' };
                    }
                    if (group.length > 1) for (let level = 1; level <= group.reduce((maximum, event) => Math.max(maximum, depth(event)), 0); level++) {
                        const eligible = group.map(event => depth(event) >= level);
                        const joins = group.map((event, index) => {
                            if (!index || !eligible[index] || !eligible[index - 1]) return false;
                            const count = source.controls.get(event)?.secondaryBreak ?? 0;
                            const shared = Math.min(depth(group[index - 1]), depth(event));
                            return level === 1 || !count || level <= Math.max(1, shared - count);
                        });
                        for (const [index, event] of group.entries()) if (eligible[index]) {
                            const left = joins[index], right = joins[index + 1] ?? false;
                            const value = left ? right ? 'continue' : 'end' : right ? 'begin' : index === group.length - 1 ? 'backward hook' : 'forward hook';
                            (event.beams ??= []).push({ number: level, value });
                        }
                    }
                    group = [];
                };
                for (const event of events) {
                    const previous = group.at(-1), control = source.controls.get(event);
                    if (!depth(event)) { finish(); group = [event]; finish(); continue; }
                    let join = !!previous && depth(previous) > 0;
                    if (join && previous) {
                        join = !!event.grace || equal(add(previous.start, previous.duration), event.start);
                        if (control?.primary === 'split') join = false;
                        else if (control?.primary !== 'join') {
                            join &&= !!event.grace || (tuplets.has(event) || tuplets.has(previous)
                                ? tuplets.get(event) === tuplets.get(previous)
                                : groupAt(previous.start, rule) === groupAt(event.start, rule));
                        }
                    }
                    if (!join) finish();
                    group.push(event);
                }
                finish();
            }
            if (!supplied) findings.push({ disposition: 'inferred', code: 'gp-default-beam-boundaries', message: 'An explicit beam edit is resolved against conventional meter/tuplet groups; no source-authored group list is claimed.', location: measure.source, fact: { unit: rule.unit, groups: rule.groups, voice: voiceIndex + 1 } });
        }
        if (supplied) findings.push({ disposition: 'preserved', code: 'gp-source-beam-groups', message: 'Explicit source grouping is projected at its exact rational boundaries; original counts remain inspectable.', location: supplied.source, fact: supplied });
    }
}

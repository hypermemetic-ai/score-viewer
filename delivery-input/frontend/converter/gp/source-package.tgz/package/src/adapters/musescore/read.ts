import {nativeClefInfo,qualifyNativeClef} from './clefs.js';
import {readNativeCustomKey} from './custom-keys.js';
import { readNativeOrnamentInterval, readNativeOrnamentPolicy, recoverNativeOrnamentPresentation } from './ornament-intervals.js';
import { nativeOrnament } from './ornaments.js';
import { child, children, hasCommentOrCdata, integer, prunedInventory, text, type SourceElement as Element } from '../../core/source-xml.js';
import { add, compare, equal, mul, q, type Rational } from '../../core/rational.js';
import { refuse, Refusal, type Finding } from '../../core/report.js';
import type { Direction, MusicalEvent, MusicalMeasure, MusicalNote, MusicalPart, MusicalScore, MusicalRelation, RelationEndpoint, Pitch, StaffFact, StaffChange, GlyphFact, OrnamentDetails, MarkAnchor, TextRun, TextFontSize } from '../../core/model.js';
import { techniqueGlyphNames } from '../../core/symbols.js';
import { plainTextFontXml } from '../../core/text-font.js';
import { nativeLimits, type ParsedNativeCapture } from './capture-core.js';
import { NativeBudget } from './budget.js';
import { recoverNativeBeamGraph } from './beam-graph.js';
import { recoverArpeggios } from './arpeggios.js';
import { articulationNames } from './markings.js';
import { recoverLyrics } from './lyrics.js';
import { readLegacyBend, readLegacyTremoloBar, nativeTechniqueLines, nativeVibratoCaption } from './techniques.js';
import { createNativeImageReader, type ImageOwner } from './images.js';
import { readModernBend, type NativeModernBend } from './modern-bend.js';
import { createNativeBendPredecessorLookup, recoverNativeBendCurves, recoverNativeBendHolds, type NativeBendRecord } from './bend-graph.js';
import { recoverNativeNavigation } from './navigation.js';
import { recoverNativeTabPresentation, recoverNativeNotationPresentation } from './tab-presentation.js';
import { expandNativeMeasureRepeats } from './measure-repeats.js';
import { nativeSectionStarts } from './section-numbering.js';
import { createNativeGlyphReader, createNativeGlyphSizeProjector } from './glyphs.js';
import { readNativeHeadScheme } from './head-schemes.js';
import { nativeStaffDeclarationId, nativePrimaryStaffLink } from './staff-identity.js';
import { nativeAccidental } from './accidentals.js';
import { readNativeStaffType } from './staff-type.js';
import { readNativeDrums } from './drums.js';
import { readNativeCapo, readLegacyCapo, sourceStateAt } from './capo.js';
import { readFiguredBassItems } from './figured-bass.js';
import { createNativeHarmonyReader } from './harmony.js';
import { createNativeTextReader, type InlineRuns } from './text.js';
import { createNativeTextStyleResolver, nativeTextStylePrefix } from './text-style.js';
import { createNativeLinePresentation } from './line-presentation.js';
import type { NativeTextPresentation } from './presentation.js';
import type { NativeTextScaleContext } from './text-size.js';
import {trillCarrierProfile,trillMeterClock,trillSourceClockPrefix,trillSourcePool,trillSourceHeader,trillLocation,trillNeutralClockRole,indexNativeTrillCarriers,selectNativeTrillCarriers,type SourceTrillBar,type SourceTrillRow,type SourceTrillCarrierIndex,type SourceTrillTupletClock,type SourceTrillCursorClock,type SourceTrillPairClock,type SourceTrillNeutralClock} from './trill-carriers.js';
import { admitNativeVersion, type NativeViews } from './views.js';

const durationTypes: Record<string, Rational> = { longa: q(16), breve: q(8), whole: q(4), half: q(2), quarter: q(1), eighth: q(1, 2), '16th': q(1, 4), '32nd': q(1, 8), '64th': q(1, 16), '128th': q(1, 32), '256th': q(1, 64), '512th': q(1, 128), '1024th': q(1, 256) };
const plainBeamField = (e: Element): boolean => !e.children.length && !Object.keys(e.attrs).length && !hasCommentOrCdata(e);
function ordinaryBeamScalar(e: Element, name: string, values: readonly (string | undefined)[]): boolean {
    const fields = children(e, name); return !fields.length ? values.includes(undefined) : fields.length === 1 && plainBeamField(fields[0]) && values.includes(fields[0].text);
}
const editedSourceBeam = (e: Element): boolean => e.name === 'Beam' && !Object.keys(e.attrs).length && !e.text.trim() && !hasCommentOrCdata(e)
    && ordinaryBeamScalar(e, 'StemDirection', ['up', 'down']) && ordinaryBeamScalar(e, 'visible', [undefined, '0', '1'])
    && (child(e, 'StemDirection')!.text === 'down' || e.children.indexOf(child(e, 'StemDirection')!) < e.children.findIndex(field => field.name === 'Fragment'))
    && children(e, 'Fragment').length > 0 && e.children.every(field => field.name === 'Fragment'
        ? !Object.keys(field.attrs).length && !field.text.trim() && !hasCommentOrCdata(field) && field.children.length === 2
            && ['y1', 'y2'].every(name => children(field, name).length === 1)
            && field.children.every(value => plainBeamField(value) && /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(value.text.trim()) && Number.isFinite(Number(value.text)))
        : ['StemDirection', 'visible'].includes(field.name) && plainBeamField(field));
const plainForcedBeam = (e: Element): boolean => e.name === 'Beam' && !Object.keys(e.attrs).length && !e.text.trim() && !hasCommentOrCdata(e)
    && e.children.every(field => ['StemDirection', 'visible'].includes(field.name) && plainBeamField(field))
    && ordinaryBeamScalar(e, 'StemDirection', ['up', 'down']) && ordinaryBeamScalar(e, 'visible', [undefined, '1']);
// An exact empty serialized Beam registers identity without an explicit direction.
const ordinaryGroupingBeam = (e: Element): boolean => plainForcedBeam(e)
    || e.name === 'Beam' && plainBeamField(e) && /^[ \t\r\n]*$/.test(e.text);

/** Numeric serialization defaults verified at the pinned native boundary; not an encoded velocity. */
function defaultVelocity(label: string): number | undefined {
    if (/^p{1,6}$/.test(label)) return [49, 33, 16, 10, 5, 1][label.length - 1];
    if (/^f{1,6}$/.test(label)) return label.length >= 4 ? 127 : [96, 112, 126][label.length - 1];
    if (label === 'mp') return 64; if (label === 'mf') return 80;
    if (label === 'fp') return 96; if (label === 'pf' || label === 'n') return 49;
    if (/^(?:sf|sfz|sfp|sfpp|rf|rfz|fz)$/.test(label)) return 112;
    if (/^sffz?$/.test(label)) return 126;
    return undefined;
}
const layout = new Set(['eid', 'lid', 'offset', 'pos', 'color', 'autoplace', 'placement', 'generated', 'isHeader', 'z', 'mag', 'small', 'bracket', 'barLineSpan', 'barLineFrom', 'barLineTo', 'show', 'defaultClef', 'defaultConcertClef', 'defaultTransposingClef', 'stemDirection', 'Stem', 'StemSlash', 'Hook', 'stem', 'leadingSpace', 'trailingSpace', 'userLen', 'noStem', 'dotPosition', 'mirror', 'LayoutBreak', 'vspacerDown', 'vspacerUp', 'systemDividerLeft', 'systemDividerRight', 'stretch', 'breakMultiMeasureRest', 'minDistance', 'off1', 'off2', 'off3', 'off4', 'slurDirection', 'lineType', 'lineWidth', 'lineColor', 'continueTextPlace', 'endTextPlace', 'beginTextPlace', 'endHookType', 'beginHookType', 'style', 'fontFace', 'fontSize', 'fontStyle', 'align', 'frameType', 'frameWidth', 'framePadding', 'systemFlag', 'textStyle', 'numberType', 'bracketType', 'baseLen', 'isSmall', 'minPitchP', 'maxPitchP', 'minPitchA', 'maxPitchA', 'singleNoteDynamics', 'clefType', 'defaultSpatium', 'Spatium']);

export interface Construct { name: string; parent: string; count: number; first: Element['location'] }
export function nativeInventory(root: Element): Construct[] {
    const counts = new Map<string, Construct>();
    const stack: [Element, string][] = [[root, 'document']];
    while (stack.length) {
        const [e, parent] = stack.pop()!, key = `${parent}/${e.name}`;
        const entry = counts.get(key);
        if (entry) entry.count++; else {
            if (counts.size >= 8192) refuse('native-inventory-budget', 'Native construct vocabulary exceeds the bounded report profile.', e.location);
            counts.set(key, { name: e.name, parent, count: 1, first: e.location });
        }
        for (const c of e.children) stack.push([c, e.name]);
    }
    for (const [key, entry] of prunedInventory(root)) {
        const existing = counts.get(key);
        if (existing) existing.count += entry.count; else {
            if (counts.size >= 8192) refuse('native-inventory-budget', 'Native construct vocabulary exceeds the bounded report profile.', entry.first);
            counts.set(key, { ...entry });
        }
    }
    return [...counts.values()].sort((a, b) => { const x = `${a.parent}/${a.name}`, y = `${b.parent}/${b.name}`; return x < y ? -1 : x > y ? 1 : 0; });
}
function fraction(value: string, e: Element): Rational {
    if (!/^-?\d{1,9}\/\d{1,9}$/.test(value)) refuse('native-fraction', 'Expected a bounded exact fraction.', e.location);
    const [n, d] = value.split('/').map(Number);
    return q(n, d);
}
function scalar(value: string, e: Element, maximum = 10_000): number {
    if (!/^-?\d{1,6}(?:\.\d{1,20})?$/.test(value) || !Number.isFinite(Number(value)) || Math.abs(Number(value)) > maximum)
        refuse('native-number', 'Expected a bounded finite decimal source value.', e.location);
    return Number(value);
}
/** Inert source geometry may use Qt's bounded scientific notation; musical scalars keep their exact profile. */
function geometryScalar(value: string, e: Element): void {
    if (!/^-?\d{1,6}(?:\.\d{1,20})?(?:[eE][+-]?\d{1,3})?$/.test(value) || !Number.isFinite(Number(value)) || Math.abs(Number(value)) > 10_000)
        refuse('native-geometry-number', 'Expected bounded finite inert geometry data.', e.location);
}
/** Documented TPC encoding, independently mapped to spelling, not guessed from MIDI. */
function pitch(midi: number, tpc: number, e: Element): Pitch {
    const steps = ['F', 'C', 'G', 'D', 'A', 'E', 'B'];
    const index = ((tpc + 1) % 7 + 7) % 7, step = steps[index], alter = Math.floor((tpc + 1) / 7) - 2;
    const bases: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
    const octave = (midi - bases[step] - alter) / 12 - 1;
    if (!Number.isInteger(octave) || octave < 0 || octave > 9) refuse('native-pitch', 'TPC spelling contradicts MIDI pitch or exceeds MusicXML register.', e.location);
    return { step, alter, octave, midi, origin: 'source' };
}
/** Transpose exact encoded spelling by diatonic distance, then derive its chromatic alteration. */
function writtenFromSounding(sounding: Pitch, transpose: MusicalPart['transpose'], e: Element): Pitch {
    if (!transpose) return { ...sounding };
    const steps = 'CDEFGAB', bases = [0, 2, 4, 5, 7, 9, 11];
    const coordinate = sounding.octave * 7 + steps.indexOf(sounding.step) - transpose.diatonic;
    const octave = Math.floor(coordinate / 7), index = (coordinate % 7 + 7) % 7, midi = sounding.midi - transpose.chromatic;
    const alter = midi - (octave + 1) * 12 - bases[index];
    if (octave < 0 || octave > 9 || alter < -3 || alter > 3) refuse('native-pitch', 'Derived written spelling exceeds the independently verified standard pitch range.', e.location);
    return { step: steps[index], alter, octave, midi, origin: 'inferred' };
}
const performedIdentity = (note: MusicalNote): string => note.kind === 'unpitched' ? `drum:${note.unpitched.instrumentId}:${note.unpitched.midi}` : note.kind === 'dead' ? `dead:${note.referenceSounding?.midi}` : `pitch:${note.sounding?.midi}`;
interface Anchor { textScale?: NativeTextScaleContext; part: MusicalPart; staff: number; globalStaff: number; measure: number; voice: number; position: Rational; event?: MusicalEvent; note?: MusicalNote; noteIndex: number; graceIndex: number }
interface Link { element: Element; anchor: Anchor; type: string; next?: Element; prev?: Element; subtype?: string; payload: SpanPayload }
interface SpanPayload {
    modernBend?: NativeModernBend;
    beginText?: string; continueText?: string; endText?: string; lineType?: 'solid' | 'dashed' | 'dotted'; lineVisible?: boolean;
    printObject?: boolean; system?: boolean; startHook?: 'none' | 'up' | 'down'; endHook?: 'none' | 'up' | 'down';
    sourceColor?: MusicalRelation['sourceColor'];
    orientation?: 'over' | 'under';
    placement?: NonNullable<MusicalRelation['placement']>;
    sourceDirection?: MusicalRelation['sourceDirection'];
    octaves?: -3 | -2 | -1 | 1 | 2 | 3; numbers?: number[]; closed?: boolean; niente?: boolean;
    performance?: NonNullable<MusicalRelation['performance']>;
    sourceDuration?: NonNullable<MusicalRelation['sourceDuration']>;
    segmentTracks?: NonNullable<MusicalRelation['segmentTracks']>;
    pedalState?: NonNullable<MusicalRelation['pedalState']>;
    textFacts?: MusicalRelation['textFacts'];
    textFontStyles?: MusicalRelation['textFontStyles'];
    textFontSizes?: MusicalRelation['textFontSizes'];
    textMusicFontSizes?: MusicalRelation['textMusicFontSizes'];
    textFontFamilies?: MusicalRelation['textFontFamilies'];
    textRuns?: MusicalRelation['textRuns'];
    sourceNumbers?: { source: Element['location']; values: number[] };
    trillForm?: Extract<MusicalRelation, { kind: 'trill' }>['form'];
    trillOrnament?: Extract<MusicalRelation, { kind: 'trill' }>['ornament'];
    noteLine?: { sourceForm: 'text-line' | 'note-line'; diagonal?: { source: Element['location']; value: boolean } };
    glissando?: Pick<Extract<MusicalRelation, { kind: 'glissando' }>, 'form' | 'formFact' | 'label'>;
}
const clockKey = (r: Rational) => `${r.n}/${r.d}`;
const anchorKey = (a: Anchor) => `${a.globalStaff}:${a.measure}:${a.voice}:${clockKey(a.position)}:${a.graceIndex}:${a.noteIndex}`;

/** Written from documented musical encodings and observed original/CC0 scores; no upstream implementation. */
export function readNative(capture: ParsedNativeCapture, findings: Finding[], selection?: { inventory: NativeViews; entry: NativeViews['entries'][number] }, sourceHasLyrics = true, sourceHasTrill = true): MusicalScore {
    const root = capture.root;
    const budget = new NativeBudget();
    admitNativeVersion(capture);
    const primaryNode = child(root, 'Score', true)!, scoreNode = selection?.entry.node ?? primaryNode;
    const selectedLinks = new Set(selection?.entry.links.map(link => link.source.path) ?? []);
    const used = new Set<Element>(), ignored = new Map<string, { count: number; first: Element }>();
    const performanceGaps = new Map<string, { count: number; source: Element['location']; message: string; disposition: 'omitted' | 'inferred' | 'preserved'; order: number; ordinal: number }>();
    let performanceOrder = 0;
    const performanceGap = (code: string, source: Element['location'], message: string, disposition: 'omitted' | 'inferred' | 'preserved' = 'omitted') => {
        const order = performanceOrder++, ordinal = 0;
        const item = performanceGaps.get(code);
        if (item) {
            item.count++;
            if (order < item.order || order === item.order && ordinal < item.ordinal) Object.assign(item, { source, message, disposition, order, ordinal });
        } else performanceGaps.set(code, { count: 1, source, message, disposition, order, ordinal });
    };
    // Every 3.x/4.x LyricsLine loader uses a positive saved span as the onset
    // of its last Chord; a fractional ticks_f wins over integer ticks. This
    // qualification does not select native fixups.
    const lyricCaptionProfile = sourceHasLyrics && scoreNode === primaryNode;
    const lyricCaptionSources = new Set<string>();
    const lyricTimingFields: Record<string, string[]> = { TimeSig: ['sigN', 'sigD', 'stretchN', 'stretchD', 'isCourtesy'], Tuplet: ['actualNotes', 'normalNotes'], location: ['fractions'], Chord: ['durationType', 'duration', 'dots', 'track'], Rest: ['durationType', 'duration', 'dots', 'track'] };
    const plainLyricTiming = (owner: Element): boolean => !hasCommentOrCdata(owner)
        && (lyricTimingFields[owner.name] ?? []).every(name => {
            const fields = children(owner, name); return fields.length <= 1 && fields.every(plainBeamField);
        }) && (owner.name !== 'location' || !Object.keys(owner.attrs).length && owner.children.every(field => ['fractions', 'timeTick'].includes(field.name) && plainBeamField(field)))
        && owner.children.filter(field => field.name.startsWith('grace') || ['acciaccatura', 'appoggiatura'].includes(field.name))
            .every(field => ['appoggiatura', 'acciaccatura', 'grace4', 'grace16', 'grace32', 'grace8after', 'grace16after', 'grace32after'].includes(field.name) && plainBeamField(field) && field.text === '');
    // This validates source grammar only. The reader's existing rational cursor,
    // measure lengths and ordinary/grace host settlement remain the clock axis.
    const plainLyricVoice = (voice: Element): boolean => {
        if (Object.keys(voice.attrs).length || hasCommentOrCdata(voice) || !voice.children.every(plainLyricTiming)) return false;
        let host: Element | undefined, interveningTiming = false;
        for (let index = voice.children.length - 1; index >= 0; index--) {
            const owner = voice.children[index], grace = owner.children.find(field => field.name.startsWith('grace') || ['acciaccatura', 'appoggiatura'].includes(field.name));
            if (owner.name === 'Chord' || owner.name === 'Rest') {
                if (!grace) { host = owner; interveningTiming = false; }
                else if (!host || host.name !== 'Chord' || interveningTiming) return false;
            } else if (['location', 'Tuplet', 'endTuplet', 'TimeSig'].includes(owner.name)) interveningTiming = true;
        }
        return true;
    };
    const lyricDivision = children(scoreNode, 'Division');
    const lyricDivisionPlain = lyricDivision.length <= 1 && lyricDivision.every(field => plainBeamField(field) && /^[1-9]\d*$/.test(field.text));
    const closedLyricCaption = (lyric: Element): boolean => {
        if (!lyricCaptionProfile || Object.keys(lyric.attrs).length || hasCommentOrCdata(lyric)
            || new Set(lyric.children.map(field => field.name)).size !== lyric.children.length) return false;
        const allowed = new Set(['ticks', 'ticks_f', 'no', 'syllabic', 'text', 'visible', 'placement', 'offset', 'autoplace', 'minDistance']);
        if (lyric.children.some(field => !allowed.has(field.name) || field.children.length || hasCommentOrCdata(field)
            || (field.name === 'offset' ? field.text.trim() || Object.keys(field.attrs).sort().join(',') !== 'x,y'
                || Object.values(field.attrs).some(value => !/^-?\d{1,6}(?:\.\d{1,20})?$/.test(value)) : Object.keys(field.attrs).length))) return false;
        const text = children(lyric, 'text')[0];
        return !!text && !/[<>\uE000-\uF8FF]/u.test(text.text)
            && lyric.children.every(field => field.name === 'ticks' ? /^\d+$/.test(field.text)
                : field.name === 'ticks_f' ? /^\d+\/[1-9]\d*$/.test(field.text)
                    : field.name === 'no' ? /^\d+$/.test(field.text)
                        : ['visible', 'autoplace'].includes(field.name) ? /^[01]$/.test(field.text)
                            : field.name === 'placement' ? ['above', 'below'].includes(field.text) : true);
    };
    const attributeProfiles: Record<string, string[]> = { museScore: ['version'], Part: ['id'], Staff: ['id'], Instrument: ['id'], Spanner: ['type'], TextLine: ['system'], Measure: ['len', 'number'], program: ['value'], controller: ['ctrl', 'value'], Channel: ['name'], LayerTag: ['id', 'tag'], metaTag: ['name'], font: ['face', 'size'], clef: ['staff'], Node: ['pos', 'action'], channelSwitch: ['name', 'voice'], Drum: ['pitch'], color: ['r', 'g', 'b', 'a'], frameFgColor: ['r', 'g', 'b', 'a'], frameBgColor: ['r', 'g', 'b', 'a'] };
    const use = (e: Element) => {
        if (Object.keys(e.attrs).some(key => !(Object.hasOwn(attributeProfiles, e.name) ? attributeProfiles[e.name] : ['id']).includes(key))) refuse('native-attribute', `Uninterpreted attributes on ${e.name}.`, e.location);
        if (e.attrs.id?.length > 256) refuse('native-identity-budget', 'Source identity exceeds the bounded field profile.', e.location);
        used.add(e); return e;
    };
    const resolvePresentation = createNativeTextStyleResolver((selection && scoreNode !== primaryNode
        ? [child(scoreNode, 'Style')] : [capture.styleRoot?.children[0], child(scoreNode, 'Style')]).filter((e): e is Element => !!e), {
        nativeVersion: capture.nativeVersion,
        use: field => {
            // The resolver uses the original Style field locator after validating
            // its normalized RGBA value; the source name is e.g. titleColor.
            if(field.name.endsWith('Color') && !field.children.length && !field.text.trim() && ['a,b,g,r','b,g,r'].includes(Object.keys(field.attrs).sort().join(','))
                && Object.values(field.attrs).every(value=>/^\d+$/.test(value)&&Number(value)<=255)) {used.add(field);return field;}
            return use(field);
        },
        addMarking: field => { if (!used.has(field)) budget.add('markings', 1, field.location); },
        gap: (field, message) => performanceGap('native-text-presentation', field.location, message),
    });
    const linePresentation=createNativeLinePresentation((selection&&scoreNode!==primaryNode?[child(scoreNode,'Style')]:[capture.styleRoot?.children[0],child(scoreNode,'Style')]).filter((e):e is Element=>!!e),{
        nativeVersion:capture.nativeVersion,use,addMarking:field=>{if(!used.has(field))budget.add('markings',1,field.location);},
        gap:(field,message)=>performanceGap('native-line-caption-presentation',field.location,message),
    });
    const deferredCaptionGaps=new Map<Element,{code:string;source:Element['location'];message:string}[]>();
    const deferCaptionGap=(owner:Element,code:string,source:Element['location'],message:string)=>{const list=deferredCaptionGaps.get(owner)??[];list.push({code,source,message});deferredCaptionGaps.set(owner,list);};
    const deferredInline=new Map<Element,{runs:InlineRuns;source:Element['location'];code:string;slot?:'beginText'|'continueText'|'endText'}[]>();
    const deferInline=(owner:Element,runs:InlineRuns,source:Element['location'],code:string,slot?:'beginText'|'continueText'|'endText')=>{const items=deferredInline.get(owner)??[];items.push({runs,source,code,slot});deferredInline.set(owner,items);};
    const resolveInline=(owner:Element,target:NativeTextPresentation|SpanPayload)=>{
        for(const item of deferredInline.get(owner)??[]){
            const runs=item.slot?(target as SpanPayload).textRuns?.[item.slot]:(target as NativeTextPresentation).textRuns;
            const remaining=new Set(item.runs.limits), effective=runs??item.runs.values;
            const sizes=effective.filter(run=>run.textFontSize);
            if(sizes.every(run=>run.symbolName?!!run.musicFontSize?.pointSize:!!run.textFontSize?.pointSize))remaining.delete('font-size');
            for(const [limit,value] of [['sup','super'],['sub','sub']] as const){const scripts=effective.filter(run=>run.script?.value===value);if(scripts.every(run=>!run.symbolName&&!!run.script?.projection))remaining.delete(limit);}
            if(remaining.size)performanceGap(item.code,item.source,`The ordered source caption retains unresolved inline appearance duties: ${[...remaining].sort().join(', ')}. Recovered ordinary run sizes and script positions remain independently located.`);
            if(runs?.some(run=>run.script?.projection&&run.script.value!=='normal'))performanceGap('native-inline-script-layout',item.source,'Source superscript/subscript state and the native 0.6 size ratio are preserved. Standard baseline placement is a derived readable layout, not a claim of exact native text geometry.','inferred');
        }
        deferredInline.delete(owner);
    };
    const unresolvedTempoFamilies = new Map<Element, Element['location']>();
    const unqualifiedRichDynamicSizes = new WeakSet<object>();
    const applyPresentation = (owner: Element, target: NativeTextPresentation, scale?:NativeTextScaleContext) => {
        resolvePresentation(owner,target,scale);
        resolveInline(owner,target);
        const unresolved=unresolvedTempoFamilies.get(owner), family=target.textFontFamily;
        if(unresolved && (!family || family.origin==='native-default' || family.qualification || !ordinaryFamily(family.value)))
            performanceGap('native-tempo-family-context',unresolved,'The exact source family/style context remains captured. No effective ordinary source family was established by the active style and ordered owner properties.');
    };
    const omit = (e: Element, reason: string) => {
        const item = ignored.get(reason);
        if (item) item.count++; else ignored.set(reason, { count: 1, first: e });
        const stack = [e]; while (stack.length) { const x = stack.pop()!; used.add(x); stack.push(...x.children); }
    };
    const get = (e: Element, name: string, required = false): string => {
        const c = child(e, name, required); if (c) use(c);
        if (c && c.text.length > 65536) refuse('native-field-budget', 'Native musical field exceeds the bounded text profile.', c.location);
        return c?.text.trim() ?? '';
    };
    const int = (e: Element, name: string, min: number, max: number, fallback?: number): number => {
        const value = get(e, name, fallback === undefined);
        return value ? integer(value, min, max, e.location) : fallback!;
    };
    const readColor = (owner: Element): Direction['sourceColor'] => {
        const colors = children(owner, 'color'); if (!colors.length) return undefined;
        let rgba: [number, number, number, number] | undefined;
        for (const color of colors) {
            budget.add('markings', 1, color.location);
            if (color.text.trim() || color.children.length || !['a,b,g,r','b,g,r'].includes(Object.keys(color.attrs).sort().join(',')))
                refuse('native-color', 'Explicit source color requires bounded RGB channels, optional alpha, and no other content.', color.location);
            const value = ['r', 'g', 'b', 'a'].map(name => integer(name==='a' ? color.attrs.a??'255' : color.attrs[name], 0, 255, color.location)) as [number, number, number, number];
            if (rgba && value.some((channel, index) => channel !== rgba![index]))
                refuse('native-color-conflict', 'Repeated source colors disagree; no override is guessed.', color.location);
            rgba = value; used.add(color); // The owner-specific RGB/optional-alpha shape validates every attribute.
        }
        if (colors.length > 1) performanceGap('native-color-identical-repetition', colors[1].location,
            'Identical repeated source color values project once; every encoded occurrence remains located in the color fact.', 'inferred');
        return { source: colors[0].location, rgba: rgba!, ...(!Object.hasOwn(colors[0].attrs,'a')?{alphaOrigin:'native-default' as const}:{}), ...(colors.length > 1 ? { occurrences: colors.map(color => color.location) } : {}) };
    };
    const readBendLineColor=(owner:Element):Direction['sourceColor']=>{
        let result:Direction['sourceColor'];
        for(const field of owner.children)if(['color','lineColor'].includes(field.name)){
            result=readColor({...owner,children:[{...field,name:'color'}]});used.add(field);
        }
        return result;
    };
    const readDots = (owner: Element, count: number): MusicalEvent['dotFacts'] => {
        const dots = children(owner, 'NoteDot'); if (!dots.length) return undefined;
        if (dots.length !== count) refuse('native-dot-count', 'Encoded dot objects must match their source-owned printed dot count; no rhythmic value is changed or stale object guessed.', dots[0].location);
        budget.add('markings', dots.length, owner.location);
        return dots.map((dot, index) => {
            if (dot.text.trim() || Object.keys(dot.attrs).length) refuse('native-dot', 'Encoded dot object has unexamined text or attributes.', dot.location);
            use(dot);
            const visible = child(dot, 'visible'), eid = child(dot, 'eid');
            for (const field of dot.children) {
                if (['visible', 'eid', 'autoplace'].includes(field.name)) {
                    if (field.children.length || Object.keys(field.attrs).length) refuse('native-dot', 'Dot property must be a plain scalar.', field.location);
                    use(field);
                    if (field.name === 'visible' || field.name === 'autoplace') integer(field.text.trim(), 0, 1, field.location);
                    else if (!field.text.trim() || field.text.trim().length > 256) refuse('native-identity-budget', 'Dot editor identity requires a bounded nonempty value.', field.location);
                } else if (field.name === 'offset') {
                    if (field.text.trim() || field.children.length || Object.keys(field.attrs).some(name => !['x', 'y'].includes(name)) || field.attrs.x === undefined || field.attrs.y === undefined)
                        refuse('native-dot', 'Dot offset must be a bounded source point.', field.location);
                    scalar(field.attrs.x, field); scalar(field.attrs.y, field); omit(field, 'native-dot-position-geometry');
                } else refuse('native-dot', 'Uninterpreted dot property.', field.location);
            }
            child(dot, 'autoplace'); child(dot, 'offset'); // Duplicate scalar declarations are never resolved by encounter order.
            return { source: dot.location, index, ...(eid ? { sourceEid: eid.text.trim() } : {}), ...(visible ? { printObject: visible.text.trim() === '1' } : {}) };
        });
    };
    const readSegment = (segment: Element, owner: string, payload?: SpanPayload, scale?:NativeTextScaleContext): void => {
        if (segment.text.trim() || Object.keys(segment.attrs).length) refuse('native-segment', 'Segment has unexamined text or attributes.', segment.location);
        use(segment);
        for (const field of segment.children) {
            if(owner==='GuitarBend' && field.name==='GuitarBendText'){
                if(field.text.trim()||Object.keys(field.attrs).length)refuse('native-bend-label','Bend text requires plain source property ownership.',field.location);
                use(field);budget.add('markings',1,field.location);
                const label:NonNullable<NonNullable<NativeModernBend['labels']>[number]>={source:field.location};
                const visible=get(field,'visible');if(visible)label.printObject=integer(visible,0,1,field.location)===1;
                const caption=child(field,'text');if(caption){label.serializedText=plainText(caption);omit(caption,'native-generated-bend-label-cache');}
                applyPresentation(field,label,scale);decoration(field);
                (payload!.modernBend!.labels??=[]).push(label);
                if(label.printObject===false||label.sourceColor||label.textEnclosure||label.textFrameAppearance||label.textAlignment||label.textEmphasis?.underline?.value||label.textEmphasis?.strike?.value||(label.textFontStyle?.value??0)&12)
                    performanceGap('native-bend-label-presentation',field.location,'The generated bend label retains its own source presentation. MusicXML bend has font attributes, but no independent label visibility/color, text decoration, frame or block-alignment attributes separate from its curve. Those source label properties remain explicit; the musical amount and curve are unchanged.');
                continue;
            }
            if (owner === 'voice') {
                if (field.name !== 'leadingSpace' || field.children.length || Object.keys(field.attrs).length) refuse('native-segment', 'Uninterpreted voice segment field.', field.location);
                geometryScalar(field.text.trim(), field); omit(field, 'native-segment-spacing-geometry'); continue;
            }
            if (['offset', 'off2'].includes(field.name) || owner==='GuitarBend'&&field.name==='bendVertexOffset') {
                if (field.text.trim() || field.children.length || Object.keys(field.attrs).some(name => !['x', 'y'].includes(name)) || field.attrs.x === undefined || field.attrs.y === undefined)
                    refuse('native-segment', 'Segment point requires bounded x/y source data.', field.location);
                geometryScalar(field.attrs.x, field); geometryScalar(field.attrs.y, field); omit(field, 'native-line-segment-geometry'); continue;
            }
            if (field.children.length || Object.keys(field.attrs).length) refuse('native-segment', 'Segment property must be a plain scalar.', field.location);
            if (field.name === 'visible') {
                const value = integer(field.text.trim(), 0, 1, field.location) === 1;
                if (!['GuitarBend','GuitarBendHold'].includes(owner) && value !== (payload?.printObject ?? true)) refuse('native-segment-visibility', 'Segment visibility conflicts with the effective parent line; no per-system view is guessed.', field.location);
                use(field);
            } else if (field.name === 'track') {
                if (owner !== 'Trill' || !payload) refuse('native-segment-track', 'Segment track needs an independently exercised printed-owner rule.', field.location);
                budget.add('timelines', 1, field.location); use(field); (payload!.segmentTracks ??= []).push({ source: field.location, value: integer(field.text.trim(), 0, 1023, field.location) });
            } else if (['subtype', 'autoplace', 'z', 'minDistance', 'eid'].includes(field.name)) {
                if (field.name === 'subtype') integer(field.text.trim(), 0, 3, field.location);
                else if (field.name === 'autoplace') integer(field.text.trim(), 0, 1, field.location);
                else if (field.name === 'z') integer(field.text.trim(), -1_000_000_000, 1_000_000_000, field.location);
                else if (field.name === 'minDistance') geometryScalar(field.text.trim(), field);
                else if (!field.text.trim() || field.text.trim().length > 256) refuse('native-identity-budget', 'Segment editor identity requires a bounded nonempty value.', field.location);
                omit(field, 'native-line-segment-geometry-and-editor-identity');
            } else refuse('native-segment', 'Uninterpreted line segment field.', field.location);
        }
        // Native point overrides may repeat in source order; scalar roles must remain unique.
        for (const field of ['subtype', 'visible', 'autoplace', 'z', 'minDistance', 'eid', 'track', 'leadingSpace','GuitarBendText']) child(segment, field);
    };
    const readStemGraphics = (owner: Element, event: MusicalEvent, clockHook?: (graphic: Element) => void): void => {
        for (const kind of ['Stem', 'Hook'] as const) {
            const graphic = child(owner, kind); if (!graphic) continue;
            if (graphic.text.trim() || Object.keys(graphic.attrs).length) refuse('native-stem-graphic', 'Stem/flag graphic requires plain source properties.', graphic.location);
            use(graphic); budget.add('markings', 1, graphic.location);
            const seen = new Set<string>();
            for (const field of graphic.children) {
                if (seen.has(field.name)) refuse('native-stem-graphic', 'Repeated stem/flag property is ambiguous.', field.location); seen.add(field.name);
                if (field.name === 'offset') {
                    if (field.text.trim() || field.children.length || Object.keys(field.attrs).some(key => !['x', 'y'].includes(key)) || field.attrs.x === undefined || field.attrs.y === undefined) refuse('native-stem-graphic', 'Stem/flag offset requires an inert source point.', field.location);
                    geometryScalar(field.attrs.x, field); geometryScalar(field.attrs.y, field); omit(field, 'native-stem-flag-geometry'); continue;
                }
                if (kind === 'Hook' && field.name === 'color') {
                    if (field.text.trim() || field.children.length || Object.keys(field.attrs).sort().join(',') !== 'a,b,g,r') refuse('native-stem-graphic', 'Flag color requires bounded source ARGB data.', field.location);
                    for (const value of Object.values(field.attrs)) integer(value, 0, 255, field.location);
                    if (field.attrs.a !== '255') refuse('native-hook-color', 'Nonopaque flag color requires a separately verified visibility projection.', field.location);
                    omit(field, 'native-flag-color'); continue;
                }
                if (field.children.length || Object.keys(field.attrs).length) refuse('native-stem-graphic', 'Stem/flag property must be a plain scalar.', field.location);
                if (field.name === 'visible') {
                    use(field); const value = integer(field.text.trim(), 0, 1, field.location) === 1;
                    if (kind === 'Stem') event.sourceStemVisibility = { source: field.location, value };
                    else (event.sourceHook ??= { source: graphic.location }).printObject = value;
                } else if (kind === 'Hook' && field.name === 'name') {
                    const value = field.text.trim(); if (!['flag8thUp', 'flag8thDown', 'flag16thUp', 'flag16thDown'].includes(value)) refuse('native-hook-name', 'Unexercised source flag glyph.', field.location);
                    use(field); (event.sourceHook ??= { source: graphic.location }).name = { source: field.location, value: value as NonNullable<NonNullable<MusicalEvent['sourceHook']>['name']>['value'] };
                } else if (field.name === 'autoplace') { integer(field.text.trim(), 0, 1, field.location); omit(field, 'native-stem-flag-geometry'); }
                else if (kind === 'Stem' && ['userLen', 'lineWidth'].includes(field.name)) { geometryScalar(field.text.trim(), field); omit(field, 'native-stem-flag-geometry'); }
                else if (field.name === 'eid') { if (!field.text.trim() || field.text.length > 256) refuse('native-identity-budget', 'Stem/flag editor identity must be bounded.', field.location); omit(field, 'native-stem-flag-editor-identity'); }
                else refuse('native-stem-graphic', 'Uninterpreted useful stem/flag property.', field.location);
            }
            if (kind === 'Hook') clockHook?.(graphic);
        }
    };
    const decoration = (e: Element) => {
        if (selection) for (const marker of e.children) if (['linked', 'linkedTo'].includes(marker.name) && selectedLinks.has(marker.location.path)) omit(marker, 'native-selected-object-membership');
        for (const c of e.children) if (!used.has(c) && layout.has(c.name)) omit(c, 'native-layout-and-playback-decoration');
        if (['Chord', 'Rest', 'Note', 'Articulation', 'Ornament', 'Breath', 'Fermata', 'Dynamic', 'StaffText', 'SystemText', 'Expression', 'Text', 'InstrumentChange', 'RehearsalMark', 'Fingering', 'Symbol', 'FSymbol', 'Image', 'Tempo', 'Marker', 'Jump', 'Slur', 'Tie', 'HairPin', 'Pedal', 'Ottava', 'TextLine', 'NoteLine', 'Trill', 'Volta', 'BarLine', 'Tuplet', 'Clef', 'KeySig', 'TimeSig', 'Lyrics', 'Arpeggio', 'Glissando', 'Harmony', 'FretDiagram', 'Capo', 'Bend', 'PalmMute', 'LetRing', 'Vibrato', 'HarmonicMark', 'Tapping', 'GuitarBend', 'HammerOnPullOff', 'TremoloBar', 'WhammyBar', 'Tremolo', 'TremoloSingleChord', 'TremoloTwoChord'].includes(e.name)) {
            const marker = child(e, 'linkedMain');
            if (marker) {
                if (marker.children.length || marker.text.trim() || Object.keys(marker.attrs).length) refuse('native-primary-link', 'Primary linked-object marker must be empty; no target is guessed.', marker.location);
                omit(marker, 'native-primary-linked-object');
            }
        }
        // This field locates a dynamic above/below its owner. The same name elsewhere is not a blanket layout rule.
        if (e.name === 'Dynamic') {
            const direction = child(e, 'direction');
            if (direction) {
                if (!['up', 'down', 'auto'].includes(direction.text.trim())) refuse('native-dynamic-direction', 'Uninterpreted dynamic placement.', direction.location);
                omit(direction, 'native-dynamic-placement');
            }
        }
        if (['Tie', 'Slur'].includes(e.name)) for (const c of e.children) {
            if (used.has(c)) continue;
            if (c.name === 'up') { if (!['0', '1', '2', 'auto', 'up', 'down'].includes(c.text.trim())) refuse('native-relation-curve', 'Unknown authored slur/tie curve direction.', c.location); omit(c, 'native-relation-curve-geometry'); }
            else if (['TieSegment', 'SlurSegment'].includes(c.name)) omit(c, 'native-relation-curve-geometry');
        }
        if (['StaffText', 'SystemText', 'Expression', 'Text', 'InstrumentChange', 'RehearsalMark', 'Tempo', 'Lyrics', 'Fingering', 'Dynamic', 'PlayTechAnnotation', 'MeasureNumber', 'Marker', 'Jump','GuitarBendText'].includes(e.name)) for (const c of e.children) if (!used.has(c) && ['size', 'snapToDynamics', 'family', 'italic', 'bold', 'underline', 'strike', 'frameBgColor', 'frameFgColor', 'frameColor', 'frameRound', 'frameCircle', 'sizeIsSpatiumDependent'].includes(c.name)) omit(c, 'native-text-engraving');
        if (['StaffText', 'SystemText', 'Expression', 'Text', 'RehearsalMark', 'Tempo', 'Lyrics', 'Fingering', 'Dynamic', 'PlayTechAnnotation', 'MeasureNumber', 'Marker', 'Jump'].includes(e.name)) {
            const leading = child(e, 'textLineSpacing');
            if (leading) { scalar(leading.text.trim(), leading); omit(leading, 'native-text-leading'); }
        }
        if (['Articulation', 'Tuplet', 'HairPin'].includes(e.name)) for (const c of e.children) {
            if (c.name === 'direction') { if (!['auto', 'up', 'down', '0', '1', '2'].includes(c.text.trim())) refuse('native-placement', 'Unknown authored direction.', c.location); omit(c, 'native-mark-placement'); }
            else if (e.name === 'Articulation' && c.name === 'anchor') { integer(c.text.trim(), 0, 4, c.location); omit(c, 'native-articulation-anchor-placement'); }
        }
        if (e.name === 'Staff') for (const c of e.children) if (c.name === 'distOffset') { scalar(c.text.trim(), c); omit(c, 'native-staff-distance'); }
        if (e.name === 'Measure') for (const c of e.children) if (c.name === 'vspacerFixed') omit(c, 'native-measure-staff-spacing');
        if (e.name === 'Part') for (const c of e.children) if (c.name === 'hideStavesWhenIndividuallyEmpty') { integer(c.text.trim(), 0, 1, c.location); omit(c, 'native-empty-staff-visibility'); }
        if (['Staff', 'Part'].includes(e.name)) for (const c of e.children) {
            if (c.name === 'hideWhenEmpty') {
                const choices = Number(capture.nativeVersion) < 4.6 ? ['0', '1', '2', '3'] : ['auto', 'on', 'off'];
                if (!choices.includes(c.text.trim())) refuse('native-staff-visibility', 'Unknown versioned empty-staff policy.', c.location);
                if (!used.has(c)) omit(c, 'native-empty-staff-visibility');
            } else if (['showIfSystemEmpty', 'cutaway', 'hideSystemBarLine'].includes(c.name)) { integer(c.text.trim(), 0, 1, c.location); omit(c, 'native-empty-staff-visibility'); }
        }
        if (e.name === 'BarLine') for (const c of e.children) if (['spanFromOffset', 'spanToOffset'].includes(c.name)) { integer(c.text.trim(), -128, 128, c.location); omit(c, 'native-barline-span-geometry'); }
        if (e.name === 'Measure') for (const c of e.children) if (c.name === 'MeasureNumber') {
            use(c); const encoded = child(c, 'text'); if (encoded) { plainText(encoded); performanceGap('native-measure-number-text',c.location,'The native generated measure-number text cache remains source-located; the performer label is recovered from the source numbering sequence and section resets.','preserved'); }
            const visible = get(c, 'visible'); if (visible) integer(visible, 0, 1, c.location);
            decoration(c);
        }
    };
    const sourceTrack = (e: Element, staff: number, voice: number) => {
        const value = get(e, 'track');
        if (value && integer(value, 0, 1023, e.location) !== (staff - 1) * 4 + voice)
            refuse('native-track', 'Encoded track changes source ownership and requires explicit recovery.', e.location);
    };
    const {
        readTextEmphasis, ordinaryFamily, readTextFamily, qualifyTextFamilies, legacyInvalidHairpinCaption,
        nativeTextLoader, hasOtherTextRole, isOrdinaryCaption, ordinaryTempoShape, systemTextGlyphShape, plainText
    } = createNativeTextReader({ capture, budget, use, omit, performanceGap });
    const glyphStyleScopes=(selection&&scoreNode!==primaryNode?[child(scoreNode,'Style')]:[capture.styleRoot?.children[0],child(scoreNode,'Style')]).filter((e):e is Element=>!!e);
    const readGlyphs=createNativeGlyphReader({nativeVersion:capture.nativeVersion,budget,use,get,readColor,decoration,performanceGap,styleScopes:glyphStyleScopes});
    const accidentalPointSize=createNativeGlyphSizeProjector(glyphStyleScopes,capture.nativeVersion,use);
    const sourceMagnification=(name:'smallNoteMag'|'graceNoteMag'):number=>{
        const field=glyphStyleScopes.flatMap(style=>children(style,name)).at(-1);if(!field)return .7;
        if(field.children.length||Object.keys(field.attrs).length)return refuse('native-accidental-size','Glyph magnification requires a plain source scalar.',field.location);
        geometryScalar(field.text.trim(),field);const value=Number(field.text.trim());if(value<=0)return refuse('native-accidental-size','Glyph magnification must be positive.',field.location);use(field);return value;
    };
    const accidentalSize=(owner:Element,small:boolean,scale?:NativeTextScaleContext,event?:MusicalEvent,note?:MusicalNote)=>{
        if(!small)return undefined;const factor=sourceMagnification('smallNoteMag')**(1+Number(!!event?.small?.value)+Number(!!note?.small?.value))*(event?.grace?sourceMagnification('graceNoteMag'):1);
        const size=accidentalPointSize(owner,factor,scale);if(!size)performanceGap('native-accidental-size',owner.location,'The small accidental retains its source request but lacks qualified active staff-space size.');return size;
    };
    const readOrnament = (owner: Element, ornament: Element | undefined, accidentalNodes: Element[], trill: boolean, scale?:NativeTextScaleContext,event?:MusicalEvent): OrnamentDetails => {
        const prefix = trill ? 'native-trill' : 'native-ornament';
        const facts: OrnamentDetails = { source: (ornament ?? owner).location, accidentals: [] };
        if (ornament) {
            use(ornament); const subtype = get(ornament, 'subtype', true);
            if (trill ? subtype !== 'ornamentTrill' : !nativeOrnament(subtype)) refuse(`${prefix}-ornament`, 'Uninterpreted source ornament.', ornament.location);
            facts.sourceSubtype = subtype;
            const sign = trill ? undefined : nativeOrnament(subtype)?.sign; if (sign) facts.sign = { source: child(ornament, 'subtype')!.location, ...sign };
            const play = get(ornament, 'play'); if (play) facts.play = { source: child(ornament, 'play')!.location, value: integer(play, 0, 1, ornament.location) === 1 };
            for(const [field,side] of [['intervalAbove','above'],['intervalBelow','below']] as const) {
                const interval=child(ornament,field);if(interval){get(ornament,field);facts[field]=readNativeOrnamentInterval(interval,subtype,side);}
            }
            for(const field of ['ornamentShowCueNote','ornamentShowAccidental']){const policy=child(ornament,field);if(policy){get(ornament,field);readNativeOrnamentPolicy(policy,facts);}}
        }
        if (accidentalNodes.length > 2) refuse(`${prefix}-accidental`, 'An ornament has ambiguous accidental annotations.', owner.location);
        budget.add('markings', accidentalNodes.length, owner.location);
        for (const accidental of accidentalNodes) {
            use(accidental); const subtype=get(accidental,'subtype',true), mapped=nativeAccidental(subtype,capture.nativeVersion,accidental.location);
            const placement = get(accidental, 'placement') || 'above'; if (!['above', 'below'].includes(placement)) refuse(`${prefix}-accidental`, 'Unknown ornament accidental placement.', accidental.location);
            const role = get(accidental, 'role'), visible = get(accidental, 'visible'), small = get(accidental, 'small'), track = get(accidental, 'track'), sourceColor=readColor(accidental);
            facts.accidentals!.push({ source: accidental.location, name: mapped.name, sourceName:subtype, ...(mapped.smufl?{smufl:mapped.smufl}:{}), ...(mapped.empty?{printObject:false}:{}), ...(sourceColor?{sourceColor}:{}), ...(small==='1'?{fontSize:accidentalSize(accidental,true,scale,event)}:{}), placement: placement as 'above' | 'below', ...(role ? { role: integer(role, 0, 1, accidental.location) ? 'user' : 'auto' } : {}), ...(visible ? { printObject: integer(visible, 0, 1, accidental.location) === 1 } : {}), ...(small ? { small: integer(small, 0, 1, accidental.location) === 1 } : {}), ...(track ? { sourceTrack: integer(track, 0, 1023, accidental.location) } : {}) });
            decoration(accidental);
        }
        if (new Set(facts.accidentals!.map(a => a.placement)).size !== facts.accidentals!.length) refuse(`${prefix}-accidental`, 'Multiple accidental annotations target the same ornament side.', owner.location);
        if (ornament) decoration(ornament);
        return facts;
    };
    use(root); use(scoreNode);
    if (selection && scoreNode !== primaryNode) {
        use(primaryNode);
        for (const unselected of primaryNode.children) if (unselected !== scoreNode) omit(unselected, 'native-unselected-source-view');
    }
    const styleValues = new Map<string, { value: string; origin: 'source' | 'native-default'; source: Element['location']; plainCaption?: boolean; runs?: InlineRuns['values'] }>();
    // D45: one primary text-style authority for every MuseScore 3/4 producer.
    // MuseScore takes the first defaultsVersion anywhere in the file; a 3.01
    // file, or a 3.02 file on a 301/206/114 baseline, keeps the pre-3.6
    // FreeSerif defaults. MuseScore 4 saves its complete style.
    const nativeMajor = capture.nativeVersion.startsWith('4.') ? 4 : 3;
    const plainStyleField = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length && !hasCommentOrCdata(field);
    const primaryStyleScopes = [capture.styleRoot?.children[0], ...children(primaryNode, 'Style')].filter((node): node is Element => !!node);
    const firstDefaultsVersion = (() => {
        const pending = [root];
        while (pending.length) {
            const node = pending.pop()!; if (node.name === 'defaultsVersion') return node;
            for (let index = node.children.length - 1; index >= 0; index--) pending.push(node.children[index]);
        }
        return undefined;
    })();
    const legacyStyleBaseline = capture.nativeVersion === '3.01'
        || capture.nativeVersion === '3.02' && ['114', '206', '301'].includes(firstDefaultsVersion?.text.trim() ?? '');
    /** The effective saved style field; null when its encoding is not a plain value. */
    const primaryStyleField = (name: string): Element | null | undefined => {
        const field = primaryStyleScopes.flatMap(scope => children(scope, name)).at(-1);
        return field && (plainStyleField(field) ? field : null);
    };
    const nativeDefaultFamily = legacyStyleBaseline ? 'FreeSerif' : 'Edwin';
    // From 4.1 Dynamic text takes its face, size and style from Expression.
    const dynamicStylePrefix = Number(capture.nativeVersion) >= 4.1 ? 'expression' : 'dynamics';
    const maxFontStyle = nativeMajor === 4 ? 15 : 7;
    const plainFontStyle = (field: Element): boolean => /^\d{1,2}$/.test(field.text.trim()) && Number(field.text.trim()) <= maxFontStyle;
    const systemTextStyleFields = new Map<string, { field: Element; repeated: boolean }>();
    const hairpinDefaultSelectors = new Map<string, { field: Element; repeated: boolean }>();
    let sourceView: MusicalScore['sourceView'];
    const measureNumbering: NonNullable<MusicalScore['measureNumbering']> = {};
    const pageTextFields = new Map<string, { source: Element['location']; raw: string; text: string }>(), pageTextConditions = new Map<string, { source: Element['location']; value: boolean; origin: 'source-style' }>();
    const styleDefaultSelectors: NonNullable<MusicalScore['sourceSelection']>['styleDefaultSelectors'] = [];
    let defaultFontDependency: { field: Element; repeated: boolean } | undefined;
    const plainCaptionSizeField = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length && !field.hasComment && !field.cdata;
    const captionSizeFields = (content: Element, field: string, property: string, value: string | undefined): { sizeField: Element; caption: Element } | undefined => {
        const definitions = children(content, property), captions = children(content, field), sizeField = definitions[0], caption = captions[0];
        return !Object.keys(content.attrs).length && definitions.length === 1 && sizeField && plainCaptionSizeField(sizeField) && sizeField.text.length <= 65536
            && captions.length === 1 && caption && plainCaptionSizeField(caption) && !!caption.text.trim() && caption.text.length <= 65536
            && !/[<>\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(caption.text) && value === caption.text ? { sizeField, caption } : undefined;
    };
    // Every 3.x/4.x line loader reads an explicit caption size in points when
    // the saved style turns off spatium-dependent defaults.
    const textLineCaptionSizeProfile = scoreNode === primaryNode && !!nativeTextLoader;
    const pointDefinition = textLineCaptionSizeProfile ? primaryStyleField('defaultFontSpatiumDependent') : undefined;
    const textLinePointDependency = pointDefinition && pointDefinition.text.trim() === '0' ? pointDefinition : undefined;
    // The native styled caption and the explicit size are independent members.
    // Hairpin caption defaults are the same in every 3.x/4.x baseline.
    let defaultHairpinSizeStyle: boolean | undefined;
    const sourceDefaultHairpinSizeStyle = (): boolean => defaultHairpinSizeStyle ??= textLineCaptionSizeProfile
        && !primaryNode.children.some(field => ['stylefile', 'styleFile', 'StyleFile', 'defaultStyle'].includes(field.name))
        && ['hairpinCrescText', 'hairpinDecrescText', 'hairpinCrescContText', 'hairpinDecrescContText'].every(name => {
            const field = primaryStyleField(name); return field !== null && (!field || field.text.length <= 65536 && !/[<>]/.test(field.text));
        });
    const defaultHairpinCaptionSizeField = (content: Element, field: 'beginText' | 'continueText' | 'endText', property: string,
        value: string | undefined, fact: NonNullable<MusicalRelation['textFacts']>['beginText']): Element | undefined => {
        if (field === 'endText' || content.name !== 'HairPin' || Object.keys(content.attrs).length || hasCommentOrCdata(content)
            || !/^[ \t\r\n]*$/.test(content.text) || children(content, field).length || children(content, 'useTextLine').length) return undefined;
        const subtype = children(content, 'subtype'), sizes = children(content, property), size = sizes[0];
        if (subtype.length !== 1 || !plainCaptionSizeField(subtype[0]) || hasCommentOrCdata(subtype[0]) || !['2', '3'].includes(subtype[0].text)
            || sizes.length !== 1 || !size || !plainCaptionSizeField(size) || hasCommentOrCdata(size) || size.text.length > 65536
            || !/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(size.text.trim()) || !Number.isFinite(Number(size.text.trim()))
            || Number(size.text.trim()) <= 0 || Number(size.text.trim()) > 10_000) return undefined;
        if (!sourceDefaultHairpinSizeStyle()) return undefined;
        const known = new Set(['beginText', 'continueText', 'endText', 'beginFontSize', 'continueFontSize', 'endFontSize', 'beginFontStyle', 'continueFontStyle', 'endFontStyle',
            'beginFontFace', 'continueFontFace', 'endFontFace', 'beginTextAlign', 'continueTextAlign', 'endTextAlign', 'beginTextPlace', 'continueTextPlace', 'endTextPlace',
            'beginTextOffset', 'continueTextOffset', 'endTextOffset', 'beginHookType', 'endHookType', 'beginHookHeight', 'endHookHeight', 'lineVisible', 'lineStyle', 'lineWidth',
            'visible', 'placement', 'autoplace', 'offset', 'minDistance', 'diagonal', 'subtype', 'hairpinCircledTip', 'veloChange', 'dynType', 'singleNoteDynamics', 'veloChangeMethod',
            'linkedMain', 'dashGapLength', 'dashLineLength', 'hairpinHeight', 'Segment']);
        const finite = (text: string, positive = false): boolean => /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(text.trim())
            && Number.isFinite(Number(text.trim())) && Math.abs(Number(text.trim())) <= 10_000 && (!positive || Number(text.trim()) > 0);
        const plain = (node: Element): boolean => plainCaptionSizeField(node) && !hasCommentOrCdata(node);
        const point = (node: Element): boolean => !hasCommentOrCdata(node) && !node.children.length && /^[ \t\r\n]*$/.test(node.text)
            && Object.keys(node.attrs).sort().join(',') === 'x,y' && Object.values(node.attrs).every(token => finite(token));
        const repeatedLineStyles = children(content, 'lineStyle');
        if (repeatedLineStyles.length > 16 || repeatedLineStyles.some(node => !plain(node) || node.text !== repeatedLineStyles[0].text)) return undefined;
        for (const node of content.children) {
            if (!known.has(node.name)) return undefined;
            if (node.name === 'Segment') {
                if (Object.keys(node.attrs).length || hasCommentOrCdata(node) || !/^[ \t\r\n]*$/.test(node.text)
                    || new Set(node.children.map(field => field.name)).size !== node.children.length) return undefined;
                for (const field of node.children) {
                    if (['offset', 'off2'].includes(field.name)) { if (!point(field)) return undefined; }
                    else if (field.name === 'subtype') { if (!plain(field) || !['0', '1', '2', '3'].includes(field.text.trim())) return undefined; }
                    else if (field.name === 'autoplace') { if (!plain(field) || !['0', '1'].includes(field.text.trim())) return undefined; }
                    else if (field.name !== 'minDistance' || !plain(field) || !finite(field.text)) return undefined;
                }
            } else if (['offset', 'beginTextOffset', 'continueTextOffset', 'endTextOffset'].includes(node.name)) {
                if (!point(node)) return undefined;
            } else if (!plain(node) || node.text.length > 65536) return undefined;
            if (['linkedMain', 'dashGapLength', 'dashLineLength', 'hairpinHeight', 'visible', 'lineVisible'].includes(node.name)) {
                if (children(content, node.name).length !== 1 || (node.name === 'linkedMain' ? node.text !== ''
                    : ['visible', 'lineVisible'].includes(node.name) ? !['0', '1'].includes(node.text) : !finite(node.text, true))) return undefined;
            }
        }
        const crescendo = subtype[0].text === '2', name = field === 'beginText' ? crescendo ? 'hairpinCrescText' : 'hairpinDecrescText'
            : crescendo ? 'hairpinCrescContText' : 'hairpinDecrescContText';
        const encoded = primaryStyleField(name) ?? undefined, expected = encoded?.text ?? (field === 'beginText' ? crescendo ? 'cresc.' : 'dim.' : crescendo ? '(cresc.)' : '(dim.)');
        if (!value || value.length > 65536 || /[<>\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(value)
            || value !== expected || fact?.value !== value || fact.origin !== (encoded ? 'source-style' : 'native-default')
            || fact.source !== (encoded?.location ?? content.location)) return undefined;
        return size;
    };
    if (selection && scoreNode !== primaryNode) for (const style of [capture.styleRoot?.children[0], child(primaryNode, 'Style')]) if (style) {
        for (const name of ['defaultsVersion', 'usePre_3_6_defaults']) {
            const fields = children(style, name);
            if (fields.length) {
                const field = fields[0];
                if (field.children.length || Object.keys(field.attrs).length) refuse('native-view-style', 'Inherited native default selector must be a plain value.', field.location);
                hairpinDefaultSelectors.set(name, { field, repeated: fields.length > 1 });
                const previous = styleDefaultSelectors.findIndex(fact => fact.name === name); if (previous !== -1) styleDefaultSelectors.splice(previous, 1);
                styleDefaultSelectors.push({ source: field.location, name, value: field.text, origin: 'primary-default-selector' });
            }
        }
    }
    for (const style of selection && scoreNode !== primaryNode ? [child(scoreNode, 'Style')] : [capture.styleRoot?.children[0], child(scoreNode, 'Style')]) if (style) {
        // Inspect only; consuming/qualifying these fields belongs to the exact
        // inline SystemText owner. The existing Dynamic style alias stays intact.
        for (const name of ['tempoFontStyle', 'expressionFontStyle', 'systemFontStyle', 'systemTextFontStyle']) {
            const fields = children(style, name); if (fields.length) systemTextStyleFields.set(name, { field: fields[0], repeated: fields.length > 1 });
        }
        const dependencyFields = children(style, 'defaultFontSpatiumDependent');
        if (dependencyFields.length) defaultFontDependency = { field: dependencyFields[0], repeated: dependencyFields.length > 1 };
        for (const name of ['defaultsVersion', 'usePre_3_6_defaults']) {
            const fields = children(style, name); if (fields.length) hairpinDefaultSelectors.set(name, { field: fields[0], repeated: fields.length > 1 });
        }
        const concertPitch = child(style, 'concertPitch');
        if (concertPitch) {
            use(concertPitch);
            if (concertPitch.children.length) refuse('native-source-view', 'Primary pitch view requires one plain boolean style value.', concertPitch.location);
            sourceView = { source: concertPitch.location, concertPitch: integer(concertPitch.text.trim(), 0, 1, concertPitch.location) === 1, origin: 'source-style' };
        }
        for(const name of ['hopoShowOnStandardStaves','hopoShowOnTabStaves','hopoUpperCase','hopoShowAll','tempoSystemFlag']){
            const field=child(style,name);if(!field)continue;use(field);
            if(field.children.length)refuse('native-hopo-style','H/P source style requires a plain boolean.',field.location);
            styleValues.set(name,{source:field.location,origin:'source',value:String(integer(field.text.trim(),0,1,field.location))});
        }
        for (const name of ['palmMuteText', 'letRingText', 'palmMuteLineStyle', 'letRingLineStyle', 'whammyBarText', 'whammyBarLineStyle', 'pedalText', 'pedalHookText', 'pedalEndText', 'pedalRosetteEndText', 'glissandoText', 'glissandoType', 'glissandoShowText', 'hairpinCrescText', 'hairpinDecrescText', 'hairpinCrescContText', 'hairpinDecrescContText']) {
            const field = child(style, name); if (!field) continue;
            // Styled pedal captions keep their glyph and emphasis runs like authored ones.
            const runs: InlineRuns | undefined = name.startsWith('pedal') ? { values: [], emphasized: false, limits: new Set() } : undefined;
            const value = runs ? plainText(field, field.location, runs) : plainText(field);
            const styledRuns = runs && !runs.limits.size && (runs.emphasized || runs.values.some(run => run.textFontSize || run.script || run.symbolName || run.sourceFont || run.sourceText)) ? runs.values : undefined;
            styleValues.set(name, { value, origin: 'source', source: field.location, ...(styledRuns ? { runs: styledRuns } : {}),
                ...(['hairpinCrescText', 'hairpinDecrescText'].includes(name) ? { plainCaption: !field.children.length && !Object.keys(field.attrs).length && !field.text.includes('<') } : {}) });
        }
        const pedalFontStyle = child(style, 'pedalFontStyle');
        if (pedalFontStyle) {
            if (pedalFontStyle.children.length || Object.keys(pedalFontStyle.attrs).length) refuse('native-pedal-font-style', 'Pedal emphasis requires one plain native font-style bit field.', pedalFontStyle.location);
            use(pedalFontStyle); const value = integer(pedalFontStyle.text.trim(), 0, 15, pedalFontStyle.location);
            styleValues.set('pedalFontStyle', { value: String(value), origin: 'source', source: pedalFontStyle.location });
        }
        const pedalPlacement = child(style, 'pedalPlacement');
        if (pedalPlacement) {
            if (pedalPlacement.children.length || Object.keys(pedalPlacement.attrs).length) refuse('native-pedal-placement', 'Pedal style placement requires one plain native enum value.', pedalPlacement.location);
            use(pedalPlacement); const value = integer(pedalPlacement.text.trim(), 0, 1, pedalPlacement.location);
            styleValues.set('pedalPlacement', { value: value === 0 ? 'above' : 'below', origin: 'source', source: pedalPlacement.location });
        }
        // The pre-4.40 source view inherits these placement styles. Modern
        // voice-based layout has different precedence; its AUTO side is not
        // inferred from these retired preference fields.
        if (Number(capture.nativeVersion) < 4.4) for (const name of ['dynamicsPlacement', 'hairpinPlacement']) {
            const field = child(style, name); if (!field) continue;
            if (field.children.length || Object.keys(field.attrs).length) refuse('native-direction-style-placement', 'Placement style requires one plain native enum value.', field.location);
            use(field); const value = integer(field.text.trim(), 0, 1, field.location);
            styleValues.set(name, { source: field.location, value: value === 0 ? 'above' : 'below', origin: 'source' });
        }
        const dynamicStyleName = Number(capture.nativeVersion) < 4.1 ? 'dynamicsFontStyle' : 'expressionFontStyle';
        const dynamicFontStyle = child(style, dynamicStyleName);
        if (dynamicFontStyle) {
            if (dynamicFontStyle.children.length || Object.keys(dynamicFontStyle.attrs).length) refuse('native-dynamic-font-style', 'Dynamic emphasis requires one plain native font-style bit field.', dynamicFontStyle.location);
            use(dynamicFontStyle); styleValues.set('dynamicTextFontStyle', { source: dynamicFontStyle.location, value: String(integer(dynamicFontStyle.text.trim(), 0, 15, dynamicFontStyle.location)), origin: 'source' });
        }
        const hairpinFontStyle = child(style, 'hairpinFontStyle');
        if (hairpinFontStyle) {
            if (hairpinFontStyle.children.length || Object.keys(hairpinFontStyle.attrs).length) refuse('native-hairpin-font-style', 'Initial hairpin emphasis requires one plain native font-style bit field.', hairpinFontStyle.location);
            use(hairpinFontStyle); const value = integer(hairpinFontStyle.text.trim(), 0, Number(capture.nativeVersion) < 4 ? 7 : 15, hairpinFontStyle.location);
            styleValues.set('hairpinFontStyle', { source: hairpinFontStyle.location, value: String(value), origin: 'source' });
        }
        for (const [name, role] of [['showMeasureNumber', 'show'], ['measureNumberSystem', 'system'], ['showMeasureNumberOne', 'showFirst'], ['measureNumberInterval', 'interval']] as const) {
            const field = child(style, name); if (!field) continue;
            use(field); if (field.children.length) refuse('native-numbering-style', 'Numbering style requires one plain scalar source value.', field.location);
            const value = integer(field.text.trim(), role === 'interval' ? 1 : 0, role === 'interval' ? 10000 : 1, field.location);
            styleValues.set(name, { source: field.location, origin: 'source', value: String(value) });
            if (role === 'interval') measureNumbering.interval = { source: field.location, value };
            else measureNumbering[role] = { source: field.location, value: value === 1 };
        }
        const staffMag = child(style, 'smallStaffMag'); if (staffMag) {
            if (staffMag.children.length || Object.keys(staffMag.attrs).length) refuse('native-staff-size', 'Small-staff magnification must be one plain source style scalar.', staffMag.location);
            use(staffMag); const value = scalar(staffMag.text.trim(), staffMag, 4); if (value <= 0) refuse('native-staff-size', 'Staff magnification must be positive.', staffMag.location);
            styleValues.set('smallStaffMag', { source: staffMag.location, value: String(value), origin: 'source' });
        }
        for (const parity of ['odd', 'even']) for (const role of ['Header', 'Footer']) for (const side of ['L', 'C', 'R']) {
            const name = `${parity}${role}${side}`, field = child(style, name); if (!field) continue;
            if (field.children.length || Object.keys(field.attrs).length) refuse('native-page-text', 'Global page text requires a bounded inert string property.', field.location);
            pageTextFields.set(name, { source: field.location, raw: field.text, text: plainText(field) });
        }
        for (const name of ['showHeader', 'showFooter', 'headerFirstPage', 'footerFirstPage', 'headerOddEven', 'footerOddEven']) {
            const field = child(style, name); if (!field) continue;
            if (field.children.length || Object.keys(field.attrs).length) refuse('native-page-text', 'Global page visibility conditions require plain boolean source properties.', field.location);
            use(field); pageTextConditions.set(name, { source: field.location, value: integer(field.text.trim(), 0, 1, field.location) === 1, origin: 'source-style' });
        }
    }
    const systemTextInline = (owner: Element, caption: Element, printed: string): Pick<Direction, 'text' | 'textFontStyle' | 'textEmphasis' | 'textRuns'> | undefined => {
        const glyphs = !!nativeTextLoader && /[\uE048\uE1D7\uE1D9\uE1DB\uE1E7\uECA7]/u.test(printed) && systemTextGlyphShape(caption);
        const families = children(owner, 'family'), family = families[0];
        if (!nativeTextLoader || !caption.children.length || !printed
            || !(glyphs || isOrdinaryCaption(caption, printed) && ordinaryTempoShape(caption))
            || owner.children.some(field => ['textStyle', 'musicSymbolSize'].includes(field.name))
            || families.length && !(glyphs && families.length === 1 && !family.children.length && !Object.keys(family.attrs).length
                && !family.hasComment && !family.cdata && family.text === 'ScoreText' && owner.children.indexOf(family) < owner.children.indexOf(caption))) return undefined;
        const styles = children(owner, 'style'), fonts = children(owner, 'fontStyle');
        if (styles.length > 1 || fonts.length > 1) return undefined;
        // Only style carried scalar syntax here before the Tempo guard's
        // bookkeeping addition. Preserve other consumers' prior semantics.
        const plain = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length && (!glyphs || field.name !== 'style' || !field.hasComment && !field.cdata);
        const style = styles[0], current = nativeMajor === 4;
        const prefix = style && plain(style) ? nativeTextStylePrefix(style.text, capture.nativeVersion) : undefined;
        const role = style ? prefix === 'system' || prefix === 'tempo' || prefix === 'expression' ? prefix : undefined : 'system';
        if (!role) return undefined;
        const flags = owner.children.filter(field => ['bold', 'italic', 'underline', 'strike'].includes(field.name)), names = new Set<string>();
        if (!flags.every(field => {
            if (names.has(field.name)) return false; names.add(field.name);
            return (field.name !== 'strike' || current) && plain(field) && /^[01]$/.test(field.text.trim());
        })) return undefined;
        const font = fonts[0], max = current ? 15 : 7;
        if (font && (!plain(font) || !/^\d{1,2}$/.test(font.text.trim()) || Number(font.text.trim()) > max)) return undefined;
        const index = (field: Element): number => owner.children.indexOf(field);
        if (style && [...flags, ...fonts].some(field => index(field) < index(style))
            || font && flags.some(field => index(field) < index(font))) return undefined;
        // 4.40 renamed the System Text style fields; earlier files use systemFont*.
        const inherited = systemTextStyleFields.get(role === 'system' ? Number(capture.nativeVersion) >= 4.4 ? 'systemTextFontStyle' : 'systemFontStyle' : `${role}FontStyle`);
        if (inherited && (inherited.repeated || !plain(inherited.field) || !/^\d{1,2}$/.test(inherited.field.text.trim()) || Number(inherited.field.text.trim()) > max)) return undefined;
        const selectorsPlain = [...hairpinDefaultSelectors.values()].every(value => !value.repeated && plain(value.field));
        if (!selectorsPlain) return undefined;
        // System, Tempo and Expression start Plain, Bold and Italic in every
        // 3.x/4.x baseline, including the legacy and unrecognised selectors.
        if (style) use(style); if (font) use(font); else if (inherited) use(inherited.field);
        const textFontStyle: NonNullable<Direction['textFontStyle']> = font ? { source: font.location, value: Number(font.text.trim()), origin: 'source' }
            : inherited ? { source: inherited.field.location, value: Number(inherited.field.text.trim()), origin: 'source-style' }
                : { source: owner.location, value: role === 'tempo' ? 1 : role === 'expression' ? 2 : 0, origin: 'native-default' };
        const runs: InlineRuns = { values: [], emphasized: false, limits: new Set(), nameGlyphs: glyphs, ...(glyphs ? { systemTextGlyphs: true } : {}) };
        const text = plainText(caption, undefined, runs);
        if (!glyphs && text !== printed) refuse('native-system-text-inline', 'Qualified SystemText runs must retain the exact decoded caption.', caption.location);
        if (glyphs) performanceGap('native-system-text-glyph-appearance', caption.location,
            'Audited musical glyph names, literal source codepoints, persistent font context and ordered emphasis are retained. Native fonts, point sizes, glyph metrics and line wrapping remain separate standard presentation limits.');
        const textEmphasis = readTextEmphasis(owner);
        budget.add('markings', 1 + runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), caption.location);
        return { ...(glyphs ? { text } : {}), textFontStyle, ...(textEmphasis ? { textEmphasis } : {}), textRuns: runs.values };
    };
    const tempoUnderlineScript = (owner: Element, caption: Element, printed: string): Direction['textFontStyle'] => {
        // Every MuseScore 3/4 Tempo style starts Bold unless the saved style
        // changes it. Superscript metrics remain a separate limit.
        if (!nativeTextLoader || scoreNode !== primaryNode
            || Object.keys(owner.attrs).length || !printed || /[<>\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(printed)
            || owner.children.some(field => ['style', 'textStyle', 'fontStyle', 'family', 'fontFace', 'size', 'fontSize', 'sizeIsSpatiumDependent', 'musicSymbolSize', ...(nativeMajor === 3 ? ['strike'] : [])].includes(field.name))) return undefined;
        const plain = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length && !field.hasComment && !field.cdata;
        let nested = false;
        const shape = (node: Element, underlined = false): boolean => {
            // An empty size-only font token changes later run sizes; those
            // sizes are projected or reported as an inline appearance duty.
            if (node.name === 'font') return !node.hasComment && !node.cdata && !node.children.length && !node.text
                && Object.keys(node.attrs).join(',') === 'size' && /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(node.attrs.size) && Number(node.attrs.size) > 0 && Number(node.attrs.size) <= 1000;
            if (node.hasComment || node.cdata || Object.keys(node.attrs).length || !['text', 'u', 'sup'].includes(node.name)) return false;
            if (node.name === 'sup' && underlined) nested = true;
            return node.children.every(child => shape(child, underlined || node.name === 'u'));
        };
        if (!shape(caption) || !nested && !caption.children.some(node => node.name === 'sup' || node.name === 'font')) return undefined;
        for (const name of ['bold', 'italic', 'underline', ...(nativeMajor === 4 ? ['strike'] : [])]) {
            const fields = children(owner, name);
            if (fields.length > 1 || fields.length && (!plain(fields[0]) || !/^[01]$/.test(fields[0].text))) return undefined;
        }
        // Old per-flag style keys fold into the base in an order we do not model.
        if (['tempoFontBold', 'tempoFontItalic', 'tempoFontUnderline'].some(name => primaryStyleField(name) !== undefined)) return undefined;
        const base = primaryStyleField('tempoFontStyle');
        if (base === null || base && !plainFontStyle(base)) return undefined;
        if (base) { use(base); return { source: base.location, value: Number(base.text.trim()), origin: 'source-style' }; }
        return { source: owner.location, value: 1, origin: 'native-default' };
    };
    // Tempo and Rehearsal Mark styles start Bold in every MuseScore 3/4 build;
    // their face follows the file's baseline unless the saved style names one.
    const ordinaryTempoProfile = nativeTextLoader ? { fontStyle: 1, fontFamily: nativeDefaultFamily, familyField: 'tempoFontFace' } as const : undefined;
    const ordinaryTempoRoles = {
        tempo: { fontStyle: 1, fontFamily: nativeDefaultFamily, styleField: 'tempoFontStyle', familyField: 'tempoFontFace', prefix: 'tempo' },
        rehearsal: { fontStyle: 1, fontFamily: nativeDefaultFamily, styleField: 'rehearsalMarkFontStyle', familyField: 'rehearsalMarkFontFace', prefix: 'rehearsalMark' },
    } as const;
    const tempo352Role = (owner: Element, caption: Element, metronome = false) => {
        if (!ordinaryTempoProfile) return undefined;
        const selectors = children(owner, 'style'), selector = selectors[0];
        if (!selector) return ordinaryTempoRoles.tempo;
        // SUB_STYLE invokes TextBase::initTid before subsequent owner flags.
        // The musical instruction remains Tempo; only its text registry changes.
        if (metronome || selectors.length !== 1 || nativeTextStylePrefix(selector.text, capture.nativeVersion) !== 'rehearsalMark' || selector.children.length
            || Object.keys(selector.attrs).length || selector.hasComment || selector.cdata
            || owner.children.indexOf(selector) > owner.children.indexOf(caption)
            || owner.children.some(field => ['bold', 'italic', 'underline'].includes(field.name)
                && owner.children.indexOf(field) < owner.children.indexOf(selector))) return undefined;
        return { ...ordinaryTempoRoles.rehearsal, selector };
    };
    const tempo352Ordinary = (owner: Element, caption: Element, printed: string, metronome = false): Direction['textFontStyle'] => {
        // The examined producer saves main Style differences against its built-in
        // baseline. This local context does not widen the global TextBase loader.
        const role = tempo352Role(owner, caption, metronome);
        if (!role
            || scoreNode !== primaryNode || Object.keys(owner.attrs).length || !printed.trim()
            || /[<>]/.test(printed) || !metronome && /[♩𝅗𝅥𝅝♪\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(printed)) return undefined;
        const allowed = new Set(['tempo', 'followText', 'visible', 'size', 'offset', 'minDistance', 'placement', 'autoplace', ...(!metronome ? ['z', 'style'] : []), 'bold', 'italic', 'underline', ...(nativeMajor === 4 ? ['strike'] : []), 'text']);
        const names = new Set<string>();
        if (owner.children.some(field => { const duplicate = names.has(field.name); names.add(field.name); return duplicate || !allowed.has(field.name)
            || (metronome || !['tempo', 'visible', 'followText'].includes(field.name)) && (field.hasComment || field.cdata); })) return undefined;
        const plain = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length && !field.hasComment && !field.cdata
            && (role.prefix !== 'rehearsalMark' || !hasCommentOrCdata(field));
        let font = false, emphasis = false;
        const shape = (node: Element): boolean => {
            if (node.hasComment || node.cdata || node.text.includes('<') || metronome && /[♩·𝅗𝅥𝅝♪]/u.test(node.text)) return false;
            if (metronome && node.name === 'sym') return !node.children.length && !Object.keys(node.attrs).length
                && ['metNoteQuarterUp', 'metAugmentationDot'].includes(node.text);
            if (node.name === 'font') {
                font = true;
                return !node.children.length && /^[ \t\r\n]*$/.test(node.text)
                    && Object.keys(node.attrs).length === 1 && ['ScoreText', 'FreeSerif', 'Edwin'].includes(node.attrs.face);
            }
            const tokens = nativeMajor === 4 ? ['b', 'i', 'u', 's'] : ['b', 'i', 'u'];
            if (Object.keys(node.attrs).length || ![...tokens, 'text'].includes(node.name)) return false;
            emphasis ||= tokens.includes(node.name);
            return node.children.every(shape);
        };
        if (!shape(caption) || !metronome && (!font || !emphasis)) return undefined;
        for (const name of ['bold', 'italic', 'underline', ...(nativeMajor === 4 ? ['strike'] : [])]) {
            const fields = children(owner, name);
            if (fields.length > 1 || fields.length && (!plain(fields[0]) || !/^[01]$/.test(fields[0].text)
                || owner.children.indexOf(fields[0]) > owner.children.indexOf(caption))) return undefined;
        }
        // Old per-flag style keys are not modelled and stay held. MuseScore's
        // style loader skips other unknown keys, so they do not hold the caption.
        if (primaryNode.children.some(field => ['stylefile', 'styleFile', 'StyleFile', 'defaultStyle'].includes(field.name))
            || [`${role.prefix}FontBold`, `${role.prefix}FontItalic`, `${role.prefix}FontUnderline`].some(name => primaryStyleField(name) !== undefined)) return undefined;
        // The metronome route keeps its followed engine-rate context. Encoded
        // owner flags retain their old path.
        const followed = child(owner, 'followText'), engine = child(owner, 'tempo'), visible = child(owner, 'visible');
        if (metronome && (owner.hasComment || owner.cdata || !engine || !plain(engine) || visible && !plain(visible)
            || !followed || !plain(followed) || followed.text !== '1'
            || ['bold', 'italic', 'underline', 'strike'].some(name => children(owner, name).length))) return undefined;
        const base = primaryStyleField(role.styleField), bases = base ? [base] : [];
        if (base === null || base && !plainFontStyle(base)) return undefined;
        if ('selector' in role) {
            use(role.selector);
            performanceGap('native-tempo-rehearsal-style', role.selector.location,
                'The explicit Rehearsal Mark selector supplies its examined text registry while the musical instruction remains Tempo. Known built-in spatium-dependent size14 and square-frame defaults do not establish final size or layout; native size/frame requests and font metrics remain separate presentation limits.');
        }
        if (bases.length) { use(bases[0]); return { source: bases[0].location, value: Number(bases[0].text), origin: 'source-style' }; }
        return { source: owner.location, value: role.fontStyle, origin: 'native-default' };
    };
    const tempo352Family = (owner: Element, runs: TextRun[]): Direction['textFontFamily'] => {
        // Emphasis qualification alone does not prove absent family overrides.
        if (!ordinaryTempoProfile || scoreNode !== primaryNode) return undefined;
        const caption = children(owner, 'text')[0], role = caption && tempo352Role(owner, caption);
        if (!role) return undefined;
        const saved = primaryStyleField(role.familyField), fields = saved ? [saved] : [];
        const uncertain = saved === null || saved && saved.text.length > 65536
            || primaryNode.children.some(field => ['stylefile', 'styleFile', 'StyleFile', 'defaultStyle'].includes(field.name))
            || owner.children.some(field => ['family', 'fontFace', 'textStyle'].includes(field.name) || field.name === 'style' && !('selector' in role));
        if (uncertain) {
            unresolvedTempoFamilies.set(owner, saved?.location ?? owner.location);
            return undefined;
        }
        const field = fields[0], family: NonNullable<Direction['textFontFamily']> = field
            ? { source: field.location, value: field.text, origin: 'source-style' }
            : { source: owner.location, value: role.fontFamily, origin: 'native-default' };
        if (field) use(field);
        budget.add('markings', 1, family.source);
        performanceGap('native-tempo-font-family', family.source,
            'The examined saved Tempo family is retained with its encoded style or native-default origin. It is a rendering hint, without font availability or exact appearance resolution.', 'preserved');
        if (ordinaryFamily(family.value) && runs.some(run => !run.symbolName && run.sourceFont && !run.sourceFont.role)) {
            family.qualification = 'unrepresentable-inline-reset';
            performanceGap('native-tempo-family-reset', family.source,
                'The known initial family remains a source fact. Its base hint is withheld because the caption enters symbolic ScoreText ordinary text, for which MusicXML cannot encode a return to an unresolved family. Later independently qualified inline hints retain their existing projection.');
        } else if (!ordinaryFamily(family.value)) performanceGap('native-text-family-projection', family.source,
            'The exact saved family request remains located. Empty, symbolic or unrepresentable family-list values do not establish an ordinary standard font hint; an empty request is not replaced by a native default.');
        return family;
    };
    // One selected resource owns both constructor masks. Search its global
    // selector once; each source owner retains its own property read order.
    const sourceText362Context = (() => {
        // Every 3.x/4.x TextBase reads these owner properties in order. Whole-style
        // resources and unmodelled old per-flag keys stay unresolved; MuseScore's
        // style loader skips other unknown keys.
        if (!nativeTextLoader || scoreNode !== primaryNode) return undefined;
        const aliases = ['tempoFontBold', 'tempoFontItalic', 'tempoFontUnderline'];
        if ([root, primaryNode].some(node => node.children.some(field => ['stylefile', 'styleFile', 'StyleFile', 'styleFileName', 'defaultStyle'].includes(field.name)))
            || aliases.some(name => primaryStyleField(name) !== undefined)) return undefined;
        return { legacy: legacyStyleBaseline, plain: plainStyleField };
    })();
    // Frame properties are independent presentation facts read by the shared
    // text presentation; they do not change the caption's emphasis mask.
    const frameFields = ['frameType', 'frameWidth', 'framePadding', 'frameRound', 'frameFgColor', 'frameBgColor'];
    const sourceText362Mask = (owner: Element, caption: Element, kind: 'Tempo' | 'Dynamic'): Direction['textFontStyle'] => {
        const context = sourceText362Context;
        if (!context || Object.keys(owner.attrs).length || hasCommentOrCdata(owner) || !/^[ \t\r\n]*$/.test(owner.text)) return undefined;
        const names = owner.children.map(node => node.name), allowed = new Set(['text', 'visible', 'fontStyle', 'bold', 'italic', 'underline', 'align', 'offset',
            'placement', 'minDistance', 'autoplace', 'z', 'linkedMain', 'size', ...(nativeMajor === 4 ? ['strike'] : []), ...(kind === 'Tempo' ? ['tempo', 'followText', 'family'] : ['subtype', 'velocity', 'dynType', 'veloChange', 'veloChangeSpeed', 'play', ...frameFields])]);
        if (new Set(names).size !== names.length || names.some(name => !allowed.has(name)) || Object.keys(caption.attrs).length || hasCommentOrCdata(caption)) return undefined;
        for (const field of owner.children) {
            if (field === caption) continue;
            if (field.name === 'offset') {
                if (field.children.length || !/^[ \t\r\n]*$/.test(field.text) || Object.keys(field.attrs).sort().join(',') !== 'x,y'
                    || Object.values(field.attrs).some(value => !/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(value) || !Number.isFinite(Number(value)))) return undefined;
            } else if (field.name === 'frameFgColor' || field.name === 'frameBgColor') {
                if (field.children.length || !/^[ \t\r\n]*$/.test(field.text) || !['a,b,g,r', 'b,g,r'].includes(Object.keys(field.attrs).sort().join(','))
                    || Object.values(field.attrs).some(value => !/^\d+$/.test(value) || Number(value) > 255)) return undefined;
            } else if (!context.plain(field)) return undefined;
            if (field.name === 'linkedMain' && (field.text !== '' || owner.children.indexOf(field) > owner.children.indexOf(caption))) return undefined;
            if (['visible', 'bold', 'italic', 'underline', 'strike', 'play', 'followText', 'autoplace'].includes(field.name) && !/^[01]$/.test(field.text)) return undefined;
        }
        const captionShape = (node: Element): boolean => {
            if (hasCommentOrCdata(node) || node.text.includes('<')) return false;
            // A face or point-size change leaves the emphasis mask unchanged;
            // the ordered runs keep the size with its own source unit authority.
            if (node.name === 'font') return !node.children.length && /^[ \t\r\n]*$/.test(node.text) && Object.keys(node.attrs).length === 1
                && (['ScoreText', 'FreeSerif', 'Edwin'].includes(node.attrs.face) || /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(node.attrs.size ?? '') && Number(node.attrs.size) > 0 && Number(node.attrs.size) <= 10000);
            if (node.name === 'sym') return !node.children.length && !Object.keys(node.attrs).length
                && (kind === 'Tempo' ? ['metNoteQuarterUp', 'metAugmentationDot'] : ['dynamicPiano', 'dynamicForte', 'dynamicMezzo', 'dynamicSforzando']).includes(node.text);
            return !Object.keys(node.attrs).length && ['text', 'b', 'i', 'u', ...(nativeMajor === 4 ? ['s'] : [])].includes(node.name) && node.children.every(captionShape);
        };
        if (!captionShape(caption)) return undefined;
        const base = child(owner, 'fontStyle'), flags = owner.children.filter(node => ['bold', 'italic', 'underline', 'strike'].includes(node.name));
        if (base && (!context.plain(base) || !plainFontStyle(base) || owner.children.indexOf(base) > owner.children.indexOf(caption))
            || flags.some(node => !context.plain(node) || !/^[01]$/.test(node.text) || owner.children.indexOf(node) > owner.children.indexOf(caption)
                || base && owner.children.indexOf(node) < owner.children.indexOf(base))) return undefined;
        const field = primaryStyleField(kind === 'Tempo' ? 'tempoFontStyle' : `${dynamicStylePrefix}FontStyle`);
        if (field === null || field && !plainFontStyle(field)) return undefined;
        if (base) { use(base); return { source: base.location, value: Number(base.text), origin: 'source' }; }
        if (field) { use(field); return { source: field.location, value: Number(field.text), origin: 'source-style' }; }
        return { source: owner.location, value: kind === 'Tempo' ? 1 : 2, origin: 'native-default' };
    };
    // Saved profile/style authority is invariant for this selected view. Inspect
    // it once rather than multiplying a Style walk by every Dynamic owner.
    const richDynamicDefaults = ((): { family: string; linkedMain: boolean; familyStyle?: Element; sizeStyle?: Element; maskStyle?: Element } | undefined => {
        // Dynamics start Italic in every 3.x/4.x build. From 4.10 their text
        // style reads the expression fields; the face follows the file baseline.
        if (!sourceText362Context) return undefined;
        const familyStyle = primaryStyleField(`${dynamicStylePrefix}FontFace`), sizeStyle = primaryStyleField(`${dynamicStylePrefix}FontSize`),
            maskStyle = primaryStyleField(`${dynamicStylePrefix}FontStyle`);
        if (familyStyle === null || sizeStyle === null || maskStyle === null || maskStyle && !plainFontStyle(maskStyle)
            || sizeStyle && !(/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(sizeStyle.text.trim()) && Number(sizeStyle.text) > 0 && Number(sizeStyle.text) <= 1000)) return undefined;
        // 3.6 and later save the linked-main marker and Dynamic subtypes.
        return { family: familyStyle?.text ?? nativeDefaultFamily, linkedMain: capture.nativeVersion !== '3.01',
            ...(familyStyle ? { familyStyle } : {}), ...(sizeStyle ? { sizeStyle } : {}), ...(maskStyle ? { maskStyle } : {}) };
    })();
    const richDynamic = (owner: Element, caption: Element, literal: string): boolean => {
        if (!richDynamicDefaults || Object.keys(owner.attrs).length || hasCommentOrCdata(owner)) return false;
        const names = new Set<string>(), allowed = new Set(['subtype', 'velocity', 'dynType', 'veloChange', 'veloChangeSpeed', 'play', 'visible', 'offset', 'minDistance', 'placement', 'autoplace', 'z', 'align', 'fontStyle', 'bold', 'italic', 'underline', 'text']);
        if (richDynamicDefaults.linkedMain) allowed.add('linkedMain');
        // Own drawing/family properties need only the qualified saved Dynamic
        // defaults above; those already bind whole-input default selectors.
        const nominalProfile = richDynamicDefaults.linkedMain;
        const drawings = ['family', 'frameType', 'framePadding', 'frameFgColor', 'frameBgColor'];
        if (nominalProfile) for (const name of drawings) allowed.add(name);
        if (owner.children.some(field => { const duplicate = names.has(field.name); names.add(field.name); return duplicate || !allowed.has(field.name) || hasCommentOrCdata(field); })) return false;
        const plain = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length && !hasCommentOrCdata(field);
        if (owner.children.some(field => drawings.includes(field.name))) {
            const music = primaryStyleField('musicalTextFont');
            if (music === null || music && music.text !== 'Leland Text') return false;
            for (const field of owner.children) {
                if (field.name === 'family' && (!plain(field) || !['FreeSerif', 'Edwin'].includes(field.text))) return false;
                if (field.name === 'frameType' && (!plain(field) || !/^[012]$/.test(field.text))) return false;
                if (field.name === 'framePadding' && (!plain(field) || !/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(field.text)
                    || !Number.isFinite(Number(field.text)) || Number(field.text) > 100)) return false;
                if (['frameFgColor', 'frameBgColor'].includes(field.name) && (field.children.length || field.text.trim()
                    || Object.keys(field.attrs).sort().join(',') !== 'a,b,g,r'
                    || Object.values(field.attrs).some(value => !/^(?:0|[1-9]\d{0,2})$/.test(value) || Number(value) > 255))) return false;
            }
        }
        const marker = child(owner, 'linkedMain');
        if (marker && (!plain(marker) || marker.text !== '' || owner.children.indexOf(marker) > owner.children.indexOf(caption))) return false;
        if (richDynamicDefaults.linkedMain && child(owner, 'subtype')?.text !== 'other-dynamics') return false;
        if (richDynamicDefaults.linkedMain && owner.children.indexOf(child(owner, 'subtype')!) > owner.children.indexOf(caption)) return false;
        for (const name of ['subtype', 'velocity', 'dynType', 'veloChange', 'veloChangeSpeed', 'play', 'visible', 'fontStyle', 'bold', 'italic', 'underline']) {
            const field = child(owner, name); if (field && (!plain(field) || ['fontStyle', 'bold', 'italic', 'underline'].includes(name)
                && (owner.children.indexOf(field) > owner.children.indexOf(caption) || !(name === 'fontStyle' ? plainFontStyle(field) : /^[01]$/.test(field.text))))) return false;
        }
        const base = child(owner, 'fontStyle');
        if (base && ['bold', 'italic', 'underline'].some(name => { const flag = child(owner, name); return flag && owner.children.indexOf(flag) < owner.children.indexOf(base); })) return false;
        const offset = child(owner, 'offset');
        if (offset && (offset.children.length || offset.text.trim() || Object.keys(offset.attrs).length !== 2
            || !['x', 'y'].every(name => Object.hasOwn(offset.attrs, name) && /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/.test(offset.attrs[name]) && Number.isFinite(Number(offset.attrs[name]))))) return false;
        if (['minDistance', 'placement', 'autoplace', 'z', 'align'].some(name => { const field = child(owner, name); return field && !plain(field); })) return false;
        let glyph = false, face: string | undefined, lastGlyph = '', groupLength = 0;
        const namedGlyph = (name: string): boolean => { glyph = true; groupLength = name === lastGlyph ? groupLength + 1 : 1; lastGlyph = name; return groupLength <= 6; };
        const characters = (value: string): boolean => {
            for (const c of value) {
                if (/[\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(c)) {
                    if (!['\uE520', '\uE522'].includes(c) || face !== 'ScoreText' || !namedGlyph(c === '\uE520' ? 'dynamicPiano' : 'dynamicForte')) return false;
                } else { lastGlyph = ''; groupLength = 0; }
            }
            return true;
        };
        const shape = (node: Element): boolean => {
            if (hasCommentOrCdata(node) || node.text.includes('<')) return false;
            if (node.name === 'sym') return !node.children.length && !Object.keys(node.attrs).length
                && ['dynamicPiano', 'dynamicForte', ...(richDynamicDefaults.linkedMain ? ['dynamicMezzo', 'dynamicSforzando'] : [])].includes(node.text) && namedGlyph(node.text);
            if (node.name === 'font') {
                face = node.attrs.face;
                return !node.children.length && /^[ \t\r\n]*$/.test(node.text) && Object.keys(node.attrs).length === 1
                    && ['ScoreText', 'FreeSerif', 'Edwin'].includes(face);
            }
            if (Object.keys(node.attrs).length || !['text', 'b', 'i', 'u'].includes(node.name)) return false;
            let at = 0;
            for (let index = 0; index < node.children.length; index++) {
                const end = node.textOrder?.[index]?.afterText ?? node.text.length;
                const nested = node.children[index];
                // Native dynList spells mf/sf with these exact adjacent sym
                // pairs. A lone m/s or intervening text keeps its prior route.
                if (nested.name === 'sym' && ['dynamicMezzo', 'dynamicSforzando'].includes(nested.text)
                    && (node.children[index + 1]?.name !== 'sym' || node.children[index + 1].text !== 'dynamicForte'
                        || (node.textOrder?.[index + 1]?.afterText ?? node.text.length) !== end)) return false;
                if (!characters(node.text.slice(at, end)) || !shape(node.children[index])) return false;
                at = end;
            }
            return characters(node.text.slice(at));
        };
        return !!literal.trim() && shape(caption) && glyph;
    };
    // Named glyphs identify the printed sign independently of the text style;
    // only a whole-style resource leaves the saved context unresolved.
    const namedDynamicStyle = !!nativeTextLoader && scoreNode === primaryNode
        && ![root, primaryNode].some(scope => scope.children.some(field => ['stylefile', 'styleFile', 'StyleFile', 'defaultStyle', 'TextStyle', 'textStyle'].includes(field.name)));
    const namedDynamicSign = (owner: Element, caption: Element, literal: string): boolean => {
        // Actual named glyphs identify the printed sign independently of the
        // surrounding text style/default resource. Keep richer run facts intact.
        if (!namedDynamicStyle || Object.keys(owner.attrs).length
            || owner.text.trim() || hasCommentOrCdata(owner) || Object.keys(caption.attrs).length
            || caption.text !== '' || hasCommentOrCdata(caption) || !caption.children.length || caption.children.length > 6) return false;
        const subtypes = children(owner, 'subtype'), captions = children(owner, 'text'), subtype = subtypes[0];
        if (subtypes.length !== 1 || captions.length !== 1 || captions[0] !== caption || !subtype
            || subtype.text !== 'other-dynamics' || subtype.children.length || Object.keys(subtype.attrs).length
            || hasCommentOrCdata(subtype) || owner.children.indexOf(subtype) > owner.children.indexOf(caption)
            || owner.children.some(field => ['tick', 'track', 'voice', 'style', 'subStyle', 'bold', 'italic', 'underline', 'strike', 'family'].includes(field.name)
                || /^(?:font|Font|textFont|dynamicFont|dynamicsFont)/.test(field.name))) return false;
        const glyphs: Record<string, string> = { dynamicPiano: 'p', dynamicMezzo: 'm', dynamicForte: 'f',
            dynamicSforzando: 's', dynamicRinforzando: 'r', dynamicZ: 'z', dynamicNiente: 'n' };
        let sign = '';
        for (const [index, node] of caption.children.entries()) {
            if (node.name !== 'sym' || node.children.length || Object.keys(node.attrs).length || hasCommentOrCdata(node)
                || !Object.hasOwn(glyphs, node.text) || node.location.member !== caption.location.member
                || node.location.path !== `${caption.location.path}/sym[${index + 1}]`) return false;
            sign += glyphs[node.text];
        }
        // Exact native table sequences that have a standard MusicXML sign.
        return sign === literal && /^(?:p{1,6}|f{1,6}|mp|mf|fp|pf|sf|sfz|sffz|sfp|sfpp|rfz|rf|fz|n)$/.test(sign);
    };
    const pedalDefault = (name: string): NonNullable<MusicalRelation['pedalState']>['beginText'] => {
        // The admitted pre-4.20 readers clear absent labels instead of inheriting
        // the later pedal-text styles. This is a versioned reading default.
        if (Number(capture.nativeVersion) < 4.2) return { value: '', origin: 'native-default', source: root.location };
        const style = styleValues.get(name);
        return style ? { ...style, origin: 'source-style' } : { value: name === 'pedalText' ? 'Ped.' : name === 'pedalRosetteEndText' ? '*' : '', origin: 'native-default', source: root.location };
    };
    for (const c of root.children) if (['programVersion', 'programRevision'].includes(c.name)) use(c);
    const lastEid = child(root, 'LastEID'); if (lastEid) {
        if (lastEid.children.length || Object.keys(lastEid.attrs).length || !/^\d{1,10}$/.test(lastEid.text.trim()) || Number(lastEid.text.trim()) > 2_147_483_647)
            refuse('native-editor-identity', 'Legacy editor identity state requires a nonnegative signed-32-bit scalar.', lastEid.location);
        omit(lastEid, 'native-editor-identity-state');
    }
    let title = 'Untitled';
    const metadata: NonNullable<MusicalScore['metadata']> = [];
    const credits: NonNullable<MusicalScore['credits']> = [];
    // The User-1/User-2 size, unit and alignment fields keep their names in
    // every 3.x/4.x style. Nested selected views do not inherit this authority.
    const userFrameStyles = new Map<string, Map<string, Element>>();
    const plainUserField = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length && !field.hasComment && !field.cdata;
    if (nativeTextLoader && scoreNode === primaryNode) {
        for (const prefix of ['user1', 'user2']) {
            const values = new Map<string, Element>();
            for (const property of ['FontSize', 'FontSpatiumDependent', 'Align']) {
                const field = primaryStyleField(prefix + property);
                if (field) values.set(property, field);
            }
            userFrameStyles.set(prefix, values);
        }
    }
    const sourceImages: NonNullable<MusicalScore['sourceImages']> = [];
    const imageGlyphs:{owner:ImageOwner;glyph:GlyphFact}[]=[];
    const readImage=createNativeImageReader({nativeVersion:capture.nativeVersion,members:capture.members,use,consume:node=>used.add(node),get,scalar,decoration,mark:source=>budget.add('markings',1,source),gap:performanceGap});
    const readImageTree=(node:Element,owner:ImageOwner,scale?:NativeTextScaleContext):void=>{
        const trackField=child(node,'track');if(trackField){const track=integer(trackField.text.trim(),0,1023,trackField.location),target=staffOwners.get(Math.floor(track/4)+1);if(!target)refuse('native-image-track','Explicit image track addresses an undeclared source staff.',trackField.location);owner={...owner,placement:{source:trackField.location,track,partId:target!.part.id,staff:target!.definition.number,voiceId:String((target!.definition.number-1)*4+track%4+1)}};}
        const image=readImage(node,owner);if(image)sourceImages.push(image);
        const hidden=owner.hiddenSource??(child(node,'visible')?.text.trim()==='0'?child(node,'visible')!.location:undefined);
        for(const nested of node.children.filter(c=>['Symbol','FSymbol'].includes(c.name))){for(const glyph of readGlyphs(nested,node.location.path,!!hidden,[],scale))imageGlyphs.push({owner,glyph});readNestedImages(nested,owner,hidden,scale);}
        for(const nested of children(node,'Image'))readImageTree(nested,{...owner,...(owner.attachment?{attachment:{...owner.attachment,parentSource:node.location}}:{}),...(hidden?{hiddenSource:hidden}:{})},scale);
    };
    const readNestedImages=(node:Element,owner:ImageOwner,hidden?:Element['location'],scale?:NativeTextScaleContext):void=>{
        const inherited=hidden??(child(node,'visible')?.text.trim()==='0'?child(node,'visible')!.location:undefined);
        for(const nested of children(node,'Image'))readImageTree(nested,{...owner,...(owner.attachment?{attachment:{...owner.attachment,parentSource:node.location}}:{}),...(inherited?{hiddenSource:inherited}:{})},scale);
        for(const nested of node.children.filter(c=>['Symbol','FSymbol'].includes(c.name)))readNestedImages(nested,owner,inherited,scale);
    };
    const readAttachedImages=(owner:Element,context:{partId:string;measure:number;position:Rational;staff:number;voiceId?:string;eventId?:string;noteId?:string;sourceKind:NonNullable<NonNullable<MusicalScore['sourceImages']>[number]['attachment']>['sourceKind'];printObject?:boolean},scale?:NativeTextScaleContext):void=>{
        const {partId,staff,printObject,...attachment}=context;
        const identity:ImageOwner={partId,staff,attachment:{source:owner.location,...attachment},...(printObject===false?{hiddenSource:owner.location}:{})};
        if(owner.name==='Image')readImageTree(owner,identity,scale);else if(['Symbol','FSymbol'].includes(owner.name))readNestedImages(owner,identity,undefined,scale);else {
            for(const image of children(owner,'Image'))readImageTree(image,identity,scale);
            for(const symbol of owner.children.filter(c=>['Symbol','FSymbol'].includes(c.name)))readNestedImages(symbol,identity,undefined,scale);
        }
    };

    for (const c of scoreNode.children) {
        if (c.name === 'metaTag') {
            use(c); budget.add('markings', 1, c.location);
            if (!c.attrs.name || c.attrs.name.length > 256 || c.children.length) refuse('native-metadata', 'Metadata needs a bounded explicit name and plain text value.', c.location);
            metadata.push({ source: c.location, name: c.attrs.name, value: c.text });
            if (c.attrs.name === 'workTitle' && c.text) title = c.text;
        }
        else if (['Division', 'LayerTag', 'currentLayer', 'showInvisible', 'showUnprintable', 'showFrames', 'showMargins', 'open', 'pageNumberOffset', 'layoutMode', 'Order', 'Synthesizer', 'Audio', 'playMode', 'excerpts'].includes(c.name)) omit(c, 'native-editor-and-playback-settings');
        else if (c.name === 'Style') omit(c, 'native-style-retained-not-engraved');
        else if (selection && c.name === 'name') { use(c); if (c.children.length || Object.keys(c.attrs).length || c.text.length > 65536) refuse('native-view-field', 'Expected a bounded plain source view name.', c.location); }
    }
    decoration(scoreNode);
    const sourcePageText: NonNullable<MusicalScore['sourcePageText']> = [], metaByName = new Map(metadata.map(fact => [fact.name, fact]));
    for (const [field, value] of pageTextFields) {
        budget.add('markings', 1, value.source); const role = field.includes('Header') ? 'header' as const : 'footer' as const;
        const substitutions: NonNullable<MusicalScore['sourcePageText']>[number]['substitutions'] = []; let literal = '', offset = 0, text = '';
        for (const match of value.text.matchAll(/\$:([^:]{1,256}):|\$:|\$./g)) {
            const before = value.text.slice(offset, match.index); literal += before; text += before; offset = match.index! + match[0].length;
            const token = match[0], key = match[1] ?? (['$C', '$c'].includes(token) ? 'copyright' : ['$i', '$I'].includes(token) ? 'partName' : undefined);
            if (key !== undefined) { const meta = metaByName.get(key); substitutions.push({ token, role: 'metadata', ...(meta ? { source: meta.source, value: meta.value } : { value: '' }) }); text += meta?.value ?? ''; }
            else if (token === '$:') { performanceGap('native-page-text-macro-repair', value.source, 'The source unterminated metadata introducer has no closing tag. Its native rule removes only the introducer and preserves the literal remainder; the original page string remains exposed.', 'inferred'); }
            else if (['$p', '$P', '$N', '$n'].includes(token)) substitutions.push({ token, role: 'pagination' });
            else if (token === '$$') { text += '$'; literal += '$'; }
            else if (token === '$v' || token === '$r') { const native = token === '$v' ? capture.producerVersion : capture.producerRevision; substitutions.push({ token, role: 'source-origin', value: native }); text += native; }
            else if (['$f', '$F', '$d', '$D', '$m', '$M'].includes(token)) { substitutions.push({ token, role: 'unresolved' }); performanceGap('native-page-text-macro', value.source, 'The original global page macro and useful literal remainder remain exposed. An environment/date/file-dependent value is not fabricated or resolved from the host filesystem; exact page content is unresolved.'); }
            else { substitutions.push({ token, role: 'literal', value: token }); text += token; literal += token; }
        }
        const remainder = value.text.slice(offset); literal += remainder; text += remainder;
        const paginationSeparatorsOnly = substitutions.length > 0 && substitutions.every(fact => fact.role === 'pagination') && /^[\s/.,:;|()[\]{}\-–—]*$/.test(literal);
        const condition = (name: string, fallback: boolean) => pageTextConditions.get(name) ?? { value: fallback, origin: 'native-default' as const };
        sourcePageText.push({ source: value.source, field, raw: value.raw, text, role, parity: field.startsWith('odd') ? 'odd' : 'even', side: field.endsWith('L') ? 'left' : field.endsWith('R') ? 'right' : 'center',
            conditions: { enabled: condition(role === 'header' ? 'showHeader' : 'showFooter', true), firstPage: condition(`${role}FirstPage`, role === 'footer'), oddEven: condition(`${role}OddEven`, true) }, substitutions,
            projection: paginationSeparatorsOnly ? 'pagination-only' : substitutions.some(fact => fact.role === 'unresolved') ? 'unresolved' : literal.trim() ? 'generic-credit' : substitutions.some(fact => fact.role === 'metadata' || fact.role === 'source-origin') ? 'metadata-only' : 'pagination-only' });
        if (literal.trim() && !paginationSeparatorsOnly) performanceGap('native-page-text-presentation', value.source, 'Useful global header/footer text is preserved as an ordinary generic credit, independent of descriptive metadata. Located original role, side, odd/even and first-page visibility conditions remain exposed; source pagination and exact page layout are not reproduced.');
    }
    // All non-score members remain byte-exact. No asset, plugin or executable input is opened.
    for (const member of capture.members) if (member.name !== capture.primaryMember) findings.push({ disposition: 'omitted', code: 'native-member', message: member.name === capture.styleRoot?.location.member ? 'Inert score style defaults are decoded only for verified musical rules; the whole style remains byte-exact and its engraving is not reproduced.' : 'Member retained byte-exact in native capture; not loaded/executed or reproduced in MusicXML.', location: { member: member.name }, fact: { sha256: member.sha256 } });
    const division = int(scoreNode, 'Division', 1, 65536, 480);
    const trillAttachmentProfile = sourceHasTrill && trillCarrierProfile(root, primaryNode, scoreNode, division);
    const trillSourceBars = new Map<MusicalPart, Map<number, Map<number, {bar: SourceTrillBar; safe: boolean}>>>();
    const parts: MusicalPart[] = [], partIdentities = new Set<string>(), staffOwners = new Map<number, { part: MusicalPart; definition: StaffFact }>();
    const sourceObjectLinks: NonNullable<MusicalScore['sourceObjectLinks']> = [], objectPeers: { globalStaff: number; fact: NonNullable<MusicalScore['sourceObjectLinks']>[number]['owner'] }[] = [];
    const readObjectLink = (e: Element, part: MusicalPart, staff: number, globalStaff: number, measure: number, voice: number, position: Rational): void => {
        if (e.name !== 'BarLine' && e.name !== 'Tuplet') return;
        budget.add('timelines', 1, e.location);
        const eid = get(e, 'eid'); if (eid.length > 256) refuse('native-identity-budget', 'Linked source object identity exceeds its field profile.', e.location);
        const owner = { source: e.location, kind: e.name as 'BarLine' | 'Tuplet', partId: part.id, staff, measure, position, voiceId: String((staff - 1) * 4 + voice + 1), ...(eid ? { sourceEid: eid } : {}) };
        objectPeers.push({ globalStaff, fact: owner }); const linked = child(e, 'linked'), to = child(e, 'linkedTo');
        if (!linked && !to) return;
        if (linked && to) refuse('native-object-link', 'Conflicting legacy/current object reference forms are not resolved by encounter order.', e.location);
        const fact: NonNullable<MusicalScore['sourceObjectLinks']>[number] = { source: (linked ?? to)!.location, owner, status: 'unresolved-source-reference' };
        if (to) {
            if (to.children.length || Object.keys(to.attrs).length || !to.text.trim() || to.text.length > 256) refuse('native-object-link', 'Linked object target must be a bounded plain editor identity.', to.location);
            use(to); fact.targetEid = { source: to.location, value: to.text.trim() };
        } else {
            if (linked!.text.trim() || Object.keys(linked!.attrs).length || linked!.children.some(child => child.name !== 'location')) refuse('native-object-link', 'Uninterpreted linked source-object reference.', linked!.location);
            use(linked!); const location = child(linked!, 'location');
            if (location) {
                if (location.text.trim() || Object.keys(location.attrs).length || location.children.some(child => child.name !== 'staves')) refuse('native-object-link', 'Linked object coordinates require an explicitly exercised source role.', location.location);
                use(location); const staves = child(location, 'staves', true)!;
                if (staves.children.length || Object.keys(staves.attrs).length) refuse('native-object-link', 'Relative staff target must be a plain source scalar.', staves.location);
                use(staves); fact.relativeStaff = { source: staves.location, value: integer(staves.text.trim(), -255, 255, staves.location) };
            }
        }
        sourceObjectLinks.push(fact);
    };
    const drumsByPart = new Map<MusicalPart, Map<number, NonNullable<MusicalPart['percussionInstruments']>[number]>>();
    let sequentialStaff = 1;
    for (const p of children(scoreNode, 'Part')) {
        use(p);
        const instrument = child(p, 'Instrument', true)!; use(instrument);
        const partName = child(p, 'trackName'), instrumentName = child(instrument, 'longName'), instrumentShortName = child(instrument, 'shortName'), instrumentTrackName = child(instrument, 'trackName');
        const names: NonNullable<MusicalPart['names']> = {};
        for (const [role, node] of [['track', partName], ['long', instrumentName], ['short', instrumentShortName], ['instrumentTrack', instrumentTrackName]] as const) if (node) { budget.add('markings', 1, node.location); names[role] = { source: node.location, value: plainText(node) }; }
        const name = names.long?.value || names.track?.value || names.instrumentTrack?.value || 'Part';
        const encodedInstrumentId = child(instrument, 'instrumentId'), instrumentSound = get(instrument, 'instrumentId');
        const identifier = instrumentSound || instrument.attrs.id || name;
        const transpose = { diatonic: int(instrument, 'transposeDiatonic', -35, 35, 0), chromatic: int(instrument, 'transposeChromatic', -60, 60, 0) };
        const channels = children(instrument, 'Channel');
        let midiProgram: number | undefined;
        const playbackChannels: NonNullable<MusicalPart['playbackChannels']> = [];
        budget.add('markings', channels.length, instrument.location);
        for (let i = 0; i < channels.length; i++) {
            const c = channels[i]; use(c);
            const fact: NonNullable<MusicalPart['playbackChannels']>[number] = { source: c.location, ...(c.attrs.name ? { name: c.attrs.name } : {}), controllers: [], volume: { value: 100, origin: 'native-default' }, pan: { value: 64, origin: 'native-default' } };
            const program = child(c, 'program');
            if (program) { use(program); fact.program = integer(program.attrs.value ?? program.text.trim(), -1, 127, program.location); if (fact.program === -1) delete fact.program; if (!i) midiProgram = fact.program; }
            const controllers = children(c, 'controller'); budget.add('markings', controllers.length, c.location);
            for (const setting of controllers) {
                use(setting); const number = integer(setting.attrs.ctrl ?? '0', 0, 127, setting.location), value = integer(setting.attrs.value ?? '0', 0, 127, setting.location);
                if (setting.children.length || setting.text.trim()) refuse('native-midi-controller', 'Static controller must have an empty bounded numeric payload.', setting.location);
                fact.controllers.push({ source: setting.location, number, value });
                if (number === 7) fact.volume = { value, origin: 'source' };
                else if (number === 10) fact.pan = { value, origin: 'source' };
                else if (number === 0) fact.bank = value * 128 + (fact.bank ?? 0) % 128;
                else if (number === 32) fact.bank = Math.floor((fact.bank ?? 0) / 128) * 128 + value;
                else performanceGap('native-midi-controller', setting.location, 'This authored MIDI controller is retained as a located playback fact; MusicXML has no identical static controller element. It is not executed or silently converted to another control.');
            }
            for (const field of ['midiChannel', 'midiPort'] as const) { const value = get(c, field); if (value) { const number = integer(value, -1, field === 'midiChannel' ? 15 : 65535, c.location); if (number >= 0) fact[field] = number; } }
            for (const field of ['mute', 'solo'] as const) { const value = get(c, field); if (value) { fact[field] = integer(value, 0, 1, c.location) === 1; if (fact[field]) performanceGap('native-channel-audibility', c.location, 'The authored channel mute/solo setting is retained independently; XML instrument playback does not promise native mixer routing or solo arbitration.'); } }
            const synti = get(c, 'synti'); if (synti) fact.synthesizer = synti;
            const color = get(c, 'color'); if (color) performanceGap('native-channel-color', c.location, 'The source mixer channel color remains in the byte-exact source; it does not alter musical notation.');
            for (const setting of c.children) if (setting.name === 'Articulation') omit(setting, 'native-playback-articulation-template');
            playbackChannels.push(fact);
            if (i) performanceGap('native-alternate-channel', c.location, 'Alternate named playback channel and controls remain located source facts; dynamic channel selection requires consumer routing and is not collapsed into the primary instrument.');
        }
        const stringData = child(instrument, 'StringData');
        let tuning: number[] | undefined;
        if (stringData) {
            use(stringData); tuning = children(stringData, 'string').map(e => {
                use(e); if (Object.keys(e.attrs).length) refuse('native-string', 'String modifiers require independent decoding.', e.location);
                const midi = integer(e.text.trim(), 0, 127, e.location);
                if (midi < 12) refuse('native-tuning-register', 'Complete source tuning contains an open pitch below the verified MusicXML octave spelling range; no string is dropped.', e.location);
                return midi;
            });
            get(stringData, 'frets');
            if (!tuning.length || tuning.length > 16) refuse('native-string', 'Invalid native string count.', stringData.location);
        }
        for (const c of instrument.children) {
            if (c.name === 'Articulation') omit(c, 'native-playback-articulation-template');
            else if (['longName', 'shortName', 'trackName'].includes(c.name)) plainText(c);
            else if (['concertClef', 'transposingClef', 'glissandoStyle'].includes(c.name)) use(c);
            else if (c.name === 'clef') use(c);
        }
        decoration(instrument);
        const part: MusicalPart = { source: p.location, id: p.attrs.id ?? `native-part-${parts.length + 1}`, name, instrument: identifier, ...(instrumentName ? { instrumentName: names.long!.value } : {}), names,
            nameOrigin: names.long?.value ? 'source-long-name' : names.track?.value || names.instrumentTrack?.value ? 'derived-track-fallback' : 'derived-placeholder',
            ...(!names.long?.value ? { namePrintObject: false } : {}),
            ...(names.short?.value ? { abbreviation: names.short.value, instrumentAbbreviation: names.short.value } : {}),
            midiProgram, ...(playbackChannels.length ? { playbackChannels } : {}), transposeOctaves: 0,
            ...(instrumentSound ? { instrumentSound: { value: instrumentSound, source: encodedInstrumentId!.location } } : {}),
            ...(transpose.chromatic || transpose.diatonic ? { transpose: sourceView?.concertPitch ? { diatonic: 0, chromatic: 0 } : transpose, sourceInstrumentTranspose: { source: instrument.location, ...transpose } } : {}), measures: [], staves: [] };
        if (partIdentities.has(part.id)) refuse('native-part-identity', 'Primary native part identities are ambiguous; they cannot overwrite the musical part index.', p.location);
        partIdentities.add(part.id);
        const useDrumset = get(instrument, 'useDrumset'), drums = children(instrument, 'Drum');
        if (useDrumset) integer(useDrumset, 0, 1, instrument.location);
        if (drums.length) {
            if (useDrumset !== '1' || tuning || part.transpose) refuse('native-percussion', 'Explicit drum definitions require an enabled nontransposing untuned drum instrument.', instrument.location);
            part.percussionInstruments = readNativeDrums(instrument, part.id, { use, get, budget });
            drumsByPart.set(part, new Map(part.percussionInstruments.map(drum => [drum.midi, drum])));
            if (part.instrumentSound) performanceGap('native-percussion-group-timbre', part.instrumentSound.source, 'The explicit source group timbre remains a located part fact. Individual drum declarations retain source drum identities; no per-drum timbre is fabricated from the group label.');
        }
        const panelColumns = get(instrument, 'percussionPanelColumns'); if (panelColumns) integer(panelColumns, 1, 128, instrument.location);
        for (const s of children(p, 'Staff')) {
            use(s);
            if (selection && scoreNode !== primaryNode) { const linked = child(s, 'linkedTo', true)!; omit(linked, 'native-selected-staff-membership'); }
            const type = child(s, 'StaffType');
            const group = type?.attrs.group ?? 'pitched';
            if (!['pitched', 'tablature', 'percussion'].includes(group)) refuse('native-staff', `Staff group ${group} needs an explicit pitch/percussion policy.`, s.location);
            const percussionLines = group === 'percussion' && type ? int(type, 'lines', 1, 16, 5) : undefined;
            if (group === 'percussion' && !part.percussionInstruments?.length) refuse('native-percussion', 'Percussion needs explicit source drum definitions; no catalog is guessed.', s.location);
            const invisible = child(s, 'invisible') ?? (type ? child(type, 'invisible') : undefined), staffVisible = child(s, 'isStaffVisible');
            for (const field of [invisible, staffVisible]) if (field) use(field);
            if (type) used.add(type);
            const number = part.staves!.length + 1;
            const defaultClef = child(s, 'defaultClef'), concertClef = child(s, 'defaultConcertClef'), transposingClef = child(s, 'defaultTransposingClef'), instrumentClef = children(instrument, 'clef').find(e => Number(e.attrs.staff ?? 1) === number);
            for (const field of [defaultClef, concertClef, transposingClef]) if (field) use(field);
            // The explicitly selected primary view owns its clef. Absent selection keeps
            // the verified native written-view baseline, separately from sounding pitch.
            const selectedClef = part.transpose && !sourceView?.concertPitch ? transposingClef ?? defaultClef ?? instrumentClef : concertClef ?? defaultClef ?? instrumentClef;
            const initialClef = qualifyNativeClef(selectedClef?.text.trim() || (group === 'percussion' ? 'PERC' : group === 'tablature' ? 'TAB' : 'G'),selectedClef?.location??s.location,findings,capture.nativeVersion);
            const definition: StaffFact = { source: s.location, number, clef: initialClef,
                ...(initialClef === 'G8vbp' ? { clefBadge: { source: selectedClef?.location ?? s.location, value: 'optional-octave-below' as const } } : {}),
                clefOrigin: { source: selectedClef?.location ?? s.location, origin: selectedClef ? 'source' : 'native-default', ...(concertClef ? { concert: concertClef.text.trim() } : {}), ...(transposingClef ? { transposing: transposingClef.text.trim() } : {}) },
                ...(staffVisible ? { printObject: integer(staffVisible.text.trim(),0,1,staffVisible.location)!==0 } : {}),
                ...(invisible?{lineVisibility:{source:invisible.location,value:integer(invisible.text.trim(),0,1,invisible.location)!==1}}:{}),
                kind: group as 'pitched' | 'tablature' | 'percussion', ...(group === 'percussion' ? { lines: percussionLines } : {}), ...(group === 'tablature' && tuning ? { tuning, lines: tuning.length } : {}) };
            if (type) Object.assign(definition, readNativeStaffType(type, { use, omit, smallMagnification: styleValues.get('smallStaffMag'), readColor }));
            const ownInvisible=child(s,'invisible'); if(ownInvisible && (!type || s.children.indexOf(ownInvisible)>s.children.indexOf(type)))definition.lineVisibility={source:ownInvisible.location,value:integer(ownInvisible.text,0,1,ownInvisible.location)!==1};
            const staffColor=readColor(s); if(staffColor && (!type || s.children.indexOf(child(s,'color')!)>s.children.indexOf(type)))definition.sourceColor=staffColor;
            const partShow=child(p,'show'); if(partShow) { use(partShow); part.sourceVisibility={source:partShow.location,value:integer(partShow.text,0,1,partShow.location)!==0}; if(!part.sourceVisibility.value)definition.printObject=false; }
            for(const name of ['cutaway','showIfSystemEmpty'] as const) {const field=child(s,name); if(field) {use(field); definition[name]={source:field.location,value:integer(field.text,0,1,field.location)===1}; performanceGap('native-staff-system-visibility',field.location,'The source system-dependent empty-staff visibility policy remains located. Source staff music and explicit visibility are preserved; deciding system breaks and whether an entire system is empty belongs to consumer pagination.');}}
            const emptyVisibility = child(s, 'hideWhenEmpty'); if (emptyVisibility) {
                const rawValue = get(s, 'hideWhenEmpty'), policies: Record<string, NonNullable<StaffFact['hideWhenEmpty']>['policy']> = Number(capture.nativeVersion) < 4.6 ? { '0': 'auto', '1': 'always', '2': 'never', '3': 'instrument' } : { auto: 'auto', on: 'always', off: 'never' };
                if (emptyVisibility.children.length || Object.keys(emptyVisibility.attrs).length || !Object.hasOwn(policies, rawValue)) refuse('native-staff-visibility', 'Unknown versioned empty-staff visibility policy.', emptyVisibility.location);
                definition.hideWhenEmpty = { source: emptyVisibility.location, rawValue, policy: policies[rawValue] };
                performanceGap('native-empty-staff-system-view', emptyVisibility.location, 'The source empty-staff policy remains a located versioned view fact. Actual system-dependent collapsing remains consumer layout; source staff/event clocks and visibility are not changed.');
            }
            for (let vi = 0; vi < 4; vi++) {
                const flag = child(s, `playbackVoice${vi + 1}`); if (!flag) continue;
                use(flag); budget.add('markings', 1, flag.location);
                (definition.voicePlayback ??= []).push({ source: flag.location, voiceId: String((number - 1) * 4 + vi + 1), play: integer(flag.text.trim(), 0, 1, flag.location) === 1 });
            }
            const globalStaff = nativeStaffDeclarationId(s, scoreNode, capture.nativeVersion);
            if (staffOwners.has(globalStaff)) refuse('native-staff', 'Duplicate source staff identity.', s.location);
            staffOwners.set(globalStaff, { part, definition }); sequentialStaff = Math.max(sequentialStaff + 1, globalStaff + 1);
            part.staves!.push(definition); decoration(s);
        }
        if (!part.staves!.length) refuse('native-part', 'Part has no declared staff.', p.location);
        // Ordinary fretted staffs need one tuning carrier; actual TAB staffs already carry their source tuning.
        if (tuning && !part.staves!.some(s => s.kind === 'tablature')) part.tuning = tuning;
        decoration(p); parts.push(part);
    }
    if (!parts.length) refuse('native-part', 'Score has no parts.', scoreNode.location);
    const cachedMeasureViews: NonNullable<MusicalScore['cachedMeasureViews']> = [];
    const cachedNodes = new Map<NonNullable<MusicalScore['cachedMeasureViews']>[number], Element>();
    const measureAxes = new Map<Element, Element[]>();
    const isCachedMeasure = (m: Element) => {
        const count = child(m, 'multiMeasureRest');
        return count ? integer(count.text.trim(), 0, 10000, count.location) > 0 : false;
    };
    const primaryMeasures = (staff: Element) => {
        const existing = measureAxes.get(staff); if (existing) return existing;
        const measures: Element[] = [], owner = staffOwners.get(integer(staff.attrs.id, 1, 256, staff.location))!;
        for (const m of children(staff, 'Measure')) {
            if (!isCachedMeasure(m)) { measures.push(m); continue; }
            if (!measures.length) refuse('native-cache-owner', 'Cached multirest has no preceding ordinary source measure.', m.location);
            budget.add('markings', 1, m.location);
            const restValues: NonNullable<MusicalScore['cachedMeasureViews']>[number]['restValues'] = [];
            for (const voice of children(m, 'voice')) for (const rest of children(voice, 'Rest')) { const duration = child(rest, 'duration'); if (duration) restValues.push({ source: duration.location, raw: duration.text.trim() }); }
            const fact: NonNullable<MusicalScore['cachedMeasureViews']>[number] = { source: m.location, partId: owner.part.id, staff: owner.definition.number, startMeasure: measures.length - 1,
                count: integer(text(m, 'multiMeasureRest'), 1, 10000, m.location), ...(m.attrs.len ? { encodedSpan: { source: m.location, raw: m.attrs.len } } : {}), restValues, contentStatus: 'unverified-cache-content' };
            cachedMeasureViews.push(fact); cachedNodes.set(fact, m); omit(m, 'native-cached-multirest-view');
        }
        measureAxes.set(staff, measures); return measures;
    };
    const readFrames = (staff: Element, partId: string, staffNumber: number, target: NonNullable<MusicalScore['credits']>, viewSource?: Element['location']) => {
        let frameMeasure = 0;
        for (const item of staff.children) {
            if (item.name === 'Measure') { if (!isCachedMeasure(item)) frameMeasure++; continue; }
            if (!['VBox', 'HBox', 'FBox', 'TBox'].includes(item.name)) continue;
            const frameStack: { node: Element; frame: Element; hiddenSource?: Element['location'] }[] = [{ node: item, frame: item }];
            while (frameStack.length) {
                const context = frameStack.pop()!, node = context.node, frame = context.frame;
                if (node.name === 'Image') {
                    readImageTree(node,{partId,staff:staffNumber,beforeMeasure:frameMeasure,frame:frame.name as 'VBox'|'HBox'|'FBox'|'TBox',...(viewSource?{viewSource}:{}),...(context.hiddenSource?{hiddenSource:context.hiddenSource}:{})},{scope:'score',source:node.location});
                    continue;
                }
                if (node.name !== 'Text' && !['Symbol','FSymbol'].includes(node.name)) {
                    use(node); const visible = get(node, 'visible'); if (visible) integer(visible, 0, 1, node.location);
                    if (selection) for (const marker of children(node, 'linked')) if (selectedLinks.has(marker.location.path)) omit(marker, 'native-selected-object-membership');
                    const hiddenSource = context.hiddenSource ?? (visible === '0' ? child(node, 'visible')!.location : undefined);
                    for (let i = node.children.length - 1; i >= 0; i--) { const c = node.children[i]; if (['VBox', 'HBox', 'FBox', 'TBox', 'Text', 'Symbol', 'FSymbol', 'Image'].includes(c.name)) frameStack.push({ node: c, frame: node, hiddenSource }); }
                    for (const marker of children(node, 'linkedMain')) {
                        if (marker.children.length || marker.text.trim() || Object.keys(marker.attrs).length) refuse('native-primary-link', 'Primary linked frame marker must be empty.', marker.location);
                        omit(marker, 'native-primary-linked-frame');
                    }
                    for (const c of node.children) if (!used.has(c) && (['height', 'width', 'topGap', 'bottomGap', 'leftMargin', 'rightMargin', 'topMargin', 'bottomMargin', 'autoSize', 'boxAutoSize', 'boxHeight', 'boxWidth', 'heightSpatiumDependent', 'widthSpatiumDependent', 'sizeIsSpatiumDependent', 'paddingToNotationAbove', 'paddingToNotationBelow', 'excludeFromOtherParts', 'LayoutBreak'].includes(c.name) || layout.has(c.name))) omit(c, 'native-frame-geometry');
                    continue;
                }
                if (['Symbol','FSymbol'].includes(node.name)) {
                    readNestedImages(node,{partId,staff:staffNumber,beforeMeasure:frameMeasure,frame:frame.name as 'VBox'|'HBox'|'FBox'|'TBox',...(viewSource?{viewSource}:{})},context.hiddenSource,{scope:'score',source:node.location});
                    const name = text(node, 'name'), symbols: Record<string, string> = { segno: '𝄋', coda: '𝄌' };
                    for (const symbol of readGlyphs(node, undefined, !!context.hiddenSource,[],{scope:'score',source:node.location})) {
                        target.push({ source: symbol.source, text: symbols[symbol.name]??symbol.name, symbol, ...(symbol.printObject !== undefined ? { printObject: symbol.printObject } : {}), frame: frame.name as NonNullable<MusicalScore['credits']>[number]['frame'], partId, staff: staffNumber, beforeMeasure: frameMeasure });
                    }
                    continue;
                }
                use(node); budget.add('markings', 1, node.location);
                const field = child(node, 'text'), style = child(node, 'style'), visibilityField = child(node, 'visible'), visible = get(node, 'visible');
                if (visible) integer(visible, 0, 1, node.location);
                const sourceStyle = style ? { source: style.location, value: get(node, 'style') } : undefined;
                let styleFontSize: NonNullable<MusicalScore['credits']>[number]['textFontSize'], styleAlignment: Direction['textAlignment'];
                const frameStyle = style && userFrameStyles.get(nativeTextStylePrefix(style.text, capture.nativeVersion) ?? '');
                if (frameStyle && !viewSource && frameMeasure === 0 && item.name === 'VBox' && frame === item && item.children.includes(node)
                    && !Object.keys(node.attrs).length && node.children.every(c => ['style', 'text', 'visible'].includes(c.name))
                    && style && plainUserField(style) && field && plainUserField(field) && node.children.indexOf(style) < node.children.indexOf(field)
                    && field.text.trim() && !/[<\uE000-\uF8FF]/.test(field.text)
                    && (!visibilityField || plainUserField(visibilityField) && ['0', '1'].includes(visibilityField.text))) {
                    const size = frameStyle.get('FontSize'), dependency = frameStyle.get('FontSpatiumDependent'), alignment = frameStyle.get('Align');
                    if (size && /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(size.text) && Number.isFinite(Number(size.text)) && Number(size.text) > 0) {
                        const value = Number(size.text);
                        styleFontSize = { source: size.location, rawValue: size.text, value, origin: 'source-style',
                            ...(dependency?.text === '0' && value <= 10_000 ? { pointSize: { value, origin: 'source-context' as const, context: 'musescore-3.6.1-user-text-style' as const,
                                spatiumDependent: { source: dependency.location, value: false as const, origin: 'source-style' as const } } } : {}) };
                        budget.add('markings', 1 + Number(!!styleFontSize.pointSize), size.location);
                    }
                    const match = alignment && /^(left|center|right),(top|center|bottom|baseline)$/.exec(alignment.text);
                    if (match) {
                        styleAlignment = { source: alignment!.location, origin: 'source-style', justify: match[1] as 'left' | 'center' | 'right',
                            valign: match[2] === 'center' ? 'middle' : match[2] as 'top' | 'bottom' | 'baseline' };
                        budget.add('markings', 1, alignment!.location);
                    }
                    if (styleFontSize || styleAlignment) performanceGap('native-initial-user-frame-style', node.location, 'The examined initial main User-1/User-2 caption retains its explicit own Score style size request and alignment. Only encoded unscaled size establishes the standard point-size hint; no available font, native dimensions, semantic title role or inherited parent-view style is inferred.', 'preserved');
                }
                const align = get(node, 'align'), position = get(node, 'position'), textAlignment: NonNullable<Direction['textAlignment']> = { source: node.location };
                if (align) {
                    const match = /^(left|center|right),(top|center|bottom|baseline)$/.exec(align);
                    if (!match) return refuse('native-text-alignment', 'Uninterpreted source frame text alignment.', node.location);
                    textAlignment.justify = match[1] as NonNullable<Direction['textAlignment']>['justify']; textAlignment.valign = match[2] === 'center' ? 'middle' : match[2] as NonNullable<Direction['textAlignment']>['valign'];
                    if (Number(capture.nativeVersion) < 4.7) { textAlignment.halign = textAlignment.justify; textAlignment.halignOrigin = 'derived-legacy-align'; }
                }
                if (position) { if (Number(capture.nativeVersion) < 4.7 || !['left', 'center', 'right'].includes(position)) refuse('native-text-position', 'Unexercised native frame text position.', node.location); textAlignment.halign = position as NonNullable<Direction['textAlignment']>['halign']; textAlignment.halignOrigin = 'source-position'; }
                const roles: Record<string, NonNullable<NonNullable<MusicalScore['credits']>[number]['role']>> = { Title: 'title', title: 'title', Subtitle: 'subtitle', subtitle: 'subtitle', Composer: 'composer', composer: 'composer', Lyricist: 'lyricist', poet: 'lyricist' };
                const frameRuns:InlineRuns={values:[],emphasized:false,limits:new Set()},frameText=field?plainText(field,undefined,frameRuns):'';
                const retainFrameRuns=frameRuns.values.some(run=>run.emphasis||run.emphasisResets?.length||run.sourceFont||run.symbolName||run.sourceText||run.textFontSize||run.script);
                if(retainFrameRuns)budget.add('markings',frameRuns.values.length,field!.location);
                if(frameRuns.limits.size)deferInline(node,frameRuns,field!.location,'native-frame-inline-appearance');
                target.push({ source: node.location, text: frameText, ...(retainFrameRuns?{textRuns:frameRuns.values}:{}), ...(sourceStyle ? { sourceStyle } : {}), ...(align || position ? { textAlignment } : styleAlignment ? { textAlignment: styleAlignment } : {}), ...(styleFontSize ? { textFontSize: styleFontSize } : {}), ...(sourceStyle && Object.hasOwn(roles, sourceStyle.value) ? { role: roles[sourceStyle.value] } : {}),
                    ...(context.hiddenSource ? { printObject: false, visibility: { source: context.hiddenSource, value: false, origin: 'derived-frame' as const } } : visible ? { printObject: integer(visible, 0, 1, node.location) === 1, visibility: { source: child(node, 'visible')!.location, value: visible === '1', origin: 'source-text' as const } } : {}), frame: frame.name as NonNullable<MusicalScore['credits']>[number]['frame'], partId, staff: staffNumber, beforeMeasure: frameMeasure });
                applyPresentation(node, target.at(-1)!,{scope:'score',source:node.location});
                const resolvedFrameSize=target.at(-1)!.textFontSize;
                if(styleFontSize&&!styleFontSize.pointSize && !(resolvedFrameSize?.pointSize && resolvedFrameSize.source.member===styleFontSize.source.member && resolvedFrameSize.source.path===styleFontSize.source.path))
                    performanceGap('native-user-frame-size-unit',styleFontSize.source,'The source User text size request lacks a qualified point-size projection after resolving its actual style and source-space dependencies.');
                decoration(node);
                for (const link of children(node, 'linked')) omit(link, 'native-linked-frame-text-reference');
            }
        }
    };
    const alternateViews: NonNullable<MusicalScore['alternateViews']> = [];
    for (const view of children(scoreNode, 'Score')) {
        budget.add('markings', 1, view.location);
        const name = child(view, 'name'), viewFact: NonNullable<MusicalScore['alternateViews']>[number] = { source: view.location,
            ...(name ? { name: { source: name.location, value: plainText(name) } } : {}), metadata: [], credits: [], parts: [], contentStatus: 'linked-content-unverified' };
        for (const field of children(view, 'metaTag')) {
            budget.add('markings', 1, field.location);
            if (!field.attrs.name || field.attrs.name.length > 256 || field.children.length) refuse('native-metadata', 'View metadata needs a bounded explicit name and plain text.', field.location);
            viewFact.metadata.push({ source: field.location, name: field.attrs.name, value: field.text });
        }
        const viewStaffIds = new Set<number>();
        for (const viewPart of children(view, 'Part')) {
            budget.add('markings', 1, viewPart.location);
            const viewInstrument = child(viewPart, 'Instrument'), names: NonNullable<MusicalPart['names']> = {}, staffs: NonNullable<MusicalScore['alternateViews']>[number]['parts'][number]['staffs'] = [];
            for (const [role, field] of [['track', child(viewPart, 'trackName')], ['long', viewInstrument ? child(viewInstrument, 'longName') : undefined], ['short', viewInstrument ? child(viewInstrument, 'shortName') : undefined], ['instrumentTrack', viewInstrument ? child(viewInstrument, 'trackName') : undefined]] as const)
                if (field) { budget.add('markings', 1, field.location); names[role] = { source: field.location, value: plainText(field) }; }
            let primaryPart: MusicalPart | undefined;
            for (const staff of children(viewPart, 'Staff')) {
                budget.add('markings', 1, staff.location);
                const link = child(staff, 'linkedTo', true)!, sourceStaffId = nativePrimaryStaffLink(staff, primaryNode, capture.nativeVersion).id, viewStaffId = nativeStaffDeclarationId(staff, view, capture.nativeVersion), owner = staffOwners.get(sourceStaffId);
                if (!owner) return refuse('native-view-link', 'Alternate view staff link does not resolve to a primary source staff.', link.location);
                if (primaryPart && owner.part !== primaryPart || viewStaffIds.has(viewStaffId)) refuse('native-view-link', 'Alternate view staff links must uniquely resolve within one primary source part.', staff.location);
                primaryPart = owner.part; viewStaffIds.add(viewStaffId);
                staffs.push({ source: link.location, viewStaffId, sourceStaffId, sourceStaffNumber: owner.definition.number });
            }
            if (!primaryPart) refuse('native-view-link', 'Alternate view part has no encoded primary staff link.', viewPart.location);
            viewFact.parts.push({ source: viewPart.location, names, sourcePartId: primaryPart!.id, sourcePartIdOrigin: 'derived-staff-links', staffs });
        }
        if (!viewFact.parts.length || children(view, 'Staff').some(staff => !viewStaffIds.has(integer(staff.attrs.id, 1, 256, staff.location)))) refuse('native-view-link', 'Alternate view content has no unique declared staff mapping.', view.location);
        const viewOwners = new Map(viewFact.parts.flatMap(part => part.staffs.map(staff => [staff.viewStaffId, { partId: part.sourcePartId, number: staff.sourceStaffNumber }] as const)));
        for (const staff of children(view, 'Staff')) { const owner = viewOwners.get(integer(staff.attrs.id, 1, 256, staff.location))!; readFrames(staff, owner.partId, owner.number, viewFact.credits, view.location); }
        alternateViews.push(viewFact);
        omit(view, 'native-alternate-view-content-retained');
        performanceGap('native-alternate-view-content', view.location, 'Located view names, metadata and explicit primary part/staff links are recovered. Its independently serialized music remains byte-exact; equivalence to the primary events has not been certified. The primary performer event stream is converted once.');
    }
    // Native staff sections serialize one shared score measure sequence. Repeat execution belongs
    // to that shared measure, while each staff's BarLine can retain its own displayed shape.
    const masterStaff = children(scoreNode, 'Staff')[0];
    if (!masterStaff) refuse('native-staff', 'Score has no serialized staff measures.', scoreNode.location);
    const masterMeasures = primaryMeasures(masterStaff);
    let lyricClockUnsafeFrom = Infinity;
    let regularNumber = 1;
    const numberStyle = (name: string, fallback: number) => { const fact = styleValues.get(name); return fact ? integer(fact.value, 0, 1, fact.source) : fallback; };
    const automaticNumbering = numberStyle('showMeasureNumber', 1) ? numberStyle('measureNumberSystem', 1) ? 'system' as const : 'measure' as const : 'none' as const;
    const numberInterval = measureNumbering.interval?.value ?? 5, showFirstNumber = measureNumbering.showFirst?.value ?? false;
    const sectionStarts=nativeSectionStarts(children(scoreNode,'Staff'),primaryMeasures);
    const firstInSection=(index:number)=>index===0||sectionStarts.has(index);
    const repeatFacts = masterMeasures.map((m, index) => {
        const sectionStart=sectionStarts.get(index);if(sectionStart?.restart)regularNumber=1;
        const irregular = child(m, 'irregular');
        const offset = child(m, 'noOffset'), mode = child(m, 'measureNumberMode');
        for (const fact of [offset, mode]) if (fact) { use(fact); if (fact.children.length || Object.keys(fact.attrs).length) refuse('native-measure-numbering', 'Measure-number fields require plain scalar source values.', fact.location); }
        regularNumber += offset ? integer(offset.text.trim(), -1000000, 1000000, offset.location) : 0;
        const isIrregular = irregular ? integer(irregular.text.trim(), 0, 1, irregular.location) === 1 : false;
        const displayNumber = isIrregular ? undefined : regularNumber++;
        const firstQualifier = firstInSection(index) || index>0 && firstInSection(index-1) && child(masterMeasures[index-1],'irregular')?.text.trim()==='1' && numberInterval!==1;
        const automatic = isIrregular || automaticNumbering === 'none' || firstQualifier && !showFirstNumber ? 'none' as const
            : firstQualifier ? 'measure' as const
            : automaticNumbering === 'measure' && numberInterval !== 1 && displayNumber! % numberInterval !== (showFirstNumber ? 1 : 0) ? 'none' as const : automaticNumbering;
        return { source: m.location, start: !!child(m, 'startRepeat'), end: text(m, 'endRepeat') ? integer(text(m, 'endRepeat'), 0, 128, m.location) : 0,
            numbering: { source: irregular?.location ?? m.location, irregular: isIrregular, origin: irregular ? 'source' as const : 'native-default' as const, automatic,...(sectionStart?{sectionStart}:{}),
                ...(displayNumber !== undefined ? { displayNumber } : {}), ...(offset ? { offset: { source: offset.location, value: integer(offset.text.trim(), -1000000, 1000000, offset.location) } } : {}),
                ...(mode ? { mode: { source: mode.location, value: (['auto', 'show', 'hide'] as const)[integer(mode.text.trim(), 0, 2, mode.location)] } } : {}) } };
    });
    // Every 3.x/4.x TextLine starts with a +1.5sp (downward) hook. From 4.60
    // the drawn sign also flips for below-placed TextLine and Pedal lines.
    const textLineShapeProfile = true;
    const viewStyles = (selection && scoreNode !== primaryNode ? [child(scoreNode, 'Style')] : [capture.styleRoot?.children[0], child(scoreNode, 'Style')]).filter((node): node is Element => !!node);
    const viewStyleField = (name: string): Element | undefined => {
        const field = viewStyles.flatMap(style => children(style, name)).at(-1);
        return field && plainStyleField(field) ? field : undefined;
    };
    const finiteStyle = (field: Element | undefined): number | undefined => field && /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(field.text.trim()) ? Number(field.text.trim()) : undefined;
    const lineHookDirection = (content: Element, type: string, height: number | undefined, qualified: boolean): 'up' | 'down' => {
        const modern = Number(capture.nativeVersion) >= 4.6;
        const signed = height ?? (type === 'Volta' ? 1 : type === 'TextLine' && qualified ? (modern ? finiteStyle(viewStyleField('textLineHookHeight')) : undefined) ?? 1.5
            : type === 'Pedal' ? finiteStyle(viewStyleField('pedalHookHeight')) ?? (modern ? 1.2 : -1.2) : -1);
        let below = false;
        if (modern && (type === 'TextLine' || type === 'Pedal')) {
            const own = child(content, 'placement')?.text.trim(), style = viewStyleField(type === 'Pedal' ? 'pedalPlacement' : 'textLinePlacement')?.text.trim();
            below = (own === 'above' || own === 'below' ? own : style === 'above' || style === 'below' ? style : type === 'Pedal' ? 'below' : 'above') === 'below';
        }
        return (below ? -signed : signed) > 0 ? 'down' : 'up';
    };
    const plainLineShape = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length && !hasCommentOrCdata(field);
    const qualifiedLineHook = (content: Element, side: 'begin' | 'end'): boolean => {
        const hooks = children(content, `${side}HookType`), heights = children(content, `${side}HookHeight`);
        return textLineShapeProfile && hooks.length === 1 && plainLineShape(hooks[0]) && ['1', '2'].includes(hooks[0].text.trim())
            && (heights.length === 0 || heights.length === 1 && plainLineShape(heights[0])
                && /^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(heights[0].text.trim()) && Number(heights[0].text) !== 0);
    };
    const harmonyReader = createNativeHarmonyReader({ get, use, consume: node => used.add(node), omit, budget, readColor, plainText, decoration, performanceGap, applyPresentation,
        styles: (selection && scoreNode !== primaryNode ? [child(scoreNode, 'Style')] : [capture.styleRoot?.children[0], child(scoreNode, 'Style')]).filter((node): node is Element => !!node),
        chordList: child(scoreNode, 'ChordList') });
    const anchors = new Map<string, Anchor>(), links: Link[] = [], noteEvents = new Map<MusicalNote, MusicalEvent>();
    const physicalNotes: { note: MusicalNote; event: MusicalEvent; part: MusicalPart; definition: StaffFact; measure: number; midi: number }[] = [];
    const tremoloBars: { part: MusicalPart; measure: number; staff: number; voice: number; position: Rational; fact: NonNullable<MusicalEvent['whammy']> }[] = [];
    const pendingWritten: { note: MusicalNote; event: MusicalEvent; part: MusicalPart; source: Element; midi: number; tpc: number; tpc2?: number; definition: StaffFact; clef: string }[] = [];
    const registerSpanners = (e: Element, anchor: Anchor) => {
        for (const spanner of children(e, 'Spanner')) {
            budget.add('relations', 1, spanner.location);
            use(spanner);
            const encodedType = spanner.attrs.type;
            if (!['Tie', 'Slur', 'Pedal', 'HairPin', 'TextLine', 'NoteLine', 'Ottava', 'Volta', 'Trill', 'Glissando', 'GuitarBend', 'HammerOnPullOff'].includes(encodedType) && !nativeTechniqueLines.has(encodedType)) refuse('native-spanner', `Unsupported ${encodedType} spanner.`, spanner.location);
            const type = encodedType === 'TextLine' && anchor.note ? 'NoteLine' : encodedType;
            const next = child(spanner, 'next'), prev = child(spanner, 'prev');
            if (!next && !prev) {
                if (encodedType === 'HairPin' && !spanner.text.trim() && !spanner.children.length && !anchor.event && !anchor.note) { omit(spanner, 'native-empty-direction-wrapper'); continue; }
                refuse('native-spanner', 'Spanner has no endpoint reference.', spanner.location);
            }
            const content = child(spanner, encodedType);
            let subtype: string | undefined; const payload: SpanPayload = {};
            if (type === 'Glissando') {
                if (!anchor.note) refuse('native-glissando-owner', 'Glissando needs actual source note components.', spanner.location);
                const form = styleValues.get('glissandoType'), label = styleValues.get('glissandoText'), show = styleValues.get('glissandoShowText');
                if (form && !['0', '1'].includes(form.value)) refuse('native-glissando', 'Uninterpreted source glissando style type.', form.source);
                payload.glissando = { form: form?.value === '1' ? 'glissando' : 'slide', formFact: { source: form?.source ?? spanner.location, origin: form ? 'source-style' : 'native-default' }, label: { source: label?.source ?? spanner.location, value: label?.value ?? 'gliss.', show: show ? integer(show.value, 0, 1, show.source) === 1 : true, origin: label ? 'source-style' : 'native-default' } };
            }
            if (type === 'NoteLine') {
                if (!anchor.note) refuse('native-note-line-owner', 'A note line needs an actual source note owner.', spanner.location);
                payload.noteLine = { sourceForm: encodedType === 'TextLine' ? 'text-line' : 'note-line' };
            }
            if (content) {
                use(content); subtype = get(content, 'subtype');
                let beginSizeContext = true;
                if (type === 'GuitarBend') {
                    if (!anchor.note) refuse('native-bend-owner', 'Modern bends require a source note owner.', spanner.location);
                    payload.modernBend = readModernBend(content, get);
                    const anchorType = get(content, 'anchor'); if (anchorType && anchorType !== '3') refuse('native-bend-owner', 'Modern bend anchor must retain its explicit note ownership.', content.location);
                    const sourceColor = readBendLineColor(content); if (sourceColor) payload.sourceColor = sourceColor;
                    const direction = get(content, 'direction'); if (direction && !['auto', 'up', 'down'].includes(direction)) refuse('native-bend-direction', 'Unknown source bend direction.', content.location);
                    const hold = child(content, 'GuitarBendHold');
                    if(hold){
                        use(hold);budget.add('markings',1,hold.location);
                        const held:NonNullable<NativeModernBend['hold']>={source:hold.location};
                        const visible=get(hold,'visible');if(visible)held.printObject=integer(visible,0,1,hold.location)===1;
                        const color=readBendLineColor(hold);if(color)held.sourceColor=color;
                        const anchor=get(hold,'anchor');if(anchor&&anchor!=='3')refuse('native-bend-hold','A bend hold retains its note endpoints.',hold.location);
                        const line=get(hold,'lineStyle');if(line){const styles:Record<string,'solid'|'dashed'|'dotted'>={'1':'solid','2':'dashed','3':'dotted'};if(!styles[line])refuse('native-bend-hold','Uninterpreted hold line style.',hold.location);held.lineType=styles[line];}
                        for(const field of hold.children)if(['lineWidth','dashLineLen','dashGapLen'].includes(field.name)){geometryScalar(field.text.trim(),field);omit(field,'native-line-geometry');}
                        for(const segment of children(hold,'Segment'))readSegment(segment,'GuitarBendHold',{printObject:held.printObject});
                        decoration(hold);payload.modernBend.hold=held;
                    }
                    const placement = get(content, 'guitarDiveTabPos'); if (placement && !['auto', 'up', 'down'].includes(placement)) refuse('native-bend-direction', 'Unknown source dive placement.', content.location);
                }
                if (type === 'Glissando') {
                    if (subtype && !['0', '1'].includes(subtype)) refuse('native-glissando', 'Unknown source glissando type.', content.location);
                    if (subtype) { payload.glissando!.form = subtype === '0' ? 'slide' : 'glissando'; payload.glissando!.formFact = { source: child(content, 'subtype')!.location, origin: 'source' }; }
                    const labels = children(content, 'text'), label = labels[0], show = get(content, 'showText'), anchorType = get(content, 'anchor');
                    if (labels.length > 1) {
                        if (labels.length > 16 || labels.some(item => item.children.length || Object.keys(item.attrs).length || item.text !== label.text)) refuse('native-glissando-label', 'Duplicate glissando labels must be strictly identical bounded plain definitions.', content.location);
                        for (const item of labels) use(item);
                        performanceGap('native-duplicate-glissando-label', labels[1].location, 'Identical source glissando label definitions retain all locations and one effective literal label; differing definitions are never resolved by encounter order.', 'inferred');
                    }
                    if (anchorType && anchorType !== '3') refuse('native-glissando-owner', 'Encoded glissando anchor must retain note ownership.', content.location);
                    if (label) payload.glissando!.label = { ...payload.glissando!.label, source: label.location, ...(labels.length > 1 ? { duplicateSources: labels.slice(1).map(item => item.location) } : {}), value: plainText(label), origin: 'source' };
                    if (show) payload.glissando!.label.show = integer(show, 0, 1, content.location) === 1;
                    for (const field of ['glissandoStyle', 'easeInSpin', 'easeOutSpin', 'glissandoShift']) {
                        const item = child(content, field); if (!item) continue;
                        if (item.children.length || Object.keys(item.attrs).length) refuse('native-glissando-performance', 'Playback-only glissando settings require bounded plain data.', item.location);
                        omit(item, 'native-glissando-engine-profile');
                    }
                }
                if (type === 'NoteLine') {
                    const noteAnchor = get(content, 'anchor');
                    if (encodedType === 'TextLine' && noteAnchor !== '3' || noteAnchor && noteAnchor !== '3') refuse('native-note-line-owner', 'Encoded note-line anchor must identify its actual note owner.', content.location);
                    const diagonal = get(content, 'diagonal'); if (diagonal) payload.noteLine!.diagonal = { source: child(content, 'diagonal')!.location, value: integer(diagonal, 0, 1, content.location) === 1 };
                    const endpointPlacement = get(content, 'noteLinePlacement'); if (endpointPlacement) refuse('native-note-line-placement', 'Authored endpoint placement needs independent source evidence.', child(content, 'noteLinePlacement')!.location);
                }
                // Scoped line vocabulary: these fields describe this relation, never arbitrary similarly named nodes.
                for (const name of ['beginText', 'continueText', 'endText'] as const) {
                    const t = child(content, name); if (t) {
                        use(t); const wrapper = child(t, 'text');
                        const runs: InlineRuns | undefined = type === 'Pedal' ? { values: [], emphasized: false, limits: new Set() } : undefined;
                        const invalidLegacyCaption = legacyInvalidHairpinCaption(type, subtype, name, t);
                        // The examined native canonical lookup returns noSym for
                        // this exact invalid name, while dynamicForte remains.
                        // Decode an inert view; the original STRING stays exact.
                        const caption = invalidLegacyCaption ? { ...t, text: '<sym>dynamicForte</sym>' } : wrapper ?? t;
                        payload[name] = runs ? plainText(caption, t.location, runs) : plainText(caption);
                        if (invalidLegacyCaption) performanceGap('native-legacy-invalid-hairpin-symbol', t.location, 'The exact MuseScore 3.6.2 canonical lookup emits no glyph for dynamicPForte and retains the following valid dynamicForte. This qualified HairPin BEGIN caption projects f; its original token, text and location remain in sourceText and source capture. No intended pf/fp glyph or playback value is inferred.', 'preserved');
                        if (name === 'beginText' && runs?.limits.size) beginSizeContext = false;
                        (payload.textFacts ??= {})[name] = { source: t.location, value: payload[name]!, origin: 'source' };
                        budget.add('markings', 1, t.location);
                        if (runs && (runs.emphasized || runs.values.some(run=>run.textFontSize||run.script||run.symbolName||run.sourceFont||run.sourceText))) {
                            budget.add('markings', runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), t.location);
                            (payload.textRuns ??= {})[name] = runs.values;
                            if (runs?.limits.size) deferInline(content,runs,t.location,'native-caption-inline-appearance', name);
                        }
                    }
                }
                if (type === 'HairPin' && ['2', '3'].includes(subtype ?? '0')) {
                    const crescendo = subtype === '2';
                    for (const [field, styleName, fallback] of [['beginText', crescendo ? 'hairpinCrescText' : 'hairpinDecrescText', crescendo ? 'cresc.' : 'dim.'], ['continueText', crescendo ? 'hairpinCrescContText' : 'hairpinDecrescContText', crescendo ? '(cresc.)' : '(dim.)']] as const) {
                        if (payload[field] === undefined) { const style = styleValues.get(styleName); payload[field] = style?.value ?? fallback; (payload.textFacts ??= {})[field] = { source: style?.source ?? content.location, value: payload[field]!, origin: style ? 'source-style' : 'native-default' }; }
                    }
                }
                if (nativeTechniqueLines.has(type)) {
                    const sourceColor = readColor(content); if (sourceColor) payload.sourceColor = sourceColor;
                    const styleName = type === 'PalmMute' ? 'palmMute' : type === 'WhammyBar' ? 'whammyBar' : 'letRing';
                    if (type !== 'Vibrato' && subtype) refuse('native-technique-line', 'This native text technique has no qualified subtype property.', content.location);
                    const caption = ['PalmMute', 'LetRing', 'WhammyBar'].includes(type) ? styleValues.get(`${styleName}Text`) : undefined;
                    if (payload.beginText === undefined) {
                        payload.beginText = type === 'Vibrato' ? nativeVibratoCaption(subtype || 'guitarVibrato', content)
                            : type === 'HarmonicMark' ? '' : caption?.value ?? (type === 'PalmMute' ? 'P.M.' : type === 'WhammyBar' ? 'w/bar' : 'let ring');
                        (payload.textFacts ??= {}).beginText = { source: caption?.source ?? content.location, value: payload.beginText, origin: caption ? 'source-style' : 'native-default' };
                    }
                    const line = type === 'Vibrato' ? undefined : styleValues.get(`${styleName}LineStyle`);
                    if (line && !['1', '2', '3', 'solid', 'dashed', 'dotted'].includes(line.value)) refuse('native-technique-line', 'Unknown technique line style.', line.source);
                    payload.lineType = type === 'Vibrato' || line?.value === '1' || line?.value === 'solid' ? 'solid' : line?.value === '3' || line?.value === 'dotted' ? 'dotted' : 'dashed';
                }
                if (payload.continueText) performanceGap('native-line-continuation-layout', payload.textFacts!.continueText!.source, 'The exact continuation text, effective source/default binding, relation scope and visibility remain located. MusicXML retains the initial instruction and line plus useful continuation metadata; repeating it at native system breaks needs consumer layout interpretation.');
                for (const [name, field] of [['lineVisible', 'lineVisible'], ['visible', 'printObject'], ['systemFlag', 'system']] as const) {
                    const value = get(content, name); if (value) payload[field] = integer(value, 0, 1, content.location) === 1;
                }
                if (content.attrs.system) payload.system = integer(content.attrs.system, 0, 1, content.location) === 1;
                if (type === 'HairPin' || type === 'Pedal') {
                    if (type === 'HairPin') { const color = readColor(content); if (color) payload.sourceColor = color; }
                    const field = child(content, 'placement');
                    if (field) {
                        const value = get(content, 'placement', true);
                        if (value !== 'above' && value !== 'below') refuse(type === 'Pedal' ? 'native-pedal-placement' : 'native-hairpin-placement', 'Uninterpreted explicit source relation placement.', field.location);
                        budget.add('markings', 1, field.location);
                        payload.placement = { source: field.location, value: value as 'above' | 'below' };
                        if (type === 'Pedal') payload.placement.origin = 'source';
                    }
                    if (type === 'HairPin') {
                        if (Number(capture.nativeVersion) < 4.4 && !payload.placement) {
                            const style = styleValues.get('hairpinPlacement');
                            if (style) payload.placement = { source: style.source, value: style.value as 'above' | 'below', origin: 'source-style' };
                        } else if (Number(capture.nativeVersion) >= 4.4) {
                            const direction = child(content, 'direction');
                            if (direction) {
                                if (direction.children.length || Object.keys(direction.attrs).length) refuse('native-hairpin-direction', 'Hairpin direction requires one plain native value.', direction.location);
                                const value = get(content, 'direction', true);
                                if (!['auto', 'up', 'down'].includes(value)) refuse('native-hairpin-direction', 'Uninterpreted modern hairpin direction.', direction.location);
                                if (field) refuse('native-hairpin-direction', 'Concurrent placement/direction overrides need an independently verified ordering policy.', direction.location);
                                budget.add('markings', 1, direction.location);
                                payload.sourceDirection = { source: direction.location, value: value as 'auto' | 'up' | 'down' };
                                if (value !== 'auto') payload.placement = { source: direction.location, value: value === 'up' ? 'above' : 'below', origin: 'source-direction' };
                                else performanceGap('native-hairpin-auto-side', direction.location, 'Source AUTO direction remains located. Its native voice, instrument and centering-dependent printed side is not inferred from the legacy placement preference.');
                            }
                        }
                    }
                }
                if (type === 'HammerOnPullOff') {
                    const color = readColor(content); if (color) payload.sourceColor = color;
                    for (const segment of children(content, 'HammerOnPullOffSegment')) {
                        if (segment.text.trim() || Object.keys(segment.attrs).some(name => name !== 'no')) refuse('native-hopo-segment', 'H/P segment requires one bounded source index.', segment.location);
                        integer(segment.attrs.no ?? '0', 0, 10000, segment.location); used.add(segment); budget.add('markings', 1, segment.location);
                        for (const label of children(segment, 'HammerOnPullOffText')) {
                            if (label.text.trim() || Object.keys(label.attrs).some(name => name !== 'idx')) refuse('native-hopo-segment', 'H/P label requires its source region index.', label.location);
                            integer(label.attrs.idx ?? '0', 0, 10000, label.location); used.add(label);
                            const style = get(label, 'style'); if (style && style !== 'hammer_on_pull_off') refuse('native-hopo-text', 'Unqualified H/P text style.', label.location);
                            decoration(label);
                        }
                        for (const field of segment.children) if (['o1', 'o2', 'o3', 'o4'].includes(field.name)) {
                            if (field.children.length || field.text.trim() || Object.keys(field.attrs).sort().join(',') !== 'x,y') refuse('native-hopo-segment', 'H/P curve handles require inert x/y points.', field.location);
                            geometryScalar(field.attrs.x, field); geometryScalar(field.attrs.y, field); omit(field, 'native-hopo-curve-geometry');
                        }
                        decoration(segment);
                    }
                }
                if (['Tie', 'Slur', 'HammerOnPullOff'].includes(type)) {
                    const up = get(content, 'up');
                    if (up && !['0', '1', '2', 'auto', 'up', 'down'].includes(up)) refuse('native-relation-curve', 'Unknown authored slur/tie curve direction.', content.location);
                    if (up === '1' || up === 'up') payload.orientation = 'over'; else if (up === '2' || up === 'down') payload.orientation = 'under';
                }
                const lineStyles = children(content, 'lineStyle');
                for (const field of lineStyles) use(field);
                if (lineStyles.some(field => field.children.length || field.text.trim() !== lineStyles[0].text.trim())) refuse('native-line-style', 'Conflicting repeated relation line styles are ambiguous.', content.location);
                const lineStyle = lineStyles[0]?.text.trim() ?? '';
                if (lineStyles.length > 1) performanceGap('native-repeated-line-style', content.location, 'Identical repeated source line styles resolve to one value; every original occurrence remains captured.', 'inferred');
                if (lineStyle) {
                    const styles: Record<string, NonNullable<SpanPayload['lineType']>> = { solid: 'solid', dashed: 'dashed', dotted: 'dotted', '1': 'solid', '2': 'dashed', '3': 'dotted', '4': 'dashed', '5': 'dotted', '6': 'dashed' };
                    if (!Object.hasOwn(styles, lineStyle)) refuse('native-line-style', 'Uninterpreted native relation line style.', content.location);
                    payload.lineType = styles[lineStyle];
                    if (['4', '5'].includes(lineStyle)) performanceGap('native-complex-line-style', content.location, 'The source dash-dot pattern is retained byte-exact; MusicXML exports the dashed or dotted relation that MuseScore 4 reads for it, with this engraving difference explicit.');
                }
                for (const side of ['begin', 'end'] as const) {
                    const hook = get(content, `${side}HookType`), height = get(content, `${side}HookHeight`);
                    if (hook) {
                        const value = integer(hook, 0, 6, content.location);
                        if (value > 2 && type !== 'Pedal') refuse('native-line-hook', 'This authored line hook needs an explicit standard representation.', content.location);
                        payload[side === 'begin' ? 'startHook' : 'endHook'] = !value ? 'none'
                            : lineHookDirection(content, type, height ? scalar(height, content) : undefined, qualifiedLineHook(content, side));
                        if (type === 'Volta' && side === 'end') payload.closed = value !== 0;
                        if (value === 2 && type !== 'Pedal') performanceGap('native-diagonal-hook', content.location, 'The source diagonal hook is retained; MusicXML bracket exports its directional hook without the native 45-degree angle.');
                    }
                }
                if (type === 'Pedal') {
                    const startHook = int(content, 'beginHookType', 0, 6, 0), endHook = int(content, 'endHookType', 0, 6, 0), line = payload.lineVisible !== false;
                    if (!payload.placement) {
                        const style = styleValues.get('pedalPlacement');
                        budget.add('markings', 1, style?.source ?? content.location);
                        payload.placement = { source: style?.source ?? content.location, value: style?.value === 'above' ? 'above' : 'below', origin: style ? 'source-style' : 'native-default' };
                    }
                    const beginField = child(content, 'beginText'), endField = child(content, 'endText');
                    payload.pedalState = { startHook, endHook,
                        beginText: beginField ? { value: payload.beginText ?? '', origin: 'source', source: beginField.location } : pedalDefault(startHook ? 'pedalHookText' : 'pedalText'),
                        endText: endField ? { value: payload.endText ?? '', origin: 'source', source: endField.location } : pedalDefault(line ? 'pedalEndText' : 'pedalRosetteEndText') };
                    payload.beginText = payload.pedalState.beginText.value; payload.endText = payload.pedalState.endText.value;
                    for (const [side, name] of [['beginText', startHook ? 'pedalHookText' : 'pedalText'], ['endText', line ? 'pedalEndText' : 'pedalRosetteEndText']] as const) {
                        const styled = styleValues.get(name);
                        if (payload.pedalState[side].origin === 'source-style' && styled?.runs) { (payload.textRuns ??= {})[side] = styled.runs; budget.add('markings', styled.runs.length, styled.source); }
                    }
                    payload.lineVisible = line;
                    const sizes = children(content, 'beginFontSize');
                    if (sizes.length === 1 && sizes[0].text.length <= 65536 && !sizes[0].children.length && !Object.keys(sizes[0].attrs).length) {
                        const field = sizes[0], rawValue = field.text, token = rawValue.trim();
                        use(field); budget.add('markings', 1, field.location);
                        const value = /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(token) && Number(token) > 0 && Number(token) <= 10_000 ? Number(token) : undefined;
                        const size: NonNullable<MusicalRelation['textFontSizes']>['beginText'] = { source: field.location, rawValue, ...(value !== undefined ? { value } : {}), origin: 'source-property' };
                        const dependency = defaultFontDependency;
                        if (value !== undefined && beginSizeContext && !!nativeTextLoader
                            && dependency && !dependency.repeated && !dependency.field.children.length && !Object.keys(dependency.field.attrs).length && dependency.field.text.trim() === '0') {
                            use(dependency.field);
                            size.pointSize = { value, origin: 'source-context', context: 'musescore-3.3.4-default-text', spatiumDependent: { source: dependency.field.location, value: false, origin: 'source-style' } };
                        } else if (!(textLineCaptionSizeProfile && value !== undefined && textLinePointDependency
                            && captionSizeFields(content, 'beginText', 'beginFontSize', payload.beginText) && !/^(?:Ped\.|Sost\.|S)$/.test(payload.beginText ?? '')))
                            deferCaptionGap(content,'native-pedal-begin-size-context', field.location, 'The literal requested BEGIN size remains located. Only the temporary DEFAULT Text with explicit unscaled default-font context and no inline size/vertical override establishes a standard point-size hint; no scaled, absent or unknown context is guessed.');
                        (payload.textFontSizes ??= {}).beginText = size;
                    } else if (sizes.length) deferCaptionGap(content,'native-pedal-begin-size-shape', sizes[0].location, 'Unexamined or repeated requested BEGIN size definitions remain byte-exact in the source; no effective point-size is guessed.');
                    for (const [field, property] of [['beginText', 'beginFontStyle'], ['continueText', 'continueFontStyle'], ['endText', 'endFontStyle']] as const) {
                        const encoded = child(content, property), style = styleValues.get('pedalFontStyle');
                        if (!encoded && !style) continue;
                        if (encoded && (encoded.children.length || Object.keys(encoded.attrs).length)) refuse('native-pedal-font-style', 'Pedal emphasis requires one plain native font-style bit field.', encoded.location);
                        if (encoded) use(encoded);
                        const source = encoded?.location ?? style!.source;
                        (payload.textFontStyles ??= {})[field] = { source, value: integer(encoded?.text.trim() ?? style!.value, 0, 15, source), origin: encoded ? 'source' : 'source-style' };
                        budget.add('markings', 1, source);
                    }
                }
                if (type === 'TextLine') {
                    // Every 3.x/4.x TextLineBase applies these bits to each
                    // ordinary caption. An absent property supplies no fact;
                    // inline/string/font contexts retain their prior limits.
                    for (const [field, property] of [['beginText', 'beginFontStyle'], ['continueText', 'continueFontStyle'], ['endText', 'endFontStyle']] as const) {
                        const definitions = children(content, property);
                        if (!definitions.length) continue;
                        const captions = children(content, field), encoded = definitions[0], caption = captions[0];
                        const plain = (node: Element): boolean => !node.children.length && !Object.keys(node.attrs).length && !node.hasComment && !node.cdata;
                        const qualified = !!nativeTextLoader
                            && !Object.keys(content.attrs).length && definitions.length === 1 && plain(encoded) && plainFontStyle(encoded)
                            && captions.length === 1 && plain(caption) && !!caption.text.trim() && !/[<>\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(caption.text)
                            && payload[field] === caption.text;
                        if (!qualified) {
                            deferCaptionGap(content,'native-text-line-emphasis-context', encoded.location, 'Explicit TextLine caption style remains exact in source capture. Only a plain ordinary caption and unique font-style scalar establish located emphasis; absent, compound, inline or glyph contexts are not guessed.');
                            continue;
                        }
                        use(encoded); budget.add('markings', 1, encoded.location);
                        (payload.textFontStyles ??= {})[field] = { source: encoded.location, value: Number(encoded.text.trim()), origin: 'source' };
                    }
                }
                if (textLineCaptionSizeProfile && !Object.keys(content.attrs).length && ['TextLine', 'HairPin', 'Pedal'].includes(type)) {
                    // Temporary TextLineBase captions use DEFAULT Text, whose
                    // unit dependency is independent of the line's own style.
                    for (const [field, property] of [['beginText', 'beginFontSize'], ['continueText', 'continueFontSize'], ['endText', 'endFontSize']] as const) {
                        const fields = captionSizeFields(content, field, property, payload[field]);
                        const sizeField = fields?.sizeField ?? defaultHairpinCaptionSizeField(content, field, property, payload[field], payload.textFacts?.[field]);
                        if (!sizeField) continue;
                        const captionText = fields?.caption.text ?? payload[field]!;
                        const rawValue = sizeField.text, token = rawValue.trim();
                        const value = /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(token) && Number.isFinite(Number(token)) && Number(token) > 0 && Number(token) <= 10_000 ? Number(token) : undefined;
                        const size: NonNullable<MusicalRelation['textFontSizes']>['beginText'] = { source: sizeField.location, rawValue, ...(value !== undefined ? { value } : {}), origin: 'source-property' };
                        const standardSign = type === 'Pedal' && (field === 'beginText' && /^(?:Ped\.|Sost\.|S)$/.test(captionText) || field === 'endText' && captionText === '*');
                        const existing = payload.textFontSizes?.[field];
                        if (existing && (value === undefined || !textLinePointDependency || standardSign)) continue;
                        if (!existing) { use(sizeField); budget.add('markings', 1, sizeField.location); }
                        if (value !== undefined && textLinePointDependency && !standardSign) {
                            use(textLinePointDependency); budget.add('markings', 1, textLinePointDependency.location);
                            size.pointSize = { value, origin: 'source-context', context: 'musescore-3.6.2-text-line-default-text',
                                spatiumDependent: { source: textLinePointDependency.location, value: false, origin: 'source-style' } };
                        } else deferCaptionGap(content,'native-text-line-caption-size-context', sizeField.location, 'The exact requested caption size remains located. Only a positive bounded request, independently encoded unscaled temporary DEFAULT Text context and qualified words caption establish a standard point-unit hint. Standard Pedal signs, absent, scaled, ambiguous or invalid size contexts are not guessed; BEGIN nonpositive size is not valid native effective size.');
                        (payload.textFontSizes ??= {})[field] = size;
                        performanceGap('native-text-line-caption-size', sizeField.location, 'The explicit caption size request and any independently qualified point-unit hint remain source-owned. Native magnification, font metrics and exact layout are separate; continuation size is retained without inventing native system-break repetition.', 'preserved');
                    }
                }
                if (type === 'HairPin') {
                    const encoded = child(content, 'beginFontStyle'), caption = child(content, 'beginText');
                    let value: number | undefined;
                    if (encoded) {
                        if (encoded.children.length || Object.keys(encoded.attrs).length) refuse('native-hairpin-font-style', 'Initial hairpin emphasis requires one plain native font-style bit field.', encoded.location);
                        use(encoded); value = integer(encoded.text.trim(), 0, Number(capture.nativeVersion) < 4 ? 7 : 15, encoded.location);
                    }
                    const text = caption && (child(caption, 'text') ?? caption);
                    const generated = !caption && ['2', '3'].includes(subtype ?? '0') && !!payload.beginText
                        && styleValues.get(subtype === '2' ? 'hairpinCrescText' : 'hairpinDecrescText')?.plainCaption !== false
                        && !payload.beginText.includes('<') && !/[\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(payload.beginText);
                    if (payload.beginText && (text && isOrdinaryCaption(text, payload.beginText) || generated)) {
                        const inherited = styleValues.get('hairpinFontStyle'), selectors = [...hairpinDefaultSelectors.values()];
                        const plainSelector = (selector: { field: Element; repeated: boolean } | undefined, expected: string) => !!selector && !selector.repeated && !selector.field.children.length && !Object.keys(selector.field.attrs).length && selector.field.text.trim() === expected;
                        // Hairpin captions start Italic in every 3.x/4.x built-in and
                        // legacy resource. Only a malformed selector leaves it unresolved.
                        const qualifiedDefault = !selectors.length || selectors.every(selector => plainSelector(selector, selector.field.text.trim()));
                        if (encoded || inherited || qualifiedDefault) {
                            const source = encoded?.location ?? inherited?.source ?? content.location;
                            (payload.textFontStyles ??= {}).beginText = { source, value: value ?? (inherited ? Number(inherited.value) : 2), origin: encoded ? 'source' : inherited ? 'source-style' : 'native-default' };
                            budget.add('markings', 1, source);
                            if (text) {
                                const runs: InlineRuns = { values: [], emphasized: false, limits: new Set() };
                                if (plainText(text, caption!.location, runs) !== payload.beginText) refuse('native-hairpin-caption', 'Initial hairpin runs disagree with the literal source caption.', caption!.location);
                                if (runs.emphasized) {
                                    budget.add('markings', runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), caption!.location);
                                    (payload.textRuns ??= {}).beginText = runs.values;
                                }
                            }
                        } else deferCaptionGap(content,'native-hairpin-default-style', selectors[0]?.field.location ?? content.location, 'The initial literal caption remains exact. Its native default profile or selector combination has no independently qualified hairpin emphasis rule; a default font style is not guessed.');
                    } else if (payload.beginText) deferCaptionGap(content,'native-hairpin-caption-emphasis-context', encoded?.location ?? payload.textFacts!.beginText!.source, 'The exact initial caption and encoded style remain source-located. Glyph, typeface and superscript/subscript contexts need independent projection authority; their emphasis is not guessed from ordinary words.');
                }
                if (type === 'Ottava') {
                    const octaves: Record<string, NonNullable<SpanPayload['octaves']>> = { '0': 1, '1': -1, '2': 2, '3': -2, '4': 3, '5': -3, '8va': 1, '8vb': -1, '15ma': 2, '15mb': -2, '22ma': 3, '22mb': -3 };
                    if (subtype && !octaves[subtype]) refuse('native-ottava', 'Unknown native octave-shift subtype.', content.location);
                    payload.octaves = octaves[subtype ?? '0'];
                    const numbersOnly = get(content, 'numbersOnly'); if (numbersOnly) { integer(numbersOnly, 0, 1, content.location); performanceGap('native-ottava-label', content.location, 'Source octave-line label styling is retained; MusicXML uses its standard size and direction.'); }
                }
                if (type === 'Volta') {
                    const endings = get(content, 'endings', true);
                    if (!/^\d{1,2}(?:\s*,\s*\d{1,2}){0,15}$/.test(endings)) refuse('native-ending', 'Expected bounded explicit ending numbers.', content.location);
                    const values = endings.split(',').map(s => integer(s.trim(), 0, 99, content.location));
                    if (new Set(values).size !== values.length) refuse('native-ending', 'Duplicate ending number.', content.location);
                    payload.sourceNumbers = { source: child(content, 'endings')!.location, values };
                    payload.numbers = values.filter(value => value > 0);
                    if (!payload.numbers.length || values.includes(0) && payload.beginText?.replace(/[.\s]/g, '') !== payload.numbers.join(',')) refuse('native-ending', 'An engine-only zero ending requires an independently encoded unambiguous positive printed label.', content.location);
                    if (values.includes(0)) performanceGap('native-ending-engine-zero', child(content, 'endings')!.location, 'The source stores zero in its execution ending set while explicitly printing only the positive ending numbers. Exact encoded and printed roles remain separate; no zeroth performer label is invented.');
                    payload.closed ??= false;
                }
                if (type === 'Trill') {
                    const form = subtype === '0' ? 'trill' : subtype === 'pure' ? 'prallprall' : subtype || 'trill';
                    if (!['trill', 'upprall', 'downprall', 'prallprall'].includes(form)) refuse('native-trill', 'Unknown source trill-line subtype.', content.location);
                    payload.trillForm = form as NonNullable<SpanPayload['trillForm']>;
                    const ornament = child(content, 'Ornament'), directAccidentals = children(content, 'Accidental');
                    if (ornament || directAccidentals.length) {
                        budget.add('markings', ornament ? 1 : 0, content.location);
                        payload.trillOrnament = readOrnament(content, ornament, [...directAccidentals, ...(ornament ? children(ornament, 'Accidental') : [])], true,anchor.textScale,anchor.event);
                    }
                }
                const velocityChange = get(content, 'veloChange'), changeMethod = get(content, 'veloChangeMethod'), play = get(content, 'play');
                if (type === 'NoteLine' && play && integer(play, 0, 1, content.location)) performanceGap('native-note-line-playback', child(content, 'play')!.location, 'The authored software playback switch remains a located fact; the performer export preserves the visual note connection without inventing glissando or engine scheduling.');
                const singleNoteDynamics = type === 'HairPin' ? get(content, 'singleNoteDynamics') : '', scope = type === 'HairPin' ? get(content, 'dynType') : '', voiceAssignment = type === 'HairPin' ? get(content, 'voiceAssignment') : '';
                if (voiceAssignment && !['currentVoiceOnly', 'allInStaff'].includes(voiceAssignment)) refuse('native-relation-voice', 'Unknown source relation voice assignment.', content.location);
                if (velocityChange || changeMethod || play || singleNoteDynamics || scope || voiceAssignment) {
                    payload.performance = { source: content.location,
                        ...(velocityChange ? { velocityChange: integer(velocityChange, -127, 127, content.location) } : {}),
                        ...(changeMethod ? { changeMethod } : {}), ...(play ? { play: integer(play, 0, 1, content.location) === 1 } : {}),
                        ...(singleNoteDynamics ? { singleNoteDynamics: integer(singleNoteDynamics, 0, 1, content.location) === 1 } : {}),
                        ...(scope ? { scope: ['staff', 'part', 'system'][integer(scope, 0, 2, content.location)] as NonNullable<MusicalRelation['performance']>['scope'] } : {}),
                        ...(voiceAssignment ? { voiceAssignment: voiceAssignment as 'currentVoiceOnly' | 'allInStaff' } : {}) };
                    if (changeMethod && !['normal', 'ease-in', 'ease-out', 'ease-in-out', 'exponential'].includes(changeMethod)) refuse('native-hairpin-method', 'Uninterpreted native velocity interpolation method.', content.location);
                    if (Number(velocityChange) !== 0 || changeMethod && changeMethod !== 'normal' || play === '0' || singleNoteDynamics || scope || voiceAssignment) performanceGap('native-relation-performance', content.location, 'The authored relation playback/interpolation and assignment settings remain located result facts; MusicXML retains the standard musical relation without promising the native engine scheduler.');
                }
                const niente = get(content, 'hairpinCircledTip'); if (niente) payload.niente = integer(niente, 0, 1, content.location) === 1;
                const encodedTicks = child(content, 'ticks'); if (encodedTicks) {
                    use(encodedTicks); const value = encodedTicks.text.trim();
                    payload.sourceDuration = { source: encodedTicks.location, value: value.includes('/') ? mul(fraction(value, encodedTicks), q(4)) : q(integer(value, 0, 1_000_000_000, encodedTicks.location), division) };
                    if (payload.sourceDuration.value.n < 0) refuse('native-relation-clock', 'Encoded relation duration cannot be negative.', encodedTicks.location);
                }
                for (const c of content.children) if (!(used.has(c) && /^(?:begin|continue|end)FontSize$/.test(c.name) || type === 'TextLine' && /^(?:begin|continue|end)FontStyle$/.test(c.name) && used.has(c)) && (/^(?:begin|continue|end)(?:Font(?:Face|Size|Style)|Text(?:Align|Position|Offset|Place)|(?:Filled|Line)Arrow(?:Width|Height))$/.test(c.name)
                    || ['diagonal', 'dashLineLength', 'dashGapLength', 'hairpinHeight', 'hairpinContHeight', 'beginHookHeight', 'endHookHeight'].includes(c.name))) omit(c, 'native-relation-engraving');
                for (const segment of children(content, 'Segment')) {
                    if (!['HairPin', 'Pedal', 'Volta', 'TextLine', 'NoteLine', 'Glissando', 'Ottava', 'Trill','GuitarBend'].includes(type) && !nativeTechniqueLines.has(type)) refuse('native-segment', 'Segment owner needs a scoped source rule.', segment.location);
                    readSegment(segment, type, payload, anchor.textScale);
                }
                if(payload.modernBend?.labels){const fonts=payload.modernBend.labels.map(label=>plainTextFontXml(label));if(fonts.some(font=>font!==fonts[0]))performanceGap('native-bend-label-system-style',content.location,'Different source system segments use different generated-label fonts. MusicXML bend has one font style per musical bend, with no per-system label font selection. Exact segment label facts remain separate; no system break or competing musical bend is invented.');}
                decoration(content);
            }
            for (const endpoint of [next, prev]) if (endpoint) { use(endpoint); const location = child(endpoint, 'location', true)!; use(location); for (const field of location.children) {
                if (!['staves', 'voices', 'measures', 'fractions', 'notes', 'grace'].includes(field.name)) refuse('native-location', `Unsupported endpoint coordinate ${field.name}.`, field.location);
                use(field);
            } }
            links.push({ element: spanner, anchor, type, next, prev, subtype, payload });
        }
    };
    const repeatPointSize=createNativeGlyphSizeProjector(glyphStyleScopes,capture.nativeVersion,use);
    const repeatSignVoices=new Map<Element,number>();
    const repeatExpansions=new Map<Element,ReturnType<typeof expandNativeMeasureRepeats>>();
    for(const staff of children(scoreNode,'Staff')){
        const expansion=expandNativeMeasureRepeats(primaryMeasures(staff),{findings,use,consume:node=>omit(node,'native-measure-repeat-source-shell'),readSign:(sign,voice)=>{
            repeatSignVoices.set(sign,voice);
            if(sign.text.trim()||Object.keys(sign.attrs).length)refuse('native-measure-repeat','Repeat sign must have plain source-owned properties.',sign.location);
            use(sign);budget.add('markings',1,sign.location);sourceTrack(sign,integer(staff.attrs.id,1,256,staff.location),voice);
            const subtype=get(sign,'subtype'),encoded=subtype?integer(subtype,0,4,sign.location):1,count=encoded||1;
            if(![1,2,4].includes(count)||sign.name==='RepeatMeasure'&&count!==1)refuse('native-measure-repeat','Unsupported native repeat pattern size.',sign.location);
            const durationType=get(sign,'durationType');if(durationType&&durationType!=='measure')refuse('native-measure-repeat','Measure repeat must retain whole-measure duration.',sign.location);
            const duration=get(sign,'duration',Number(capture.nativeVersion)>=4);if(duration&&fraction(duration,sign).n<=0)refuse('native-measure-repeat','Measure repeat duration must be positive.',sign.location);
            const visible=get(sign,'visible'),sourceColor=readColor(sign),small=get(sign,'small');
            for(const field of sign.children)if(['numberPos','measureRepeatNumberPos'].includes(field.name)){geometryScalar(field.text.trim(),field);omit(field,'native-measure-repeat-number-position');}
            decoration(sign);
            return {source:sign.location,count:count as 1|2|4,...(small?{small:{source:child(sign,'small')!.location,value:integer(small,0,1,sign.location)===1}}:{}),...(visible?{printObject:integer(visible,0,1,sign.location)===1}:{}),...(sourceColor?{sourceColor}:{})};
        },projectSign:(fact,sign,part,staff,measure)=>{
            const definition=part.measures[measure].staffs!.find(s=>s.number===staff)!;
            const scale:NativeTextScaleContext={scope:'staff',source:definition.source,staffSize:definition.staffSize};
            if(fact.small?.value){
                const field=glyphStyleScopes.flatMap(s=>children(s,'smallNoteMag')).at(-1);let multiplier=.7;
                if(field){if(field.children.length||Object.keys(field.attrs).length)refuse('native-measure-repeat-small','Small-note magnification must be a plain source scalar.',field.location);geometryScalar(field.text.trim(),field);multiplier=Number(field.text.trim());if(multiplier<=0)refuse('native-measure-repeat-small','Small-note magnification must be positive.',field.location);use(field);}
                fact.fontSize=repeatPointSize(sign,multiplier,scale);
                if(!fact.fontSize)performanceGap('native-measure-repeat-small',sign.location,'The small repeat sign retains its source flag, but its actual staff-space size is not qualified.');
            }
            readAttachedImages(sign,{partId:part.id,measure,position:q(0),staff,voiceId:String((staff-1)*4+repeatSignVoices.get(sign)!+1),sourceKind:sign.name as 'MeasureRepeat'|'RepeatMeasure'},scale);
            for(const symbol of sign.children.filter(c=>['Symbol','FSymbol'].includes(c.name)))for(const glyph of readGlyphs(symbol,undefined,false,[],scale))(part.measures[measure].directions??=[]).push({source:symbol.location,staff,position:q(0),kind:'symbol',symbol:glyph,...(fact.printObject!==undefined?{printObject:fact.printObject}:{})});
        }});
        repeatExpansions.set(staff,expansion);
    }
    for (const staff of children(scoreNode, 'Staff')) {
        use(staff);
        const globalStaff = integer(staff.attrs.id, 1, 256, staff.location), owner = staffOwners.get(globalStaff);
        if (!owner) return refuse('native-staff', 'Music references an undeclared staff.', staff.location);
        const { part } = owner; let definition = owner.definition;
        let staffSize = definition.staffSize;
        let time: MusicalMeasure['time'] = { beats: 4, unit: 4 }, key: NonNullable<StaffFact['key']> = { fifths: 0, mode: 'major' }, clef = definition.clef, clefBadge = definition.clefBadge, clefPrintObject: boolean | undefined;
        let stretch = q(1), stretchSource = definition.source;
        let timeSource: Element['location'] | undefined;
        const trillMeters = trillAttachmentProfile ? new Map<Element['location'], Element>() : undefined;
        let trillClockSafe = trillAttachmentProfile && definition.kind === 'pitched';
        const initialClefRoles = new Map<Element, NonNullable<StaffChange['clefRole']>>();
        const readAttribute = (e: Element, position: Rational, measureDuration?: Rational): StaffChange => {
            use(e); budget.add('timelines', 1, e.location);
            const courtesy = get(e, 'isCourtesy'), legacyAnnouncement = Number(capture.nativeVersion) <= 4 && (e.name === 'TimeSig' && position.n > 0 || e.name === 'KeySig' && !!measureDuration && equal(position, measureDuration));
            const encodedCourtesy = courtesy ? integer(courtesy, 0, 1, e.location) === 1 : undefined;
            const change: StaffChange = { source: e.location, position, staff: definition.number, ...(legacyAnnouncement || encodedCourtesy !== undefined ? { courtesy: legacyAnnouncement || encodedCourtesy,
                courtesyFact: { source: legacyAnnouncement ? e.location : child(e, 'isCourtesy')!.location, ...(encodedCourtesy !== undefined ? { encoded: encodedCourtesy } : {}), origin: legacyAnnouncement ? 'native-positive-clock-announcement' : 'source-isCourtesy' } } : {}) };
            const visible = get(e, 'visible'); if (visible) change.printObject = integer(visible, 0, 1, e.location) === 1;
            if (e.name === 'TimeSig') {
                change.time = { beats: int(e, 'sigN', 1, 128), unit: int(e, 'sigD', 1, 1024) };
                if (change.printObject !== undefined) change.time.printObject = change.printObject;
                const subtype = get(e, 'subtype'); if (subtype) { const value = integer(subtype, 0, 2, e.location); if (value) change.time.symbol = value === 1 ? 'common' : 'cut'; }
                const textBeats = get(e, 'textN'), textUnit = get(e, 'textD');
                if (textBeats) change.time.textBeats = textBeats; if (textUnit) change.time.textUnit = textUnit;
                const stretchN = get(e, 'stretchN'), stretchD = get(e, 'stretchD');
                change.stretch = q(stretchN ? integer(stretchN, 1, 100000, e.location) : 1, stretchD ? integer(stretchD, 1, 100000, e.location) : 1);
                const groups = child(e, 'Groups'); if (groups) {
                    use(groups); const nodes = children(groups, 'Node'); budget.add('markings', nodes.length, groups.location);
                    if (nodes.length > 1024) refuse('native-beam-groups', 'Authored meter beam group count exceeds its bounded profile.', groups.location);
                    const seen = new Set<number>();
                    change.time.beamGroups = nodes.map(node => {
                        use(node); const position = integer(node.attrs.pos, 0, 8192, node.location), action = integer(node.attrs.action, 0, 819, node.location);
                        if (seen.has(position) || node.text.trim() || node.children.length) refuse('native-beam-groups', 'Ambiguous beam grouping position or payload.', node.location); seen.add(position);
                        const breaks: [number, number, number] = [action & 15, action >> 4 & 15, action >> 8 & 15];
                        if (breaks.some(value => value > 3)) refuse('native-beam-groups', 'Unknown authored beam grouping action.', node.location);
                        return { source: node.location, position: q(position, 8), breaks };
                    });
                }
            } else if (e.name === 'KeySig') {
                const mode = get(e, 'mode') || 'major';
                if (!['major', 'minor', 'dorian', 'phrygian', 'lydian', 'mixolydian', 'aeolian', 'ionian', 'locrian', 'none', 'unknown'].includes(mode)) refuse('native-key', 'Unsupported key mode.', e.location);
                const custom = child(e, 'custom'); if(custom)integer(get(e,'custom'),0,1,custom.location);
                const actual = int(e, 'actualKey', -7, 7, int(e, 'concertKey', -7, 7, int(e, 'accidental', -7, 7, 0)));
                change.key = { fifths: sourceView?.concertPitch ? int(e, 'concertKey', -7, 7, actual) : actual, mode: mode === 'unknown' ? '' : mode };
                if (custom) change.key.custom = { source: custom.location, value: true,encoded:custom.text.trim()==='1' };
                const keyColor=readColor(e);if(keyColor)change.key.sourceColor=keyColor;
                readNativeCustomKey(e,change.key,{nativeVersion:capture.nativeVersion,clef:nativeClefInfo(clef,capture.nativeVersion)!,consume:node=>{used.add(node);},add:node=>budget.add('markings',1,node.location),findings});
                if (change.printObject !== undefined) (change.key as NonNullable<StaffFact['key']>).printObject = change.printObject;
            } else {
                const transposing = get(e, 'transposingClefType'), concert = get(e, 'concertClefType'), subtype = get(e, 'subtype');
                change.clef = qualifyNativeClef((sourceView?.concertPitch ? concert || transposing : transposing || concert) || subtype || clef,e.location,findings,capture.nativeVersion);
                if (change.clef === 'G8vbp') change.clefBadge = { source: child(e, sourceView?.concertPitch && concert ? 'concertClefType' : transposing ? 'transposingClefType' : concert ? 'concertClefType' : 'subtype')?.location ?? e.location, value: 'optional-octave-below' };
                const role = initialClefRoles.get(e); if (role) change.clefRole = role;
            }
            for (const c of e.children) if (['showCourtesySig', 'showCourtesyClef', 'showCourtesy', 'forInstrumentChange', 'clefToBarlinePos'].includes(c.name)) omit(c, 'native-attribute-engraving-control');
            decoration(e); return change;
        };
        const applyAttribute = (change: StaffChange) => {
            if (change.courtesy) { performanceGap('native-courtesy-engraving', change.source, 'The source courtesy announcement is retained as a located inactive timeline fact; it is not serialized as an active MusicXML attribute change.'); return; }
            if (change.time) { time = change.time; timeSource = change.source; stretch = change.stretch ?? q(1); stretchSource = change.source; }
            if (change.key) key = change.key; if (change.clef) { clef = change.clef; clefBadge = change.clefBadge; clefPrintObject = change.printObject; }
        };
        readFrames(staff, part.id, definition.number, credits);
        const sourceMeasures = repeatExpansions.get(staff)!.measures;
        if (trillClockSafe && children(staff, 'Measure').some(measure => children(measure, 'multiMeasureRest').length)) trillClockSafe = false;
        let lyricStaffClockSafe = lyricCaptionProfile && lyricDivisionPlain;
        let mi = 0;
        for (const sourceMeasure of sourceMeasures) {
            use(sourceMeasure);
            const sourceVoices = children(sourceMeasure, 'voice');
            const trillRows: SourceTrillRow[] | undefined = trillAttachmentProfile ? [] : undefined;
            const trillTupletClocks: SourceTrillTupletClock[] | undefined = trillAttachmentProfile ? [] : undefined;
            const trillCursorClocks: SourceTrillCursorClock[] | undefined = trillAttachmentProfile ? [] : undefined;
            const trillPairClocks: SourceTrillPairClock[] | undefined = trillAttachmentProfile ? [] : undefined;
            const trillNeutralClocks: SourceTrillNeutralClock[] | undefined = trillAttachmentProfile ? [] : undefined;
            const recordTrillNeutral = trillNeutralClocks ? (node: Element, owner: Element, role: SourceTrillNeutralClock['role'], voice?: number): void => {
                if (trillNeutralClockRole(node, role)) trillNeutralClocks.push({node,owner,role,voice});
            } : undefined;
            if (!sourceVoices.length || sourceVoices.length > 4) refuse('native-voice', 'Expected one to four encoded native voices.', sourceMeasure.location);
            if (lyricCaptionProfile) {
                if (sourceVoices.slice(1).some(voice => children(voice, 'TimeSig').length)
                    || sourceVoices.some(voice => children(voice, 'TimeSig').some(signature => !plainLyricTiming(signature)))) lyricStaffClockSafe = false;
                if (staff === masterStaff && (!sourceVoices[0].children.every(plainLyricTiming)
                    || sourceMeasure.attrs.len !== undefined && !/^\d+\/[1-9]\d*$/.test(sourceMeasure.attrs.len))) lyricClockUnsafeFrom = Math.min(lyricClockUnsafeFrom, mi);
            }
            const voices: MusicalEvent[][] = [], directions: Direction[] = [], barlines: NonNullable<MusicalMeasure['barlines']> = [], changes: StaffChange[] = [];
            if (mi === 0) {
                // Source role qualification is confined to the examined initial pair.
                // Active staff state still follows every literal attribute in source order.
                const candidates: { node: Element; voice: number; index: number }[] = [];
                let count = 0;
                for (let vi = 0; vi < sourceVoices.length; vi++) {
                    const nodes = sourceVoices[vi].children;
                    for (let index = 0; index < nodes.length; index++) {
                        const node = nodes[index]; if (node.name === 'Chord' || node.name === 'Rest') break;
                        if (node.name === 'Clef') { count++; if (candidates.length < 3) candidates.push({ node, voice: vi, index }); }
                    }
                }
                if (count > 1) {
                    const [first, last] = candidates;
                    // Before 4.10 the loader guesses the header from source order;
                    // from 4.10 the saved isHeader tag is authoritative.
                    const legacy = Number(capture.nativeVersion) < 4.1, current = !legacy;
                    const flags = candidates.map(({ node }) => {
                        const fields = children(node, 'isHeader'), field = fields[0];
                        const valid = fields.length <= 1 && (!field || !field.children.length && !Object.keys(field.attrs).length && ['0', '1'].includes(field.text.trim()));
                        return { field, valid, value: field?.text.trim() === '1' };
                    });
                    let ordered = count === 2 && first.voice === last.voice && first.index === 0 && last.index > 1;
                    let signatures = 0;
                    if (ordered) for (let index = 1; index < last.index; index++) {
                        const node = sourceVoices[first.voice].children[index];
                        if (node.name === 'KeySig' || node.name === 'TimeSig') signatures++; else ordered = false;
                    }
                    const clefValue = (node: Element) => (sourceView?.concertPitch ? text(node, 'concertClefType') || text(node, 'transposingClefType') : text(node, 'transposingClefType') || text(node, 'concertClefType')) || text(node, 'subtype');
                    const distinct = clefValue(first.node) && clefValue(last.node) && clefValue(first.node) !== clefValue(last.node);
                    const qualifiedFlags = flags.every(flag => flag.valid) && (legacy ? flags.every(flag => !flag.field) : current && !!flags[0].field && flags[0].value && !flags[1].value);
                    const ordinaryRoles = candidates.every(({ node }) => !children(node, 'clefToBarlinePos').length
                        && children(node, 'isCourtesy').every(field => field.text.trim() === '0') && children(node, 'forInstrumentChange').every(field => field.text.trim() === '0'));
                    if (ordered && signatures && distinct && ordinaryRoles && ![clefValue(first.node), clefValue(last.node)].includes('G8vbp') && qualifiedFlags) {
                        for (let index = 0; index < 2; index++) {
                            const { node } = candidates[index], flag = flags[index];
                            if (flag.field) use(flag.field);
                            initialClefRoles.set(node, { source: flag.field?.location ?? node.location, value: index === 0 ? 'header' : 'change',
                                origin: legacy ? 'native-source-order' : flag.field ? 'source-isHeader' : 'native-default', ...(flag.field ? { encoded: flag.value } : {}) });
                        }
                        performanceGap('native-initial-clef-role', first.node.location, 'The qualified initial source header and ordinary same-clock clef are retained separately. MusicXML presents the header followed by the actual source change after the barline; active clef and note clocks are unchanged.', 'preserved');
                    } else performanceGap('native-initial-clef-role-limit', first.node.location, 'Multiple initial source clefs remain located timeline facts, but this profile/order/header-flag context does not qualify the separate header projection. No header, clock or source-view choice is inferred.');
                }
            }
            const deferredFermatas: { fermata: NonNullable<MusicalEvent['fermata']>; position: Rational; voice: number }[] = [];
            const segmentFermatas: NonNullable<MusicalMeasure['segmentFermatas']> = [];
            const typeChange = child(sourceMeasure, 'StaffTypeChange'); if (typeChange) {
                if (typeChange.text.trim() || Object.keys(typeChange.attrs).length || children(typeChange,'StaffType').length!==1) refuse('native-staff-type-change','Staff change needs one complete source-owned type.',typeChange.location);
                use(typeChange); budget.add('timelines',1,typeChange.location); const type=child(typeChange,'StaffType',true)!;
                const recovered=readNativeStaffType(type,{use,omit,smallMagnification:styleValues.get('smallStaffMag'),readColor}); used.add(type);
                definition={...definition,...recovered,source:type.location}; if(!recovered.sourceColor)delete definition.sourceColor; if(!recovered.lineVisibility)delete definition.lineVisibility; if(!recovered.tablature)delete definition.tablature; if(!recovered.noteheadScheme)delete definition.noteheadScheme; staffSize=recovered.staffSize;
                if(definition.kind==='tablature') definition.tuning=owner.definition.tuning??part.tuning??part.staves!.find(s=>s.tuning)?.tuning;
                else delete definition.tuning;
                decoration(typeChange);
                const eid = child(typeChange, 'eid'); if (eid) { if (eid.children.length || Object.keys(eid.attrs).length || !eid.text.trim() || eid.text.length > 256) refuse('native-identity-budget', 'Staff-change identity must be bounded plain data.', eid.location); omit(eid, 'native-staff-change-editor-identity'); }
            }
            // Only leading attributes establish the initial snapshot. Later changes keep their actual clock.
            for (const voice of sourceVoices) {
                for (const e of voice.children) {
                if (['TimeSig', 'KeySig', 'Clef'].includes(e.name)) {
                    const change = readAttribute(e, q(0)); changes.push(change); applyAttribute(change);
                    if (trillMeters && e.name === 'TimeSig' && !change.courtesy && voice === sourceVoices[0] && trillMeterClock(e, time)) trillMeters.set(e.location, e);

                }
                if (e.name === 'Chord' || e.name === 'Rest' || e.name === 'location' && text(e, 'fractions') && fraction(text(e, 'fractions'), e).n !== 0) break;
                }
            }
            const initialTime = { ...time }, initialTimeSource = timeSource, initialKey = { ...key }, initialClef = clef, initialClefBadge = clefBadge, initialClefPrintObject = clefPrintObject, initialStretch = stretch, initialStretchSource = stretchSource;
            const nominalDuration = mul(q(time.beats * 4, time.unit), q(stretch.d, stretch.n));
            const measureDuration = sourceMeasure.attrs.len ? mul(fraction(sourceMeasure.attrs.len, sourceMeasure), q(4)) : nominalDuration;
            if (measureDuration.n <= 0) refuse('native-measure-clock', 'Declared measure length must have a positive exact clock.', sourceMeasure.location);
            for (const item of sourceMeasure.children) if (item.name === 'Marker' || item.name === 'Jump') {
                use(item); budget.add('markings', 1, item.location);
                const textNode = child(item, 'text'), label = get(item, 'label'), visible = get(item, 'visible'), placement = get(item, 'placement');
                if (placement && !['above', 'below'].includes(placement)) refuse('native-navigation-placement', 'Uninterpreted source navigation placement.', item.location);
                if (label.length > 256) refuse('native-navigation-label', 'Navigation label exceeds the bounded identity profile.', item.location);
                const navigation: NonNullable<Direction['navigation']> = { source: item.location, kind: item.name === 'Marker' ? 'marker' : 'jump', ...(label ? { label } : {}) };
                const markerType = child(item, 'markerType'); if (markerType) {
                    const value = get(item, 'markerType');
                    if (item.name !== 'Marker' || markerType.children.length || !['segno', 'varsegno', 'codab', 'varcoda', 'codetta', 'fine', 'coda', 'codasym', 'dacoda', 'dadblcoda', 'user'].includes(value)) refuse('native-marker-type', 'Uninterpreted encoded navigation marker role.', markerType.location);
                    navigation.markerType = { source: markerType.location, value };
                }
                const glyphs = textNode ? children(textNode, 'sym') : [], glyph = glyphs.length === 1 ? glyphs[0].text.trim() : undefined;
                if (glyph && ['segno', 'segnoSerpent1', 'coda'].includes(glyph) && textNode!.children.length === 1 && !textNode!.text.trim()) navigation.glyph = glyph;
                const text = textNode ? plainText(textNode) : '';
                let kind: Direction['kind'] = navigation.glyph === 'coda' ? 'coda' : navigation.glyph?.startsWith('segno') ? 'segno' : 'words';
                if (item.name === 'Jump') {
                    kind = 'words';
                    for (const field of ['jumpTo', 'playUntil', 'continueAt'] as const) { navigation[field] = get(item, field, true); if (navigation[field]!.length > 256) refuse('native-navigation-label', 'Navigation target exceeds the bounded identity profile.', item.location); }
                    const repeats = get(item, 'playRepeats'); if (repeats) navigation.playRepeats = integer(repeats, 0, 1, item.location) === 1;
                }
                const atEnd = item.name === 'Jump' || label === 'fine';
                const align = get(item, 'align'), horizontal = get(item, 'position'), textAlignment: NonNullable<Direction['textAlignment']> = { source: item.location };
                if (align) {
                    const match = /^(left|center|right),(top|center|bottom|baseline)$/.exec(align);
                    if (!match) refuse('native-navigation-alignment', 'Uninterpreted source navigation text alignment.', item.location);
                    textAlignment.justify = match![1] as NonNullable<Direction['textAlignment']>['justify']; textAlignment.valign = match![2] === 'center' ? 'middle' : match![2] as NonNullable<Direction['textAlignment']>['valign'];
                    if (Number(capture.nativeVersion) < 4.7) { textAlignment.halign = textAlignment.justify; textAlignment.halignOrigin = 'derived-legacy-align'; }
                }
                if (horizontal) { if (capture.nativeVersion !== '4.70' || !['left', 'center', 'right'].includes(horizontal)) refuse('native-navigation-alignment', 'Unexercised source navigation horizontal-position role.', item.location); textAlignment.halign = horizontal as NonNullable<Direction['textAlignment']>['halign']; textAlignment.halignOrigin = 'source-position'; }
                const sourceColor = readColor(item);
                directions.push({ ...(sourceColor ? { sourceColor } : {}), source: item.location, position: atEnd ? measureDuration : q(0), positionOrigin: atEnd ? 'native-measure-end' : 'native-measure-start', staff: definition.number, kind, text, navigation,
                    ...(align || horizontal ? { textAlignment } : {}),
                    ...(visible ? { printObject: integer(visible, 0, 1, item.location) === 1 } : {}), ...(placement ? { placement: placement as 'above' | 'below' } : {}) });
                decoration(item);
            }
            for (let vi = 0; vi < sourceVoices.length; vi++) {
                const sourceVoice = sourceVoices[vi]; use(sourceVoice);
                const lyricVoiceClockSafe = lyricStaffClockSafe && mi < lyricClockUnsafeFrom && plainLyricVoice(sourceVoice);
                const events: MusicalEvent[] = []; let position = q(0), eventOrdinal = 0;
                const ordinaryAtRelease = new Map<string, MusicalEvent | undefined>();
                const figures: NonNullable<MusicalEvent['figuredBass']> = [];
                time = initialTime; timeSource = initialTimeSource; key = initialKey; clef = initialClef; clefPrintObject = initialClefPrintObject; stretch = initialStretch; stretchSource = initialStretchSource;
                // Earlier serialized voices establish staff-wide timelines. Merge them into
                // this voice's monotonic cursor without repeatedly scanning all attributes.
                const priorChanges = changes.filter(change => !change.courtesy && change.position.n > 0).sort((a, b) => compare(a.position, b.position));
                let priorChange = 0;
                let pendingFermata: MusicalEvent['fermata'];
                let pendingFermataPosition = q(0);
                const deferFermata = () => { if (pendingFermata) deferredFermatas.push({ fermata: pendingFermata, position: pendingFermataPosition, voice: vi }); pendingFermata = undefined; };
                const pendingGrace: MusicalEvent[] = [];
                let pendingTremolo: { event: MusicalEvent; displayed: Rational; strokes: number; source: Element; trillClock?: SourceTrillPairClock } | undefined;
                let pendingBeam: MusicalEvent['beam'];
                const tuplets: { actual: number; normal: number; element: Element; first?: MusicalEvent; last?: MusicalEvent; printObject?: boolean; sourceTrack?: number; trillClock?: SourceTrillTupletClock; appearance: Pick<NonNullable<MusicalEvent['tupletBoundary']>[number], 'actual' | 'normal' | 'numberType' | 'bracketType' | 'direction' | 'numberCache'> }[] = [];
                for (const e of sourceVoice.children) {
                    readObjectLink(e, part, definition.number, globalStaff, mi, vi, position);
                    if (used.has(e)) continue;
                    while (priorChange < priorChanges.length && compare(priorChanges[priorChange].position, position) <= 0) applyAttribute(priorChanges[priorChange++]);
                    const anchor: Anchor = { textScale:{scope:'staff',source:definition.source,staffSize}, part, staff: definition.number, globalStaff, measure: mi, voice: vi, position, noteIndex: 0, graceIndex: -1 };
                    if (['TimeSig', 'KeySig', 'Clef'].includes(e.name)) {
                        const change = readAttribute(e, position, measureDuration); changes.push(change); applyAttribute(change);
                    } else if (e.name === 'Beam') {
                        use(e); budget.add('markings', 1, e.location);
                        if (pendingBeam) refuse('native-beam', 'Beam geometry has no unambiguous following owner.', e.location);
                        pendingBeam = { source: e.location, mode: 'auto' };
                        const left = get(e, 'growLeft'), right = get(e, 'growRight'), visible = get(e, 'visible');
                        if (left) pendingBeam.growLeft = scalar(left, e, 100);
                        if (right) pendingBeam.growRight = scalar(right, e, 100);
                        if (visible) pendingBeam.visible = integer(visible, 0, 1, e.location) === 1;
                        const sourceColor = readColor(e); if (sourceColor) pendingBeam.sourceColor = sourceColor;
                        const direction = get(e, 'StemDirection'); if (direction) {
                            if (!['auto', 'up', 'down'].includes(direction)) refuse('native-beam-stem', 'Unknown source beam-owned stem direction.', e.location);
                            pendingBeam.stemDirection = { source: child(e, 'StemDirection')!.location, value: direction as 'auto' | 'up' | 'down' };
                        }
                        const beamMove = get(e, 'crossStaffMove'); if (beamMove) {
                            pendingBeam.crossStaffMove = integer(beamMove, -1, 1, e.location);
                            performanceGap('native-beam-cross-staff-geometry', e.location, 'The source beam displacement remains a located beam fact, separate from each chord staffMove. Standard beam membership is exported; native between-staff beam geometry is not imposed on the consumer.');
                        }
                        for (const c of e.children) if (['Fragment', 'distribute', 'noSlope', 'l1', 'l2'].includes(c.name)) omit(c, 'native-beam-geometry');
                        decoration(e);
                        recordTrillNeutral?.(e,sourceVoice,'beam-distribution',vi);
                        recordTrillNeutral?.(e,sourceVoice,'beam-autoplace',vi);
                    } else if (e.name === 'Fermata') {
                        use(e); budget.add('markings', 1, e.location);
                        const subtype = get(e, 'subtype', true), shape = /Short/.test(subtype) ? 'angled' : /VeryLong/.test(subtype) ? 'double-square' : /Long/.test(subtype) ? 'square' : 'normal';
                        if (!/^fermata(?:Short|Long|VeryLong)?(?:Above|Below)$/.test(subtype) || pendingFermata) refuse('native-fermata', 'Uninterpreted or overlapping fermata.', e.location);
                        const stretch = get(e, 'timeStretch'), visible = get(e, 'visible'), placement = get(e, 'placement');
                        if (placement && !['above', 'below'].includes(placement)) refuse('native-fermata-placement', 'Uninterpreted fermata placement.', e.location);
                        pendingFermataPosition = position;
                        pendingFermata = { source: e.location, shape, inverted: placement ? placement === 'below' : subtype.endsWith('Below'), ...(placement ? { placement: { source: child(e, 'placement')!.location, value: placement as 'above' | 'below' } } : {}), ...(stretch ? { playbackStretch: scalar(stretch, e) } : {}), ...(visible ? { printObject: integer(visible, 0, 1, e.location) === 1 } : {}) }; decoration(e);
                    } else if (e.name === 'Breath') {
                        use(e); budget.add('markings', 1, e.location);
                        const symbol = get(e, 'symbol', true), symbols: Record<string, NonNullable<MusicalEvent['breath']>['shape']> = { breathMarkComma: 'comma', breathMarkTick: 'tick', breathMarkUpbow: 'upbow', breathMarkSalzedo: 'salzedo', caesura: 'normal', caesuraThick: 'thick', caesuraShort: 'short', caesuraCurved: 'curved', caesuraSingleStroke: 'single', chantCaesura: 'single' };
                        const previous = ordinaryAtRelease.get(clockKey(position));
                        if (!Object.hasOwn(symbols, symbol) || !previous || previous.breath) return refuse('native-breath', 'Breath needs one exact ordinary release owner in its source measure/voice and a known symbol.', e.location);
                        const pause = get(e, 'pause'), visible = get(e, 'visible'), placement = get(e, 'placement'), placementNode = child(e, 'placement');
                        if (placementNode && !['above', 'below'].includes(placement)) refuse('native-breath-placement', 'Uninterpreted breath placement.', placementNode.location);
                        previous.breath = { source: e.location, kind: symbol.startsWith('caesura') || symbol === 'chantCaesura' ? 'caesura' : 'breath-mark', shape: symbols[symbol],
                            placement: { source: placementNode?.location ?? e.location, value: placementNode ? placement as 'above' | 'below' : vi % 2 ? 'below' : 'above', origin: placementNode ? 'source' : 'native-default' },
                            ownership: { source: e.location, logicalStaff: { source: staff.location, number: definition.number }, voice: { source: sourceVoices[vi].location, id: String((definition.number - 1) * 4 + vi + 1) }, releasePosition: position,
                                host: { source: previous.source, eventId: previous.id, printedStaff: previous.staff! }, origin: 'native-source-release-track' },
                            ...(pause ? { pause: scalar(pause, e) } : {}), ...(visible ? { printObject: integer(visible, 0, 1, e.location) === 1 } : {}) }; decoration(e);
                        if (previous.staff !== definition.number) performanceGap('native-breath-cross-staff-projection', e.location,
                            'The logical source staff/voice, exact ordinary release clock and real host printed staff remain located ownership facts. Standard breath/caesura notation attaches to that host note; it cannot independently select the native mark staff or certify physical placement. Raw displacement/autoplace remains separate; no relocation or duplicate mark is invented.');
                        if (pause) performanceGap('native-breath-scheduler', e.location, 'The printed breath/caesura and authored pause are retained. MusicXML notation does not encode this engine-specific pause duration; written clocks are unchanged.');
                    } else if (e.name === 'Tuplet') {
                        use(e); const actual = int(e, 'actualNotes', 1, 128), normal = int(e, 'normalNotes', 1, 128);
                        get(e, 'baseNote'); const encodedTrack = get(e, 'track'), sourceTupletTrack = encodedTrack ? integer(encodedTrack, 0, 1023, e.location) : undefined;
                        if (sourceTupletTrack !== undefined && (sourceTupletTrack % 4 !== vi || staffOwners.get(Math.floor(sourceTupletTrack / 4) + 1)?.part !== part)) refuse('native-tuplet-track', 'Tuplet display anchorage must resolve to the same source part and voice slot.', e.location);
                        const appearance: typeof tuplets[number]['appearance'] = { actual, normal };
                        for (const [name, vocabulary] of [['numberType', ['actual', 'both', 'none']], ['bracketType', ['auto', 'yes', 'no']]] as const) {
                            const field = child(e, name); if (!field) continue; if (field.children.length || Object.keys(field.attrs).length) refuse('native-tuplet-display', 'Tuplet display fields require plain source scalars.', field.location);
                            use(field); const index = integer(field.text.trim(), 0, 2, field.location);
                            if (name === 'numberType') appearance.numberType = { source: field.location, value: vocabulary[index] as 'actual' | 'both' | 'none' }; else appearance.bracketType = { source: field.location, value: vocabulary[index] as 'auto' | 'yes' | 'no' };
                        }
                        const direction = child(e, 'direction'); if (direction) { if (direction.children.length || Object.keys(direction.attrs).length || !['auto', 'up', 'down'].includes(direction.text.trim())) refuse('native-tuplet-display', 'Uninterpreted source tuplet direction.', direction.location); use(direction); appearance.direction = { source: direction.location, value: direction.text.trim() as 'auto' | 'up' | 'down' }; }
                        const number = child(e, 'Number'); if (number) {
                            const numberText = child(number, 'text'), visible = child(number, 'visible'); appearance.numberCache = { source: number.location, origin: 'renderer-cache', ...(numberText ? { text: plainText(numberText) } : {}), ...(visible ? { printObject: integer(get(number, 'visible'), 0, 1, visible.location) === 1 } : {}) };
                            const expected = appearance.numberType?.value === 'both' ? `${actual}:${normal}` : appearance.numberType?.value === 'none' ? '' : String(actual);
                            if (appearance.numberCache.text !== undefined && appearance.numberCache.text !== expected) performanceGap('native-tuplet-number-cache', number.location, 'The stored Number text remains located renderer-cache data. Native layout regenerates its numeral from the individual unreduced actual/normal count and numberType; the stale/custom cache is not promoted to authored musical authority.');
                            omit(number, 'native-tuplet-number-appearance');
                        }
                        for (const c of e.children) if (['p1', 'p2'].includes(c.name)) omit(c, 'native-tuplet-geometry'); decoration(e);
                        if (tuplets.length >= 16) refuse('native-tuplet-budget', 'More than 16 nested tuplets exceed the supported notation profile.', e.location);
                        const visible = get(e, 'visible');
                        const trillClock: SourceTrillTupletClock | undefined = trillTupletClocks ? {node:e,actual,normal,voice:vi,end:undefined} : undefined;
                        if (trillClock) trillTupletClocks!.push(trillClock);
                        tuplets.push({ actual, normal, element: e, sourceTrack: sourceTupletTrack, appearance, ...(trillClock ? {trillClock} : {}), ...(visible ? { printObject: integer(visible, 0, 1, e.location) === 1 } : {}) });
                    } else if (e.name === 'endTuplet') { use(e); const number = tuplets.length, tuplet = tuplets.pop(); if (tuplet?.trillClock) tuplet.trillClock.end=e; if (!tuplet?.last) refuse('native-tuplet', 'Unmatched or empty tuplet end.', e.location); else (tuplet.last.tupletBoundary ??= []).push({ type: 'stop', number, printObject: tuplet.printObject, source: tuplet.element.location, sourceTrack: tuplet.sourceTrack, ...tuplet.appearance }); }
                    else if (e.name === 'location') { use(e); const f = get(e, 'fractions', true), before = position, delta = mul(fraction(f, e), q(4)); position = add(before, delta);
                        if (trillCursorClocks) trillCursorClocks.push({node:e,fraction:child(e,'fractions')!,voice:vi,before,delta,after:position});
                        if (position.n < 0) refuse('native-clock', 'Voice cursor moved before measure start.', e.location); const timeTick = get(e, 'timeTick'); if (timeTick) { integer(timeTick, 0, 1, e.location); performanceGap('native-time-tick-editor-anchor', e.location, 'The native time-tick editor anchor flag remains captured; its exact cursor movement is recovered without creating a musical event.'); } }
                    else if (e.name === 'Chord' || e.name === 'Rest') {
                        budget.add('events', 1, e.location);
                        use(e);
                        sourceTrack(e, globalStaff, vi);
                        const graceTags = e.children.filter(c => ['appoggiatura', 'acciaccatura', 'grace4', 'grace16', 'grace32', 'grace8after', 'grace16after', 'grace32after'].includes(c.name));
                        if (graceTags.length > 1 || graceTags.length && e.name !== 'Chord') refuse('native-grace', 'Ambiguous grace kind/owner.', e.location);
                        const grace = graceTags[0]; if (grace) { use(grace); anchor.graceIndex = pendingGrace.length; }
                        const fullMeasureRest = get(e, 'durationType', true) === 'measure', type = fullMeasureRest ? 'whole' : text(e, 'durationType');
                        const dots = int(e, 'dots', 0, 4, 0), base = Object.hasOwn(durationTypes, type) ? durationTypes[type] : undefined;
                        if (!base) return refuse('native-duration', `Unsupported note type ${type}.`, e.location);
                        let duration = fullMeasureRest ? mul(measureDuration, stretch) : mul(base, q(2 ** (dots + 1) - 1, 2 ** dots));
                        const displayedDuration = duration;
                        const tremolos = e.children.filter(c => ['Tremolo', 'TremoloSingleChord', 'TremoloTwoChord'].includes(c.name));
                        if (tremolos.length > 1 || tremolos.length && (e.name !== 'Chord' || grace || pendingTremolo)) refuse('native-tremolo', 'Overlapping tremolo or unsupported grace/rest owner.', e.location);
                        const tremolo = tremolos[0];
                        let tremoloStrokes = 0, tremoloPair = false, tremoloVisible: boolean | undefined;
                        if (tremolo) {
                            use(tremolo); budget.add('markings', 1, tremolo.location);
                            const subtype = get(tremolo, 'subtype', true), match = /^([rc])(8|16|32|64)$/.exec(subtype);
                            if (!match) return refuse('native-tremolo', `Unsupported tremolo subtype ${subtype}.`, tremolo.location);
                            tremoloStrokes = Math.log2(Number(match[2])) - 2; tremoloPair = match[1] === 'c';
                            const visible = get(tremolo, 'visible'); if (visible) tremoloVisible = integer(visible, 0, 1, tremolo.location) === 1;
                            if (tremolo.name === 'TremoloSingleChord' && tremoloPair || tremolo.name === 'TremoloTwoChord' && !tremoloPair) refuse('native-tremolo', 'Tremolo container and subtype disagree.', tremolo.location);
                            for (const c of tremolo.children) if (['strokeStyle', 'Fragment'].includes(c.name)) omit(c, 'native-tremolo-engraving');
                            decoration(tremolo);
                        }
                        const pair = !grace && (tremoloPair || !!pendingTremolo);
                        if (pair && (fullMeasureRest || e.name !== 'Chord' || pendingTremolo && !equal(pendingTremolo.displayed, displayedDuration))) refuse('native-tremolo', 'Two-chord tremolo requires adjacent equally valued ordinary chords.', e.location);
                        const encodedDuration = get(e, 'duration');
                        let encodedElapsed: Rational | undefined;
                        if (fullMeasureRest && !encodedDuration && !equal(stretch, q(1))) refuse('native-local-rest-default', 'A locally stretched full-measure rest needs an encoded value or independently verified producer default; no whole-bar duration is fabricated.', e.location);
                        if (encodedDuration) {
                            const explicit = mul(fraction(encodedDuration, e), q(4));
                            if (trillPairClocks) encodedElapsed = explicit;
                            if (pair && !equal(explicit, mul(duration, q(1, 2)))) refuse('native-duration', 'Paired tremolo explicit duration contradicts its verified half-value convention.', e.location);
                            if (explicit.n <= 0) refuse('native-duration', 'Encoded elapsed duration must be positive.', e.location);
                            duration = explicit;
                        } else if (pair) refuse('native-tremolo', 'Paired tremolo requires an independently corroborated encoded elapsed value.', e.location);
                        // Grace values describe their printed notes; they are not members of the elapsed tuplet clock.
                        const memberships = grace ? [] : tuplets;
                        let ratio = pair ? q(1, 2) : q(1);
                        for (const tuplet of memberships) { duration = mul(duration, q(tuplet.normal, tuplet.actual)); ratio = mul(ratio, q(tuplet.normal, tuplet.actual)); }
                        // Native locations are elapsed coordinates. Only ordinary note values
                        // are divided by the active source staff stretch; grace remains unclocked.
                        const localStretch = !grace && !equal(stretch, q(1));
                        if (localStretch) duration = mul(duration, q(stretch.d, stretch.n));
                        const sourceEid = get(e, 'eid');
                        if (sourceEid.length > 256) refuse('native-identity-budget', 'Source editor identity exceeds the bounded field profile.', e.location);
                        const event: MusicalEvent = { source: e.location, id: `native-event:${globalStaff}:${mi}:${vi}:${eventOrdinal++}`, ...(sourceEid ? { sourceEid } : {}), start: position, duration, type, dots, notes: [], fullMeasureRest,
                            staff: definition.number, voiceId: String((definition.number - 1) * 4 + vi + 1), ...(memberships.length || pair ? { tuplet: { actual: ratio.d, normal: ratio.n } } : {}) };
                        if (e.name === 'Rest') event.dotFacts = readDots(e, dots);
                        if (localStretch) {
                            event.staffTiming = { source: stretchSource, stretch }; event.writtenDuration = displayedDuration;
                            if (!fullMeasureRest) { const cumulative = mul(ratio, q(stretch.d, stretch.n)); event.timeModification = { actual: cumulative.d, normal: cumulative.n }; }
                        }
                        const chordSmall = child(e, 'small'); if (chordSmall) { use(chordSmall); event.small = { source: chordSmall.location, value: integer(chordSmall.text.trim(), 0, 1, chordSmall.location) === 1 }; }
                        if (!fullMeasureRest && encodedDuration && !equal(displayedDuration, mul(fraction(encodedDuration, e), q(4)))) {
                            event.writtenDuration = displayedDuration;
                            event.durationOverride = { source: child(e, 'duration')!.location, encoded: mul(fraction(encodedDuration, e), q(4)), displayed: displayedDuration };
                            if (!pair && !memberships.length && !localStretch) performanceGap('native-display-elapsed-duration', event.durationOverride.source, 'The source explicitly encodes an elapsed duration different from its printed note value. Standard type/dots and duration retain those independent facts; no tuplet, tremolo or time-modification is fabricated from their ratio.', 'inferred');
                        }
                        const encodedBeamMode = get(e, 'BeamMode');
                        const beamMode = Number(capture.nativeVersion) < 4 ? ({ begin32: 'begin16', begin64: 'begin32' } as Record<string, string>)[encodedBeamMode] ?? encodedBeamMode : encodedBeamMode;
                        if (beamMode && !['auto', 'begin', 'mid', 'end', 'no', 'begin16', 'begin32'].includes(beamMode)) refuse('native-beam', `Unsupported source beam mode ${encodedBeamMode}.`, e.location);
                        if (pendingBeam || beamMode) { event.beam = { ...(pendingBeam ?? { source: child(e, 'BeamMode')!.location }), mode: (beamMode || 'auto') as NonNullable<MusicalEvent['beam']>['mode'] }; pendingBeam = undefined; }
                        const staffMove = int(e, 'staffMove', -255, 255, 0);
                        if (staffMove) { const target = definition.number + staffMove; if (!part.staves!.some(s => s.number === target)) refuse('native-cross-staff', 'Staff movement leaves its source part.', e.location); event.staff = target; }
                        if (pair || tremolo) { event.writtenDuration = displayedDuration; (event.ornaments ??= []).push({ source: (tremolo ?? pendingTremolo!.source).location, kind: 'tremolo', type: tremoloPair ? 'start' : pendingTremolo ? 'stop' : 'single', strokes: tremoloStrokes || pendingTremolo!.strokes, ...(tremoloVisible !== undefined ? { printObject: tremoloVisible } : pendingTremolo?.event.ornaments?.[0].printObject !== undefined ? { printObject: pendingTremolo.event.ornaments[0].printObject } : {}) }); }
                        let trillPair: SourceTrillPairClock | undefined;
                        if (trillPairClocks && pair && memberships.length <= 1 && !localStretch && encodedElapsed) {
                            const point = {node:e,event,elapsed:{node:child(e,'duration')!,value:encodedElapsed}};
                            if (tremoloPair) { trillPair = {source:tremolo!,voice:vi,displayed:displayedDuration,first:point,...(memberships.length?{tuplet:memberships[0].trillClock}: {})};trillPairClocks.push(trillPair); }
                            else if (pendingTremolo?.trillClock && pendingTremolo.trillClock.tuplet === memberships[0]?.trillClock) { trillPair = pendingTremolo.trillClock;trillPair.second = point; }
                        }
                        if (tremoloPair) pendingTremolo = { event, displayed: displayedDuration, strokes: tremoloStrokes, source: tremolo!, ...(trillPair ? {trillClock:trillPair} : {}) };
                        else if (pair) pendingTremolo = undefined;
                        if (grace) { event.writtenDuration = duration; event.duration = q(0); event.grace = { source: grace.location, before: !grace.name.endsWith('after'), slash: grace.name === 'acciaccatura', index: pendingGrace.length, hostId: '' }; }
                        if (trillRows) trillRows.push({node:e,event,measure:mi,track:vi,voice:vi,clock:q(0),clockTuplets:memberships.map(t=>t.trillClock!),...(trillPair ? {clockPair:trillPair} : {}),...(fullMeasureRest&&encodedDuration ? {encodedFullRest:{node:child(e,'duration')!,duration}} : {})});
                        if (pendingFermata && (event.grace || event.staff !== definition.number || !equal(pendingFermataPosition, event.start))) deferFermata();
                        if (pendingFermata) { event.fermata = pendingFermata; pendingFermata = undefined; }
                        if (event.fermata?.playbackStretch !== undefined) performanceGap('native-fermata-scheduler', event.fermata.source, 'The printed fermata and authored stretch are retained. MusicXML fermata notation does not encode this engine-specific scheduler factor; written clocks are unchanged.');
                        const eventVisible = get(e, 'visible'); if (eventVisible) event.printObject = integer(eventVisible, 0, 1, e.location) === 1;
                        const stem = get(e, 'StemDirection'); if (stem) { if (!['auto', 'up', 'down'].includes(stem)) refuse('native-stem', 'Unknown source stem direction.', e.location); event.sourceStem = { source: child(e, 'StemDirection')!.location, value: stem as 'auto' | 'up' | 'down' }; if (stem !== 'auto') { event.stem = stem as 'up' | 'down'; event.stemOrigin = { source: child(e, 'StemDirection')!.location, origin: 'source-chord' }; } }
                        readStemGraphics(e, event,recordTrillNeutral ? graphic=>recordTrillNeutral(graphic,e,'hook-drawing',vi) : undefined);
                        for (const [index, tuplet] of memberships.entries()) { if (!tuplet.first) { tuplet.first = event; (event.tupletBoundary ??= []).push({ type: 'start', number: index + 1, printObject: tuplet.printObject, source: tuplet.element.location, sourceTrack: tuplet.sourceTrack, ...tuplet.appearance }); } tuplet.last = event; }
                        const chordLines = children(e, 'ChordLine'); budget.add('markings', chordLines.length, e.location);
                        for (const line of chordLines) {
                            use(line); const subtype = get(line, 'subtype', true), vocabulary: Record<string, NonNullable<MusicalEvent['chordLines']>[number]['kind']> = { '1': 'falloff', '2': 'doit', '3': 'plop', '4': 'scoop' };
                            if (!Object.hasOwn(vocabulary, subtype)) refuse('native-chord-line', 'Unknown native chord-line musical subtype.', line.location);
                            const straight = get(line, 'straight'), wavy = get(line, 'wavy'), play = get(line, 'play'), visible = get(line, 'visible');
                            (event.chordLines ??= []).push({ source: line.location, kind: vocabulary[subtype], ...(straight ? { straight: integer(straight, 0, 1, line.location) === 1 } : {}), ...(wavy ? { wavy: integer(wavy, 0, 1, line.location) === 1 } : {}), ...(play ? { play: integer(play, 0, 1, line.location) === 1 } : {}), ...(visible ? { printObject: integer(visible, 0, 1, line.location) === 1 } : {}) });
                            for (const geometry of line.children) if (['Path', 'lengthX', 'lengthY'].includes(geometry.name)) omit(geometry, 'native-chord-line-geometry');
                            if (play) performanceGap('native-chord-line-playback', line.location, 'The source slide/fall playback switch is retained. MusicXML exports the standard articulation without promising the native pitch-curve scheduler.');
                            decoration(line);
                        }
                        const eventAnchor = { ...anchor, event };
                        const sourceNotes = children(e, 'Note');
                        if (sourceNotes.length > nativeLimits.chordNotes) refuse('native-chord-budget', 'Source chord exceeds the bounded component count.', e.location);
                        budget.add('components', sourceNotes.length, e.location);
                        for (const [ni, n] of sourceNotes.entries()) {
                            use(n);
                            sourceTrack(n, globalStaff, vi);
                            const midi = int(n, 'pitch', 0, 127), tpc = definition.kind === 'percussion' ? int(n, 'tpc', -1, 33, 14) : int(n, 'tpc', -1, 33), encodedTpc2 = get(n, 'tpc2');
                            const sourceEid = get(n, 'eid');
                            if (sourceEid.length > 256) refuse('native-identity-budget', 'Source editor identity exceeds the bounded field profile.', n.location);
                            const identity = { source: n.location, id: `${event.id}:note:${ni}`, ...(sourceEid ? { sourceEid } : {}), tieStart: false, tieStop: false };
                            // Resolve actual note kind and pitch only after every part-wide source instrument change is known.
                            const provisional = { step: 'C', alter: 0, octave: Math.floor(midi / 12) - 1, midi, origin: 'inferred' as const };
                            let note: MusicalNote = { ...identity, kind: 'pitched', sounding: provisional, written: provisional };
                            pendingWritten.push({ note, event, part, source: n, midi, tpc, definition, clef, ...(encodedTpc2 ? { tpc2: integer(encodedTpc2, -1, 33, n.location) } : {}) });
                            const noteheadColor = readColor(n);
                            if (noteheadColor) note.noteheadColor = noteheadColor;
                            note.dotFacts = readDots(n, dots);
                            const dead = child(n, 'dead'); if (dead) {
                                const value = get(n, 'dead');
                                if (dead.children.length || Object.keys(dead.attrs).length) refuse('native-dead-note', 'An explicit dead-note flag requires a plain boolean on a verified non-percussion pitch reference.', dead.location);
                                const isDead = integer(value, 0, 1, dead.location) === 1;
                                note.sourceDead = { source: dead.location, value: isDead };
                                if (isDead && note.kind === 'pitched') {
                                    note.kind = 'dead'; note.referenceSounding = note.sounding!; note.sounding = null;
                                    performanceGap('native-dead-note-projection', dead.location, 'The explicit dead/muted-note technique is retained as a standard unpitched x-headed event with source-written display guidance and physical facts. Encoded MIDI/TPC remains a located reference pitch; it does not claim a sounding pitched attack.');
                                }
                            }
                            const fixed = get(n, 'fixed'), fixedLine = get(n, 'fixedLine');
                            if (fixed || fixedLine) { note.fixedPosition = { source: n.location, fixed: fixed === '1', ...(fixedLine ? { line: integer(fixedLine, -128, 128, n.location) } : {}) }; if (fixed) integer(fixed, 0, 1, n.location); if (fixed === '1') performanceGap('native-fixed-note-position', n.location, 'The source fixed visual staff line remains a located fact independent of encoded pitch; MusicXML exports encoded pitch with this native visual position difference explicit.'); }
                            const sourceVelocity = get(n, 'velocity'), velocityType = get(n, 'veloType');
                            if (velocityType && !['offset', 'user'].includes(velocityType)) refuse('native-note-velocity', 'Unknown native note velocity mode.', n.location);
                            if (sourceVelocity) { note.sourceVelocity = { source: n.location, value: integer(sourceVelocity, -127, 127, n.location), mode: velocityType === 'user' ? 'absolute' : 'offset' }; if (note.sourceVelocity.mode === 'absolute' && note.sourceVelocity.value < 0) refuse('native-note-velocity', 'Absolute source velocity cannot be negative.', n.location); if (note.sourceVelocity.mode === 'offset') performanceGap('native-note-relative-velocity', n.location, 'Authored note velocity offsets remain source facts. Their native dynamic-relative playback needs a verified scheduler mapping; they are not emitted as misleading absolute note dynamics.'); }
                            noteEvents.set(note, event);
                            const play = child(n, 'play'), sourceEvents = child(n, 'Events');
                            if (play || sourceEvents) {
                                note.performance = { source: (sourceEvents ?? play!).location };
                                if (play) { use(play); note.performance.play = integer(play.text.trim(), 0, 1, play.location) === 1; }
                                if (sourceEvents) {
                                    use(sourceEvents); const events = children(sourceEvents, 'Event');
                                    if (events.length > 128) refuse('native-performance-budget', 'A note performance schedule exceeds the bounded component profile.', sourceEvents.location);
                                    budget.add('markings', events.length, sourceEvents.location);
                                    note.performance.events = events.map(p => { use(p); return { source: p.location, pitchOffset: int(p, 'pitch', -127, 127, 0), ontime: int(p, 'ontime', -100000, 100000, 0), length: int(p, 'len', 0, 100000, 1000) }; });
                                    if (!events.length) note.performance.play = false;
                                }
                            }
                            const tuningAdjustment = child(n, 'tuning'); if (tuningAdjustment) {
                                if (tuningAdjustment.children.length || Object.keys(tuningAdjustment.attrs).length) refuse('native-note-tuning', 'Encoded note tuning requires a bounded plain numeric source value.', tuningAdjustment.location);
                                use(tuningAdjustment); (note.performance ??= { source: tuningAdjustment.location }).tuning = { source: tuningAdjustment.location, value: scalar(tuningAdjustment.text.trim(), tuningAdjustment) };
                                performanceGap('native-note-tuning', tuningAdjustment.location, 'The exact encoded note tuning adjustment remains a located source fact, separate from nominal pitch/spelling and performer notation. Software tuning reproduction is not required; no unencoded accidental or pitch correction is invented.');
                            }
                            const noteSmall = child(n, 'small'); if (noteSmall) { use(noteSmall); note.small = { source: noteSmall.location, value: integer(noteSmall.text.trim(), 0, 1, noteSmall.location) === 1 }; }
                            if ((note.small?.value || event.small?.value) && note.performance?.play === false) { note.cue = true; note.cueOrigin = 'derived-small-unplayed'; }
                            const sourceString = get(n, 'string'), fret = get(n, 'fret');
                            if (!!sourceString !== !!fret) refuse('native-physical', 'String and fret must be encoded together.', n.location);
                            if (sourceString) { note.string = integer(sourceString, 0, 15, n.location) + 1; note.fret = integer(fret, 0, 100, n.location);
                                physicalNotes.push({ note, event, part, definition, measure: mi, midi }); }
                            const head = get(n, 'head');
                            if (head) {
                                const shapes: Record<string, string> = { normal: 'normal', cross: 'x', plus: 'cross', xcircle: 'circle-x', 'triangle-up': 'triangle', 'triangle-down': 'inverted triangle', slash: 'slash', diamond: 'diamond', 'diamond-old': 'diamond', circled: 'circled', slashed1: 'slashed', slashed2: 'back slashed' };
                                if (!Object.hasOwn(shapes, head)) refuse('native-notehead', `Unsupported note head ${head}.`, child(n, 'head')!.location);
                                note.sourceNotehead = { source: child(n, 'head')!.location, value: head };
                                if (head !== 'normal') note.notehead = shapes[head];
                            }
                            const headType = get(n, 'headType');
                            const headScheme = child(n, 'headScheme'); if (headScheme) {
                                use(headScheme); note.sourceHeadScheme = readNativeHeadScheme(headScheme);
                            }
                            if (headType && headType !== 'auto') { if (!['quarter', 'half', 'whole', 'breve'].includes(headType)) refuse('native-notehead', 'Unsupported head fill.', n.location); note.sourceHeadType = { source: child(n, 'headType')!.location, value: headType as 'quarter' | 'half' | 'whole' | 'breve' }; note.notehead ??= 'normal'; note.noteheadFilled = headType === 'quarter'; }
                            const noteVisible = get(n, 'visible'); if (noteVisible) note.printObject = integer(noteVisible, 0, 1, n.location) === 1;
                            const parentheses = get(n, 'parentheses'), hideGenerated = get(n, 'hideGeneratedParentheses');
                            if (parentheses || hideGenerated) {
                                if (parentheses && !['none', 'both'].includes(parentheses)) refuse('native-note-parentheses', 'Authored note parentheses need a verified complete enclosure.', n.location);
                                note.noteheadParentheses = { source: child(n, parentheses ? 'parentheses' : 'hideGeneratedParentheses')!.location, ...(parentheses ? { value: parentheses === 'both' } : {}), origin: 'source', ...(hideGenerated ? { hideGenerated: integer(hideGenerated, 0, 1, n.location) === 1, hideGeneratedSource: child(n, 'hideGeneratedParentheses')!.location } : {}) };
                                if (!parentheses) performanceGap('native-generated-parentheses', n.location, 'The authored generated-parenthesis visibility setting remains located. Consumer automatic grouping is not claimed as encoded enclosure authority.');
                            }
                            readAttachedImages(n,{partId:part.id,measure:mi,position:event.start,staff:definition.number,voiceId:event.voiceId,eventId:event.id,noteId:note.id,sourceKind:'Note'},anchor.textScale);
                            const glyphs = n.children.filter(c=>['Symbol','FSymbol'].includes(c.name)).flatMap(symbol => readGlyphs(symbol,undefined,false,[],anchor.textScale));
                            if (glyphs.length) {
                                note.symbols = glyphs;
                                const left = glyphs.filter(g => g.name === 'noteheadParenthesisLeft'), right = glyphs.filter(g => g.name === 'noteheadParenthesisRight');
                                if (left.length === 1 && right.length === 1 && !left[0].parentId && !right[0].parentId && left[0].printObject !== false && right[0].printObject !== false && [left[0],right[0]].every(g=>!g.rotation?.degrees&&!g.sourceColor&&(!g.fontSize||g.fontSize.multiplier===1))) {
                                    if (parentheses === 'none') refuse('native-note-parentheses', 'Explicit enclosure flag contradicts the authored parenthesis glyph pair.', n.location);
                                    if (note.noteheadParentheses?.value === undefined) note.noteheadParentheses = { ...note.noteheadParentheses, source: left[0].source, value: true, origin: 'derived-symbol-pair' };
                                    left[0].projection = right[0].projection = 'notehead-parenthesis';
                                }
                            }
                            const accidental = child(n, 'Accidental');
                            if (accidental) {
                                use(accidental); const subtype = get(accidental, 'subtype', true);
                                const mapped=nativeAccidental(subtype,capture.nativeVersion,accidental.location);
                                note.sourceAccidental={source:accidental.location,name:subtype,...(mapped.cents!==undefined?{centOffset:mapped.cents}:{})};
                                if(!mapped.empty){note.accidental=mapped.name;note.accidentalSmufl=mapped.smufl;}
                                if(mapped.cents!==undefined)note.centOffset={source:accidental.location,value:mapped.cents,origin:'native-accidental'};
                                else performanceGap('native-accidental-cent-authority',accidental.location,'The exact accidental glyph is preserved, but this serializer has no independently qualified cent-offset default for that glyph. No fractional pitch is guessed.');
                                note.accidentalColor=readColor(accidental);
                                const small=get(accidental,'small');if(small){note.accidentalSmall={source:child(accidental,'small')!.location,value:integer(small,0,1,accidental.location)===1};note.accidentalFontSize=accidentalSize(accidental,note.accidentalSmall.value,anchor.textScale,event,note);}
                                const role = get(accidental, 'role'); if (role) { note.accidentalRole = integer(role, 0, 1, accidental.location) === 1 ? 'user' : 'auto'; if (note.accidentalRole === 'user') { note.accidentalCautionary = true; performanceGap('native-user-accidental-projection', accidental.location, 'The explicit native user accidental role is retained. MusicXML carries cautionary=yes as the exporter-compatible choice; native data does not distinguish cautionary from editorial intention.'); } }
                                const bracket = get(accidental, 'bracket'); if (bracket) { const kind = integer(bracket, 0, 2, accidental.location); if (kind === 1) note.accidentalParentheses = true; if (kind === 2) note.accidentalBracket = true; }
                                const visible = get(accidental, 'visible'); if (visible) note.accidentalVisible = integer(visible, 0, 1, accidental.location) === 1; decoration(accidental);
                            }
                            const cents=child(n,'centOffset');if(cents){
                                if(Number(capture.nativeVersion)<4.6||cents.children.length||Object.keys(cents.attrs).length)refuse('native-cent-offset','Unqualified source cent-offset property.',cents.location);
                                const value=scalar(cents.text.trim(),cents);use(cents);
                                if(note.sourceAccidental?.centOffset!==undefined&&value!==note.sourceAccidental.centOffset)refuse('native-accidental-cent-conflict','Encoded accidental and cent-offset property contradict each other; no native normalization is silently copied.',cents.location);
                                note.centOffset={source:cents.location,value,origin:'source-property'};
                            }
                            for (const line of children(n, 'ChordLine')) {
                                use(line); budget.add('markings', 1, line.location);
                                const type = integer(get(line, 'subtype', true), 1, 4, line.location), straight = get(line, 'straight'), wavy = get(line, 'wavy'), visible = get(line, 'visible'), play = get(line, 'play');
                                const sourceColor = readColor(line);
                                (note.slides ??= []).push({ source: line.location, kind: (['out-down', 'out-up', 'into-from-above', 'into-from-below'] as const)[type - 1],
                                    lineShape: straight && integer(straight, 0, 1, line.location) ? 'straight' : 'curved', lineType: wavy && integer(wavy, 0, 1, line.location) ? 'wavy' : 'solid',
                                    ...(visible ? { printObject: integer(visible, 0, 1, line.location) === 1 } : {}), ...(sourceColor ? { sourceColor } : {}) });
                                if (play) { integer(play, 0, 1, line.location); performanceGap('native-chord-line-playback', line.location, 'The source software slide playback switch is excluded; its actual note-owned performer slide remains standard notation.'); }
                                for (const geometry of line.children) if (['Path', 'lengthX', 'lengthY'].includes(geometry.name)) omit(geometry, 'native-chord-line-geometry');
                                decoration(line);
                            }
                            const fingerings = children(n, 'Fingering');
                            budget.add('markings', fingerings.length, n.location);
                            for (const f of fingerings) {
                                use(f); const t = child(f, 'text', true)!, runs:InlineRuns={values:[],emphasized:false,limits:new Set()}, value = plainText(t,undefined,runs), style = get(f, 'style');
                                const hand = ['guitar_fingering_lh', 'LH Guitar Fingering'].includes(style) ? 'left' : ['guitar_fingering_rh', 'RH Guitar Fingering'].includes(style) ? 'right' : undefined;
                                const visible = get(f, 'visible'), sourceColor = readColor(f);
                                const finger:NonNullable<MusicalNote['fingerings']>[number]={ source: f.location, ...(hand ? { hand } : {}), value, ...(visible ? { printObject: integer(visible, 0, 1, f.location) === 1 } : {}), ...(sourceColor ? { sourceColor } : {}) };
                                const placement=get(f,'placement');if(placement){if(!['above','below'].includes(placement))refuse('native-fingering-placement','Unknown source fingering placement.',f.location);finger.placement=placement as 'above'|'below';}
                                if(runs.emphasized||runs.values.some(run=>run.sourceFont||run.textFontSize||run.musicFontSize||run.script||run.symbolName))finger.textRuns=runs.values;
                                if(runs.limits.size)deferInline(f,runs,t.location,'native-fingering-inline-appearance');
                                applyPresentation(f,finger,{scope:'staff',source:definition.source,staffSize});
                                if (hand || visible || sourceColor || finger.textRuns || finger.placement || ['textFontFamily','textFontSize','textFontStyle','textEmphasis','textAlignment','textFrameAppearance','textEnclosure'].some(key=>Object.hasOwn(finger,key))) (note.fingerings ??= []).push(finger);
                                else (note.fingering ??= []).push(value);
                                decoration(f);
                            }
                            const bend = child(n, 'Bend');
                            if (bend) {
                                // The dedicated point reader validates every attribute before consumption.
                                note.bend = readLegacyBend(bend, budget, node => node.name === 'point' ? used.add(node) : use(node));
                                note.bend.sourceKind = 'legacy-bend';
                                const sourceColor = readColor(bend); if (sourceColor) note.bend.sourceColor = sourceColor;
                                const visible = get(bend, 'visible'), play = get(bend, 'play');
                                if (visible) note.bend.printObject = integer(visible, 0, 1, bend.location) === 1;
                                if (play) { integer(play, 0, 1, bend.location); performanceGap('native-bend-playback', bend.location, 'The legacy bend playback switch is retained in source capture; its ordered performer curve is preserved independently of scheduler enablement.'); }
                                for (const field of bend.children) if (['fontFace', 'fontSize', 'fontStyle', 'lineWidth'].includes(field.name)) omit(field, 'native-bend-engraving');
                                decoration(bend);
                            }
                            decoration(n); const noteAnchor = { ...eventAnchor, note, noteIndex: ni }; anchors.set(anchorKey(noteAnchor), noteAnchor); registerSpanners(n, noteAnchor);
                            event.notes.push(note);
                        }
                        if (e.name === 'Chord' && !event.notes.length || e.name === 'Rest' && event.notes.length) refuse('native-event', 'Chord/rest note membership is invalid.', e.location);
                        const parenthesisGroups = children(e, 'NoteParenGroup'), enclosedNotes = new Map<string, { id: string; rawIndex: string }>();
                        if (parenthesisGroups.length && (Number(capture.nativeVersion) < 4.6 || event.notes.some(note => note.kind !== 'pitched') || definition.kind === 'tablature' || event.notes.some((note, i) => i && note.written!.midi <= event.notes[i - 1].written!.midi)))
                            refuse('native-note-parenthesis-order', 'Indexed note groups need independently verified standard pitched component ordering; ambiguous unison, TAB and percussion order remains a gap.', parenthesisGroups[0].location);
                        for (const group of parenthesisGroups) {
                            use(group); budget.add('markings', 1, group.location);
                            const noteList = child(group, 'Notes', true)!; use(noteList);
                            const indexes = children(noteList, 'NoteIdx');
                            if (indexes.length !== 1 || group.children.some(node => node !== noteList) || group.text.trim() || noteList.text.trim() || Object.keys(group.attrs).length || Object.keys(noteList.attrs).length) refuse('native-note-parenthesis-group', 'Only the independently exercised single-member group with native default sides is admitted; multi-member/custom sides remain source-located gaps.', group.location);
                            const index = indexes[0]; use(index); budget.add('markings', 1, index.location);
                            const sourceIndex = integer(index.text, 0, event.notes.length - 1, index.location), noteId = event.notes[sourceIndex].id;
                            const previous = enclosedNotes.get(noteId), id = `${event.id}:notehead-group:${event.noteheadGroups?.length ?? 0}`;
                            if (index.children.length || Object.keys(index.attrs).length || previous && (previous.rawIndex !== index.text || event.notes[sourceIndex].noteheadParentheses?.value !== true)) refuse('native-note-parenthesis-group', 'Indexed note enclosure membership is ambiguous.', group.location);
                            if (!previous) enclosedNotes.set(noteId, { id, rawIndex: index.text });
                            (event.noteheadGroups ??= []).push({ source: group.location, id, members: [{ source: index.location, sourceIndex, noteId }], sidesOrigin: 'native-default', ...(previous ? { duplicateOf: previous.id } : {}) });
                            if (previous) performanceGap('native-note-parenthesis-duplicate', group.location, 'The structurally identical default-side single-member group repeats an explicitly enclosed source component. Both definitions and locations remain retained; one effective standard enclosure is emitted.', 'inferred');
                            performanceGap('native-note-parenthesis-default', group.location, 'The indexed source note group has verified native default left/right sides. Standard notehead enclosure preserves its single actual member; default side provenance remains distinct from encoded note flags.', 'inferred');
                        }
                        readAttachedImages(e,{partId:part.id,measure:mi,position:event.start,staff:definition.number,voiceId:event.voiceId,eventId:event.id,sourceKind:e.name==='Rest'?'Rest':'Chord'},anchor.textScale);
                        const glyphs = e.children.filter(c=>['Symbol','FSymbol'].includes(c.name)).flatMap(symbol => readGlyphs(symbol,undefined,false,[],anchor.textScale)); if (glyphs.length) event.symbols = glyphs;
                        const articulations = [...children(e, 'Articulation'), ...children(e, 'Ornament'), ...children(e, 'Tapping')];
                        budget.add('markings', articulations.length, e.location);
                        const techniques: Record<string, NonNullable<MusicalNote['technical']>[number]['kind']> = { stringsUpBow: 'up-bow', stringsDownBow: 'down-bow', stringsHarmonic: 'harmonic', stringsThumbPosition: 'thumb-position', brassMuteClosed: 'stopped', pluckedSnapPizzicatoAbove: 'snap-pizzicato', pluckedSnapPizzicatoBelow: 'snap-pizzicato' };
                        for (const a of articulations) {
                            use(a); const subtype = a.name === 'Tapping' ? 'Tapping' : get(a, 'subtype', true), names = articulationNames(subtype), ornament = a.name === 'Tapping' ? undefined : nativeOrnament(subtype)?.kind, technique = Object.hasOwn(techniques, subtype) ? techniques[subtype] : undefined;
                            let anchor: MarkAnchor | undefined; const anchorNode = child(a, 'anchor');
                            if (anchorNode) {
                                if (anchorNode.children.length || Object.keys(anchorNode.attrs).length) refuse('native-mark-anchor', 'Mark anchor must be a plain source scalar.', anchorNode.location);
                                const legacy = Number(capture.nativeVersion) <= 4, encoded = integer(get(a, 'anchor'), 0, legacy ? 4 : 2, anchorNode.location);
                                const roles: MarkAnchor['role'][] = legacy ? ['top-staff', 'bottom-staff', 'auto', 'top-chord', 'bottom-chord'] : ['top', 'bottom', 'auto'];
                                anchor = { source: anchorNode.location, encoded, role: roles[encoded], placement: encoded === 2 ? 'auto' : encoded === 0 || encoded === 3 ? 'above' : 'below' };
                            }
                            const directionNode = names?.includes('strong-accent') ? child(a, 'direction') : undefined;
                            let strongAccentDirection: NonNullable<MusicalEvent['hiddenMarkings']>[number]['strongAccentDirection'];
                            if (directionNode) {
                                const value = get(a, 'direction');
                                if (directionNode.children.length || Object.keys(directionNode.attrs).length || !['auto', 'up', 'down'].includes(value)) refuse('native-articulation-direction', 'Strong accent direction requires a verified plain source value.', directionNode.location);
                                strongAccentDirection = { source: directionNode.location, value: value as 'auto' | 'up' | 'down' };
                            }
                            const visible = get(a, 'visible'), play = get(a, 'play');
                            if (visible) integer(visible, 0, 1, a.location); if (play) integer(play, 0, 1, a.location);
                            if (['Slap', 'Pop', 'Tapping'].includes(subtype)) {
                                if (!event.notes.length) refuse('native-gesture-owner', 'A playing gesture requires a source chord owner.', a.location);
                                const hand = subtype === 'Tapping' ? get(a, 'hand', true) : undefined;
                                if (hand && !['left', 'right'].includes(hand)) refuse('native-tapping-hand', 'Tapping requires an explicitly encoded performing hand.', a.location);
                                const sourceColor = readColor(a);
                                (event.notes[0].gestures ??= []).push({ source: a.location, kind: subtype === 'Slap' ? 'slap' : subtype === 'Pop' ? 'pop' : 'tap', ...(hand ? { hand: hand as 'left' | 'right' } : {}), ...(visible ? { printObject: visible === '1' } : {}), ...(sourceColor ? { sourceColor } : {}) });
                                decoration(a); continue;
                            }
                            if (Object.hasOwn(techniqueGlyphNames, subtype)) {
                                (event.techniqueGlyphs ??= []).push({ source: a.location, smufl: subtype, ...(anchor ? { anchor } : {}), ...(visible ? { printObject: visible === '1' } : {}), ...(play ? { play: play === '1' } : {}) });
                                decoration(a); continue;
                            }
                            if (ornament) {
                                const details = readOrnament(a, a, children(a, 'Accidental'), false,{scope:'staff',source:definition.source,staffSize},event);
                                (event.ornaments ??= []).push({ source: a.location, kind: ornament, details, ...(anchor ? { anchor } : {}), ...(visible ? { printObject: visible === '1' } : {}) });
                                if (play) performanceGap('native-articulation-playback', a.location, 'The source ornament playback switch remains captured; its standard musical sign is exported without promising the native scheduler enable state.');
                                if (subtype === 'ornamentTrill' && !details.intervalAbove) performanceGap('native-trill-default-neighbor', a.location, 'No explicit ornament interval is encoded. The native automatic-neighbor realization is not established by a bare MusicXML trill mark; source notation and written clocks remain preserved.');
                                continue;
                            }
                            if (visible === '0') {
                                const kind = names ? 'articulation' : ornament ? 'ornament' : technique ? 'technical' : undefined;
                                if (!kind) return refuse('native-hidden-mark', 'Hidden source marking still needs a verified musical vocabulary.', a.location);
                                for (const name of names ?? [ornament ?? technique!]) (event.hiddenMarkings ??= []).push({ source: a.location, nativeSubtype: subtype, kind, name, ...(anchor ? { anchor } : {}), ...(name === 'strong-accent' && strongAccentDirection ? { strongAccentDirection } : {}), ...(play ? { play: play === '1' } : {}) });
                                decoration(a); continue;
                            }
                            if (play) performanceGap('native-articulation-playback', a.location, 'The source articulation playback switch remains captured; its standard musical sign is exported without promising the native scheduler enable state.');
                            if (names) {
                                const owner = event.notes[0] ?? event, index = (owner.articulations?.length ?? 0) + names.indexOf('strong-accent');
                                if (anchor) for (let i = 0; i < names.length; i++) (owner.articulationAnchors ??= []).push({ index: (owner.articulations?.length ?? 0) + i, anchor });
                                if (names.includes('strong-accent') && anchor?.placement !== 'auto' && anchor && (!strongAccentDirection || strongAccentDirection.value === 'auto')) performanceGap('native-strong-accent-anchor-direction', anchor.source, 'The explicit source mark side determines the native AUTO strong-accent glyph orientation. Standard type is derived from that side; raw subtype, anchor and any encoded AUTO direction remain separate facts.', 'inferred');
                                if (strongAccentDirection) (owner.strongAccentDirections ??= []).push({ ...strongAccentDirection, index });
                                (owner.articulations ??= []).push(...names);
                            }
                            else if (technique && event.notes.length) (event.notes[0].technical ??= []).push({ source: a.location, kind: technique, ...(anchor ? { anchor } : {}) });
                            else refuse('native-articulation', `Unsupported articulation ${subtype}.`, a.location);
                            decoration(a);
                        }
                        const arpeggio = child(e, 'Arpeggio');
                        if (arpeggio) {
                            use(arpeggio); budget.add('markings', 1, arpeggio.location);
                            const subtype = int(arpeggio, 'subtype', 0, 5, 0), span = int(arpeggio, 'span', 1, 16, 1), stretch = get(arpeggio, 'timeStretch'), play = get(arpeggio, 'play');
                            if (!event.notes.length) refuse('native-arpeggio', 'Arpeggio needs a source chord owner.', arpeggio.location);
                            const visible = get(arpeggio, 'visible');
                            event.arpeggio = { source: arpeggio.location, span, trackSpan: Number(capture.nativeVersion) < 4.2 ? (span - 1) * 4 + 1 : span, ...(visible ? { printObject: integer(visible, 0, 1, arpeggio.location) === 1 } : {}), ...(subtype === 1 || subtype === 4 ? { direction: 'up' } : subtype === 2 || subtype === 5 ? { direction: 'down' } : {}),
                                ...(subtype === 3 ? { nonArpeggiate: true } : {}), ...(subtype >= 4 ? { straight: true } : {}), ...(stretch ? { playbackStretch: scalar(stretch, arpeggio) } : {}), ...(play ? { play: integer(play, 0, 1, arpeggio.location) === 1 } : {}) };
                            if (subtype >= 4) performanceGap('native-straight-arpeggio', arpeggio.location, 'The source straight arrow style is retained; MusicXML carries the standard arpeggiate direction with this visual difference explicit.');
                            if (stretch || play === '0') performanceGap('native-arpeggio-scheduler', arpeggio.location, 'Source arpeggio scheduling settings remain located facts; MusicXML retains its notation without promising the native playback rollout.');
                            for (const c of arpeggio.children) if (['userLen1', 'userLen2'].includes(c.name)) omit(c, 'native-arpeggio-geometry');
                            decoration(arpeggio);
                        }
                        const lyrics = children(e, 'Lyrics');
                        budget.add('markings', lyrics.length, e.location);
                        for (const lyric of lyrics) { use(lyric); const t = child(lyric, 'text', true)!, runs: InlineRuns = { values: [], emphasized: false, limits: new Set() }, lyricText = plainText(t, undefined, runs), syllabic = get(lyric, 'syllabic') || 'single';
                            if (lyricVoiceClockSafe && e.name === 'Chord' && !event.grace && !localStretch && !staffMove
                                && ordinaryBeamScalar(e, 'staffMove', [undefined, '0']) && closedLyricCaption(lyric) && lyric.location.path) lyricCaptionSources.add(lyric.location.path);
                            const textFontFamily = readTextFamily(lyric); qualifyTextFamilies(runs.values, textFontFamily);
                            const textEmphasis = readTextEmphasis(lyric), textRuns = runs.values.some(run => run.emphasis !== 0 || run.emphasisResets?.length || run.symbolName || run.sourceFont || run.sourceText || run.textFontSize || run.script) ? runs.values : undefined;
                            if (textRuns) budget.add('markings', textRuns.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), t.location);
                            if (runs?.limits.size) deferInline(lyric,runs,t.location,'native-lyric-inline-appearance');
                            if (textRuns?.some(run => run.symbolName)) performanceGap('native-lyric-inline-symbol', t.location, 'The exact source glyph names and semantic Unicode text remain located. Standard lyric text preserves the text fallback, without requiring a particular SMuFL font glyph.');
                            if (!['single', 'begin', 'middle', 'end'].includes(syllabic)) refuse('native-lyrics', 'Unsupported syllabic value.', lyric.location);
                            const ticks = get(lyric, 'ticks'), ticksFraction = get(lyric, 'ticks_f');
                            const fractionalSpan = child(lyric, 'ticks_f') ? mul(fraction(ticksFraction, lyric), q(4)) : undefined;
                            let legacySpan: Rational | undefined;
                            if (child(lyric, 'ticks')) {
                                if (Number(capture.nativeVersion) >= 4.6) refuse('native-lyric-legacy-field', 'This native family no longer defines the obsolete lyric ticks field.', child(lyric, 'ticks')!.location);
                                if (ticks.includes('/')) legacySpan = mul(fraction(ticks, lyric), q(4));
                                else {
                                    const division = child(scoreNode, 'Division');
                                    if (division && integer(division.text.trim(), 1, 9600, division.location) !== 480) refuse('native-lyric-division', 'Legacy integer lyric ticks require an independently exercised source division.', division.location);
                                    legacySpan = q(integer(ticks, -100000000, 100000000, child(lyric, 'ticks')!.location), 480);
                                }
                            }
                            if (fractionalSpan && legacySpan && !equal(fractionalSpan, legacySpan)) refuse('native-lyric-length', 'Encoded lyric length fields contradict each other.', lyric.location);
                            const melismaSpan = fractionalSpan ?? legacySpan;
                            const backwardsPlaceholder = !!melismaSpan && melismaSpan.n < 0 && e.name === 'Rest' && !event.grace && /^\u00a0+$/.test(lyricText) && syllabic === 'single'
                                && lyric.children.every(c => ['no', 'ticks', 'ticks_f', 'text', 'eid'].includes(c.name)) && !Object.keys(lyric.attrs).length;
                            if (melismaSpan && melismaSpan.n < 0 && !backwardsPlaceholder) refuse('native-lyric-length', 'A negative authored lyric span has no verified forward extension mapping for this role.', lyric.location);
                            const justify = get(lyric, 'position'); if (justify && !['left', 'center', 'right'].includes(justify)) refuse('native-lyric-alignment', 'Uninterpreted source lyric alignment.', lyric.location);
                            const placement = get(lyric, 'placement'); if (placement && !['above', 'below'].includes(placement)) refuse('native-lyric-placement', 'Uninterpreted source lyric placement.', lyric.location);
                            const owner = event.notes[0] ?? event;
                            const visible = get(lyric, 'visible');
                            (owner.lyrics ??= []).push({ source: lyric.location, number: int(lyric, 'no', 0, 31, 0) + 1, text: lyricText, syllabic, ...(textFontFamily ? { textFontFamily } : {}), ...(textEmphasis ? { textEmphasis } : {}), ...(textRuns ? { textRuns } : {}), ...(justify ? { justify: justify as 'left' | 'center' | 'right' } : {}), ...(placement ? { placement: placement as 'above' | 'below' } : {}), ...(visible ? { printObject: integer(visible, 0, 1, lyric.location) === 1 } : {}), ...(melismaSpan?.n ? { extend: !backwardsPlaceholder, melisma: { source: child(lyric, ticksFraction ? 'ticks_f' : 'ticks')!.location, duration: melismaSpan, ...(backwardsPlaceholder ? { projection: 'rest-nbsp-backwards-placeholder' as const } : {}), ...(equal(melismaSpan, q(1, 480)) ? { editorPlaceholder: true } : {}) } } : {}) }); applyPresentation(lyric, owner.lyrics!.at(-1)!,{scope:'staff',source:definition.source,staffSize}); decoration(lyric);
                        }
                        decoration(e); registerSpanners(e, eventAnchor);
                        if (!event.notes.length) anchors.set(anchorKey(eventAnchor), eventAnchor);
                        if (grace) pendingGrace.push(event);
                        else {
                            for (const g of pendingGrace) g.grace!.hostId = event.id;
                            events.push(...pendingGrace.filter(g => g.grace!.before), event);
                            position = add(position, duration);
                            const release = clockKey(position);
                            ordinaryAtRelease.set(release, ordinaryAtRelease.has(release) ? undefined : event);
                            for (const g of pendingGrace.filter(g => !g.grace!.before).reverse()) { g.start = position; events.push(g); }
                            pendingGrace.length = 0;
                        }
                        if (compare(position, measureDuration) > 0) refuse('native-clock', 'Voice extends beyond encoded measure span.', e.location);
                    } else if (e.name === 'FiguredBass') {
                        if (e.text.trim() || Object.keys(e.attrs).length || e.children.some(field => !['ticks', 'onNote', 'FiguredBassItem', 'visible', 'placement', 'color', 'offset', 'minDistance', 'eid'].includes(field.name))) refuse('native-figured-bass', 'Uninterpreted source figured-bass definition.', e.location);
                        use(e); budget.add('markings', 1, e.location);
                        const ticks = child(e, 'ticks', true)!, duration = mul(fraction(get(e, 'ticks', true), ticks), q(4));
                        if (duration.n <= 0) refuse('native-figured-bass', 'Figured-bass duration must be an encoded positive exact span.', ticks.location);
                        const onNote = child(e, 'onNote'), visible = get(e, 'visible'), placement = get(e, 'placement');
                        for (const name of ['ticks', 'onNote', 'visible', 'placement', 'eid']) { const field = child(e, name); if (field && (field.children.length || Object.keys(field.attrs).length)) refuse('native-figured-bass', 'Figured-bass property must be plain source data.', field.location); }
                        if (placement && !['above', 'below'].includes(placement)) refuse('native-figured-bass', 'Uninterpreted figured-bass placement.', e.location);
                        const content = readFiguredBassItems(e, node => { used.add(node); budget.add('markings', 1, node.location); });
                        const sourceColor = readColor(e);
                        if (content.literalBracketText !== undefined) performanceGap('native-figured-bass-bracket-format-limit', e.location, 'MusicXML has one parentheses switch for the complete figure stack, with no per-component square or mixed bracket boundaries. Literal standard words preserve those source boundaries and hidden standard figures preserve numeric/modifier content; exact bracket and continuation enums are retained in compatible miscellaneous metadata. Native continuation-line geometry is not reconstructed.', 'preserved');
                        figures.push({ source: e.location, position, duration, durationSource: ticks.location, ...content, ...(sourceColor ? { sourceColor } : {}), ...(onNote ? { onNote: { source: onNote.location, value: integer(get(e, 'onNote'), 0, 1, onNote.location) === 1 } } : {}), ...(visible ? { printObject: integer(visible, 0, 1, e.location) === 1 } : {}), ...(placement ? { placement: placement as 'above' | 'below' } : {}), projection: { hostEventId: '', offset: q(0) } });
                        decoration(e);
                    } else if (e.name === 'Harmony' || e.name === 'FretDiagram') {
                        const at = { position, staff: definition.number, voiceId: String((definition.number - 1) * 4 + vi + 1) };
                        const direction = e.name === 'Harmony' ? harmonyReader.readHarmony(e, at) : harmonyReader.readFretDiagram(e, at);
                        if (direction) directions.push(direction);
                    } else if (e.name === 'TremoloBar') {
                        const fact = readLegacyTremoloBar(e, budget, node => used.add(node));
                        const visible = get(e, 'visible'), sourceColor = readColor(e), play = get(e, 'play');
                        if (visible) fact.printObject = integer(visible, 0, 1, e.location) === 1; if (sourceColor) fact.sourceColor = sourceColor;
                        if (play) { integer(play, 0, 1, e.location); performanceGap('native-tremolo-bar-playback', e.location, 'The native software playback switch remains captured; the actual performer bar curve is projected separately.'); }
                        for (const property of ['mag', 'lineWidth']) { const field = child(e, property); if (field) { geometryScalar(get(e, property), field); omit(field, 'native-tremolo-bar-geometry'); } }
                        decoration(e); tremoloBars.push({ part, measure: mi, staff: definition.number, voice: vi, position, fact });
                    } else if (e.name === 'Capo') {
                        const capo = readNativeCapo(e, { measure: mi, position, staff: definition.number }, { budget, get, use, consume: node => used.add(node), plainText, decoration });
                        (part.capoChanges ??= []).push(capo);
                    } else if (e.name === 'InstrumentChange') {
                        use(e); budget.add('timelines', 1, e.location);
                        const incoming = child(e, 'Instrument', true)!; use(incoming);
                        const transpose = { diatonic: int(incoming, 'transposeDiatonic', -35, 35, 0), chromatic: int(incoming, 'transposeChromatic', -60, 60, 0) };
                        const context: NonNullable<MusicalPart['instrumentChanges']>[number] = { source: e.location, id: `native-instrument:${part.id}:${mi}:${definition.number}:${vi}:${part.instrumentChanges?.length ?? 0}`, measure: mi, position, staff: definition.number, defaultClefs: [] };
                        context.sourceInstrumentTranspose = { source: incoming.location, ...transpose };
                        context.transpose = sourceView?.concertPitch ? { diatonic: 0, chromatic: 0 } : transpose;
                        const stringData = child(incoming, 'StringData');
                        if (stringData) {
                            use(stringData); const strings = children(stringData, 'string');
                            if (!strings.length || strings.length > 16) refuse('native-string', 'Changed instrument requires a complete bounded tuning.', stringData.location);
                            context.tuning = strings.map(string => { use(string); if (Object.keys(string.attrs).length || string.children.length) refuse('native-string', 'Changed tuning needs plain source MIDI values.', string.location); return integer(string.text.trim(), 12, 127, string.location); });
                            const frets = get(stringData, 'frets'); if (frets) integer(frets, 0, 100, stringData.location);
                        }
                        const drumMode = get(incoming, 'useDrumset'); if (drumMode) integer(drumMode, 0, 1, incoming.location);
                        const incomingDrums = children(incoming, 'Drum');
                        if (incomingDrums.length || drumMode === '1') {
                            if (drumMode !== '1' || !incomingDrums.length || context.tuning || transpose.chromatic || transpose.diatonic) refuse('native-instrument-change', 'Changing percussion requires a complete explicit untuned source drum map.', incoming.location);
                            context.percussionInstruments = readNativeDrums(incoming, context.id, { use, get, budget });
                            (part.percussionInstruments ??= []).push(...context.percussionInstruments);
                        }
                        const names: NonNullable<MusicalPart['names']> = {};
                        for (const [field, role] of [['longName', 'long'], ['shortName', 'short'], ['trackName', 'track']] as const) {
                            const node = child(incoming, field); if (node) names[role] = { source: node.location, value: plainText(node) };
                        }
                        if (Object.keys(names).length) context.names = names;
                        const identity = child(incoming, 'instrumentId'); if (identity) { const value = get(incoming, 'instrumentId'); if (value.length > 256) refuse('native-identity-budget', 'Changed instrument identity exceeds its bounded profile.', identity.location); context.instrumentId = { source: identity.location, value }; }
                        for (const clef of children(incoming, 'clef')) { use(clef); context.defaultClefs.push({ source: clef.location, staff: integer(clef.attrs.staff ?? '1', 1, part.staves!.length, clef.location), value: clef.text.trim() }); }
                        for (const node of incoming.children) {
                            if (used.has(node)) continue;
                            if (['minPitchP', 'maxPitchP', 'minPitchA', 'maxPitchA', 'singleNoteDynamics', 'concertClef', 'transposingClef', 'glissandoStyle'].includes(node.name)) use(node);
                            else if (['Channel', 'Articulation'].includes(node.name)) omit(node, 'native-changed-instrument-engine-settings');
                            else if (node.name === 'useDrumset') { integer(get(incoming, 'useDrumset'), 0, 1, node.location); }
                        }
                        const init = get(e, 'init'); if (init) integer(init, 0, 1, e.location);
                        const field = child(e, 'text'); if (field) context.text = { source: field.location, value: plainText(field) };
                        const visible = get(e, 'visible'), placement = get(e, 'placement'); if (visible) context.printObject = integer(visible, 0, 1, e.location) === 1;
                        if (placement) { if (!['above', 'below'].includes(placement)) refuse('native-instrument-change', 'Unknown instrument-change text placement.', e.location); context.placement = placement as 'above' | 'below'; }
                        const sourceColor = readColor(e);
                        if (context.text) directions.push({ ...(sourceColor ? { sourceColor } : {}), source: e.location, position, staff: definition.number, kind: 'words', text: context.text.value, ...(context.printObject !== undefined ? { printObject: context.printObject } : {}), ...(context.placement ? { placement: context.placement } : {}) });
                        (part.instrumentChanges ??= []).push(context); decoration(e); decoration(incoming);
                    } else if (e.name === 'Image') {
                        readAttachedImages(e,{partId:part.id,measure:mi,position,staff:definition.number,voiceId:String((definition.number-1)*4+vi+1),sourceKind:'voice'},anchor.textScale);
                    } else if (['Symbol','FSymbol'].includes(e.name)) {
                        readAttachedImages(e,{partId:part.id,measure:mi,position,staff:definition.number,voiceId:String((definition.number-1)*4+vi+1),sourceKind:'voice'},anchor.textScale);
                        for (const glyph of readGlyphs(e,undefined,false,[],anchor.textScale)) {
                            directions.push({ source: glyph.source, position, staff: definition.number, voiceId: String((definition.number - 1) * 4 + vi + 1), kind: 'symbol', symbol: glyph });
                        }
                    } else if (['Dynamic', 'Tempo', 'StaffText', 'SystemText', 'Expression', 'Text', 'RehearsalMark', 'PlayTechAnnotation'].includes(e.name)) {
                        budget.add('markings', 1, e.location);
                        use(e); let direction: Direction;
                        // A hidden Tempo is not a performer instruction. Its caption and
                        // typography are not carried; the playback rate stays standard.
                        if (e.name === 'Tempo' && children(e, 'visible').length === 1 && get(e, 'visible') === '0') {
                            const tempo = get(e, 'tempo', true), quarterRate = scalar(tempo, e) * 60;
                            if (!(quarterRate > 0)) refuse('native-tempo', 'Invalid quarter-note-per-second tempo.', e.location);
                            const hidden = [e]; while (hidden.length) { const x = hidden.pop()!; used.add(x); hidden.push(...x.children); }
                            performanceGap('native-hidden-tempo-playback-only', e.location, 'A hidden Tempo is not a performer instruction. Its caption and typography are not carried; its playback rate is written as a standard sound tempo.');
                            directions.push({ source: e.location, position, staff: definition.number, kind: 'tempo', quarterRate, rate: String(quarterRate), unit: 'quarter', dots: 0,
                                showMetronome: false, quarterRateOrigin: 'source-tempo', printObject: false, playbackOnly: true });
                            continue;
                        }
                        const legacyCapo = e.name === 'StaffText' ? child(e, 'capo') : undefined;
                        if (legacyCapo) {
                            const capo = readLegacyCapo(legacyCapo, { measure: mi, position, staff: definition.number }, { budget, get, use, consume: node => used.add(node), plainText, decoration });
                            // The StaffText itself owns the printed caption; this state emits no duplicate label.
                            capo.text = ''; (part.capoChanges ??= []).push(capo);
                        }
                        if (e.name === 'Dynamic') {
                            const subtype = get(e, 'subtype', true), t = child(e, 'text'), sourceText = t ? plainText(t) : undefined;
                            const vocabulary = /^(?:p{1,6}|f{1,6}|mp|mf|sf|sff|sfp|sfpp|fp|rf|rfz|sfz|sffz|fz|n|pf|sfzp|other-dynamics)$/;
                            if (!vocabulary.test(subtype)) refuse('native-dynamic', 'Unknown native dynamic subtype.', e.location);
                            // SMuFL dynamic letters express the authored label without requiring a private font payload.
                            const letters: Record<string, string> = { '\uE520': 'p', '\uE521': 'm', '\uE522': 'f', '\uE523': 'r', '\uE524': 's', '\uE525': 'z', '\uE526': 'n' };
                            const label = sourceText?.replace(/[\uE520-\uE526]/g, c => letters[c]);
                            const custom = subtype === 'other-dynamics' || subtype === 'sff' || label !== undefined && label !== subtype;
                            direction = { source: e.location, position, staff: definition.number, kind: 'dynamic', dynamicSubtype: subtype, text: custom ? label ?? subtype : subtype,
                                ...(sourceText !== undefined ? { sourceText } : {}), ...(custom ? { customDynamic: true } : {}) };
                            // A framed exact named glyph sequence keeps its standard sign; a shared
                            // frame cannot span split rich components portably.
                            const framedNamedSign = t && e.children.some(field => field.name.startsWith('frame')) && namedDynamicSign(e, t, direction.text!);
                            if (subtype === 'other-dynamics' && t && sourceText && !framedNamedSign && richDynamic(e, t, sourceText)) {
                                const runs: InlineRuns = { values: [], emphasized: false, limits: new Set(), nativeDynamicPairs: richDynamicDefaults!.linkedMain };
                                const value = plainText(t, undefined, runs, 0, true);
                                if (runs.values.some(run => run.sourceText && !run.symbolName)) refuse('native-rich-dynamic-glyph-context', 'Qualified private glyphs must retain their exact semantic source spans.', t.location);
                                {
                                    const field = child(e, 'fontStyle'); if (field) use(field);
                                    direction.text = value; direction.textRuns = runs.values;
                                    const maskStyle = richDynamicDefaults!.maskStyle;
                                    direction.textFontStyle = sourceText362Mask(e, t, 'Dynamic')
                                        ?? { source: field?.location ?? maskStyle?.location ?? e.location, value: field ? Number(field.text) : maskStyle ? Number(maskStyle.text) : 2, origin: field ? 'source' : maskStyle ? 'source-style' : 'native-default' };
                                    if (maskStyle && !field) use(maskStyle);
                                    const emphasis = readTextEmphasis(e); if (emphasis) direction.textEmphasis = emphasis;
                                    const ownFamily = readTextFamily(e);
                                    qualifyTextFamilies(runs.values, ownFamily);
                                    const { familyStyle, sizeStyle } = richDynamicDefaults!;
                                    direction.textFontFamily = { ...(ownFamily ?? { source: familyStyle?.location ?? e.location, value: richDynamicDefaults!.family, origin: familyStyle ? 'source-style' as const : 'native-default' as const }),
                                        ...(runs.values.some(run => !run.symbolName && run.sourceFont && !run.sourceFont.role) ? { qualification: 'unrepresentable-inline-reset' as const } : {}) };
                                    if (familyStyle) use(familyStyle);
                                    if (sizeStyle) {
                                        use(sizeStyle); direction.textFontSize = { source: sizeStyle.location, rawValue: sizeStyle.text, value: Number(sizeStyle.text), origin: 'source-style' };
                                        budget.add('markings', 1, sizeStyle.location);
                                        unqualifiedRichDynamicSizes.add(direction);
                                        performanceGap('native-rich-dynamic-size-context', sizeStyle.location, 'The explicit saved Dynamic size request remains source-owned. Its spatium-dependent unit is not resolved; no standard point size, final magnification or font metrics is inferred.');
                                    }
                                    budget.add('markings', 2 + runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), t.location);
                                    performanceGap('native-rich-dynamic-components', t.location, 'The source-qualified formatter text, base emphasis, family, ordered clears and Dynamic glyphs remain located. Standard words and semantic dynamics share one source direction, clock and velocity.', 'preserved');
                                    if (direction.textFontFamily.qualification) performanceGap('native-rich-dynamic-family-reset', e.location, `The known initial ${direction.textFontFamily.value} family remains a source fact. Its base hint is withheld where ordinary text enters symbolic ScoreText; later qualified inline hints remain separate from that unresolved reset.`);
                                }
                            }
                            // Keep this finite rule on ordinary text wrappers. Glyph,
                            // font and superscript contexts need their own authority.
                            if (!direction.textRuns && custom && t && sourceText && isOrdinaryCaption(t, sourceText)) {
                                const runs: InlineRuns = { values: [], emphasized: false, limits: new Set() };
                                const text = plainText(t, undefined, runs);
                                if (text !== direction.text) refuse('native-dynamic-text', 'Custom dynamic inline text disagrees with its literal label.', t.location);
                                const field = child(e, 'fontStyle'), inherited = styleValues.get('dynamicTextFontStyle');
                                if (field && (field.children.length || Object.keys(field.attrs).length)) refuse('native-dynamic-font-style', 'Dynamic emphasis requires one plain native font-style bit field.', field.location);
                                if (field) use(field);
                                direction.textFontStyle = field ? { source: field.location, value: integer(field.text.trim(), 0, 15, field.location), origin: 'source' }
                                    : inherited ? { source: inherited.source, value: Number(inherited.value), origin: 'source-style' }
                                        : { source: e.location, value: 2, origin: 'native-default' };
                                const emphasis = readTextEmphasis(e); if (emphasis) direction.textEmphasis = emphasis;
                                budget.add('markings', 1 + runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), t.location);
                                if (runs.values.length) direction.textRuns = runs.values;
                                if (runs?.limits.size) deferInline(e,runs,t.location,'native-custom-dynamic-inline-appearance');
                                let base = direction.textFontStyle.value;
                                for (const [name, bit] of [['bold', 1], ['italic', 2], ['underline', 4], ['strike', 8]] as const) {
                                    const fact = emphasis?.[name]; if (fact) base = fact.value ? base | bit : base & ~bit;
                                }
                                const styles = new Set(runs.values.map(run => (base & ~(run.emphasisResets ?? []).reduce((mask, reset) => mask | reset.bit, 0)) | run.emphasis));
                                if (styles.size > 1) performanceGap('native-custom-dynamic-mixed-emphasis', t.location, 'Visible standard words preserve the exact ordered custom dynamic emphasis. A hidden typed dynamic retains the complete semantic caption at the same source clock and staff.', 'preserved');
                            }
                            if (!direction.textRuns && custom && t && sourceText && namedDynamicSign(e, t, direction.text!)) {
                                direction.customDynamic = false;
                                performanceGap('native-named-dynamic-signs', t.location, 'The exact ordered named Dynamic glyphs project their native standard sign. Original subtype, source label and playback facts remain separate; surrounding font, frame and geometry duties are unchanged.', 'preserved');
                            }
                            const velocity = get(e, 'velocity');
                            if (velocity) { const value = integer(velocity, -1, 127, e.location); direction.sourceVelocity = value; if (value > 0) { direction.velocity = value; direction.velocityOrigin = 'source'; } }
                            if (direction.velocity === undefined) { const value = defaultVelocity(subtype); if (value !== undefined) { direction.velocity = value; direction.velocityOrigin = 'native-default'; } }
                            const velocityChange = get(e, 'veloChange'), changeSpeed = get(e, 'veloChangeSpeed'), play = get(e, 'play');
                            if (changeSpeed && !['slow', 'normal', 'fast'].includes(changeSpeed)) refuse('native-dynamic-speed', 'Unknown dynamic change speed.', e.location);
                            if (velocityChange || changeSpeed || play) { direction.performance = { source: e.location, ...(velocityChange ? { velocityChange: integer(velocityChange, -127, 128, e.location) } : {}), ...(changeSpeed ? { changeSpeed: changeSpeed as 'slow' | 'normal' | 'fast' } : {}), ...(play ? { play: integer(play, 0, 1, e.location) === 1 } : {}) }; performanceGap('native-dynamic-scheduler', e.location, 'The authored dynamic change speed, velocity change and playback enable remain located facts; the standard dynamic is exported without promising the native transient scheduler.'); }
                            const scope = get(e, 'dynType'); if (scope) { direction.scope = ['staff', 'part', 'system'][integer(scope, 0, 2, e.location)] as NonNullable<Direction['scope']>; if (direction.scope !== 'staff') performanceGap('native-dynamic-scope', e.location, 'The authored dynamic assignment scope remains a source fact. The standard direction is exported at its source staff; exact native engine propagation across parts is not promised.'); }
                        }
                        else if (e.name === 'Tempo') {
                            const tempo = get(e, 'tempo', true);
                            if (scalar(tempo, e) <= 0) refuse('native-tempo', 'Invalid quarter-note-per-second tempo.', e.location);
                            const tempoText = child(e, 'text'), literal = tempoText ? plainText(tempoText) : '';
                            let printed = literal, quarterRuns: InlineRuns | undefined;
                            // This finite profile reuses the inert source formatter. A
                            // literal private glyph is not named without the persistent,
                            // unambiguous explicit family that owns that actual token.
                            const privatePoints = [...literal].filter(character => /[\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(character));
                            const quarterCaption = /^(.*?)\uECA5(\s*\uECB7)?\s*=\s*(\d+(?:\.\d+)?)([\s\S]*)$/s.exec(literal);
                            const expectedDots = quarterCaption?.[2] ? 1 : 0;
                            if (tempoText && privatePoints.length === 1 + expectedDots && quarterCaption) {
                                const runs: InlineRuns = { values: [], emphasized: false, limits: new Set(), ...(expectedDots ? { tempoAugmentationDot: true } : {}) };
                                const candidate = plainText(tempoText, undefined, runs), glyphs = runs.values.filter(run => run.symbolName);
                                const matched = /^(.*?)(♩|𝅗𝅥|𝅝|♪)((?:\s*·){0,4})\s*=\s*(\d+(?:\.\d+)?)([\s\S]*)$/s.exec(candidate);
                                if (glyphs.length === 1 + expectedDots && glyphs[0].symbolName === 'metNoteQuarterUp' && glyphs[0].sourceText === '\uECA5'
                                    && (!expectedDots || glyphs[1].symbolName === 'metAugmentationDot' && glyphs[1].sourceText === '\uECB7')
                                    && matched && matched[2] === '♩' && matched[3].replace(/\s/g, '') === '·'.repeat(expectedDots)
                                    && matched[1] === quarterCaption[1] && matched[4] === quarterCaption[3] && matched[5] === quarterCaption[4] && Number(matched[4]) > 0) {
                                    printed = candidate; quarterRuns = runs;
                                } else performanceGap('native-tempo-scoretext-context', tempoText.location,
                                    'The exact private-use tempo caption remains literal. Only an audited positive plain-quarter or single dotted-quarter caption in unambiguous explicit ScoreText context becomes a standard metronome; no unknown font or token meaning is guessed.');
                            } else if (tempoText && /[\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(literal)) {
                                performanceGap('native-tempo-scoretext-context', tempoText.location,
                                    'The exact private-use tempo caption remains literal. Repeated dots, compound and other unverified glyph contexts are not projected as a guessed standard metronome.');
                            }
                            const metronome = /^(.*?)(♩|𝅗𝅥|𝅝|♪)((?:\s*·){0,4})\s*=\s*(\d+(?:\.\d+)?)([\s\S]*)$/s.exec(printed);
                            const units: Record<string, string> = { '♩': 'quarter', '𝅗𝅥': 'half', '𝅝': 'whole', '♪': 'eighth' };
                            const unit = metronome && units[metronome[2]], dots = metronome?.[3].replace(/\s/g, '').length ?? 0;
                            const ordinary352Style = tempoText && !metronome ? tempo352Ordinary(e, tempoText, printed) : undefined;
                            let underlineStyle: Direction['textFontStyle'];
                            const followText = get(e, 'followText') === '1';
                            const rate = metronome?.[4], quarterRate = !quarterRuns && followText && rate && unit ? Number(rate) * durationTypes[unit].n / durationTypes[unit].d * (2 - 1 / 2 ** dots) : Number(tempo) * 60;
                            direction = { source: e.location, position, staff: definition.number, kind: 'tempo', showMetronome: !!metronome, quarterRate, rate: rate && unit ? rate : String(quarterRate), unit: unit || 'quarter', dots, quarterRateOrigin: !quarterRuns && followText && rate && unit ? 'derived-follow-text' : 'source-tempo', tempoWords: metronome ? { before: metronome[1], after: metronome[5] } : { before: printed, after: '' } };
                            // A separate local run set must not change the old
                            // quarterRuns/followText engine calculation above.
                            const canonicalQuarter = (node: Element): boolean => node.name === 'sym' && node.text === 'metNoteQuarterUp' || node.children.some(canonicalQuarter);
                            const local352Style = tempoText && metronome && unit === 'quarter' && dots <= 1
                                && privatePoints.length === (quarterRuns ? 1 + dots : 0)
                                && (quarterRuns || canonicalQuarter(tempoText)) ? tempo352Ordinary(e, tempoText, literal, true) : undefined;
                            let local352Runs: InlineRuns | undefined;
                            if (local352Style && tempoText) {
                                // Preview literal loader output without collecting
                                // font/reset facts or findings for a held candidate.
                                const preview = plainText(tempoText, undefined, undefined, 0, true)
                                    .replaceAll('\uECA5', '♩').replaceAll('\uECB7', '·');
                                const matched = /^(.*?)(♩)(\s*·)?\s*=\s*(\d+(?:\.\d+)?)([\s\S]*)$/ds.exec(preview);
                                if (matched && matched[4] === rate && Number(matched[4]) > 0 && (matched[3] ? 1 : 0) === dots
                                    && [...preview].filter(character => character === '♩' || character === '·').length === 1 + dots) {
                                    const runs: InlineRuns = { values: [], emphasized: false, limits: new Set(), ...(dots ? { tempoAugmentationDot: true } : {}) };
                                    const value = plainText(tempoText, undefined, runs, 0, true), glyphs = runs.values.filter(run => run.symbolName);
                                    if (value !== preview || glyphs.length !== 1 + dots || glyphs[0].symbolName !== 'metNoteQuarterUp'
                                        || dots && glyphs[1].symbolName !== 'metAugmentationDot') refuse('native-tempo-component-context', 'Qualified metronome runs must equal the exact preview and named beat/dot spans.', tempoText.location);
                                    local352Runs = runs;
                                    direction.sourceText = literal; direction.text = value; direction.textRuns = runs.values; direction.textFontStyle = local352Style;
                                    direction.tempoWords = { before: matched[1], after: matched[5] };
                                    qualifyTextFamilies(runs.values, undefined);
                                    const family = tempo352Family(e, runs.values); if (family) direction.textFontFamily = family;
                                    const followed = child(e, 'followText');
                                    direction.sourceTempo = { source: child(e, 'tempo')!.location, quarterNotesPerSecond: tempo,
                                        ...(followed ? { followText: { source: followed.location, rawValue: followed.text.trim() } } : {}) };
                                    budget.add('markings', 1 + runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), tempoText.location);
                                    performanceGap('native-tempo-metronome-components', tempoText.location,
                                        'The source-qualified formatter caption, base emphasis, ordered clears and named beat/rate spans remain located. Standard prose and uniform component font hints are projected separately from encoded engine tempo and written clocks.', 'preserved');
                                    const stylesAt = (start: number, end: number): Set<number> => {
                                        let at = 0; const values = new Set<number>();
                                        for (const run of runs.values) { const next = at + run.text.length;
                                            if (at < end && next > start) values.add((local352Style.value & ~(run.emphasisResets ?? []).reduce((mask, reset) => mask | reset.bit, 0)) | run.emphasis);
                                            at = next;
                                        } return values;
                                    };
                                    const numeric = matched.indices![4], equal = value.lastIndexOf('=', numeric[0]);
                                    // The examined canonical sym insertion uses a
                                    // temporary nonbold/nonitalic music font, then resumes
                                    // the cursor format. It is not a closing reset.
                                    const beatStyles = new Set(glyphs.map(run => ((local352Style.value & ~(run.emphasisResets ?? []).reduce((mask, reset) => mask | reset.bit, 0)) | run.emphasis)
                                        & (run.sourceText === undefined && /\/sym\[\d+\]$/.test(run.source.path ?? '') ? ~3 : ~0))), rateStyles = stylesAt(numeric[0], numeric[1]), equalStyles = stylesAt(equal, equal + 1);
                                    let at = 0, ordinaryEqual = false; const rateFamilies = new Set<string | undefined>();
                                    for (const run of runs.values) { const end = at + run.text.length;
                                        if (at < numeric[1] && end > numeric[0]) rateFamilies.add(run.sourceFont ? run.sourceFont.role ? run.sourceFont.face : undefined : ordinaryTempoProfile!.fontFamily);
                                        if (at <= equal && end > equal && (!run.sourceFont || run.sourceFont.role === 'ordinary-family')) ordinaryEqual = true;
                                        at = end;
                                    }
                                    if (ordinaryEqual || [...equalStyles].some(style => !beatStyles.has(style))) performanceGap('native-tempo-metronome-separator', tempoText.location,
                                        'The source equals/separator appearance remains in the exact ordered runs. MusicXML has no separate font carrier for the metronome equals sign; its independent emphasis/typeface is not flattened onto the beat or rate.');
                                    if (rateStyles.size > 1 || beatStyles.size > 1 || rateFamilies.size > 1) performanceGap('native-tempo-metronome-mixed-component', tempoText.location,
                                        'Mixed emphasis or family inside a beat or numeric span remains located. A string component cannot carry those ordered changes; no uniform hint is invented.');
                                    if ([...beatStyles, ...rateStyles].some(style => style & 12)) performanceGap('native-tempo-metronome-decoration', tempoText.location,
                                        'Beat/rate underline or strike remains located in source runs. The standard metronome and per-minute font groups have no independent decoration attributes.');
                                }
                            }
                            if (quarterRuns && tempoText && !local352Runs) {
                                const followed = child(e, 'followText');
                                direction.sourceText = literal; direction.textRuns = quarterRuns.values;
                                const mask = sourceText362Mask(e, tempoText, 'Tempo');
                                // Inline point sizes are projected with the owner's unit authority;
                                // any size left unresolved is reported once presentation settles.
                                if (quarterRuns.limits.has('font-size')) deferInline(e, quarterRuns, tempoText.location, 'native-tempo-inline-appearance');
                                const faceOnly = ![...quarterRuns.limits].some(limit => limit !== 'font' && limit !== 'font-size');
                                // An explicit visible face token names its family independently
                                // of the producer's initial emphasis authority and of script runs.
                                if (get(e, 'visible') !== '0' && [...quarterRuns.limits].every(limit => ['font', 'font-size', 'sup', 'sub'].includes(limit)))
                                    qualifyTextFamilies(quarterRuns.values, undefined);
                                if (mask && faceOnly) {
                                    direction.text = printed; direction.textFontStyle = mask;
                                    budget.add('markings', 1, mask.source);
                                    performanceGap('native-tempo-source-emphasis', mask.source,
                                        'The qualified constructor resource or explicit source mask supplies initial Tempo emphasis. Existing ordered inline clears, beat glyph and printed rate retain independent identities.', 'preserved');
                                }
                                const emphasis = readTextEmphasis(e); if (emphasis) direction.textEmphasis = emphasis;
                                direction.sourceTempo = { source: child(e, 'tempo')!.location, quarterNotesPerSecond: tempo,
                                    ...(followed ? { followText: { source: followed.location, rawValue: followed.text.trim() } } : {}) };
                                budget.add('markings', quarterRuns.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), tempoText.location);
                                performanceGap('native-tempo-scoretext-appearance', tempoText.location,
                                    'The qualified quarter or single dotted-quarter glyphs, printed rate and exact ordered source font/emphasis runs remain located. Standard metronome notation preserves the printed instruction, independently of encoded engine tempo; native typeface and per-run metronome engraving are not reproduced.');
                            }
                            // Ordinary textual tempo instructions use the same
                            // individually authored TextBase flags as StaffText.
                            // Music-glyph and formatter contexts remain separate.
                            if (local352Runs) {
                                // Qualified component facts were retained above.
                            } else if (quarterRuns) {
                                // Individually encoded flags stay distinct from inline
                                // spans and are not flattened into metronome engraving.
                            } else if (tempoText && ordinary352Style) {
                                direction.textFontStyle = ordinary352Style;
                                const emphasis = readTextEmphasis(e); if (emphasis) direction.textEmphasis = emphasis;
                                const runs: InlineRuns = { values: [], emphasized: false, limits: new Set(), nameGlyphs: false };
                                const value = plainText(tempoText, undefined, runs, 0, true);
                                direction.sourceText = literal; direction.text = value;
                                direction.tempoWords = { before: value, after: '' }; direction.textRuns = runs.values;
                                qualifyTextFamilies(runs.values, undefined);
                                const family = tempo352Family(e, runs.values); if (family) direction.textFontFamily = family;
                                budget.add('markings', 1 + runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), tempoText.location);
                                performanceGap('native-tempo-formatter-input', tempoText.location,
                                    'The qualified producer TextBase loader supplies located ordered emphasis resets and formatter text, separately from the original source literal and capture. Explicit ordinary font tokens become standard family hints; symbolic ScoreText and the known initial default family remain separate projection duties.', 'inferred');
                            } else if (tempoText && !metronome && (underlineStyle = tempoUnderlineScript(e, tempoText, printed))) {
                                direction.textFontStyle = underlineStyle;
                                const emphasis = readTextEmphasis(e); if (emphasis) direction.textEmphasis = emphasis;
                                const runs: InlineRuns = { values: [], emphasized: false, limits: new Set(), nameGlyphs: false };
                                const value = plainText(tempoText, undefined, runs);
                                if (value !== printed) refuse('native-tempo-inline-text', 'Qualified ordinary tempo runs must retain the exact decoded instruction.', tempoText.location);
                                direction.textRuns = runs.values;
                                if (runs.limits.size) deferInline(e, runs, tempoText.location, 'native-tempo-inline-appearance');
                                budget.add('markings', 1 + runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), tempoText.location);
                                if (runs.values.some(run => run.script)) performanceGap('native-tempo-script-appearance', tempoText.location,
                                    'The qualified native Tempo base style, ordered underline and closing resets remain located and projected with exact literal words. Superscript source text and syntax remain captured; native script position, size and font metrics are not reproduced.');
                            } else if (tempoText && printed && !metronome && isOrdinaryCaption(tempoText, printed)
                                && ordinaryTempoShape(tempoText) && !child(e, 'fontStyle')) {
                                const emphasis = readTextEmphasis(e); if (emphasis) direction.textEmphasis = emphasis;
                                if (tempoText.children.length || tempoText.text.includes('<')) {
                                    const runs: InlineRuns = { values: [], emphasized: false, limits: new Set(), nameGlyphs: false };
                                    const value = plainText(tempoText, undefined, runs);
                                    if (value !== printed) refuse('native-tempo-inline-text', 'Qualified ordinary tempo runs must retain the exact decoded instruction.', tempoText.location);
                                    if (runs.values.some(run => run.emphasis !== 0 || run.emphasisResets?.length)) {
                                        // Runs before any inline token keep the Tempo style's base mask.
                                        const mask = sourceText362Mask(e, tempoText, 'Tempo'); if (mask) direction.textFontStyle = mask;
                                        direction.textRuns = runs.values;
                                        budget.add('markings', runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), tempoText.location);
                                    }
                                }
                            } else {
                                const field = ['bold', 'italic', 'underline', 'strike'].map(name => child(e, name)).find(Boolean);
                                if (field || tempoText && (tempoText.children.length || tempoText.text.includes('<'))) performanceGap('native-tempo-emphasis-context', field?.location ?? tempoText!.location, 'Exact source tempo text and emphasis properties remain captured. Metronome, music-glyph, font/position and unqualified formatter contexts require separate projection authority; their emphasis is not guessed from ordinary tempo words.');
                            }
                            // Every 3.x/4.x TextBase reader preserves an explicit
                            // family loaded before a scalar caption. Style selectors,
                            // inline formatting and metronome glyphs remain separate.
                            const families = children(e, 'family'), family = families.length === 1 ? families[0] : undefined;
                            const familyProfile = !!nativeTextLoader;
                            if (familyProfile && family && tempoText && !metronome && !quarterRuns
                                && e.children.indexOf(family) < e.children.indexOf(tempoText)
                                && !e.children.some(field => ['style', 'textStyle', 'fontFace', 'musicSymbolSize'].includes(field.name))
                                && !family.children.length && !Object.keys(family.attrs).length && !family.hasComment && !family.cdata && family.text.length <= 65536
                                && !tempoText.children.length && !Object.keys(tempoText.attrs).length && !tempoText.hasComment && !tempoText.cdata
                                && tempoText.text.trim() && !/[<>\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(tempoText.text))
                                direction.textFontFamily = readTextFamily(e);
                        } else {
                            const t = child(e, 'text', true)!, runs: InlineRuns = { values: [], emphasized: false, limits: new Set() };
                            direction = { source: e.location, position, staff: definition.number, kind: e.name === 'RehearsalMark' ? 'rehearsal' : 'words', text: plainText(t, undefined, runs) };
                            const systemInline = e.name === 'SystemText' ? systemTextInline(e, t, direction.text ?? '') : undefined;
                            if (systemInline) Object.assign(direction, systemInline);
                            if (['StaffText', 'SystemText', 'Expression', 'Text', 'PlayTechAnnotation', 'RehearsalMark'].includes(e.name)) {
                                const family = readTextFamily(e);
                                if (family) {
                                    direction.textFontFamily = family;

                                }
                                qualifyTextFamilies(systemInline?.textRuns ?? runs.values, family);
                            }
                            if (!systemInline && runs.values.some(run => run.emphasis !== 0 || run.emphasisResets?.length || run.symbolName || run.sourceFont || run.sourceText || run.textFontSize || run.script)) {
                                budget.add('markings', runs.values.reduce((count, run) => count + 1 + (run.emphasisResets?.length ?? 0), 0), t.location); direction.textRuns = runs.values;
                            }
                            if (runs?.limits.size) deferInline(e,runs,t.location,'native-staff-text-inline-appearance');
                        }
                        const assignment = get(e, 'voiceAssignment'); if (assignment) {
                            if (!['currentVoiceOnly', 'allInStaff'].includes(assignment)) refuse('native-direction-voice', 'Unknown authored direction voice assignment.', e.location);
                            direction.voiceAssignment = assignment as NonNullable<Direction['voiceAssignment']>; if (assignment === 'currentVoiceOnly') direction.voiceId = String((definition.number - 1) * 4 + vi + 1);
                        }
                        if (e.name === 'PlayTechAnnotation') {
                            const technique = get(e, 'playTechType') || 'natural', play = get(e, 'play');
                            if (!['natural', 'pizzicato', 'arco', 'tremolo'].includes(technique)) refuse('native-playing-technique', 'Authored playing technique needs a verified standard mapping.', e.location);
                            direction.playingTechnique = { source: e.location, kind: technique as NonNullable<Direction['playingTechnique']>['kind'], ...(play ? { play: integer(play, 0, 1, e.location) === 1 } : {}) };
                        }
                        for (const channel of children(e, 'channelSwitch')) {
                            use(channel); budget.add('markings', 1, channel.location);
                            if (!channel.attrs.name || channel.attrs.name.length > 256 || channel.text.trim() || channel.children.length) refuse('native-channel-switch', 'Invalid source playback channel selector.', channel.location);
                            const voiceId = channel.attrs.voice === undefined ? undefined : String((definition.number - 1) * 4 + integer(channel.attrs.voice, 0, 3, channel.location) + 1);
                            (direction.channelSwitches ??= []).push({ source: channel.location, name: channel.attrs.name, ...(voiceId ? { voiceId } : {}) });
                            performanceGap('native-playback-channel-switch', channel.location, 'The authored voice/channel selection remains a located fact; no external soundfont or native playback channel is loaded or guessed.');
                        }
                        const visible = get(e, 'visible'); if (visible) direction.printObject = integer(visible, 0, 1, e.location) === 1;
                        const color = readColor(e); if (color) direction.sourceColor = color;
                        if (e.name === 'StaffText') {
                            const emphasis = readTextEmphasis(e); if (emphasis) direction.textEmphasis = emphasis;
                        }
                        if (e.name === 'SystemText') {
                            const caption = child(e, 'text', true)!, inline = direction.textRuns;
                            const flags = e.children.filter(field => ['bold', 'italic', 'underline', 'strike'].includes(field.name));
                            if (flags.length && !inline) {
                                // Strike is a 4.x owner property; 3.x has no strike flag.
                                const legacy = nativeMajor === 3 && !!nativeTextLoader, current = nativeMajor === 4 && !!nativeTextLoader;
                                const names = new Set<string>();
                                const plainFlags = flags.every(field => {
                                    if (names.has(field.name)) return false;
                                    names.add(field.name);
                                    return (field.name !== 'strike' || current) && !field.children.length && !Object.keys(field.attrs).length && /^[01]$/.test(field.text.trim());
                                });
                                // Explicit owner flags qualify independently of defaults only
                                // in this plain-caption context. Rich text and font
                                // contexts keep their existing interpretation and raw origin.
                                if ((legacy || current) && plainFlags && !caption.children.length && !Object.keys(caption.attrs).length
                                    && caption.text.trim() && !/[<>]/.test(caption.text) && isOrdinaryCaption(caption, direction.text ?? '')
                                    && !e.children.some(field => ['family', 'size', 'fontStyle', 'sizeIsSpatiumDependent', 'musicSymbolSize', 'style', 'textStyle'].includes(field.name))) {
                                    const emphasis = readTextEmphasis(e); if (emphasis) direction.textEmphasis = emphasis;
                                } else performanceGap('native-system-text-emphasis-context', flags[0].location, 'Exact SystemText emphasis properties remain captured. This profile or structured/font/glyph/property context has no qualified ordinary owner-emphasis projection; literal text, system scope and written clocks retain their existing interpretation.');
                            }
                            if (!inline && caption.children.length && isOrdinaryCaption(caption, direction.text ?? '')) performanceGap('native-system-text-inline-context', caption.location, 'The located inline SystemText caption retains its existing text and source capture. Unexamined producer, selector, property ordering or wrapper context does not establish an effective base style or ordered-emphasis projection.');
                        }
                        const alignField = child(e, 'align'), positionField = child(e, 'position');
                        if (alignField || positionField) {
                            const alignment: NonNullable<Direction['textAlignment']> = { source: e.location };
                            if (alignField) {
                                const value = get(e, 'align'), match = /^(left|center|right),(top|center|bottom|baseline)$/.exec(value);
                                if (!match) return refuse('native-text-alignment', 'Uninterpreted source text block alignment.', alignField.location);
                                alignment.justify = match[1] as NonNullable<Direction['textAlignment']>['justify'];
                                alignment.valign = (match[2] === 'center' ? 'middle' : match[2]) as NonNullable<Direction['textAlignment']>['valign'];
                                if (Number(capture.nativeVersion) < 4.7) { alignment.halign = alignment.justify; alignment.halignOrigin = 'derived-legacy-align'; }
                            }
                            if (positionField) { if (Number(capture.nativeVersion) < 4.7) refuse('native-text-position-version', 'This older text-position combination has no independently exercised migration policy.', positionField.location); const value = get(e, 'position'); if (!['left', 'center', 'right'].includes(value)) refuse('native-text-position', 'Uninterpreted source text horizontal position.', positionField.location); alignment.halign = value as NonNullable<Direction['textAlignment']>['halign']; alignment.halignOrigin = 'source-position'; }
                            direction.textAlignment = alignment;
                            if (direction.kind === 'dynamic' && alignment.justify && direction.text?.includes('\n')) performanceGap('native-dynamic-text-alignment', alignField!.location, 'The source multiline dynamic text justification remains a located fact. MusicXML dynamics supports block position but has no separate text justification attribute.');
                        }
                        const placement = get(e, 'placement'), nativeDirection = get(e, 'direction');
                        if (placement && !['above', 'below'].includes(placement) || nativeDirection && !['auto', 'up', 'down'].includes(nativeDirection)) refuse('native-direction-placement', 'Uninterpreted source text/dynamic placement.', e.location);
                        if (nativeDirection && nativeDirection !== 'auto') direction.placement = nativeDirection === 'up' ? 'above' : 'below'; else if (placement) direction.placement = placement as NonNullable<Direction['placement']>;
                        if (e.name === 'Dynamic' && Number(capture.nativeVersion) < 4.4 && !direction.placement) {
                            const style = styleValues.get('dynamicsPlacement');
                            if (style) {
                                direction.placement = style.value as 'above' | 'below';
                                direction.placementFact = { source: style.source, value: direction.placement, origin: 'source-style' };
                            }
                        }
                        const system = get(e, 'systemFlag'); if (system) direction.system = integer(system, 0, 1, e.location) === 1;
                        if (!system && ['SystemText','RehearsalMark','Tempo'].includes(e.name)) direction.system=e.name==='Tempo'?numberStyle('tempoSystemFlag',1)===1:true;
                        const swing = child(e, 'swing'); if (swing) {
                            if (!['StaffText', 'SystemText'].includes(e.name) || swing.children.length || swing.text.trim() || Object.keys(swing.attrs).some(k => !['unit', 'ratio'].includes(k)) || !Object.hasOwn(swing.attrs, 'unit') || !Object.hasOwn(swing.attrs, 'ratio') || !['', '0'].includes(swing.attrs.unit))
                                refuse('native-swing', 'This source swing record is not the verified disabled scheduling form.', swing.location);
                            used.add(swing); (direction.performance ??= { source: swing.location }).swing = { source: swing.location, unit: 'disabled', ratio: integer(swing.attrs.ratio, 0, 100, swing.location) };
                            performanceGap('native-disabled-swing', swing.location, 'The exact disabled source swing settings remain captured independently. Their engine scheduling ratio does not add a performer instruction or alter written clocks.');
                        }
                        applyPresentation(e, direction,{scope:direction.system?'score':'staff',source:definition.source,staffSize});
                        // The legacy rich Dynamic size unit is unresolved, so its
                        // runs do not acquire projected point sizes from that request.
                        if (unqualifiedRichDynamicSizes.has(direction)) {
                            for (const run of direction.textRuns ?? []) for (const key of ['textFontSize', 'musicFontSize'] as const) if (run[key]?.pointSize) { const { pointSize: _, ...rest } = run[key]!; run[key] = rest; }
                            if (direction.musicFontSize?.pointSize) { const { pointSize: _, ...rest } = direction.musicFontSize; direction.musicFontSize = rest; }
                        }
                        decoration(e); directions.push(direction);
                    } else if (e.name === 'Spanner') {
                        const wrapper: Element = { ...e, name: 'wrapper', children: [e] }; registerSpanners(wrapper, anchor);
                    } else if (e.name === 'Segment') {
                        readSegment(e, 'voice');
                        recordTrillNeutral?.(e,sourceVoice,'segment-spacing',vi);
                    } else if (e.name === 'BarLine') {
                        use(e); budget.add('markings', 1, e.location);
                        const subtype = get(e, 'subtype') || 'normal', styles: Record<string, NonNullable<MusicalMeasure['barlines']>[number]['style']> = { normal: 'regular', end: 'light-heavy', double: 'light-light', broken: 'dashed', dashed: 'dashed', dotted: 'dotted', 'start-repeat': 'heavy-light', 'end-repeat': 'light-heavy' };
                        if (!Object.hasOwn(styles, subtype)) refuse('native-barline', `Unsupported barline ${subtype}.`, e.location);
                        if (subtype === 'start-repeat' && position.n !== 0 || subtype === 'end-repeat' && !equal(position, measureDuration)) refuse('native-repeat-barline', 'Repeat barline must occur at its source measure boundary.', e.location);
                        const span = get(e, 'span'); if (span) { integer(span, 0, 16, e.location); performanceGap('native-barline-span', e.location, 'Source barline staff span is retained in captured data; MusicXML exports its musical boundary/style without native staff-joining geometry.'); }
                        const visible = get(e, 'visible'); if (visible) integer(visible, 0, 1, e.location);
                        if (pendingFermata && !equal(pendingFermataPosition, position)) deferFermata();
                        barlines.push({ source: e.location, origin: 'source', position, location: position.n === 0 ? 'left' : equal(position, measureDuration) ? 'right' : 'middle', style: styles[subtype], ...(visible ? { printObject: visible === '1' } : {}), ...(pendingFermata ? { fermata: pendingFermata } : {}) });
                        pendingFermata = undefined; decoration(e);
                        recordTrillNeutral?.(e,sourceVoice,'barline',vi);
                    }
                    else if (layout.has(e.name)) omit(e, 'native-layout-and-playback-decoration');
                    else refuse('native-feature', `Unsupported voice construct ${e.name}; no musical output admitted.`, e.location);
                }
                if (tuplets.length) refuse('native-tuplet', 'Unclosed tuplet.', tuplets[0].element.location);
                if (pendingFermata) {
                    if (!equal(pendingFermataPosition, measureDuration)) deferFermata();
                    else {
                        barlines.push({ source: pendingFermata.source, origin: 'native-default', position: pendingFermataPosition, location: 'right', style: 'regular', fermata: pendingFermata });
                        if (pendingFermata.playbackStretch !== undefined) performanceGap('native-fermata-scheduler', pendingFermata.source, 'The source end-barline fermata and authored stretch are retained; MusicXML does not promise the engine-specific scheduler factor.');
                        pendingFermata = undefined;
                    }
                }
                if (pendingGrace.length) refuse('native-grace', 'Grace chords have no encoded ordinary host.', pendingGrace[0].source);
                if (pendingTremolo) refuse('native-tremolo', 'Two-chord tremolo has no adjacent encoded second chord.', pendingTremolo.source.location);
                if (pendingBeam) refuse('native-beam', 'Beam geometry has no following chord/rest owner.', pendingBeam.source);
                if (figures.length) {
                    const regular = events.filter(event => !event.grace); let hostIndex = 0;
                    figures.sort((a, b) => compare(a.position, b.position));
                    for (const figure of figures) {
                        while (hostIndex < regular.length && compare(add(regular[hostIndex].start, regular[hostIndex].duration), figure.position) <= 0) hostIndex++;
                        const host = regular[hostIndex];
                        if (!host || compare(host.start, figure.position) > 0 || host.staff !== definition.number || figure.onNote?.value && !equal(host.start, figure.position)) refuse('native-figured-bass-owner', 'Figured bass needs a verified regular source staff/voice host at its exact clock.', figure.source);
                        const previous = host.figuredBass?.at(-1);
                        if (previous && compare(add(previous.position, previous.duration), figure.position) > 0) refuse('native-figured-bass-overlap', 'Overlapping source figures under one note need an explicit independently verified interpretation.', figure.source);
                        figure.projection = { hostEventId: host.id, offset: add(figure.position, q(-host.start.n, host.start.d)) }; (host.figuredBass ??= []).push(figure);
                        if (figure.projection.offset.n) performanceGap('native-figured-bass-interior', figure.source, 'The source figure remains at its exact interior clock under the verified regular note. Ordered standard figured-bass duration intervals, including a hidden blank leading interval when required, preserve figure changes without adding note events.', 'inferred');
                    }
                }
                voices.push(events);
            }
            if (deferredFermatas.length) {
                const atClock = new Map<string, { event: MusicalEvent; voice: number }[]>();
                for (let voice = 0; voice < voices.length; voice++) for (const event of voices[voice]) if (!event.grace) { const key = clockKey(event.start), events = atClock.get(key) ?? []; events.push({ event, voice }); atClock.set(key, events); }
                for (const deferred of deferredFermatas) {
                    const { fermata, position, voice } = deferred;
                    if (compare(position, q(0)) < 0 || compare(position, measureDuration) > 0) refuse('native-fermata', 'Segment fermata clock lies outside its source measure.', fermata.source);
                    const candidates = atClock.get(clockKey(position)) ?? [], owned = candidates.filter(c => c.voice === voice), onStaff = candidates.filter(c => c.event.staff === definition.number);
                    const target = owned.length === 1 && owned[0].event.staff === definition.number ? owned[0].event : onStaff.length === 1 ? onStaff[0].event : undefined;
                    const base = { source: fermata.source, position, staff: definition.number, sourceVoiceId: String((definition.number - 1) * 4 + voice + 1), fermata };
                    if (target && !target.fermata) {
                        target.fermata = fermata; segmentFermatas.push({ ...base, projection: { kind: 'derived-event', eventId: target.id } });
                        performanceGap('native-segment-fermata-owner', fermata.source, 'The exact source staff/clock/voice segment mark is retained. A unique ordinary event at that clock supplies its derived standard notation attachment; original source voice authority is not rewritten.', 'inferred');
                    } else {
                        if (fermata.shape !== 'normal') refuse('native-fermata', 'An unowned nonordinary fermata needs an independently verified positioned glyph.', fermata.source);
                        const glyph = fermata.inverted ? 'fermataBelow' : 'fermataAbove';
                        segmentFermatas.push({ ...base, projection: { kind: 'direction-glyph', glyph } });
                        directions.push({ source: fermata.source, position, staff: definition.number, kind: 'symbol', symbol: { source: fermata.source, id: `native-segment-fermata:${globalStaff}:${mi}:${segmentFermatas.length}`, name: glyph, ...(fermata.printObject !== undefined ? { printObject: fermata.printObject } : {}) }, placement: fermata.inverted ? 'below' : 'above', ...(fermata.printObject !== undefined ? { printObject: fermata.printObject } : {}) });
                        performanceGap('native-segment-fermata-glyph', fermata.source, 'The exact source segment clock, staff, voice and fermata instruction remain located. A standard positioned glyph preserves the visible instruction without inventing a note or choosing an ambiguous simultaneous voice; typed MusicXML note/barline attachment remains a precise interchange limit.');
                    }
                    if (fermata.playbackStretch !== undefined) performanceGap('native-fermata-scheduler', fermata.source, 'Authored stretch remains retained without changing nominal clocks or promising a software scheduler.');
                }
            }
            // The next measure inherits the latest active staff change by musical clock,
            // rather than whichever source voice happened to serialize last.
            time = initialTime; timeSource = initialTimeSource; key = initialKey; clef = initialClef; clefPrintObject = initialClefPrintObject; stretch = initialStretch; stretchSource = initialStretchSource;
            for (const change of [...changes].sort((a, b) => compare(a.position, b.position))) applyAttribute(change);
            const startRepeat = child(sourceMeasure, 'startRepeat'); if (startRepeat) use(startRepeat);
            const encodedEndRepeat = get(sourceMeasure, 'endRepeat'), master = repeatFacts[mi];
            if (!master || startRepeat && !master.start || encodedEndRepeat && integer(encodedEndRepeat, 0, 128, sourceMeasure.location) !== master.end) refuse('native-repeat', 'Encoded staff repeat flags contradict the shared native measure.', sourceMeasure.location);
            if (startRepeat) recordTrillNeutral?.(startRepeat,sourceMeasure,'repeat');
            const endRepeat = child(sourceMeasure,'endRepeat');if (endRepeat) recordTrillNeutral?.(endRepeat,sourceMeasure,'repeat');
            const repeatStart = master.start, repeatEnd = master.end;
            // An absent final boundary has a verified native END default. Keep it distinct
            // from authored BarLine facts; an explicit right boundary always owns its style.
            if (mi === sourceMeasures.length - 1 && !barlines.some(b => b.location === 'right' && b.origin === 'source')) {
                const generated = barlines.find(b => b.location === 'right');
                if (generated) generated.style = 'light-heavy';
                else { budget.add('markings', 1, sourceMeasure.location); barlines.push({ source: sourceMeasure.location, origin: 'native-default', position: measureDuration, location: 'right', style: 'light-heavy' }); }
            }
            const irregular = get(sourceMeasure, 'irregular');
            if (irregular && (integer(irregular, 0, 1, sourceMeasure.location) === 1) !== master.numbering.irregular) refuse('native-measure-numbering', 'Encoded staff irregular-numbering flags contradict the shared source measure.', sourceMeasure.location);
            for (const [field, expected] of [['noOffset', master.numbering.offset?.value ?? 0], ['measureNumberMode', master.numbering.mode ? ['auto', 'show', 'hide'].indexOf(master.numbering.mode.value) : 0]] as const) {
                const node = child(sourceMeasure, field); if (node) { use(node); if (node.children.length || integer(node.text.trim(), field === 'noOffset' ? -1000000 : 0, field === 'noOffset' ? 1000000 : 2, node.location) !== expected) refuse('native-measure-numbering', 'Encoded staff numbering facts contradict the shared measure.', node.location); }
            }
            decoration(sourceMeasure);
            const measureVisible = get(sourceMeasure, 'visible');
            const staffFact: StaffFact = { ...definition, clef: initialClef, clefBadge: initialClefBadge, key: initialKey, time: initialTime, stretch: initialStretch, ...(staffSize ? { staffSize } : {}), ...(initialClefPrintObject !== undefined ? { clefPrintObject: initialClefPrintObject } : {}), ...(measureVisible ? { printObject: integer(measureVisible, 0, 1, sourceMeasure.location) === 1 } : {}) };
            if(definition.notation?.showClef?.value===false) staffFact.clefPrintObject=false;
            if(definition.notation?.showKeySignature?.value===false) staffFact.key={...initialKey,printObject:false};
            if(definition.notation?.showTimeSignature?.value===false) staffFact.time={...initialTime,printObject:false};
            for(const change of changes) {
                if(change.clef && definition.notation?.showClef?.value===false)change.printObject=false;
                if(change.key && definition.notation?.showKeySignature?.value===false)change.key.printObject=false;
                if(change.time && definition.notation?.showTimeSignature?.value===false)change.time.printObject=false;
            }



            if (initialClefBadge) performanceGap('native-optional-octave-clef', initialClefBadge.source, 'The source optional 8vb clef uses the ordinary G-clef pitch baseline. MusicXML preserves that baseline and an explicit optional-octave instruction; the native parenthesized clef badge remains a located fact rather than an obligatory octave transform.');
            if (!mi) Object.assign(definition, staffFact);
            let m = part.measures[mi];
            if (!m) { m = { source: sourceMeasure.location, time: initialTime, key: initialKey, clef: initialClef, pickup: mi === 0 && master.numbering.irregular && compare(measureDuration, nominalDuration) < 0, implicit: master.numbering.irregular, numbering: {...master.numbering}, duration: measureDuration, voices: [], repeatStart, repeatEnd, staffs: [], directions: [], barlines: [], changes: [] }; part.measures.push(m); }
            else if (!equal(m.duration, measureDuration)) refuse('native-meter', 'Staff measure spans disagree.', sourceMeasure.location);
            for (let vi = 0; vi < voices.length; vi++) m.voices[(definition.number - 1) * 4 + vi] = voices[vi];
            if (trillRows) {
                const bar: SourceTrillBar = {node:sourceMeasure,voices:sourceVoices,initialTime,initialTimeSource:initialTimeSource ? trillMeters!.get(initialTimeSource) : undefined,model:m,start:q(0),rows:trillRows,declaredDuration:measureDuration,tuplets:trillTupletClocks!,cursors:trillCursorClocks!,pairs:trillPairClocks!,neutralClocks:trillNeutralClocks!};
                // Once unsafe, a later signature cannot repair earlier clock authority.
                trillClockSafe = trillClockSafe && trillSourceClockPrefix(bar, e => plainForcedBeam(e) || ordinaryGroupingBeam(e) || editedSourceBeam(e));
                const staffs = trillSourceBars.get(part) ?? new Map<number, Map<number, {bar:SourceTrillBar;safe:boolean}>>();
                const measures = staffs.get(definition.number) ?? new Map<number, {bar:SourceTrillBar;safe:boolean}>();
                measures.set(mi,{bar,safe:trillClockSafe});staffs.set(definition.number,measures);trillSourceBars.set(part,staffs);
            }
            for(const number of children(sourceMeasure,'MeasureNumber')){
                const visible=child(number,'visible'),cached=child(number,'text');
                const appearance:NonNullable<NonNullable<MusicalMeasure['numbering']>['appearances']>[number]={source:number.location,staff:definition.number,...(visible?{printObject:integer(visible.text.trim(),0,1,visible.location)===1}:{}),...(cached?{cachedText:{source:cached.location,value:plainText(cached)}}:{})};
                const selector=glyphStyleScopes.flatMap(style=>children(style,'measureNumberTextStyle')).at(-1);
                if(selector&&!child(number,'style'))use(selector);
                applyPresentation(selector&&!child(number,'style')?{...number,children:[{...selector,name:'style'},...number.children]}:number,appearance,{scope:'staff',source:definition.source,staffSize});
                (m.numbering!.appearances??=[]).push(appearance);
                if(appearance.textEnclosure&&appearance.textEnclosure.value!=='none'||appearance.textFrameAppearance||appearance.textFontStyle&&appearance.textFontStyle.value&12||appearance.textEmphasis?.underline?.value||appearance.textEmphasis?.strike?.value){
                    const mode=m.numbering!.mode?.value==='show'?'measure':m.numbering!.mode?.value==='hide'?'none':m.numbering!.automatic;
                    if(mode!=='system'){
                        appearance.projection='words';
                        directions.push({...appearance,kind:'words',position:q(0),text:String(m.numbering!.displayNumber??''),printObject:appearance.printObject!==false&&mode==='measure'&&m.numbering!.displayNumber!==undefined});
                    }else performanceGap('native-measure-number-decoration',number.location,'The source numbering decoration is retained exactly. Standard measure-numbering has no enclosure or underline/strike carrier; a static words replacement cannot preserve this source system-conditional label after consumer repagination. Explicit per-measure labels use located words instead.');
                }
            }
            m.staffs!.push(staffFact); m.directions!.push(...directions); m.barlines!.push(...barlines); m.changes!.push(...changes); mi++;
            if (segmentFermatas.length) (m.segmentFermatas ??= []).push(...segmentFermatas);
        }
    }
    for (const bar of tremoloBars) {
        const events = bar.part.measures[bar.measure].voices[(bar.staff - 1) * 4 + bar.voice] ?? [];
        const event = events.find(event => !event.grace && equal(event.start, bar.position));
        if (!event || event.whammy) refuse('native-tremolo-bar-owner', 'A native tremolo-bar curve requires one actual source event at its staff and voice clock.', bar.fact.source);
        event!.whammy = bar.fact;
    }
    for (const part of parts) if (part.instrumentChanges?.length) {
        const contexts = part.instrumentChanges.sort((a, b) => a.measure - b.measure || compare(a.position, b.position));
        for (let i = 1; i < contexts.length; i++) if (contexts[i].measure === contexts[i - 1].measure && equal(contexts[i].position, contexts[i - 1].position)) {
            findings.push({ disposition: 'preserved', code: 'native-instrument-change-conflict', message: 'Both source contexts at this part clock are identified; no encounter-order instrument authority is selected.', location: contexts[i].source, fact: { otherSource: contexts[i - 1].source } });
            refuse('native-instrument-change', 'Multiple source instrument definitions occupy one shared part clock.', contexts[i].source);
        }
        for (const context of contexts) {
            const tuningStaffs = part.staves!.filter(staff => staff.kind === 'tablature');
            for (const staff of part.staves!) {
                (part.measures[context.measure].changes ??= []).push({ source: context.source, staff: staff.number, position: context.position,
                    ...(context.transpose ? { transpose: context.transpose } : {}),
                    ...(context.tuning && (tuningStaffs.length ? staff.kind === 'tablature' : staff.number === 1) ? { tuning: context.tuning } : {}) });
            }
        }
        for (const [measure, m] of part.measures.entries()) for (const voice of m.voices) for (const event of voice ?? []) {
            let low = 0, high = contexts.length;
            while (low < high) { const middle = low + Math.floor((high - low) / 2), context = contexts[middle]; if (context.measure < measure || context.measure === measure && compare(context.position, event.start) <= 0) low = middle + 1; else high = middle; }
            if (low) event.instrumentContextId = contexts[low - 1].id;
        }
    }
    const instrumentContextsById = new Map(parts.flatMap(part => (part.instrumentChanges ?? []).map(context => [context.id, context] as const)));
    for (const { note, event, part, source, midi, tpc, tpc2, definition, clef } of pendingWritten) {
        const context = event.instrumentContextId ? instrumentContextsById.get(event.instrumentContextId) : undefined;
        const drumMap = context ? context.percussionInstruments : drumsByPart.get(part) ? [...drumsByPart.get(part)!.values()] : undefined;
        if (drumMap) {
            const drum = drumMap.find(item => item.midi === midi);
            if (event.noteheadGroups?.length) refuse('native-note-parenthesis-order', 'Indexed pitch groups cannot be reinterpreted as percussion note ordering.', source.location);
            if (!drum || clef !== 'PERC') refuse('native-drum-reference', 'An unpitched note requires its active explicit source drum map and percussion clef.', source.location);
            if (note.sourceDead?.value || note.string !== undefined) refuse('native-drum-reference', 'Percussion cannot silently absorb a conflicting fretted/dead-pitch interpretation.', source.location);
            const displayLine = drum!.line + (definition.percussionStepOffset?.value ?? 0) + 10 - 2 * (definition.lines ?? 5), diatonic = 38 - displayLine, octave = Math.floor(diatonic / 7);
            if (octave < 0 || octave > 9) refuse('native-drum-register', 'Drum display exceeds the standard register.', source.location);
            Object.assign(note, { kind: 'unpitched', sounding: null, unpitched: { displayStep: 'CDEFGAB'[(diatonic % 7 + 7) % 7], displayOctave: octave, midi, instrumentId: drum!.id, ...(child(source, 'tpc') ? { sourceTpc: tpc } : {}) } });
            delete note.written;
            if (!note.sourceNotehead && drum!.noteheadGlyphs?.active) {
                const type = note.sourceHeadType?.value ?? (event.type === 'whole' ? 'whole' : event.type === 'half' ? 'half' : event.type === 'breve' || event.type === 'longa' ? 'breve' : 'quarter');
                const glyph = drum!.noteheadGlyphs.byType[type]!;
                if (glyph.name === 'noSym') { note.notehead = 'none'; delete note.noteheadFilled; }
                else { note.noteheadSmufl = glyph; note.notehead = 'other'; }
            } else if (!note.sourceNotehead && drum!.notehead !== 'normal') note.notehead = drum!.notehead;
            event.stem ??= drum!.defaultStem;
            continue;
        }
        const transpose = context ? context.sourceInstrumentTranspose ?? context.transpose : part.sourceInstrumentTranspose ?? part.transpose;
        const reference = pitch(midi, tpc, source);
        if (note.kind === 'dead') note.referenceSounding = reference; else note.sounding = reference;
        const transposed = tpc2 !== undefined ? pitch(midi - (transpose?.chromatic ?? 0), tpc2, source) : writtenFromSounding(reference, transpose, source);
        note.written = sourceView?.concertPitch ? { ...reference } : transposed;
        if(note.centOffset?.value){
            const cents=note.centOffset.value;note.microtonalPitch={source:note.centOffset.source,baseSounding:{...reference},cents};
            const sounding={...reference,midi:reference.midi+cents/100,alter:reference.alter+cents/100,origin:'inferred' as const};
            if(note.kind==='dead')note.referenceSounding=sounding;else note.sounding=sounding;
        }
    }
    for (const part of parts) for (const m of part.measures) {
        if (m.staffs!.length !== part.staves!.length) refuse('native-measure', 'Staff measures are missing or misaligned.', m.source);
        for (let i = 0; i < m.voices.length; i++) m.voices[i] ??= [];
    }
    const cacheParts = new Map(parts.map(part => [part.id, part]));
    for (const fact of cachedMeasureViews) {
        const part = cacheParts.get(fact.partId)!, node = cachedNodes.get(fact)!, subset = part.measures.slice(fact.startMeasure, fact.startMeasure + fact.count);
        if (subset.length !== fact.count) { performanceGap('native-cache-content', fact.source, 'Cached multirest count extends beyond its linked primary measure sequence; exact view data is retained without changing primary clocks.'); continue; }
        fact.span = subset.reduce((span, measure) => add(span, measure.duration), q(0));
        const initialStaff = subset[0].staffs!.find(s => s.number === fact.staff)!, meter = initialStaff.time!;
        const notationNodes = children(node, 'voice').flatMap(voice => voice.children);
        const ordinaryRestOnly = !credits.some(credit => credit.partId === fact.partId && credit.beforeMeasure > fact.startMeasure && credit.beforeMeasure < fact.startMeasure + fact.count) && subset.every(measure => !measure.repeatStart && !measure.repeatEnd && !measure.directions?.length && !measure.changes?.length &&
            measure.staffs!.filter(staff => staff.number === fact.staff).every(staff => staff.clef === initialStaff.clef && staff.key?.fifths === initialStaff.key?.fifths && staff.key?.mode === initialStaff.key?.mode && staff.time!.beats === meter.beats && staff.time!.unit === meter.unit && staff.printObject === initialStaff.printObject) &&
            !measure.barlines?.some(barline => barline.fermata || barline.location !== 'right' || barline.style !== 'regular') &&
            measure.staffs!.every(staff => equal(measure.duration, mul(q(staff.time!.beats, staff.time!.unit), q(4)))) &&
            measure.voices.slice((fact.staff - 1) * 4, fact.staff * 4).some(voice => voice.length > 0) &&
            measure.voices.slice((fact.staff - 1) * 4, fact.staff * 4).every(voice => voice.every(event => !event.notes.length && !event.grace && !event.fermata && !event.symbols?.length && !event.lyrics?.length && !event.articulations?.length && !event.ornaments?.length)));
        const cacheRestOnly = notationNodes.every(n =>
            n.name === 'Rest' && text(n, 'durationType') === 'measure' && !Object.keys(n.attrs).length && n.children.every(c => ['durationType', 'duration'].includes(c.name) || layout.has(c.name)) ||
            n.name === 'TimeSig' && !Object.keys(n.attrs).length && n.children.every(c => ['sigN', 'sigD'].includes(c.name) || layout.has(c.name)) && Number(text(n, 'sigN')) === meter.beats && Number(text(n, 'sigD')) === meter.unit);
        const cacheRootOnly = node.children.every(c => ['multiMeasureRest', 'voice'].includes(c.name) || layout.has(c.name));
        const cacheSpan = (raw: string): Rational | undefined => {
            if (!/^\d{1,9}\/[1-9]\d{0,8}$/.test(raw)) return undefined;
            try { const [n, d] = raw.split('/').map(Number); return mul(q(n, d), q(4)); }
            catch (error) { if (error instanceof Refusal) return undefined; throw error; }
        };
        const encodedSpan = fact.encodedSpan ? cacheSpan(fact.encodedSpan.raw) : undefined;
        const spanMatches = encodedSpan && equal(encodedSpan, fact.span);
        if (!ordinaryRestOnly || !cacheRestOnly || !cacheRootOnly || !spanMatches) { performanceGap('native-cache-content', fact.source, 'Cached multirest musical content/span is not verified as an unmarked nominal primary rest-only alias. Located view facts and original cache bytes remain retained; primary music, annotations and clocks are independently converted without applying a collapsed-rest instruction.'); continue; }
        fact.contentStatus = 'verified-rest-alias'; (subset[0].collapsedRests ??= []).push({ source: fact.source, staff: fact.staff, count: fact.count });
        if (fact.restValues.some(value => { const span = cacheSpan(value.raw); return !span || !equal(span, fact.span!); })) performanceGap('native-cache-stale-rest-clock', fact.source, 'The cached full-rest elapsed value differs from its verified primary rest subset/span. Its source value remains explicit view data; it does not replace primary duration or the multirest count instruction.');
    }
    recoverArpeggios(parts, budget);
    const measureClocks = new Map<MusicalPart, Rational[]>();
    for (const part of parts) { const clocks: Rational[] = []; let clock = q(0); for (const m of part.measures) { clocks.push(clock); clock = add(clock, m.duration); } measureClocks.set(part, clocks); }
    const objectByEid = new Map<string, typeof objectPeers>(), objectByClock = new Map<string, typeof objectPeers>();
    const objectClockKey = (globalStaff: number, fact: typeof objectPeers[number]['fact']) => {
        const part = cacheParts.get(fact.partId)!;
        return `${globalStaff}:${fact.kind}:${(Number(fact.voiceId) - 1) % 4}:${clockKey(add(measureClocks.get(part)![fact.measure], fact.position))}`;
    };
    for (const peer of objectPeers) {
        if (peer.fact.sourceEid) { const list = objectByEid.get(peer.fact.sourceEid) ?? []; list.push(peer); objectByEid.set(peer.fact.sourceEid, list); }
        const key = objectClockKey(peer.globalStaff, peer.fact), list = objectByClock.get(key) ?? []; list.push(peer); objectByClock.set(key, list);
    }
    const objectStaffIds = new Map(Array.from(staffOwners, ([global, value]) => [`${value.part.id}:${value.definition.number}`, global]));
    for (const link of sourceObjectLinks) {
        const globalStaff = objectStaffIds.get(`${link.owner.partId}:${link.owner.staff}`);
        const candidates = link.targetEid ? objectByEid.get(link.targetEid.value) ?? [] : link.relativeStaff && globalStaff !== undefined ? objectByClock.get(objectClockKey(globalStaff + link.relativeStaff.value, link.owner)) ?? [] : [];
        if (candidates.length === 1 && candidates[0].fact.kind === link.owner.kind && candidates[0].fact.source !== link.owner.source) {
            link.target = candidates[0].fact; link.status = 'located-primary-peer';
        } else performanceGap('native-object-link-unresolved', link.source, 'The exact source editing-link target and owner remain located source metadata. A unique same-kind primary peer could not be established; no musical alias/content equivalence or alternate view is inferred from this reference.');
    }
    recoverLyrics(parts, measureClocks, performanceGap, lyricCaptionSources);
    // One source-owned voice index supports exclusive ornament span endpoints, including
    // a native stop inside a note. Standard notation attaches to that final included event.
    const trillVoices = new Map<string, { event: MusicalEvent; clock: Rational }[]>();
    const trillScopes = new Set(links.filter(link => link.type === 'Trill' && link.next).map(link => `${link.anchor.part.id}:${(link.anchor.staff - 1) * 4 + link.anchor.voice}`));
    if (trillScopes.size) for (const part of parts) for (let mi = 0; mi < part.measures.length; mi++) for (let vi = 0; vi < part.measures[mi].voices.length; vi++) {
        const key = `${part.id}:${vi}`, events = trillVoices.get(key) ?? [];
        if (!trillScopes.has(key)) continue;
        for (const event of part.measures[mi].voices[vi]) if (!event.grace) events.push({ event, clock: add(measureClocks.get(part)![mi], event.start) });
        trillVoices.set(key, events);
    }
    const target = (link: Link, endpoint: Element): Anchor => {
        const location = child(endpoint, 'location', true)!;
        const a = link.anchor;
        return { ...a, globalStaff: a.globalStaff + int(location, 'staves', -255, 255, 0), measure: a.measure + int(location, 'measures', -100000, 100000, 0), voice: a.voice + int(location, 'voices', -3, 3, 0), position: add(a.position, get(location, 'fractions') ? mul(fraction(text(location, 'fractions'), location), q(4)) : q(0)), noteIndex: a.noteIndex + int(location, 'notes', -128, 128, 0), graceIndex: int(location, 'grace', -1, 127, -1) };
    };
    // Prepare pure source reciprocal identities before original relation/report emission.
    // Final reciprocal validation below remains literal and mandatory.
    const trillReceivers = new Map<string, Link | null>();
    let trillReceiverSyntaxSafe = trillAttachmentProfile;
    if (trillAttachmentProfile) for (const link of links) if (link.type === 'Trill' && link.prev) {
        const node = link.element, a = link.anchor;
        const simple = Object.keys(node.attrs).length === 1 && node.attrs.type === 'Trill'
            && /^[ \t\r\n]*$/.test(node.text) && !hasCommentOrCdata(node)
            && node.children.length === 1 && node.children[0] === link.prev && trillLocation(link.prev)
            && !link.next && !a.event && !a.note && a.graceIndex === -1;
        if (!simple) { trillReceiverSyntaxSafe = false; continue; }
        let previous: Anchor;
        try { previous = target(link, link.prev); }
        catch (error) { if (!(error instanceof Refusal)) throw error; trillReceiverSyntaxSafe = false; continue; }
        if (previous.part !== a.part || previous.staff !== a.staff || previous.globalStaff !== a.globalStaff
            || previous.voice !== a.voice || previous.event || previous.note || previous.graceIndex !== -1) { trillReceiverSyntaxSafe = false; continue; }
        const key = `Trill:${anchorKey(a)}:${anchorKey(previous)}`;
        trillReceivers.set(key,trillReceivers.has(key) ? null : link);
    }
    const trillContexts = new Map<SourceTrillBar, SourceTrillCarrierIndex | null>();
    const qualifiedTrillContext = (part:MusicalPart,staff:number,measure:number):SourceTrillCarrierIndex|undefined => {
        const context = trillSourceBars.get(part)?.get(staff)?.get(measure);
        if (!context?.safe) return undefined;
        const bar = context.bar;
        if (!trillContexts.has(bar)) {
            bar.start = measureClocks.get(part)![measure];
            // Refresh only final settled before/after-grace clocks, once per context.
            for (const row of bar.rows) row.clock = add(bar.start,row.event.start);
            const pool = trillSourcePool(bar,staff);
            trillContexts.set(bar,pool ? indexNativeTrillCarriers(pool) ?? null : null);
        }
        return trillContexts.get(bar) ?? undefined;
    };
    const trillMeasureContaining = (part:MusicalPart,clock:Rational):number => {
        const clocks = measureClocks.get(part)!;let lo=0,hi=clocks.length;
        while (lo<hi) { const mid=(lo+hi)>>>1;if(compare(clocks[mid],clock)<=0)lo=mid+1;else hi=mid; }
        const measure=lo-1;
        return measure>=0 && compare(clock,add(clocks[measure],part.measures[measure].duration))<0 ? measure : -1;
    };
    const starts = new Map<string, Link>(), ties = new Map<MusicalNote, MusicalNote>(), tiedBack = new Set<MusicalNote>();
    const relations: MusicalRelation[] = [];
    const relationEndpoint = (a: Anchor): RelationEndpoint => ({ partId: a.part.id, measure: a.measure, position: a.position, staff: a.staff,
        voiceId: String((a.staff - 1) * 4 + a.voice + 1), ...(a.event ? { eventId: a.event.id } : {}), ...(a.note ? { noteId: a.note.id } : {}), ...(a.graceIndex !== -1 ? { graceIndex: a.graceIndex } : {}) });
    const directionBoundaries = new Map<string, { link: Link; relation: MusicalRelation } | null>();
    const boundaryKey = (type: string, endpoint: Anchor, previous: Anchor): string | undefined => {
        if (!['Pedal', 'HairPin', 'Ottava', 'Volta', 'TextLine', 'Trill'].includes(type) || endpoint.note || endpoint.event || previous.note || previous.event || endpoint.graceIndex !== -1 || previous.graceIndex !== -1) return undefined;
        const owner = staffOwners.get(endpoint.globalStaff), measure = endpoint.part.measures[endpoint.measure], clocks = measureClocks.get(endpoint.part)!;
        if (!owner || owner.part !== endpoint.part || endpoint.voice < 0 || endpoint.voice > 3 || !measure || endpoint.position.n !== 0 && !equal(endpoint.position, measure.duration)) return undefined;
        return `${type}:${endpoint.part.id}:${endpoint.globalStaff}:${endpoint.voice}:${clockKey(add(clocks[endpoint.measure], endpoint.position))}:${anchorKey(previous)}`;
    };
    const modernBendRecords: NativeBendRecord[] = [];
    const hammerOns: { source: Anchor; destination: Anchor; element: Element; payload: SpanPayload }[] = [];
    const slurs: { source: Anchor; destination: Anchor; element: Element; relationId: string; payload: SpanPayload }[] = [];
    const globalStaffByPart = new Map<MusicalPart, Map<number, number>>();
    for (const [global, owner] of staffOwners) { const staffs = globalStaffByPart.get(owner.part) ?? new Map<number, number>(); staffs.set(owner.definition.number, global); globalStaffByPart.set(owner.part, staffs); }
    for (const link of links) if (link.next) {
        const destination = target(link, link.next), source = link.anchor;
        const { noteLine, glissando, trillForm, trillOrnament, modernBend, ...details } = link.payload;
        if (link.type === 'Tie' || link.type === 'Slur' || link.type === 'NoteLine' || link.type === 'Glissando' || link.type === 'GuitarBend' || link.type === 'HammerOnPullOff') {
            const endpoint = anchors.get(anchorKey(destination));
            if (!source.event || !endpoint?.event || endpoint.part !== source.part || ['Tie', 'NoteLine', 'Glissando', 'GuitarBend'].includes(link.type) && (!source.note || !endpoint.note)) return refuse('native-spanner', 'Spanner endpoint does not resolve to its source event/note kind.', link.element.location);
            if (link.type === 'HammerOnPullOff') hammerOns.push({ source, destination: endpoint, element: link.element, payload: link.payload });
            if (link.type === 'GuitarBend') {
                if (!modernBend) refuse('native-bend', 'A modern bend needs its source definition.', link.element.location);
                modernBendRecords.push({shape:modernBend!,start:source.note!,end:endpoint.note!,endpoints:{start:relationEndpoint(source),end:relationEndpoint(endpoint)},
                    ...(details.printObject!==undefined?{printObject:details.printObject}:{}),...(details.sourceColor?{sourceColor:details.sourceColor}:{})});
                if (source.note === endpoint.note) {
                    if (!['slight-bend', 'dip', 'scoop'].includes(modernBend!.type)) refuse('native-bend-clock', 'This modern bend kind requires separate connected source notes.', link.element.location);
                    starts.set(`${link.type}:${anchorKey(destination)}:${anchorKey(source)}`, link); continue;
                }
            }
            if (link.type === 'Glissando') {
                const startClock = add(measureClocks.get(source.part)![source.measure], source.position), endClock = add(measureClocks.get(endpoint.part)![endpoint.measure], endpoint.position);
                if (compare(startClock, endClock) >= 0 || source.note === endpoint.note) refuse('native-glissando-clock', 'Glissando needs distinct chronological note endpoints.', link.element.location);
                relations.push({ ...details, source: link.element.location, id: `native-relation-${relations.length + 1}`, kind: 'glissando', ...glissando!, start: relationEndpoint(source), end: relationEndpoint(endpoint) });
                starts.set(`${link.type}:${anchorKey(destination)}:${anchorKey(source)}`, link); continue;
            }
            if (link.type === 'NoteLine') {
                const clocks = measureClocks.get(source.part)!, startClock = add(clocks[source.measure], source.position), endClock = add(clocks[endpoint.measure], endpoint.position);
                if (compare(startClock, endClock) > 0 || source.note === endpoint.note) refuse('native-note-line-clock', 'A visual note line must retain distinct chronological source note endpoints.', link.element.location);
                relations.push({ ...details, source: link.element.location, id: `native-relation-${relations.length + 1}`, kind: 'note-line', ...noteLine!, start: relationEndpoint(source), end: relationEndpoint(endpoint) });
                performanceGap('native-note-line-notation', link.element.location, 'The source visual note connection and exact component endpoints remain located facts. Standard other-notation retains a paired note annotation without inventing glissando playback; native line geometry, continuation labels and hooks require consumer interpretation.');
                starts.set(`${link.type}:${anchorKey(destination)}:${anchorKey(source)}`, link); continue;
            }
            if (link.type === 'Tie') {
                if ((source.note!.kind === 'dead' || endpoint.note!.kind === 'dead') && performedIdentity(source.note!) !== performedIdentity(endpoint.note!)) refuse('native-tie', 'Tie endpoints contradict the encoded dead-note state/reference.', link.element.location);
                if ((source.note!.kind === 'unpitched' || endpoint.note!.kind === 'unpitched') && performedIdentity(source.note!) !== performedIdentity(endpoint.note!)) refuse('native-tie', 'Tie endpoints contradict source drum identity.', link.element.location);
                if (ties.has(source.note!) || tiedBack.has(endpoint.note!)) refuse('native-tie', 'Tie chain branches or repeats an endpoint.', link.element.location);
                ties.set(source.note!, endpoint.note!); tiedBack.add(endpoint.note!); source.note!.tieStart = true; endpoint.note!.tieStop = true;
                const metadata = { relationId: `native-relation-${relations.length + 1}`, ...(link.payload.printObject !== undefined ? { printObject: link.payload.printObject } : {}), ...(link.payload.orientation ? { orientation: link.payload.orientation } : {}), ...(link.payload.lineType ? { lineType: link.payload.lineType } : {}) };
                (source.note!.tieNotations ??= []).push({ type: 'start', ...metadata }); (endpoint.note!.tieNotations ??= []).push({ type: 'stop', ...metadata });
            }
            else slurs.push({ source, destination: source.note ? endpoint : { ...endpoint, note: undefined }, element: link.element, relationId: `native-relation-${relations.length + 1}`, payload: link.payload });
            relations.push({ ...details, source: link.element.location, id: `native-relation-${relations.length + 1}`, kind: link.type === 'Tie' ? 'tie' : 'slur', ...(link.type === 'GuitarBend' || link.type === 'HammerOnPullOff' ? { sourceTechnique: { source: link.element.location, kind: link.type === 'GuitarBend' ? 'bend-continuation' as const : 'hammer-on-pull-off' as const } } : {}), start: relationEndpoint(source), end: relationEndpoint(link.type === 'Slur' && !source.note ? { ...endpoint, note: undefined } : endpoint) });
        } else {
            const destinationOwner = staffOwners.get(destination.globalStaff);
            if (!destinationOwner || destinationOwner.part !== source.part) return refuse('native-spanner', 'Direction endpoint does not resolve within its source part.', link.element.location);
            const end = { ...destination, part: source.part, staff: destinationOwner.definition.number, event: undefined, note: undefined };
            if (end.measure === source.part.measures.length && end.position.n === 0) { end.measure--; end.position = source.part.measures[end.measure].duration; }
            const endMeasure = source.part.measures[end.measure];
            if (!endMeasure || compare(end.position, q(0)) < 0 || compare(end.position, endMeasure.duration) > 0) refuse('native-spanner', 'Direction endpoint clock lies outside its source part measure.', link.element.location);
            const base = { ...details, source: link.element.location, id: `native-relation-${relations.length + 1}`, start: relationEndpoint(source), end: relationEndpoint(end) };
            const lineOwner=child(link.element,link.type);
            if(lineOwner&&['TextLine','HairPin','Pedal'].includes(link.type)){
                const endStaff=endMeasure.staffs?.find(staff=>staff.number===end.staff);
                const scale=(a:Anchor,staff?:StaffFact):NativeTextScaleContext=>base.system?{scope:'score',source:lineOwner.location}:staff?{scope:'staff',source:staff.source,staffSize:staff.staffSize}:a.textScale??{scope:'staff',source:lineOwner.location};
                linePresentation(lineOwner,base,{beginText:scale(source),endText:scale(end,endStaff),continueText:scale(source)});
                resolveInline(lineOwner,base);
                for(const gap of deferredCaptionGaps.get(lineOwner)??[]){
                    const facts=gap.code.includes('size')?Object.values(base.textFontSizes??{}).filter(f=>f?.pointSize):Object.values(base.textFontStyles??{});
                    let recovered=facts.some(f=>f?.source.member===gap.source.member&&f?.source.path===gap.source.path);
                    if(!recovered&&gap.code==='native-text-line-emphasis-context')for(const [slot,property] of [['beginText','beginFontStyle'],['continueText','continueFontStyle'],['endText','endFontStyle']] as const){
                        const fields=children(lineOwner,property),fact=base.textFontStyles?.[slot];
                        if(fact&&fields.some(f=>f.location.member===gap.source.member&&f.location.path===gap.source.path)&&fields.every(f=>!f.children.length&&!Object.keys(f.attrs).length&&/^\d+$/.test(f.text.trim())&&Number(f.text.trim())===fact.value))recovered=true;
                    }
                    if(!recovered&&gap.code==='native-hairpin-caption-emphasis-context'){
                        const caption=base.textFacts?.beginText,fact=base.textFontStyles?.beginText;
                        recovered=!!fact&&!!caption&&caption.source.member===gap.source.member&&caption.source.path===gap.source.path;
                    }
                    if(!recovered)performanceGap(gap.code,gap.source,gap.message);
                }
                deferredCaptionGaps.delete(lineOwner);
            }

            if (link.type === 'Pedal' || link.type === 'HairPin') {
                const kind = link.type === 'Pedal' ? 'pedal' : 'wedge', subtype = link.subtype || '0';
                if (kind === 'wedge' && !['0', '1', '2', '3'].includes(subtype)) refuse('native-hairpin', 'Unknown hairpin subtype.', link.element.location);
                if (kind === 'wedge' && ['2', '3'].includes(subtype)) relations.push({ ...base, kind: 'text-line', beginText: base.beginText ?? (subtype === '2' ? 'cresc.' : 'dim.'), line: 'dashes', lineType: 'dashed' });
                else {
                    const pedal = link.payload.pedalState;
                    const sourcePedal = kind === 'pedal' ? child(link.element, 'Pedal') : undefined;
                    const closingHook = sourcePedal ? child(sourcePedal, 'endHookType') : undefined;
                    if (closingHook?.text.trim() === '2')
                        performanceGap('native-pedal-closing-hook-projection', closingHook.location, 'The exact source pedal interval, ownership, closing-hook value and visibility remain located. Standard MusicXML preserves the paired interval instruction, but its closing line hook does not encode this native 45-degree angle or determine a connection or re-pedalling between separately authored source lines. No endpoint or neighboring pedal state is invented.' + (Number(capture.nativeVersion) < 4.4 ? ' Before format 4.40 MuseScore drew this 45-degree end at the last chord rather than the saved end; the saved end is kept.' : ''));
                    // Plain standard spellings or one unstyled canonical pedal glyph are the
                    // standard sign. Styled or mixed runs stay authored words.
                    const canonicalPedalGlyph = (field: 'beginText' | 'endText'): boolean => {
                        const runs = base.textRuns?.[field];
                        if (runs?.length !== 1) return false;
                        const [run] = runs;
                        return (field === 'beginText' ? ['keyboardPedalPed', 'keyboardPedalSost', 'keyboardPedalS'] : ['keyboardPedalUp']).includes(run.symbolName ?? '')
                            && run.emphasis === 0 && !run.emphasisResets && !run.textFontSize && !run.script && !run.sourceFont && !run.sourceText;
                    };
                    // Only an independent SMuFL scale sizes the sign itself. Under the legacy
                    // fragment rule the glyph follows its text size and that qualification.
                    const pedalSignMusicSize = (size: TextFontSize | undefined): boolean => size?.pointSize?.music?.rule === 'smufl-scale';
                    const standardPedalSign = (field: 'beginText' | 'endText'): boolean => (!base.textRuns?.[field]?.length || canonicalPedalGlyph(field)) && (field === 'beginText' ? /^(?:Ped\.|Sost\.|S)$/.test(base.beginText ?? '') : base.endText === '*');
                    if (kind === 'pedal' && base.lineType === 'dotted' && base.lineVisible !== false)
                        performanceGap('native-pedal-dotted-line-projection', link.element.location, 'Standard pedal has no line-pattern field. Its typed endpoints remain transparent while one paired standard dotted bracket and original caption/sign preserve the source performer instruction at the exact clocks. Source hook geometry and system layout remain separate facts.', 'preserved');
                    if (kind === 'pedal') for (const field of ['beginText', 'endText'] as const) {
                        const style = base.textFontStyles?.[field];
                        if (style && style.value & 12 && standardPedalSign(field) && !(base.lineType === 'dotted' && base.lineVisible !== false))
                            performanceGap('native-pedal-sign-decoration', style.source, 'Exact source underline/strike emphasis remains located. Standard pedal signs retain bold/italic but cannot encode those text decorations; the useful presentation difference is explicit.');
                    }
                    const action = kind === 'wedge' ? subtype === '1' ? 'diminuendo' : 'crescendo' : /^(?:Sost\.|S)$/.test(pedal?.beginText.value ?? '') ? 'sostenuto' : pedal?.startHook === 2 ? 'change' : pedal?.startHook === 0 && base.lineVisible !== false && !base.beginText ? 'resume' : 'start';
                    const stop = kind === 'pedal' && pedal?.endHook === 0 && base.lineVisible !== false && !base.endText ? 'discontinue' : 'stop';
                    source.part.measures[source.measure].directions!.push({ source: link.element.location, relationId: base.id, position: source.position, staff: source.staff, kind, action,
                        ...(base.sourceColor ? { sourceColor: base.sourceColor } : {}),
                        ...(base.placement ? { placement: base.placement.value } : {}), ...(base.printObject !== undefined ? { printObject: base.printObject } : {}),
                        ...(kind === 'pedal' ? { sign: standardPedalSign('beginText'), ...(pedalSignMusicSize(base.textMusicFontSizes?.beginText)?{musicFontSize:base.textMusicFontSizes!.beginText!}:{}), ...(base.beginText === 'S' ? { abbreviated: true } : {}), ...(base.textFontStyles?.beginText ? { textFontStyle: base.textFontStyles.beginText } : {}), ...(base.textFontSizes?.beginText && standardPedalSign('beginText') ? { textFontSize: base.textFontSizes.beginText } : {}) } : {}), ...(base.lineVisible !== undefined ? { line: base.lineVisible } : {}), ...(kind === 'wedge' && base.niente && subtype === '0' ? { niente: true } : {}) });
                    source.part.measures[end.measure].directions!.push({ source: link.element.location, relationId: base.id, position: end.position, staff: end.staff, kind, action: stop,
                        ...(base.sourceColor ? { sourceColor: base.sourceColor } : {}),
                        ...(base.placement ? { placement: base.placement.value } : {}), ...(base.printObject !== undefined ? { printObject: base.printObject } : {}),
                        ...(kind === 'pedal' ? { sign: standardPedalSign('endText'), ...(pedalSignMusicSize(base.textMusicFontSizes?.endText)?{musicFontSize:base.textMusicFontSizes!.endText!}:{}), ...(base.textFontStyles?.endText ? { textFontStyle: base.textFontStyles.endText } : {}), ...(base.textFontSizes?.endText && standardPedalSign('endText') ? { textFontSize: base.textFontSizes.endText } : {}) } : {}), ...(base.lineVisible !== undefined ? { line: base.lineVisible } : {}), ...(kind === 'wedge' && base.niente && subtype === '1' ? { niente: true } : {}) });
                    relations.push(kind === 'pedal' ? { ...base, kind: 'pedal' } : { ...base, kind: 'wedge', diminuendo: subtype === '1' });
                    const sourceHairpin = kind === 'wedge' ? child(link.element, 'HairPin') : undefined;
                    const sourceBeginText = sourceHairpin ? child(sourceHairpin, 'beginText') : undefined;
                    for (const [a, value, field] of [[source, base.beginText, 'beginText'], [end, base.endText, 'endText']] as const) if (value && !(kind === 'pedal' && standardPedalSign(field))) a.part.measures[a.measure].directions!.push({ source: link.element.location, position: a.position, staff: a.staff, kind: 'words', text: value,
                        ...(legacyInvalidHairpinCaption(link.type, subtype, field, sourceBeginText) ? { sourceText: sourceBeginText.text } : {}),
                        ...(base.textFontSizes?.[field] ? { textFontSize: base.textFontSizes[field] } : {}),
                        ...(base.textFontFamilies?.[field] ? { textFontFamily: base.textFontFamilies[field] } : {}),
                        ...(base.textFontStyles?.[field] ? { textFontStyle: base.textFontStyles[field] } : {}),
                        ...(base.textRuns?.[field] ? { textRuns: base.textRuns[field] } : {}),
                        ...(base.sourceColor ? { sourceColor: base.sourceColor } : {}),
                        ...(base.placement ? { placement: base.placement.value } : {}), ...(base.printObject !== undefined ? { printObject: base.printObject } : {}) });
                }
            } else if (link.type === 'Ottava') {
                if (source.staff !== end.staff || source.graceIndex !== -1 || end.graceIndex !== -1) refuse('native-ottava', 'Octave lines must retain one source staff and ordinary clock boundaries.', link.element.location);
                const zero = equal(add(measureClocks.get(source.part)![source.measure], source.position), add(measureClocks.get(end.part)![end.measure], end.position));
                relations.push({ ...base, kind: 'ottava', octaves: link.payload.octaves ?? 1, ...(zero ? { projection: { source: link.element.location, kind: 'words-bracket' as const, reason: 'zero-duration' as const } } : {}) });
                if (zero) performanceGap('native-zero-ottava', link.element.location, 'The reciprocal source octave label/line has a zero-duration view scope. Its paired standard words/bracket instruction and exact source endpoints are retained; it applies no register interval to notes.');
            } else if (nativeTechniqueLines.has(link.type)) {
                if (source.staff !== end.staff || source.voice !== end.voice || source.graceIndex !== -1 || end.graceIndex !== -1)
                    refuse('native-technique-line', 'A performer technique line must retain its source staff, voice and ordinary clock boundaries.', link.element.location);
                const clocks = measureClocks.get(source.part)!;
                if (compare(add(clocks[source.measure], source.position), add(clocks[end.measure], end.position)) >= 0)
                    refuse('native-technique-line', 'A performer technique span needs a positive source duration.', link.element.location);
                relations.push({ ...base, kind: 'text-line', line: base.lineType === 'dashed' ? 'dashes' : 'bracket' });
            } else if (link.type === 'TextLine') {
                const content = child(link.element, 'TextLine'), styles = content ? children(content, 'lineStyle') : [];
                const knownHooks = !!content && (['begin', 'end'] as const).every(side => {
                    const hooks = children(content, `${side}HookType`);
                    return !hooks.length || hooks.length === 1 && plainLineShape(hooks[0])
                        && (hooks[0].text.trim() === '0' || qualifiedLineHook(content, side));
                });
                const hooked = knownHooks && (qualifiedLineHook(content!, 'begin') || qualifiedLineHook(content!, 'end'));
                const dotted = textLineShapeProfile && knownHooks && styles.length === 1 && plainLineShape(styles[0]) && ['3', '5', 'dotted'].includes(styles[0].text.trim());
                relations.push({ ...base, kind: 'text-line', line: (base.lineType ?? 'solid') === 'solid' || hooked || dotted ? 'bracket' : 'dashes' });
                if (hooked || dotted) performanceGap('native-text-line-standard-shape', link.element.location,
                    'The examined TextLine hook direction, including its positive native default height, and dotted line type remain source-bound. Standard brackets retain directional hooks and solid/dashed/dotted line types at the original endpoints; exact custom dash spacing and diagonal hook angles remain separate projection limits.', 'preserved');
            }
            else if (link.type === 'Trill') {
                if (source.staff !== end.staff || source.voice !== end.voice || source.graceIndex !== -1 || end.graceIndex !== -1) refuse('native-trill', 'Trill span must retain an ordinary source-owned voice and staff.', link.element.location);
                const events = trillVoices.get(`${source.part.id}:${(source.staff - 1) * 4 + source.voice}`) ?? [];
                const startClock = add(measureClocks.get(source.part)![source.measure], source.position), endClock = add(measureClocks.get(source.part)![end.measure], end.position);
                const lowerBound = (clock: Rational) => { let lo = 0, hi = events.length; while (lo < hi) { const mid = (lo + hi) >>> 1; if (compare(events[mid].clock, clock) < 0) lo = mid + 1; else hi = mid; } return lo; };
                const first = events[lowerBound(startClock)], last = events[lowerBound(endClock) - 1];
                const zero = equal(startClock, endClock);
                if (!first || !equal(first.clock, startClock) || compare(startClock, endClock) > 0 || !zero && (!last || compare(last.clock, startClock) < 0)) refuse('native-trill', 'Trill notation needs an exact ordinary source host and chronological span; no nearest note is selected.', link.element.location);
                if (zero && (!first.event.notes.length || first.event.notes.some(note => note.kind !== 'pitched'))) refuse('native-trill', 'The verified zero-duration glyph needs an actual pitched source chord host; rest/unpitched ownership remains unproved.', link.element.location);
                if (zero && (trillForm ?? 'trill') !== 'trill') refuse('native-trill', 'Only the verified zero-duration trill glyph has a point-ornament projection.', link.element.location);
                base.start.eventId = first.event.id; base.end.eventId = zero ? first.event.id : last.event.id;
                for (const fact of base.segmentTracks ?? []) {
                    const printedGlobal = globalStaffByPart.get(source.part)!.get(first.event.staff ?? source.staff)!;
                    if (fact.value !== (printedGlobal - 1) * 4 + source.voice) refuse('native-segment-track', 'Encoded trill segment track contradicts its resolved printed host event.', fact.source);
                    fact.printedOwnerEventId = first.event.id;
                }
                let notationAttachments: Extract<MusicalRelation,{kind:'trill'}>['notationAttachments'];
                if (!zero && trillReceiverSyntaxSafe && trillSourceHeader(link.element,link.next!)
                    && !source.event && !source.note && !end.event && !end.note && source.part === end.part
                    && source.globalStaff === end.globalStaff && source.staff === end.staff && source.voice === end.voice
                    && source.graceIndex === -1 && end.graceIndex === -1) {
                    const receiver = trillReceivers.get(`Trill:${anchorKey(destination)}:${anchorKey(source)}`);
                    if (receiver && receiver.anchor.part === source.part) {
                        const endMeasure = trillMeasureContaining(source.part,add(endClock,q(-1,480)));
                        const startIndex = qualifiedTrillContext(source.part,source.staff,trillMeasureContaining(source.part,startClock));
                        const endIndex = qualifiedTrillContext(source.part,source.staff,endMeasure);
                        if (startIndex && endIndex) notationAttachments = selectNativeTrillCarriers(startIndex,endIndex,source.part.id,source.staff,startClock,endClock,endMeasure);
                        if (notationAttachments) budget.add('markings',2,link.element.location);
                    }
                }
                relations.push({ ...base, kind: 'trill', form: trillForm ?? 'trill', ...(trillOrnament ? { ornament: trillOrnament } : {}), ...(zero ? { projection: { source: link.element.location, kind: 'point-ornament' as const, reason: 'zero-duration' as const } } : {}), ...(notationAttachments ? {notationAttachments} : {}) });
                if (zero) performanceGap('native-zero-trill-glyph', link.element.location, 'The reciprocal zero-duration source relation has an exact ordinary host. Verified native drawing shows its visible trill glyph without a positive line span; standard trill-mark preserves that point instruction and source visibility, without inventing a wavy extension or playback interval.', 'preserved');
                if (!trillOrnament?.intervalAbove) performanceGap('native-trill-default-neighbor', link.element.location, 'No explicit ornament interval is encoded. The native automatic-neighbor realization is not established by a bare MusicXML trill mark; source notation, span and written clocks remain preserved.');
                if (!zero && !notationAttachments && !equal(add(last.clock, last.event.duration), endClock)) performanceGap('native-trill-endpoint-projection', link.element.location, 'The exact native ornament span endpoint remains a located relation fact. Standard MusicXML wavy-line notation attaches to the final included source event and cannot express this interior/gapped engine boundary; written clocks and attacks are unchanged.');
                if (notationAttachments) performanceGap('native-trill-notation-attachments',link.element.location,'The paired native start/end notation carriers are independently source-qualified across the staff tracks. Logical span endpoints and legacy host event IDs remain unchanged; located notation attachments preserve actual ordinary carrier identity, visibility and source Origin without retiming.','preserved');
            }
            else if (link.type === 'Volta') {
                if (!link.payload.numbers) return refuse('native-ending', 'Ending needs explicit source numbers.', link.element.location);
                const interior = source.position.n !== 0 || !equal(end.position, endMeasure.duration) && end.position.n !== 0;
                if (interior && !base.beginText) return refuse('native-ending', 'An interior ending line needs its explicit performer label.', link.element.location);
                relations.push({ ...base, kind: 'ending', numbers: link.payload.numbers, closed: link.payload.closed ?? false, ...(interior ? { projection: { source: link.element.location, kind: 'words-bracket' as const, reason: 'interior-clock' as const } } : {}) });
                if (interior) performanceGap('native-ending-interior-projection', link.element.location, 'The exact source ending label, closed/open line, execution numbers and interior endpoints remain located. Standard words plus a paired bracket preserve that instruction at its source clocks; MusicXML barline ending cannot encode this interior scope, so typed repeat-ending interchange remains limited.');
            } else refuse('native-spanner', `${link.type} musical relation needs a verified endpoint notation rule.`, link.element.location);
        }
        starts.set(`${link.type}:${anchorKey(destination)}:${anchorKey(source)}`, link);
        const boundary = boundaryKey(link.type, destination, source);
        if (boundary) directionBoundaries.set(boundary, directionBoundaries.has(boundary) ? null : { link, relation: relations.at(-1)! });
    }
    for (const link of links) if (link.prev) {
        const previous = target(link, link.prev);
        const forward = starts.get(`${link.type}:${anchorKey(link.anchor)}:${anchorKey(previous)}`);
        if (forward) {
            continue;
        }
        const boundary = boundaryKey(link.type, link.anchor, previous), candidate = boundary ? directionBoundaries.get(boundary) : undefined;
        const location = child(link.prev, 'location', true)!;
        if (!candidate || link.next || child(link.element, link.type) || child(location, 'notes') || child(location, 'grace') || anchorKey(candidate.link.anchor) !== anchorKey(previous)) return refuse('native-spanner', 'Unmatched reciprocal endpoint reference.', link.element.location);
        (candidate.relation.endpointAliases ??= []).push({ source: link.element.location, endpoint: relationEndpoint(link.anchor), previous: relationEndpoint(previous) });
        performanceGap('native-direction-boundary-alias', link.element.location, 'The extra definition-free reciprocal direction stop is verified at the exact adjacent-measure boundary with the same source start, type, part, staff and voice. Its literal coordinates/location remain a typed alias; one musical relation is emitted.', 'inferred');
    }
    recoverNativeBendCurves(modernBendRecords,ties);
    {
        const noteAnchors=new Map<MusicalNote,Anchor>(), eventAnchors=new Map<MusicalEvent,Anchor>(), nextEvents=new Map<MusicalEvent,MusicalEvent>(), previousEvents=new Map<MusicalEvent,MusicalEvent>();
        for(const anchor of anchors.values()){if(anchor.note)noteAnchors.set(anchor.note,anchor);if(anchor.event)eventAnchors.set(anchor.event,anchor);}
        for(const part of parts)for(let voice=0;voice<part.measures.reduce((max,m)=>Math.max(max,m.voices.length),0);voice++){
            const events=part.measures.flatMap(m=>m.voices[voice]??[]);
            for(let i=0;i+1<events.length;i++){nextEvents.set(events[i],events[i+1]);previousEvents.set(events[i+1],events[i]);}
        }
        const barSources=new Set(links.filter(link=>link.type==='WhammyBar'&&link.next).map(link=>link.element.location));
        const barLines=relations.filter(relation=>barSources.has(relation.source));
        const endpointClock=(endpoint:RelationEndpoint,part:MusicalPart)=>add(measureClocks.get(part)![endpoint.measure],endpoint.position);
        const eventClock=(event:MusicalEvent)=>{const a=eventAnchors.get(event)!;return add(measureClocks.get(a.part)![a.measure],event.start);};
        const followingChord=(note:MusicalNote,record:NativeBendRecord):readonly MusicalNote[]|undefined=>{
            const anchor=noteAnchors.get(note)!;let next=nextEvents.get(anchor.event!);
            if(next&&!next.notes.length&&['dive','pre-dive','dip','scoop'].includes(record.shape.type)){
                const start=noteAnchors.get(record.start)!,startClock=eventClock(start.event!),restEnd=add(eventClock(next),next.duration);
                const covering=barLines.filter(line=>line.start.partId===start.part.id&&line.start.staff===start.staff&&compare(endpointClock(line.start,start.part),startClock)<0&&compare(endpointClock(line.end,start.part),restEnd)>=0);
                if(covering.length>1&&covering.some(line=>!equal(endpointClock(line.end,start.part),endpointClock(covering[0].end,start.part))))refuse('native-bend-hold-scope','Competing bar spans do not establish one following pre-dive scope.',record.shape.source);
                if(covering.length){const stop=endpointClock(covering[0].end,start.part);while(next&&!next.notes.length&&compare(eventClock(next),stop)<0)next=nextEvents.get(next);}
            }
            return next?.notes.length?next.notes:undefined;
        };
        const precedingBend=createNativeBendPredecessorLookup(modernBendRecords,ties,{previousChord:(record,note)=>{
            const anchor=noteAnchors.get(note)!;let previous=previousEvents.get(anchor.event!);
            if(previous&&!previous.notes.length&&record.shape.type==='pre-dive'){
                const start=noteAnchors.get(record.start)!,restClock=eventClock(previous),endClock=eventClock(noteAnchors.get(record.end)!.event!);
                const covering=barLines.filter(line=>line.start.partId===start.part.id&&line.start.staff===start.staff&&compare(endpointClock(line.start,start.part),restClock)<0&&compare(endpointClock(line.end,start.part),endClock)>=0);
                if(covering.length>1&&covering.some(line=>!equal(endpointClock(line.start,start.part),endpointClock(covering[0].start,start.part))))refuse('native-bend-hold-scope','Competing bar spans do not establish one preceding pre-dive scope.',record.shape.source);
                if(covering.length){const begin=endpointClock(covering[0].start,start.part);while(previous&&!previous.notes.length&&compare(eventClock(previous),begin)>0)previous=previousEvents.get(previous);}
            }
            return previous?.notes.length?previous.notes:undefined;
        }});
        const tabPresentation=recoverNativeTabPresentation({capture,scoreNode,parts,ties,modernBendRecords,budget,hasPrecedingBend:record=>!!precedingBend(record)});
        findings.push(...tabPresentation.findings);
        findings.push(...recoverNativeOrnamentPresentation({parts,relations,budget,isTop:tabPresentation.isTop,styles:primaryNode===scoreNode?[capture.styleRoot?.children[0],child(scoreNode,'Style')]:[child(scoreNode,'Style')]}));
        const isTab=(note:MusicalNote)=>{const a=noteAnchors.get(note)!;return a.part.measures[a.measure].staffs?.find(s=>s.number===a.staff)?.kind==='tablature';};
        relations.push(...recoverNativeBendHolds(modernBendRecords,ties,{
            endpoint:note=>relationEndpoint(noteAnchors.get(note)!),isTab,
            uncertainTop:record=>performanceGap('native-bend-hold-system-policy',record.shape.source,'This native optional hold depends on a top TAB component whose fret visibility is conditional on system layout. The source curve, hold mode and exact note endpoints remain retained; no page-dependent hold or string owner is invented.'),
            isTop:tabPresentation.isTop,
            nextChord:followingChord,
        }));
    }
    // Source clock indexes are independent from document-order MusicXML numbering in the writer.
    // Native pitch encodes the visual register before an octave line. Performed register is derived once.
    // MusicXML encodes that performed written register and octave-shift changes its displayed register.
    const octaveLines = new Map<string, Extract<MusicalRelation, { kind: 'ottava' }>[]>();
    for (const relation of relations) if (relation.kind === 'ottava') {
        if (relation.projection?.reason === 'zero-duration') continue;
        const key = `${relation.start.partId}:${relation.start.staff}`, entries = octaveLines.get(key) ?? [];
        entries.push(relation); octaveLines.set(key, entries);
    }
    const partsById = new Map(parts.map(p => [p.id, p]));
    const relationClock = (r: MusicalRelation, end = false) => {
        const endpoint = end ? r.end : r.start, part = partsById.get(endpoint.partId)!;
        return add(measureClocks.get(part)![endpoint.measure], endpoint.position);
    };
    for (const entries of octaveLines.values()) {
        entries.sort((a, b) => compare(relationClock(a), relationClock(b)));
        for (let i = 0; i < entries.length; i++) {
            if (compare(relationClock(entries[i]), relationClock(entries[i], true)) >= 0) refuse('native-ottava', 'Octave line stop must follow its start.', entries[i].source);
            if (i && compare(relationClock(entries[i]), relationClock(entries[i - 1], true)) < 0) refuse('native-ottava', 'Overlapping octave lines on one native staff need a verified ownership rule.', entries[i].source);
        }
    }
    const octaveAt = (part: MusicalPart, staff: number, clock: Rational) => {
        const entries = octaveLines.get(`${part.id}:${staff}`) ?? [];
        let low = 0, high = entries.length;
        while (low < high) { const middle = (low + high) >>> 1; if (compare(relationClock(entries[middle]), clock) <= 0) low = middle + 1; else high = middle; }
        const entry = entries[low - 1]; return entry && compare(clock, relationClock(entry, true)) < 0 ? entry : undefined;
    };
    const eventById = new Map<string, MusicalEvent>();
    for (const part of parts) for (const measure of part.measures) for (const voice of measure.voices) for (const event of voice) eventById.set(event.id, event);
    for (const part of parts) for (let mi = 0; mi < part.measures.length; mi++) for (let vi = 0; vi < part.measures[mi].voices.length; vi++) for (const event of part.measures[mi].voices[vi]) {
        const position = event.grace ? eventById.get(event.grace.hostId)!.start : event.start, clock = add(measureClocks.get(part)![mi], position), ownerStaff = Math.floor(vi / 4) + 1;
        const line = octaveAt(part, ownerStaff, clock), printed = octaveAt(part, event.staff ?? ownerStaff, clock);
        const differentScope = (line?.octaves ?? 0) !== (printed?.octaves ?? 0);
        if (differentScope && event.notes.length) performanceGap('native-ottava-printed-projection', event.source, 'Standard MusicXML pitch follows the displayed staff octave instruction, preserving native baseline register beneath its line. Native logical sounding ownership remains separately located; reproducing that software register difference is outside performer fidelity.');
        for (const note of event.notes) if (note.kind === 'pitched' && (printed || differentScope)) {
            const writtenOctave = note.written.octave + (printed?.octaves ?? 0);
            if (writtenOctave < 0 || writtenOctave > 9) refuse('native-ottava-register', 'Printed octave projection exceeds the standard pitch range.', note.source);
            note.printedOctaveShift = { source: printed?.source ?? event.source, octaves: printed?.octaves ?? 0, staff: event.staff ?? ownerStaff,
                ...(printed ? { relationId: printed.id } : {}), origin: printed ? 'source-line' : 'derived-no-line' };
        }
        if (line && line.performance?.play !== false) for (const note of event.notes) {
            if (note.kind !== 'pitched' || !note.sounding) return refuse('native-ottava', 'Octave line requires ordinary pitched events.', note.source);
            const octave = note.sounding.octave + line.octaves, writtenOctave = note.written.octave + line.octaves;
            if (octave < 0 || octave > 9 || writtenOctave < 0 || writtenOctave > 9) refuse('native-ottava-register', 'Derived octave register exceeds the standard pitch range.', note.source);
            note.octaveShift = { source: line.source, octaves: line.octaves };
            note.sounding = { ...note.sounding, octave, midi: note.sounding.midi + 12 * line.octaves, origin: 'inferred' };
        }
    }
    const caposByStaff = new Map<string, NonNullable<MusicalPart['capoChanges']>>();
    for (const part of parts) for (const capo of part.capoChanges ?? []) {
        const key = `${part.id}:${capo.staff}`, list = caposByStaff.get(key) ?? []; list.push(capo); caposByStaff.set(key, list);
    }
    for (const list of caposByStaff.values()) {
        list.sort((a, b) => a.measure - b.measure || compare(a.position, b.position));
        for (let i = 1; i < list.length; i++) if (list[i].measure === list[i - 1].measure && equal(list[i].position, list[i - 1].position))
            refuse('native-capo-conflict', 'Multiple capo states occupy the same source staff clock.', list[i].source);
    }
    for(const part of parts)for(const capo of part.capoChanges??[]){
        const context=sourceStateAt(part.instrumentChanges??[],capo.measure,capo.position);
        const staff=part.measures[capo.measure].staffs?.find(s=>s.number===capo.staff);
        const tuning=context?context.tuning:staff?.tuning??part.tuning;
        if(tuning)capo.appliedStrings={source:context?.source??staff?.source??part.source,stringCount:tuning.length,
            values:capo.active&&capo.fret>0?Array.from({length:tuning.length},(_,i)=>i+1).filter(string=>!capo.ignoredStrings?.values.includes(string)):[]};
        else if(capo.ignoredStrings?.values.length)performanceGap('native-capo-string-context',capo.source,'The exact partial capo mask remains source-owned, but this source instrument has no established StringData for its generated applied-string caption. No string count or tuning is invented.');
    }
    for (const { note, event, part, definition, measure, midi } of physicalNotes) {
        const context = event.instrumentContextId ? instrumentContextsById.get(event.instrumentContextId) : undefined;
        const tuning = context ? context.tuning : definition.tuning ?? part.tuning;
        const capo = sourceStateAt(caposByStaff.get(`${part.id}:${definition.number}`) ?? [], measure, event.start);
        const capod = capo?.active && !capo.ignoredStrings?.values.includes(note.string!) && capo.transposeMode?.value !== 'playback-only' ? capo.fret : 0;
        const transpose = context ? (context.sourceInstrumentTranspose ?? context.transpose)?.chromatic ?? 0 : (part.sourceInstrumentTranspose ?? part.transpose)?.chromatic ?? 0;
        if (!tuning || tuning[tuning.length - note.string!] === undefined || tuning[tuning.length - note.string!] + note.fret! + capod + transpose !== midi + 12 * (note.octaveShift?.octaves ?? 0))
            refuse('native-physical', 'Physical position contradicts the complete source tuning, active capo, instrument and octave state.', note.source);
    }
    const standardTieIdentity = (note: MusicalNote) => note.kind === 'unpitched' ? performedIdentity(note) : `pitch:${note.written.midi + (note.centOffset?.value??0)/100 + 12 * (note.printedOctaveShift?.octaves ?? note.octaveShift?.octaves ?? 0)}`;
    const octaveRelationsById = new Map([...octaveLines.values()].flat().map(r => [r.id, r]));
    const visualOctaveRelations = new Set<string>();
    for (const [source, destination] of ties) if (standardTieIdentity(source) !== standardTieIdentity(destination) && source.kind === 'pitched' && destination.kind === 'pitched' && source.written.midi === destination.written.midi) {
        for (const note of [source, destination]) if (note.printedOctaveShift?.relationId) visualOctaveRelations.add(note.printedOctaveShift.relationId);
    }
    for (const id of visualOctaveRelations) {
        const relation = octaveRelationsById.get(id)!;
        relation.projection = { source: relation.source, kind: 'words-bracket', reason: 'printed-scope-tie-conflict' };
        performanceGap('native-ottava-visual-projection', relation.source, 'This source octave line crosses a tied printed ownership boundary that a staff-wide MusicXML octave-shift cannot encode without changing the tie pitches. Standard words and a paired bracket preserve the native baseline notes and visible octave instruction; the typed source logical relation remains separately located.');
    }
    if (visualOctaveRelations.size) for (const part of parts) for (const measure of part.measures) for (const voice of measure.voices) for (const event of voice) for (const note of event.notes) {
        if (note.printedOctaveShift?.relationId && visualOctaveRelations.has(note.printedOctaveShift.relationId)) { note.printedOctaveShift.octaves = 0; note.printedOctaveShift.origin = 'derived-visual-line'; }
    }
    for (const [source, destination] of ties) {
        if (standardTieIdentity(source) !== standardTieIdentity(destination)) refuse('native-tie', 'Source tie endpoints would join different standard pitches after preserving their printed octave scopes.', source.source);
        if (performedIdentity(source) !== performedIdentity(destination)) performanceGap('native-tie-logical-register', source.source, 'The source tie preserves same standard pitch and its displayed endpoints; native logical sounding registers differ and remain separately located without a software playback promise.');
    }
    const absolute = (anchor: Anchor) => add(measureClocks.get(anchor.part)![anchor.measure], anchor.event?.start ?? anchor.position);
    const graceOrder = (anchor: Anchor) => anchor.event?.grace ? anchor.event.grace.before ? anchor.event.grace.index : 2000 - anchor.event.grace.index : 1000;
    const hostClock = (part: MusicalPart, measure: number, event: MusicalEvent) => add(measureClocks.get(part)![measure], event.grace ? eventById.get(event.grace.hostId)!.start : event.start);
    for (const relation of relations) {
        if (relation.sourceDuration) {
            const part = partsById.get(relation.start.partId)!, start = add(measureClocks.get(part)![relation.start.measure], relation.start.position), end = add(measureClocks.get(part)![relation.end.measure], relation.end.position);
            if (!equal(add(start, relation.sourceDuration.value), end)) refuse('native-relation-clock', 'Encoded relation duration contradicts its resolved endpoint coordinates.', relation.sourceDuration.source);
        }
        if (relation.kind !== 'tie') continue;
        const part = partsById.get(relation.start.partId)!, source = eventById.get(relation.start.eventId!)!, destination = eventById.get(relation.end.eventId!)!;
        const onset = add(measureClocks.get(part)![relation.start.measure], source.start), targetOnset = add(measureClocks.get(part)![relation.end.measure], destination.start);
        const sourceOrder = source.grace ? source.grace.before ? source.grace.index : 2000 - source.grace.index : 1000;
        const destinationOrder = destination.grace ? destination.grace.before ? destination.grace.index : 2000 - destination.grace.index : 1000;
        const hostOrder = compare(hostClock(part, relation.start.measure, source), hostClock(part, relation.end.measure, destination));
        if (compare(onset, targetOnset) > 0 || equal(onset, targetOnset) && (hostOrder > 0 || hostOrder === 0 && sourceOrder >= destinationOrder)) refuse('native-tie-clock', 'Tie endpoints must advance chronologically in source host/event/grace order.', relation.source);
        const release = add(onset, source.duration);
        if (!equal(release, targetOnset)) {
            relation.clockGap = add(targetOnset, mul(release, q(-1)));
            performanceGap('native-gapped-tie-scheduler', relation.source, 'The authored tie graph, exact component values and calculated clock gap are preserved. Native modern duration spans first onset to last release, while its compatibility MIDI scheduler sums component lengths; neither engine-specific schedule is silently imposed or used to stretch written notation.');
        }
    }
    for (const relation of slurs) {
            const start = absolute(relation.source), stop = absolute(relation.destination);
            const hostOrder = compare(hostClock(relation.source.part, relation.source.measure, relation.source.event!), hostClock(relation.destination.part, relation.destination.measure, relation.destination.event!));
            if (compare(start, stop) > 0 || equal(start, stop) && (hostOrder > 0 || hostOrder === 0 && graceOrder(relation.source) >= graceOrder(relation.destination))) refuse('native-slur', 'Slur endpoint must follow its source host/event/grace order.', relation.element.location);
            const metadata = { relationId: relation.relationId, ...(relation.payload.printObject !== undefined ? { printObject: relation.payload.printObject } : {}), ...(relation.payload.orientation ? { orientation: relation.payload.orientation } : {}), ...(relation.payload.lineType ? { lineType: relation.payload.lineType } : {}) };
            ((relation.source.note ?? relation.source.event!).slurs ??= []).push({ type: 'start', ...metadata });
            ((relation.destination.note ?? relation.destination.event!).slurs ??= []).push({ type: 'stop', ...metadata });
    }
    const hopoVoices = new Map<string, { event: MusicalEvent; measure: number }[]>();
    for (const relation of hammerOns) {
        const { source, destination, element, payload } = relation;
        if (source.staff !== destination.staff || source.voice !== destination.voice) refuse('native-hopo-owner', 'A native H/P chain requires its actual single source voice.', element.location);
        const key = `${source.part.id}:${source.staff}:${source.voice}`;
        let sequence = hopoVoices.get(key);
        if (!sequence) { sequence = source.part.measures.flatMap((measure, mi) => (measure.voices[(source.staff - 1) * 4 + source.voice] ?? []).filter(event => event.notes.length > 0).map(event => ({ event, measure: mi }))); hopoVoices.set(key, sequence); }
        const begin = sequence.findIndex(item => item.event === source.event), end = sequence.findIndex(item => item.event === destination.event);
        if (begin < 0 || end <= begin) refuse('native-hopo-clock', 'An H/P span requires a forward source chord chain.', element.location);
        budget.add('markings', end - begin, element.location);
        let previousKind:'hammer-on'|'pull-off'|undefined;
        for (let i = begin; i < end; i++) {
            const a = sequence[i].event, b = sequence[i + 1].event;
            const ordered = (event: MusicalEvent) => event.notes.filter(note => note.kind === 'pitched').sort((a, b) => a.sounding!.midi - b.sounding!.midi);
            const from = ordered(a), to = ordered(b);
            if (from.length !== a.notes.length || to.length !== b.notes.length || !from.length || !to.length) refuse('native-hopo-pitch', 'Native H/P requires source pitched chord components.', element.location);
            const tab = source.part.measures[sequence[i].measure].staffs!.find(staff => staff.number === source.staff)!.kind === 'tablature';
            let pair: [MusicalNote, MusicalNote] | undefined;
            for (let n = Math.max(from.length, to.length) - 1; n >= 0; n--) {
                const left = from[Math.min(n, from.length - 1)], right = to[Math.min(n, to.length - 1)];
                if (ties.get(left) === right || left.sounding!.midi === right.sounding!.midi || tab && left.string !== right.string) continue;
                pair = [left, right]; break;
            }
            if (!pair) refuse('native-hopo-pitch', 'The native H/P span contains no distinct eligible source note pair.', element.location);
            const [left, right] = pair!;
            const kind = (tab ? right.fret! > left.fret! : right.sounding!.midi > left.sounding!.midi) ? 'hammer-on' as const : 'pull-off' as const;
            if (left.hopoNotations?.some(item => item.type === 'start') || right.hopoNotations?.some(item => item.type === 'stop')) refuse('native-hopo-conflict', 'H/P relations duplicate a source component endpoint.', element.location);
            const show=numberStyle(tab?'hopoShowOnTabStaves':'hopoShowOnStandardStaves',1)!==0;
            const repeated=numberStyle('hopoShowAll',1)===0&&previousKind===kind;
            const caption=repeated?'':kind==='hammer-on'?'H':'P', text=numberStyle('hopoUpperCase',1)?caption:caption.toLowerCase();
            const notation = { source: element.location, kind, number: 1, text, ...(!show?{printObject:false}:payload.printObject !== undefined ? { printObject: payload.printObject } : {}), ...(payload.sourceColor ? { sourceColor: payload.sourceColor } : {}) };
            (left.hopoNotations ??= []).push({ ...notation, type: 'start' }); (right.hopoNotations ??= []).push({ ...notation, type: 'stop' });
            previousKind=kind;
        }
    }
    // Verify source tie chains independently of the software-only native NoteEvents schedule.
    const visitedTies = new Set<MusicalNote>();
    for (const first of noteEvents.keys()) {
        if (tiedBack.has(first)) continue;
        let note: MusicalNote | undefined = first;
        while (note) {
            if (visitedTies.has(note)) refuse('native-tie', 'Cyclic or overlapping tie chain.', note.source);
            visitedTies.add(note);
            if (note.performance?.events) performanceGap('native-performance-schedule', note.performance.source, 'The exact native NoteEvents schedule remains a located source fact. Its software-only ontime, length, pitch offsets and extra attacks are not promoted to performer note attack/release or notation divisions; nominal written clocks and source tie relationships remain unchanged.');
            note = ties.get(note);
        }
    }
    if (visitedTies.size !== noteEvents.size) refuse('native-tie', 'Tie graph contains a cycle without a source attack.', root.location);
    for(const gaps of deferredCaptionGaps.values())for(const gap of gaps)performanceGap(gap.code,gap.source,gap.message);
    for(const [staff,expansion] of repeatExpansions){const owner=staffOwners.get(integer(staff.attrs.id,1,256,staff.location))!;expansion.apply(owner.part,owner.definition.number);}
    for(const owner of [...deferredInline.keys()])resolveInline(owner,{});
    const unknown: Element[] = []; const stack = [root];
    while (stack.length) { const e = stack.pop()!; if (!used.has(e)) unknown.push(e); stack.push(...e.children); }
    if (unknown.length) refuse('native-feature', `Uninterpreted native construct ${unknown[0].name}; ${unknown.length} captured nodes remain unclassified.`, unknown[0].location);
    const repeatScore={...scoreNode,children:scoreNode.children.map(node=>repeatExpansions.has(node)?{...node,children:[...node.children.filter(c=>c.name!=='Measure'),...repeatExpansions.get(node)!.measures]}:node)};
    const repeatCapture={...capture,root:{...capture.root,children:capture.root.children.map(node=>node===scoreNode?repeatScore:node)}};
    findings.push(...recoverNativeBeamGraph(repeatCapture, repeatScore, parts, budget));
    findings.push(...recoverNativeNotationPresentation(repeatScore,parts,budget,capture.nativeVersion));
    findings.push(...recoverNativeNavigation(parts));
    for(const part of parts) for(const measure of part.measures) for(const voice of measure.voices) for(const event of voice??[]) {
        const staff=measure.staffs?.find(s=>s.number===event.staff), rules=staff?.notation; if(!rules)continue;
        if(rules.stemless?.value) event.stem='none';
        if(!event.notes.length && rules.showRests?.value===false)event.printObject=false;
        for(const note of event.notes) {
            if(rules.showLedgerLines) note.printLedgerLines=rules.showLedgerLines;
            if(staff?.kind==='tablature' && rules.showTabFingering?.value===false) {for(const fingering of note.fingerings??[])fingering.printObject=false; if(note.fingering){for(const value of note.fingering)(note.fingerings??=[]).push({source:rules.showTabFingering.source,value,printObject:false});delete note.fingering;}}
        }
    }

                for (const part of parts) for (const measure of part.measures) for (const voice of measure.voices) for (const event of voice) if (event.sourceHook?.printObject === false && event.sourceStemVisibility?.value !== false && !event.beams?.length)
                    performanceGap('native-hidden-hook-projection', event.sourceHook.source, 'The located source flag visibility and glyph remain exposed independently of stem direction. MusicXML has no separate default-flag visibility attribute; this export does not hide an otherwise visible stem or change rhythm to suppress the flag. Exact performer flag rendering remains a declared projection limit.');
                for (const part of parts) for (const measure of part.measures) for (const voice of measure.voices) for (const event of voice) if (event.sourceStemVisibility?.value === false && event.sourceHook?.printObject !== false && !event.beams?.length && ['eighth', '16th', '32nd', '64th', '128th', '256th', '512th', '1024th'].includes(event.type))
                    performanceGap('native-hidden-stem-flag-projection', event.sourceStemVisibility.source, 'The source hides its stem without separately confirming a hidden flag. Standard stem none preserves the hidden stem, but may also suppress a native independently visible generated flag; exact combined rendering is not certified. Rhythm and source visibility facts remain unchanged.');
    for (const [reason, item] of ignored) findings.push({ disposition: reason === 'native-unselected-source-view' ? 'excluded-by-scope' : 'omitted', code: reason, message: reason === 'native-unselected-source-view' ? 'Unselected original score content is retained byte-exact. The explicitly chosen source Score is recovered independently, without primary-model slicing or merged view event streams.' : 'Source data retained in immutable capture; this category is not serialized as original native engraving/editor/playback metadata.', location: item.first.location, fact: { count: item.count } });
    const orderedPerformanceGaps = performanceGaps;
    for (const [code, item] of orderedPerformanceGaps) findings.push({ disposition: item.disposition, code, message: item.message, location: item.source, fact: { count: item.count, writtenClocksPreserved: true } });
    findings.push({ disposition: 'inferred', code: 'native-absent-defaults', message: 'Known unencoded baseline values are C-major, 4/4, zero transposition and ordinary initial clefs; they are decoded defaults, not claimed as encoded markings.', location: scoreNode.location });
    for(const {owner,glyph} of imageGlyphs){
        if(owner.viewSource)continue;
        const part=parts.find(part=>part.id===(owner.placement?.partId??owner.partId))!;
        const measure=owner.attachment?.measure??Math.min(owner.beforeMeasure!,part.measures.length-1),position=owner.attachment?.position??(owner.beforeMeasure===part.measures.length?part.measures[measure].duration:q(0));
        (part.measures[measure].directions??=[]).push({source:glyph.source,kind:'symbol',symbol:glyph,position,staff:owner.placement?.staff??owner.staff,...(owner.placement?.voiceId||owner.attachment?.voiceId?{voiceId:owner.placement?.voiceId??owner.attachment?.voiceId}:{})});
    }
    return { title, parts, tempos: [], relations, ...(sourceView ? { sourceView } : {}), ...(selection ? { sourceSelection: { id: selection.entry.info.id, source: scoreNode.location, identityOrigin: 'source-location' as const, primary: selection.entry.info.primary, mainSource: primaryNode.location, ...(selection.entry.info.name ? { name: selection.entry.info.name } : {}), styleDefaultSelectors, objectLinks: selection.entry.links } } : {}), ...(Object.keys(measureNumbering).length ? { measureNumbering } : {}), ...(sourceImages.length ? { sourceImages } : {}), ...(metadata.length ? { metadata } : {}), ...(sourceObjectLinks.length ? { sourceObjectLinks } : {}), ...(sourcePageText.length ? { sourcePageText } : {}), ...(credits.length ? { credits } : {}), ...(cachedMeasureViews.length ? { cachedMeasureViews } : {}), ...(alternateViews.length ? { alternateViews } : {}) };
}

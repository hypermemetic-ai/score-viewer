import type { MusicalEvent, MusicalPart } from '../../core/model.js';
import { add, equal, mul, q, type Rational } from '../../core/rational.js';
import { refuse, type Finding } from '../../core/report.js';
import { child, children, type SourceElement } from '../../core/source-xml.js';
import type { ParsedNativeCapture } from './capture-core.js';

const values: Readonly<Record<string, Rational>> = { long: q(16), breve: q(8), whole: q(4), half: q(2), quarter: q(1), eighth: q(1, 2), '16th': q(1, 4), '32nd': q(1, 8), '64th': q(1, 16), '128th': q(1, 32), '256th': q(1, 64), '512th': q(1, 128), '1024th': q(1, 256) };
const written = (event: MusicalEvent) => mul(values[event.type], q(2 ** (event.dots + 1) - 1, 2 ** event.dots));
const singleValue = (duration: Rational): { type: string; dots: number } | undefined => {
    for (const [type, base] of Object.entries(values)) for (let dots = 0; dots <= 4; dots++)
        if (equal(duration, mul(base, q(2 ** (dots + 1) - 1, 2 ** dots)))) return { type, dots };
    return undefined;
};

/** Source-qualified native single-note tie display; attacks, timing and original visibility stay separate. */
export function applyCrossMeasureValues(capture: Partial<Pick<ParsedNativeCapture, 'root' | 'styleRoot'>>, scoreNode: SourceElement, parts: MusicalPart[]): Finding[] {
    const primary = capture.root ? child(capture.root, 'Score') : scoreNode;
    const styles = primary === scoreNode ? [capture.styleRoot?.children[0], child(scoreNode, 'Style')] : [child(scoreNode, 'Style')];
    let field: SourceElement | undefined;
    for (const style of styles) if (style) {
        const fields = children(style, 'crossMeasureValues');
        if (fields.length > 1) refuse('native-cross-measure-style', 'Cross-measure value style must have one source value.', fields[1].location);
        if (fields[0]) field = fields[0];
    }
    if (!field) return [];
    if (field.children.length || Object.keys(field.attrs).length || !['0', '1'].includes(field.text.trim()))
        refuse('native-cross-measure-style', 'Cross-measure value style requires a literal boolean.', field.location);
    if (field.text.trim() === '0') return [{ disposition: 'preserved', code: 'native-cross-measure-values', message: 'Source disables combined cross-bar duration display.', location: field.location, fact: { enabled: false, pairs: 0 } }];
    let pairs = 0;
    for (const part of parts) {
        const rows = part.measures.flatMap((measure, index) => measure.voices.flatMap((voice, voiceIndex) => voice.map(event => ({ event, index, measure, staff: Math.floor(voiceIndex / 4) + 1 }))));
        const destinations = new Map<string, typeof rows[number]>();
        for (const row of rows) {
            delete row.event.crossMeasureValue;
            for (const note of row.event.notes) for (const tie of note.tieNotations ?? []) if (tie.type === 'stop') destinations.set(tie.relationId, row);
        }
        for (const row of rows) {
            const event = row.event;
            if (event.crossMeasureValue || event.grace || event.notes.length !== 1 || !values[event.type]) continue;
            const tie = event.notes[0].tieNotations?.find(tie => tie.type === 'start'), target = tie && destinations.get(tie.relationId);
            if (!tie || !target || target.index === row.index || target.event.grace || target.event.notes.length !== 1 || target.event.crossMeasureValue || !values[target.event.type]) continue;
            const duration = add(written(event), written(target.event)), display = singleValue(duration);
            if (!display) continue;
            const staff = target.measure.staffs?.find(staff => staff.number === target.staff) ?? part.staves?.find(staff => staff.number === target.staff);
            const metadata = { source: field.location, tieId: tie.relationId, ...display, duration, origin: 'native-cross-measure-style' as const };
            event.crossMeasureValue = { ...metadata, role: 'start', partnerEventId: target.event.id, hideNotehead: false };
            target.event.crossMeasureValue = { ...metadata, role: 'continuation', partnerEventId: event.id, hideNotehead: staff?.kind !== 'tablature' };
            pairs++;
        }
    }
    return [{ disposition: 'inferred', code: 'native-cross-measure-values', message: 'Explicit native style combines qualified single-note cross-bar ties into one displayed value. Original event durations, notes, ties, accidental and performer attachments remain separate; continuation fret marks remain visible on tablature.', location: field.location, fact: { enabled: true, pairs } }];
}

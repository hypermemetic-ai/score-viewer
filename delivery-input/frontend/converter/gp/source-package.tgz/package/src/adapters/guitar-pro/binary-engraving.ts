import type {MusicalEvent,MusicalPart,MusicalRelation} from '../../core/model.js';
import {refuse,type Finding,type Location} from '../../core/report.js';
import {add,compare,equal,mul,q} from '../../core/rational.js';
import {applyGpBeams,type GpBeamControl,type GpBeamGrouping} from './beams.js';

export interface BinaryBeatEngraving {event:MusicalEvent;source:Location;facts:Record<string,number>}

/** GP5 beam boundaries belong before the encoded beat, unlike GPIF's after-beat flags. */
export function binaryBeams(parts:MusicalPart[],beats:BinaryBeatEngraving[],masters:{source:Location;facts:Record<string,number>}[],locations:Map<string,Location>,findings:Finding[]):void {
    const controls=new Map<MusicalEvent,GpBeamControl>();
    const groups=new Map<number,GpBeamGrouping>();let inherited:GpBeamGrouping|undefined;
    for(const [index,master] of masters.entries()) {
        if(master.facts['beam-group:0']!==undefined) {
            const values=Array.from({length:4},(_,i)=>master.facts[`beam-group:${i}`]),source=locations.get(master.source.path+'/beam-group:0')??master.source;
            if(values.every(value=>value===0))refuse('gp-beam-groups','An all-zero binary grouping does not establish musical spans.',source);
            inherited={source:{...source,byteLength:4},unit:8,groups:values};
        }
        if(inherited)groups.set(index,inherited);
    }
    for(const {event,source:beatSource,facts} of beats) {
        const flags=facts['beat-flags2']??0,source=locations.get(beatSource.path+'/beat-flags2')??beatSource;
        // Producer-authored flags5 are valid: force-join overrides the split bit.
        if(flags&(15|0x800))controls.set(event,{source,...(flags&4?{primary:'join' as const}:flags&1?{primary:'split' as const}:{}),...(flags&8?{stem:'up' as const}:flags&2?{stem:'down' as const}:{}),...(flags&0x800?{secondaryBreak:facts['break-secondary-beams'],secondarySource:locations.get(beatSource.path+'/break-secondary-beams')??source}:{})});
    }
    for(const part of parts)applyGpBeams(part,{controls,groups},findings);
}

/** Source ratios determine clocks; inferred bracket grouping never changes them. */
export function binaryTuplets(parts:MusicalPart[],beats:BinaryBeatEngraving[],locations:Map<string,Location>,findings:Finding[]):void {
    const raw=new Map(beats.map(beat=>[beat.event,beat]));
    const flags=(event:MusicalEvent)=>raw.get(event)?.facts['beat-flags2']??0;
    const at=(event:MusicalEvent)=>locations.get(raw.get(event)?.source.path+'/beat-flags2')??event.source;
    for(const part of parts)for(const measure of part.measures)for(const voice of measure.voices) {
        const events=voice.filter(event=>!event.grace);let group:MusicalEvent[]=[],explicit=false;
        const close=(encodedEnd=false)=>{
            if(!group.length)return;
            if(explicit&&!encodedEnd)refuse('binary-tuplet-bracket','Explicit tuplet bracket start has no matching end in its ratio run.',at(group[0]));
            const first=group[0],last=group.at(-1)!,ratio=first.tuplet!,force=group.find(event=>flags(event)&0x2000);
            (first.tupletBoundary??=[]).push({type:'start',number:1,source:at(first),actual:ratio.actual,normal:ratio.normal,...(force?{bracketType:{source:at(force),value:'yes' as const}}:{})});
            (last.tupletBoundary??=[]).push({type:'stop',number:1,source:at(last)});
            findings.push({disposition:explicit?'preserved':'inferred',code:'binary-tuplet-bracket',message:explicit?'Encoded tuplet bracket anchors retain their exact source events; the ratio and attack clocks are unchanged.':'Tuplet notation groups are calculated from contiguous equal source ratios and exact written units; source clocks and ratios are unchanged.',location:at(first),fact:{events:group.map(event=>event.source),actual:ratio.actual,normal:ratio.normal,forceBracket:!!force}});
            group=[];explicit=false;
        };
        for(const event of events) {
            const f=flags(event);
            if(!event.tuplet){close();if(f&0x2600)refuse('binary-tuplet-bracket','Tuplet display control has no source tuplet ratio.',at(event));continue;}
            if(group.length&&(group[0].tuplet!.actual!==event.tuplet.actual||group[0].tuplet!.normal!==event.tuplet.normal||f&0x200))close();
            if(f&0x200)explicit=true;
            group.push(event);
            if(f&0x400){explicit=true;close(true);continue;}
            if(!explicit){
                const values=group.map(value=>mul(value.duration,q(value.tuplet!.actual,value.tuplet!.normal))),minimum=values.reduce((a,b)=>compare(a,b)<0?a:b),total=values.reduce(add,q(0));
                if(equal(total,mul(minimum,q(event.tuplet.actual))))close();
            }
        }
        if(explicit)refuse('binary-tuplet-bracket','Explicit tuplet bracket start has no end before its source measure boundary.',at(group[0]));
        close();
    }
}

/** Binary ottava bits are per-beat engraving instructions, not acoustic transposition. */
export function binaryOttavas(parts:MusicalPart[],beats:BinaryBeatEngraving[],locations:Map<string,Location>,relations:MusicalRelation[],findings:Finding[]):void {
    const raw=new Map(beats.map(beat=>[beat.event,beat]));
    const amount=(event:MusicalEvent)=>{
        const flags=(raw.get(event)?.facts['beat-flags2']??0)&0x170;
        if(flags&&(flags&(flags-1)))refuse('binary-ottava','Conflicting octave-line flags on one source beat.',event.source);
        return ({16:1,32:-1,64:2,256:-2} as const)[flags as 16|32|64|256];
    };
    for(const part of parts)for(let voice=0;voice<Math.max(...part.measures.map(measure=>measure.voices.length));voice++) {
        const entries=part.measures.flatMap((measure,mi)=>(measure.voices[voice]??[]).filter(event=>!event.grace).map(event=>({event,mi})));
        for(let index=0;index<entries.length;index++) {
            const octaves=amount(entries[index].event);if(!octaves)continue;
            let end=index;while(end+1<entries.length&&amount(entries[end+1].event)===octaves)end++;
            const first=entries[index],last=entries[end],source=locations.get(raw.get(first.event)?.source.path+'/beat-flags2')??first.event.source;
            const scoped=part.measures.slice(first.mi,last.mi+1).some(measure=>measure.voices.some((events,vi)=>vi!==voice&&events.some(event=>!event.grace&&event.notes.length)));
            const label=`${Math.abs(octaves)===1?'8':'15'}${octaves>0?Math.abs(octaves)===1?'va':'ma':Math.abs(octaves)===1?'vb':'mb'}`;
            relations.push({source,id:`binary-ottava:${part.id}:${voice}:${index}`,kind:'ottava',octaves,start:{partId:part.id,measure:first.mi,position:first.event.start,staff:first.event.staff??1,voiceId:first.event.voiceId??String(voice+1),eventId:first.event.id},end:{partId:part.id,measure:last.mi,position:add(last.event.start,last.event.duration),staff:last.event.staff??1,voiceId:last.event.voiceId??String(voice+1)},...(scoped?{beginText:`${label} (voice ${voice+1})`,projection:{source,kind:'words-bracket' as const,reason:'voice-local-scope' as const}}:{})});
            findings.push({disposition:scoped?'inferred':'preserved',code:'binary-ottava',message:scoped?'The source voice-local octave line uses an explicit voice-labelled standard bracket to avoid shifting unrelated staff voices. Exact interval, endpoints and source flags remain retained.':'Per-beat source octave-line flags become a standard octave-shift span without changing physical or written pitch data.',location:source,fact:{octaves,voice:voice+1,first:first.event.source,last:last.event.source}});
            index=end;
        }
    }
}

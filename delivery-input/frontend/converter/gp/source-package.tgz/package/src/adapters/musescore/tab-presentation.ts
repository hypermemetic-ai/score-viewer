import type { MusicalEvent, MusicalNote, MusicalPart, StaffFact } from '../../core/model.js';
import { refuse, type Finding, type Location } from '../../core/report.js';
import { child, children, type SourceElement } from '../../core/source-xml.js';
import type { ParsedNativeCapture } from './capture-core.js';
import type { NativeBudget } from './budget.js';
import type { NativeBendRecord } from './bend-graph.js';
import { recoverNativeTabRhythm, nativeTabFretFont } from './tab-rhythm.js';
import { recoverNativeHeadSchemes } from './head-schemes.js';

type Row = { event: MusicalEvent; measure: number; staff?: StaffFact };
/** Run after complete beams/cross-bar values; it must not precede that graph. */
export function recoverNativeNotationPresentation(scoreNode:SourceElement,parts:MusicalPart[],budget:Pick<NativeBudget,'add'>,nativeVersion:string):Finding[] {
    const nodes=new Map<string,SourceElement>(),pending=[scoreNode];while(pending.length){const node=pending.pop()!;nodes.set(node.location.path!,node);pending.push(...node.children);}
    return [...recoverNativeTabRhythm(parts,nodes,budget),...recoverNativeHeadSchemes(parts,budget,nativeVersion)];
}
/** Fret drawing and native top-component selection are independent of note visibility. */
export function recoverNativeTabPresentation(context: {
    capture: Pick<ParsedNativeCapture, 'root' | 'styleRoot' | 'nativeVersion'>;
    scoreNode: SourceElement; parts: MusicalPart[];
    ties: ReadonlyMap<MusicalNote, MusicalNote>; modernBendRecords: readonly NativeBendRecord[];
    budget: Pick<NativeBudget, 'add'>;
    hasPrecedingBend: (record: NativeBendRecord) => boolean;
}): { findings: Finding[]; isTop: (note: MusicalNote) => boolean | undefined } {
    const { capture, scoreNode, parts, ties, modernBendRecords, budget } = context;
    const modern = Number(capture.nativeVersion) >= 4.3, newBendExceptions = Number(capture.nativeVersion) >= 4.7;
    const sourceNodes = new Map<string, SourceElement>(), stack = [scoreNode];
    while (stack.length) {const node=stack.pop()!;sourceNodes.set(node.location.path!,node);stack.push(...node.children);}
    const primary=child(capture.root,'Score'), styles=primary===scoreNode?[capture.styleRoot?.children[0],child(scoreNode,'Style')]:[child(scoreNode,'Style')];
    const setting = (name:string, fallback:number, maximum:number) => {
        let selected:SourceElement|undefined;
        for(const style of styles)if(style){const found=children(style,name);if(found.length>1)refuse('native-tab-style','TAB policy needs a unique source value.',found[1].location);if(found[0])selected=found[0];}
        if(!selected)return {value:fallback,source:scoreNode.location};
        if(selected.children.length || Object.keys(selected.attrs).length || !/^\d+$/.test(selected.text.trim()) || Number(selected.text)>maximum)refuse('native-tab-style','TAB policy requires a supported source enum.',selected.location);
        return {value:Number(selected.text),source:selected.location};
    };
    const show=setting('tabShowTiedFret',0,2), parenthesize=setting('tabParenthesizeTiedFret',0,2), force=setting('parenthesizeTiedFretIfArticulation',1,1);
    const rows=new Map<MusicalNote,Row>(), back=new Map<MusicalNote,MusicalNote>(), incoming=new Set<MusicalNote>(), outgoing=new Map<MusicalNote,NativeBendRecord[]>();
    for(const [start,end] of ties)back.set(end,start);
    for(const record of modernBendRecords){if(!['slight-bend','dip'].includes(record.shape.type))incoming.add(record.end);const list=outgoing.get(record.start)??[];list.push(record);outgoing.set(record.start,list);}
    for(const part of parts)for(const [measureIndex,measure] of part.measures.entries())for(const [voiceIndex,voice] of measure.voices.entries())for(const event of voice??[])for(const note of event.notes)
        rows.set(note,{event,measure:measureIndex,staff:measure.staffs?.find(staff=>staff.number===Math.floor(voiceIndex/4)+1)??part.staves?.find(staff=>staff.number===Math.floor(voiceIndex/4)+1)});
    for(const note of rows.keys()){delete note.tabFret;delete note.tabTieVisibility;}
    // Shared tie tails are memoized; a long tied passage is visited once.
    const continuation=new Map<MusicalNote,boolean>();
    const followsBend=(note:MusicalNote):boolean=>{
        const pending:MusicalNote[]=[],seen=new Set<MusicalNote>();let current:MusicalNote|undefined=note,value=false;
        while(current){if(continuation.has(current)){value=continuation.get(current)!;break;}if(incoming.has(current)){value=true;break;}if(seen.has(current))refuse('native-tab-tie','TAB policy cannot traverse a cyclic source tie.',current.source);seen.add(current);pending.push(current);current=back.get(current);}
        for(const item of pending)continuation.set(item,value);return value;
    };
    const facts:Finding[]=[], conditional:Location[]=[];
    const fontCache=new Map<StaffFact,ReturnType<typeof nativeTabFretFont>>();
    for(const [note,row] of rows){delete note.tabFretFont;if(row.staff?.kind!=='tablature')continue;if(!fontCache.has(row.staff))fontCache.set(row.staff,nativeTabFretFont(row.staff,sourceNodes,{version:capture.nativeVersion,styles,findings:facts}));const font=fontCache.get(row.staff);if(font){note.tabFretFont=font;budget.add('markings',1,font.source);}}
    for(const [note,row] of rows){
        if(row.staff?.kind!=='tablature'||!note.tieStop)continue;
        const raw=sourceNodes.get(note.source.path!), chord=sourceNodes.get(row.event.source.path!);
        const attached=raw?.children.some(node=>['Bend','Fingering','Image','Text','Symbol'].includes(node.name))??false;
        let printObject=true, parentheses=false, condition:NonNullable<MusicalNote['tabFret']>['condition'],policy:NonNullable<MusicalNote['tabFret']>['policy']='ordinary',source=row.staff.source;
        if(!modern){
            const hidden=row.staff.notation?.showBackTied;
            if(hidden?.value!==false)continue;
            source=hidden.source;policy='legacy-tied';
            if(attached)parentheses=true;
            else if(back.has(note)&&rows.get(back.get(note)!)?.measure===row.measure)printObject=false;
            else {condition='same-system-tie';parentheses=true;}
        }else{
            const starts=(outgoing.get(note)??[]).filter(record=>record.shape.type!=='scoop');
            const bendFor=starts.find(record=>!['dive','pre-dive','dip'].includes(record.shape.type))??starts[0],hasBend=!!bendFor;
            const otherSpanner=raw?.children.some(node=>node.name==='Spanner'&&node.attrs.type!=='Tie'&&!!child(node,'next'))??false;
            const chordMarks=chord?.children.some(node=>['Articulation','Ornament','ChordLine'].includes(node.name))??false;
            const vibrato=chord?.children.some(node=>node.name==='Spanner'&&node.attrs.type==='Vibrato'&&!!child(node,'next'))??false;
            const newBend=newBendExceptions&&!!bendFor&&!context.hasPrecedingBend(bendFor);
            const dip=newBendExceptions&&row.event.notes.some(component=>outgoing.get(component)?.some(record=>record.shape.type==='dip'));
            const forced=force.value===1&&(chordMarks||otherSpanner&&!hasBend||!!row.event.whammy||vibrato||newBend||dip);
            if(forced){policy='performer-mark';source=force.source;}
            else if(followsBend(note)&&row.event.start.n!==0){policy='bend-continuation';printObject=false;source=note.source;}
            else if(show.value!==0){
                policy='modern-tied';source=show.source;
                if(parenthesize.value===2||row.event.start.n!==0)printObject=false;
                else if(parenthesize.value===0)condition='system-start';
            }
        }
        if(modern&&printObject&&(show.value!==0||followsBend(note))&&!note.fixedPosition?.fixed)parentheses=true;
        budget.add('markings',1,source);
        note.tabFret={source,printObject,...(parentheses?{parentheses}:{}),...(condition?{condition}:{}),policy,origin:'native-tab-policy'};
        if(condition)conditional.push(source);
    }
    for(const [start,end] of ties){
        const staff=rows.get(start)?.staff;
        if(staff?.kind!=='tablature')continue;
        const continuation=modern&&followsBend(start),hiddenByStyle=modern?show.value===2:staff.notation?.showBackTied?.value===false;
        if(!continuation&&!hiddenByStyle)continue;
        const reason=continuation?'bend-continuation' as const:'source-style' as const,source=continuation?start.source:modern?show.source:staff.notation!.showBackTied!.source;
        const starts=start.tieNotations?.filter(tie=>tie.type==='start')??[],stops=end.tieNotations?.filter(tie=>tie.type==='stop')??[];
        for(const tie of starts)if(stops.some(stop=>stop.relationId===tie.relationId))for(const note of [start,end]){budget.add('markings',1,source);(note.tabTieVisibility??=[]).push({source,relationId:tie.relationId,printObject:false,reason});}
    }
    if(conditional.length)facts.push({disposition:'omitted',code:'native-tab-system-fret-policy',location:conditional[0],message:'The located source fret policy depends on generated system boundaries. MusicXML has no conditional fret visibility keyed to future system starts; the fret stays readable while its exact conditional policy remains separate. No source or future system break is invented.',fact:{count:conditional.length}});
    const pitch=(note:MusicalNote)=>note.kind==='unpitched'?note.unpitched.midi??0:note.written.midi;
    const topFor=(row:Row, includeConditional:boolean):MusicalNote|undefined=>{
        const notes=[...row.event.notes].sort((a,b)=>pitch(a)-pitch(b));let result=notes.at(-1);
        if(row.staff?.kind!=='tablature')return result;
        let line=row.staff.lines??row.staff.tuning?.length??5;
        for(const note of notes){if(note.string===undefined||modern&&(note.tabFret?.printObject===false||note.tabFret?.condition&&!includeConditional))continue;
            const position=row.staff.notation?.upsideDown?.value?(row.staff.lines??row.staff.tuning?.length??5)-note.string:note.string-1;
            if(position<line){line=position;result=note;}}
        return result;
    };
    const topCache=new Map<MusicalEvent,{a:MusicalNote|undefined;b:MusicalNote|undefined}>();
    return {findings:facts,isTop:note=>{const row=rows.get(note);if(!row)return undefined;let result=topCache.get(row.event);if(!result){result={a:topFor(row,true),b:topFor(row,false)};topCache.set(row.event,result);}if(result.a===result.b)return result.a===note;return result.a===note||result.b===note?undefined:false;}};
}

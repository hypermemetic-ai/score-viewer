import type { MusicalEvent, MusicalPart } from '../../core/model.js';
import { add, compare, mul, q, type Rational } from '../../core/rational.js';
import type { SourceElement } from '../../core/source-xml.js';
import type { Finding, Location } from '../../core/report.js';
import type { ParsedNativeCapture } from './capture-core.js';
import type { NativeBudget } from './budget.js';
import { beamLevels, qualifyBeamSource, type BeamRow, type BeamSourceGraph } from './beam-source.js';
import { applyCrossMeasureValues } from './cross-measure-values.js';

type Mode = NonNullable<MusicalEvent['beam']>['mode'];
const hooks = (row: BeamRow) => row.event.crossMeasureValue?.role === 'continuation' ? 0 : beamLevels[row.event.crossMeasureValue?.type ?? row.event.type] ?? 0;
const displayedType = (row: BeamRow) => row.event.crossMeasureValue?.role === 'start' ? row.event.crossMeasureValue.type : row.event.type;
const displayedDots = (row: BeamRow) => row.event.crossMeasureValue?.role === 'continuation' ? 0 : row.event.crossMeasureValue?.dots ?? row.event.dots;
const rawMode = (row: BeamRow): Mode => row.event.beam?.mode ?? 'auto';
const continued = (mode: Mode) => mode === 'mid' || mode === 'begin16' || mode === 'begin32';
const ticks = (r: Rational) => Math.round(r.n * 480 / r.d);
const number = (r: Rational) => r.n / r.d;
const subtract = (a: Rational, b: Rational) => add(a, q(-b.n, b.d));
const actionMode = (action: number): Mode => action === 1 ? 'begin' : action === 2 ? 'begin16' : action === 3 ? 'begin32' : 'auto';
const meterGroups = new WeakMap<BeamRow['meter'], Map<number, [number, number, number]>>();

/** Native meter defaults expressed as rhythmic boundaries, independently of engraving geometry. */
function meterAction(row: BeamRow, level: number, position: Rational): number {
    if (level < 1 || level > 3) return 0;
    const meter = row.meter, tick = ticks(position);
    if (meter.beamGroups) {
        let indexed = meterGroups.get(meter); if (!indexed) { indexed = new Map(meter.beamGroups.map(group => [ticks(group.position), group.breaks])); meterGroups.set(meter, indexed); }
        return indexed.get(tick)?.[level - 1] ?? 0;
    }
    if (tick <= 0 || tick >= ticks(q(meter.beats * 4, meter.unit))) return 0;
    const onQuarter = tick % 480 === 0, onEighth = tick % 240 === 0;
    const simple = meter.unit === 2 && [2, 3, 4].includes(meter.beats) || meter.unit === 4 && [2, 3, 4, 5, 6].includes(meter.beats);
    if (simple) {
        const grouping = meter.unit === 2 || meter.beats === 4 ? 2 : meter.beats >= 5 ? 3 : 1;
        if (level === 1) return tick % (grouping * 480) === 0 ? 1 : 0;
        return onQuarter ? 1 : level === 3 && onEighth ? 2 : 0;
    }
    if (meter.unit === 8 && [3, 5, 6, 7, 9, 12].includes(meter.beats)) {
        const eighth = tick / 240;
        const primary = meter.beats === 7 ? eighth === 3 || eighth === 5 : Number.isInteger(eighth / 3);
        return primary ? 1 : level === 3 && onEighth ? 2 : 0;
    }
    if (![2, 4, 8, 16, 32].includes(meter.unit)) return 0;
    const unitTicks = ticks(q(4, meter.unit));
    return unitTicks > 0 && tick % unitTicks === 0 ? 1 : 0;
}

function sourceMode(row: BeamRow, previous: BeamRow | undefined, graph: BeamSourceGraph, level = hooks(row)): Mode {
    const explicit = rawMode(row);
    if (row.event.grace || explicit !== 'auto') return explicit;
    const position = graph.pickup ? add(row.writtenStart, row.pickupOffset) : row.writtenStart;
    let action = meterAction(row, level, position);
    if (!action && graph.modern) {
        const maximum = Math.max(number(row.writtenDuration), previous ? number(previous.writtenDuration) : 0);
        const gridClock = ticks(graph.relativeGrid ? row.event.start : row.clock);
        let grid = 1;
        while (grid <= 3 && (1 / 2 ** grid > maximum || gridClock % (480 / 2 ** grid))) grid++;
        action = meterAction(row, grid <= 3 ? grid : hooks(row), position);
    }
    if (!action && position.n) {
        if (previous && row.tuplet !== previous.tuplet && displayedType(row) === displayedType(previous) && displayedDots(row) === displayedDots(previous))
            action = meterAction(row, Math.max(2, level + 1), position);
        if (row.voice && previous && !previous.tuplet && compare(add(previous.clock, previous.event.duration), row.clock) < 0) action = 1;
    }
    return actionMode(action);
}

function primaryModes(rows: BeamRow[], graph: BeamSourceGraph): Mode[] {
    const shortest = new Map<number, number>();
    for (const row of rows) { const beat = Math.floor(number(row.writtenStart)); shortest.set(beat, Math.max(shortest.get(beat) ?? 0, beamLevels[row.event.type] ?? 0)); }
    return rows.map((row, index) => {
        if ((!row.event.notes.length && rawMode(row) === 'auto') || row.event.notes.length && !hooks(row)) return 'no';
        let mode = sourceMode(row, rows[index - 1], graph);
        if (mode === 'auto' && row.hasSourceTime && !row.event.grace && row.event.start.n && row.meter.unit === 4 && ticks(row.writtenStart) % 480 === 0) {
            const beat = Math.floor(number(row.writtenStart));
            mode = sourceMode(row, rows[index - 1], graph, Math.max(shortest.get(beat) ?? 0, shortest.get(beat - 1) ?? 0));
        }
        return mode;
    });
}

export interface NativeBeamGroup { members: BeamRow[]; header?: SourceElement }
/** Pair formation and an already open END are distinct source operations. */
function groupsForTrack(track: BeamRow[], graph: BeamSourceGraph): NativeBeamGroup[] {
    const groups: NativeBeamGroup[] = [], membership = new Map<BeamRow, NativeBeamGroup>();
    const sequences = new Map<string, BeamRow[]>();
    for (const row of track) { const grace = row.event.grace, key = grace ? `g:${grace.hostId}:${grace.before}` : `m:${row.measure}`; const sequence = sequences.get(key); if (sequence) sequence.push(row); else sequences.set(key, [row]); }
    let previousOrdinary: BeamRow | undefined;
    for (const rows of sequences.values()) {
        let pending: BeamRow | undefined, active: NativeBeamGroup | undefined;
        const grace = !!rows[0].event.grace, first = rows[0], firstMode = rawMode(first);
        if (!grace && previousOrdinary && first.measure > previousOrdinary.measure && !previousOrdinary.breakAfter
            && (firstMode === 'mid' || firstMode === 'end' || graph.modern && continued(firstMode))
            && !['no', 'end'].includes(rawMode(previousOrdinary)) && (!previousOrdinary.event.notes.length || hooks(previousOrdinary))) {
            active = membership.get(previousOrdinary); if (!active) pending = previousOrdinary;
        }
        const modes = primaryModes(rows, graph);
        for (const [index, row] of rows.entries()) {
            const mode = modes[index];
            if (mode === 'no') { pending = undefined; active = undefined; continue; }
            if (active) {
                if (mode === 'begin') active = undefined;
                else { active.members.push(row); membership.set(row, active); if (mode === 'end') active = undefined; continue; }
            }
            if (!pending) { pending = row; continue; }
            const gap = !grace && compare(add(pending.clock, pending.event.duration), row.clock) < 0;
            if (mode === 'begin' || gap && !continued(mode)) { pending = row; continue; }
            active = { members: [pending, row], header: pending.header };
            groups.push(active); membership.set(pending, active); membership.set(row, active); pending = undefined;
        }
        if (!grace) previousOrdinary = rows.at(-1);
    }
    return groups.filter(group => group.members.some(row => row.event.notes.length));
}

/** Inspectable source graph for independent receipts; no public result facts participate in construction. */
export function nativeBeamGroups(graph: BeamSourceGraph): NativeBeamGroup[] { return graph.tracks.flatMap(track => groupsForTrack(track, graph)); }

function hookDirection(group: NativeBeamGroup, index: number, level: number, graph: BeamSourceGraph): 'forward hook' | 'backward hook' {
    const rows = group.members, row = rows[index], previous = rows[index - 1], next = rows[index + 1];
    if (!index) return 'forward hook';
    if (index === rows.length - 1) return 'backward hook';
    if (row.tuplet?.rows[0] === row) return 'forward hook';
    if (row.tuplet?.rows.at(-1) === row) return 'backward hook';
    const nextMode = sourceMode(next, row, graph);
    if (nextMode === 'begin16' && level >= 2 || nextMode === 'begin32' && level >= 3) return 'backward hook';
    if (row.event.grace && !graph.modern) return 'forward hook';
    const currentAction = meterAction(row, hooks(row), row.writtenStart);
    const incoming = currentAction === 2 ? 1 : currentAction === 3 ? 2 : hooks(previous), outgoing = hooks(next);
    if (graph.modern) {
        if (outgoing !== incoming) return outgoing < incoming ? 'backward hook' : 'forward hook';
    } else {
        if (hooks(row) - outgoing > 1 && incoming > outgoing && hooks(row) > incoming) return 'backward hook';
        if (incoming < outgoing) return 'forward hook';
        if (meterAction(next, hooks(row), next.writtenStart)) return 'backward hook';
    }
    let relative = row.tuplet ? subtract(next.clock, row.tuplet.rows[0].clock) : next.event.start;
    if (graph.modern) relative = mul(relative, row.event.staffTiming?.stretch ?? q(1));
    if (row.tuplet && row.tuplet.ratio.n % 2) relative = mul(relative, row.tuplet.ratio);
    const span = ticks(mul(row.writtenDuration, q(2))), remainder = span > 0 ? ticks(relative) % span : 0;
    return remainder <= 6 || span - remainder <= 6 ? 'backward hook' : 'forward hook';
}

function projectGroup(group: NativeBeamGroup, graph: BeamSourceGraph, budget: NativeBudget, findings: Finding[]): void {
    const rows = group.members; let maximum = 0; for (const row of rows) maximum = Math.max(maximum, hooks(row));
    const owner = rows[0], beam = owner.event.beam;
    let direction = beam?.stemDirection;
    // Source-authored chord preferences also select automatic beam direction.
    // This is a source precedence rule; no note-line or page-position heuristic.
    if ((!direction || direction.value === 'auto') && !owner.event.grace && owner.staffKind === 'pitched' && rows.every(row => (row.event.staff ?? row.logicalStaff) === row.logicalStaff)) {
        const chord = graph.modern ? rows.find(row => row.event.notes.length && ['up', 'down'].includes(row.event.sourceStem?.value ?? '')) : rows.find(row => row.event.notes.length);
        const authored = chord?.event.sourceStem;
        if (authored?.value === 'up' || authored?.value === 'down') {
            direction = authored;
            if (graph.modern) {
                const activity = graph.otherVoiceActivity.get(`${owner.part}:${owner.logicalStaff}:${owner.measure}`), last = rows.at(-1)!, end = add(last.clock, last.event.duration);
                if (activity) {
                    let lo = 0, hi = activity.starts.length;
                    while (lo < hi) { const middle = Math.floor((lo + hi) / 2); if (compare(activity.starts[middle], end) < 0) lo = middle + 1; else hi = middle; }
                    if (lo && compare(activity.ends[lo - 1], owner.clock) > 0) direction = { source: owner.event.source, value: owner.voice % 2 ? 'down' : 'up' };
                }
            }
        }
    }
    const sourceBreak = rows.map((row, index) => sourceMode(row, rows[index - 1], graph));
    for (let level = 1; level <= maximum; level++) {
        let segment: number[] = [];
        const finish = (trimRest = false) => {
            // Native rests may bridge beams, but do not create isolated beamlets.
            while (trimRest && segment.length > 1 && !rows[segment.at(-1)!].event.notes.length) segment.pop();
            if (!segment.length) return;
            if (segment.length === 1 && !rows[segment[0]].event.notes.length) { segment = []; return; }
            for (const [offset, index] of segment.entries()) {
                const row = rows[index];
                const value = segment.length === 1 ? hookDirection(group, index, level, graph) : offset === 0 ? 'begin' : offset === segment.length - 1 ? 'end' : 'continue';
                budget.add('markings', 1, row.event.source);
                (row.event.beams ??= []).push({ number: level, value, ...(beam?.visible === false ? { printObject: false } : {}), ...(beam?.sourceColor ? { sourceColor: beam.sourceColor } : {}) });
            }
            segment = [];
        };
        for (const [index, row] of rows.entries()) {
            const broken = sourceBreak[index] === 'begin16' && level >= 2 || sourceBreak[index] === 'begin32' && level >= 3;
            if (broken) finish(true);
            if (!row.event.notes.length) {
                if (segment.length) segment.push(index);
                else if (!index && hooks(row) >= level) segment.push(index);
            } else if (hooks(row) >= level) segment.push(index);
            else finish(true);
        }
        finish();
    }
    if (beam?.growLeft !== undefined || beam?.growRight !== undefined) {
        const left = beam.growLeft ?? 1, right = beam.growRight ?? 1;
        if (left !== right && owner.event.beams?.[0]) owner.event.beams[0].fan = left < right ? 'accel' : 'rit';
    }
    if (!direction || direction.value === 'auto') return;
    // Fragment coordinates belong to the direction slot active when read.
    // Obsolete l1/l2 fields do not activate a modified drawing.
    let fragmentSlot = 'auto'; const editedSlots = new Set<string>();
    for (const node of group.header?.children ?? []) {
        if (node.name === 'StemDirection') fragmentSlot = node.text.trim();
        else if (['Fragment', 'y1', 'y2'].includes(node.name)) editedSlots.add(fragmentSlot === 'up' ? 'up' : 'down');
    }
    const edited = editedSlots.has(beam?.stemDirection?.value === 'up' ? 'up' : 'down');
    const moves = new Set(rows.filter(row => row.event.notes.length).map(row => (row.event.staff ?? row.logicalStaff) - row.logicalStaff));
    let physical = false;
    for (const row of rows) {
        if (!row.event.notes.length || row.event.stem === 'none') continue;
        if (edited || moves.size > 1 && row.event.staff !== row.logicalStaff) { physical = true; continue; }
        row.event.stem = direction.value; row.event.stemOrigin = { source: direction.source, origin: 'derived-source-beam' };
    }
    if (physical) findings.push({ disposition: 'excluded-by-scope', code: 'native-beam-physical-layout', message: 'Source beam direction and complete musical membership are retained. Individual stems in edited or mixed moved groups depend on native page geometry; the authored request is not an invented uniform physical direction.', location: direction.source });
}

/** One source-qualified pass after exact clocks/ties; no score-specific profiles or musical-note substitutions. */
export function recoverNativeBeamGraph(capture: Pick<ParsedNativeCapture, 'nativeVersion'> & Partial<Pick<ParsedNativeCapture, 'root' | 'styleRoot'>>, scoreNode: SourceElement, parts: MusicalPart[], budget: NativeBudget): Finding[] {
    const findings = applyCrossMeasureValues(capture, scoreNode, parts), graph = qualifyBeamSource(capture, scoreNode, parts);
    let count = 0; let first: Location | undefined;
    for (const track of graph.tracks) {
        for (const row of track) { delete row.event.beams; if (row.event.stemOrigin?.origin === 'derived-source-beam') { delete row.event.stemOrigin; if (row.event.sourceStem?.value === 'up' || row.event.sourceStem?.value === 'down') { row.event.stem = row.event.sourceStem.value; row.event.stemOrigin = { source: row.event.sourceStem.source, origin: 'source-chord' }; } else if (row.event.stem !== 'none') delete row.event.stem; } }
        for (const group of groupsForTrack(track, graph)) { projectGroup(group, graph, budget, findings); count++; first ??= group.members[0].event.source; }
    }
    if (first) findings.unshift({ disposition: 'inferred', code: 'native-source-beam-graph', message: 'Complete source logical tracks establish ordinary/grace beam membership, secondary boundaries and hooks from written values, active meter Groups, nested tuplet identity and source modes. Cross-measure continuation and authored beam direction retain their source ownership; pitches, clocks, modes and physical moves are unchanged.', location: first, fact: { groups: count } });
    return findings;
}

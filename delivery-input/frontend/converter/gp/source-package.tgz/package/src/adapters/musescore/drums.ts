import { child, children, integer, type SourceElement as Element } from '../../core/source-xml.js';
import type { MusicalPart } from '../../core/model.js';
import type { NativeBudget } from './budget.js';
import { refuse } from '../../core/report.js';

const heads: Record<string, string> = { normal: 'normal', cross: 'x', plus: 'cross', xcircle: 'circle-x', 'triangle-up': 'triangle', 'triangle-down': 'inverted triangle', slash: 'slash', diamond: 'diamond', 'diamond-old': 'diamond', circled: 'circled', slashed1: 'slashed', slashed2: 'back slashed', sol: 'so', la: 'la', fa: 'fa', mi: 'mi', do: 'do', re: 're', ti: 'ti' };
export function readNativeDrums(instrument: Element, identity: string, ctx: { use: (e: Element) => void; get: (e: Element, field: string, required?: boolean) => string; budget: NativeBudget }): NonNullable<MusicalPart['percussionInstruments']> {
    const drums = children(instrument, 'Drum'), seen = new Set<number>(); ctx.budget.add('markings', drums.length, instrument.location);
    return drums.map(drum => {
        ctx.use(drum); const midi = integer(drum.attrs.pitch, 0, 127, drum.location);
        if (seen.has(midi)) refuse('native-drum-identity', 'Conflicting source drum definitions share one MIDI identity.', drum.location); seen.add(midi);
        const line = integer(ctx.get(drum, 'line', true), -32, 32, drum.location), head = ctx.get(drum, 'head') || 'normal', stem = ctx.get(drum, 'stem'), voice = ctx.get(drum, 'voice');
        if (!Object.hasOwn(heads, head)) refuse('native-drum-head', 'Unknown source drum notehead.', drum.location);
        if (stem && !['0', '1', '2'].includes(stem)) refuse('native-drum-stem', 'Unknown drum stem default.', drum.location);
        const glyphs = child(drum, 'noteheads');
        let noteheadGlyphs: NonNullable<MusicalPart['percussionInstruments']>[number]['noteheadGlyphs'];
        if (glyphs) {
            if (glyphs.text.trim() || Object.keys(glyphs.attrs).length || children(drum, 'noteheads').length !== 1)
                refuse('native-drum-glyphs', 'Custom drum heads require one plain duration map.', glyphs.location);
            ctx.use(glyphs); noteheadGlyphs = { source: glyphs.location, active: drum.children.indexOf(child(drum, 'head')!) < drum.children.indexOf(glyphs), byType: {} };
            for (const field of glyphs.children) {
                if (!['whole', 'half', 'quarter', 'breve'].includes(field.name) || field.children.length || Object.keys(field.attrs).length
                    || !/^[a-zA-Z][a-zA-Z0-9]{0,127}$/.test(field.text) || Object.hasOwn(noteheadGlyphs.byType, field.name))
                    refuse('native-drum-glyphs', 'Custom drum heads require unique source duration keys and canonical symbol names.', field.location);
                ctx.use(field); ctx.budget.add('markings', 1, field.location);
                noteheadGlyphs.byType[field.name as keyof typeof noteheadGlyphs.byType] = { source: field.location, name: field.text };
            }
            if (Object.keys(noteheadGlyphs.byType).length !== 4) refuse('native-drum-glyphs', 'An incomplete custom drum map has no source authority for every duration head.', glyphs.location);
            // Loading a later ordinary head resets the custom group; preserve the
            // glyph table but only use it when the native load order activates it.

        }
        return { source: drum.location, id: `native-drum:${identity}:${midi}`, midi, line, notehead: heads[head], ...(noteheadGlyphs ? { noteheadGlyphs } : {}), name: ctx.get(drum, 'name') || `Percussion ${midi}`, defaultVoice: voice ? integer(voice, 0, 3, drum.location) : 0,
            ...(stem && stem !== '0' ? { defaultStem: stem === '1' ? 'up' as const : 'down' as const } : {}) };
    });
}

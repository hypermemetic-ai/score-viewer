import type { Meter, MusicalEvent, MusicalPart } from '../../core/model.js';
import type { Location } from '../../core/report.js';
import { refuse } from '../../core/report.js';
import { add, compare, mul, q, type Rational } from '../../core/rational.js';
import { child, children, type SourceElement } from '../../core/source-xml.js';
import type { ParsedNativeCapture } from './capture-core.js';

export const beamLevels: Readonly<Record<string, number>> = { eighth: 1, '16th': 2, '32nd': 3, '64th': 4, '128th': 5, '256th': 6, '512th': 7, '1024th': 8 };
export interface BeamTuplet { source: SourceElement; parent?: BeamTuplet; ratio: Rational; rows: BeamRow[] }
export interface BeamRow {
    event: MusicalEvent; source: SourceElement; header?: SourceElement; tuplet?: BeamTuplet;
    meter: Meter; writtenStart: Rational; writtenDuration: Rational; clock: Rational;
    measure: number; logicalStaff: number; voice: number; breakAfter: boolean; pickupOffset: Rational; part: string; staffKind: string; hasSourceTime: boolean;
}
export interface BeamSourceGraph {
    tracks: BeamRow[][];
    modern: boolean; pickup: boolean; relativeGrid: boolean;
    otherVoiceActivity: ReadonlyMap<string, { starts: Rational[]; ends: Rational[] }>;
}
const value = (owner: SourceElement, name: string) => child(owner, name)?.text.trim();
const duration = (event: MusicalEvent): Rational => {
    if (event.crossMeasureValue?.role === 'start') return event.crossMeasureValue.duration;
    if (event.durationOverride) return event.durationOverride.encoded;
    const level = beamLevels[event.type], base = level ? q(1, 2 ** level) : q(event.type === 'quarter' ? 1 : event.type === 'half' ? 2 : event.type === 'whole' ? 4 : event.type === 'breve' ? 8 : 16);
    return mul(base, q(2 ** (event.dots + 1) - 1, 2 ** event.dots));
};

/** Only topology-bearing source fields enter qualification; captions and note payload cannot invalidate a beam. */
export function qualifyBeamSource(capture: Pick<ParsedNativeCapture, 'nativeVersion'>, scoreNode: SourceElement, parts: MusicalPart[]): BeamSourceGraph {
    // The file format, not the producer build, selects the beam layout rules.
    const nativeMajor = Number(capture.nativeVersion.split('.')[0]), minor = Math.floor(Number(capture.nativeVersion.split('.')[1] ?? '0') / 10);
    const modern = nativeMajor === 4;
    const contexts = new Map<Location, { source: SourceElement; header?: SourceElement; tuplet?: BeamTuplet; breakAfter: boolean; hasSourceTime: boolean }>();
    for (const staff of children(scoreNode, 'Staff')) {
        let hasSourceTime = false;
        for (const measure of children(staff, 'Measure')) {
            const primary = children(measure, 'voice')[0];
            if (primary) for (const node of primary.children) { if (node.name === 'Chord' || node.name === 'Rest') break; if (node.name === 'TimeSig' && value(node, 'isCourtesy') !== '1') hasSourceTime = true; }
            const breakAfter = measure.children.some(node => node.name === 'LayoutBreak' && ['line', 'page', 'section', '0', '1', '2'].includes(value(node, 'subtype') ?? ''));
            for (const voice of children(measure, 'voice')) {
                const tuplets: BeamTuplet[] = []; let header: SourceElement | undefined;
                for (const node of voice.children) {
                    if (node.name === 'Tuplet') {
                        const actual = Number(value(node, 'actualNotes')), normal = Number(value(node, 'normalNotes'));
                        if (!Number.isInteger(actual) || !Number.isInteger(normal) || actual < 1 || normal < 1) refuse('native-beam-source', 'Beam tuplet identity needs the admitted source ratio.', node.location);
                        tuplets.push({ source: node, parent: tuplets.at(-1), ratio: q(actual, normal), rows: [] });
                    } else if (node.name === 'endTuplet') tuplets.pop();
                    else if (node.name === 'Beam') header = node;
                    else if (node.name === 'Chord' || node.name === 'Rest') {
                        contexts.set(node.location, { source: node, header, tuplet: tuplets.at(-1), breakAfter, hasSourceTime }); header = undefined;
                    }
                }
            }
        }
    }
    const tracks: BeamRow[][] = [];
    for (const part of parts) {
        const voices: BeamRow[][] = []; let measureClock = q(0);
        for (const [mi, measure] of part.measures.entries()) {
            for (const [vi, events] of measure.voices.entries()) {
                const logicalStaff = Math.floor(vi / 4) + 1, staff = measure.staffs?.find(staff => staff.number === logicalStaff);
                let meter = staff?.time ?? measure.time;
                const changes = (measure.changes ?? []).filter(change => change.staff === logicalStaff && change.time && !change.courtesy).sort((a, b) => compare(a.position, b.position));
                let changeIndex = 0;
                for (const event of events) {
                    const context = contexts.get(event.source) ?? refuse('native-beam-source', 'Decoded event lacks its original selected source chord/rest.', event.source);
                    while (changeIndex < changes.length && compare(changes[changeIndex].position, event.start) <= 0) meter = changes[changeIndex++].time!;
                    const stretch = event.staffTiming?.stretch ?? staff?.stretch ?? q(1);
                    const nominal = q(meter.beats * 4, meter.unit), writtenSpan = mul(measure.duration, stretch);
                    const pickupOffset = measure.pickup && compare(writtenSpan, nominal) < 0 ? add(nominal, q(-writtenSpan.n, writtenSpan.d)) : q(0);
                    const row: BeamRow = { ...context, event, meter, writtenStart: mul(event.start, stretch), writtenDuration: duration(event), clock: add(measureClock, event.start), measure: mi, logicalStaff, voice: vi % 4, pickupOffset, part: part.id, staffKind: staff?.kind ?? 'pitched' };
                    for (let tuplet = row.tuplet; tuplet; tuplet = tuplet.parent) tuplet.rows.push(row);
                    (voices[vi] ??= []).push(row);
                }
            }
            measureClock = add(measureClock, measure.duration);
        }
        tracks.push(...voices.filter(Boolean));
    }
    const otherVoices = new Map<string, BeamRow[]>();
    for (const track of tracks) for (const row of track) if (row.voice && !row.event.grace && row.event.printObject !== false && (!row.event.notes.length || row.event.notes.some(note => note.printObject !== false) || row.event.sourceStemVisibility?.value === true || row.event.sourceHook?.printObject === true)) {
        const key = `${row.part}:${row.logicalStaff}:${row.measure}`, rows = otherVoices.get(key) ?? []; rows.push(row); otherVoices.set(key, rows);
    }
    const otherVoiceActivity = new Map<string, { starts: Rational[]; ends: Rational[] }>();
    for (const [key, rows] of otherVoices) {
        rows.sort((a, b) => compare(a.clock, b.clock)); const starts: Rational[] = [], ends: Rational[] = [];
        for (const row of rows) { const end = add(row.clock, row.event.duration), previous = ends.at(-1); starts.push(row.clock); ends.push(previous && compare(previous, end) > 0 ? previous : end); }
        otherVoiceActivity.set(key, { starts, ends });
    }
    return { tracks, modern, pickup: modern && minor >= 4, relativeGrid: modern && minor >= 7, otherVoiceActivity };
}

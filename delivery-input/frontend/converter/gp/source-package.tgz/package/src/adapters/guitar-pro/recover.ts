import { gpifHopo } from './gpif-hopo.js';
import { transposeWrittenKeys } from './keys.js';
import { readPartialCapo, physicalFret, partialOpenOffset, partialCapoInstruction } from './partial-capo.js';
import { masterStructure, beatStructure, beatRelations, scoreTexts, trackLyrics } from './structure.js';
import { GpifParser } from '../../../third_party/alphatab/src/importer/GpifParser.js';
import { Settings } from '../../../third_party/alphatab/src/ReaderSettings.js';
import { Logger } from '../../../third_party/alphatab/src/Logger.js';
import { LogLevel } from '../../../third_party/alphatab/src/LogLevel.js';
import { Note } from '../../../third_party/alphatab/src/model/Note.js';
import { add, decimal, equal, mul, q, type Rational } from '../../core/rational.js';
import { freeze, refuse, type Finding, type Location } from '../../core/report.js';
import type { MusicalEvent as Event, MusicalMeasure as Measure, MusicalScore, MusicalNote, NoteFact, MusicalPart as Part, Pitch, Tempo, MusicalRelation, Part as FrettedPart } from '../../core/model.js';
import { child, children, integer, value, type Element } from './xml.js';
import { arrangementTrack, type ArrangementTrack } from './arrangements.js';
import { sourcePercussion, percussionNote, percussionInstrument, type SourcePercussion } from './percussion.js';
import { limits } from './limits.js';
import { admittedFamily, midiFamily } from './admission.js';
import type { GpifMode } from './profile.js';
import { noteTechniques, beatTechniques, connectSlides, harmonicKind, connectSustainMarks, numberHopo, harmonicResult } from './techniques.js';

const values: Record<string, [number, string]> = {
    Long: [-4, 'long'], DoubleWhole: [-2, 'breve'], Whole: [1, 'whole'], Half: [2, 'half'], Quarter: [4, 'quarter'], Eighth: [8, 'eighth'],
    '16th': [16, '16th'], '32nd': [32, '32nd'], '64th': [64, '64th'], '128th': [128, '128th'], '256th': [256, '256th']
};
function idmap(root: Element, group: string, kind: string): Map<string, Element> {
    const result = new Map<string, Element>();
    for (const e of children(child(root, group)!, kind)) {
        const id = e.attrs.id;
        if (!/^[0-9]{1,6}$/.test(id) || result.has(id)) refuse('identity', `Invalid/duplicate ${kind} ID.`, e.location);
        result.set(id, e);
    }
    if (!result.size && !['Notes','Beats','Rhythms','Voices'].includes(group)) refuse('structure', `Empty ${group} are unsupported in this proof.`, root.location);
    return result;
}
function refs(e: Element, name: string, required = true): string[] {
    const s = value(e, name, required);
    if (!s) return [];
    if (!(name === 'Voices' ? /^(?:-1|[0-9]{1,6})(?:\s+(?:-1|[0-9]{1,6}))*$/ : /^[0-9]{1,6}(?:\s+[0-9]{1,6})*$/).test(s)) refuse('reference', `Invalid ${name} reference list; missing placeholder scopes require a separate profile.`, e.location);
    return s.split(/\s+/);
}
function lookup(map: Map<string, Element>, id: string, at: Element): Element {
    const e = map.get(id);
    if (!e) refuse('reference', `Unresolved source ID ${id}.`, at.location);
    return e!;
}
function props(e: Element): Map<string, Element> {
    const result = new Map<string, Element>();
    const group = child(e, 'Properties', false);
    for (const p of group?.children ?? []) {
        if (result.has(p.attrs.name)) refuse('property', 'Duplicate source property.', p.location);
        result.set(p.attrs.name, p);
    }
    return result;
}
function flag(s: string | undefined, at: Element): boolean {
    if (s === undefined) return false;
    if (s !== 'true' && s !== 'false') refuse('boolean', 'Expected true/false.', at.location);
    return s === 'true';
}
const semitones: Record<string, number> = { C: 0, D: 2, E: 4, F: 5, G: 7, A: 9, B: 11 };
function inferPitch(midi: number): Pitch {
    const steps = ['C', 'C', 'D', 'D', 'E', 'F', 'F', 'G', 'G', 'A', 'A', 'B'];
    const step = steps[midi % 12], alter = midi % 12 - semitones[step];
    return { step, alter, octave: Math.floor(midi / 12) - 1, midi, origin: 'inferred' };
}
function pitch(property: Element, expected: number, convention: 'midi-octave' | 'scientific' = 'midi-octave'): Pitch {
    const p = child(property, 'Pitch')!, step = value(p, 'Step'), acc = value(p, 'Accidental');
    const alter = ({ '': 0, '#': 1, b: -1, x: 2, bb: -2 } as Record<string, number>)[acc];
    const octave = integer(value(p, 'Octave'), 0, 10, p);
    if (semitones[step] === undefined || alter === undefined) refuse('pitch', 'Unsupported pitch spelling.', p.location);
    const midi = (octave + (convention === 'scientific' ? 1 : 0)) * 12 + semitones[step] + alter;
    if (midi !== expected) refuse('pitch-conflict', `Encoded pitch ${step}${acc}${octave} (${midi}) disagrees with physical/transposition pitch ${expected}.`, p.location);
    return { step, alter, octave: octave - (convention === 'scientific' ? 0 : 1), midi, origin: 'source' };
}
export interface FrettedOccurrenceCapture {
    kind?: 'fretted';
    source: Location; rhythmId: string; noteId: string;
    before: { fret: number; string: number; tieDestination: boolean };
    after: { fret: number; string: number; tieDestination: boolean; soundingMidi: number; playbackTicks: number };
}
/** Explicit source deadness with unspecified physical fret; -1 is a raw sentinel only. */
export interface DeadOccurrenceCapture {
    kind:'dead'; source:Location; rhythmId:string; noteId:string;
    before:{string?:number;rawFret:-1;tieDestination:false};
    after:{string?:number;rawFret:-1;tieDestination:false;playbackTicks:number};
}
export type OccurrenceCapture = DeadOccurrenceCapture | FrettedOccurrenceCapture | { kind: 'pitched'; source: Location; rhythmId: string; noteId: string; before: { soundingMidi: number; writtenMidi: number; tieDestination: boolean }; after: { soundingMidi: number; tieDestination: boolean; playbackTicks: number } } | { kind: 'unpitched'; source: Location; rhythmId: string; noteId: string; before: { articulation: number; tieDestination: boolean }; after: { articulation: number; tieDestination: boolean; playbackTicks: number } };
export interface Recovery { score: MusicalScore; occurrences: OccurrenceCapture[] }

/** Raw immutable GPIF feeds clocks/spelling; borrowed model is reconciled recovery evidence. */
export function recover(root: Element, xml: string, findings: Finding[], mode: GpifMode = 'constructed', context?: { track: ArrangementTrack; percussion: SourcePercussion[]; staffNumber: number; sourceNotes?: Map<string, Element> }): Recovery {
    const tracks = idmap(root, 'Tracks', 'Track'), bars = idmap(root, 'Bars', 'Bar'), voices = idmap(root, 'Voices', 'Voice');
    const beats = idmap(root, 'Beats', 'Beat'), notes = idmap(root, 'Notes', 'Note'), rhythms = idmap(root, 'Rhythms', 'Rhythm');
    const trackIds = refs(child(root, 'MasterTrack')!, 'Tracks');
    if (trackIds.length !== tracks.size || new Set(trackIds).size !== trackIds.length || trackIds.length > limits.tracks)
        refuse('track-scope', 'Every defined track must occur exactly once in the master track and fit the profile.', root.location);
    const masters = children(child(root, 'MasterBars')!, 'MasterBar');
    if (!masters.length || masters.length > limits.measures) refuse('measure-budget', 'Measure count outside profile.', root.location);
    const used = { bars: new Set<string>(), voices: new Set<string>(), beats: new Set<string>(), notes: new Set<string>(), rhythms: new Set<string>() };
    const expectedOccurrences: { note: MusicalNote; event: Event; rhythmId: string }[] = [];
    const readerPhysicalFrets = new Map<MusicalNote, number>();
    const drumArticulations = new Map<MusicalNote, number>();
    const slideOrigins = new Map<NoteFact, number>(), relations: MusicalRelation[] = [];
    let eventCount = 0, noteCount = 0;
    const pickup = !!child(child(root, 'MasterTrack')!, 'Anacrusis', false);
    let repeatDepth = 0;
    const common = masters.map((master, index) => {
        const time = value(master, 'Time').split('/');
        if (time.length !== 2) refuse('meter', 'Expected n/d meter.', master.location);
        const unit = integer(time[1], 1, 64, master), numerator = integer(time[0], 1, 32, master);
        if (unit & (unit - 1)) refuse('meter', 'Meter denominator must be a power of two.', master.location);
        const key = child(master, 'Key')!, fifths = integer(value(key, 'AccidentalCount'), -7, 7, key), mode = value(key, 'Mode');
        if (!['Major', 'Minor'].includes(mode)) refuse('key', 'Unsupported key mode.', key.location);
        const ids = refs(master, 'Bars');
        if (ids.length !== tracks.size || new Set(ids).size !== ids.length) refuse('bar-scope', 'One unique staff bar per track is required.', master.location);
        const repeat = child(master, 'Repeat', false);
        const start = repeat ? flag(repeat.attrs.start, repeat) : false, end = repeat ? flag(repeat.attrs.end, repeat) : false;
        if (start) repeatDepth++;
        // The start of the piece is the conventional implicit start for an unmatched end-repeat.
        const count = end ? integer(repeat!.attrs.count, 2, 255, repeat!) : 0;
        if (repeat?.attrs.count) integer(repeat.attrs.count, end ? 2 : 0, 255, repeat);
        if (repeat && !end && repeat.attrs.count) findings.push({ disposition: 'omitted', code: 'inactive-repeat-count', message: 'Inactive repeat count does not specify playback without an end flag; retained in original input (capture delivered only on success).', location: repeat.location, fact: repeat.attrs.count });
        if (end && repeatDepth) repeatDepth--;
        return { time: { beats: numerator, unit }, key: { fifths, mode: mode.toLowerCase() }, duration: q(numerator * 4, unit), ids, start, count, free:!!child(master,'FreeTime',false), pickup: index === 0 && pickup };
    });
    if (repeatDepth) refuse('repeat', 'Unclosed repeat start.', masters.at(-1)!.location);
    const parts: Part[] = trackIds.map((trackId, trackIndex) => {
        const t = lookup(tracks, trackId, root), properties = props(t), tuningProperty = properties.get('Tuning');
        const descriptor = context?.track ?? arrangementTrack(t), percussion = descriptor.percussion, fretted = descriptor.fretted;
        const percussionUsed = new Map<string, SourcePercussion>();
        if (fretted && !tuningProperty) refuse('tuning', 'Explicit tuning is required; no instrument-name defaults.', t.location);
        const tuningText = tuningProperty && !percussion ? value(tuningProperty, 'Pitches') : '';
        const tuning = tuningText ? tuningText.split(/\s+/).map(s => integer(s, 0, 127, tuningProperty!)) : [];
        if (tuningProperty && !percussion && (tuning.length < 1 || tuning.length > 16))
            refuse('tuning', 'Source tuning requires 1–16 explicitly ordered strings; pitch order is not assumed.', tuningProperty!.location);
        const capoProperty = properties.get('CapoFret');
        const capo = capoProperty ? { source: { ...child(capoProperty, 'Fret')!.location, trackId }, fret: integer(value(capoProperty, 'Fret'), 0, 999999, capoProperty) } : undefined;
        if (capo) findings.push({ disposition: 'preserved', code: 'full-capo', message: 'Full capo is retained separately from non-capo open-string tuning and capo-relative source fret. Its semitone shift is applied once to physical pitch, independently of written octave transposition.', location: capo.source, fact: { fret: capo.fret } });
        const partialCapo = readPartialCapo(properties, tuning.length);
        const openOffset = (stringIndex: number) => partialOpenOffset(capo?.fret ?? 0, partialCapo, stringIndex);
        const physicalOffset = (stringIndex: number, fret: number) => physicalFret(capo?.fret ?? 0, partialCapo, stringIndex, fret);
        const trans = child(t, 'Transpose', false);
        const octaves = trans ? integer(value(trans, 'Octave'), -2, 2, trans) : 0;
        const chromatic = trans ? integer(value(trans, 'Chromatic'), -24, 24, trans) : 0, semitoneTranspose = octaves * 12 + chromatic;
        let diatonicTranspose: number | undefined;
        const inferredDiatonic = Math.sign(chromatic) * (Math.floor(Math.abs(chromatic) / 12) * 7 + [0,0,1,2,2,3,3,4,5,5,6,6][Math.abs(chromatic) % 12]);
        const midi = child(t, 'GeneralMidi')!;
        if (!['Instrument','Percussion'].includes(midi.attrs.table)) refuse('instrument', 'Non-string/percussion tables require another profile.', midi.location);
        const program = integer(value(midi, 'Program'), 0, 127, midi);
        const instrument = child(t, 'Instrument')!;
        if (!/^[A-Za-z0-9_-]{1,128}$/.test(instrument.attrs.ref ?? '')) refuse('instrument', 'An explicit nonempty instrument reference is required.', instrument.location);
        admittedFamily(instrument.attrs.ref, program, instrument.location);
        if (descriptor.family !== midiFamily(program, percussion)) findings.push({ disposition: 'preserved', code: 'playback-timbre-role', message: 'Explicit source instrument identity and independently checked notation/physical facts determine the part family. Its separately encoded MIDI program is retained as playback timbre without overriding that performer role.', location: instrument.location, fact: { sourceFamily: descriptor.family, midiProgram: program } });
        if (instrument.attrs.ref === 's-gtr6' && tuning.length !== 6) refuse('instrument-profile', 'The reviewed s-gtr6 source reference requires six explicit strings.', instrument.location);
        let convention: 'midi-octave-written' | 'scientific-physical' | 'absent' = mode === 'gp8-scientific' ? 'scientific-physical' : 'midi-octave-written';
        if (mode === 'gpif-physical' && !percussion) {
            let midiOctave = true, scientific = true, explicit = 0, absent = 0;
            const reachable = new Set<string>();
            for (const c of common) for (const voiceId of refs(lookup(bars, c.ids[trackIndex], t), 'Voices').filter(id => id !== '-1'))
                for (const beatId of refs(lookup(voices, voiceId, t), 'Beats'))
                    for (const noteId of refs(lookup(beats, beatId, t), 'Notes', false)) reachable.add(noteId);
            for (const id of reachable) {
                const n = lookup(notes, id, t), p = props(n), concert = p.get('ConcertPitch'), transposed = p.get('TransposedPitch'), sourceMidi = p.get('Midi');
                if (!concert && !transposed && !sourceMidi) { absent++; continue; }
                if (!concert || !transposed || !sourceMidi) refuse('pitch-corroboration', 'Encoded pitch profile requires complete ConcertPitch/TransposedPitch/Midi triplets, or wholly absent GP6 spelling.', n.location);
                const string = p.get('String'), fret = p.get('Fret');
                if (fretted && (!string || !fret) || !!string !== !!fret) refuse('physical-pitch', 'Fretted notes require paired explicit string/fret.', n.location);
                const hasGrid = !!string && !!fret && !!tuning.length;
                const physical = hasGrid ? tuning[integer(value(string!, 'String'), 0, tuning.length - 1, string!)] + physicalOffset(integer(value(string!, 'String'), 0, tuning.length - 1, string!), integer(value(fret!, 'Fret'), 0, 999999, fret!)) : integer(value(sourceMidi!, 'Number'), 0, 127, sourceMidi!);
                const harmonic = harmonicKind(n), actualMidi = integer(value(sourceMidi!, 'Number'), 0, 127, sourceMidi!);
                if (!harmonic && actualMidi !== physical) refuse('pitch-conflict', 'Source MIDI disagrees with non-capo tuning plus full capo plus source fret.', sourceMidi!.location);
                const raw = (property: Element): number => {
                    const field = child(property, 'Pitch')!, step = value(field, 'Step'), acc = value(field, 'Accidental');
                    const alter = ({ '': 0, '#': 1, b: -1, x: 2, bb: -2 } as Record<string, number>)[acc];
                    if (semitones[step] === undefined || alter === undefined) refuse('pitch', 'Unsupported source spelling.', field.location);
                    return integer(value(field, 'Octave'), 0, 10, field) * 12 + semitones[step] + alter;
                };
                const cp = raw(concert!), tp = raw(transposed!);
                const stringIndex = hasGrid ? integer(value(string!, 'String'), 0, tuning.length - 1, string!) : 0;
                if (harmonic && !hasGrid) refuse('harmonic-source', 'Harmonic source requires its encoded physical reference.', n.location);
                const result = hasGrid ? harmonicResult(n, physical, tuning[stringIndex] + openOffset(stringIndex), integer(value(fret!, 'Fret'), 0, 999999, fret!)) : undefined;
                if (harmonic && actualMidi !== physical && actualMidi !== result) refuse('harmonic-pitch-conflict', 'Encoded MIDI contradicts both source physical reference and established harmonic-node result.', sourceMidi!.location);
                const displayed = harmonic === 'natural' && result !== undefined ? result : physical;
                midiOctave &&= cp === physical && [physical - semitoneTranspose, displayed - semitoneTranspose].includes(tp);
                scientific &&= cp + 12 === physical && [physical, displayed].includes(tp + 12);
                explicit++;
            }
            const gp6 = !value(root, 'GPVersion', false) || /^6(?:\.|$)/.test(value(root, 'GPVersion', false));
            if (absent && (!gp6 || explicit)) refuse('pitch-corroboration', 'Only GP6 wholly absent spelling is admitted; mixed profiles are refused.', t.location);
            if (explicit && midiOctave === scientific) refuse('pitch-conflict', 'All source note tuples must establish one consistent physical pitch convention; version labels do not choose it.', t.location);
            convention = explicit ? midiOctave ? 'midi-octave-written' : 'scientific-physical' : 'absent';
            if (!explicit && !gp6 && reachable.size) refuse('pitch-corroboration', 'GP7/8 physical admission requires complete explicit pitch triplets.', t.location);
            findings.push({ disposition: convention === 'absent' ? 'inferred' : 'preserved', code: 'gpif-pitch-profile', message: 'Pitch encoding profile is established across every reachable source note using physical tuning/fret/MIDI consistency, independently of producer/version labels. Raw pitches remain unchanged.', location: t.location, fact: { convention, explicitNotes: explicit, absentNotes: absent } });
        }
        const measures: Measure[] = common.map((c, measureIndex) => {
            const barId = c.ids[trackIndex], b = lookup(bars, barId, masters[measureIndex]);
            if (used.bars.has(barId)) refuse('bar-reuse', 'Reused staff bar objects require distinct occurrence construction.', b.location);
            used.bars.add(barId);
            const clef = value(b, 'Clef'), clefOctave = value(b, 'Ottavia', false);
            if (clefOctave && !['8va','8vb','15ma','15mb'].includes(clefOctave)) refuse('clef-octave', 'Unknown source clef octave decoration.', b.location);
            if (clefOctave && clef === 'Neutral') refuse('clef-octave', 'Unpitched clef cannot carry a pitched octave decoration.', b.location);
            const outputClef = clef === 'Neutral' ? 'PERC' : clefOctave ? (clef === 'G2' ? 'G' : clef === 'F4' ? 'F' : clef) + clefOctave : clef;
            if (!['G2', 'F4', 'C3', 'C4', 'Neutral'].includes(clef)) refuse('clef', 'Unsupported clef.', b.location);
            const voiceIds = refs(b, 'Voices');
            if (!voiceIds.length || voiceIds.length > 4 || new Set(voiceIds.filter(id => id !== '-1')).size !== voiceIds.filter(id => id !== '-1').length) refuse('voice-scope', 'Expected 1–4 distinct voices.', b.location);
            const recoveredVoices = voiceIds.map((voiceId, voiceIndex) => {
                if (voiceId === '-1') return [];
                const v = lookup(voices, voiceId, b);
                if (used.voices.has(voiceId)) refuse('voice-reuse', 'Reused voice objects require a separate reader patch; beat/note reuse is supported.', v.location);
                used.voices.add(voiceId);
                const ids = refs(v, 'Beats');
                if (!ids.length && mode === 'constructed') refuse('empty-voice', 'Represent silence with explicit rhythmic rests.', v.location);
                let position = q(0);
                return ids.map((beatId, beatIndex) => {
                    if (++eventCount > limits.occurrences) refuse('occurrence-budget', 'Expanded occurrence budget exceeded.', v.location);
                    used.beats.add(beatId);
                    const be = lookup(beats, beatId, v), rhythmRef = child(be, 'Rhythm')!.attrs.ref;
                    const r = lookup(rhythms, rhythmRef, be); used.rhythms.add(rhythmRef);
                    const type = value(r, 'NoteValue'), item = values[type];
                    if (!item) refuse('rhythm', 'Unrecognized native written duration.', r.location);
                    const dot = child(r, 'AugmentationDot', false), dots = dot ? integer(dot.attrs.count, 0, 3, dot) : 0;
                    const tuple = child(r, 'PrimaryTuplet', false);
                    const tuplet = tuple ? { actual: integer(tuple.attrs.num, 2, 64, tuple), normal: integer(tuple.attrs.den, 1, 64, tuple) } : undefined;
                    let duration = item[0] < 0 ? q(-4 * item[0]) : q(4, item[0]);
                    duration = mul(duration, q(2 ** (dots + 1) - 1, 2 ** dots));
                    if (tuplet) duration = mul(duration, q(tuplet.normal, tuplet.actual));
                    const grace = child(be, 'GraceNotes', false), writtenDuration = duration;
                    if (grace) { if (!['BeforeBeat','OnBeat'].includes(grace.text.trim())) refuse('grace', 'Unknown grace timing.', grace.location); duration = q(0); }
                    const location = { ...be.location, trackId, staff: context?.staffNumber ?? 1, measure: measureIndex + 1, voice: voiceIndex + 1, beat: beatIndex + 1 };
                    const noteIds = refs(be, 'Notes', false);
                    if (new Set(noteIds).size !== noteIds.length || noteIds.length > (fretted ? tuning.length : 64)) refuse('chord', 'Duplicate/oversized chord.', location);
                    if ((noteCount += noteIds.length) > limits.occurrences) refuse('occurrence-budget', 'Expanded note occurrence budget exceeded.', location);
                    const sourceNotes: MusicalNote[] = noteIds.map(noteId => {
                        used.notes.add(noteId); const n = lookup(notes, noteId, be), np = props(n);
                        const noteSource = { ...location, ...n.location, trackId, staff: context?.staffNumber ?? 1, measure: measureIndex + 1, voice: voiceIndex + 1, beat: beatIndex + 1 };
                        const outputId = `gp:${trackId}:${context?.staffNumber ?? 1}:${measureIndex}:${voiceIndex}:${beatIndex}:note:${noteId}`;
                        const sourceTie = child(n, 'Tie', false);
                        const identity = { source: noteSource, id: outputId, tieStart: sourceTie ? flag(sourceTie.attrs.origin, sourceTie) : false, tieStop: sourceTie ? flag(sourceTie.attrs.destination, sourceTie) : false };
                        if (percussion) {
                            const raw = context?.sourceNotes?.get(noteId) ?? n, encodedArticulation = child(raw, 'InstrumentArticulation', false);
                            if (encodedArticulation?.text.trim() === '-1') {
                                const rawProperties = props(raw);
                                if (rawProperties.has('Element') || rawProperties.has('Variation')) refuse('percussion-identity', 'Conflicting indexed and element/variation percussion encodings.', raw.location);
                                const fact: MusicalNote = { ...identity, kind: 'unpitched', sounding: null, unpitched: { displayUnspecified: { source: encodedArticulation.location, reason: 'unassigned-source-articulation' } } };
                                noteTechniques(n, fact); drumArticulations.set(fact, -1);
                                findings.push({ disposition: 'inferred', code: 'unassigned-percussion-source', message: 'Source percussion articulation is explicitly unassigned (-1). No drum identity, sound or authored staff position is invented. Standard empty unpitched preserves the note; its consumer-default middle-line display is a projection, not evidence of source placement. Literal source pitch/editor fields remain auxiliary data.', location: noteSource, fact: { articulation: -1, properties: [...props(raw)].map(([name,property]) => ({name,fields:property.children.map(field=>({name:field.name,text:field.text,children:field.children.map(c=>({name:c.name,text:c.text}))}))})) } });
                                return fact;
                            }
                            const selected = sourcePercussion(context?.sourceNotes?.get(noteId) ?? n, context?.percussion ?? [], trackId, findings, descriptor.reference);
                            percussionUsed.set(selected.fact.id, selected.fact);
                            const fact = percussionNote(selected.fact, identity, item[1]);
                            noteTechniques(n, fact); drumArticulations.set(fact, selected.articulation);
                            return fact;
                        }
                        if (!np.has('String') && !np.has('Fret')) {
                            if (fretted) refuse('physical-pitch', 'Fretted source note lacks physical string/fret.', n.location);
                            const midiField = np.get('Midi'), concert = np.get('ConcertPitch'), transposed = np.get('TransposedPitch');
                            const tone = np.get('Tone'), octave = np.get('Octave');
                            let sounding: Pitch, written: Pitch;
                            if (convention === 'absent' && tone && octave) {
                                const soundingMidi = integer(value(octave, 'Number'), 0, 10, octave) * 12 + integer(value(tone, 'Step'), 0, 11, tone);
                                if (soundingMidi > 127 || soundingMidi - semitoneTranspose < 12 || soundingMidi - semitoneTranspose > 131) refuse('pitch-range', 'Source traditional pitch exceeds reference register.', n.location);
                                sounding = inferPitch(soundingMidi); written = inferPitch(soundingMidi - semitoneTranspose);
                                findings.push({ disposition: 'inferred', code: 'gp6-traditional-spelling', message: 'GP6 Octave/Tone fixes definite sounding pitch. Absent note spelling receives a labelled sharp reference spelling; written register follows explicit source display transposition.', location: n.location, fact: { octave: value(octave,'Number'), tone: value(tone,'Step') } });
                            } else {
                                if (!midiField || !concert || !transposed) refuse('pitch-corroboration', 'Traditional source note requires its complete authored pitch tuple or complete GP6 Octave/Tone.', n.location);
                                const soundingMidi = integer(value(midiField!, 'Number'), 0, 127, midiField!);
                                sounding = pitch(concert!, soundingMidi, convention === 'scientific-physical' ? 'scientific' : 'midi-octave');
                                written = pitch(transposed!, soundingMidi - semitoneTranspose);
                                if (tone || octave) {
                                    if (!tone || !octave || integer(value(octave!,'Number'),0,10,octave!)*12+integer(value(tone!,'Step'),0,11,tone!) !== soundingMidi) refuse('pitch-conflict', 'Source or reader Octave/Tone contradicts independently encoded MIDI.', n.location);
                                }
                            }
                            const diatonic = convention === 'absent' ? inferredDiatonic : (sounding.octave - written.octave) * 7 + 'CDEFGAB'.indexOf(sounding.step) - 'CDEFGAB'.indexOf(written.step) - octaves * 7;
                            if (diatonicTranspose !== undefined && diatonicTranspose !== diatonic) refuse('transpose-conflict', 'Authored spellings disagree on the diatonic instrument transposition.', n.location);
                            diatonicTranspose = diatonic;
                            const dead = np.has('Muted');
                            if (dead && !child(np.get('Muted')!, 'Enable', false)) refuse('technique','Muted requires its explicit enable marker.',n.location);
                            const fact: MusicalNote = { ...identity, kind: dead ? 'dead' : 'pitched', sounding: dead ? null : sounding, written, ...(dead ? {referenceSounding:sounding} : {}) };
                            noteTechniques(n, fact, midi => inferPitch(midi - semitoneTranspose));
                            return fact;
                        }
                        const stringProp = np.get('String'), fretProp = np.get('Fret');
                        if (!stringProp || !fretProp) refuse('physical-pitch', 'Explicit string and fret are required.', n.location);
                        const stringIndex = integer(value(stringProp!, 'String'), 0, tuning.length - 1, stringProp!);
                        const fret = integer(value(fretProp!, 'Fret'), 0, 999999, fretProp!);
                        const physicalMidi = tuning[stringIndex] + physicalOffset(stringIndex, fret), harmonic = harmonicKind(n);
                        const resultMidi = harmonicResult(n, physicalMidi, tuning[stringIndex] + openOffset(stringIndex), fret);
                        const soundingMidi = harmonic && resultMidi !== undefined ? resultMidi : physicalMidi;
                        const displayedMidi = harmonic === 'natural' && resultMidi !== undefined ? soundingMidi : physicalMidi;
                        const writtenMidi = displayedMidi - semitoneTranspose;
                        if (soundingMidi > 127 || writtenMidi < 12 || writtenMidi > 131) refuse('pitch-range', 'Pitch outside MIDI/reference range.', n.location);
                        const concert = np.get('ConcertPitch'), transposed = np.get('TransposedPitch');
                        let sounding: Pitch, written: Pitch;
                        if (convention === 'scientific-physical' && mode !== 'constructed') {
                            const sourceMidi = np.get('Midi');
                            if (!concert || !transposed || !sourceMidi) refuse('pitch-corroboration', 'GP8 admission requires both full pitch fields and Midi/Number.', n.location);
                            if (![physicalMidi, soundingMidi].includes(integer(value(sourceMidi!, 'Number'), 0, 127, sourceMidi!)))
                                refuse('pitch-conflict', 'Midi/Number differs from independently derived tuning plus fret.', sourceMidi!.location);
                            const sourcePhysical = pitch(concert!, physicalMidi, 'scientific');
                            sounding = harmonic ? inferPitch(soundingMidi) : sourcePhysical;
                            const displayField = child(transposed!, 'Pitch')!, displayValue = (integer(value(displayField, 'Octave'), 0, 10, displayField) + 1) * 12 + semitones[value(displayField, 'Step')] + ({ '': 0, '#': 1, b: -1, x: 2, bb: -2 } as Record<string, number>)[value(displayField, 'Accidental')];
                            if (![physicalMidi, displayedMidi].includes(displayValue)) refuse('harmonic-pitch-conflict', 'Display pitch contradicts physical or harmonic source roles.', transposed!.location);
                            const rawDisplay = harmonic && displayValue !== displayedMidi ? inferPitch(displayedMidi) : pitch(transposed!, displayedMidi, 'scientific');
                            if (!harmonic && (rawDisplay.step !== sounding.step || rawDisplay.alter !== sounding.alter))
                                refuse('pitch-conflict', 'Both encoded pitch spellings must corroborate the observed sounding-pitch convention.', n.location);
                            written = chromatic ? inferPitch(writtenMidi) : { ...rawDisplay, midi: writtenMidi, octave: rawDisplay.octave - octaves, origin: 'inferred' };
                            findings.push({ disposition: 'inferred', code: 'gp8-written-register', message: 'Observed raw pitch fields encode sounding register. Written register is calculated from corroborated physical/MIDI pitch and explicit source octave display transpose; raw fields stay untouched (gp8-scientific-physical/0).', location: { ...n.location, ...location, path: n.location.path, id: noteId }, fact: { rawConcert: sounding, rawTransposed: rawDisplay, transposeOctaves: octaves } });
                        } else {
                            if (concert) pitch(concert, physicalMidi);
                            sounding = harmonic ? inferPitch(soundingMidi) : concert ? pitch(concert, soundingMidi) : inferPitch(soundingMidi);
                            if (harmonic && transposed) {
                                const field = child(transposed, 'Pitch')!, valueMidi = integer(value(field, 'Octave'), 0, 10, field) * 12 + semitones[value(field, 'Step')] + ({ '': 0, '#': 1, b: -1, x: 2, bb: -2 } as Record<string, number>)[value(field, 'Accidental')];
                                if (![physicalMidi - semitoneTranspose, writtenMidi].includes(valueMidi)) refuse('harmonic-pitch-conflict', 'Display pitch contradicts physical or harmonic source roles.', transposed.location);
                                written = valueMidi === writtenMidi ? pitch(transposed, writtenMidi) : inferPitch(writtenMidi);
                            } else written = transposed ? pitch(transposed, writtenMidi) : inferPitch(writtenMidi);
                        }
                        if (chromatic && transposed && convention === 'midi-octave-written') {
                            const diatonic = (sounding.octave - written.octave) * 7 + 'CDEFGAB'.indexOf(sounding.step) - 'CDEFGAB'.indexOf(written.step) - octaves * 7;
                            if (diatonicTranspose !== undefined && diatonicTranspose !== diatonic) refuse('transpose-conflict', 'Source spelling contradicts instrument diatonic transposition.', n.location);
                            diatonicTranspose = diatonic;
                        }
                        const dead = np.has('Muted');
                        if (dead && !child(np.get('Muted')!, 'Enable', false)) refuse('technique', 'Muted property requires an explicit Enable marker.', n.location);
                        const tie = child(n, 'Tie', false);
                        if (tie && (!('origin' in tie.attrs) || !('destination' in tie.attrs))) refuse('tie', 'Both tie endpoint flags must be explicit.', tie.location);
                        if (!concert || !transposed) findings.push({ disposition: 'inferred', code: 'pitch-spelling', message: 'Absent spelling uses an explicit sharp-based reference spelling; physical pitch and encoded octave transposition are retained.', location: { ...n.location, ...location, path: n.location.path, id: noteId }, fact: { concertPresent: !!concert, transposedPresent: !!transposed } });
                        const fact: NoteFact = { source: { ...location, ...n.location, trackId, staff: context?.staffNumber ?? 1, measure: measureIndex + 1, voice: voiceIndex + 1, beat: beatIndex + 1 }, id: outputId,
                            string: tuning.length - stringIndex, fret, kind: dead ? 'dead' : 'pitched', sounding: dead ? null : sounding, written,
                            ...(dead ? { referenceSounding: sounding } : {}),
                            ...(np.has('HopoOrigin') ? { sourceHopoOrigin: !!child(np.get('HopoOrigin')!, 'Enable') } : {}),
                            ...(np.has('HopoDestination') ? { sourceHopoDestination: !!child(np.get('HopoDestination')!, 'Enable') } : {}),
                            tieStart: tie ? flag(tie.attrs.origin, tie) : false, tieStop: tie ? flag(tie.attrs.destination, tie) : false };
                        if (harmonic) {
                            if (dead) refuse('harmonic-dead', 'Simultaneous definite harmonic and dead-note marking needs source clarification.', n.location);
                            const base = harmonic === 'natural' ? inferPitch(tuning[stringIndex] + openOffset(stringIndex)) : concert ? pitch(concert, physicalMidi, convention === 'scientific-physical' ? 'scientific' : 'midi-octave') : inferPitch(physicalMidi);
                            fact.harmonic = { source: np.get('HarmonicType')!.location, type: harmonic, base,
                                pitchRole: harmonic === 'natural' ? resultMidi !== undefined ? 'sounding' : 'touching' : 'base',
                                ...(harmonic === 'natural' ? { touch: concert ? pitch(concert, physicalMidi, convention === 'scientific-physical' ? 'scientific' : 'midi-octave') : inferPitch(physicalMidi) } : {}),
                                ...(resultMidi !== undefined ? { result: sounding } : {}) };
                            if (resultMidi === undefined) fact.sounding = null;
                            findings.push({ disposition: resultMidi !== undefined ? 'inferred' : 'preserved', code: 'harmonic-roles', message: 'Harmonic result is derived only from an established source node/partial rule, separately from literal physical pitch tuples and absent artificial touch pitch. No borrowed default supplies a missing node.', location: fact.source, fact: { type: harmonic, definiteResult: resultMidi !== undefined, resultOrigin: resultMidi === undefined ? 'unestablished' : 'source-node-partial/1' } });
                        }
                        readerPhysicalFrets.set(fact, physicalOffset(stringIndex, fret) - (capo?.fret ?? 0));
                        const slide = noteTechniques(n, fact, midi => inferPitch(midi - octaves * 12)); if (slide) slideOrigins.set(fact, slide);
                        return fact;
                    });
                    if (fretted && new Set(sourceNotes.map(n => n.string)).size !== sourceNotes.length) refuse('chord-string', 'One chord cannot occupy the same string twice.', location);
                    const event: Event = { source: location, voiceId: String(voiceIndex + 1), staff: 1, id: `gp:${trackId}:${context?.staffNumber ?? 1}:${measureIndex}:${voiceIndex}:${beatIndex}:beat:${beatId}`, start: position, duration, type: item[1], dots, ...(tuplet ? { tuplet } : {}), notes: sourceNotes,
                        ...(child(be, 'Dynamic', false) ? { dynamic: value(be, 'Dynamic') } : {}),
                        fullMeasureRest: !noteIds.length && ids.length === 1 && equal(duration, c.duration), ...(child(be, 'FreeText', false) ? { text: value(be, 'FreeText') } : {}) };
                    if (grace) {
                        const remaining = ids.slice(beatIndex + 1), hostId = remaining.find(id => !child(lookup(beats,id,v),'GraceNotes',false));
                        if (!hostId) refuse('grace-host', 'Grace group requires a following ordinary source host.', grace.location);
                        let groupStart=beatIndex; while(groupStart>0 && child(lookup(beats,ids[groupStart-1],v),'GraceNotes',false)) groupStart--;
                        event.grace={source:grace.location,before:grace.text.trim()==='BeforeBeat',slash:grace.text.trim()==='BeforeBeat',index:beatIndex-groupStart,hostId:`gp:${trackId}:${context?.staffNumber ?? 1}:${measureIndex}:${voiceIndex}:${ids.indexOf(hostId!)}:beat:${hostId}`}; event.writtenDuration=writtenDuration;
                    }
                    beatTechniques(be, event); beatStructure(be,event);
                    for (const note of sourceNotes) expectedOccurrences.push({ note, event, rhythmId: rhythmRef });
                    position = add(position, duration);
                    return event;
                });
            });
            const totals = recoveredVoices.filter(v => v.length).map(v => v.reduce((s, e) => add(s, e.duration), q(0)));
            if (!totals.length && (c.pickup || c.free)) refuse('empty-measure', 'An entirely empty pickup or free-time staff needs an independently established exact master-bar span.', b.location);
            const actualDuration = totals[0] ?? c.duration;
            if (!totals.every(t => equal(t, actualDuration)) || !c.free && c.pickup && actualDuration.n * c.duration.d >= c.duration.n * actualDuration.d)
                refuse('measure-duration', 'Active voices must establish one exact source measure extent; an explicit pickup must be shorter than its meter.', b.location);
            const irregular = !equal(actualDuration, c.duration);
            if (irregular && !c.pickup && !c.free) findings.push({ disposition: 'inferred', code: 'source-irregular-measure', message: 'All active source voices establish this exact underfull or overfull extent. The literal meter and every written value remain unchanged; ordinary MusicXML marks an implicit measure without adding notes/rests or calling an interior bar a pickup.', location: b.location, fact: { declaredMeter: c.time, declaredSpan: c.duration, writtenExtent: actualDuration } });
            return { source: { ...b.location, trackId, staff: context?.staffNumber ?? 1, measure: measureIndex + 1 }, time: c.time, key: c.key, clef: outputClef,
                pickup: c.pickup, ...(irregular ? { implicit: true } : {}), duration: actualDuration, voices: recoveredVoices, repeatStart: c.start, repeatEnd: c.count };
        });
        // Validate source ties before letting alphaTab infer or repair any link.
        const pending = new Map<string, { note: MusicalNote; end: Rational }>();
        let absolute = q(0);
        for (const m of measures) {
            for (let vi = 0; vi < m.voices.length; vi++) for (const e of m.voices[vi]) {
                const start = add(absolute, e.start);
                for (const n of e.notes) {
                    const key = `${vi}:${n.string ?? (n.kind === 'unpitched' ? n.unpitched.instrumentId : n.written.midi)}`, previous = pending.get(key);
                    if (n.tieStop && (!previous || previous.note.kind !== n.kind || !equal(previous.end, start) || previous.note.sounding?.midi !== n.sounding?.midi || previous.note.written?.midi !== n.written?.midi || previous.note.fret !== n.fret || previous.note.written?.step !== n.written?.step || previous.note.written?.alter !== n.written?.alter))
                        refuse('tie-conflict', 'Tie destination has no contiguous, identical explicit origin; no source pitch/fret repair is permitted.', n.source);
                    if (!n.tieStop && previous) refuse('tie-conflict', 'Explicit tie origin reaches an ordinary attack.', n.source);
                    pending.delete(key);
                    if (n.tieStart) pending.set(key, { note: n, end: add(start, e.duration) });
                }
            }
            absolute = add(absolute, m.duration);
        }
        for (const m of measures) for (const v of m.voices) for (const e of v) {
            if (e.dynamic && !['PPP', 'PP', 'P', 'MP', 'MF', 'F', 'FF', 'FFF'].includes(e.dynamic)) refuse('dynamic', 'Unknown dynamic value.', e.source);
            for (const n of e.notes) if (n.kind === 'dead') findings.push({ disposition: 'omitted', code: 'dead-playback-timbre', message: 'Dead note exports as standard unpitched x notehead with dead-note technical meaning and hidden physical guidance. Original reference pitch is retained; playback timbre is not assigned or verified.', location: n.source, fact: { physicalReference: n.referenceSounding } });
        }
        if (pending.size) refuse('tie-conflict', 'Explicit tie origin has no destination.', [...pending.values()][0].note.source);
        const part: Part = { source: t.location, id: trackId, name: value(t, 'Name'), ...(child(t, 'ShortName', false) ? { abbreviation: value(t, 'ShortName') } : {}), instrument: instrument.attrs.ref,
            midiProgram: program, ...(tuning.length ? { tuning } : {}), ...(capo ? { capo } : {}), transposeOctaves: octaves, ...(chromatic ? { transpose: { diatonic: diatonicTranspose ?? inferredDiatonic, chromatic, octaveChange: octaves } } : {}), ...(percussion ? { staves: [{ source: t.location, number: 1, kind: 'percussion', clef: 'PERC', lines: 5 }], percussionInstruments: [...percussionUsed.values()].map(percussionInstrument) } : {}), measures };
        transposeWrittenKeys(part, findings);
        if (partialCapo) partialCapoInstruction(part, partialCapo, findings);
        for (let mi=0;mi<part.measures.length;mi++) masterStructure(masters[mi],part.measures[mi],part,mi,relations);
        beatRelations(part,beats,relations); trackLyrics(t,part,(context?.staffNumber ?? 1)===1);
        if (fretted) { gpifHopo(part as FrettedPart, relations, findings); connectSlides(part as FrettedPart, slideOrigins, relations); }
        if (fretted) { connectSustainMarks(part as FrettedPart, relations); numberHopo(part as FrettedPart); }
        return part;
    });
    if (parts.some(p => !equal(p.measures[0].duration, parts[0].measures[0].duration)))
        refuse('pickup-span', 'All tracks must share one exact master-bar pickup span; no implicit padding.', root.location);
    // Every source musical definition must be reachable; no successful hidden dropping.
    for (const [name, map] of Object.entries({ bars, voices, beats, notes, rhythms })) {
        for (const [id, e] of map) if (!used[name as keyof typeof used].has(id)) refuse('unreferenced', `Unreferenced ${name} source object ${id}.`, e.location);
    }
    const tempos: Tempo[] = [], tempoChanges: { tempo: Tempo; linear: boolean; source: Location }[] = [];
    for (const a of child(child(root, 'MasterTrack')!, 'Automations', false)?.children ?? []) {
        if (value(a, 'Type') !== 'Tempo') refuse('automation', 'Unreviewed master automation type.', a.location);
        const linear = flag(value(a, 'Linear'), a);
        const measure = integer(value(a, 'Bar'), 0, masters.length - 1, a);
        const position = decimal(value(a, 'Position'));
        if (position.n >= position.d) refuse('tempo-position', 'Tempo ratio position must be in [0,1).', a.location);
        const partsValue = value(a, 'Value').split(/\s+/);
        if (partsValue.length !== 2) refuse('tempo-reference', 'Original rate plus explicit tempo unit/reference are required.', a.location);
        const rate = decimal(partsValue[0]), reference = integer(partsValue[1], 1, 5, a);
        if (rate.n <= 0 || rate.n > 1000 * rate.d) refuse('tempo-rate', 'Tempo rate outside profile.', a.location);
        const ref = ([null, ['eighth', 0, 0.5], ['quarter', 0, 1], ['quarter', 1, 1.5], ['half', 0, 2], ['half', 1, 3]] as const)[reference]!;
        const actual = parts[0].measures[measure].duration;
        tempos.push({ source: a.location, measure, position: mul(position, actual), rate: partsValue[0], reference,
            unit: ref[0], dots: ref[1], quarterRate: rate.n / rate.d * ref[2], visible: flag(value(a, 'Visible'), a) });
        tempoChanges.push({ tempo: tempos.at(-1)!, linear, source: a.location });
        findings.push({ disposition: 'preserved', code: 'tempo-unit', message: 'Original tempo rate, unit, visibility and exact position preserved.', location: a.location, fact: { rate: partsValue[0], reference, ratioPosition: position, visible: value(a, 'Visible') } });
        const text = child(a, 'Text', false);
        if (text?.text.trim()) {
            (parts[0].measures[measure].directions ??= []).push({ source: text.location, kind: 'words', staff: 1, position: mul(position, actual), text: text.text, printObject: flag(value(a, 'Visible'), a) });
            findings.push({ disposition: 'preserved', code: 'tempo-text', message: 'Authored tempo words retain exact position and visibility as standard text.', location: text.location, fact: text.text });
        }
    }
    tempoChanges.sort((a,b) => a.tempo.measure-b.tempo.measure || a.tempo.position.n*b.tempo.position.d-b.tempo.position.n*a.tempo.position.d);
    for (const [index, point] of tempoChanges.entries()) {
        const next = tempoChanges[index + 1];
        if (next && point.tempo.measure === next.tempo.measure && equal(point.tempo.position, next.tempo.position)) refuse('tempo-conflict', 'Two tempo points cannot own the same exact source clock.', next.source);
        if (!point.linear) continue;
        if (!next) {
            findings.push({ disposition: 'preserved', code: 'linear-tempo', message: 'A terminal source gradual-tempo flag has no target tempo; its literal instruction is retained without inventing an endpoint or rate.', location: point.source, fact: { linear: true, terminal: true } });
            (parts[0].measures[point.tempo.measure].directions ??= []).push({ source: point.source, kind: 'words', staff: 1, position: point.tempo.position, text: 'gradual tempo change', printObject: point.tempo.visible });
            continue;
        }
        const text = next.tempo.quarterRate > point.tempo.quarterRate ? 'accel.' : next.tempo.quarterRate < point.tempo.quarterRate ? 'rall.' : 'steady tempo';
        if ((context?.staffNumber ?? 1) === 1) relations.push({ source: point.source, id: `gp-tempo:${parts[0].id}:${index}`, kind: 'text-line', line: 'dashes', beginText: text, printObject: point.tempo.visible,
            start: { partId: parts[0].id, measure: point.tempo.measure, position: point.tempo.position, staff: 1 },
            end: { partId: parts[0].id, measure: next.tempo.measure, position: next.tempo.position, staff: 1 } });
        findings.push({ disposition: 'inferred', code: 'linear-tempo', message: 'Source linear interpolation connects this exact tempo point to the next. Its direction is derived from the two explicit rates and preserved as a standard gradual-tempo instruction; continuous audio interpolation is not synthesized.', location: point.source, fact: { linear: true, start: point.tempo, end: next.tempo, instruction: text } });
    }
    if (!tempos.length) findings.push({ disposition: 'omitted', code: 'no-tempo', message: 'No encoded tempo exists; no upstream playback default is printed.', location: root.location });
    freeze(tempos);
    const occurrenceKey = (location: Location, noteId: string) => `${location.trackId}:${location.measure}:${location.voice}:${location.beat}:${noteId}`;
    const expectedByKey = new Map(expectedOccurrences.map(e => [occurrenceKey(e.note.source, e.note.source.id!), e]));
    const capturedKeys = new Set<string>();
    const parser = new GpifParser(), captures: OccurrenceCapture[] = [], normalized: Note[] = [];
    const capturedExpected: typeof expectedOccurrences = [];
    // Avoid score-controlled or accidental upstream diagnostic dumps.
    Logger.logLevel = LogLevel.None;
    parser.onNoteOccurrence = (s, note) => {
        const key = `${s.trackId}:${s.measure + 1}:${s.voice + 1}:${s.beat + 1}:${s.noteId}`;
        const expected = expectedByKey.get(key)!;
        if (capturedKeys.has(key)) refuse('reader-identity', 'Duplicate borrowed source occurrence.', root.location);
        capturedKeys.add(key);
        if (!expected || s.noteId !== expected.note.source.id || s.beatId !== expected.event.source.id || s.rhythmId !== expected.rhythmId || s.trackId !== expected.note.source.trackId || s.measure + 1 !== expected.note.source.measure || s.voice + 1 !== expected.note.source.voice || s.beat + 1 !== expected.note.source.beat)
            refuse('reader-identity', 'Borrowed reader occurrence identity differs from the complete source traversal.', root.location);
        const commonCapture = { source: expected.note.source, rhythmId: s.rhythmId, noteId: s.noteId };
        if (expected.note.kind === 'unpitched') captures.push({ ...commonCapture, kind: 'unpitched', before: freeze({ articulation: note.percussionArticulation, tieDestination: note.isTieDestination }), after: { articulation: 0, tieDestination: false, playbackTicks: 0 } });
        else if (expected.note.string === undefined) captures.push({ ...commonCapture, kind: 'pitched', before: freeze({ soundingMidi: (expected.note.sounding ?? expected.note.referenceSounding)!.midi, writtenMidi: expected.note.written.midi, tieDestination: note.isTieDestination }), after: { soundingMidi: 0, tieDestination: false, playbackTicks: 0 } });
        else captures.push({ ...commonCapture, before: freeze({ fret: note.fret, string: note.string, tieDestination: note.isTieDestination }), after: { fret: 0, string: 0, tieDestination: false, soundingMidi: 0, playbackTicks: 0 } });
        const projectedFret = readerPhysicalFrets.get(expected.note);
        if (projectedFret !== undefined && projectedFret !== note.fret) {
            findings.push({ disposition: 'preserved', code: 'partial-capo-reader-alias', message: 'After exact raw occurrence capture, the borrowed reader receives the independently established effective open-string fret. Original source tab fret remains unchanged in the output model.', location: expected.note.source, fact: { sourceFret: note.fret, readerFret: projectedFret } });
            note.fret = projectedFret;
        }
        normalized.push(note); capturedExpected.push(expected);
    };
    try { parser.parseXml(xml, new Settings()); } catch (e) {
        if (e instanceof Error && 'code' in e) throw e;
        refuse('reader', 'Borrowed GPIF reader failed within the admitted profile.', root.location);
    }
    if (captures.length !== expectedOccurrences.length || parser.score.tracks.length !== parts.length)
        refuse('reader-coverage', 'Borrowed reader did not recover the complete requested source scope.', root.location);
    for (let i = 0; i < captures.length; i++) {
        const n = normalized[i], expected = capturedExpected[i];
        const capture = captures[i], sourceNote = expected.note;
        if(capture.kind==='dead')refuse('reader-reconciliation','Unexpected binary-only dead capture in GPIF recovery.',capture.source);
        if (capture.kind === 'unpitched') {
            capture.after = { articulation: n.percussionArticulation, tieDestination: n.isTieDestination, playbackTicks: n.beat.playbackDuration };
            if (n.percussionArticulation !== drumArticulations.get(sourceNote) || n.isTieDestination !== sourceNote.tieStop) refuse('reader-reconciliation', 'Borrowed percussion identity or tie differs from immutable source.', sourceNote.source);
        } else if (capture.kind === 'pitched') {
            capture.after = { soundingMidi: n.realValue, tieDestination: n.isTieDestination, playbackTicks: n.beat.playbackDuration };
            if (n.realValue !== (sourceNote.sounding ?? sourceNote.referenceSounding)?.midi || n.isTieDestination !== sourceNote.tieStop) refuse('reader-reconciliation', 'Borrowed traditional pitch or tie differs from authored source.', sourceNote.source);
        } else {
            capture.after = { fret: n.fret, string: n.string, tieDestination: n.isTieDestination, soundingMidi: n.realValue, playbackTicks: n.beat.playbackDuration };
            const part = parts.find(p => p.id === sourceNote.source.trackId)!, tuning = part.tuning!;
            const expectedPhysical = tuning[tuning.length - sourceNote.string!] + (part.capo?.fret ?? 0) + (readerPhysicalFrets.get(sourceNote) ?? sourceNote.fret!);
            if ((sourceNote.harmonic ? n.realValueWithoutHarmonic !== expectedPhysical : n.realValue !== (sourceNote.sounding ?? sourceNote.referenceSounding)!.midi) || n.fret !== (readerPhysicalFrets.get(sourceNote) ?? sourceNote.fret) || n.string !== tuning.length - sourceNote.string! + 1 || n.isTieDestination !== sourceNote.tieStop || n.isDead !== (sourceNote.kind === 'dead')) refuse('reader-reconciliation', 'Normalized pitch, physical choice or tie disagrees with immutable source facts.', sourceNote.source);
        }
    }
    for (let pi = 0; pi < parts.length; pi++) {
        const track = parser.score.tracks[pi];
        if (track.staves.length !== 1 || track.staves[0].bars.length !== masters.length) refuse('reader-scope', 'Borrowed staff/measure scope differs.', parts[pi].source);
        for (let mi = 0; mi < masters.length; mi++) {
            const bar = track.staves[0].bars[mi], measure = parts[pi].measures[mi];
            if (bar.voices.length !== measure.voices.length) refuse('reader-scope', 'Borrowed voice scope differs.', measure.source);
            for (let vi = 0; vi < measure.voices.length; vi++) {
                const voice = bar.voices[vi];
                if (!measure.voices[vi].length && voice.beats.every(beat => beat.isEmpty && !beat.notes.length)) continue;
                if (voice.beats.length !== measure.voices[vi].length) refuse('reader-scope', 'Borrowed beat scope differs.', measure.source);
                for (let bi = 0; bi < voice.beats.length; bi++) {
                    const be = voice.beats[bi], source = measure.voices[vi][bi];
                    if (source.grace && (be.dots !== source.dots || be.duration !== values[Object.keys(values).find(k => values[k][1] === source.type)!][0])) findings.push({ disposition:'preserved',code:'grace-written-rhythm',message:'Borrowed reader normalized grace written duration; output retains the independently encoded source rhythm and zero ordinary elapsed clock.',location:source.source });
                    if (be.notes.length !== source.notes.length || !source.grace && (be.dots !== source.dots || be.duration !== (values[Object.keys(values).find(k => values[k][1] === source.type)!][0])))
                        refuse('reader-rhythm', 'Borrowed written rhythm/chord disagrees with source.', source.source);
                }
            }
        }
    }
    for (const part of parts) {
        const descriptor = context?.track ?? arrangementTrack(tracks.get(part.id)!);
        if (!descriptor.fretted) {
            if (part.tuning) findings.push({ disposition: 'preserved', code: 'editor-pitch-grid', message: 'Encoded string/fret grid corroborates source pitch but the declared traditional instrument does not acquire guitar tablature or a performing-hand assignment. Raw editor coordinates remain in source and occurrence capture.', location: part.source });
            delete part.tuning; delete part.capo;
            for (const measure of part.measures) for (const voice of measure.voices) for (const event of voice) for (const note of event.notes) { delete note.string; delete note.fret; }
        }
    }
    findings.push({ disposition: 'preserved', code: 'source-reconciled', message: 'Complete source definitions, cloned occurrence IDs and normalized pitch/voice/rhythm/tie scope reconciled; exact source clocks replace truncated playback ticks.', location: root.location, fact: { noteOccurrences: captures.length, events: eventCount } });
    return { score: freeze({ title: value(child(root, 'Score')!, 'Title'), ...scoreTexts(child(root,'Score')!,parts[0].id), parts, tempos, ...(relations.length ? { relations } : {}) }), occurrences: freeze(captures) };
}

import { captureNative, nativeAdapter, nativeLimits, type NativeHost } from './capture-core.js';
import { inventoryViews, type SourceViewInfo } from './views.js';
import { nativeInventory } from './read.js';
import { boundJson } from './budget.js';
import { freeze, Refusal } from '../../core/report.js';
import type { MuseScoreReport } from './convert-core.js';

export interface MuseScoreInspectionSuccess { ok: true; views: SourceViewInfo[]; report: MuseScoreReport }
export interface MuseScoreInspectionFailure { ok: false; views?: never; report: MuseScoreReport }
export type MuseScoreInspectionResult = MuseScoreInspectionSuccess | MuseScoreInspectionFailure;
/** Descriptive discovery checks the whole source container/identity graph, never admits its music. */
export function inspectNative(bytes: Uint8Array, host: NativeHost): MuseScoreInspectionResult {
    if (bytes.length > nativeLimits.inputBytes) throw new RangeError('Native input exceeds 32 MiB before digest or decoding.');
    const report: MuseScoreReport = { schema: 'score-converter-report/0', inputSha256: host.sha256(bytes), adapter: nativeAdapter,
        profile: 'musescore-source-view-inventory/0', requestedScope: 'all-parts', findings: [], metrics: { inputBytes: bytes.length, outputBytes: 0, nodeCount: 0, eventCount: 0 } };
    try {
        const capture = captureNative(bytes, host), inventory = inventoryViews(capture), views = inventory.entries.map(entry => entry.info);
        report.nativeVersion = capture.nativeVersion; report.producerVersion = capture.producerVersion; report.producerRevision = capture.producerRevision;
        report.constructs = nativeInventory(capture.root); report.metrics.nodeCount = report.constructs.reduce((n, construct) => n + construct.count, 0);
        report.findings.push({ disposition: 'preserved', code: 'native-view-inventory', message: 'File-scoped source view identities and descriptive links are discovered. Musical constructs, relationships and performer fidelity require independent selected-view conversion.', location: capture.root.location, fact: { views: views.length, musicalAdmission: 'not-checked' } });
        const unavailable = views.flatMap(view => view.parts.flatMap(part => part.labels.filter(label => label.derivation === 'unavailable-markup')));
        if (unavailable.length) report.findings.push({ disposition: 'omitted', code: 'native-view-label-unavailable', message: 'Unqualified descriptive label markup remains source-bound; discovery does not guess its text/glyph meaning.', location: unavailable[0].source, fact: { count: unavailable.length } });
        boundJson(report, nativeLimits.reportBytes, 'native-report-budget');
        const result = { ok: true as const, views, report };
        // Inventory has the report-sized public surface, not a score/capture-sized exemption.
        boundJson(result, nativeLimits.reportBytes, 'native-view-inventory-budget');
        return freeze(result);
    } catch (error) {
        const refusal = error instanceof Refusal ? error : new Refusal('native-invalid', 'Native input failed bounded view discovery.');
        delete report.constructs;
        report.findings = [{ disposition: 'blocking', code: refusal.code, message: refusal.message, location: refusal.location }];
        return freeze({ ok: false as const, report });
    }
}

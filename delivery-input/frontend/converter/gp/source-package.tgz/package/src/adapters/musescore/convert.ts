import { nodeHost } from './capture.js';
import { convertNative, type MuseScoreResult } from './convert-core.js';
import type { SourceViewSelection } from './views.js';
export type * from './convert-core.js';
/** Internal synchronous Node worker entry. Public conversion runs in a bounded worker. */
export function convertMuseScoreInWorker(bytes: Uint8Array, options: { sourceView?: SourceViewSelection } = {}): MuseScoreResult {
    return convertNative(bytes, nodeHost, options);
}

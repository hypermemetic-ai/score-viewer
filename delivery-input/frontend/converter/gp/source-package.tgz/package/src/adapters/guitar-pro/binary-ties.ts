import type {MusicalEvent,MusicalNote,MusicalPart,MusicalRelation,RelationEndpoint} from '../../core/model.js';
import {add,equal,mul,q,type Rational} from '../../core/rational.js';
import {refuse,type Finding} from '../../core/report.js';

/** Destination-only GP ties follow the prior source note on the same string, not the prior chord. */
export function binaryTies(part:MusicalPart,durations:Map<MusicalNote,Rational>,relations:MusicalRelation[],findings:Finding[]):void {
    for(let voice=0;voice<Math.max(...part.measures.map(measure=>measure.voices.length));voice++) {
        const previous=new Map<number,{note:MusicalNote;event:MusicalEvent;measure:number;release:Rational}>();
        let clock=q(0);
        const endpoint=(event:MusicalEvent,note:MusicalNote,measure:number):RelationEndpoint=>({partId:part.id,measure,position:event.start,staff:event.staff??1,voiceId:event.voiceId??String(voice+1),eventId:event.id,noteId:note.id});
        for(let measure=0;measure<part.measures.length;measure++) {
            for(const event of part.measures[measure].voices[voice]??[])if(!event.grace)for(const note of event.notes) {
                if(note.string===undefined)continue;
                const onset=add(clock,event.start),prior=previous.get(note.string);
                if(note.tieStop) {
                    if(!prior||prior.note.kind!=='pitched'||note.kind!=='pitched'||prior.note.fret!==note.fret||prior.note.sounding?.midi!==note.sounding?.midi)refuse('tie-conflict','Source tie needs a matching prior same-string pitched origin.',note.source);
                    const origin=prior!.note,id=`binary-tie:${note.id}`,gap=add(onset,mul(prior!.release,q(-1)));
                    origin.tieStart=true;
                    (origin.tieNotations??=[]).push({type:'start',relationId:id});(note.tieNotations??=[]).push({type:'stop',relationId:id});
                    relations.push({kind:'tie',source:note.source,id,start:endpoint(prior!.event,origin,prior!.measure),end:endpoint(event,note,measure),...(!equal(gap,q(0))?{clockGap:gap}:{})});
                    if(!equal(gap,q(0))) {
                        origin.tieSound={...origin.tieSound,start:false,reason:'source-clock-gap'};note.tieSound={...note.tieSound,stop:false,reason:'source-clock-gap'};
                        findings.push({disposition:'preserved',code:'binary-gapped-tie',message:'The encoded tie follows the preceding source note on its string. Exact written durations and the visual tied arc are retained; no sounding tie or sustained duration is fabricated across the calculated clock gap.',location:note.source,fact:{origin:origin.source,gap}});
                    } else findings.push({disposition:'inferred',code:'binary-tie-origin',message:'Destination-only tie resolves to the preceding same-string source note at its exact release.',location:note.source,fact:{origin:origin.source}});
                }
                previous.set(note.string,{note,event,measure,release:add(onset,durations.get(note)??event.duration)});
            }
            clock=add(clock,part.measures[measure].duration);
        }
    }
}

import type { StaffFact, TextFontSize } from '../../core/model.js';
import type { Location } from '../../core/report.js';
import type { SourceElement as Element } from '../../core/source-xml.js';

/** The reader supplies the active source staff at this owner's exact clock. */
export interface NativeTextScaleContext {
    scope: 'staff' | 'score';
    source: Location;
    staffSize?: StaffFact['staffSize'];
    /** Modern line captions cancel their temporary DEFAULT Text scaling when false. */
    lineSpatiumDependent?: NonNullable<TextFontSize['pointSize']>['spatiumDependent'];
}
type Dependency = NonNullable<TextFontSize['pointSize']>['spatiumDependent'];
const plain = (field: Element): boolean => !field.children.length && !Object.keys(field.attrs).length;
const positive = (text: string): number | undefined => /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(text.trim()) && Number(text) > 0 && Number(text) <= 10000 ? Number(text) : undefined;

// Property facts shared by the examined legacy resources and modern registries.
// No default face or point-size request is supplied by this table.
const unscaled = new Set(['title', 'subTitle', 'composer', 'lyricist', 'translator', 'partInstrument', 'metronome', 'frame', 'header', 'footer']);
const scaled = new Set(['default', 'staff', 'system', 'expression', 'dynamics', 'tempo', 'rehearsalMark', 'lyricsOdd', 'lyricsEven', 'fingering', 'lhGuitarFingering', 'rhGuitarFingering', 'stringNumber', 'longInstrument', 'shortInstrument', 'chordSymbolA', 'chordSymbolB', 'romanNumeral', 'nashvilleNumber', 'repeatLeft', 'repeatRight', 'instrumentChange', 'sticking', 'tuplet', 'textLine', 'hairpin', 'pedal', 'ottava', 'volta', 'letRing', 'palmMute', 'glissando', 'bend', ...Array.from({ length: 12 }, (_, i) => `user${i + 1}`)]);
export function nativeTextSizeDependency(prefix: string | undefined, owner: Element): Dependency | undefined {
    return prefix && (scaled.has(prefix) || unscaled.has(prefix)) ? { source: owner.location, value: scaled.has(prefix), origin: 'native-default' } : undefined;
}

export type NativeStaffSpace = Omit<NonNullable<NonNullable<TextFontSize['pointSize']>['scaling']>, 'lineSpatiumDependent'>;

/** Effective source staff-space units shared by text and glyph projection. */
export function createNativeStaffSpaceResolver(scopes: readonly Element[], nativeVersion?: string, use?: (field: Element) => unknown) {
    const version = Number(nativeVersion), fields = scopes.flatMap(scope => scope.children);
    const spatium = fields.filter(field => field.name === 'Spatium' || version >= 4 && field.name === 'spatium').at(-1);
    const selector = fields.filter(field => field.name === 'defaultsVersion').at(-1);
    const pre = fields.filter(field => field.name === 'usePre_3_6_defaults').at(-1);
    return (owner: Element, context?: NativeTextScaleContext): NativeStaffSpace | undefined => {
        if (!context || !(version >= 3 && version < 5)) return undefined;
        const modern = version >= 4.7, legacy = version < 3.02 || ['114', '206', '301'].includes(selector?.text.trim() ?? '');
        if (!spatium && (selector && (!plain(selector) || !['114', '206', '301', '302', '400', '410', '420', '430', '440', '450', '460', '470'].includes(selector.text.trim())) || pre && (!plain(pre) || !['0', '1'].includes(pre.text.trim())))) return undefined;
        const millimeters = spatium ? plain(spatium) ? positive(spatium.text) : undefined
            : legacy ? selector ? 1.76389 : 127 / 72 : modern ? 1.75 : 24.8 * 25.4 / 360;
        if (millimeters === undefined) return undefined;
        const referenceSpatiumMillimeters = modern ? 1.75 : 127 / 72;
        const factor = context.scope === 'score' ? 1 : (context.staffSize?.percent ?? 100) / 100;
        if (!Number.isFinite(factor) || factor <= 0 || factor > 4) return undefined;
        if (spatium) use?.(spatium);
        return {
            nativeVersion: nativeVersion!,
            scoreSpatium: { source: spatium?.location ?? owner.location, millimeters, origin: spatium ? 'source-style' : 'native-default', ...(spatium ? { rawValue: spatium.text } : {}) },
            referenceSpatiumMillimeters,
            staff: { source: context.scope === 'score' ? context.source : context.staffSize?.source ?? context.source, factor, origin: context.scope === 'score' ? 'score-scope' : context.staffSize ? 'source-staff' : 'native-default' },
        };
    };
}

/** Native font point size is a unit conversion, not a font-metric/layout claim. */
export function createNativeTextSizeProjector(scopes: readonly Element[], nativeVersion?: string, use?: (field: Element) => unknown) {
    const space = createNativeStaffSpaceResolver(scopes, nativeVersion, use);
    return (owner: Element, size: TextFontSize, dependency: Dependency | undefined, context?: NativeTextScaleContext): TextFontSize['pointSize'] => {
        if (!context || !dependency || size.value === undefined || !(Number(nativeVersion) >= 3 && Number(nativeVersion) < 5)) return undefined;
        if (!dependency.value && !context.lineSpatiumDependent) return { value: size.value, origin: 'source-context', context: 'musescore-source-scaled-text', spatiumDependent: dependency };
        // Music glyphs have a separate family/role-specific size law.
        if (owner.name === 'Dynamic' || owner.children.some(field => field.name === 'text' && (/<sym\b/.test(field.text) || field.children.some(n => n.name === 'sym')))) return undefined;
        const scaling = space(owner, context);
        if (!scaling) return undefined;
        const { scoreSpatium: { millimeters }, referenceSpatiumMillimeters, staff: { factor } } = scaling;
        const value = (dependency.value ? size.value * millimeters / referenceSpatiumMillimeters * factor : size.value)
            / (context.lineSpatiumDependent?.value === false ? millimeters / referenceSpatiumMillimeters * factor : 1);
        if (!Number.isFinite(value) || value <= 0 || value > 10000) return undefined;
        return { value, origin: 'source-context', context: 'musescore-source-scaled-text', spatiumDependent: dependency,
            scaling: { ...scaling, ...(context.lineSpatiumDependent ? { lineSpatiumDependent: context.lineSpatiumDependent } : {}) } };
    };
}

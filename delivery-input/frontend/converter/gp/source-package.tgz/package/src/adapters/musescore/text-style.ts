import { createNativeMusicTextSize } from './music-text-size.js';
import type { TextRun } from '../../core/model.js';
import { createNativeInlinePresentation } from './inline-presentation.js';
import { createNativeTextSizeProjector, nativeTextSizeDependency, type NativeTextScaleContext } from './text-size.js';
import type { SourceElement as Element } from '../../core/source-xml.js';
import { applyNativeTextPresentation, type NativeTextPresentation, type NativeTextPresentationContext } from './presentation.js';

// Serialized vocabulary and style/property binding facts, independently checked
// against the native 3/4 registries. No built-in font/default values are copied.
const styles: readonly (readonly [string, string, string])[] = [
    ['Default', 'default', 'default'], ['Title', 'title', 'title'], ['Subtitle', 'subtitle', 'subTitle'],
    ['Composer', 'composer', 'composer'], ['Lyricist', 'poet', 'lyricist'], ['Translator', 'translator', 'translator'],
    ['Frame', 'frame', 'frame'], ['Instrument Name (Part)', 'instrument_excerpt', 'partInstrument'],
    ['Instrument Name (Long)', 'instrument_long', 'longInstrument'], ['Instrument Name (Short)', 'instrument_short', 'shortInstrument'],
    ['Instrument Change', 'instrument_change', 'instrumentChange'], ['Header', 'header', 'header'], ['Footer', 'footer', 'footer'],
    ['Measure Number', 'measure_number', 'measureNumber'], ['Multimeasure Rest Range', 'mmrest_range', 'mmRestRange'],
    ['Tempo', 'tempo', 'tempo'], ['Metronome', 'metronome', 'metronome'],
    ['Repeat Text Left', 'repeat_left', 'repeatLeft'], ['Repeat Text Right', 'repeat_right', 'repeatRight'],
    ['Rehearsal Mark', 'rehearsal_mark', 'rehearsalMark'], ['System', 'system', 'system'], ['Staff', 'staff', 'staff'],
    ['Expression', 'expression', 'expression'], ['Dynamics', 'dynamics', 'dynamics'],
    ['Lyrics Odd Lines', 'lyrics_odd', 'lyricsOdd'], ['Lyrics Even Lines', 'lyrics_even', 'lyricsEven'],
    ['Chord Symbol', 'harmony_a', 'chordSymbolA'], ['Chord Symbol (Alternate)', 'harmony_b', 'chordSymbolB'],
    ['Roman Numeral Analysis', 'harmony_roman', 'romanNumeral'], ['Nashville Number', 'harmony_nashville', 'nashvilleNumber'],
    ['Tuplet', 'tuplet', 'tuplet'], ['Sticking', 'sticking', 'sticking'], ['Fingering', 'fingering', 'fingering'],
    ['LH Guitar Fingering', 'guitar_fingering_lh', 'lhGuitarFingering'], ['RH Guitar Fingering', 'guitar_fingering_rh', 'rhGuitarFingering'],
    ['Tablature fret number', 'tab_fret_number', 'tabFretNumber'], ['String Number', 'string_number', 'stringNumber'], ['Glissando', 'glissando', 'glissando'], ['Bend', 'bend', 'bend'],
    ...Array.from({ length: 12 }, (_, i) => [`User-${i + 1}`, `user_${i + 1}`, `user${i + 1}`] as const),
];
const v3Names = new Map(styles.map(([v3, , prefix]) => [v3, prefix]));
const v4Names = new Map(styles.map(([, v4, prefix]) => [v4, prefix]));
v3Names.set('Technique', 'expression');
/** Shared binding vocabulary; callers retain their own native property/unit semantics. */
export const nativeTextStylePrefix=(selector:string,version:string):string|undefined=>version.startsWith('4.') ? v4Names.get(selector)??v3Names.get(selector) : v3Names.get(selector);
const ownerStyles: Readonly<Record<string, string>> = {
    StaffText: 'staff', PlayTechAnnotation: 'staff', SystemText: 'system', Expression: 'expression', Dynamic: 'dynamics', Tempo: 'tempo',
    RehearsalMark: 'rehearsalMark', Text: 'default', InstrumentChange: 'instrumentChange', Sticking: 'sticking', Fingering: 'fingering', GuitarBendText: 'bend', MeasureNumber:'measureNumber',
};
const suffixes: Readonly<Record<string, string>> = {
    FontFace: 'family', FontSize: 'size', FontSpatiumDependent: 'sizeIsSpatiumDependent', FontStyle: 'fontStyle',
    Color: 'color', Align: 'align', Position: 'position', FrameType: 'frameType', FrameWidth: 'frameWidth', FrameFgColor: 'frameFgColor', FrameBgColor: 'frameBgColor',
};
const localProperty = (name: string): string => name === 'fontFace' ? 'family' : name === 'fontSize' ? 'size' : name;
const locationKey = (field: Element) => `${field.location.member ?? ''}\0${field.location.path ?? ''}`;

/** Supply only the style scopes belonging to the selected score, in loading order.
 * Returned function replaces the explicit-property helper at the same owner hook.
 * Only an actually used style field is marked; unused definitions remain captured.
 */
export function createNativeTextStyleResolver(scopes: readonly Element[], context: NativeTextPresentationContext): (owner: Element, target: NativeTextPresentation, scale?: NativeTextScaleContext) => void {
    const fields = new Map<string, Element>();
    const major = context.nativeVersion?.split('.')[0];
    const renamedTextFields = major === '4' && Number(context.nativeVersion) >= 4.4;
    // Native 4.4 renamed staff/system properties and reads the earlier spellings
    // as aliases. Canonicalize while loading so the last alias wins in source order.
    const canonicalField = (name: string): string => renamedTextFields
        ? name.replace(/^(staff|system)(FontFace|FontSize|FontSpatiumDependent|FontStyle|Align|FrameType|FrameWidth|FrameFgColor|FrameBgColor)$/, '$1Text$2') : name;
    for (const scope of scopes) for (const field of scope.children) fields.set(canonicalField(field.name), field);
    const projectInline = createNativeInlinePresentation(scopes, context.nativeVersion, context.use);
    const projectMusic = createNativeMusicTextSize(scopes, context.nativeVersion, context.use);
    const projectSize = createNativeTextSizeProjector(scopes, context.nativeVersion, context.use);
    return (owner, target, scale) => {
        if (major !== '3' && major !== '4') { applyNativeTextPresentation(owner, target, context); return; }
        const selectors = owner.children.filter(field => field.name === 'style');
        const selector = selectors.at(-1);
        let prefix: string | undefined;
        if (selector) {
            if (!selector.children.length && !Object.keys(selector.attrs).length) {
                prefix = v3Names.get(selector.text);
                if (major === '4') prefix = v4Names.get(selector.text) ?? prefix ?? (selector.text === '12' ? 'dynamics' : selector.text === '26' ? 'staff' : undefined);
            }
            if (!prefix) context.gap(selector, 'The text style selector has no verified property binding; only later explicit properties establish presentation.');
            else { context.addMarking(selector); context.use(selector); }
        } else if (owner.name === 'Harmony') {
            const kind = owner.children.find(field => field.name === 'harmonyType')?.text.trim() ?? '0';
            prefix = ({ '0': 'chordSymbolA', '1': 'romanNumeral', '2': 'nashvilleNumber' } as Record<string, string>)[kind];
        } else if (owner.name === 'Lyrics') {
            const numbers = owner.children.filter(field => field.name === 'no');
            if (numbers.length <= 1 && (!numbers.length || !numbers[0].children.length && !Object.keys(numbers[0].attrs).length && /^\d+$/.test(numbers[0].text.trim()))) {
                const number = Number(numbers[0]?.text ?? '0');
                if (Number.isSafeInteger(number)) prefix = number % 2 ? 'lyricsEven' : 'lyricsOdd';
            }
        } else prefix = ownerStyles[owner.name];
        const lastSelector = selector ? owner.children.indexOf(selector) : -1;
        const explicit = owner.children.filter((field, index) => index > lastSelector && field.name !== 'style');
        const normalized = new Map<Element, Element>();
        const inherited = new Set<string>();
        const combined: Element[] = [];
        if (prefix) for (const [suffix, name] of Object.entries(suffixes)) {
            if (suffix === 'Position' && Number(context.nativeVersion) < 4.7) continue;
            const fieldPrefix = prefix === 'dynamics' && Number(context.nativeVersion) >= 4.1 && !['Align', 'Position'].includes(suffix) ? 'expression' : prefix;
            const serialized = `${fieldPrefix}${['system', 'staff'].includes(fieldPrefix) && (suffix === 'Color' || renamedTextFields) ? 'Text' : ''}${suffix}`;
            const field = fields.get(serialized);
            if (!field || explicit.some(local => localProperty(local.name) === name)) continue;
            const clone = { ...field, name }; normalized.set(clone, field); inherited.add(locationKey(field)); combined.push(clone);
        }
        combined.push(...explicit);
        // The caption itself is not reset by selecting a new style.
        if (!combined.some(field => field.name === 'text')) combined.push(...owner.children.filter(field => field.name === 'text'));
        const effective = { ...owner, children: combined };
        const isInherited = (source: { member?: string; path?: string }) => inherited.has(`${source.member ?? ''}\0${source.path ?? ''}`);
        // A later style selection resets earlier explicit values, including when
        // the new value comes from an absent native default we do not invent.
        if (selector) {
            if (owner.children.slice(0, lastSelector).some(field => ['align', 'position'].includes(field.name))) delete target.textAlignment;
            const replaced = new Set(owner.children.slice(0, lastSelector).map(locationKey));
            for (const key of ['textFontFamily', 'textFontStyle', 'textFontSize', 'sourceColor', 'textEnclosure', 'textAlignment'] as const) {
                const fact = target[key]; if (fact && replaced.has(`${fact.source.member ?? ''}\0${fact.source.path ?? ''}`)) delete target[key];
            }
            for (const key of ['bold', 'italic', 'underline', 'strike'] as const) {
                const fact = target.textEmphasis?.[key]; if (fact && replaced.has(`${fact.source.member ?? ''}\0${fact.source.path ?? ''}`)) delete target.textEmphasis![key];
            }
        }
        applyNativeTextPresentation(effective, target, {
            ...context,
            defaultSizeDependency: nativeTextSizeDependency(prefix, owner),
            projectFontSize: (effectiveOwner, size, dependency) => projectSize(effectiveOwner.name === 'Dynamic' && owner.children.some(f => f.name === 'subtype' && f.text.trim() === 'other-dynamics') && !target.textRuns?.some(run => run.symbolName || run.sourceText || run.sourceFont?.face === 'ScoreText') ? { ...effectiveOwner, name: 'StaffText' } : effectiveOwner, size, dependency, scale),
            use: field => { context.use(normalized.get(field) ?? field); return field; },
            addMarking: field => context.addMarking(normalized.get(field) ?? field),
            gap: (field, message) => context.gap(normalized.get(field) ?? field, message),
        });
        const dependencyField = combined.filter(f => f.name === 'sizeIsSpatiumDependent').at(-1);
        const dependency = dependencyField ? !dependencyField.children.length && !Object.keys(dependencyField.attrs).length && /^[01]$/.test(dependencyField.text.trim())
            ? { source: dependencyField.location, value: dependencyField.text.trim() === '1', origin: isInherited(dependencyField.location) ? 'source-style' as const : 'source-property' as const } : undefined
            : nativeTextSizeDependency(prefix, owner);
        // Inherited origins are settled before inline runs copy the owner size.
        if (target.textAlignment && isInherited(target.textAlignment.source)) target.textAlignment.origin = 'source-style';
        if (target.textFontFamily && isInherited(target.textFontFamily.source)) target.textFontFamily.origin = 'source-style';
        if (target.textFontStyle && isInherited(target.textFontStyle.source)) target.textFontStyle.origin = 'source-style';
        if (target.textEnclosure && isInherited(target.textEnclosure.source)) target.textEnclosure.origin = 'source-style';
        const size = target.textFontSize;
        if (size && isInherited(size.source)) size.origin = 'source-style';
        if (size?.pointSize) {
            if (isInherited(size.pointSize.spatiumDependent.source)) size.pointSize.spatiumDependent.origin = 'source-style';
            if (size.pointSize.context !== 'musescore-source-scaled-text' && (size.origin === 'source-style' || size.pointSize.spatiumDependent.origin === 'source-style')) size.pointSize.context = 'musescore-source-style-unscaled-text';
        }
        // Native 4.6+ defers these owners' serialized musicSymbolSize until
        // after style selection, including files which wrote it before style.
        const musicDeferred = Number(context.nativeVersion) >= 4.6 && ['Tempo', 'StaffText', 'Marker'].includes(owner.name);
        const inlineOwner = musicDeferred ? { ...effective, children: [...effective.children.filter(f => f.name !== 'musicSymbolSize'), ...owner.children.filter(f => f.name === 'musicSymbolSize')] } : effective;
        projectInline(inlineOwner, target.textRuns, target.textFontSize, dependency, scale, prefix);
        if (owner.name === 'Dynamic') {
            const run: TextRun = { source: owner.location, text: '', sourceFont: { source: owner.location, face: 'ScoreText', origin: 'source-markup' }, emphasis: 0, origin: 'source-markup' };
            projectMusic(inlineOwner, run, target.textFontSize, dependency, scale, prefix);
            if (run.musicFontSize) target.musicFontSize = run.musicFontSize;
        }
    };
}

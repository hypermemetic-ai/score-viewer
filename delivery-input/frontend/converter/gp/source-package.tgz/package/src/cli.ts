#!/usr/bin/env node
import { open, mkdtemp, rename, rm, writeFile } from 'node:fs/promises';
import { resolve, dirname, basename, join } from 'node:path';
import { convertScore, inspectMuseScore } from './index.js';
import { nativeLimits as limits } from './adapters/musescore/capture.js';

const [input, destination, ...flags] = process.argv.slice(2);
const inspection = destination === '--inspect-views';
const tracks = flags.filter(flag => flag.startsWith('--tracks=')), views = flags.filter(flag => flag.startsWith('--view-id=')), digests = flags.filter(flag => flag.startsWith('--input-sha256='));
if (!input || !destination || flags.length > 3 || flags.length !== tracks.length + views.length + digests.length || tracks.length > 1 || views.length > 1 || digests.length > 1 ||
    tracks.some(flag => !/^--tracks=\d+(?:,\d+)*$/.test(flag)) || views.some(flag => !flag.slice('--view-id='.length) || flag.slice('--view-id='.length).length > 4096) ||
    digests.some(flag => !/^--input-sha256=[a-f0-9]{64}$/.test(flag)) || views.length !== digests.length || inspection && flags.length) {
    console.error('Usage: score-converter local-file.gp|mscx|mscz new-output-directory [--tracks=source-id,... | --view-id=opaque-id --input-sha256=digest]\n       score-converter local-file.mscx|mscz --inspect-views');
    process.exitCode = 2;
} else {
    const controller = new AbortController();
    const cancel = () => controller.abort(new Error('Conversion cancelled.'));
    process.once('SIGINT', cancel); process.once('SIGTERM', cancel);
    let temporary: string | undefined;
    try {
        const file = await open(resolve(input), 'r');
        let bytes: Buffer;
        try {
            const stat = await file.stat();
            if (!stat.isFile() || stat.size > limits.inputBytes) throw new Error('Input must be a regular file no larger than 32 MiB.');
            const chunks: Buffer[] = [];
            let length = 0;
            while (length <= limits.inputBytes) {
                const chunk = Buffer.allocUnsafe(Math.min(64 * 1024, limits.inputBytes + 1 - length));
                const read = await file.read(chunk, 0, chunk.length, null);
                if (!read.bytesRead) break;
                length += read.bytesRead; chunks.push(chunk.subarray(0, read.bytesRead));
            }
            if (length > limits.inputBytes) throw new Error('Input grew beyond the 32 MiB bound.');
            bytes = Buffer.concat(chunks, length);
        } finally { await file.close(); }
        if (inspection) {
            const result = await inspectMuseScore(bytes!, { signal: controller.signal });
            console.log(JSON.stringify(result, null, 2)); if (!result.ok) process.exitCode = 1;
        } else {
        const result = await convertScore(bytes!, { signal: controller.signal, ...(tracks[0] ? { trackIds: tracks[0].slice('--tracks='.length).split(',') } : {}),
            ...(views[0] ? { sourceView: { id: views[0].slice('--view-id='.length), inputSha256: digests[0].slice('--input-sha256='.length) } } : {}) });
        const target = resolve(destination);
        // A new directory is the atomic result boundary; never overwrite previous results.
        const lock = await open(target + '.conversion-lock', 'wx');
        try {
            const { lstat } = await import('node:fs/promises');
            try { await lstat(target); throw new Error('Output directory already exists.'); } catch (e) {
                if ((e as NodeJS.ErrnoException).code !== 'ENOENT') throw e;
            }
            temporary = await mkdtemp(join(dirname(target), `.${basename(target)}-`));
            await writeFile(join(temporary, 'report.json'), JSON.stringify(result.report, null, 2) + '\n', { mode: 0o600 });
            if (result.ok) {
                if ('telemetry' in result && result.telemetry) await writeFile(join(temporary, 'telemetry.json'), JSON.stringify(result.telemetry, null, 2) + '\n', { mode: 0o600 });
                await writeFile(join(temporary, 'score.musicxml'), result.musicxml!, { mode: 0o600 });
                const source = 'nativeCapture' in result ? result.nativeCapture : { inputSource: result.inputSource, source: result.source,
                    binarySource: result.binarySource, gpxSource: result.gpxSource, containerSource: result.containerSource, occurrences: result.occurrences };
                await writeFile(join(temporary, 'source-capture.json'), JSON.stringify(source, null, 2) + '\n', { mode: 0o600 });
            }
            if (controller.signal.aborted) throw controller.signal.reason;
            await rename(temporary, target); temporary = undefined;
        } finally { await lock.close(); await rm(target + '.conversion-lock', { force: true }); }
        console.log(result.ok ? `Converted locally: ${destination}/score.musicxml` : `Conversion refused: ${destination}/report.json`);
        if (!result.ok) process.exitCode = 1;
        }
    } catch (e) {
        console.error(e instanceof Error ? e.message : 'Conversion failed.'); process.exitCode = 1;
    } finally {
        if (temporary) await rm(temporary, { recursive: true, force: true });
        process.removeListener('SIGINT', cancel); process.removeListener('SIGTERM', cancel);
    }
}

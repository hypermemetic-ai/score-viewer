/** Shared public GP declarations; this module contains no runtime host or decoder imports. */
import type { ConversionResult as InternalConversionResult, ConvertedPart } from './adapters/guitar-pro/convert-core.js';
import type { MusicalScore, NeutralScore } from './core/model.js';
export type { ConvertedPart } from './adapters/guitar-pro/convert-core.js';
export type { InspectionResult, SourceTrackInfo } from './adapters/guitar-pro/inspect-core.js';
export type { Finding, Location } from './core/report.js';
export type { NeutralScore, Part, Measure, Event, NoteFact, Pitch, Tempo } from './core/model.js';
export type { Element as GuitarProSourceElement } from './adapters/guitar-pro/xml.js';
export type { BinaryCapture } from './adapters/guitar-pro/binary.js';
export type { GpxCapture, GpxMemberCapture } from './adapters/guitar-pro/gpx.js';
export type { ContainerFact } from './adapters/guitar-pro/container-facts.js';
export type { OccurrenceCapture } from './adapters/guitar-pro/recover.js';
type ConversionSuccessBase = Omit<InternalConversionResult, 'ok' | 'musicxml' | 'report' | 'score' | 'scoreKind' | 'inputSource' | 'occurrences' | 'containerSource'> & {
    readonly ok: true; readonly musicxml: string;
    readonly report: Omit<InternalConversionResult['report'], 'convertedParts'> & { readonly convertedParts: readonly ConvertedPart[] };
    readonly inputSource: NonNullable<InternalConversionResult['inputSource']>;
    readonly occurrences: NonNullable<InternalConversionResult['occurrences']>;
    readonly containerSource: NonNullable<InternalConversionResult['containerSource']>;
};
/** Whole arrangements can contain genuinely unpitched or non-fretted parts. */
export type ConversionSuccess = ConversionSuccessBase & (
    { readonly scoreKind: 'fretted'; readonly score: NeutralScore }
    | { readonly scoreKind: 'arrangement'; readonly score: MusicalScore }
);
export type ConversionFailure = { readonly ok: false; readonly report: Omit<InternalConversionResult['report'], 'convertedParts'> & { readonly convertedParts?: never } } & {
    readonly [Key in Exclude<keyof InternalConversionResult, 'ok' | 'report'>]?: never;
};
export type ConversionResult = ConversionSuccess | ConversionFailure;
export type GuitarProReport = ConversionResult['report'];
export interface GuitarProOptions { readonly signal?: AbortSignal; readonly trackIds?: readonly string[] }
export interface GuitarProInspectionOptions { readonly signal?: AbortSignal }

import type { SourceViewSelection } from './adapters/musescore/views.js';

/** Scope values are bounded own data, never caller getters/iteration or a mutable selection object. */
export function snapshotSourceView(selection: unknown): SourceViewSelection | undefined {
    if (selection === undefined) return undefined;
    if (!selection || typeof selection !== 'object' || Array.isArray(selection)) throw new TypeError('Expected a file-scoped sourceView selection.');
    const id = Object.getOwnPropertyDescriptor(selection, 'id'), digest = Object.getOwnPropertyDescriptor(selection, 'inputSha256');
    if (!id || !('value' in id) || typeof id.value !== 'string' || !id.value || id.value.length > 4096 || !digest || !('value' in digest) || typeof digest.value !== 'string' || !/^[a-f0-9]{64}$/.test(digest.value)) throw new TypeError('sourceView requires bounded own id and exact lowercase inputSha256 strings.');
    return { id: id.value, inputSha256: digest.value };
}

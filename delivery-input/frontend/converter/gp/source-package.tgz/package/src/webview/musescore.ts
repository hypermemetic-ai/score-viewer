import { freeze } from '../core/report.js';
import { nativeAdapter, nativeLimits } from '../adapters/musescore/limits.js';
import { inputView, snapshotInput, snapshotTrackIds } from '../guitar-pro-input.js';
import { snapshotSourceView } from '../musescore-input.js';
import { protocol, hostFailure, type Operation, type Result } from './musescore-protocol.js';
import type { MuseScoreResult, MuseScoreInspectionResult, MuseScoreOptions, MuseScoreInspectionOptions } from '../musescore-contract.js';
export type * from '../musescore-contract.js';

let sequence = 0;
const cancellationReason = (signal: AbortSignal): unknown => signal.reason === undefined ? new Error('Conversion cancelled.') : signal.reason;
const workMessage = `Native worker exceeded ${nativeLimits.workerMs / 1000} seconds; no musical output admitted.`;
const has = (value: object, keys: readonly string[]) => Object.keys(value).every(key => keys.includes(key));

/** Local module Worker per request; the consumer owns concurrency, hosting and platform acceptance. */
export async function convertMuseScore(bytes: Uint8Array, options: MuseScoreOptions = {}): Promise<MuseScoreResult> {
    return run('convert', bytes, options) as Promise<MuseScoreResult>;
}
/** Descriptive view discovery; each conversion independently admits the selected source music. */
export async function inspectMuseScore(bytes: Uint8Array, options: MuseScoreInspectionOptions = {}): Promise<MuseScoreInspectionResult> {
    return run('inspect', bytes, options) as Promise<MuseScoreInspectionResult>;
}
async function run(operation: Operation, bytes: Uint8Array, options: MuseScoreOptions & { readonly trackIds?: unknown }): Promise<Result> {
    if (!options || typeof options !== 'object' || Array.isArray(options)) throw new TypeError('Conversion options must be an object.');
    const signal = options.signal, requestedTrackIds = options.trackIds, requestedSourceView = options.sourceView;
    if (signal !== undefined && (!signal || typeof signal.aborted !== 'boolean' || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) throw new TypeError('Conversion signal must be an AbortSignal.');
    if (signal?.aborted) throw cancellationReason(signal);
    const view = inputView(bytes, nativeLimits.inputBytes, 'Native input exceeds 32 MiB; no snapshot, digest, worker or decoding started.');
    const selectedTracks = snapshotTrackIds(requestedTrackIds) !== undefined;
    const sourceView = snapshotSourceView(requestedSourceView);
    if (operation === 'inspect' && (selectedTracks || sourceView)) throw new TypeError('Inspection discovers source views; selection belongs to conversion.');
    if (typeof Worker !== 'function' || typeof globalThis.crypto?.subtle?.digest !== 'function' || typeof globalThis.performance?.now !== 'function') throw new TypeError('This entry requires local module Workers, WebCrypto SHA-256 and a monotonic clock.');
    const inputBytes = view.byteLength, input = snapshotInput(view);
    const requestId = ++sequence, started = performance.now();
    return new Promise((resolve, reject) => {
        let worker: Worker | undefined, done = false, inputSha256: string | undefined;
        const finish = (result?: Result, error?: unknown) => {
            if (done) return;
            let immutable = result === undefined ? undefined : freeze(result);
            // Validation/freezing is synchronous; a delayed timer cannot authorize a late result.
            if (immutable !== undefined && inputSha256 && performance.now() - started >= nativeLimits.workerMs) immutable = failure('work-budget', workMessage);
            done = true; clearTimeout(timer); signal?.removeEventListener('abort', abort);
            if (worker) { worker.onmessage = worker.onerror = worker.onmessageerror = null; worker.terminate(); }
            if (error !== undefined) reject(error); else resolve(immutable!);
        };
        const failure = (code: string, message: string) => hostFailure(operation, inputSha256!, inputBytes, sourceView, code, message);
        const abort = () => finish(undefined, cancellationReason(signal!));
        const expire = () => {
            // A crypto operation cannot be cancelled. Do not invent an unavailable source digest.
            if (!inputSha256) finish(undefined, new Error(`Native request exceeded ${nativeLimits.workerMs / 1000} seconds before source hashing completed.`));
            else finish(failure('work-budget', workMessage));
        };
        const timer = setTimeout(expire, nativeLimits.workerMs);
        signal?.addEventListener('abort', abort, { once: true });
        if (signal?.aborted) { abort(); return; }
        void (async () => {
            try {
                const digest = await globalThis.crypto.subtle.digest('SHA-256', input);
                if (done) return;
                inputSha256 = [...new Uint8Array(digest)].map(value => value.toString(16).padStart(2, '0')).join('');
                if (performance.now() - started >= nativeLimits.workerMs) { expire(); return; }
                if (sourceView && selectedTracks) { finish(failure('native-scope', 'Source view and GP source track selection are contradictory; no native decoding started.')); return; }
                if (selectedTracks) { finish(failure('native-scope', '--tracks selects GP source tracks and cannot silently select native parts; no native decoding started.')); return; }
                worker = new Worker(new URL('./musescore.worker.js', import.meta.url), { type: 'module' });
                worker.onmessage = ({ data }) => {
                    if (done) return;
                    if (performance.now() - started >= nativeLimits.workerMs) { expire(); return; }
                    try {
                        const result = data?.result, report = result?.report, scope = report?.requestedScope;
                        if (!data || data.protocol !== protocol || data.requestId !== requestId || data.operation !== operation || report?.inputSha256 !== inputSha256 ||
                            typeof result.ok !== 'boolean') throw new Error('identity');
                        if (sourceView ? scope?.sourceView?.id !== sourceView.id || scope?.sourceView?.inputSha256 !== sourceView.inputSha256 : scope !== 'all-parts') throw new Error('scope');
                        if (report.schema !== 'score-converter-report/0' || report.adapter !== nativeAdapter || typeof report.profile !== 'string' || !Array.isArray(report.findings) ||
                            !report.metrics || report.metrics.inputBytes !== inputBytes) throw new Error('report-shape');
                        if (!result.ok) {
                            if (!has(result, ['ok', 'report', 'telemetry', 'nativeCapture']) || report.convertedParts !== undefined) throw new Error('failure-shape');
                        } else if (operation === 'inspect') {
                            if (!Array.isArray(result.views) || !has(result, ['ok', 'report', 'views'])) throw new Error('inventory-shape');
                        } else if (typeof result.musicxml !== 'string' || !result.score || !Array.isArray(result.score.parts) || !result.telemetry ||
                            result.nativeCapture?.inputSha256 !== inputSha256 || !has(result, ['ok', 'report', 'musicxml', 'nativeCapture', 'score', 'telemetry']) ||
                            sourceView && !Array.isArray(report.convertedParts)) throw new Error('conversion-shape');
                        finish(result);
                    } catch { finish(failure('worker-identity', 'Native result does not match the exact admitted input and source-scope request.')); }
                };
                worker.onerror = event => { event.preventDefault(); finish(failure('worker-runtime', 'Local module Worker failed; no musical output admitted.')); };
                worker.onmessageerror = () => finish(failure('worker-message', 'Worker result could not be received; no musical output admitted.'));
                worker.postMessage({ protocol, requestId, operation, inputSha256, bytes: input, ...(sourceView ? { sourceView } : {}) }, [input.buffer]);
            } catch (error) { if (inputSha256) finish(failure('worker-runtime', 'Local module Worker could not start; no musical output admitted.')); else finish(undefined, error); }
        })();
    });
}

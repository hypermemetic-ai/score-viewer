import { convertNative } from '../adapters/musescore/convert-core.js';
import { inspectNative } from '../adapters/musescore/inspect-core.js';
import { nativeLimits } from '../adapters/musescore/limits.js';
import type { NativeHost } from '../adapters/musescore/capture-core.js';
import { captureZipWebView } from '../core/source-zip-webview.js';
import { Refusal } from '../core/report.js';
import { sha256, crc32 } from '../adapters/guitar-pro/bytes.js';
import { protocol, hostFailure, type Request, type Result } from './musescore-protocol.js';

// Dedicated to one request. No Node/native adapter or UI synchronous entry is exported.
const scope = globalThis as unknown as { onmessage: ((event: MessageEvent) => void) | null; postMessage(value: unknown): void; close(): void };
const workMessage = `Native worker exceeded ${nativeLimits.workerMs / 1000} seconds; no musical output admitted.`;
const sourceViewShape = (value: unknown): boolean => !!value && typeof value === 'object' && !Array.isArray(value) && Object.keys(value).length === 2 &&
    typeof (value as Record<string, unknown>).id === 'string' && !!(value as Record<string, string>).id && (value as Record<string, string>).id.length <= 4096 &&
    typeof (value as Record<string, unknown>).inputSha256 === 'string' && /^[a-f0-9]{64}$/.test((value as Record<string, string>).inputSha256);
let received = false, invalidated = false;
scope.onmessage = async ({ data }: MessageEvent) => {
    if (received) { invalidated = true; scope.close(); return; }
    received = true;
    if (!data || data.protocol !== protocol || !Number.isSafeInteger(data.requestId) || data.requestId < 1 || !['convert', 'inspect'].includes(data.operation) ||
        !(data.bytes instanceof Uint8Array) || !(data.bytes.buffer instanceof ArrayBuffer) || data.bytes.byteOffset !== 0 || data.bytes.buffer.byteLength !== data.bytes.byteLength || data.bytes.byteLength > nativeLimits.inputBytes || !/^[a-f0-9]{64}$/.test(data.inputSha256) ||
        Object.keys(data).some(key => !['protocol', 'requestId', 'operation', 'inputSha256', 'bytes', 'sourceView'].includes(key)) ||
        data.sourceView !== undefined && (data.operation !== 'convert' || !sourceViewShape(data.sourceView))) {
        scope.close(); return; // An unbound request never gets useful inventory, source or XML.
    }
    const request = data as Request, deadline = performance.now() + nativeLimits.workerMs;
    const digest = sha256(request.bytes);
    if (digest !== request.inputSha256) { scope.close(); return; }
    const bytes = request.bytes;
    let members: Map<string, Uint8Array> | undefined, decodeError: unknown;
    if (bytes.length >= 4 && bytes[0] === 0x50 && bytes[1] === 0x4b && bytes[2] === 0x03 && bytes[3] === 0x04) {
        try { members = await captureZipWebView(bytes, { at: deadline, work: () => new Refusal('work-budget', workMessage, { member: 'container' }) }, crc32); }
        catch (error) { decodeError = error; }
    }
    // Native stream promises may drain entirely through microtasks. Give queued duplicate
    // message tasks a turn before source recovery and before publishing useful output.
    await new Promise(resolve => setTimeout(resolve, 0));
    if (invalidated) return;
    const host: NativeHost = { sha256, zipMembers: () => { if (decodeError) throw decodeError; return members!; } };
    let result: Result = request.operation === 'inspect' ? inspectNative(bytes, host) : convertNative(bytes, host, { sourceView: request.sourceView });
    if (performance.now() >= deadline) result = hostFailure(request.operation, digest, bytes.length, request.sourceView, 'work-budget', workMessage);
    await new Promise(resolve => setTimeout(resolve, 0));
    if (!invalidated) scope.postMessage({ protocol, requestId: request.requestId, operation: request.operation, result });
    scope.close();
};

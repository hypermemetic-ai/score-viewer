import { freeze } from '../core/report.js';
import { nativeAdapter } from '../adapters/musescore/limits.js';
import type { MuseScoreInspectionResult, MuseScoreResult, SourceViewSelection } from '../musescore-contract.js';

export const protocol = 'score-converter-musescore-worker/1';
export type Operation = 'convert' | 'inspect';
export interface Request {
    protocol: typeof protocol;
    requestId: number;
    operation: Operation;
    inputSha256: string;
    bytes: Uint8Array;
    sourceView?: SourceViewSelection;
}
export type Result = MuseScoreResult | MuseScoreInspectionResult;
/** The same located refusal the Node host returns when no admitted worker result exists. */
export function hostFailure(operation: Operation, inputSha256: string, inputBytes: number, sourceView: SourceViewSelection | undefined, code: string, message: string): MuseScoreResult {
    return freeze({ ok: false, report: {
        schema: 'score-converter-report/0', inputSha256, adapter: nativeAdapter,
        profile: operation === 'inspect' ? 'musescore-source-view-inventory/0' : 'musescore-observed-vocabulary/0', requestedScope: sourceView ? { sourceView } : 'all-parts',
        findings: [{ disposition: 'blocking', code, message, location: { member: 'input' } }],
        metrics: { inputBytes, outputBytes: 0, nodeCount: 0, eventCount: 0 }
    } });
}

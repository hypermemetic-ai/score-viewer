/** Shared public MuseScore declarations; this module contains no runtime host or decoder imports. */
import type { MuseScoreSuccess as InternalMuseScoreSuccess, MuseScoreFailure as InternalMuseScoreFailure, MuseScoreReport as InternalMuseScoreReport, MuseScoreTelemetry as InternalMuseScoreTelemetry } from './adapters/musescore/convert-core.js';
import type { NativeCapture as InternalNativeCapture } from './adapters/musescore/capture-core.js';
import type { MuseScoreInspectionResult as InternalMuseScoreInspectionResult } from './adapters/musescore/inspect-core.js';
import type { SourceViewInfo as InternalSourceViewInfo, SourceViewSelection } from './adapters/musescore/views.js';
import type * as MusicalFacts from './core/model.js';
export type { SourceViewSelection } from './adapters/musescore/views.js';
/** Public conversion facts match the recursively frozen runtime result. */
type ReadonlyFacts<T> = T extends object ? { readonly [Key in keyof T]: ReadonlyFacts<T[Key]> } : T;
export type MuseScoreReport = ReadonlyFacts<InternalMuseScoreReport>;
export type MuseScoreTelemetry = ReadonlyFacts<InternalMuseScoreTelemetry>;
export type NativeCapture = ReadonlyFacts<InternalNativeCapture>;
export type MuseScoreSuccess = ReadonlyFacts<InternalMuseScoreSuccess>;
export type MuseScoreFailure = ReadonlyFacts<InternalMuseScoreFailure>;
export type MuseScoreResult = MuseScoreSuccess | MuseScoreFailure;
export type MuseScoreInspectionResult = ReadonlyFacts<InternalMuseScoreInspectionResult>;
export type SourceViewInfo = ReadonlyFacts<InternalSourceViewInfo>;
export type MusicalScore = ReadonlyFacts<MusicalFacts.MusicalScore>;
export type MusicalPart = ReadonlyFacts<MusicalFacts.MusicalPart>;
export type MusicalMeasure = ReadonlyFacts<MusicalFacts.MusicalMeasure>;
export type MusicalEvent = ReadonlyFacts<MusicalFacts.MusicalEvent>;
export type MusicalNote = ReadonlyFacts<MusicalFacts.MusicalNote>;
export type UnpitchedNote = ReadonlyFacts<MusicalFacts.UnpitchedNote>;
export type PitchedOrDeadNote = ReadonlyFacts<MusicalFacts.PitchedOrDeadNote>;
export type StaffFact = ReadonlyFacts<MusicalFacts.StaffFact>;
export type StaffChange = ReadonlyFacts<MusicalFacts.StaffChange>;
export type MusicalRelation = ReadonlyFacts<MusicalFacts.MusicalRelation>;
export type RelationEndpoint = ReadonlyFacts<MusicalFacts.RelationEndpoint>;
export type TrillNotationAttachment = ReadonlyFacts<MusicalFacts.TrillNotationAttachment>;
export type Direction = ReadonlyFacts<MusicalFacts.Direction>;
export type SourceColor = ReadonlyFacts<MusicalFacts.SourceColor>;
export type GlyphFact = ReadonlyFacts<MusicalFacts.GlyphFact>;
export type OrnamentDetails = ReadonlyFacts<MusicalFacts.OrnamentDetails>;
export interface MuseScoreOptions { readonly signal?: AbortSignal; readonly sourceView?: SourceViewSelection }
export interface MuseScoreInspectionOptions { readonly signal?: AbortSignal }

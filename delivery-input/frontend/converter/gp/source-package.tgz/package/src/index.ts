import { nativeLimits, nativeAdapter } from './adapters/musescore/capture.js';
import { zipMemberNames } from './core/source-zip.js';
import { snapshotSourceView } from './musescore-input.js';
export type * from './musescore-contract.js';
import type { MuseScoreResult, MuseScoreInspectionResult, MuseScoreOptions, MuseScoreInspectionOptions, SourceViewSelection } from './musescore-contract.js';
import { Worker } from 'node:worker_threads';
import { createHash } from 'node:crypto';
import { freeze } from './core/report.js';
import { limits } from './adapters/guitar-pro/limits.js';
import { inputView, snapshotInput, snapshotTrackIds } from './guitar-pro-input.js';
import type { InspectionResult } from './adapters/guitar-pro/inspect.js';
export type * from './guitar-pro-contract.js';
import type { ConversionResult, GuitarProOptions, GuitarProInspectionOptions } from './guitar-pro-contract.js';

let sequence = 0;
const cancellationReason = (signal: AbortSignal): unknown => { const reason = signal.reason; return reason === undefined ? new Error('Conversion cancelled.') : reason; };

/** One local worker per caller invocation. The caller owns concurrency. No filesystem/network score access. */
export async function convertGuitarPro(bytes: Uint8Array, options: GuitarProOptions = {}): Promise<ConversionResult> {
    return runGuitarPro<ConversionResult>('convert', bytes, options);
}
/** Metadata-only inventory; conversion independently admits each selected musical graph. */
export async function inspectGuitarPro(bytes: Uint8Array, options: GuitarProInspectionOptions = {}): Promise<InspectionResult> {
    return runGuitarPro<InspectionResult>('inspect', bytes, options);
}
async function runGuitarPro<T extends ConversionResult | InspectionResult>(operation: 'convert' | 'inspect', bytes: Uint8Array, options: GuitarProOptions): Promise<T> {
    if (!options || typeof options !== 'object' || Array.isArray(options)) throw new TypeError('Expected a conversion options object.');
    const signal = options.signal, requestedTrackIds = options.trackIds;
    if (operation === 'inspect' && requestedTrackIds !== undefined) throw new TypeError('Inspection discovers source tracks; selection belongs to conversion.');
    if (signal !== undefined && (!signal || typeof signal.aborted !== 'boolean' || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) throw new TypeError('Expected an AbortSignal.');
    if (signal?.aborted) throw cancellationReason(signal);
    const view = inputView(bytes), trackIds = snapshotTrackIds(requestedTrackIds);
    // Copy exactly the caller's view before yielding; subsequent caller mutations cannot change source identity.
    const input = snapshotInput(view);
    const inputSha256 = createHash('sha256').update(input).digest('hex');
    const failure = (code: string, message: string): T => freeze({ ok: false, report: {
        schema: 'score-converter-report/0', inputSha256, adapter: 'alphatab-1.8.4-022a45c8+source-hook/1',
        profile: operation === 'inspect' ? 'gp-family-inventory/0' : 'gp-family-fretted/0', requestedScope: trackIds ? { trackIds } : 'all-tracks', findings: [{ disposition: 'blocking', code, message, location: { member: 'input' } }]
    } } as T);
    const requestId = ++sequence;
    const worker = new Worker(new URL('./worker.js', import.meta.url), { workerData: { bytes: input, trackIds, operation, requestId },
        execArgv: [], // Compiled reader needs no parent eval/test/V8 or preload flags.
        resourceLimits: { maxOldGenerationSizeMb: limits.workerHeapMb, maxYoungGenerationSizeMb: 16, stackSizeMb: 4 } });
    return new Promise((resolve, reject) => {
        let done = false;
        const finish = async (result?: T, error?: unknown) => {
            if (done) return;
            done = true; clearTimeout(timer); signal?.removeEventListener('abort', abort);
            await worker.terminate();
            if (error !== undefined) reject(error); else resolve(freeze(result!));
        };
        const abort = () => { void finish(undefined, cancellationReason(signal!)); };
        const timer = setTimeout(() => { void finish(failure('work-budget', 'Worker exceeded 5 seconds; no musical output is admitted.')); }, limits.workerMs);
        signal?.addEventListener('abort', abort, { once: true });
        if (signal?.aborted) { abort(); return; }
        worker.once('message', response => {
            if (response?.requestId !== requestId || response?.operation !== operation || response?.result?.report?.inputSha256 !== inputSha256) void finish(failure('worker-identity', 'Worker response does not match the immutable input request.'));
            else void finish(response.result as T);
        });
        worker.once('error', () => { void finish(failure('worker-budget', 'Worker failed or exceeded memory limits; no musical output is admitted.')); });
        worker.once('exit', () => { if (!done) void finish(failure('worker-exit', 'Worker exited before delivering a result.')); });
    });
}

export interface ScoreConversionOptions extends GuitarProOptions { readonly sourceView?: SourceViewSelection }
export type ScoreConversionResult = ConversionResult | MuseScoreResult;
function nativeOptions(options: ScoreConversionOptions): { signal?: AbortSignal; trackIds?: readonly string[]; sourceView?: SourceViewSelection } {
    if (!options || typeof options !== 'object' || Array.isArray(options)) throw new TypeError('Conversion options must be an object.');
    const signal = options.signal, tracks = options.trackIds, sourceView = options.sourceView;
    if (signal !== undefined && (!signal || typeof signal.aborted !== 'boolean' || typeof signal.addEventListener !== 'function' || typeof signal.removeEventListener !== 'function')) throw new TypeError('Conversion signal must be an AbortSignal.');
    return { signal, ...(tracks !== undefined ? { trackIds: tracks } : {}), ...(sourceView !== undefined ? { sourceView } : {}) };
}
async function nativeWorker(bytes: Uint8Array, options: ScoreConversionOptions = {}, operation: 'convert' | 'inspect' = 'convert'): Promise<MuseScoreResult | MuseScoreInspectionResult> {
    options = nativeOptions(options);
    const signal = options.signal;
    if (signal?.aborted) throw signal.reason === undefined ? new Error('Conversion cancelled.') : signal.reason;
    const view = inputView(bytes, nativeLimits.inputBytes, 'Native input exceeds 32 MiB; no snapshot, digest, worker or decoding started.');
    const selectedTracks = snapshotTrackIds(options.trackIds) !== undefined;
    const sourceView = snapshotSourceView(options.sourceView);
    if (operation === 'inspect' && (selectedTracks || sourceView)) throw new TypeError('Inspection discovers source views; selection belongs to conversion.');
    const input = snapshotInput(view), inputBytes = view.byteLength, inputSha256 = createHash('sha256').update(input).digest('hex');
    const failure = (code: string, message: string): MuseScoreResult => freeze({ ok: false, report: {
        schema: 'score-converter-report/0', inputSha256, adapter: nativeAdapter,
        profile: operation === 'inspect' ? 'musescore-source-view-inventory/0' : 'musescore-observed-vocabulary/0', requestedScope: sourceView ? { sourceView } : 'all-parts', findings: [{ disposition: 'blocking', code, message, location: { member: 'input' } }],
        metrics: { inputBytes, outputBytes: 0, nodeCount: 0, eventCount: 0 }
    } });
    if (sourceView && selectedTracks) return failure('native-scope', 'Source view and GP source track selection are contradictory; no native decoding started.');
    if (selectedTracks) return failure('native-scope', '--tracks selects GP source tracks and cannot silently select native parts; no native decoding started.');
    const requestId = ++sequence;
    const worker = new Worker(new URL('./native-worker.js', import.meta.url), { workerData: { bytes: input, sourceView, operation, requestId }, transferList: [input.buffer], execArgv: [],
        resourceLimits: { maxOldGenerationSizeMb: nativeLimits.workerHeapMb, maxYoungGenerationSizeMb: 16, stackSizeMb: 4 } });
    return new Promise((resolve, reject) => {
        let done = false;
        const finish = async (result?: MuseScoreResult | MuseScoreInspectionResult, error?: unknown, rejected = false) => {
            if (done) return;
            done = true; clearTimeout(timer); signal?.removeEventListener('abort', abort); await worker.terminate();
            if (rejected) reject(error); else resolve(freeze(result!));
        };
        const abort = () => { void finish(undefined, signal!.reason === undefined ? new Error('Conversion cancelled.') : signal!.reason, true); };
        const timer = setTimeout(() => { void finish(failure('work-budget', `Native worker exceeded ${nativeLimits.workerMs / 1000} seconds; no musical output admitted.`)); }, nativeLimits.workerMs);
        signal?.addEventListener('abort', abort, { once: true });
        if (signal?.aborted) { abort(); return; }
        worker.once('message', response => {
            const result = response?.result, scope = result?.report?.requestedScope;
            const scopeMatches = sourceView ? scope?.sourceView?.id === sourceView.id && scope?.sourceView?.inputSha256 === sourceView.inputSha256 : scope === 'all-parts';
            void finish(response?.requestId === requestId && response?.operation === operation && result?.report?.inputSha256 === inputSha256 && scopeMatches ? result : failure('worker-identity', 'Native result does not match the exact admitted input and source-scope request.'));
        });
        worker.once('error', () => { void finish(failure('worker-budget', 'Native worker failed or exceeded memory budget; no musical output admitted.')); });
        worker.once('exit', () => { if (!done) void finish(failure('worker-exit', 'Native worker exited without a result.')); });
    });
}
/** Independent native reader. No MuseScore executable/library is invoked by conversion. */
export async function convertMuseScore(bytes: Uint8Array, options: MuseScoreOptions = {}): Promise<MuseScoreResult> {
    return nativeWorker(bytes, options) as Promise<MuseScoreResult>;
}
/** Descriptive view discovery; each conversion independently admits the selected source music. */
export async function inspectMuseScore(bytes: Uint8Array, options: MuseScoreInspectionOptions = {}): Promise<MuseScoreInspectionResult> {
    return nativeWorker(bytes, options, 'inspect') as Promise<MuseScoreInspectionResult>;
}
/** Content-based source dispatch; MusicXML and MXL consumer intake remain outside this converter. */
export async function convertScore(bytes: Uint8Array, options: ScoreConversionOptions = {}): Promise<ScoreConversionResult> {
    options = nativeOptions(options);
    if (options.signal?.aborted) throw options.signal.reason === undefined ? new Error('Conversion cancelled.') : options.signal.reason;
    const view = inputView(bytes, nativeLimits.inputBytes, 'Source input exceeds 32 MiB; no snapshot, digest, worker or directory decoding started.');
    options = { signal: options.signal, trackIds: snapshotTrackIds(options.trackIds), sourceView: snapshotSourceView(options.sourceView) };
    const source = new Uint8Array(view.buffer, view.byteOffset, view.byteLength), prefix = Buffer.from(view.buffer, view.byteOffset, Math.min(view.byteLength, 128));
    const guitarPro = () => {
        if (options.sourceView) throw new TypeError('sourceView selects native MuseScore views; Guitar Pro uses source trackIds.');
        return convertGuitarPro(source, options);
    };
    if (prefix.toString('latin1').includes('FICHIER GUITAR PRO') || prefix.toString('latin1').startsWith('BCF')) return guitarPro();
    if (view.byteLength >= 4 && prefix.readUInt32LE(0) === 0x04034b50) {
        let names: string[] = [];
        try { names = zipMemberNames(source); } catch { /* Full native admission reports malformed/unidentified ZIP; no payload was inflated. */ }
        if (names.includes('Content/score.gpif') && names.includes('VERSION')) return guitarPro();
    }
    return nativeWorker(source, options) as Promise<MuseScoreResult>;
}

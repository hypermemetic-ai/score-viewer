import { parentPort, workerData } from 'node:worker_threads';
import { convertMuseScoreInWorker } from './adapters/musescore/convert.js';
import { inspectMuseScoreInWorker } from './adapters/musescore/inspect.js';
const result = workerData.operation === 'inspect' ? inspectMuseScoreInWorker(workerData.bytes as Uint8Array)
    : convertMuseScoreInWorker(workerData.bytes as Uint8Array, { sourceView: workerData.sourceView });
parentPort!.postMessage({ requestId: workerData.requestId, operation: workerData.operation, result });

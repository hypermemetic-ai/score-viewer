import type { Direction, FingeringFact, TextFontSize, TextRun } from './model.js';
import { refuse } from './report.js';
const esc = (value: string): string => value.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
export function pointSizeXml(size?: TextFontSize, userCredit = false): string {
    const point = size?.pointSize;
    if (point?.context === 'musescore-source-scaled-text') {
        const scale = point.scaling, dependent = point.spatiumDependent, music = point.music;
        const musicValid = !music || Number(music.nativeVersion) >= 3 && Number(music.nativeVersion) < 5
            && (!scale || scale.nativeVersion === music.nativeVersion)
            && (music.rule === 'fragment' && music.factor === 1
                || music.rule === 'tempo-ratio' && Number(music.nativeVersion) >= 4 && Number(music.nativeVersion) < 4.7 && music.factor === 5 / 3
                || music.rule === 'legacy-dynamic' && Number(music.nativeVersion) >= 4 && Number(music.nativeVersion) < 4.1 && music.factor === 2
                || music.rule === 'smufl-scale' && Number(music.nativeVersion) >= 4.1 && music.factor === (Number(music.nativeVersion) >= 4.7 ? 4 * 1.75 * 72 / 25.4 : 20)
                || music.rule === 'symbol-size' && Number(music.nativeVersion) >= 4.6 && music.factor === 1);
        const musicFactor = music?.factor ?? 1;
        const valid = musicValid && size && ['source-property', 'source-style', 'source-markup', 'native-default'].includes(size.origin) && /^(?:\d+(?:\.\d*)?|\.\d+)$/.test(size.rawValue.trim())
            && Number(size.rawValue) === size.value && Number.isFinite(size.value) && size.value! > 0 && size.value! <= 10000
            && point.origin === 'source-context' && ['source-property', 'source-style', 'native-default'].includes(dependent.origin)
            && (!scale ? dependent.value === false && point.value === size.value! * musicFactor : typeof dependent.value === 'boolean'
                && Number(scale.nativeVersion) >= 3 && Number(scale.nativeVersion) < 5
                && scale.referenceSpatiumMillimeters === (Number(scale.nativeVersion) >= 4.7 ? 1.75 : 127 / 72)
                && ['source-style', 'native-default'].includes(scale.scoreSpatium.origin)
                && Number.isFinite(scale.scoreSpatium.millimeters) && scale.scoreSpatium.millimeters > 0 && scale.scoreSpatium.millimeters <= 10000
                && (scale.scoreSpatium.rawValue === undefined ? scale.scoreSpatium.origin === 'native-default' : Number(scale.scoreSpatium.rawValue) === scale.scoreSpatium.millimeters)
                && ['source-staff', 'native-default', 'score-scope'].includes(scale.staff.origin) && Number.isFinite(scale.staff.factor) && scale.staff.factor > 0 && scale.staff.factor <= 4
                && (scale.staff.origin !== 'score-scope' || scale.staff.factor === 1)
                && (!scale.lineSpatiumDependent || Number(scale.nativeVersion) >= 4.1 && typeof scale.lineSpatiumDependent.value === 'boolean' && ['source-property', 'source-style', 'native-default'].includes(scale.lineSpatiumDependent.origin))
                && point.value === (dependent.value ? size.value! * scale.scoreSpatium.millimeters / scale.referenceSpatiumMillimeters * scale.staff.factor : size.value!)
                    / (scale.lineSpatiumDependent?.value === false ? scale.scoreSpatium.millimeters / scale.referenceSpatiumMillimeters * scale.staff.factor : 1) * musicFactor)
            && Number.isFinite(point.value) && point.value > 0 && point.value <= 10000;
        if (!valid) refuse('writer-text-font-size', 'Projected point size requires the exact source request, unit dependency and version-qualified scale facts.', size!.source);
        const [mantissa, exponent] = point.value.toString().split('e');
        let decimal = mantissa;
        if (exponent) {
            const digits = mantissa.replace('.', ''), position = (mantissa.includes('.') ? mantissa.indexOf('.') : mantissa.length) + Number(exponent);
            decimal = position <= 0 ? '0.' + '0'.repeat(-position) + digits : position >= digits.length ? digits + '0'.repeat(position - digits.length) : digits.slice(0, position) + '.' + digits.slice(position);
        }
        return ` font-size="${decimal}"`;
    }
    const explicit = point?.context === 'musescore-explicit-unscaled-text' && size?.origin === 'source-property' && point.spatiumDependent.origin === 'source-property';
    const inherited = point?.context === 'musescore-source-style-unscaled-text' && ['source-property', 'source-style'].includes(size!.origin) && ['source-property', 'source-style'].includes(point.spatiumDependent.origin)
        && (size!.origin === 'source-style' || point.spatiumDependent.origin === 'source-style');
    if (point && (!explicit && !inherited && !(userCredit ? size!.origin === 'source-style' && point.context === 'musescore-3.6.1-user-text-style'
        : size!.origin === 'source-property' && ['musescore-3.3.4-default-text', 'musescore-3.6.2-text-line-default-text'].includes(point.context))
        || point.origin !== 'source-context' || point.spatiumDependent.value !== false || (!inherited && point.spatiumDependent.origin !== (explicit ? 'source-property' : 'source-style'))
        || !/^(?:\d+(?:\.\d*)?|\.\d+)$/.test(size!.rawValue.trim()) || Number(size!.rawValue.trim()) !== point.value
        || !Number.isFinite(point.value) || point.value <= 0 || point.value > 10_000 || point.value !== size!.value))
        refuse('writer-text-font-size', 'Point size requires the independently qualified unscaled source context and exact requested value.', size!.source);
    // Decimal source spelling avoids generated exponent notation.
    return point ? ` font-size="${size!.rawValue.trim()}"` : '';
}
export const ordinaryFamily = (value: string): boolean => !!value && value === value.trim() && value !== 'ScoreText' && !/[,\t\r\n\uE000-\uF8FF\u{F0000}-\u{FFFFD}\u{100000}-\u{10FFFD}]/u.test(value);

/** Standard print-style font attributes only. Color/visibility and unsupported
 * text decorations belong to the actual carrier and remain separate facts. */
export function plainTextFontXml(owner: Pick<Direction, 'textFontFamily' | 'textFontSize' | 'textFontStyle' | 'textEmphasis'>): string {
    const family = owner.textFontFamily, style = owner.textFontStyle;
    if (family && (!['source-property', 'source-style', 'native-default'].includes(family.origin) || typeof family.value !== 'string' || family.value.length > 65536
        || family.qualification && !['unverified-inline-context', 'unrepresentable-inline-reset'].includes(family.qualification))) refuse('writer-text-family', 'Unverified bounded source text family.', family.source);
    if (style && (!Number.isInteger(style.value) || style.value < 0 || style.value > 15 || !['source', 'source-style', 'native-default'].includes(style.origin))) refuse('writer-text-font-style', 'Uninterpreted native text emphasis bit field.', style.source);
    const flag = (name: 'bold' | 'italic', bit: number): boolean | undefined => {
        const fact = owner.textEmphasis?.[name];
        if (fact && typeof fact.value !== 'boolean') refuse('writer-text-emphasis', 'Text emphasis requires a source Boolean.', fact.source);
        return fact ? fact.value : style ? !!(style.value & bit) : undefined;
    };
    const bold = flag('bold', 1), italic = flag('italic', 2);
    return (family && !family.qualification && ordinaryFamily(family.value) ? ` font-family="${esc(family.value)}"` : '')
        + pointSizeXml(owner.textFontSize)
        + (bold === undefined ? '' : ` font-weight="${bold ? 'bold' : 'normal'}"`)
        + (italic === undefined ? '' : ` font-style="${italic ? 'italic' : 'normal'}"`);
}

/** Script placement is a readable derived layout, not native font-metric geometry.
 * The source formatter's exact .6 size ratio is applied after point conversion.
 * A normal reset is explicit because MusicXML sibling formatting carries forward.
 */
export function inlineTextFontXml(run: TextRun, base?: TextFontSize): string {
    const reset = run.lineFontSize;
    if (reset && (reset.origin !== 'derived-native-line-reset' || reset.request.pointSize && (reset.request.pointSize.context !== 'musescore-source-scaled-text' || reset.request.pointSize.scaling?.lineSpatiumDependent?.value !== false))) refuse('writer-line-font-size', 'Unverified native line size reset.', reset.source);
    const size = run.musicFontSize ?? reset?.request ?? run.textFontSize ?? base;
    const attrs = pointSizeXml(size), script = run.script;
    if (!script) return attrs;
    if (script.origin !== 'source-markup' || !['normal', 'super', 'sub'].includes(script.value)) refuse('writer-text-script', 'Unverified source script state.', script.source);
    const projection = script.projection;
    if (!projection) return attrs;
    if (projection.origin !== 'derived-readable-layout' || projection.relativeY !== (script.value === 'super' ? 6 : script.value === 'sub' ? -4 : 0)
        || projection.sizeFactor !== (script.value === 'normal' ? 1 : .6) || !size?.pointSize) refuse('writer-text-script', 'Unverified derived script presentation.', script.source);
    const decimal = (number: number): string => {
        const [mantissa, exponent] = String(number).split('e'); if (!exponent) return mantissa;
        const digits = mantissa.replace('.', ''), position = (mantissa.includes('.') ? mantissa.indexOf('.') : mantissa.length) + Number(exponent);
        return position <= 0 ? '0.' + '0'.repeat(-position) + digits : position >= digits.length ? digits + '0'.repeat(position - digits.length) : digits.slice(0, position) + '.' + digits.slice(position);
    };
    const scaled = attrs.replace(/font-size="[^"]+"/, `font-size="${decimal(size!.pointSize!.value * projection.sizeFactor)}"`);
    return scaled + ` relative-y="${projection.relativeY}"`;
}

/** Preserve typed note ownership while words carry formatting absent on fingering/pluck. */
export function fingeringNeedsWords(finger:FingeringFact):boolean {
    const mask=finger.textFontStyle?.value??0;
    // Centered alignment is the standard fingering drawing; only another
    // requested alignment needs the positioned words carrier.
    const align=finger.textAlignment, centered=!align||[align.halign,align.justify].every(v=>v===undefined||v==='center')&&[undefined,'middle'].includes(align.valign);
    return !!(finger.textRuns?.length || !centered || (finger.textEnclosure && finger.textEnclosure.value!=='none')
        || (finger.textEmphasis?.underline?.value??!!(mask&4)) || (finger.textEmphasis?.strike?.value??!!(mask&8)));
}

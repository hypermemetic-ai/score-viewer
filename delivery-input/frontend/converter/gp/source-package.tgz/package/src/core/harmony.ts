import type { ChordFrame, ChordHarmony, Direction, SourceColor } from './model.js';
import { refuse } from './report.js';
import { plainTextFontXml } from './text-font.js';
const esc = (s: string) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
const tag = (name: string, value: string | number) => `<${name}>${esc(String(value))}</${name}>`;
const kinds = new Set(['major', 'minor', 'augmented', 'diminished', 'dominant', 'major-seventh', 'minor-seventh', 'diminished-seventh', 'augmented-seventh', 'half-diminished', 'major-minor', 'major-sixth', 'minor-sixth', 'dominant-ninth', 'major-ninth', 'minor-ninth', 'dominant-11th', 'major-11th', 'minor-11th', 'dominant-13th', 'major-13th', 'minor-13th', 'suspended-second', 'suspended-fourth', 'Neapolitan', 'Italian', 'French', 'German', 'pedal', 'power', 'Tristan', 'other', 'none']);
function colorXml(color?: SourceColor): string {
    if (!color) return '';
    if (color.rgba.length !== 4 || color.rgba.some(channel => !Number.isInteger(channel) || channel < 0 || channel > 255)) return refuse('writer-harmony-color', 'Harmony color requires exact source RGBA.', color.source);
    return ` color="#${[color.rgba[3], ...color.rgba.slice(0, 3)].map(channel => channel.toString(16).padStart(2, '0')).join('').toUpperCase()}"`;
}
function frameXml(frame: ChordFrame): string {
    if (!Number.isSafeInteger(frame.strings) || frame.strings < 1 || frame.strings > 32 || !Number.isSafeInteger(frame.frets) || frame.frets < 1 || !frame.notes.length || frame.notes.length > 256 || frame.firstFret !== undefined && (!Number.isSafeInteger(frame.firstFret) || frame.firstFret < 1) || frame.unplayed !== undefined && !['', 'x'].includes(frame.unplayed))
        return refuse('writer-frame', 'Chord frame requires bounded strings, frets and explicit source positions.', frame.source);
    for (const marker of frame.markers ?? []) {
        if (!Number.isInteger(marker.string) || marker.string < 1 || marker.string > frame.strings || !['muted', 'open', 'none'].includes(marker.kind)) return refuse('writer-frame-marker', 'Unknown source frame-string marker.', marker.source);
        if (marker.kind === 'open' && !frame.notes.some(note => note.string === marker.string && note.fret === 0) || marker.kind === 'muted' && frame.notes.some(note => note.string === marker.string)) return refuse('writer-frame-marker', 'Source frame marker conflicts with its explicit note.', marker.source);
    }
    let content = tag('frame-strings' , frame.strings) + tag('frame-frets', frame.frets) + (frame.firstFret === undefined ? '' : tag('first-fret', frame.firstFret));
    const barres = new Map<number, number>();
    for (const note of frame.notes) {
        if (!Number.isSafeInteger(note.string) || note.string < 1 || note.string > frame.strings || !Number.isSafeInteger(note.fret) || note.fret < 0 || note.barre && !['start', 'stop'].includes(note.barre)) return refuse('writer-frame-note', 'Invalid source chord-frame note.', note.source);
        if (note.barre) barres.set(note.fret, (barres.get(note.fret) ?? 0) + (note.barre === 'start' ? 1 : -1));
        content += `<frame-note>${tag('string', note.string)}${tag('fret', note.fret)}${note.fingering ? `<fingering${note.fingeringVisible === false ? ' color="#00000000"' : ''}>${esc(note.fingering)}</fingering>` : ''}${note.barre ? `<barre type="${note.barre}"/>` : ''}</frame-note>`;
    }
    if ([...barres.values()].some(value => value !== 0)) return refuse('writer-frame-barre', 'Chord-frame barre endpoints must pair at the same fret.', frame.source);
    return `<frame${colorXml(frame.sourceColor)}${frame.unplayed !== undefined ? ` unplayed="${frame.unplayed}"` : ''}>${content}</frame>`;
}
export function harmonyXml(direction: Direction, offset: number): string {
    const style = direction.textFontStyle?.value ?? 0;
    const underline = direction.textEmphasis?.underline?.value ?? !!(style & 4);
    const strike = direction.textEmphasis?.strike?.value ?? !!(style & 8);
    const enclosure = direction.textEnclosure, alignment = direction.textAlignment;
    if (direction.printObject !== false && (underline || strike || enclosure && enclosure.value !== 'none' || alignment)) {
        const harmony = direction.harmony;
        if (!harmony) return refuse('writer-harmony', 'Missing source harmony.', direction.source);
        const label = harmony.role === 'literal-function' ? harmony.value : [harmony, ...(harmony.additional ?? [])].map(component => [component.value, ...(component.degrees ?? []).map(degree => `${degree.type === 'subtract' ? 'omit' : degree.type}${degree.alter === 0 ? '' : degree.alter === 1 ? '#' : degree.alter === -1 ? 'b' : `(${degree.alter})`}${degree.value}`)].filter(Boolean).join(' ')).join('\n');
        const attrs = plainTextFontXml(direction) + colorXml(direction.sourceColor)
            + ` underline="${underline ? 1 : 0}" line-through="${strike ? 1 : 0}"`
            + (enclosure ? ` enclosure="${enclosure.value}"` : '')
            + (alignment?.halign ? ` halign="${alignment.halign}"` : '')
            + (alignment?.valign ? ` valign="${alignment.valign}"` : '')
            + (alignment?.justify ? ` justify="${alignment.justify}"` : '');
        const words = `<direction${direction.placement ? ` placement="${direction.placement}"` : ''}><direction-type><words${attrs}>${esc(label)}</words></direction-type>${tag('offset', offset)}${direction.voiceId ? tag('voice', direction.voiceId) : ''}${tag('staff', direction.staff)}</direction>`;
        // Harmony's print-style lacks text-decoration/enclosure/alignment. Keep
        // tonal semantics as hidden standard harmony and show one styled label.
        return harmonyBodyXml({ ...direction, printObject: false }, offset) + words;
    }
    return harmonyBodyXml(direction, offset);
}
function harmonyBodyXml(direction: Direction, offset: number): string {
    const harmony = direction.harmony;
    if (!harmony) return refuse('writer-harmony', 'Missing source harmony.', direction.source);
    const font = plainTextFontXml(direction);
    const attributes = `${font}${colorXml(direction.sourceColor)}${direction.printObject === false ? ' print-object="no"' : ''}${direction.placement ? ` placement="${direction.placement}"` : ''}`;
    const ending = tag('offset', offset) + tag('staff', direction.staff);
    if (harmony.role === 'literal-function') {
        if (!/^[IVXivx]{1,16}$/.test(harmony.value.trim())) return refuse('writer-harmony', 'Unverified literal functional harmony projection.', harmony.source);
        return `<harmony${attributes}><function>${esc(harmony.value)}</function><kind>none</kind>${ending}</harmony>`;
    }
    if (harmony.role !== 'chord-symbol') return refuse('writer-harmony', 'Unknown source harmony role.', direction.source);
    const frame = harmony.frame ? frameXml(harmony.frame) : '';
    const frameVisibility = harmony.frame?.printObject === false ? ' print-frame="no"' : '';
    const separateFrame = !!frame && direction.printObject === false && harmony.frame?.printObject !== false;
    const frameInside = separateFrame ? '' : frame;
    const frameAfter = separateFrame ? `<harmony><function></function><kind text="">none</kind>${frame}${ending}</harmony>` : '';
    const muted = harmony.frame?.unplayed !== 'x' ? harmony.frame?.markers?.filter(marker => marker.kind === 'muted').map(marker => marker.string) ?? [] : [];
    const annotationWords = (harmony.annotations ?? []).map(annotation => `<direction><direction-type><words${annotation.printObject === false ? ' color="#00000000"' : colorXml(annotation.sourceColor)}>${esc(annotation.value)}</words></direction-type>${ending}</direction>`).join('');
    const markerWords = annotationWords + (muted.length && harmony.frame?.printObject !== false ? `<direction><direction-type><words${colorXml(harmony.frame?.sourceColor)}>${esc(`mute strings ${muted.join(', ')}`)}</words></direction-type>${ending}</direction>` : '');
    if (!harmony.root || !harmony.kind || harmony.additional?.some(component => !component.root || !component.kind)) {
        // Uninterpreted authored chord text is an ordinary words instruction; never invent its root or quality.
        const label = [harmony, ...(harmony.additional ?? [])].map(component => [component.value, ...(component.degrees ?? []).map(degree => `${degree.type === 'subtract' ? 'omit' : degree.type}${degree.alter === 0 ? '' : degree.alter === 1 ? '#' : degree.alter === -1 ? 'b' : `(${degree.alter})`}${degree.value}`)].filter(Boolean).join(' ')).join('\n');
        const words = label ? `<direction${direction.placement ? ` placement="${direction.placement}"` : ''}><direction-type><words${font}${direction.printObject === false ? ' color="#00000000"' : colorXml(direction.sourceColor)}>${esc(label)}</words></direction-type>${tag('offset', offset)}${direction.voiceId ? tag('voice', direction.voiceId) : ''}${tag('staff', direction.staff)}</direction>` : '';
        // MusicXML requires a harmony wrapper for a frame. kind=none explicitly makes its empty function semantically meaningless.
        return markerWords + words + (frameInside ? `<harmony${attributes}${frameVisibility}><function></function><kind text="">none</kind>${frameInside}${ending}</harmony>` : '') + frameAfter;
    }
    if (!kinds.has(harmony.kind)) return refuse('writer-harmony-kind', 'Unknown standard chord quality.', harmony.source);
    const tone = (name: 'root' | 'bass', pitch: { step: string; alter: number }) => {
        if (!/^[A-G]$/.test(pitch.step) || !Number.isFinite(pitch.alter) || Math.abs(pitch.alter) > 4) return refuse('writer-harmony-pitch', 'Chord pitch requires a source spelling and accidental.', harmony.source);
        const text = name === 'root' ? harmony.rootText : harmony.bassText;
        const printAlter = name === 'root' ? harmony.rootAlterPrintObject : harmony.bassAlterPrintObject;
        return `<${name}><${name}-step${text !== undefined ? ` text="${esc(text)}"` : ''}>${pitch.step}</${name}-step>${pitch.alter ? `<${name}-alter${printAlter === false ? ' print-object="no"' : ''}>${pitch.alter}</${name}-alter>` : ''}</${name}>`;
    };
    if (harmony.inversion !== undefined && (!Number.isSafeInteger(harmony.inversion) || harmony.inversion < 0)) return refuse('writer-harmony-inversion', 'Invalid chord inversion.', harmony.source);
    let content = tone('root', harmony.root) + `<kind${harmony.kindText !== undefined ? ` text="${esc(harmony.kindText)}"` : ''}>${harmony.kind}</kind>`;
    if (harmony.inversion !== undefined) content += tag('inversion', harmony.inversion);
    if (harmony.bass) content += tone('bass', harmony.bass);
    for (const degree of harmony.degrees ?? []) {
        if (!Number.isSafeInteger(degree.value) || degree.value < 1 || !Number.isFinite(degree.alter) || Math.abs(degree.alter) > 4 || !['add', 'alter', 'subtract'].includes(degree.type)) return refuse('writer-harmony-degree', 'Invalid source chord degree.', degree.source);
        content += `<degree>${tag('degree-value', degree.value)}${tag('degree-alter', degree.alter)}${tag('degree-type', degree.type)}</degree>`;
    }
    for (const additional of harmony.additional ?? []) {
        if (additional.frame || additional.additional?.length) return refuse('writer-harmony-stack', 'Stacked harmony components cannot contain nested frames or stacks.', additional.source);
        const component = harmonyBodyXml({ ...direction, harmony: additional }, 0);
        const match = /^<harmony[^>]*>([\s\S]*?)<offset>0<\/offset><staff>\d+<\/staff><\/harmony>$/.exec(component);
        if (!match) return refuse('writer-harmony-stack', 'Stacked harmony needs independently established tonal components.', additional.source);
        content += match[1];
    }
    return markerWords + `<harmony${attributes}${frameVisibility}>${content}${frameInside}${ending}</harmony>` + frameAfter;
}

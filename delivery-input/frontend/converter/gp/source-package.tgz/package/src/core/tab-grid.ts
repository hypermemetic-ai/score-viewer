import type { MusicalRelation, MusicalScore } from './model.js';
import { refuse } from './report.js';
import { compare } from './rational.js';

/** Generic bracket lines preserve grid edges without changing standard beam units. */
export function tabGridRelations(score:MusicalScore):{relations:MusicalRelation[];levels:Map<string,{index:number;count:number;serial:number}>} {
    const relations:MusicalRelation[]=[],levels=new Map<string,{index:number;count:number;serial:number}>();
    for(const part of score.parts) {
        const events=new Map(part.measures.flatMap((measure,mi)=>measure.voices.flatMap((voice,vi)=>voice.map(event=>[event.id,{event,mi,vi}] as const))));
        for(const [eventId,{event,mi,vi}] of events) {
            const grid=event.tabRhythm?.durationSymbol?.grid;if(!grid)continue;
            if(!Number.isInteger(grid.lines)||grid.lines<0||grid.lines>10)refuse('writer-tab-grid','TAB duration grid needs a bounded exact line count.',grid.source);
            if(!grid.lines||!grid.previous)continue;
            const previous=events.get(grid.previous.eventId??'');
            if(!previous||previous.vi!==vi||grid.previous.partId!==part.id||grid.previous.measure!==previous.mi||compare(grid.previous.position,previous.event.start)!==0||previous.mi>mi||previous.mi===mi&&compare(previous.event.start,event.start)>0)
                refuse('writer-tab-grid','TAB grid connection must resolve to its actual preceding source event.',grid.source);
            for(let index=1;index<=grid.lines;index++) {
                const id=`tab-grid:${part.id}:${eventId}:${index}`;
                relations.push({source:grid.source,id,kind:'text-line',line:'bracket',lineType:'solid',startHook:index===1?'down':'none',endHook:index===1?'down':'none',placement:{source:grid.source,value:'above'},
                    ...(event.printObject===false?{printObject:false}:{}),start:grid.previous,end:{partId:part.id,measure:mi,position:event.start,staff:event.staff??Math.floor(vi/4)+1,voiceId:event.voiceId??String(vi+1),eventId}});
                levels.set(id,{index,count:grid.lines,serial:levels.size+1});
            }
        }
    }
    return {relations,levels};
}

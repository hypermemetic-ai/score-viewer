import { plainTextFontXml, fingeringNeedsWords } from './text-font.js';
import type { BendFact, MusicalNote, NoteDetails, SourceColor, Pitch, MusicalPart, MusicalEvent } from './model.js';
import type { Location } from './report.js';
import { refuse } from './report.js';
import { add, compare, mul, q, type Rational } from './rational.js';
const esc = (s: string) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
function sourceColor(color?: SourceColor): string {
    if (!color) return '';
    if (color.rgba.length !== 4 || color.rgba.some(channel => !Number.isInteger(channel) || channel < 0 || channel > 255)) return refuse('writer-technique-color', 'Technique color needs exact source RGBA channels.', color.source);
    return ` color="#${[color.rgba[3], ...color.rgba.slice(0, 3)].map(channel => channel.toString(16).padStart(2, '0')).join('').toUpperCase()}"`;
}
const notation = (content: string, visible?: boolean) => `<notations${visible === false ? ' print-object="no"' : ''}>${content}</notations>`;
/** XML decimal has no exponent or rational spelling. Playback-only percentages may be omitted when inexact. */
function decimal(value: Rational, source: Location, optional = false): string | undefined {
    const r = q(value.n, value.d); let denominator = r.d;
    while (denominator % 2 === 0) denominator /= 2;
    while (denominator % 5 === 0) denominator /= 5;
    if (denominator !== 1) {
        if (optional) return undefined;
        return refuse('writer-bend-decimal', 'Bend amount has no finite exact MusicXML decimal representation.', source);
    }
    let n = BigInt(Math.abs(r.n)), d = BigInt(r.d), result = String(n / d); n %= d;
    if (n) { result += '.'; while (n) { n *= 10n; result += String(n / d); n %= d; } }
    return (r.n < 0 ? '-' : '') + result;
}
export function bendXml(bend: BendFact): string {
    const labelFonts=bend.labels?.map(label=>plainTextFontXml(label))??[];
    const font=labelFonts.length&&labelFonts.every(value=>value===labelFonts[0])?labelFonts[0]:'';
    if(bend.qualitative) {
        if(!bend.withBar || !['slack','release-from-slack'].includes(bend.qualitative.value) || bend.points.length) return refuse('writer-bend-qualitative','A qualitative bar instruction cannot invent a numerical slack curve.',bend.qualitative.source);
        return notation(`<technical><other-technical${sourceColor(bend.sourceColor)}>${bend.qualitative.value==='slack'?'whammy bar: slack':'release whammy bar from slack'}</other-technical></technical>`,bend.printObject);
    }
    if (!bend.points.length || bend.points.length > 1024) return refuse('writer-bend-points', 'Bend requires a bounded ordered source curve.', bend.source);
    if(bend.initialState && (bend.initialState.origin!=='preceding-bend' || compare(bend.initialState.semitones,bend.points[0].semitones)!==0 || Math.abs(bend.initialState.semitones.n/bend.initialState.semitones.d)>96))return refuse('writer-bend-state','A source continuation must begin at its established preceding displacement.',bend.initialState.source);
    let previous = bend.initialState?.semitones ?? q(0), previousOffset = q(0), content = '';
    for (let index = 0; index < bend.points.length; index++) {
        const point = bend.points[index], offset = q(point.offset.n, point.offset.d), semitones = q(point.semitones.n, point.semitones.d);
        if (compare(offset, q(0)) < 0 || compare(offset, q(1)) > 0 || compare(offset, previousOffset) < 0 || Math.abs(semitones.n / semitones.d) > 96)
            return refuse('writer-bend-points', 'Bend points require ordered normalized offsets and bounded semitone displacement.', point.source);
        const delta = add(semitones, q(-previous.n, previous.d));
        if (delta.n) {
            const preBend = !bend.initialState && index === 0 && offset.n === 0;
            const first = decimal(mul(previousOffset, q(100)), point.source, true), last = decimal(mul(offset, q(100)), point.source, true);
            const timing = !preBend && first !== undefined && last !== undefined ? ` first-beat="${first}" last-beat="${last}"` : '';
            const color = bend.sourceColor;
            if (color && (color.rgba.length !== 4 || color.rgba.some(channel => !Number.isInteger(channel) || channel < 0 || channel > 255))) return refuse('writer-bend-color', 'Bend color requires exact RGBA channels.', color.source);
            const colorAttribute = color ? ` color="#${[color.rgba[3], ...color.rgba.slice(0, 3)].map(channel => channel.toString(16).padStart(2, '0')).join('').toUpperCase()}"` : '';
            const crossing = previous.n * semitones.n < 0;
            const segments = crossing ? [{ amount: q(-previous.n, previous.d), release: true }, { amount: semitones, release: false }] : [{ amount: preBend ? q(-delta.n, delta.d) : delta, release: previous.n !== 0 && (previous.n > 0 ? delta.n < 0 : delta.n > 0) }];
            for (const segment of segments) content += `<bend${crossing ? '' : timing}${colorAttribute}${font}><bend-alter>${decimal(segment.amount, point.source)}</bend-alter>${preBend ? '<pre-bend/>' : segment.release ? '<release/>' : ''}${bend.withBar ? `<with-bar>${esc(bend.withBar.text ?? '')}</with-bar>` : ''}</bend>`;
        }
        previous = semitones; previousOffset = offset;
    }
    const vibratoPoints=bend.points.filter(point=>point.vibrato?.value);
    if(vibratoPoints.length) {
        for(const point of vibratoPoints)if(point.vibrato?.speed&&!['fast','average','slow'].includes(point.vibrato.speed))refuse('writer-bend-vibrato','Unknown source vibrato speed.',point.vibrato.source);
        const speeds=vibratoPoints.filter(point=>point.vibrato?.speed).map(point=>`${point.vibrato!.speed} at ${point.offset.n}/${point.offset.d} of curve`);
        content+=`<other-technical>${esc(speeds.length?`vibrato: ${speeds.join('; ')}`:'vibrato')}</other-technical>`;
    }
    return content ? notation(`<technical>${content}</technical>`, bend.printObject) : '';
}
/** Standard note-local performers' marks. Source pitch and clocks are never changed here. */
export function frettedTechniqueXml(note: MusicalNote, whammy?: BendFact): string {
    let result = (whammy ? bendXml(whammy) : '') + (note.bend ? bendXml(note.bend) : '') + (note.whammy ? bendXml(note.whammy) : '');
    if (note.hopoNotations?.length && (note.hopoStart || note.hopoStop)) refuse('writer-hopo-duplicate', 'H/P endpoints cannot use both legacy and located carriers.', note.source);
    for (const mark of note.hopoNotations ?? []) {
        if (!['start', 'stop'].includes(mark.type) || !['hammer-on', 'pull-off'].includes(mark.kind) || !Number.isInteger(mark.number) || mark.number < 1 || mark.number > 16) refuse('writer-hopo', 'Invalid source H/P endpoint.', mark.source);
        result += notation(`<technical><${mark.kind} type="${mark.type}" number="${mark.number}"${sourceColor(mark.sourceColor)}>${mark.type === 'start' ? esc(mark.text ?? (mark.kind === 'hammer-on' ? 'H' : 'P')) : ''}</${mark.kind}></technical>`, mark.printObject);
    }
    if (note.bendTransition) {
        const transition=note.bendTransition;
        if(note.bend || transition.origin!=='derived-source-pitches' || !transition.targetSource || Math.abs(transition.semitones.n/transition.semitones.d)>96) refuse('writer-bend-transition','A source endpoint bend must be distinct from a raw curve and retain its target provenance.',transition.source);
        result+=notation(`<technical><bend><bend-alter>${decimal(transition.semitones,transition.source)}</bend-alter></bend></technical>`);
    }
    if (note.trill) {
        const target = note.trill.target;
        if (target && (!/^[A-G]$/.test(target.step) || !Number.isInteger(target.octave) || !Number.isFinite(target.alter))) return refuse('writer-trill-target', 'Trill target requires established source pitch spelling.', note.trill.source);
        const accidental = target ? target.alter === 0 ? '' : target.alter === 1 ? '#' : target.alter === -1 ? 'b' : `(${target.alter > 0 ? '+' : ''}${target.alter})` : '';
        result += notation(`<ornaments><trill-mark/>${target ? `<other-ornament>${esc(`trill to ${target.step}${accidental}${target.octave}`)}</other-ornament>` : ''}</ornaments>`, note.trill.printObject);
    }
    const harmonic = note.harmonic;
    if (harmonic) {
        if (!['natural', 'artificial', 'pinch', 'tap', 'semi', 'feedback'].includes(harmonic.type) || harmonic.pitchRole && !['base', 'touching', 'sounding'].includes(harmonic.pitchRole))
            return refuse('writer-harmonic', 'Unknown source harmonic type or pitch role.', harmonic.source);
        const subtype = ['natural', 'artificial'].includes(harmonic.type) ? '' : `<other-technical>${esc(`${harmonic.type} harmonic`)}</other-technical>`;
        const role = harmonic.pitchRole ? `<${harmonic.pitchRole === 'touching' ? 'touching' : harmonic.pitchRole === 'sounding' ? 'sounding' : 'base'}-pitch/>` : '';
        result += notation(`<technical><harmonic>${harmonic.type === 'natural' || harmonic.type === 'artificial' ? `<${harmonic.type}/>` : ''}${role}</harmonic>${subtype}</technical>`, harmonic.printObject);
    }
    for (const gesture of note.gestures ?? []) {
        const labels: Record<NonNullable<NoteDetails['gestures']>[number]['kind'], string> = { 'vibrato': 'vibrato', 'wide-vibrato': 'wide vibrato', 'palm-mute': 'P.M.', 'let-ring': 'let ring', tap: 'tap', slap: 'slap', pop: 'pop', 'pick-scrape': 'pick scrape', whammy: 'whammy bar' };
        if (!Object.hasOwn(labels, gesture.kind) || gesture.hand && !['left', 'right'].includes(gesture.hand)) return refuse('writer-gesture', 'Unknown source playing gesture.', gesture.source);
        const color = sourceColor(gesture.sourceColor);
        const content = gesture.kind === 'tap' ? `<tap${color}${gesture.hand ? ` hand="${gesture.hand}"` : ''}>${esc(gesture.text ?? '')}</tap>` : `<other-technical${color}>${esc(gesture.text ?? labels[gesture.kind])}</other-technical>`;
        result += notation(`<technical>${content}</technical>`, gesture.printObject);
    }
    for (const finger of note.fingerings ?? []) {
        if (finger.hand && !['left', 'right'].includes(finger.hand) || !finger.value || finger.placement && !['above','below'].includes(finger.placement)) return refuse('writer-fingering', 'Located fingering requires a hand and source value.', finger.source);
        const element = finger.hand === 'right' ? 'pluck' : 'fingering';
        result += notation(`<technical><${element}${plainTextFontXml(finger)}${sourceColor(finger.sourceColor)}${finger.placement?` placement="${finger.placement}"`: ''}>${esc(finger.value)}</${element}></technical>`, fingeringNeedsWords(finger)?false:finger.printObject);
    }
    for (const slide of note.slides ?? []) {
        const elements: Partial<Record<typeof slide.kind, string>> = { 'into-from-below': 'scoop', 'into-from-above': 'plop', 'out-up': 'doit', 'out-down': 'falloff' };
        const element = elements[slide.kind];
        if (slide.lineShape && !['straight', 'curved'].includes(slide.lineShape) || slide.lineType && !['solid', 'wavy'].includes(slide.lineType)) return refuse('writer-slide-shape', 'Unknown source slide shape.', slide.source);
        if (element) result += notation(`<articulations><${element} line-shape="${slide.lineShape ?? 'straight'}"${slide.lineType ? ` line-type="${slide.lineType}"` : ''}${sourceColor(slide.sourceColor)}/></articulations>`, slide.printObject);
        else if (slide.kind === 'pick-slide-up' || slide.kind === 'pick-slide-down') result += notation(`<technical><other-technical>${slide.kind === 'pick-slide-up' ? 'pick slide up' : 'pick slide down'}</other-technical></technical>`, slide.printObject);
        else return refuse('writer-slide', 'Unknown source note-local slide.', slide.source);
    }
    return result;
}
/** Auxiliary exact facts supplement, never replace, standard musical notation. */
export function frettedTechniqueMetadata(note: MusicalNote, owner: string): { source: Location; name: string; value: string }[] {
    const facts: { source: Location; name: string; value: string }[] = [];
    for(const [index,finger] of (note.fingerings??[]).entries())if(fingeringNeedsWords(finger))facts.push({source:finger.source,name:`source-fingering:${owner}:${index+1}`,value:JSON.stringify(finger)});
    if(note.bendTransition) facts.push({source:note.bendTransition.source,name:`source-bend-transition:${owner}`,value:JSON.stringify(note.bendTransition)});
    if(note.whammy) facts.push({source:note.whammy.source,name:`source-whammy:${owner}`,value:JSON.stringify(note.whammy)});
    if (note.bend) facts.push({ source: note.bend.source, name: `source-bend:${owner}`, value: (note.bend.sourceCurve?.points??note.bend.points).map(p => `${p.offset.n}/${p.offset.d}:${p.semitones.n}/${p.semitones.d}${p.vibrato ? `:vibrato=${p.vibrato.value}${p.vibrato.speed?`:speed=${p.vibrato.speed}`:''}` : ''}`).join(';') });
    if(note.bend?.sourceCurve) facts.push({source:note.bend.sourceCurve.source,name:`derived-bend-segment:${owner}`,value:JSON.stringify({origin:note.bend.sourceCurve.origin,segment:note.bend.sourceCurve.segment,points:note.bend.points})});
    if (note.bend?.sourceBendType) facts.push({ source: note.bend.sourceBendType.source, name: `source-bend:${owner}:type`, value: note.bend.sourceBendType.value });
    if (note.bend?.sourceEndpoints) facts.push({ source: note.bend.source, name: `source-bend:${owner}:endpoints`, value: JSON.stringify(note.bend.sourceEndpoints) });
    if(note.bend?.initialState)facts.push({source:note.bend.initialState.source,name:`source-bend:${owner}:initial`,value:JSON.stringify(note.bend.initialState)});
    if(note.bend?.labels)facts.push({source:note.bend.source,name:`source-bend:${owner}:labels`,value:JSON.stringify(note.bend.labels)});
    for(const key of ['sourceHoldMode','sourceVibrato'] as const)if(note.bend?.[key])facts.push({source:note.bend[key]!.source,name:`source-bend:${owner}:${key}`,value:JSON.stringify(note.bend[key])});
    if (note.trill) { if (note.trill.fret !== undefined) facts.push({ source: note.trill.source, name: `source-trill:${owner}:fret`, value: String(note.trill.fret) }); if (note.trill.speed) facts.push({ source: note.trill.source, name: `source-trill:${owner}:speed`, value: note.trill.speed }); }
    if (note.harmonic) {
        for (const role of ['base', 'touch', 'result'] as const) { const pitch = note.harmonic[role]; if (pitch) facts.push({ source: note.harmonic.source, name: `source-harmonic:${owner}:${role}`, value: `${pitch.step}:${pitch.alter}:${pitch.octave}:${pitch.midi}` }); }
        const fret = note.harmonic.harmonicFret; if (fret) facts.push({ source: fret.source, name: `source-harmonic:${owner}:fret`, value: `${fret.value.n}/${fret.value.d}` });
    }
    return facts;
}

type Transpose = NonNullable<MusicalPart['transpose']>;
/** The standard transpose is written-to-sounding; role facts use physical/sounding register. */
function harmonicWrittenPitch(pitch: Pitch, transpose: Transpose): Pitch {
    const steps = 'CDEFGAB', natural = [0, 2, 4, 5, 7, 9, 11];
    const index = steps.indexOf(pitch.step) + pitch.octave * 7 - transpose.diatonic - (transpose.octaveChange ?? 0) * 7;
    const octave = Math.floor(index / 7), step = ((index % 7) + 7) % 7;
    const midi = pitch.midi - transpose.chromatic - (transpose.octaveChange ?? 0) * 12;
    return { step: steps[step], octave, alter: midi - (octave + 1) * 12 - natural[step], midi, origin: 'inferred' };
}
/** Resolve changes once in source-clock order, independently of voice serialization. */
export function harmonicTransposes(part: MusicalPart): ReadonlyMap<MusicalEvent, Transpose> {
    const result = new Map<MusicalEvent, Transpose>(), active = new Map<number, Transpose>();
    const initial: Transpose = { diatonic: part.transpose?.diatonic ?? 0, chromatic: part.transpose?.chromatic ?? 0, octaveChange: part.transpose?.octaveChange ?? part.transposeOctaves };
    for (const measure of part.measures) {
        const changes = (measure.changes ?? []).filter(change => change.transpose && !change.courtesy).sort((a, b) => compare(a.position, b.position));
        const events = measure.voices.flat().filter(event => event.notes.some(note => note.harmonic)).sort((a, b) => compare(a.start, b.start));
        let index = 0;
        for (const event of events) {
            while (index < changes.length && compare(changes[index].position, event.start) <= 0) { const change = changes[index++]; active.set(change.staff, change.transpose!); }
            result.set(event, active.get(event.staff ?? 1) ?? initial);
        }
        while (index < changes.length) { const change = changes[index++]; active.set(change.staff, change.transpose!); }
    }
    return result;
}
/** Additional established harmonic roles are standard silent chord components, never invented pitches. */
export function harmonicComponents(notes: MusicalNote[], transpose: Transpose = { diatonic: 0, chromatic: 0 }): MusicalNote[] {
    const companions: MusicalNote[] = [];
    for (const note of notes) {
        if (!note.harmonic || note.kind === 'unpitched') continue;
        const primaryRole = note.harmonic.pitchRole;
        const primary = primaryRole ? note.harmonic[primaryRole === 'touching' ? 'touch' : primaryRole === 'sounding' ? 'result' : 'base'] : undefined;
        // A known role on the authored note establishes the actual written view,
        // including concert display and source spelling, without confusing the
        // harmonic result interval with an instrument transposition.
        const steps = 'CDEFGAB';
        const localTranspose = primary ? {
            diatonic: steps.indexOf(primary.step) + primary.octave * 7 - steps.indexOf(note.written.step) - note.written.octave * 7,
            chromatic: primary.midi - note.written.midi,
        } : transpose;
        for (const [field, role] of [['base', 'base'], ['touch', 'touching'], ['result', 'sounding']] as const) {
            const pitch = note.harmonic[field];
            if (!pitch || role === note.harmonic.pitchRole) continue;
            if (!/^[A-G]$/.test(pitch.step) || !Number.isInteger(pitch.octave) || !Number.isFinite(pitch.alter) || !Number.isFinite(pitch.midi)) return refuse('writer-harmonic-pitch', 'Harmonic component requires established source pitch facts.', note.harmonic.source);
            const written = harmonicWrittenPitch(pitch, localTranspose);
            if (notes.some(candidate => candidate.kind !== 'unpitched' && candidate.harmonic?.pitchRole === role && Object.keys(candidate.harmonic.source).length === Object.keys(note.harmonic!.source).length && Object.entries(candidate.harmonic.source).every(([key, value]) => note.harmonic!.source[key as keyof typeof note.harmonic.source] === value) && candidate.written.step === written.step && candidate.written.alter === written.alter && candidate.written.octave === written.octave)) continue;
            companions.push({ source: note.harmonic.source, id: `${note.id}:harmonic-${role}`, kind: 'pitched', written, sounding: role === 'sounding' ? pitch : null,
                tieStart: false, tieStop: false, printObject: false,
                performance: { source: note.harmonic.source, play: false },
                harmonic: { source: note.harmonic.source, type: note.harmonic.type, pitchRole: role, printObject: false } });
        }
    }
    return [...notes, ...companions];
}

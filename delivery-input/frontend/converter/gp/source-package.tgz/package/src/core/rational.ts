import { refuse } from './report.js';
export interface Rational { n: number; d: number }
export function gcd(a: number, b: number): number {
    while (b) [a, b] = [b, a % b];
    return Math.abs(a);
}
export function q(n: number, d = 1): Rational {
    if (!Number.isSafeInteger(n) || !Number.isSafeInteger(d) || d <= 0)
        refuse('clock-budget', 'Exact rational arithmetic exceeds the proving profile budget.');
    const g = gcd(n, d);
    n /= g; d /= g;
    if (Math.abs(n) > 1e12 || d > 1e9) refuse('clock-budget', 'Exact rational arithmetic exceeds the proving profile budget.');
    return { n, d };
}
// The bounded canonical result, rather than a possibly much larger intermediate, owns the budget.
function exact(n: bigint, d: bigint): Rational {
    let a = n < 0n ? -n : n, b = d;
    while (b) [a, b] = [b, a % b];
    n /= a; d /= a;
    if (n < -1_000_000_000_000n || n > 1_000_000_000_000n || d > 1_000_000_000n)
        refuse('clock-budget', 'Exact rational arithmetic exceeds the proving profile budget.');
    return { n: Number(n), d: Number(d) };
}
export function add(a: Rational, b: Rational): Rational {
    const g = gcd(a.d, b.d), ad = a.d / g, bd = b.d / g;
    const x = a.n * bd, y = b.n * ad, d = ad * b.d;
    if (Number.isSafeInteger(x) && Number.isSafeInteger(y) && Number.isSafeInteger(x + y) && Number.isSafeInteger(d)) return q(x + y, d);
    return exact(BigInt(a.n) * BigInt(bd) + BigInt(b.n) * BigInt(ad), BigInt(ad) * BigInt(b.d));
}
export function mul(a: Rational, b: Rational): Rational {
    const g = gcd(a.n, b.d), h = gcd(b.n, a.d);
    const an = a.n / g, bn = b.n / h, ad = a.d / h, bd = b.d / g;
    const n = an * bn, d = ad * bd;
    if (Number.isSafeInteger(n) && Number.isSafeInteger(d)) return q(n, d);
    return exact(BigInt(an) * BigInt(bn), BigInt(ad) * BigInt(bd));
}
export function equal(a: Rational, b: Rational): boolean {
    const g = gcd(a.n, a.d), h = gcd(b.n, b.d);
    return a.n / g === b.n / h && a.d / g === b.d / h;
}
export function compare(a: Rational, b: Rational): number {
    const x = a.n * b.d, y = b.n * a.d;
    if (Number.isSafeInteger(x) && Number.isSafeInteger(y)) return x < y ? -1 : x > y ? 1 : 0;
    const difference = BigInt(a.n) * BigInt(b.d) - BigInt(b.n) * BigInt(a.d);
    return difference < 0n ? -1 : difference > 0n ? 1 : 0;
}
export function decimal(s: string): Rational {
    if (!/^\d{1,4}(?:\.\d{1,6})?$/.test(s)) refuse('number', 'Expected a bounded nonnegative decimal.');
    const [whole, fraction = ''] = s.split('.');
    return q(Number(whole + fraction), 10 ** fraction.length);
}
export function divisions(clocks: Rational[]): number {
    let d = 1;
    for (const c of clocks) {
        d = d / gcd(d, c.d) * c.d;
        if (d > 65536) refuse('divisions-budget', 'Exact MusicXML divisions exceed 65536; timing will not be rounded.');
    }
    return d;
}

/** Standard base64/UTF-8 helpers with identical output on Node and WebView hosts. */
type NativeBase64 = { toBase64?: (this: Uint8Array) => string };
type NativeBase64Decode = { fromBase64?: (text: string) => Uint8Array };

export function encodeBase64(bytes: Uint8Array): string {
    const native = (Uint8Array.prototype as NativeBase64).toBase64;
    if (typeof native === 'function') return native.call(bytes);
    // A multiple of three keeps every chunk free of interior padding.
    const parts: string[] = [];
    for (let at = 0; at < bytes.length; at += 24576) parts.push(btoa(String.fromCharCode.apply(null, bytes.subarray(at, at + 24576) as unknown as number[])));
    return parts.join('');
}
export function decodeBase64(text: string): Uint8Array {
    const native = (Uint8Array as NativeBase64Decode).fromBase64;
    if (typeof native === 'function') return native(text);
    const binary = atob(text), bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
}
/** UTF-8 byte length of well-formed text; a lone surrogate counts as its three-byte replacement. */
export function utf8ByteLength(text: string): number {
    let bytes = 0;
    for (let i = 0; i < text.length; i++) {
        const c = text.charCodeAt(i);
        if (c >= 0xD800 && c <= 0xDBFF && i + 1 < text.length && text.charCodeAt(i + 1) >= 0xDC00 && text.charCodeAt(i + 1) <= 0xDFFF) { bytes += 4; i++; }
        else bytes += c < 0x80 ? 1 : c < 0x800 ? 2 : 3;
    }
    return bytes;
}

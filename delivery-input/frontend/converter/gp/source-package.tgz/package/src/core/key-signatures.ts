import type {KeySignature} from './model.js';
import {refuse} from './report.js';
import {canonicalSymbolVocabulary} from './canonical-symbols.js';
const esc=(s:string)=>s.replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;');
const tag=(name:string,value:string|number)=>`<${name}>${esc(String(value))}</${name}>`;
const color=(key:KeySignature,hidden=false)=>{const rgba=key.sourceColor?.rgba;if(rgba&&rgba.some(v=>!Number.isInteger(v)||v<0||v>255))refuse('writer-key-color','Key color requires source byte channels.',key.sourceColor!.source);return hidden?' color="#00000000"':rgba?` color="#${[rgba[3],...rgba.slice(0,3)].map(n=>n.toString(16).padStart(2,'0')).join('').toUpperCase()}"`:'';};
export function keySignatureXml(key:KeySignature,staff?:number,hidden=false):string {
 let content:string;
 if(key.customTones){
  content=key.customTones.map(t=>{if(!/^[A-G]$/.test(t.step)||!Number.isFinite(t.alter)||Math.abs(t.alter)>16||t.smufl&&!canonicalSymbolVocabulary.has(t.smufl.name))refuse('writer-custom-key','Unqualified source custom key tone.',t.source);return tag('key-step',t.step)+tag('key-alter',t.alter)+`<key-accidental${t.smufl?` smufl="${esc(t.smufl.name)}"`:''}>${esc(t.accidental)}</key-accidental>`;}).join('');
  for(const [index,t] of key.customTones.entries())if(t.octave!==undefined){if(!Number.isInteger(t.octave)||t.octave<0||t.octave>9)refuse('writer-custom-key','Standard key octave must be between zero and nine.',t.source);content+=`<key-octave number="${index+1}">${t.octave}</key-octave>`;}
 }else content=tag('fifths',key.fifths)+(key.mode?tag('mode',key.mode):'');
 return `<key${staff?` number="${staff}"`:''}${hidden||key.printObject===false||key.customProjection?' print-object="no"':''}${color(key)}>${content}</key>`;
}
/** An exact component sequence cannot fit one key-accidental. Keep the semantic
 * signature hidden and give its source spelling as a readable staff instruction. */
export function keyInstructionXml(key:KeySignature,staff:number):string {
 if(!key.customProjection)return '';
 const appearance=color(key,key.printObject===false),words=(text:string)=>`<direction-type><words${appearance}>${esc(text)}</words></direction-type>`;
 const standard:Record<string,string>={sharp:'accidentalSharp',flat:'accidentalFlat',natural:'accidentalNatural','double-sharp':'accidentalDoubleSharp','flat-flat':'accidentalDoubleFlat','natural-sharp':'accidentalNaturalSharp','natural-flat':'accidentalNaturalFlat'};
 let content=words('Key signature: ');
 for(const [index,tone] of (key.customTones??[]).entries()){
  content+=words(`${index?'; ':''}${tone.step}${tone.octave??''} `);
  for(const component of tone.components??[{source:tone.source,name:tone.smufl?.name??standard[tone.accidental]}]){
   if(!canonicalSymbolVocabulary.has(component.name))refuse('writer-custom-key-component','Key instruction needs an exact canonical accidental symbol.',component.source);
   content+=`<direction-type><symbol${appearance}>${esc(component.name)}</symbol></direction-type>`;
  }
 }
 return `<direction placement="above">${content}${tag('staff',staff)}</direction>`;
}

/** XML 1.0 permits these Unicode scalars, independently of any musical meaning. */
export function xmlCharacter(code: number): string | undefined {
    return Number.isInteger(code) && (code === 9 || code === 10 || code === 13 || code >= 0x20 && code <= 0xd7ff || code >= 0xe000 && code <= 0xfffd || code >= 0x10000 && code <= 0x10ffff)
        ? String.fromCodePoint(code) : undefined;
}
/** MusicXML font-family is a comma-separated list, so a literal comma is ambiguous. */
export function literalFontFamily(value: string): boolean {
    return !!value && !/[,\x00-\x1f\x7f]/.test(value);
}

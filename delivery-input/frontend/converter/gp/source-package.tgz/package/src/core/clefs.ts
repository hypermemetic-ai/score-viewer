/** Standard pitch meaning, independent of native clef glyph contours. */
export interface StandardClef {
    sign:'G'|'F'|'C'|'TAB'|'percussion'; line?:number; octaveChange?:number;
    sourceGlyph?:string; appearanceVariant?:boolean;
}
const aliases:Readonly<Record<string,readonly[string,string]>>={
    G8vbo:['G8vb','gClef8vbOld'],G8vbc:['G8vb','gClef8vbCClef'],G8vbp:['G','gClef8vbParens'],
    C_19C:['G','cClefSquare'],
    C1_F18C:['C1','cClefFrench'],C3_F18C:['C3','cClefFrench'],C4_F18C:['C4','cClefFrench'],
    C1_F20C:['C1','cClefFrench20C'],C3_F20C:['C3','cClefFrench20C'],C4_F20C:['C4','cClefFrench20C'],
    F_F18C:['F','fClefFrench'],F_19C:['F','fClef19thCentury'],C4_8VB:['C48vb','cClef8vb'],
    PERC2:['PERC','unpitchedPercussionClef2'],TAB4:['TAB','fourStringTabClef'],TAB2:['TAB','sixStringTabClefSerif'],TAB4_SERIF:['TAB','fourStringTabClefSerif'],
};
export function standardClef(token:string):StandardClef|undefined {
    const alias=Object.hasOwn(aliases,token)?aliases[token]:undefined,canonical=alias?.[0]??token;
    let result:StandardClef;
    if(canonical==='TAB')result={sign:'TAB'};
    else if(canonical==='PERC')result={sign:'percussion'};
    else {
        const match=/^([GFC])([1-5])?(8va|8vb|15ma|15mb)?$/.exec(canonical);if(!match)return undefined;
        const sign=match[1] as 'G'|'F'|'C',line=match[2]?Number(match[2]):sign==='G'?2:sign==='F'?4:3;
        const octaveChange=match[3]?({'8va':1,'8vb':-1,'15ma':2,'15mb':-2} as const)[match[3] as '8va'|'8vb'|'15ma'|'15mb']:undefined;
        result={sign,line,...(octaveChange?{octaveChange}:{})};
    }
    if(alias){result.sourceGlyph=alias[1];result.appearanceVariant=token!=='C4_8VB';}
    return result;
}

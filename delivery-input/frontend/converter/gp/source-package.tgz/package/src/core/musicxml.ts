import {keySignatureXml,keyInstructionXml} from './key-signatures.js';
import { standardClef } from './clefs.js';
import { tabGridRelations } from './tab-grid.js';
import { canonicalSymbolVocabulary } from './canonical-symbols.js';
import { ordinaryFamily, pointSizeXml, inlineTextFontXml, plainTextFontXml, fingeringNeedsWords } from './text-font.js';
import { harmonyXml } from './harmony.js';
import { bendXml, frettedTechniqueXml, frettedTechniqueMetadata, harmonicComponents, harmonicTransposes } from './fretted-techniques.js';
import type { MusicalScore, MusicalEvent, MusicalRelation, Pitch, StaffFact, StaffChange, Direction, TextRun, NoteDetails, OrnamentDetails, MarkAnchor, SourceColor, FrettedCapo, GlyphFact } from './model.js';
import { xmlCharacter, literalFontFamily } from './font-character.js';
import { divisions, add, compare, q, type Rational } from './rational.js';
import { refuse } from './report.js';
import { symbolVocabulary, textRunSymbolVocabulary, techniqueGlyphNames } from './symbols.js';
const esc = (s: string) => s.replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;').replaceAll('"', '&quot;');
const tag = (name: string, value: string | number) => `<${name}>${esc(String(value))}</${name}>`;
const meterXml = (time: MusicalScore['parts'][number]['measures'][number]['time'], staff?: number) => `<time${staff ? ` number="${staff}"` : ''}${!time.senzaMisura && time.symbol ? ` symbol="${time.symbol}"` : ''}${time.printObject === false ? ' print-object="no"' : ''}>${time.senzaMisura ? tag('senza-misura', time.senzaMisura.text ?? '') : tag('beats', time.textBeats ?? time.beats) + tag('beat-type', time.textUnit ?? time.unit)}</time>`;
const sameMeter = (a: MusicalScore['parts'][number]['measures'][number]['time'], b: typeof a) => a.beats === b.beats && a.unit === b.unit && a.symbol === b.symbol && a.textBeats === b.textBeats && a.textUnit === b.textUnit && a.printObject === b.printObject && !!a.senzaMisura === !!b.senzaMisura && a.senzaMisura?.text === b.senzaMisura?.text;
const articulationVocabulary = new Set(['accent', 'strong-accent', 'soft-accent', 'staccato', 'tenuto', 'detached-legato', 'staccatissimo', 'spiccato', 'scoop', 'plop', 'doit', 'falloff', 'breath-mark', 'caesura', 'stress', 'unstress']);
const accidentalVocabulary = new Set(['sharp', 'flat', 'natural', 'double-sharp', 'flat-flat', 'natural-sharp', 'natural-flat', 'other']);
const noteheadVocabulary = new Set(['slash', 'triangle', 'diamond', 'square', 'cross', 'x', 'circle-x', 'inverted triangle', 'arrow down', 'arrow up', 'circled', 'slashed', 'back slashed', 'normal', 'cluster', 'circle dot', 'left triangle', 'rectangle', 'none', 'do', 're', 'mi', 'fa', 'fa up', 'so', 'la', 'ti', 'other']);
function ornamentSound(details?: OrnamentDetails): string {
    const interval=details?.intervalAbove;if(!interval||interval.active===false)return '';
    if(interval.step==='unison'&&interval.quality==='perfect')return ' trill-step="unison"';
    return interval.step==='second'&&['major','minor'].includes(interval.quality)?` trill-step="${interval.quality==='major'?'whole':'half'}"`:'';
}
function ornamentIntervals(details?: OrnamentDetails): string {
    return ([['upper',details?.intervalAbove],['lower',details?.intervalBelow]] as const).map(([side,interval])=>{
        if(!interval||interval.active===false)return '';
        if(!['unison','second','third','fourth','fifth','sixth','seventh','octave'].includes(interval.step)||!['auto','diminished','minor','major','perfect','augmented'].includes(interval.quality))refuse('writer-ornament-interval','Unqualified source ornament interval.',interval.source);
        const text=`${side} auxiliary: ${interval.quality==='auto'?'diatonic':interval.quality} ${interval.step}${interval.quality==='auto'?' (active accidentals)':''}`;
        return `<other-ornament>${esc(text)}</other-ornament>`;
    }).join('');
}
const glyphPointSize = (size: GlyphFact['fontSize']): string | undefined => {
        if (size && (size.origin !== 'source-staff-space' || ![size.points,size.millimeters,size.staffFactor,size.multiplier].every(x=>Number.isFinite(x)&&x>0) || size.points>10000 || size.points!==4*size.millimeters*size.staffFactor*72/25.4*size.multiplier)) refuse('writer-symbol-size','Glyph point size must retain its qualified four-spatium source em.',size.source);
        if(size?.sourceSpace && (size.sourceSpace.scoreSpatium.millimeters!==size.millimeters || size.sourceSpace.staff.factor!==size.staffFactor)) refuse('writer-symbol-size','Glyph size and source staff-space authority disagree.',size.source);
        let pointText=size?.points.toString();
        if(pointText?.includes('e')) {
            const [mantissa,exponent]=pointText.split('e'),digits=mantissa.replace('.',''),position=(mantissa.includes('.')?mantissa.indexOf('.'):mantissa.length)+Number(exponent);
            pointText=position<=0?'0.'+'0'.repeat(-position)+digits:position>=digits.length?digits+'0'.repeat(position-digits.length):digits.slice(0,position)+'.'+digits.slice(position);
        }
        return pointText;
    };
function accidentalSmuflXml(smufl:{source:import('./report.js').Location;name:string}|undefined,name:string):string {
    if(smufl&&(!canonicalSymbolVocabulary.has(smufl.name)||! /^(accidental|accSagittal)/.test(smufl.name)))refuse('writer-accidental-smufl','Accidental glyph needs a canonical accidental identity.',smufl.source);
    if(name==='other'&&!smufl)refuse('writer-accidental-smufl','An other accidental requires its exact standard glyph.');
    return smufl?` smufl="${esc(smufl.name)}"`:'';
}
function accidentalColorXml(color:SourceColor|undefined,visible=true):string {
    if(!color)return visible?'':' color="#00000000"';
    if(color.rgba.length!==4||color.rgba.some(v=>!Number.isInteger(v)||v<0||v>255))refuse('writer-color','Accidental color requires four byte channels.',color.source);
    const [r,g,b,a]=color.rgba;return ` color="#${[visible?a:0,r,g,b].map(v=>v.toString(16).padStart(2,'0').toUpperCase()).join('')}"`;
}
function ornamentAccidentalXml(accidental: NonNullable<OrnamentDetails['accidentals']>[number]): string {
    if(accidental.sourceName==='noSym'&&accidental.name==='other'&&!accidental.smufl)return '';

    if (!accidentalVocabulary.has(accidental.name) || !['above', 'below'].includes(accidental.placement)) refuse('writer-ornament-accidental', 'Unsupported ornament accidental.', accidental.source);
    return `<accidental-mark placement="${accidental.placement}"${accidentalSmuflXml(accidental.smufl,accidental.name)}${accidentalColorXml(accidental.sourceColor,accidental.printObject!==false)}${accidental.fontSize?` font-size="${glyphPointSize(accidental.fontSize)}"`: ''}>${esc(accidental.name)}</accidental-mark>`;
}
function pitchXml(p: Pitch, cents=0): string { if(!Number.isFinite(cents))refuse('writer-cent-offset','Pitch cent offset must be finite.');const alter=p.alter+cents/100;return tag('step', p.step) + (alter ? tag('alter', alter) : '') + tag('octave', p.octave); }
function capoXml(capo?: FrettedCapo): string {
    if (!capo) return '';
    if (!Number.isSafeInteger(capo.fret) || capo.fret < 0) refuse('writer-capo', 'Full capo requires a source-qualified nonnegative safe integer fret.', capo.source);
    return tag('capo', capo.fret);
}
/** Source tuning supplies MIDI pitches, not spelling; use a reported sharp reference spelling. */
function tuningXml(midi: number): string {
    const [step, alter] = ([['C', 0], ['C', 1], ['D', 0], ['D', 1], ['E', 0], ['F', 0],
        ['F', 1], ['G', 0], ['G', 1], ['A', 0], ['A', 1], ['B', 0]] as const)[midi % 12];
    return tag('tuning-step', step) + (alter ? tag('tuning-alter', alter) : '') + tag('tuning-octave', Math.floor(midi / 12) - 1);
}
/** MusicXML octave is 0..9. Keep lower MIDI tuning exact as words and auxiliary data. */
function tuningEntries(tuning: number[], upsideDown = false): string {
    if (!tuning.length || tuning.length > 32 || tuning.some(midi => !Number.isInteger(midi) || midi < 0 || midi > 127)) refuse('writer-tuning', 'Tuning needs one through32 explicit MIDI pitches.');
    return tuning.map((midi,index)=>midi<12?'':`<staff-tuning line="${upsideDown ? tuning.length-index : index+1}">${tuningXml(midi)}</staff-tuning>`).join('');
}
function tuningFallback(tuning: number[]): string | undefined {
    if (!tuning.some(midi=>midi<12)) return undefined;
    const names=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
    return 'Open strings (string 1 first): '+[...tuning].reverse().map(midi=>`${names[midi%12]}${Math.floor(midi/12)-1} (MIDI ${midi})`).join(', ')+'.';
}
/** Plain MusicXML 4.0 partwise; no mandatory private musical elements. */
export function writeMusicXml(score: MusicalScore, display = { hideDynamics: false, hideTempo: false }, onPartAssigned?: (sourcePartId: string, musicxmlPartId: string) => void, limits?: { outputBytes: number }): string {
    const grids=tabGridRelations(score), relations=[...(score.relations??[]),...grids.relations];
    const partIds = score.parts.map((part, index) => { const id = `P${index + 1}`; onPartAssigned?.(part.id, id); return id; });
    const clocks: Rational[] = [];
    for (const p of score.parts) for (const m of p.measures) {
        clocks.push(m.duration);
        for (const v of m.voices) for (const e of v) { clocks.push(e.start, e.duration); for (const figure of e.figuredBass ?? []) clocks.push(figure.position, figure.duration, figure.projection.offset); for (const n of e.notes) { if (n.attack) clocks.push(n.attack); if (n.release) clocks.push(n.release); } }
        for (const direction of m.directions ?? []) clocks.push(direction.position);
        for (const change of m.changes ?? []) clocks.push(change.position);
        for (const barline of m.barlines ?? []) clocks.push(barline.position);
    }
    for (const p of score.parts) for (const capo of p.capoChanges ?? []) clocks.push(capo.position);
    for (const t of score.tempos) clocks.push(t.position);
    for (const r of relations) clocks.push(r.start.position, r.end.position);
    for(const image of score.sourceImages??[])if(image.attachment)clocks.push(image.attachment.position);
    const d = divisions(clocks);
    const ticks = (r: Rational) => {
        const n = r.n * (d / r.d);
        if (!Number.isSafeInteger(n)) refuse('writer-clock', 'Unable to represent exact clock in MusicXML.');
        return n;
    };
    const clefXml = (staff: StaffFact, afterBarline = false): string => {
        const c=standardClef(staff.clef);
        if (!c) return refuse('writer-clef', `Unsupported clef ${staff.clef}.`, staff.source);
        return `<clef number="${staff.number}"${staff.clefPrintObject === false ? ' print-object="no"' : ''}${afterBarline ? ' after-barline="yes"' : ''}>${tag('sign', c.sign)}${c.line ? tag('line', c.line) : ''}${c.octaveChange ? tag('clef-octave-change', c.octaveChange) : ''}</clef>`;
    };
    const anchorXml = (anchor?: MarkAnchor): string => {
        if (anchor && !['above', 'below', 'auto'].includes(anchor.placement)) refuse('writer-mark-anchor', 'Unverified source mark placement.', anchor.source);
        return anchor && anchor.placement !== 'auto' ? ` placement="${anchor.placement}"` : '';
    };
    const strongAccentType = (direction?: 'auto' | 'up' | 'down', anchor?: MarkAnchor): string => direction && direction !== 'auto' ? ` type="${direction}"` : anchor && anchor.placement !== 'auto' ? ` type="${anchor.placement === 'above' ? 'up' : 'down'}"` : '';
    const articulationsXml = (names: string[], source: MusicalEvent['source'], directions?: MusicalEvent['strongAccentDirections'], anchors?: MusicalEvent['articulationAnchors']): string => {
        const byIndex = new Map<number, 'auto' | 'up' | 'down'>();
        const anchorByIndex = new Map<number, MarkAnchor>();
        for (const entry of anchors ?? []) { if (!Number.isInteger(entry.index) || !names[entry.index] || anchorByIndex.has(entry.index)) refuse('writer-mark-anchor', 'Ambiguous source articulation anchor ownership.', entry.anchor.source); anchorByIndex.set(entry.index, entry.anchor); }
        for (const direction of directions ?? []) {
            if (!Number.isInteger(direction.index) || names[direction.index] !== 'strong-accent' || byIndex.has(direction.index) || !['auto', 'up', 'down'].includes(direction.value)) refuse('writer-articulation-direction', 'Unverified strong-accent direction ownership.', direction.source);
            byIndex.set(direction.index, direction.value);
        }
        return `<articulations>${names.map((name, index) => {
            if (!articulationVocabulary.has(name)) refuse('writer-articulation', `Unsupported articulation ${name}.`, source);
            const direction = byIndex.get(index);
            const anchor = anchorByIndex.get(index);
            return `<${name}${name === 'strong-accent' ? strongAccentType(direction, anchor) : ''}${anchorXml(anchor)}/>`;
        }).join('')}</articulations>`;
    };
    const colorXml = (color: SourceColor | undefined, visible: boolean): string => {
        if (!color) return visible ? '' : ' color="#00000000"';
        if (color.rgba.length !== 4 || color.rgba.some(value => !Number.isInteger(value) || value < 0 || value > 255))
            refuse('writer-color', 'Source color requires exactly four integer channels from 0 through 255.', color.source);
        const [r, g, b, a] = color.rgba;
        return ` color="#${[visible ? a : 0, r, g, b].map(value => value.toString(16).padStart(2, '0').toUpperCase()).join('')}"`;
    };
    const rotatedGlyph = (glyph: GlyphFact): boolean => !!glyph.rotation?.degrees && canonicalSymbolVocabulary.has(glyph.name) && glyph.projection !== 'notehead-parenthesis';
    const glyphXml = (glyph: GlyphFact, role: 'direction' | 'notation', inheritedColor?: SourceColor, visible = true): string => {
        if(glyph.projection==='font-character') {
            const character=glyph.fontCharacter;
            if(!character)return refuse('writer-font-character','Missing source font character.',glyph.source);
            if(glyph.name!=='FSymbol'||glyph.fontSize||glyph.rotation||!Number.isInteger(character.code)||character.code< -2147483648||character.code>2147483647
                ||!['source-property','native-default'].includes(character.origin)||character.origin==='native-default'&&character.code!==0||character.text!==xmlCharacter(character.code))refuse('writer-font-character','Font character must retain its exact source code without inferred glyph meaning.',glyph.source);
            const size=character.pointSize;
            if(size&&(!/^-?\d{1,6}(?:\.\d{1,20})?$/.test(size.rawValue)||Number(size.rawValue)!==size.value||!Number.isFinite(size.value)||Math.abs(size.value)>10000))refuse('writer-font-character-size','Font character point size must match its exact source field.',size.source);
            const font=glyph.sourceFont;
            if(font&&(typeof font.value!=='string'||font.value.length>256))refuse('writer-font-character-family','Font character family must retain its bounded source label.',font.source);
            const shown=visible&&glyph.printObject!==false&&character.text!==undefined;
            const appearance=colorXml(glyph.sourceColor??inheritedColor,shown)+(font&&literalFontFamily(font.value)?` font-family="${esc(font.value)}"`:'')+(size&&size.value>0?` font-size="${size.rawValue}"`:'');
            const text=character.text===undefined?`U+${(character.code>>>0).toString(16).toUpperCase().padStart(4,'0')}`:esc(character.text).replace(/\r/g,'&#13;');
            return role==='direction'?`<words${appearance}>${text}</words>`:`<other-notation type="single"${shown?'':' print-object="no"'}${appearance}>${text}</other-notation>`;
        }
        if(glyph.fontCharacter)refuse('writer-font-character','Font character facts require their explicit source projection.',glyph.source);
        if (glyph.projection && !['source-name','empty','notehead-parenthesis'].includes(glyph.projection)) refuse('writer-symbol','Unknown source glyph projection.',glyph.source);
        if (!glyph.name || glyph.name.length > 256 || !['source-name','empty'].includes(glyph.projection ?? '') && !canonicalSymbolVocabulary.has(glyph.name)) refuse('writer-symbol','Unverified standard direction glyph or note/rest glyph.',glyph.source);
        if (glyph.projection === 'empty' && glyph.name !== 'noSym' || glyph.projection === 'source-name' && canonicalSymbolVocabulary.has(glyph.name)) refuse('writer-symbol','Contradictory native glyph projection.',glyph.source);
        const size = glyph.fontSize, pointText = glyphPointSize(size);
        if (glyph.rotation && (!Number.isFinite(glyph.rotation.degrees) || glyph.rotation.degrees < -180 || glyph.rotation.degrees > 180)) refuse('writer-symbol-rotation','Glyph rotation must be a finite standard degree value.',glyph.rotation.source);
        const shown = visible && glyph.printObject !== false && glyph.projection !== 'empty';
        const appearance = colorXml(glyph.sourceColor ?? inheritedColor,shown)+(size ? ` font-size="${pointText}"` : '');
        if (role === 'direction' && !['source-name','empty'].includes(glyph.projection ?? '')) return `<symbol${appearance}${glyph.rotation ? ` rotation="${glyph.rotation.degrees}"` : ''}>${esc(glyph.name)}</symbol>`;
        const name = role === 'direction' ? 'other-direction' : 'other-notation';
        const open = `<${name}${role === 'notation' ? ' type="single"' : ''}${shown ? '' : ' print-object="no"'}${appearance}${!glyph.projection || glyph.projection === 'notehead-parenthesis' ? ` smufl="${esc(glyph.name)}"` : ''}`;
        return ['source-name','empty'].includes(glyph.projection ?? '') ? `${open}>${esc(glyph.name)}</${name}>` : `${open}/>`;
    };
    const textResetMask = (run: NonNullable<Direction['textRuns']>[number]): number => {
        const resets = run.emphasisResets ?? []; let mask = 0;
        if (resets.length > 4) refuse('writer-text-reset', 'Too many independently located text emphasis resets.', run.source);
        for (const reset of resets) {
            if (![1, 2, 4, 8].includes(reset.bit) || mask & reset.bit || run.emphasis & reset.bit) refuse('writer-text-reset', 'Ambiguous source text emphasis reset.', reset.source);
            mask |= reset.bit;
        }
        return mask;
    };
    const familyPlan = (owner: Direction['textFontFamily'], runs?: Direction['textRuns']): { base?: string; values?: (string | undefined)[] } => {
        if (owner && (!['source-property', 'source-style', 'native-default'].includes(owner.origin) || typeof owner.value !== 'string' || owner.value.length > 65536
            || owner.qualification && !['unverified-inline-context', 'unrepresentable-inline-reset'].includes(owner.qualification))) refuse('writer-text-family', 'Unverified bounded source text family.', owner.source);
        const base = owner && !owner.qualification && ordinaryFamily(owner.value) ? owner.value : undefined;
        if (!runs) return { base };
        let introduced = !!base, unsafeReset = false;
        const values = runs.map(run => {
            const font = run.sourceFont;
            if (font && (font.origin !== 'source-markup' || typeof font.face !== 'string' || font.face.length > 65536 || font.role && font.role !== 'ordinary-family' || font.qualification && font.qualification !== 'ambiguous-properties')) refuse('writer-text-family', 'Unverified bounded inline font context.', font.source);
            // Source selector/ambiguous context cannot inherit an ordinary hint.
            const value = run.symbolName ? undefined : font ? font.role === 'ordinary-family' && !font.qualification && ordinaryFamily(font.face) ? font.face : undefined : base;
            if (!run.symbolName) { if (introduced && !value) unsafeReset = true; introduced ||= !!value; }
            return value;
        });
        // Standard font-family cannot encode an empty/unknown reset. Keep the
        // precise source context without silently leaking an earlier family.
        return unsafeReset ? {} : { base, values };
    };
    const familyXml = (value?: string): string => value === undefined ? '' : ` font-family="${esc(value)}"`;
    const scriptCaption = (runs?: TextRun[]) => runs?.some(run => run.script?.projection && run.script.value !== 'normal') === true;
    const lyricTextXml = (lyric: NonNullable<NoteDetails['lyrics']>[number]): string => {
        const flags = [['bold', 1, 'font-weight'], ['italic', 2, 'font-style'], ['underline', 4, 'underline'], ['strike', 8, 'line-through']] as const;
        let base = lyric.textFontStyle?.value ?? 0, introduced = lyric.textFontStyle ? 15 : 0;
        if (!Number.isInteger(base) || base < 0 || base > 15) refuse('writer-lyric-font-style', 'Invalid lyric font style mask.', lyric.source);
        for (const [name, bit] of flags) {
            const fact = lyric.textEmphasis?.[name];
            if (!fact) continue;
            if (typeof fact.value !== 'boolean') refuse('writer-lyric-emphasis', 'Authored lyric emphasis requires a boolean source fact.', fact.source);
            introduced |= bit; base = fact.value ? base | bit : base & ~bit;
        }
        const runs = lyric.textRuns;
        const families = familyPlan(lyric.textFontFamily, runs);
        if (runs) {
            if (!runs.length || runs.length > 4096 || runs.map(run => run.text).join('') !== lyric.text) refuse('writer-lyric-runs', 'Ordered lyric runs must equal the literal syllable within the bounded profile.', lyric.source);
            for (const run of runs) {
                if (!Number.isInteger(run.emphasis) || run.emphasis < 0 || run.emphasis > 15 || run.origin !== 'source-markup' || run.symbolName && !symbolVocabulary.has(run.symbolName)) refuse('writer-lyric-runs', 'Unverified source lyric inline emphasis or symbol.', run.source);
                introduced |= run.emphasis | textResetMask(run);
            }
        }
        const textXml = (value: string, emphasis: number, family?: string, run?: TextRun) => {
            const attrs = flags.filter(([, bit]) => introduced & bit).map(([name, bit, attribute]) => {
                const enabled = !!(emphasis & bit), setting = name === 'bold' ? enabled ? 'bold' : 'normal' : name === 'italic' ? enabled ? 'italic' : 'normal' : enabled ? '1' : '0';
                return ` ${attribute}="${setting}"`;
            }).join('');
            return `<text${attrs}${(run ? inlineTextFontXml(run, lyric.textFontSize) : pointSizeXml(lyric.textFontSize)).replace(/ relative-y="[^"]+"/, '')}${scriptCaption(runs) ? ' color="#00000000"' : ''}${familyXml(family)}>${esc(value)}</text>`;
        };
        // Adjacent MusicXML text elements without elision retain one syllable.
        // Reset only emphasis actually introduced by this source lyric.
        const split = runs && (!runs.every(run => !run.symbolName && run.emphasis === 0 && run.emphasisResets === undefined && !run.textFontSize && !run.musicFontSize && !run.script)
            || families.values?.some(value => value !== families.values![0]));
        return split ? runs!.map((run, index) => textXml(run.text, (base & ~textResetMask(run)) | run.emphasis, families.values?.[index], run)).join('')
            : textXml(lyric.text, base, families.values?.[0] ?? families.base);
    };
    const directionXml = (direction: Direction, wordsOnly = false): string => {
        if (direction.playbackOnly) {
            if (direction.kind !== 'tempo' || wordsOnly || !(Number(direction.quarterRate) > 0)) refuse('writer-playback-tempo', 'A playback-only direction must be a positive tempo.', direction.source);
            return `<sound tempo="${direction.quarterRate}">${tag('offset', ticks(direction.position))}</sound>`;
        }
        if (wordsOnly && direction.kind !== 'words') refuse('writer-caption-content', 'A line caption requires the standard words formatter.', direction.source);
        if (direction.textEnclosure && !['words', 'rehearsal', 'dynamic', 'harmony'].includes(direction.kind)) refuse('writer-rehearsal-enclosure', 'The qualified source enclosure needs a text or dynamic carrier.', direction.textEnclosure.source);
        const enclosure = direction.textEnclosure;
        if (enclosure && (!['source-property', 'source-style'].includes(enclosure.origin) || ![0, 1, 2].includes(enclosure.nativeFrameType) || enclosure.value !== (['none', 'rectangle', 'circle'] as const)[enclosure.nativeFrameType])) refuse('writer-rehearsal-enclosure', 'Text enclosure requires the exact qualified source frame shape.', enclosure.source);
        const enclosureXml = enclosure ? ` enclosure="${enclosure.value}"` : '';
        const alignment = direction.textAlignment;
        if (alignment && (alignment.halign && !['left', 'center', 'right'].includes(alignment.halign) || alignment.justify && !['left', 'center', 'right'].includes(alignment.justify) || alignment.valign && !['top', 'middle', 'bottom', 'baseline'].includes(alignment.valign))) refuse('writer-text-alignment', 'Uninterpreted standard text alignment.', alignment.source);
        const positionXml = `${alignment?.halign ? ` halign="${alignment.halign}"` : ''}${alignment?.valign ? ` valign="${alignment.valign}"` : ''}`;
        const alignmentXml = `${positionXml}${alignment?.justify ? ` justify="${alignment.justify}"` : ''}`;
        if (direction.kind === 'harmony') return harmonyXml(direction, ticks(direction.position));
        // These direction glyphs lack print-object. Standard ARGB preserves the
        // authored default invisibility without deleting their typed content.
        const visibilityXml = colorXml(direction.sourceColor, direction.printObject !== false);
        const fontStyle = direction.textFontStyle;
        if (fontStyle && (!Number.isInteger(fontStyle.value) || fontStyle.value < 0 || fontStyle.value > 15)) refuse('writer-text-font-style', 'Uninterpreted native text emphasis bit field.', fontStyle.source);
        // Qualified metronome components need an explicit normal reset too:
        // MusicXML direction-font defaults belong to the receiving application.
        const showFontStyle = fontStyle && (fontStyle.value !== 0 || fontStyle.origin === 'source'
            || direction.kind === 'tempo' && direction.showMetronome !== false && direction.text !== undefined && direction.textRuns !== undefined);
        const emphasisValue = (name: 'bold' | 'italic' | 'underline' | 'strike', bit: number): boolean | undefined => {
            const fact = direction.textEmphasis?.[name];
            if (fact && typeof fact.value !== 'boolean') refuse('writer-text-emphasis', 'Authored text emphasis requires a boolean source fact.', fact.source);
            return fact ? fact.value : showFontStyle ? !!(fontStyle!.value & bit) : undefined;
        };
        const bold = emphasisValue('bold', 1), italic = emphasisValue('italic', 2), underline = emphasisValue('underline', 4), strike = emphasisValue('strike', 8);
        const sizeXml = pointSizeXml(direction.kind === 'dynamic' && !direction.customDynamic || direction.kind === 'pedal' ? direction.musicFontSize ?? direction.textFontSize : direction.textFontSize);
        const fontXml = `${bold !== undefined ? ` font-weight="${bold ? 'bold' : 'normal'}"` : ''}${italic !== undefined ? ` font-style="${italic ? 'italic' : 'normal'}"` : ''}`;
        const decorationXml = `${underline !== undefined ? ` underline="${underline ? 1 : 0}"` : ''}${strike !== undefined ? ` line-through="${strike ? 1 : 0}"` : ''}`;
        const literalTempoCaption = direction.kind === 'tempo' && direction.showMetronome !== false && !!direction.textRuns?.some(run => run.musicFontSize || run.textFontSize || run.script?.projection)
            && (direction.text === undefined || direction.textRuns.some(run => run.script?.projection)
                || new Set(direction.textRuns.filter(run => run.symbolName).map(run => inlineTextFontXml(run, direction.textFontSize))).size > 1);
        const componentCaption = !literalTempoCaption && direction.kind === 'tempo' && direction.showMetronome !== false && direction.text !== undefined && direction.textRuns !== undefined;
        const mixedDynamicTypography = direction.customDynamic && !!direction.textRuns?.some(run => run.script?.projection)
            || direction.customDynamic && new Set((direction.textRuns ?? []).map(run => inlineTextFontXml(run, direction.textFontSize))).size > 1;
        const richDynamic = (!enclosure || enclosure.value === 'none') && !direction.textRuns?.some(run => run.script?.projection) && direction.kind === 'dynamic' && direction.customDynamic && direction.textRuns?.some(run => ['dynamicPiano', 'dynamicForte', 'dynamicMezzo', 'dynamicSforzando'].includes(run.symbolName ?? ''))
            && direction.textRuns.every(run => !run.symbolName || ['dynamicPiano', 'dynamicForte', 'dynamicMezzo', 'dynamicSforzando'].includes(run.symbolName))
            && direction.textRuns.every((run, index, runs) => !['dynamicMezzo', 'dynamicSforzando'].includes(run.symbolName ?? '') || !runs[index + 1] || inlineTextFontXml(run, direction.textFontSize) === inlineTextFontXml(runs[index + 1], direction.textFontSize));
        const families = familyPlan(direction.textFontFamily, direction.kind === 'words' || direction.kind === 'rehearsal' || direction.kind === 'tempo' && direction.showMetronome === false || componentCaption || direction.customDynamic || literalTempoCaption ? direction.textRuns : undefined);
        const words = (text: string, family = families.base) => `<words${alignmentXml}${enclosureXml}${fontXml}${sizeXml}${decorationXml}${familyXml(family)}${visibilityXml}>${esc(text)}</words>`;
        const inlineWords = (text = direction.text, runs = direction.textRuns!, values = families.values): string => {
            if (!runs.length || runs.length > 4096 || runs.map(run => run.text).join('') !== text) refuse('writer-text-runs', 'Ordered inline caption facts must equal the literal direction text within the bounded profile.', direction.source);
            // Family hints do not introduce emphasis resets into plain text.
            const styled = !runs.every(run => run.origin === 'source-markup' && !run.symbolName && run.emphasis === 0 && run.emphasisResets === undefined && !run.textFontSize && !run.musicFontSize && !run.script);
            if (!styled && !values?.some(value => value !== values![0])) return words(text ?? '', values?.[0]);
            if (enclosure && enclosure.value !== 'none') {
                if (enclosure.inlineProjection === 'whole-caption-format-limit') return words(text ?? '', families.base);
                const attributes = runs.map((run, index) => {
                    const value = (((bold ? 1 : 0) | (italic ? 2 : 0) | (underline ? 4 : 0) | (strike ? 8 : 0)) & ~textResetMask(run)) | run.emphasis;
                    return ` font-weight="${value & 1 ? 'bold' : 'normal'}" font-style="${value & 2 ? 'italic' : 'normal'}" underline="${value & 4 ? 1 : 0}" line-through="${value & 8 ? 1 : 0}"${inlineTextFontXml(run, direction.textFontSize)}${familyXml(values?.[index])}`;
                });
                if (runs.every(run => !run.symbolName) && attributes.every(value => value === attributes[0])) return `<words${alignmentXml}${enclosureXml}${attributes[0]} xml:space="preserve"${visibilityXml}>${esc(text ?? '')}</words>`;
                if (runs.length === 1 && runs[0].symbolName && textRunSymbolVocabulary.has(runs[0].symbolName)) return `<symbol${alignmentXml}${enclosureXml}${attributes[0]}${visibilityXml}>${esc(runs[0].symbolName)}</symbol>`;
                refuse('writer-text-frame-runs', 'A shared caption frame with mixed formatting requires its located whole-caption format qualification.', enclosure.source);
            }
            let ordinaryHintEmitted = false;
            return runs.map((run, index) => {
                if (!Number.isInteger(run.emphasis) || run.emphasis < 0 || run.emphasis > 15 || run.origin !== 'source-markup') refuse('writer-text-runs', 'Uninterpreted source inline emphasis.', run.source);
                const value = (((bold ? 1 : 0) | (italic ? 2 : 0) | (underline ? 4 : 0) | (strike ? 8 : 0)) & ~textResetMask(run)) | run.emphasis;
                if (run.symbolName && !textRunSymbolVocabulary.has(run.symbolName) && !(literalTempoCaption && run.symbolName === 'metAugmentationDot' && direction.dots === 1)) refuse('writer-text-runs', 'Unverified source inline symbol.', run.source);
                const element = run.symbolName ? 'symbol' : 'words';
                const emphasisXml = styled ? ` font-weight="${value & 1 ? 'bold' : 'normal'}" font-style="${value & 2 ? 'italic' : 'normal'}" underline="${value & 4 ? 1 : 0}" line-through="${value & 8 ? 1 : 0}"` : fontXml + decorationXml;
                // MusicXML sibling formatting carries forward. Reset a prior
                // ordinary family for a canonical symbol, using the standard
                // generic category rather than resolving a native font. Do not
                // introduce it before unqualified ordinary text.
                const family = run.symbolName && ordinaryHintEmitted ? 'music' : values?.[index];
                if (!run.symbolName && family !== undefined) ordinaryHintEmitted = true;
                return `<${element}${alignmentXml}${emphasisXml}${inlineTextFontXml(run, direction.textFontSize)}${familyXml(family)}${run.symbolName ? '' : ' xml:space="preserve"'}${visibilityXml}>${esc(run.symbolName ?? run.text)}</${element}>`;
            }).join('');
        };
        let componentProjection: { before: string; after: string; metronomeFont: string; minuteFont: string } | undefined;
        if (componentCaption) {
            const text = direction.text!, runs = direction.textRuns!;
            if (!runs.length || runs.length > 4096 || runs.map(run => run.text).join('') !== text)
                refuse('writer-tempo-components', 'Metronome runs must equal the complete bounded formatter caption.', direction.source);
            const match = /^(.*?)(♩)(\s*·)?\s*=\s*(\d+(?:\.\d+)?)([\s\S]*)$/ds.exec(text);
            const glyphs = runs.filter(run => run.symbolName);
            if (!match || direction.unit !== 'quarter' || Number(match[4]) <= 0 || match[4] !== direction.rate
                || (match[3] ? 1 : 0) !== (direction.dots ?? 0) || match[1] !== direction.tempoWords?.before || match[5] !== direction.tempoWords?.after
                || !fontStyle || !['native-default', 'source-style', 'source'].includes(fontStyle.origin)
                || fontStyle.origin === 'source' && (fontStyle.source.member !== direction.source.member || fontStyle.source.path !== direction.source.path + '/fontStyle[1]')
                || glyphs.length !== 1 + (direction.dots ?? 0) || glyphs[0].symbolName !== 'metNoteQuarterUp'
                || direction.dots && glyphs[1].symbolName !== 'metAugmentationDot')
                refuse('writer-tempo-components', 'Complete caption, source styles, named beat/dots and printed rate must agree with all existing metronome fields.', direction.source);
            const boundary = (at: number): boolean => at <= 0 || at >= text.length
                || !(text.charCodeAt(at - 1) >= 0xD800 && text.charCodeAt(at - 1) <= 0xDBFF && text.charCodeAt(at) >= 0xDC00 && text.charCodeAt(at) <= 0xDFFF);
            const intervals: { run: NonNullable<Direction['textRuns']>[number]; start: number; end: number; family?: string }[] = [];
            let at = 0;
            for (let i = 0; i < runs.length; i++) {
                const run = runs[i], end = at + run.text.length;
                if (!boundary(at) || !boundary(end) || !Number.isInteger(run.emphasis) || run.emphasis < 0 || run.emphasis > 15 || run.origin !== 'source-markup'
                    || run.symbolName && !['metNoteQuarterUp', 'metAugmentationDot'].includes(run.symbolName)) refuse('writer-tempo-components', 'Metronome run boundaries and source style/glyph facts must be exact.', run.source);
                intervals.push({ run, start: at, end, family: families.values?.[i] }); at = end;
            }
            const glyphIntervals = intervals.filter(item => item.run.symbolName);
            const beat = match!.indices![2], dot = match!.indices![3];
            if (glyphIntervals[0].start !== beat[0] || glyphIntervals[0].end !== beat[1]
                || dot && (glyphIntervals[1].start !== dot[1] - 1 || glyphIntervals[1].end !== dot[1])
                || glyphs.some(run => !run.source.path?.startsWith(direction.source.path + '/text[1]')
                    || (run.sourceText === undefined ? !/\/sym\[\d+\]$/.test(run.source.path) : run.sourceText !== (run.symbolName === 'metNoteQuarterUp' ? '\uECA5' : '\uECB7'))))
                refuse('writer-tempo-components', 'Named glyph owners must equal the exact beat and augmentation-dot spans.', direction.source);
            const slice = (range: [number, number]) => {
                if (!boundary(range[0]) || !boundary(range[1])) refuse('writer-tempo-components', 'A component boundary cannot split a Unicode character.', direction.source);
                const selected = intervals.filter(item => item.start < range[1] && item.end > range[0]);
                return { runs: selected.map(item => ({ ...item.run, text: item.run.text.slice(Math.max(0, range[0] - item.start), Math.min(item.run.text.length, range[1] - item.start)) })),
                    values: selected.map(item => item.family) };
            };
            const effective = (run: NonNullable<Direction['textRuns']>[number]) => (((bold ? 1 : 0) | (italic ? 2 : 0) | (underline ? 4 : 0) | (strike ? 8 : 0)) & ~textResetMask(run)) | run.emphasis;
            const uniform = <T,>(values: T[]): T | undefined => values.length && values.every(value => value === values[0]) ? values[0] : undefined;
            const fontAttrs = (value?: number) => value === undefined ? '' : ` font-weight="${value & 1 ? 'bold' : 'normal'}" font-style="${value & 2 ? 'italic' : 'normal'}"`;
            const prefix = slice(match!.indices![1] as [number, number]), suffix = slice(match!.indices![5] as [number, number]), numeric = slice(match!.indices![4] as [number, number]);
            // Full-caption family safety remains authoritative for prose. The
            // numeric string has an independent local font override in MusicXML.
            const numericFamilies = numeric.runs.map(run => run.sourceFont ? run.sourceFont.role === 'ordinary-family' && !run.sourceFont.qualification && ordinaryFamily(run.sourceFont.face) ? run.sourceFont.face : undefined
                : direction.textFontFamily && !direction.textFontFamily.qualification && ordinaryFamily(direction.textFontFamily.value) ? direction.textFontFamily.value : undefined);
            componentProjection = { before: match![1] ? inlineWords(match![1], prefix.runs, prefix.values) : '', after: match![5] ? inlineWords(match![5], suffix.runs, suffix.values) : '',
                // Canonical sym insertion temporarily clears bold/italic;
                // private characters retain their authored cursor emphasis.
                metronomeFont: (uniform(glyphs.map(run => inlineTextFontXml(run, direction.textFontSize))) ?? '') + fontAttrs(uniform(glyphs.map(run => effective(run) & (run.sourceText === undefined ? ~3 : ~0)))) + (prefix.values.some(value => value !== undefined) ? familyXml('music') : ''),
                minuteFont: (uniform(numeric.runs.map(run => inlineTextFontXml(run, direction.textFontSize))) ?? '') + fontAttrs(uniform(numeric.runs.map(effective))) + familyXml(uniform(numericFamilies)) };
        }
        let content: string, projectedLine = '', dynamicTypes = '';
        if (direction.kind === 'words') content = direction.textRuns ? inlineWords() : words(direction.text ?? '');
        else if (direction.kind === 'segno' || direction.kind === 'coda') {
            const glyph = direction.navigation?.glyph;
            if (glyph && !['segno', 'segnoSerpent1', 'coda'].includes(glyph)) refuse('writer-navigation-glyph', 'Unverified source navigation glyph.', direction.source);
            content = `<${direction.kind}${glyph === 'segnoSerpent1' ? ' smufl="segnoSerpent1"' : ''}${positionXml}${visibilityXml}/>`;
        }
        else if (direction.kind === 'symbol') {
            if (!direction.symbol) refuse('writer-symbol', 'A glyph direction needs its source identity.', direction.source);
            content = glyphXml(direction.symbol!,'direction',direction.sourceColor,direction.printObject !== false);
        }
        else if (direction.kind === 'rehearsal') {
            const enclosure = direction.textEnclosure;
            if (enclosure && (!['source-property', 'source-style'].includes(enclosure.origin) || ![0, 1, 2].includes(enclosure.nativeFrameType)
                || enclosure.value !== (['none', 'rectangle', 'circle'] as const)[enclosure.nativeFrameType]))
                refuse('writer-rehearsal-enclosure', 'Rehearsal enclosure requires the exact qualified source frame shape.', enclosure.source);
            content = `<rehearsal${alignmentXml}${fontXml}${sizeXml}${familyXml(families.base)}${decorationXml}${enclosure ? ` enclosure="${enclosure.value}"` : ''}${visibilityXml}>${esc(direction.text ?? '')}</rehearsal>`;
            if(direction.textRuns?.length) {
                content=inlineWords();
                dynamicTypes=`<direction-type>${content}</direction-type><direction-type><rehearsal color="#00000000">${esc(direction.text??'')}</rehearsal></direction-type>`;
                content='';
            }
        }
        else if (direction.kind === 'dynamic') {
            if (!direction.customDynamic && !/^(?:p{1,6}|f{1,6}|mp|mf|sf|sfp|sfpp|fp|rf|rfz|sfz|sffz|fz|n|pf|sfzp)$/.test(direction.text ?? '')) refuse('writer-dynamic', 'Unsupported dynamic.', direction.source);
            if (richDynamic) {
                if (enclosure && enclosure.value !== 'none') refuse('writer-text-frame-runs', 'A shared Dynamic frame cannot become separate per-component enclosures.', enclosure.source);
                const runs = direction.textRuns!;
                if (!fontStyle || !runs.length || runs.length > 4096 || runs.map(run => run.text).join('') !== direction.text)
                    refuse('writer-dynamic-components', 'Ordered Dynamic components must equal their bounded complete caption.', direction.source);
                const effective = (run: NonNullable<Direction['textRuns']>[number]) => (((bold ? 1 : 0) | (italic ? 2 : 0) | (underline ? 4 : 0)) & ~textResetMask(run)) | run.emphasis;
                const glyphStyle = (run: NonNullable<Direction['textRuns']>[number]) => {
                    const letter = ({ dynamicPiano: 'p', dynamicForte: 'f', dynamicMezzo: 'm', dynamicSforzando: 's' } as Record<string, string>)[run.symbolName!];
                    if (run.text !== letter || !run.source.path?.startsWith(direction.source.path + '/text[1]')
                        || (run.sourceText === undefined ? !/\/sym\[\d+\]$/.test(run.source.path)
                            : !['p', 'f'].includes(letter) || run.sourceText !== (letter === 'p' ? '\uE520' : '\uE522') || run.sourceFont?.face !== 'ScoreText' || run.sourceFont.qualification))
                        refuse('writer-dynamic-components', 'Semantic Dynamic glyphs require their exact canonical or private source interval.', run.source);
                    // Canonical insertion clears bold/italic only; private
                    // characters retain their authored cursor style.
                    return effective(run) & (run.sourceText === undefined ? ~3 : ~0);
                };
                let at = 0, familyEmitted = false;
                for (let index = 0; index < runs.length; index++) {
                    const run = runs[index]; let end = at + run.text.length;
                    const boundary = (position: number) => position === 0 || position === direction.text!.length
                        || !(/[\uD800-\uDBFF]/.test(direction.text![position - 1]) && /[\uDC00-\uDFFF]/.test(direction.text![position]));
                    if (!boundary(at) || !boundary(end) || run.origin !== 'source-markup' || !Number.isInteger(run.emphasis) || run.emphasis < 0 || run.emphasis > 7)
                        refuse('writer-dynamic-components', 'Dynamic component character boundaries and source emphasis must be exact.', run.source);
                    if (!run.symbolName) {
                        dynamicTypes += `<direction-type>${inlineWords(run.text, [run], [families.values?.[index]])}</direction-type>`;
                        familyEmitted ||= families.values?.[index] !== undefined;
                    } else {
                        const letter = ({ dynamicPiano: 'p', dynamicForte: 'f', dynamicMezzo: 'm', dynamicSforzando: 's' } as Record<string, string>)[run.symbolName!];
                        const style = glyphStyle(run); let group = letter;
                        if (letter === 'm' || letter === 's') {
                            const next = runs[index + 1], ordinal = /^(.*\/sym\[)(\d+)\]$/.exec(run.source.path ?? '');
                            if (!next || next.symbolName !== 'dynamicForte' || glyphStyle(next) !== style || next.origin !== 'source-markup'
                                || !Number.isInteger(next.emphasis) || next.emphasis < 0 || next.emphasis > 7 || !ordinal
                                || next.source.path !== `${ordinal[1]}${Number(ordinal[2]) + 1}]`)
                                refuse('writer-dynamic-components', 'Native mf/sf requires one exact adjacent canonical source pair with uniform emphasis.', run.source);
                            index++; end += next.text.length; group += 'f';
                        }
                        while (['p', 'f'].includes(letter) && group.length < 6 && runs[index + 1]?.symbolName === run.symbolName && glyphStyle(runs[index + 1]) === style && inlineTextFontXml(runs[index + 1], direction.textFontSize) === inlineTextFontXml(run, direction.textFontSize)) {
                            const next = runs[++index];
                            if (next.origin !== 'source-markup' || !Number.isInteger(next.emphasis) || next.emphasis < 0 || next.emphasis > 7)
                                refuse('writer-dynamic-components', 'Grouped Dynamic glyphs require exact source emphasis.', next.source);
                            end += next.text.length; group += letter;
                        }
                        if (group.length === 6 && runs[index + 1]?.symbolName === run.symbolName && glyphStyle(runs[index + 1]) === style && inlineTextFontXml(runs[index + 1], direction.textFontSize) === inlineTextFontXml(run, direction.textFontSize))
                            refuse('writer-dynamic-components', 'A uniform source Dynamic group exceeds the six-letter standard profile.', runs[index + 1].source);
                        dynamicTypes += `<direction-type><dynamics${positionXml}${pointSizeXml(run.musicFontSize ?? direction.musicFontSize ?? direction.textFontSize)} font-weight="${style & 1 ? 'bold' : 'normal'}" font-style="${style & 2 ? 'italic' : 'normal'}" underline="${style & 4 ? 1 : 0}" line-through="0"${familyEmitted ? familyXml('music') : ''}${visibilityXml}><${group}/></dynamics></direction-type>`;
                    }
                    at = end;
                }
                content = '';
            } else {
            let dynamicFontXml = '', splitCustom = !!mixedDynamicTypography || enclosure?.inlineProjection === 'whole-caption-format-limit';
            if (direction.customDynamic && fontStyle) {
                let base = fontStyle.value;
                for (const [name, bit] of [['bold', 1], ['italic', 2], ['underline', 4], ['strike', 8]] as const) {
                    const fact = direction.textEmphasis?.[name]; if (fact) base = fact.value ? base | bit : base & ~bit;
                }
                const runs = direction.textRuns;
                if (runs && (!runs.length || runs.length > 4096 || runs.map(run => run.text).join('') !== direction.text)) refuse('writer-dynamic-runs', 'Custom dynamic runs must equal the bounded literal label.', direction.source);
                const styles = new Set((runs ?? []).map(run => {
                    if (!Number.isInteger(run.emphasis) || run.emphasis < 0 || run.emphasis > 15 || run.origin !== 'source-markup' || run.symbolName && !textRunSymbolVocabulary.has(run.symbolName)) refuse('writer-dynamic-runs', 'Unverified custom dynamic inline emphasis or glyph.', run.source);
                    return (base & ~textResetMask(run)) | run.emphasis;
                }));
                // The standard child is a string. Uniform source emphasis belongs
                // on its parent; mixed runs use visible words and a hidden typed carrier.
                splitCustom ||= styles.size > 1 || !!families.values?.some(value => value !== families.values![0]);
                const value = styles.size <= 1 ? styles.values().next().value ?? base : undefined;
                if (value !== undefined) dynamicFontXml = ` font-weight="${value & 1 ? 'bold' : 'normal'}" font-style="${value & 2 ? 'italic' : 'normal'}" underline="${value & 4 ? 1 : 0}" line-through="${value & 8 ? 1 : 0}"`;
            }
            content = `<dynamics${positionXml}${enclosureXml}${direction.customDynamic && fontStyle ? dynamicFontXml : fontXml + decorationXml}${sizeXml}${familyXml(families.base)}${visibilityXml}>${direction.customDynamic ? tag('other-dynamics', direction.text ?? '') : `<${direction.text}/>`}</dynamics>`;
            if (splitCustom) {
                const visible = inlineWords();
                const typed = `<dynamics${colorXml(direction.sourceColor, false)}>${tag('other-dynamics', direction.text ?? '')}</dynamics>`;
                dynamicTypes = `<direction-type>${visible}</direction-type><direction-type>${typed}</direction-type>`;
                content = '';
            }
            }
        } else if (direction.kind === 'pedal') {
            const relation = direction.relationId ? relationsById.get(direction.relationId) : undefined;
            const dotted = relation?.kind === 'pedal' && relation.lineType === 'dotted' && direction.line !== false;
            // Standard pedal has no line pattern. Preserve its typed state while
            // a bracket carries the authored dotted line at the same endpoints.
            content = `<pedal type="${direction.action}" number="${serializedNumber(direction.relationId, direction.number)}" line="${direction.line === false ? 'no' : 'yes'}"${dotted ? ' sign="no"' : direction.sign !== undefined ? ` sign="${direction.sign ? 'yes' : 'no'}"` : ''}${direction.abbreviated !== undefined ? ` abbreviated="${direction.abbreviated ? 'yes' : 'no'}"` : ''}${fontXml}${sizeXml}${dotted ? colorXml(direction.sourceColor, false) : visibilityXml}/>`;
            if (dotted) {
                // Non-positional formatting inherits across direction-types.
                // Reset the transparent typed carrier before visible projection.
                const projectedVisibilityXml = visibilityXml || ' color="#000000"';
                const stop = direction.action === 'stop' || direction.action === 'discontinue';
                const hook = (stop ? relation.endHook : relation.startHook) ?? 'none';
                if (!['none', 'up', 'down', 'both', 'arrow'].includes(hook)) refuse('writer-pedal-line-hook', 'Unverified source dotted pedal hook.', relation.source);
                projectedLine = `<direction-type><bracket type="${stop ? 'stop' : 'start'}" number="${serializedNumber(relation.id, undefined, 'bracket')}" line-end="${hook}" line-type="dotted"${projectedVisibilityXml}/></direction-type>`;
                if (direction.sign) {
                    const glyph = stop ? 'keyboardPedalUp' : direction.action === 'sostenuto' ? direction.abbreviated ? 'keyboardPedalS' : 'keyboardPedalSost' : 'keyboardPedalPed';
                    projectedLine += `<direction-type><symbol${fontXml}${sizeXml}${decorationXml}${projectedVisibilityXml}>${glyph}</symbol></direction-type>`;
                }
            }
        }
        else if (direction.kind === 'wedge') content = `<wedge type="${direction.action}" number="${serializedNumber(direction.relationId, direction.number)}"${direction.niente ? ' niente="yes"' : ''}${colorXml(direction.sourceColor, direction.printObject !== false && direction.line !== false)}/>`;
        else content = direction.showMetronome === false ? '' : `<metronome${alignmentXml}${componentProjection?.metronomeFont ?? ''}${direction.printObject === false || literalTempoCaption ? ' print-object="no"' : ''}>${tag('beat-unit', direction.unit ?? 'quarter')}${'<beat-unit-dot/>'.repeat(direction.dots ?? 0)}${componentProjection ? `<per-minute${componentProjection.minuteFont}>${esc(direction.rate!)}</per-minute>` : tag('per-minute', direction.rate ?? String(direction.quarterRate))}</metronome>`;
        if (wordsOnly) return content;
        // Each direction-type uses one MusicXML choice. Words cannot share the metronome choice.
        const before = literalTempoCaption ? `<direction-type>${inlineWords(direction.textRuns!.map(run => run.text).join(''))}</direction-type>` : direction.kind === 'tempo' && direction.tempoWords?.before ? `<direction-type>${componentProjection ? componentProjection.before : direction.showMetronome === false && direction.textRuns ? inlineWords(direction.tempoWords.before) : words(direction.tempoWords.before)}</direction-type>` : '';
        const after = !literalTempoCaption && direction.kind === 'tempo' && direction.tempoWords?.after ? `<direction-type>${componentProjection ? componentProjection.after : words(direction.tempoWords.after)}</direction-type>` : '';
        const technique = direction.playingTechnique;
        const feel = direction.rhythmicFeel;
        if (feel && (!['triplet', 'dotted', 'scottish'].includes(feel.kind) || !['eighth', '16th'].includes(feel.unit))) refuse('writer-rhythmic-feel', 'Unknown source rhythmic feel.', feel.source);
        const navigation = direction.navigation;
        if (navigation?.standardSound && Object.entries(navigation.standardSound).some(([key, value]) => !['segno','coda','fine','tocoda','dalsegno','dacapo'].includes(key) || typeof value !== 'string' || !value.length || key === 'dacapo' && value !== 'yes')) refuse('writer-navigation-sound', 'Unqualified standard navigation target.', direction.source);
        const navigationSound = navigation?.standardSound !== undefined ? Object.keys(navigation.standardSound).length ? `<sound ${Object.entries(navigation.standardSound).map(([key, value]) => `${key}="${esc(value!)}"`).join(' ')}/>` : '' : navigation?.kind === 'marker' ? direction.kind === 'segno' || direction.kind === 'coda' ? `<sound ${direction.kind}="${esc(navigation.label ?? '1')}"/>` : navigation.label === 'fine' ? '<sound fine="yes"/>' : ''
            : navigation?.kind === 'jump' ? `<sound ${navigation.jumpTo === 'start' ? 'dacapo="yes"' : `${navigation.targetKind === 'coda' ? 'tocoda' : 'dalsegno'}="${esc(navigation.jumpTo ?? '')}"`}/>` : '';
        const sound = (feel ? `<sound><swing><first>${feel.kind === 'triplet' ? 2 : feel.kind === 'dotted' ? 3 : 1}</first><second>${feel.kind === 'scottish' ? 3 : 1}</second><swing-type>${feel.unit}</swing-type></swing></sound>` : '') || navigationSound || (direction.kind === 'tempo' ? `<sound tempo="${direction.quarterRate}"/>` : direction.velocity !== undefined && direction.performance?.play !== false ? `<sound dynamics="${(direction.velocity / 90 * 100).toFixed(2)}"/>`
            : technique && technique.play !== false ? technique.kind === 'pizzicato' ? '<sound pizzicato="yes"/>' : technique.kind === 'natural' || technique.kind === 'arco' ? '<sound pizzicato="no"/>' : `<sound><play><other-play type="${technique.kind}">${esc(technique.kind)}</other-play></play></sound>` : '');
        return `<direction${direction.system ? ' system="only-top"' : ''}${direction.placement ? ` placement="${direction.placement}"` : ''}>${before}${dynamicTypes || (content ? `<direction-type>${content}</direction-type>` : before || after ? '' : '<direction-type><words/></direction-type>')}${projectedLine}${after}${tag('offset', ticks(direction.position))}${direction.voiceId ? tag('voice', direction.voiceId) : ''}${tag('staff', direction.staff)}${sound}</direction>`;
    };
    type RelationMark = { relation: MusicalRelation; start: boolean };
    const relationMarks = new Map<string, Map<number, RelationMark[]>>();
    const ornamentEndpoints = new Map<string, RelationMark[]>();
    const noteLineEndpoints = new Map<string, RelationMark[]>();
    const lyricStops = new Map<string, NonNullable<NoteDetails['lyrics']>>();
    const attachedTrills = (relations).filter((relation): relation is Extract<MusicalRelation, {kind:'trill'}> => relation.kind === 'trill' && relation.notationAttachments !== undefined);
    if (attachedTrills.length) {
    const attachmentIds = new Set<string>();
    for (const relation of attachedTrills) {
        const attachments = relation.notationAttachments;
        if (relation.projection || !attachments?.start || !attachments.end) return refuse('writer-trill-attachment', 'Qualified positive Trill needs both source notation attachments.', relation.source);
        for (const attachment of [attachments.start, attachments.end]) {
            if (typeof attachment.eventId !== 'string' || !attachment.eventId) refuse('writer-trill-attachment', 'Trill attachment needs a real ordinary event identity.', relation.source);
            attachmentIds.add(attachment.eventId);
        }
    }
    const attachmentEvents = new Map<string, {partId:string; measure:number; event:MusicalEvent; voiceId:string; clock:Rational; release:Rational}>();
    const attachmentMeasureClocks = new Map<string, Rational[]>();
    for (const part of score.parts) {
      let clock=q(0); const starts:Rational[]=[];
      for (const [mi,measure] of part.measures.entries()) {
       if (attachmentIds.size) starts.push(clock);
       for (const [vi,voice] of measure.voices.entries()) for (const event of voice) {
        if (attachmentIds.has(event.id)) {
            if (attachmentEvents.has(event.id)) refuse('writer-trill-attachment', 'Trill carrier identity occurs more than once.', event.source);
            attachmentEvents.set(event.id,{partId:part.id,measure:mi,event,voiceId:event.voiceId ?? String(vi+1),clock:add(clock,event.start),release:add(add(clock,event.start),event.duration)});
        }
       }
       if (attachmentIds.size) clock=add(clock,measure.duration);
      }
      if (attachmentIds.size) attachmentMeasureClocks.set(part.id,starts);
    }
    const logicalClock = (endpoint: MusicalRelation['start'], source: MusicalRelation['source']) => {
        const clock=attachmentMeasureClocks.get(endpoint.partId)?.[endpoint.measure];
        if (!clock) return refuse('writer-trill-attachment', 'Trill logical endpoint has no source measure.', source);
        return add(clock,endpoint.position);
    };
    for (const relation of attachedTrills) {
        if (relation.start.partId !== relation.end.partId || relation.start.staff !== relation.end.staff || relation.start.voiceId !== relation.end.voiceId) refuse('writer-trill-attachment', 'Source-qualified Trill keeps one logical source staff and voice.', relation.source);
        if (compare(logicalClock(relation.start,relation.source),logicalClock(relation.end,relation.source))>=0) refuse('writer-trill-attachment', 'Qualified Trill notation pair needs a positive logical interval.', relation.source);
        const attachments=relation.notationAttachments!;
        for (const [start,attachment] of [[true,attachments.start],[false,attachments.end]] as const) {
            const owner=attachmentEvents.get(attachment.eventId), event=owner?.event;
            if (!owner || !event || event.grace || compare(event.duration,q(0))<=0 || attachment.origin !== 'native-segment-anchor' || attachment.partId !== relation.start.partId || attachment.partId !== owner.partId
                || attachment.measure !== owner.measure || attachment.staff !== (event.staff ?? 1) || attachment.staff !== relation.start.staff || attachment.voiceId !== owner.voiceId
                || compare(attachment.position,event.start)!==0 || attachment.noteId !== undefined || attachment.graceIndex !== undefined
                || !attachment.source || Object.keys(attachment.source).length !== Object.keys(event.source).length || Object.keys(event.source).some(key => attachment.source[key as keyof typeof event.source] !== event.source[key as keyof typeof event.source]))
                return refuse('writer-trill-attachment', 'Trill carrier facts contradict the complete existing source event identity.', relation.source);
            if (compare(start ? owner.clock : owner.release,logicalClock(start ? relation.start : relation.end,relation.source))!==0)
                refuse('writer-trill-attachment', 'Trill source carrier does not preserve the exact logical start or end release.', relation.source);
        }
    }
    }
    for (const part of score.parts) for (const measure of part.measures) for (const voice of measure.voices) for (const event of voice) {
        for (const lyric of event.notes[0]?.lyrics ?? event.lyrics ?? []) if (lyric.extendTo?.eventId) {
            const stops = lyricStops.get(lyric.extendTo.eventId) ?? []; stops.push(lyric); lyricStops.set(lyric.extendTo.eventId, stops);
        }
    }
    const relationsById = new Map<string, MusicalRelation>(), relationsByPart = new Map<string, MusicalRelation[]>();
    for (const relation of relations) { if (relationsById.has(relation.id)) refuse('writer-relation-identity', 'Ambiguous relation identity.', relation.source); relationsById.set(relation.id, relation); const items = relationsByPart.get(relation.start.partId) ?? []; items.push(relation); relationsByPart.set(relation.start.partId, items); }
    const legacySlurNumbers = new Map<string, Set<number>>();
    for (const part of score.parts) { const numbers = new Set<number>(); for (const measure of part.measures) for (const voice of measure.voices) for (const event of voice) for (const slur of [...(event.slurs ?? []), ...event.notes.flatMap(note => note.slurs ?? [])]) if (!slur.relationId) numbers.add(slur.number ?? 1); legacySlurNumbers.set(part.id, numbers); }
    const openNumbers = new Map<string, number>(), emittedEndpoints = new Map<string, number>(), occupied = new Map<string, Set<number>>();
    const projectedOpenNumbers = new Map<string, number>(), projectedEndpoints = new Map<string, number>();
    // MusicXML number-level distinguishes overlapping intervals in XML document order,
    // including a semantic stop encountered before its start in another source voice.
    const serializedNumber = (id?: string, legacy?: number, projection?: 'bracket'): number => {
        if (!id) return legacy ?? 1;
        const relation = relationsById.get(id); if (!relation) return refuse('writer-relation-reference', 'Notation endpoint has no source relation.', undefined);
        const endpoints = projection ? projectedEndpoints : emittedEndpoints, open = projection ? projectedOpenNumbers : openNumbers;
        const namespace = `${relation.start.partId}:${projection || (relation.kind === 'ottava' || relation.kind === 'ending') && relation.projection ? 'text-line' : relation.kind}`, count = endpoints.get(id) ?? 0, numbers = occupied.get(namespace) ?? new Set<number>(); occupied.set(namespace, numbers);
        if (count >= 2) refuse('writer-relation-endpoints', 'Musical relation would emit more than two endpoint marks.', relation.source);
        endpoints.set(id, count + 1);
        if (count === 1) { const number = open.get(id)!; open.delete(id); numbers.delete(number); return number; }
        let number = 1; while (numbers.has(number) || relation.kind === 'slur' && legacySlurNumbers.get(relation.start.partId)?.has(number)) number++;
        if (number > 16) refuse('writer-relation-budget', 'More than 16 overlapping MusicXML document intervals require another verified representation.', relation.source);
        numbers.add(number); open.set(id, number); return number;
    };
    const hopoOpen = new Map<string, string>(); let hopoSerial = 0;
    const hopoSlurNumber = (partId: string, note: NoteDetails, start: boolean): number => {
        const raw = note.hopoNumber ?? 1, key = `${partId}:${raw}`;
        if (!Number.isInteger(raw) || raw < 1 || raw > 16) return refuse('writer-hopo-number', 'H/P pair needs a standard number level.', note.source);
        let id = hopoOpen.get(key);
        if (start) {
            if (id) return refuse('writer-hopo-overlap', 'Overlapping H/P pairs reuse a source pair number.', note.source);
            id = `writer-hopo-${++hopoSerial}`;
            while (relationsById.has(id)) id = `writer-hopo-${++hopoSerial}`;
            const endpoint = { partId, measure: 0, position: q(0), staff: 1 };
            relationsById.set(id, { source: note.source, id, kind: 'slur', start: endpoint, end: endpoint }); hopoOpen.set(key, id);
        } else if (!id) return refuse('writer-hopo-endpoint', 'H/P stop has no matching source pair.', note.source);
        const number = serializedNumber(id);
        if (!start) hopoOpen.delete(key);
        return number;
    };
    const slurXml = (slur: NonNullable<NoteDetails['slurs']>[number]) => `<notations${slur.printObject === false ? ' print-object="no"' : ''}><slur type="${slur.type}" number="${serializedNumber(slur.relationId, slur.number)}"${slur.orientation ? ` orientation="${slur.orientation}"` : ''}${slur.lineType ? ` line-type="${slur.lineType}"` : ''}/></notations>`;
    const tupletXml = (boundary: NonNullable<MusicalEvent['tupletBoundary']>[number], inherited?: MusicalEvent['tuplet']) => {
        const hidden = boundary.printObject === false, bracket = boundary.bracketType?.value, direction = boundary.direction?.value;
        const attrs = `${hidden ? ' bracket="no" show-number="none" show-type="none"' : `${bracket && bracket !== 'auto' ? ` bracket="${bracket}"` : ''}${boundary.numberType ? ` show-number="${boundary.numberType.value}"` : ''}`}${direction && direction !== 'auto' ? ` placement="${direction === 'up' ? 'above' : 'below'}"` : ''}`;
        const content = boundary.type === 'start' && boundary.actual !== undefined && boundary.normal !== undefined && (boundary.actual !== inherited?.actual || boundary.normal !== inherited?.normal) ? `<tuplet-actual>${tag('tuplet-number', boundary.actual)}</tuplet-actual><tuplet-normal>${tag('tuplet-number', boundary.normal)}</tuplet-normal>` : '';
        if ((boundary.actual !== undefined || boundary.normal !== undefined) && (![boundary.actual, boundary.normal].every(value => Number.isSafeInteger(value) && value! > 0 && value! <= 128))) refuse('writer-tuplet', 'Invalid individual source tuplet counts.', boundary.source);
        return `<tuplet type="${boundary.type}" number="${boundary.number}"${attrs}${content ? `>${content}</tuplet>` : '/>'}`;
    };
    for (const relation of relations) if (relation.kind === 'trill') for (const start of relation.projection?.kind === 'point-ornament' ? [true] : [true, false]) {
        if (relation.projection && (relation.form !== 'trill' || relation.start.partId !== relation.end.partId || relation.start.eventId !== relation.end.eventId)) refuse('writer-trill-endpoint', 'Point ornament must retain one exact source trill host.', relation.source);
        const endpoint = relation.notationAttachments ? start ? relation.notationAttachments.start : relation.notationAttachments.end : start ? relation.start : relation.end;
        if (!endpoint.eventId) return refuse('writer-trill-endpoint', 'Trill line has no resolved source event attachment.', relation.source);
        const marks = ornamentEndpoints.get(endpoint.eventId) ?? []; marks.push({ relation, start }); ornamentEndpoints.set(endpoint.eventId, marks);
    }
    for (const relation of relations) if (relation.kind === 'note-line' || relation.kind === 'glissando') for (const start of [true, false]) {
        const endpoint = start ? relation.start : relation.end;
        if (!endpoint.noteId) refuse('writer-note-line-endpoint', 'Visual note line has no resolved source component.', relation.source);
        const marks = noteLineEndpoints.get(endpoint.noteId!) ?? []; marks.push({ relation, start }); noteLineEndpoints.set(endpoint.noteId!, marks);
    }
    for (const part of score.parts) {
        const offsets: Rational[] = []; let clock = q(0);
        for (const measure of part.measures) { offsets.push(clock); clock = add(clock, measure.duration); }
        const boundaries: { relation: MusicalRelation; start: boolean; clock: Rational; degenerate: boolean }[] = [];
        for (const relation of relationsByPart.get(part.id) ?? []) if (!['tie', 'slur', 'trill', 'note-line', 'glissando'].includes(relation.kind)) {
            if (relation.end.partId !== part.id || !offsets[relation.start.measure] || !offsets[relation.end.measure]) refuse('writer-relation', 'Relation must resolve inside one source part.', relation.source);
            const start = add(offsets[relation.start.measure], relation.start.position), end = add(offsets[relation.end.measure], relation.end.position);
            if (compare(start, end) > 0 || compare(start, end) === 0 && !['pedal', 'wedge', 'text-line'].includes(relation.kind) && !(relation.kind === 'ottava' && relation.projection?.reason === 'zero-duration')) refuse('writer-relation-clock', 'Relation stop must follow its start, except an explicitly degenerate paired direction.', relation.source);
            const degenerate = compare(start, end) === 0 && relation.kind === 'ottava' && relation.projection?.reason === 'zero-duration';
            boundaries.push({ relation, start: true, clock: start, degenerate }, { relation, start: false, clock: end, degenerate });
        }
        boundaries.sort((a, b) => compare(a.clock, b.clock) || (a.degenerate ? 1 : a.start ? 2 : 0) - (b.degenerate ? 1 : b.start ? 2 : 0)
            || (a.degenerate && b.degenerate ? (a.relation.id < b.relation.id ? -1 : a.relation.id > b.relation.id ? 1 : Number(b.start) - Number(a.start)) : Number(a.start) - Number(b.start)));
        const measures = new Map<number, RelationMark[]>();
        for (const boundary of boundaries) {
            const { relation, start } = boundary;
            const endpoint = start ? relation.start : relation.end;
            if (!['pedal', 'wedge'].includes(relation.kind)) { const marks = measures.get(endpoint.measure) ?? []; marks.push({ relation, start }); measures.set(endpoint.measure, marks); }
        }
        relationMarks.set(part.id, measures);
    }
    let out = '', outputBytes = 0;
    const emit = (value: string) => {
        if (limits) {
            let bytes = value.length;
            for (let i = 0; i < value.length; i++) {
                const c = value.charCodeAt(i);
                if (c >= 0xD800 && c <= 0xDBFF && i + 1 < value.length && value.charCodeAt(i + 1) >= 0xDC00 && value.charCodeAt(i + 1) <= 0xDFFF) { bytes += 2; i++; }
                else if (c >= 0x800) bytes += 2; else if (c >= 0x80) bytes++;
            }
            outputBytes += bytes;
            if (outputBytes > limits.outputBytes) refuse('writer-output-size', 'MusicXML output exceeds the adapter byte budget; no output admitted.');
        }
        out += value;
    };
    emit('<?xml version="1.0" encoding="utf-8"?>\n<score-partwise version="4.0">');
    const metadata = score.metadata ?? [], meta = new Map(metadata.map(fact => [fact.name, fact.value]));
    emit(`<work>${meta.get('workNumber') ? tag('work-number', meta.get('workNumber')!) : ''}${tag('work-title', score.title)}</work>`);
    for (const name of ['movementNumber', 'movementTitle']) if (meta.get(name)) emit(tag(name === 'movementNumber' ? 'movement-number' : 'movement-title', meta.get(name)!));
    emit('<identification>');
    const creatorRoles = new Set(['composer', 'arranger', 'lyricist', 'poet', 'translator']);
    for (const fact of metadata) if (creatorRoles.has(fact.name) && fact.value) emit(`<creator type="${fact.name}">${esc(fact.value)}</creator>`);
    for (const fact of metadata) if (fact.name === 'copyright' && fact.value) emit(tag('rights', fact.value));
    emit(`<encoding>${meta.get('encoder') ? tag('encoder', meta.get('encoder')!) : ''}<software>score-converter proving slice</software></encoding>`);
    if (meta.get('source')) emit(tag('source', meta.get('source')!));
    const standardMetadata = new Set([...creatorRoles, 'copyright', 'encoder', 'source', 'workTitle', 'workNumber', 'movementTitle', 'movementNumber']);
    const miscellaneous = metadata.filter(fact => !standardMetadata.has(fact.name));
    const preserveOrnament=(details:OrnamentDetails|undefined,owner:string)=>{
        if(details?.intervalAbove||details?.intervalBelow||details?.cueNote||details?.showAccidental||details?.alwaysShowTrillCue||details?.sign)miscellaneous.push({source:details.source,name:`source-ornament-intervals:${owner}`,value:JSON.stringify({above:details.intervalAbove,below:details.intervalBelow,principal:details.principal,cueNote:details.cueNote,showAccidental:details.showAccidental,alwaysShowTrillCue:details.alwaysShowTrillCue,sourceSubtype:details.sourceSubtype,sign:details.sign})});
    };
    for(const relation of relations)if(relation.kind==='trill')preserveOrnament(relation.ornament,relation.id);
    for (const part of score.parts) {
        const previousClefs=new Map<number,string>();
        for(const [measureIndex,measure] of part.measures.entries()) {
            for(const staff of measure.staffs??part.staves??[]) {
                const definition=standardClef(staff.clef);if(previousClefs.get(staff.number)===staff.clef)continue;previousClefs.set(staff.number,staff.clef);
                if(definition?.sourceGlyph)miscellaneous.push({source:staff.clefOrigin?.source??staff.source,name:`source-clef-glyph:${part.id}:${measureIndex+1}:${staff.number}`,value:JSON.stringify({token:staff.clef,glyph:definition.sourceGlyph})});
            }
            for(const [index,change] of (measure.changes??[]).entries())if(change.clef) {
                const definition=standardClef(change.clef);
                if(definition?.sourceGlyph)miscellaneous.push({source:change.source,name:`source-clef-change-glyph:${part.id}:${measureIndex+1}:${change.staff}:${index+1}`,value:JSON.stringify({token:change.clef,glyph:definition.sourceGlyph,position:change.position})});
            }
        }
        const previousTab = new Map<number,string>();
        const previousPercussion = new Map<number,number>();
        for (const [measureIndex, measure] of part.measures.entries()) for (const staff of measure.staffs ?? part.staves ?? []) if (staff.percussionStepOffset) {
            const fact=staff.percussionStepOffset;if(previousPercussion.get(staff.number)===fact.value)continue;previousPercussion.set(staff.number,fact.value);
            miscellaneous.push({source:fact.source,name:`source-percussion-step-offset:${part.id}:${measureIndex+1}:${staff.number}`,value:JSON.stringify(fact)});
        }
        const previousHeads = new Map<number,string>();
        for (const [measureIndex, measure] of part.measures.entries()) for (const staff of measure.staffs ?? part.staves ?? []) if (staff.noteheadScheme) {
            const value=staff.noteheadScheme.value;if(previousHeads.get(staff.number)===value)continue;previousHeads.set(staff.number,value);
            miscellaneous.push({source:staff.noteheadScheme.source,name:`source-head-scheme:${part.id}:${measureIndex+1}:${staff.number}`,value});
        }
        for (const [measureIndex, measure] of part.measures.entries()) for (const staff of measure.staffs ?? part.staves ?? []) if (staff.tablature) {
            const value=JSON.stringify(staff.tablature); if(previousTab.get(staff.number)===value)continue;previousTab.set(staff.number,value);
            miscellaneous.push({ source: staff.tablature.source, name: `source-tab-staff:${part.id}:${measureIndex + 1}:${staff.number}`, value });
        }
    }
    const retainSharedFrame = (owner: { source: Direction['source']; textEnclosure?: Direction['textEnclosure']; textRuns?: Direction['textRuns'] }, id: string) => {
        if (owner.textEnclosure?.inlineProjection === 'whole-caption-format-limit') miscellaneous.push({ source: owner.source, name: `source-shared-enclosure:${id}`, value: JSON.stringify({ enclosure: owner.textEnclosure, runs: owner.textRuns }) });
    };
    for (const part of score.parts) for (const [mi, measure] of part.measures.entries()) for (const [di, direction] of (measure.directions ?? []).entries()) retainSharedFrame(direction, `${part.id}:M${mi + 1}:D${di + 1}`);
    for (const [ci, credit] of (score.credits ?? []).entries()) retainSharedFrame(credit, `credit:${ci + 1}`);
    for(const part of score.parts)for(const [index,measure] of part.measures.entries())for(const fact of measure.numbering?.appearances??[])miscellaneous.push({source:fact.source,name:`source-measure-number:${part.id}:M${index+1}:S${fact.staff}`,value:JSON.stringify(fact)});
    const preserveGlyph = (glyph: GlyphFact, owner: string) => miscellaneous.push({source:glyph.source,name:`source-glyph:${owner}:${glyph.id}`,value:JSON.stringify(glyph)});
    for (const [index,credit] of (score.credits ?? []).entries()) if(credit.symbol) preserveGlyph(credit.symbol,`credit-${index+1}`);
    for (const part of score.parts) for (const [mi,measure] of part.measures.entries()) {
        for(const [di,direction] of (measure.directions ?? []).entries()) if(direction.symbol)preserveGlyph(direction.symbol,`${part.id}:M${mi+1}:D${di+1}`);
        for(const voice of measure.voices) for(const event of voice) {
            for(const glyph of event.symbols ?? [])preserveGlyph(glyph,`${part.id}:M${mi+1}:E${event.id}`);
            for(const note of event.notes)for(const glyph of note.symbols ?? [])preserveGlyph(glyph,`${part.id}:M${mi+1}:E${event.id}:N${note.id}`);
        }
    }
    const preserveInstrumentTranspose = (name: string, interval: MusicalScore['parts'][number]['sourceInstrumentTranspose']) => {
        if (!interval) return;
        if (![interval.diatonic, interval.chromatic, interval.octaveChange ?? 0].every(Number.isSafeInteger)) refuse('writer-source-transpose', 'Source instrument transpose requires exact integer intervals.', interval.source);
        miscellaneous.push({ source: interval.source, name, value: `diatonic=${interval.diatonic};chromatic=${interval.chromatic};octave=${interval.octaveChange ?? 0}` });
    };
    for (const [pi, part] of score.parts.entries()) {
        preserveInstrumentTranspose(`source-instrument:${partIds[pi]}:transpose`, part.sourceInstrumentTranspose);
        for(const [owner,tuning] of [[`part`,part.tuning],...(part.staves??[]).map(staff=>[`staff-${staff.number}`,staff.tuning] as const)] as const)if(tuning&&tuningFallback(tuning))miscellaneous.push({source:part.source,name:`source-tuning:${partIds[pi]}:${owner}:midi-line-order`,value:tuning.join(' ')});
        for(const [mi,measure] of part.measures.entries())for(const [ci,change] of (measure.changes??[]).entries())if(change.tuning&&tuningFallback(change.tuning))miscellaneous.push({source:change.source,name:`source-tuning:${partIds[pi]}:M${mi+1}:change-${ci+1}:midi-line-order`,value:change.tuning.join(' ')});
        for (const [mi, measure] of part.measures.entries()) for (const [vi, voice] of measure.voices.entries()) for (const [ei, event] of voice.entries()) {
            const owner = `${partIds[pi]}:M${mi + 1}:V${vi + 1}:E${ei + 1}`;
            for(const {relation,start} of ornamentEndpoints.get(event.id)??[])if(start&&relation.kind==='trill'&&relation.ornament?.principal&&!event.notes.some(note=>note.id===relation.ornament!.principal!.noteId))refuse('writer-ornament-principal','Trill principal must belong to its source start chord.',relation.ornament.principal.source);
            for(const [index,ornament] of (event.ornaments??[]).entries()) {
                if(ornament.details?.principal&&!event.notes.some(note=>note.id===ornament.details!.principal!.noteId))refuse('writer-ornament-principal','Ornament principal must belong to its source chord.',ornament.details.principal.source);
                preserveOrnament(ornament.details,`${owner}:O${index+1}`);
            }
            for (const [ni, note] of event.notes.entries()) {
                for(const [index,ornament] of (note.ornaments??[]).entries())preserveOrnament(ornament.details,`${owner}:N${ni+1}:O${index+1}`);
                miscellaneous.push(...frettedTechniqueMetadata(note, `${owner}:N${ni + 1}`));
                if(note.linkedOctaveShift) miscellaneous.push({source:note.linkedOctaveShift.source,name:`source-linked-octave:${owner}:N${ni+1}`,value:JSON.stringify(note.linkedOctaveShift)});
                if(note.dynamic) miscellaneous.push({source:note.dynamic.source,name:`source-note-dynamic:${owner}:N${ni+1}`,value:JSON.stringify(note.dynamic)});
                if(note.tieSound) miscellaneous.push({source:note.source,name:`source-tie-sound:${owner}:N${ni+1}`,value:JSON.stringify(note.tieSound)});
                if(note.tabTieVisibility?.length) miscellaneous.push({source:note.source,name:`source-tab-ties:${owner}:N${ni+1}`,value:JSON.stringify(note.tabTieVisibility)});
                if(note.tabFretFont) miscellaneous.push({source:note.tabFretFont.source,name:`source-tab-fret-font:${owner}:N${ni+1}`,value:JSON.stringify(note.tabFretFont)});
                if(note.fretDisplay){if(note.fretDisplay.origin!=='short-string-notation'||!Number.isSafeInteger(note.fretDisplay.value)||note.fretDisplay.value<0||!Number.isSafeInteger(note.fretDisplay.startFret)||note.fretDisplay.startFret<0||note.fret===undefined||note.fretDisplay.value!==(note.fret===0?0:note.fret+note.fretDisplay.startFret))refuse('writer-short-string-fret','Short-string display fret must retain the exact encoded local-nut displacement.',note.fretDisplay.source);miscellaneous.push({source:note.fretDisplay.source,name:`source-relative-fret:${owner}:N${ni+1}`,value:JSON.stringify({sourceFret:note.fret,...note.fretDisplay})});}
                if(note.sourceAccidental||note.centOffset) miscellaneous.push({source:note.sourceAccidental?.source??note.centOffset!.source,name:`source-accidental:${owner}:N${ni+1}`,value:JSON.stringify({glyph:note.sourceAccidental,centOffset:note.centOffset,derivedPitch:note.microtonalPitch})});
                if(note.sourceHeadScheme) miscellaneous.push({source:note.sourceHeadScheme.source,name:`source-head-scheme:${owner}:N${ni+1}`,value:note.sourceHeadScheme.value});
                if(note.tabFret) miscellaneous.push({source:note.tabFret.source,name:`source-tab-fret:${owner}:N${ni+1}`,value:JSON.stringify(note.tabFret)});
                if(note.bend?.sourceCurveFields) miscellaneous.push({source:note.bend.source,name:`source-bend-fields:${owner}:N${ni+1}`,value:JSON.stringify(note.bend.sourceCurveFields)});
            }
            if(event.whammy?.sourceCurveFields) miscellaneous.push({source:event.whammy.source,name:`source-whammy-fields:${owner}`,value:JSON.stringify(event.whammy.sourceCurveFields)});
            if(event.tabRhythm) miscellaneous.push({source:event.tabRhythm.source,name:`source-tab-rhythm:${owner}`,value:JSON.stringify(event.tabRhythm)});
            for (const [index, instruction] of (event.performerInstructions ?? []).entries()) miscellaneous.push({ source: instruction.source, name: `source-performer-instruction:${owner}:${index + 1}:${instruction.kind}`, value: instruction.nativeValue });
            if (event.whammy) miscellaneous.push({ source: event.whammy.source, name: `source-whammy:${owner}`, value: event.whammy.points.map(point => `${point.offset.n}/${point.offset.d}:${point.semitones.n}/${point.semitones.d}${point.vibrato?`:vibrato=${point.vibrato.value}${point.vibrato.speed?`:speed=${point.vibrato.speed}`:''}`:''}`).join(';') });
        }
        for (const [mi, measure] of part.measures.entries()) if (measure.time.senzaMisura) miscellaneous.push({ source: measure.time.senzaMisura.source, name: `source-free-time:${partIds[pi]}:M${mi + 1}:encoded-meter`, value: `${measure.time.beats}/${measure.time.unit}` });
        for (const [ci, capo] of (part.capoChanges ?? []).entries()) {
            if (capo.transposeMode) miscellaneous.push({ source: capo.transposeMode.source, name: `source-capo:${partIds[pi]}:${ci + 1}:pitch-policy`, value: capo.transposeMode.value });
            if(capo.ignoredStrings)miscellaneous.push({source:capo.ignoredStrings.source,name:`source-capo:${partIds[pi]}:${ci+1}:ignored-strings`,value:JSON.stringify(capo.ignoredStrings.values)});
            if(capo.appliedStrings)miscellaneous.push({source:capo.appliedStrings.source,name:`source-capo:${partIds[pi]}:${ci+1}:applied-strings`,value:JSON.stringify(capo.appliedStrings)});
        }
    }
    // These labels identify source organizational roles, not new printed names.
    for (const [index, part] of score.parts.entries()) for (const role of ['track', 'instrumentTrack'] as const) {
        const label = part.names?.[role];
        if (label) miscellaneous.push({ source: label.source, name: `${role === 'track' ? 'source-part-track-name' : 'source-instrument-track-name'}:${partIds[index]}`, value: label.value });
    }
    const sourcePartIds = new Map(score.parts.map((part, index) => [part.id, partIds[index]]));
    const sourceParts = new Map(score.parts.map(part => [part.id, part]));
    const imageDirections = new Map<string, string[]>();
    for (const [index, image] of (score.sourceImages ?? []).entries()) {
        const partId = sourcePartIds.get(image.partId); if (!partId) refuse('writer-image-owner', 'Source image links an unknown part.', image.source);
        const prefix = `source-image:${index + 1}`;
        miscellaneous.push({ source: image.source, name: `${prefix}:owner`, value: image.attachment ? JSON.stringify({partId,staff:image.staff,...image.attachment}) : `${partId}:S${image.staff}:before-M${image.beforeMeasure! + 1}:${image.frame}:${image.viewSource ? 'alternate-view' : 'primary'}` });
        miscellaneous.push({ source: image.source, name: `${prefix}:content-status`, value: image.contentStatus });
        for(const [field,value] of Object.entries({size:image.size,offset:image.offset,autoScale:image.autoScale,appearance:image.appearance,placement:image.placement}))if(value!==undefined)miscellaneous.push({source:image.source,name:`${prefix}:${field}`,value:JSON.stringify(value)});
        for (const field of ['path', 'linkPath'] as const) if (image[field]) miscellaneous.push({ source: image[field]!.source, name: `${prefix}:${field}`, value: image[field]!.value });
        miscellaneous.push({ source: image.source, name: `${prefix}:visibility`, value: image.printObject === false ? 'hidden' : 'visible' });
        if (image.resource) {
            const resource = image.resource;
            if (!['image/png', 'image/jpeg', 'image/gif', 'image/svg+xml'].includes(resource.mime) || !/^[A-Za-z0-9+/]+={0,2}$/.test(resource.base64) || resource.base64.length % 4 || resource.base64.length > 32 * 1024 * 1024 || !/^[a-f0-9]{64}$/.test(resource.sha256)) refuse('writer-image-resource', 'Embedded image requires a bounded qualified MIME resource.', resource.source);
            const uri = `data:${resource.mime};base64,${resource.base64}`;
            miscellaneous.push({ source: resource.source, name: `${prefix}:sha256`, value: resource.sha256 });
            if (image.viewSource || image.printObject === false) miscellaneous.push({ source: resource.source, name: `${prefix}:${image.viewSource ? 'alternate-view-resource' : 'hidden-resource'}`, value: uri });
            else {
                const part = sourceParts.get(image.partId)!;
                const attached=image.attachment;
                if(!Number.isSafeInteger(image.staff)||image.staff<1)refuse('writer-image-owner','Image needs an exact source staff.',image.source);
                let measure:number,offset:number;
                if(attached){
                    if(image.beforeMeasure!==undefined||image.frame!==undefined||!Number.isSafeInteger(attached.measure)||attached.measure<0||attached.measure>=part.measures.length||compare(attached.position,q(0))<0||compare(attached.position,part.measures[attached.measure].duration)>0)refuse('writer-image-owner','Attached image requires one exact musical measure and clock.',image.source);
                    measure=attached.measure;offset=ticks(attached.position);
                    if(attached.eventId){const event=part.measures[measure].voices.flat().find(e=>e.id===attached.eventId);if(!event||compare(event.start,attached.position)!==0||(event.staff??1)!==image.staff||attached.voiceId!==undefined&&event.voiceId!==attached.voiceId||attached.noteId&&!event.notes.some(n=>n.id===attached.noteId))refuse('writer-image-owner','Image attachment does not match its original event/note owner.',image.source);}
                    else if(attached.noteId)refuse('writer-image-owner','Image note identity requires its event owner.',image.source);
                }else{
                    if(!Number.isSafeInteger(image.beforeMeasure)||image.beforeMeasure!<0||image.beforeMeasure!>part.measures.length||!image.frame)refuse('writer-image-owner','Frame image requires its original boundary.',image.source);
                    measure=Math.min(image.beforeMeasure!,part.measures.length-1);offset=image.beforeMeasure===part.measures.length?ticks(part.measures[measure].duration):0;
                }
                const placement=image.placement,targetId=placement?.partId??image.partId,target=sourceParts.get(targetId),staff=placement?.staff??image.staff,voice=placement?.voiceId??image.attachment?.voiceId;
                if(!target||!target.measures[measure]||!(target.measures[measure].staffs??target.staves??[{number:1}]).some(s=>s.number===staff)||offset>ticks(target.measures[measure].duration))refuse('writer-image-owner','Image placement addresses an unavailable staff or clock.',image.source);
                const key = `${targetId}\u0000${measure}`, items = imageDirections.get(key) ?? [];
                items.push(`<direction><direction-type><image source="${uri}" type="${resource.mime}"/></direction-type>${tag('offset', offset)}${voice?tag('voice',voice):''}${tag('staff', staff)}</direction>`); imageDirections.set(key, items);
            }
        }
    }
    for (const pageText of score.sourcePageText ?? []) {
        const prefix = `source-page-text:${pageText.field}`;
        miscellaneous.push({ source: pageText.source, name: `${prefix}:raw`, value: pageText.raw }, { source: pageText.source, name: `${prefix}:role`, value: `${pageText.role}:${pageText.parity}:${pageText.side}` }, { source: pageText.source, name: `${prefix}:conditions`, value: `enabled=${pageText.conditions.enabled.value};first-page=${pageText.conditions.firstPage.value};odd-even=${pageText.conditions.oddEven.value}` });
    }
    for (const [index, link] of (score.sourceObjectLinks ?? []).entries()) {
        const prefix = `source-object-link:${index + 1}`, owner = link.owner, ownerPart = sourcePartIds.get(owner.partId);
        if (!ownerPart) refuse('writer-object-link-owner', 'Source object link has an unknown primary part.', link.source);
        miscellaneous.push({ source: link.source, name: `${prefix}:owner`, value: `${ownerPart}:S${owner.staff}:M${owner.measure + 1}:V${owner.voiceId}:${owner.position.n}/${owner.position.d}:${owner.kind}` }, { source: link.source, name: `${prefix}:status`, value: link.status });
        if (owner.sourceEid) miscellaneous.push({ source: owner.source, name: `${prefix}:owner-eid`, value: owner.sourceEid });
        if (link.targetEid) miscellaneous.push({ source: link.targetEid.source, name: `${prefix}:target-eid`, value: link.targetEid.value });
        if (link.relativeStaff) miscellaneous.push({ source: link.relativeStaff.source, name: `${prefix}:relative-staff`, value: String(link.relativeStaff.value) });
        if (link.target) { const target = link.target; miscellaneous.push({ source: target.source, name: `${prefix}:target`, value: `${sourcePartIds.get(target.partId)}:S${target.staff}:M${target.measure + 1}:V${target.voiceId}:${target.position.n}/${target.position.d}:${target.kind}` }); }
    }
    for (const relation of relations) {
        if(relation.clockGap) miscellaneous.push({source:relation.source,name:`source-tie-clock-gap:${relation.id}`,value:JSON.stringify({start:relation.start,end:relation.end,gap:relation.clockGap})});
        if ('sourceTechnique' in relation && relation.sourceTechnique) miscellaneous.push({ source: relation.sourceTechnique.source, name: `source-relation-technique:${relation.id}`, value: relation.sourceTechnique.kind });
        for (const [field, fact] of Object.entries(relation.textFacts ?? {})) if (field === 'continueText') miscellaneous.push({ source: fact.source, name: `source-line-text:${relation.id}:${field}`, value: fact.value });
        if (relation.kind === 'ending' && relation.sourceNumbers) miscellaneous.push({ source: relation.sourceNumbers.source, name: `source-ending:${relation.id}:encoded-numbers`, value: relation.sourceNumbers.values.join(',') });
    }
    for (const [pi, part] of score.parts.entries()) for (const [mi, measure] of part.measures.entries()) for (const [di, direction] of (measure.directions ?? []).entries()) {
        const frame = direction.harmony?.role === 'chord-symbol' ? direction.harmony : undefined;
        for (const [ci, component] of (frame ? [frame, ...(frame.additional ?? [])] : []).entries()) if (component.sourceNoteNaming) miscellaneous.push({ source: component.source, name: `source-chord:${partIds[pi]}:M${mi + 1}:S${direction.staff}:D${di + 1}:C${ci + 1}:note-naming`, value: JSON.stringify(component.sourceNoteNaming) });
        for (const fact of frame?.sourceAnalysis ?? []) miscellaneous.push({ source: fact.source, name: `source-chord:${partIds[pi]}:M${mi + 1}:S${direction.staff}:D${di + 1}:${fact.name}`, value: String(fact.value) });
        if (frame?.sourceBarStates) miscellaneous.push({ source: frame.sourceBarStates.source, name: `source-frame:${partIds[pi]}:M${mi + 1}:S${direction.staff}:D${di + 1}:bar-states`, value: frame.sourceBarStates.value });
        const nav = direction.navigation; if (!nav) continue;
        for (const field of ['label', 'glyph', 'jumpTo', 'playUntil', 'continueAt'] as const) if (nav[field] !== undefined) miscellaneous.push({ source: nav.source, name: `source-navigation:${partIds[pi]}:M${mi + 1}:S${direction.staff}:D${di + 1}:${field}`, value: nav[field]! });
        if (nav.markerType) miscellaneous.push({ source: nav.markerType.source, name: `source-navigation:${partIds[pi]}:M${mi + 1}:S${direction.staff}:D${di + 1}:marker-type`, value: nav.markerType.value });
    }
    for (const [pi, part] of score.parts.entries()) for (const [ci, context] of (part.instrumentChanges ?? []).entries()) {
        const prefix = `source-instrument-change:${partIds[pi]}:C${ci + 1}`;
        preserveInstrumentTranspose(`${prefix}:transpose`, context.sourceInstrumentTranspose);
        miscellaneous.push({ source: context.source, name: `${prefix}:owner`, value: `M${context.measure + 1}:S${context.staff}:${context.position.n}/${context.position.d}` });
        for (const role of ['track', 'long', 'short', 'instrumentTrack'] as const) { const name = context.names?.[role]; if (name) miscellaneous.push({ source: name.source, name: `${prefix}:${role}-name`, value: name.value }); }
        if (context.instrumentId) miscellaneous.push({ source: context.instrumentId.source, name: `${prefix}:catalog-identity`, value: context.instrumentId.value });
        for (const clef of context.defaultClefs) miscellaneous.push({ source: clef.source, name: `${prefix}:catalog-clef:S${clef.staff}`, value: clef.value });
    }
    for (const [pi, part] of score.parts.entries()) for (const [mi, measure] of part.measures.entries()) for (const voice of measure.voices) for (const event of voice) for (const [fi, figure] of (event.figuredBass ?? []).entries()) {
        miscellaneous.push({ source: figure.source, name: `source-figured-bass:${partIds[pi]}:M${mi + 1}:S${event.staff ?? 1}:V${event.voiceId ?? '1'}:E${event.id}:F${fi + 1}`, value: JSON.stringify({ position: figure.position, duration: figure.duration, onNote: figure.onNote?.value, items: figure.items.map(item => ({ digit: item.digit?.value, prefix: item.prefix?.encoded, suffix: item.suffix?.encoded, brackets: item.brackets?.values, continuation: item.continuation?.value })) }) });
    }
    const frameDirections = new Map<string, Map<number, Direction[]>>();
    for (const [index, credit] of (score.credits ?? []).entries()) {
        const partId = sourcePartIds.get(credit.partId); if (!partId) refuse('writer-credit-owner', 'Printed source text links an unknown part.', credit.source);
        miscellaneous.push({ source: credit.source, name: `source-frame-text:${index + 1}:owner`, value: `${partId}:S${credit.staff}:before-M${credit.beforeMeasure + 1}:${credit.frame}` });
        if (credit.sourceStyle) miscellaneous.push({ source: credit.sourceStyle.source, name: `source-frame-text:${index + 1}:style`, value: credit.sourceStyle.value });
        if (!credit.beforeMeasure) continue;
        const part = sourceParts.get(credit.partId)!;
        if (credit.beforeMeasure > part.measures.length) refuse('writer-credit-owner', 'Printed source text lies beyond its part measures.', credit.source);
        const mi = Math.min(credit.beforeMeasure, part.measures.length - 1), directions = frameDirections.get(credit.partId) ?? new Map<number, Direction[]>(), atMeasure = directions.get(mi) ?? [];
        atMeasure.push({ source: credit.source, staff: credit.staff, position: credit.beforeMeasure === part.measures.length ? part.measures[mi].duration : q(0), kind: credit.symbol ? 'symbol' : 'words', ...(credit.symbol ? { symbol: credit.symbol } : { text: credit.text }), ...(credit.textAlignment ? { textAlignment: credit.textAlignment } : {}), ...(credit.textEnclosure ? { textEnclosure: credit.textEnclosure } : {}), ...(credit.textFrameAppearance ? { textFrameAppearance: credit.textFrameAppearance } : {}), ...(credit.textFontFamily ? { textFontFamily: credit.textFontFamily } : {}), ...(credit.textFontSize ? { textFontSize: credit.textFontSize } : {}), ...(credit.textFontStyle ? { textFontStyle: credit.textFontStyle } : {}), ...(credit.textEmphasis ? { textEmphasis: credit.textEmphasis } : {}), ...(credit.textRuns ? { textRuns: credit.textRuns } : {}), ...(credit.sourceColor ? { sourceColor: credit.sourceColor } : {}), ...(credit.printObject !== undefined ? { printObject: credit.printObject } : {}) });
        directions.set(mi, atMeasure); frameDirections.set(credit.partId, directions);
    }
    for (const [index, view] of (score.alternateViews ?? []).entries()) {
        const viewId = `V${index + 1}`;
        if (view.name) miscellaneous.push({ source: view.name.source, name: `source-view-name:${viewId}`, value: view.name.value });
        for (const fact of view.metadata) miscellaneous.push({ source: fact.source, name: `source-view-metadata:${viewId}:${fact.name}`, value: fact.value });
        for (const [ci, credit] of view.credits.entries()) {
            miscellaneous.push({ source: credit.source, name: `source-view-text:${viewId}:C${ci + 1}:text`, value: credit.text });
            miscellaneous.push({ source: credit.source, name: `source-view-text:${viewId}:C${ci + 1}:owner`, value: `${sourcePartIds.get(credit.partId)}:S${credit.staff}:before-M${credit.beforeMeasure + 1}:${credit.frame}` });
            miscellaneous.push({ source: credit.source, name: `source-view-text:${viewId}:C${ci + 1}:visibility`, value: credit.printObject === false ? 'hidden' : 'visible' });
            if (credit.role) miscellaneous.push({ source: credit.source, name: `source-view-text:${viewId}:C${ci + 1}:role`, value: credit.role });
            if (credit.sourceStyle) miscellaneous.push({ source: credit.sourceStyle.source, name: `source-view-text:${viewId}:C${ci + 1}:style`, value: credit.sourceStyle.value });
        }
        for (const [partIndex, part] of view.parts.entries()) {
            const partId = sourcePartIds.get(part.sourcePartId); if (!partId) refuse('writer-view-link', 'Alternate view links an unknown primary part.', part.source);
            const viewPartId = `${viewId}:VP${partIndex + 1}`;
            miscellaneous.push({ source: part.source, name: `source-view-part-link:${viewPartId}`, value: partId! });
            for (const role of ['track', 'long', 'short', 'instrumentTrack'] as const) { const label = part.names?.[role]; if (label) miscellaneous.push({ source: label.source, name: `source-view-${role}-name:${viewPartId}`, value: label.value }); }
            for (const staff of part.staffs) miscellaneous.push({ source: staff.source, name: `source-view-staff-link:${viewId}:${staff.viewStaffId}`, value: `${partId}:${staff.sourceStaffNumber}` });
        }
    }
    for(const [pi,part] of score.parts.entries())for(const [mi,measure] of part.measures.entries()){
        const keys=[...(measure.staffs??[]).map(staff=>({staff:staff.number,position:q(0),key:staff.key})),...(measure.changes??[]).map(change=>({staff:change.staff,position:change.position,key:change.key}))];
        for(const [index,entry] of keys.entries())if(entry.key?.customDefinitions)miscellaneous.push({source:entry.key.custom!.source,name:`source-custom-key:${partIds[pi]}:M${mi+1}:S${entry.staff}:${entry.position.n}/${entry.position.d}:${index}`,value:JSON.stringify({definitions:entry.key.customDefinitions,tones:entry.key.customTones,projection:entry.key.customProjection})});
    }
    if (miscellaneous.length) { emit('<miscellaneous>'); for (const fact of miscellaneous) emit(`<miscellaneous-field name="${esc(fact.name)}">${esc(fact.value)}</miscellaneous-field>`); emit('</miscellaneous>'); }
    emit('</identification>');
    if (score.sourceView?.concertPitch) emit('<defaults><concert-score/></defaults>');
    for (const credit of score.credits ?? []) if (!credit.beforeMeasure) {
        // Credit words use the same standard text-formatting attributes. Keep
        // source-owned runs, independent color and explicit normal resets.
        pointSizeXml(credit.textFontSize, true);
        const direction: Direction = { ...credit, kind: credit.symbol?'symbol':'words', position: q(0) };
        if(credit.symbol)delete direction.text;
        // Historical User style units are qualified specifically for credits.
        const historicalSize = credit.textFontSize?.pointSize?.context === 'musescore-3.6.1-user-text-style' ? credit.textFontSize : undefined;
        if (historicalSize) delete direction.textFontSize;
        const content = (credit.symbol?glyphXml(credit.symbol,'direction',credit.sourceColor,credit.printObject!==false):directionXml(direction,true)).replace(/<(\/?)(?:words|other-direction)(?=[\s>])/g, '<$1credit-words').replace(/<(\/?)symbol(?=[\s>])/g,'<$1credit-symbol').replace(/ print-object="no"/g,'')
            .replace(/<credit-words(?=[\s>])/g, '<credit-words' + pointSizeXml(historicalSize, true));
        emit(`<credit>${credit.role ? tag('credit-type', credit.role) : ''}${content}</credit>`);
    }
    const pageCredits = new Set<string>();
    for (const pageText of score.sourcePageText ?? []) if (['generic-credit', 'unresolved'].includes(pageText.projection) && pageText.text.trim()) {
        const visible = pageText.conditions.enabled.value && (pageText.conditions.oddEven.value || pageText.parity === 'odd'), key = `${visible}:${pageText.text}`;
        if (pageCredits.has(key)) continue; pageCredits.add(key);
        emit(`<credit><credit-words${visible ? '' : ' color="#00000000"'}>${esc(pageText.text)}</credit-words></credit>`);
    }
    emit('<part-list>');
    const percussionIds = new Map<string, string>();
    const instrumentContextIds = new Map<string, string>();
    for (let i = 0; i < score.parts.length; i++) {
        const p = score.parts[i];
        const channel = p.playbackChannels?.[0];
        const midiXml = (id: string, drum?: number) => {
            const body = (channel?.midiChannel === undefined ? '' : tag('midi-channel', channel.midiChannel + 1))
                + (channel?.bank === undefined ? '' : tag('midi-bank', channel.bank + 1))
                + (p.midiProgram === undefined ? '' : tag('midi-program', p.midiProgram + 1))
                + (drum === undefined ? '' : tag('midi-unpitched', drum + 1))
                + (channel ? tag('volume', Number((channel.volume.value * 100 / 127).toFixed(6))) + tag('pan', Math.trunc((channel.pan.value * 2 - 127) * 90 / 127)) : '');
            return body ? `<midi-instrument id="${id}">${body}</midi-instrument>` : '';
        };
        emit(`<score-part id="${partIds[i]}"><part-name${p.namePrintObject === false ? ' print-object="no"' : ''}>${esc(p.name)}</part-name>${p.abbreviation ? `<part-abbreviation>${esc(p.abbreviation)}</part-abbreviation>` : ''}`);
        const drums = new Map<string, NonNullable<MusicalScore['parts'][number]['percussionInstruments']>[number]>();
        for (const drum of [...(p.percussionInstruments ?? []), ...(p.instrumentChanges ?? []).flatMap(context => context.percussionInstruments ?? [])]) {
            const previous = drums.get(drum.id);
            if (previous && (previous.midi !== drum.midi || previous.name !== drum.name)) refuse('writer-drum-reference', 'Conflicting percussion instrument identities.', drum.source);
            drums.set(drum.id, drum);
        }
        const hasPitched = !drums.size || p.measures.some(measure => measure.voices.some(voice => voice.some(event => event.notes.some(note => note.kind !== 'unpitched'))));
        if (hasPitched) emit(`<score-instrument id="I${i + 1}">${tag('instrument-name', p.instrumentName ?? p.instrument)}${p.instrumentAbbreviation ? tag('instrument-abbreviation', p.instrumentAbbreviation) : ''}${p.instrumentSound ? tag('instrument-sound', p.instrumentSound.value) : ''}</score-instrument>`);
        for (const [di, drum] of [...drums.values()].entries()) {
            const id = `I${i + 1}D${di + 1}`;
            if (percussionIds.has(drum.id)) refuse('writer-drum-reference', 'Percussion instrument identities must be unique across source parts.', drum.source);
            percussionIds.set(drum.id, id); emit(`<score-instrument id="${id}">${tag('instrument-name', drum.name)}</score-instrument>`);
        }
        for (const [ci, context] of (p.instrumentChanges ?? []).entries()) {
            const id = `I${i + 1}C${ci + 1}`, key = `${p.id}\u0000${context.id}`;
            if (instrumentContextIds.has(key)) refuse('writer-instrument-context', 'Repeated source instrument-context identity.', context.source);
            instrumentContextIds.set(key, id);
            emit(`<score-instrument id="${id}">${tag('instrument-name', context.names?.long?.value ?? context.names?.track?.value ?? context.instrumentId?.value ?? 'Source instrument change')}${context.names?.short ? tag('instrument-abbreviation', context.names.short.value) : ''}${context.instrumentId ? tag('instrument-sound', context.instrumentId.value) : ''}</score-instrument>`);
        }
        if (channel?.midiPort !== undefined) emit(`<midi-device port="${channel.midiPort + 1}"/>`);
        if (hasPitched) emit(midiXml(`I${i + 1}`));
        for (const drum of drums.values()) emit(midiXml(percussionIds.get(drum.id)!, drum.midi));
        for (const context of p.instrumentChanges ?? []) if (context.midiProgram !== undefined) {
            if (!Number.isInteger(context.midiProgram) || context.midiProgram < 0 || context.midiProgram > 127) refuse('writer-instrument-program', 'Source instrument program must be a MIDI program from 0 to 127.', context.source);
            emit(`<midi-instrument id="${instrumentContextIds.get(`${p.id}\u0000${context.id}`)}">${tag('midi-program', context.midiProgram + 1)}</midi-instrument>`);
        }
        emit('</score-part>');
    }
    emit('</part-list>');
    for (let pi = 0; pi < score.parts.length; pi++) {
        const p = score.parts[pi];
        const laterTuning = p.measures.flatMap(measure => measure.changes ?? []).find(change => change.tuning?.length)?.tuning ?? p.instrumentChanges?.find(context => context.tuning?.length)?.tuning;
        const carrierTuning = p.tuning ?? laterTuning;
        const harmonicTranspose = harmonicTransposes(p);
        const voicePlayback = new Map(p.staves?.flatMap(staff => staff.voicePlayback?.map(setting => [setting.voiceId, setting.play] as const) ?? []));
        const previousClefs = new Map<number, string>();
        const previousStaffSizes = new Map<number, number>();
        const previousStaffDetails = new Map<number, { key: string; color: boolean; hiddenLines: boolean }>();
        const initialStaffCapos = new Map<number, number>();
        const initialHeaders = new Map<number, StaffChange>(), initialChanges = new Map<number, StaffChange>();
        const initialRoleOrder = new Map<StaffChange, number>();
        emit(`<part id="${partIds[pi]}">`);
        for (let mi = 0; mi < p.measures.length; mi++) {
            const m = p.measures[mi];
            const sourceStaves = m.staffs ?? p.staves ?? [{ number: 1, source: m.source, clef: m.clef }];
            const staffNumbers = mi === 0 ? new Set(sourceStaves.map(staff => staff.number)) : undefined;
            if (mi === 0) for (let index = 0; index < (m.changes?.length ?? 0); index++) {
                const change = m.changes![index]; if (!change.clefRole) continue;
                if (!change.clef || change.courtesy || change.position.n !== 0 || !staffNumbers!.has(change.staff) || !['header', 'change'].includes(change.clefRole.value)) refuse('writer-clef-role', 'Qualified initial clef role needs its actual first-measure zero-clock staff occurrence.', change.source);
                const map = change.clefRole.value === 'header' ? initialHeaders : initialChanges;
                if (map.has(change.staff)) refuse('writer-clef-role', 'Ambiguous initial clef role ownership.', change.source);
                map.set(change.staff, change); initialRoleOrder.set(change, index);
            }
            if (mi === 0) for (const staff of new Set([...initialHeaders.keys(), ...initialChanges.keys()])) {
                const header = initialHeaders.get(staff), change = initialChanges.get(staff);
                if (!header || !change || header.clef === change.clef || initialRoleOrder.get(header)! >= initialRoleOrder.get(change)!) refuse('writer-clef-role', 'Initial header projection needs its ordered distinct source change.', (header ?? change)!.source);
            }
            const carrier = !!carrierTuning?.length && !sourceStaves.some(s => s.kind === 'tablature' && s.tuning?.length);
            const carrierNumber = sourceStaves.length + 1;
            if (p.capo && !carrier && !sourceStaves.some(s => s.kind === 'tablature' && s.tuning?.length)) refuse('writer-capo', 'Full capo requires non-capo tuning on a TAB staff or alternate carrier.', p.capo.source);
            for (const staff of sourceStaves) {
                if (staff.tuning?.length && staff.kind !== 'tablature') refuse('writer-tuning-staff', 'String tuning must use a TAB staff or alternate carrier, never change ordinary staff geometry.', staff.source);
                if (staff.capo && (staff.kind !== 'tablature' || !staff.tuning?.length)) refuse('writer-capo', 'Staff capo requires an explicitly tuned TAB staff.', staff.capo.source);
                if (staff.capo && p.capo && staff.capo.fret !== p.capo.fret) refuse('writer-capo', 'Part and staff full capo declarations conflict.', staff.capo.source);
                const capo = staff.capo ?? p.capo;
                if (capo) capoXml(capo);
                if (mi === 0) initialStaffCapos.set(staff.number, capo?.fret ?? 0);
                else if ((capo?.fret ?? 0) !== (initialStaffCapos.get(staff.number) ?? 0)) refuse('writer-capo-change', 'Changing capo within a part is not yet supported.', capo?.source ?? staff.source);
            }
            emit(`<measure number="${mi + 1}"${m.numbering?.displayNumber !== undefined ? ` text="${m.numbering.displayNumber}"` : ''}${(m.implicit ?? m.pickup) ? ' implicit="yes"' : ''}>`);
            if(m.numbering){
                const mode=m.numbering.mode?.value==='hide'?'none':m.numbering.mode?.value==='show'?'measure':m.numbering.automatic;
                const appearances=m.numbering.appearances??[];
                if(!appearances.length)emit(`<print>${tag('measure-numbering',mode)}</print>`);
                else for(const appearance of appearances){
                    if(!p.staves?.some(staff=>staff.number===appearance.staff))refuse('writer-measure-number-owner','Measure-number presentation needs an actual staff.',appearance.source);
                    const alignment=appearance.textAlignment;
                    emit(`<print><measure-numbering staff="${appearance.staff}"${plainTextFontXml(appearance)}${colorXml(appearance.sourceColor,appearance.printObject!==false)}${alignment?.halign?` halign="${esc(alignment.halign)}"`:''}${alignment?.valign?` valign="${esc(alignment.valign)}"`:''}>${appearance.printObject===false||appearance.projection==='words'?'none':mode}</measure-numbering></print>`);
                }
            }
            emit(`<attributes>${tag('divisions', d)}`);
            for (const staff of sourceStaves) {
                const key = staff.key ?? m.key;
                emit(keySignatureXml(key,sourceStaves.length>1?staff.number:undefined));
            }
            if (sourceStaves.length > 1 && sourceStaves.some(staff => staff.time && !sameMeter(staff.time, m.time))) {
                for (const staff of sourceStaves) emit(meterXml(staff.time ?? m.time, staff.number));
            } else emit(meterXml(sourceStaves[0].time ?? m.time));
            if (mi === 0 && (sourceStaves.length > 1 || carrier)) emit(tag('staves', sourceStaves.length + (carrier ? 1 : 0)));
            for (const staff of sourceStaves) {
                const header = mi === 0 ? initialHeaders.get(staff.number) : undefined;
                emit(clefXml(header ? { ...staff, source: header.source, clef: header.clef!, clefPrintObject: header.printObject } : staff));
            }
            if(mi===0&&carrier)emit(`<clef number="${carrierNumber}" print-object="no"><sign>TAB</sign></clef>`);
            for (const staff of sourceStaves) if (staff.printObject !== undefined) emit(`<staff-details number="${staff.number}" print-object="${staff.printObject ? 'yes' : 'no'}"${staff.printObject===false && staff.cutaway?.value?' print-spacing="yes"':''}/>`);
            for (const staff of sourceStaves) if (staff.staffSize && (previousStaffSizes.get(staff.number) ?? 100) !== staff.staffSize.percent) {
                if (!Number.isFinite(staff.staffSize.percent) || staff.staffSize.percent <= 0 || staff.staffSize.percent > 400) refuse('writer-staff-size', 'Unverified source staff-size percentage.', staff.staffSize.source);
                emit(`<staff-details number="${staff.number}">${tag('staff-size', staff.staffSize.percent)}</staff-details>`); previousStaffSizes.set(staff.number, staff.staffSize.percent);
            }
            if (mi === 0 && carrier) {
                // An empty, nonprinting alternate TAB staff carries complete physical tuning.
                // Source notes occur only on staff 1; this is not a source staff or retuning mark.
                emit(`<staff-details number="${carrierNumber}" print-object="no" print-spacing="no"><staff-type>alternate</staff-type>${tag('staff-lines', carrierTuning!.length)}`);
                if(p.tuning?.length)emit(tuningEntries(p.tuning));
                emit(capoXml(p.capo));
                emit('</staff-details>');
            }
            for (const staff of sourceStaves) {
                const lines=staff.lines??staff.tuning?.length??5;
                if(!Number.isInteger(lines)||lines<0||lines>16)refuse('writer-staff-lines','Staff line count must be a bounded nonnegative integer.',staff.source);
                const state=JSON.stringify([staff.kind??'pitched',lines,staff.tuning,staff.capo??p.capo,staff.sourceColor?.rgba,staff.lineVisibility?.value,staff.notation?.useNumbers?.value,staff.notation?.upsideDown?.value]);
                const prior=previousStaffDetails.get(staff.number);
                // Five lines are the standard initial default; later transitions
                // back to five must still be explicit. Keep the source snapshot.
                if(prior?.key!==state && (prior!==undefined || lines!==5 || staff.tuning?.length || staff.capo || p.capo || staff.sourceColor || staff.lineVisibility || staff.notation?.useNumbers || staff.notation?.upsideDown)) {
                    emit(`<staff-details number="${staff.number}"${staff.kind==='tablature' ? ` show-frets="${staff.notation?.useNumbers?.value===false ? 'letters' : 'numbers'}"` : ''}>${tag('staff-lines',lines)}`);
                    if(staff.sourceColor || staff.lineVisibility || prior?.color || prior?.hiddenLines)for(let line=1;line<=lines;line++)emit(`<line-detail line="${line}"${staff.sourceColor ? colorXml(staff.sourceColor,true) : prior?.color ? ' color="#FF000000"' : ''}${staff.lineVisibility || prior?.hiddenLines ? ` print-object="${staff.lineVisibility?.value===false?'no':'yes'}"` : ''}/>`);
                    if(staff.tuning?.length)emit(tuningEntries(staff.tuning,staff.notation?.upsideDown?.value));
                    emit(capoXml(staff.capo??p.capo)); emit('</staff-details>');
                }
                previousStaffDetails.set(staff.number,{key:state,color:!!staff.sourceColor,hiddenLines:staff.lineVisibility?.value===false});
            }
            if (mi === 0 && (p.transpose || p.transposeOctaves)) emit(`<transpose>${tag('diatonic', p.transpose?.diatonic ?? 0)}${tag('chromatic', p.transpose?.chromatic ?? 0)}${p.transpose?.octaveChange || p.transposeOctaves ? tag('octave-change', p.transpose?.octaveChange ?? p.transposeOctaves) : ''}</transpose>`);
            for (const rest of m.collapsedRests ?? []) emit(`<measure-style number="${rest.staff}">${tag('multiple-rest', rest.count)}</measure-style>`);
            for (const repeat of m.measureRepeats ?? []) {
                if (!sourceStaves.some(staff => staff.number === repeat.staff) || !['start', 'stop'].includes(repeat.type) || ![1, 2, 4].includes(repeat.count) || repeat.slashes !== undefined && ![1, 2, 4].includes(repeat.slashes)) refuse('writer-measure-repeat', 'Measure-repeat style requires an actual source staff and a qualified source pattern.', repeat.source);
                emit(`<measure-style number="${repeat.staff}"${colorXml(repeat.sourceColor,repeat.printObject!==false)}${repeat.fontSize?` font-size="${glyphPointSize(repeat.fontSize)}"`: ''}><measure-repeat type="${repeat.type}"${repeat.slashes ? ` slashes="${repeat.slashes}"` : ''}>${repeat.type === 'start' ? repeat.count : ''}</measure-repeat></measure-style>`);
            }
            emit('</attributes>');
            for(const staff of sourceStaves)emit(keyInstructionXml(staff.key??m.key,staff.number));
            if(mi===0){if(p.tuning&&tuningFallback(p.tuning))emit(directionXml({source:p.source,position:q(0),staff:1,kind:'words',text:tuningFallback(p.tuning)}));for(const staff of sourceStaves)if(staff.tuning&&tuningFallback(staff.tuning))emit(directionXml({source:staff.source,position:q(0),staff:staff.number,kind:'words',text:tuningFallback(staff.tuning)}));}
            for (const staff of sourceStaves) {
                if (staff.clefBadge && previousClefs.get(staff.number) !== staff.clef)
                    emit(directionXml({ source: staff.clefBadge.source, position: q(0), staff: staff.number, kind: 'words', text: '(optional octave below)', ...(staff.clefPrintObject === false || staff.printObject === false ? { printObject: false } : {}) }));
                previousClefs.set(staff.number, staff.clef);
            }
            const hideStaffBarlines = sourceStaves.length > 0 && sourceStaves.every(staff => staff.notation?.showBarlines?.value === false);
            const barlineXml = (barline: NonNullable<typeof m.barlines>[number], repeat = '') => `<barline location="${barline.location}"><bar-style${barline.printObject === false || hideStaffBarlines && barline.location === 'right' ? ' color="#00000000"' : ''}>${barline.style}</bar-style>${barline.fermata ? `<fermata type="${barline.fermata.inverted ? 'inverted' : 'upright'}"${barline.fermata.printObject === false ? ' color="#00000000"' : ''}>${barline.fermata.shape === 'normal' ? '' : barline.fermata.shape}</fermata>` : ''}${repeat}</barline>`;
            // A shared native boundary may appear in several staff sections. One equivalent
            // part boundary carries its repeat, rather than adding a second barline there.
            const boundary = (location: 'left' | 'right', repeat: string) => {
                const seen = new Set<string>(); let emitted = false;
                for (const barline of m.barlines ?? []) if (barline.location === location) {
                    const key = `${barline.style}:${barline.fermata?.shape ?? ''}:${barline.fermata?.inverted ?? ''}`;
                    if (seen.has(key)) continue; seen.add(key);
                    emit(barlineXml(barline, emitted ? '' : repeat)); emitted = true;
                }
                if (!emitted && (repeat || hideStaffBarlines && location === 'right')) emit(`<barline location="${location}">${hideStaffBarlines && location === 'right' ? '<bar-style>none</bar-style>' : ''}${repeat}</barline>`);
            };
            boundary('left', m.repeatStart ? '<repeat direction="forward"/>' : '');
            // Located attributes and middle bars use a clock-only stream, then return to the first music voice.
            // This preserves all staff changes once without fabricating printed rests or duplicating note events.
            const timeline: { position: number; xml: string }[] = [];
            const lastClefChanges = new Map<number, NonNullable<typeof m.changes>[number]>();
            for (const change of m.changes ?? []) {
                if (mi !== 0 && change.clefRole) refuse('writer-clef-role', 'Initial header role cannot be moved to a later source measure.', change.source);
                const initialChange = initialChanges.get(change.staff) === change;
                if (change.courtesy || change.position.n === 0 && !initialChange && !change.tuning && !change.capo && !change.transpose) continue;
                let xml = '';
                if (change.key) xml += keySignatureXml(change.key,change.staff,change.printObject===false);
                if (change.time) xml += meterXml(change.time, change.staff);
                if (change.clef) xml += clefXml({ source: change.source, number: change.staff, clef: change.clef, clefPrintObject: change.printObject }, initialChange);
                if (change.clef && (!lastClefChanges.has(change.staff) || compare(change.position, lastClefChanges.get(change.staff)!.position) >= 0)) lastClefChanges.set(change.staff, change);
                if (change.tuning || change.capo) {
                    if (change.tuning?.some(midi => !Number.isInteger(midi) || midi < 0 || midi > 127) || change.tuning && (!change.tuning.length || change.tuning.length > 32)) refuse('writer-tuning-change', 'Tuning change needs bounded explicit open-string pitches.', change.source);
                    const sourceStaff = sourceStaves.find(staff => staff.number === change.staff);
                    const targetStaff = sourceStaff?.kind === 'tablature' ? change.staff : carrier ? carrierNumber : undefined;
                    if (!targetStaff) refuse('writer-tuning-change', 'Physical tuning change needs an actual or alternate TAB carrier.', change.source);
                    xml += `<staff-details number="${targetStaff}"${targetStaff === carrierNumber && carrier ? ' print-object="no" print-spacing="no"' : ''}>${change.tuning ? tag('staff-lines', change.tuning.length) + tuningEntries(change.tuning,sourceStaves.find(staff=>staff.number===targetStaff)?.notation?.upsideDown?.value) : ''}${capoXml(change.capo)}</staff-details>`;
                }
                if (change.transpose) xml += `<transpose number="${change.staff}">${tag('diatonic', change.transpose.diatonic)}${tag('chromatic', change.transpose.chromatic)}${change.transpose.octaveChange ? tag('octave-change', change.transpose.octaveChange) : ''}</transpose>`;
                if (xml) timeline.push({ position: ticks(change.position), xml: `<attributes>${xml}</attributes>${change.key?keyInstructionXml(change.key,change.staff):''}${change.tuning&&tuningFallback(change.tuning)?directionXml({source:change.source,position:q(0),staff:change.staff,kind:'words',text:tuningFallback(change.tuning)}):''}${change.clefBadge ? directionXml({ source: change.clefBadge.source, position: q(0), staff: change.staff, kind: 'words', text: '(optional octave below)', ...(change.printObject === false ? { printObject: false } : {}) }) : ''}` });
            }
            for (const [staff, change] of lastClefChanges) previousClefs.set(staff, change.clef!);
            for (const barline of m.barlines ?? []) if (barline.location === 'middle') timeline.push({ position: ticks(barline.position), xml: barlineXml(barline) });
            timeline.sort((a, b) => a.position - b.position);
            let timelineCursor = 0;
            for (const item of timeline) {
                if (item.position < 0 || item.position > ticks(m.duration)) refuse('writer-attribute-clock', 'Located source attribute/barline lies outside its declared measure.', m.source);
                if (item.position > timelineCursor) emit(`<forward>${tag('duration', item.position - timelineCursor)}</forward>`);
                emit(item.xml); timelineCursor = item.position;
            }
            if (timelineCursor) emit(`<backup>${tag('duration', timelineCursor)}</backup>`);
            for (const tempo of score.tempos.filter(t => t.measure === mi)) {
                emit(`<direction><direction-type><metronome${tempo.visible && !display.hideTempo ? '' : ' print-object="no"'}>${tag('beat-unit', tempo.unit)}${'<beat-unit-dot/>'.repeat(tempo.dots)}${tag('per-minute', tempo.rate)}</metronome></direction-type><offset sound="yes">${ticks(tempo.position)}</offset><staff>1</staff><sound tempo="${tempo.quarterRate}"/></direction>`);
            }
            for (const image of imageDirections.get(`${p.id}\u0000${mi}`) ?? []) emit(image);
            for (const capo of p.capoChanges?.filter(capo => capo.measure === mi) ?? []) {
                if (!Number.isSafeInteger(capo.fret) || capo.fret < 0 || !sourceStaves.some(staff => staff.number === capo.staff) || compare(capo.position, q(0)) < 0 || compare(capo.position, m.duration) > 0 || capo.ignoredStrings?.values.some(string => !Number.isInteger(string) || string < 1 || string > 32)) refuse('writer-capo-change', 'Capo instruction needs valid source staff, clock and strings.', capo.source);
                const applied=capo.appliedStrings;
                if(applied&&(!Number.isInteger(applied.stringCount)||applied.stringCount<1||applied.stringCount>32||new Set(applied.values).size!==applied.values.length||applied.values.some(string=>!Number.isInteger(string)||string<1||string>applied.stringCount||capo.ignoredStrings?.values.includes(string))||(!capo.active||capo.fret===0)&&applied.values.length))refuse('writer-capo-strings','Applied capo strings require their exact source tuning and original mask.',applied.source);
                if(applied&&capo.active&&capo.fret>0&&Array.from({length:applied.stringCount},(_,i)=>i+1).some(string=>applied.values.includes(string)===!!capo.ignoredStrings?.values.includes(string)))refuse('writer-capo-strings','Applied capo strings must retain the complete source mask complement.',applied.source);
                const ignored=applied?Array.from({length:applied.stringCount},(_,i)=>i+1).filter(string=>!applied.values.includes(string)):capo.ignoredStrings?.values;
                const text = capo.text ?? (!capo.active || capo.fret === 0 || applied?.values.length===0 ? 'Capo off' : `Capo ${capo.fret}${ignored?.length ? ` (except strings ${ignored.join(', ')})` : ''}`);
                emit(directionXml({ source: capo.source, kind: 'words', position: capo.position, staff: capo.staff, text, printObject: capo.printObject }));
            }
            for (const direction of m.directions ?? []) emit(directionXml(direction));
            // Lyric text lacks relative-y. Preserve its syllable/extension lane
            // with transparent text and render the exact scripted caption as
            // located standard words; lyric hyphens and extenders stay native
            // standard lyric content rather than being reconstructed as text.
            for (const voice of m.voices) for (const event of voice) for (const lyric of event.notes.length ? event.notes.flatMap(note => note.lyrics ?? []) : event.lyrics ?? []) if (scriptCaption(lyric.textRuns)) {
                emit(directionXml({ ...lyric, source: lyric.source ?? event.source, kind: 'words', position: event.start, staff: event.staff ?? 1, voiceId: event.voiceId, placement: lyric.placement ?? 'below' }));
            }
            for (const direction of frameDirections.get(p.id)?.get(mi) ?? []) emit(directionXml(direction));
            for (const { relation, start } of relationMarks.get(p.id)?.get(mi) ?? []) {
                const endpoint = start ? relation.start : relation.end;
                if (relation.kind === 'ottava' || relation.kind === 'text-line') {
                    const number = relation.kind === 'ottava' || relation.lineVisible !== false ? serializedNumber(relation.id) : undefined;
                    const text = start ? relation.beginText ?? (relation.kind === 'ottava' && relation.projection ? `${Math.abs(relation.octaves) * 7 + 1}${Math.abs(relation.octaves) === 1 ? relation.octaves > 0 ? 'va' : 'vb' : relation.octaves > 0 ? 'ma' : 'mb'}` : undefined) : relation.endText;
                    const visibility = colorXml(relation.sourceColor, relation.printObject !== false);
                    const field = start ? 'beginText' : 'endText', style = relation.textFontStyles?.[field], size = relation.textFontSizes?.[field], family = relation.textFontFamilies?.[field];
                    const caption = text && (style || size || family) ? directionXml({ source: relation.textFacts?.[field]?.source ?? relation.source, position: endpoint.position, staff: endpoint.staff, kind: 'words', text, ...(style ? { textFontStyle: style } : {}), ...(size ? { textFontSize: size } : {}), ...(family ? { textFontFamily: family } : {}),
                        ...(relation.textRuns?.[field] ? { textRuns: relation.textRuns[field] } : {}), ...(relation.sourceColor ? { sourceColor: relation.sourceColor } : {}), ...(relation.printObject !== undefined ? { printObject: relation.printObject } : {}) }, true) : text ? `<words${visibility}>${esc(text)}</words>` : '';
                    let content = caption ? `<direction-type>${caption}</direction-type>` : '';
                    if (relation.kind === 'ottava' && relation.projection) {
                        if (relation.lineVisible !== false) content += `<direction-type><bracket type="${start ? 'start' : 'stop'}" number="${number}" line-end="${start ? relation.startHook ?? 'none' : relation.endHook ?? (relation.octaves > 0 ? 'down' : 'up')}" line-type="${relation.lineType ?? 'dashed'}"${visibility}/></direction-type>`;
                    } else if (relation.kind === 'ottava') content += `<direction-type><octave-shift type="${!start ? 'stop' : relation.octaves > 0 ? 'down' : 'up'}" size="${Math.abs(relation.octaves) * 7 + 1}" number="${number}"${visibility}/></direction-type>`;
                    else if (relation.lineVisible !== false) {
                        const name = relation.line, grid=grids.levels.get(relation.id);
                        const gridPosition=grid?` id="tab-grid-${grid.serial}-${start?'start':'stop'}" default-y="${40+(grid.count-grid.index)*5}"${grid.index===1?` end-length="${10+(grid.count-1)*5}"`:''}`:'';
                        content += `<direction-type><${name} type="${start ? 'start' : 'stop'}" number="${number}"${name === 'bracket' ? ` line-end="${(start ? relation.startHook : relation.endHook) ?? 'none'}" line-type="${relation.lineType ?? 'solid'}"${gridPosition}` : ''}${visibility}/></direction-type>`;
                    }
                    if (content) emit(`<direction${relation.system ? ' system="only-top"' : ''}${relation.placement ? ` placement="${relation.placement.value}"` : ''}>${content}${tag('offset', ticks(endpoint.position))}${endpoint.voiceId ? tag('voice', endpoint.voiceId) : ''}${tag('staff', endpoint.staff)}</direction>`);
                } else if (relation.kind === 'ending') {
                    if (relation.projection) {
                        const number = serializedNumber(relation.id), visibility = relation.printObject === false ? ' color="#00000000"' : '', text = start ? relation.beginText : relation.endText;
                        const content = `${text ? `<direction-type><words${visibility}>${esc(text)}</words></direction-type>` : ''}${relation.lineVisible !== false ? `<direction-type><bracket type="${start ? 'start' : 'stop'}" number="${number}" line-end="${start ? relation.startHook ?? 'down' : relation.closed ? relation.endHook ?? 'down' : 'none'}" line-type="${relation.lineType ?? 'solid'}"${visibility}/></direction-type>` : ''}`;
                        if (content) emit(`<direction${relation.placement ? ` placement="${relation.placement.value}"` : ''}>${content}${tag('offset', ticks(endpoint.position))}${endpoint.voiceId ? tag('voice', endpoint.voiceId) : ''}${tag('staff', endpoint.staff)}</direction>`);
                    } else {
                        const location = start ? 'left' : endpoint.position.n === 0 ? 'left' : 'right';
                        emit(`<barline location="${location}"><ending number="${relation.numbers.join(',')}" type="${start ? 'start' : relation.closed ? 'stop' : 'discontinue'}"${relation.printObject === false ? ' print-object="no"' : ''}>${esc(start ? relation.beginText ?? '' : '')}</ending></barline>`);
                    }
                } else refuse('writer-relation', 'Relation kind needs an explicit common-writer projection.', relation.source);
            }
            let cursor = 0;
            for (let vi = 0; vi < m.voices.length; vi++) {
                if (!m.voices[vi].length) continue;
                if (cursor) emit(`<backup>${tag('duration', cursor)}</backup>`);
                cursor = 0;
                for (const e of m.voices[vi]) {
                    const staff = e.staff ?? 1, voice = e.voiceId ?? String(vi + 1), start = ticks(e.start);
                    if (start < cursor) refuse('writer-overlap', 'Events overlap within one source voice.', e.source);
                    if (start > cursor) emit(`<forward>${tag('duration', start - cursor)}${tag('voice', voice)}${tag('staff', staff)}</forward>`);
                    if (e.dynamic && !display.hideDynamics) emit(`<direction><direction-type><dynamics><${e.dynamic.toLowerCase()}/></dynamics></direction-type>${tag('voice', voice)}${tag('staff', staff)}</direction>`);
                    if (e.text) emit(`<direction><direction-type>${tag('words', e.text)}</direction-type>${tag('voice', voice)}${tag('staff', staff)}</direction>`);
                    for(const note of e.notes)for(const finger of note.fingerings??[])if(fingeringNeedsWords(finger)) {
                        emit(directionXml({...finger,kind:'words',text:finger.value,position:q(0),staff,voiceId:voice,
                            printObject:e.printObject!==false&&note.printObject!==false&&finger.printObject!==false}));
                    }
                    // Numeric fret remains the machine-readable physical fact.
                    // Formatted words replace its visible copy only when the
                    // source requests emphasis unavailable on MusicXML fret.
                    for(const note of e.notes)if(note.fret!==undefined&&note.string!==undefined&&note.tabFretFont?.style&&(note.tabFretFont.style&12)) {
                        const tabStaff=sourceStaves.find(item=>item.number===staff&&item.kind==='tablature');if(!tabStaff)continue;
                        const font=note.tabFretFont,number=tabStaff.notation?.useNumbers?.value!==false;
                        const fretText=note.kind==='dead'?'x':number?(note.fret<100?String(note.fret):'?'):note.fret<17?String.fromCharCode(97+note.fret):'?';
                        const text=(note.tabFret?.parentheses??note.noteheadParentheses?.value)?`(${fretText})`:fretText;
                        const row=(tabStaff.notation?.upsideDown?.value?(tabStaff.lines??tabStaff.tuning?.length??5)-note.string:note.string-1)-(tabStaff.tablature?.onLines.value===false?0.5:0);
                        const visible=note.printObject!==false&&e.printObject!==false&&note.tabFret?.printObject!==false;
                        emit(`<direction><direction-type><words default-y="${-10*row}" halign="center" valign="middle"${colorXml(note.noteheadColor,visible)}${font.family?` font-family="${esc(font.family)}"`:''}${font.size?` font-size="${font.size}"`:''} font-weight="${font.style!&1?'bold':'normal'}" font-style="${font.style!&2?'italic':'normal'}" underline="${font.style!&4?1:0}" line-through="${font.style!&8?1:0}">${esc(text)}</words></direction-type>${tag('voice',voice)}${tag('staff',staff)}</direction>`);
                    }
                    if(e.tabRhythm?.durationSymbol) {
                        const sign=e.tabRhythm.durationSymbol;
                        const glyph:Record<string,string>={maxima:'mensuralWhiteMaxima',long:'mensuralWhiteLonga',breve:'noteDoubleWhole',whole:'noteWhole',half:'noteHalfUp',quarter:'noteQuarterUp',eighth:'note8thUp','16th':'note16thUp','32nd':'note32ndUp','64th':'note64thUp','128th':'note128thUp','256th':'note256thUp','512th':'note512thUp','1024th':'note1024thUp'};
                        if(!glyph[sign.type] || !Number.isInteger(sign.dots)||sign.dots<0||sign.dots>4)refuse('writer-tab-duration','TAB duration sign needs a standard written value and dot count.',sign.source);
                        emit(`<direction placement="above"><direction-type><symbol${e.printObject===false?' color="#00000000"':''}${sign.fontSize?` font-size="${sign.fontSize}"`:''}>${glyph[sign.type]}</symbol>${`<symbol${e.printObject===false?' color="#00000000"':''}>augmentationDot</symbol>`.repeat(sign.dots)}</direction-type>${tag('voice',voice)}${tag('staff',staff)}</direction>`);
                    }
                    for (const instruction of e.performerInstructions ?? []) emit(`<direction><direction-type>${tag('words', instruction.text)}</direction-type>${tag('voice', voice)}${tag('staff', staff)}</direction>`);
                    // MusicXML note-attached other-notation lacks rotation. Keep its hidden
                    // attachment and draw the same glyph once at this exact event clock.
                    for(const [note,glyphs] of [[undefined,e.symbols ?? []],...e.notes.map(note=>[note,note.symbols ?? []] as const)] as const) for(const glyph of glyphs) if(rotatedGlyph(glyph)) {
                        emit(directionXml({source:glyph.source,position:q(0),staff,voiceId:voice,kind:'symbol',symbol:glyph,printObject:e.printObject !== false && note?.printObject !== false}));
                    }
                    // Directions do not advance either the note clock or the figured-bass interval clock.
                    for (const figure of e.figuredBass ?? []) if (figure.literalBracketText !== undefined) {
                        emit(`<direction${figure.placement ? ` placement="${figure.placement}"` : ''}><direction-type><words${colorXml(figure.sourceColor, figure.printObject !== false)}>${esc(figure.literalBracketText)}</words></direction-type>${tag('offset', ticks(figure.projection.offset))}${tag('voice', voice)}${tag('staff', staff)}</direction>`);
                    }
                    let figureClock = e.start;
                    for (const figure of e.figuredBass ?? []) {
                        if (e.grace || figure.projection.hostEventId !== e.id || compare(figure.position, figureClock) < 0 || figure.duration.n <= 0 || !figure.items.length) refuse('writer-figured-bass', 'Figured bass must retain its verified regular host and ordered exact source intervals.', figure.source);
                        const gap = add(figure.position, q(-figureClock.n, figureClock.d));
                        if (gap.n) emit(`<figured-bass print-object="no"><figure/>${tag('duration', ticks(gap))}</figured-bass>`);
                        emit(`<figured-bass${figure.printObject === false || figure.literalBracketText !== undefined ? ' print-object="no"' : ''}${figure.placement ? ` placement="${figure.placement}"` : ''}${figure.parentheses ? ' parentheses="yes"' : ''}${colorXml(figure.sourceColor, true)}>`);
                        for (const item of figure.items) {
                            const modifiers = ['', 'flat-flat', 'flat', 'natural', 'sharp', 'double-sharp', 'plus', 'back-slash', 'slash'];
                            if (item.digit && (!Number.isInteger(item.digit.value) || item.digit.value < 0) || [item.prefix, item.suffix].some(modifier => modifier && modifiers[modifier.encoded] !== modifier.value)) refuse('writer-figured-bass', 'Invalid figured-bass figure vocabulary.', item.source);
                            const extension = item.continuation?.value;
                            if (extension !== undefined && ![0, 1, 2].includes(extension)) refuse('writer-figured-bass', 'Invalid figured-bass continuation.', item.source);
                            emit(`<figure>${item.prefix?.value ? tag('prefix', item.prefix.value) : ''}${item.digit ? tag('figure-number', item.digit.value) : ''}${item.suffix?.value ? tag('suffix', item.suffix.value) : ''}${extension ? `<extend${extension === 1 ? '' : ` type="${item.digit || item.prefix?.value || item.suffix?.value ? 'start' : 'continue'}"`}/>` : ''}</figure>`);
                        }
                        emit(`${tag('duration', ticks(figure.duration))}</figured-bass>`); figureClock = add(figure.position, figure.duration);
                    }
                    const notes = e.notes.length ? harmonicComponents(e.notes, harmonicTranspose.get(e)) : [undefined];
                    const groupNotes = e.noteheadGroups?.length ? new Set<string>() : undefined;
                    const groupIds = e.noteheadGroups?.length ? new Map<string, { noteId: string; sourceIndex: number }>() : undefined;
                    for (const group of e.noteheadGroups ?? []) {
                        if (group.members.length !== 1 || group.sidesOrigin !== 'native-default') refuse('writer-notehead-group', 'Unverified note enclosure group projection.', group.source);
                        const member = group.members[0];
                        const original = group.duplicateOf ? groupIds!.get(group.duplicateOf) : undefined;
                        if (!Number.isInteger(member.sourceIndex) || e.notes[member.sourceIndex]?.id !== member.noteId || groupIds!.has(group.id)
                            || groupNotes!.has(member.noteId) && (!original || original.noteId !== member.noteId || original.sourceIndex !== member.sourceIndex || e.notes[member.sourceIndex].noteheadParentheses?.value !== true)
                            || group.duplicateOf && !groupNotes!.has(member.noteId)) refuse('writer-notehead-group', 'Unresolved or repeated note enclosure member.', member.source);
                        groupIds!.set(group.id, { noteId: member.noteId, sourceIndex: member.sourceIndex });
                        groupNotes!.add(member.noteId);
                    }
                    for (let ni = 0; ni < notes.length; ni++) {
                        const n = notes[ni];
                        const visualTabStaff = sourceStaves.find(sourceStaff => sourceStaff.number === staff && sourceStaff.kind === 'tablature');
                        // This is source musical string order, not native page placement.
                        const tabVisualLine = n?.string !== undefined && visualTabStaff && (visualTabStaff.notation?.upsideDown?.value || visualTabStaff.tablature?.onLines.value === false)
                            ? (visualTabStaff.notation?.upsideDown?.value ? (visualTabStaff.lines ?? visualTabStaff.tuning?.length ?? 5) - n.string : n.string - 1) - (visualTabStaff.tablature?.onLines.value === false ? 0.5 : 0) : undefined;
                        if (n?.attack && n.tieStop || n?.release && n.tieStart) refuse('writer-performance-tie', 'Performance start/stop offsets must occur at the appropriate tie endpoints.', n?.source);
                        emit(`<note${tabVisualLine !== undefined ? ` default-y="${-10 * tabVisualLine}"` : ''}${e.crossMeasureValue?.role === 'continuation' ? ' print-leger="no"' : n?.printLedgerLines ? ` print-leger="${n.printLedgerLines.value ? 'yes' : 'no'}"` : ''}${n?.printObject === false || e.printObject === false ? ' print-object="no"' : ''}${n?.attack?.n ? ` attack="${ticks(n.attack)}"` : ''}${n?.release?.n ? ` release="${ticks(n.release)}"` : ''}${n && (n.performance?.play === false || voicePlayback.get(voice) === false) ? ' dynamics="0"' : n?.sourceVelocity?.mode === 'absolute' ? ` dynamics="${(n.sourceVelocity.value / 90 * 100).toFixed(2)}"` : ''}>${e.grace ? `<grace${e.grace.slash ? ' slash="yes"' : ''}/>` : n?.cue ? '<cue/>' : ''}` + (ni ? '<chord/>' : ''));
                        if (n?.kind === 'unpitched' && (n.unpitched.displayStep === undefined) !== (n.unpitched.displayOctave === undefined)) refuse('writer-unpitched-position', 'Unpitched display step and octave must occur together or remain explicitly unspecified.', n.source);
                        if (n?.kind === 'unpitched' && n.unpitched.displayStep === undefined && n.unpitched.displayUnspecified?.reason !== 'unassigned-source-articulation') refuse('writer-unpitched-position', 'Absent display position requires a qualified source uncertainty.', n.source);
                        emit(!n ? `<rest${e.fullMeasureRest ? ' measure="yes"' : ''}/>` : n.kind === 'unpitched'
                            ? n.unpitched.displayStep === undefined ? '<unpitched/>' : `<unpitched>${tag('display-step', n.unpitched.displayStep)}${tag('display-octave', n.unpitched.displayOctave)}</unpitched>`
                            : n.kind === 'dead' ? `<unpitched>${tag('display-step', n.written.step)}${tag('display-octave', n.written.octave)}</unpitched>` : `<pitch>${pitchXml(n.printedOctaveShift || n.octaveShift ? { ...n.written, octave: n.written.octave + (n.printedOctaveShift?.octaves ?? n.octaveShift!.octaves), midi: n.written.midi + (n.printedOctaveShift?.octaves ?? n.octaveShift!.octaves) * 12 } : n.written,n.centOffset?.value??0)}</pitch>`);
                        if (!e.grace) emit(tag('duration', ticks(e.duration)));
                        if (n?.tieStop && n.tieSound?.stop !== false && !n.cue) emit('<tie type="stop"/>');
                        if (n?.tieStart && n.tieSound?.start !== false && !n.cue) emit('<tie type="start"/>');
                        if (n?.kind === 'unpitched' && n.unpitched.instrumentId) {
                            const id = percussionIds.get(n.unpitched.instrumentId); if (!id) refuse('writer-drum-reference', 'Unpitched note has no declared MIDI instrument.', n.source);
                            emit(`<instrument id="${id}"/>`);
                        } else if (n && p.instrumentChanges?.length) {
                            const id = e.instrumentContextId ? instrumentContextIds.get(`${p.id}\u0000${e.instrumentContextId}`) : `I${pi + 1}`;
                            if (!id) refuse('writer-instrument-context', 'Source event references an undeclared instrument context.', e.source);
                            emit(`<instrument id="${id}"/>`);
                        }
                        const crossValue = e.crossMeasureValue, crossContinuation = crossValue?.role === 'continuation';
                        const displayedType = crossValue?.role === 'start' ? crossValue.type : e.type;
                        const displayedDots = crossContinuation ? 0 : crossValue?.role === 'start' ? crossValue.dots : e.dots;
                        emit(tag('voice', voice) + `<type${n?.small?.value || e.small?.value ? ' size="cue"' : ''}>${esc(displayedType)}</type>`);
                        const dotFacts = n ? n.dotFacts : e.dotFacts;
                        if (dotFacts && (dotFacts.length !== e.dots || dotFacts.some((fact, index) => fact.index !== index || fact.printObject !== undefined && typeof fact.printObject !== 'boolean')))
                            refuse('writer-dot', 'Dot visibility must be bound to the complete ordered printed dot count.', e.source);
                        for (let dot = 0; dot < displayedDots; dot++) emit(dotFacts?.[dot]?.printObject === false ? '<dot color="#00000000"/>' : '<dot/>');
                        if (n?.accidental) { if (!accidentalVocabulary.has(n.accidental)) refuse('writer-accidental', 'Unsupported accidental notation.', n.source); emit(`<accidental${n.accidentalCautionary ? ' cautionary="yes"' : ''}${n.accidentalParentheses ? ' parentheses="yes"' : ''}${n.accidentalBracket ? ' bracket="yes"' : ''}${accidentalSmuflXml(n.accidentalSmufl,n.accidental)}${accidentalColorXml(n.accidentalColor,n.accidentalVisible!==false)}${n.accidentalFontSize?` font-size="${glyphPointSize(n.accidentalFontSize)}"`:''}>${esc(n.accidental)}</accidental>`); }
                        const modification = e.timeModification ?? e.tuplet;
                        if (modification) emit(`<time-modification>${tag('actual-notes', modification.actual)}${tag('normal-notes', modification.normal)}</time-modification>`);
                        if (crossContinuation || e.sourceStemVisibility?.value === false || e.tabRhythm?.stem==='none') emit(tag('stem', 'none'));
                        else if(e.tabRhythm?.stem)emit(tag('stem',e.tabRhythm.stem));
                        else if (e.stem) emit(tag('stem', e.stem));
                        const hideHead = crossContinuation && crossValue.hideNotehead || visualTabStaff&&!!(n?.tabFretFont?.style!&12);
                        const enclosed = hideHead ? undefined : n && groupNotes?.has(n.id) ? true : n?.tabFret?.parentheses ?? n?.noteheadParentheses?.value;
                        if (n?.noteheadSmufl && !/^[a-zA-Z][a-zA-Z0-9]{0,127}$/.test(n.noteheadSmufl.name)) refuse('writer-notehead-smufl', 'Invalid canonical SMuFL notehead name.', n.noteheadSmufl.source);
                        if (hideHead || n?.kind === 'dead' || n?.notehead || n?.noteheadColor || n?.noteheadSmufl || enclosed !== undefined) {
                            const shape = hideHead ? 'none' : n!.noteheadSmufl ? n!.notehead ?? 'other' : n!.kind === 'dead' ? 'x' : n!.notehead ?? 'normal';
                            if (!noteheadVocabulary.has(shape)) refuse('writer-notehead', 'Unsupported standard notehead.', n!.source);
                            emit(`<notehead${!hideHead && n!.noteheadSmufl ? ` smufl="${esc(n!.noteheadSmufl.name)}"` : ''}${colorXml(n!.noteheadColor, true)}${!hideHead && n!.noteheadFilled !== undefined ? ` filled="${n!.noteheadFilled ? 'yes' : 'no'}"` : ''}${enclosed !== undefined ? ` parentheses="${enclosed ? 'yes' : 'no'}"` : ''}>${esc(shape)}</notehead>`);
                        }
                        if(n?.noteheadText&&!hideHead) {
                            if(!n.noteheadText.text||n.noteheadText.text.length>32||n.noteheadText.accidental&&!['sharp','flat'].includes(n.noteheadText.accidental))refuse('writer-notehead-text','Invalid source-established notehead text.',n.noteheadText.source);
                            emit(`<notehead-text><display-text${colorXml(n.noteheadColor,true)}>${esc(n.noteheadText.text)}</display-text>${n.noteheadText.accidental?`<accidental-text${colorXml(n.noteheadColor,true)}>${n.noteheadText.accidental}</accidental-text>`:''}</notehead-text>`);
                        }
                        emit(tag('staff', staff));
                        if (!ni && !crossContinuation && e.tabRhythm?.stem!=='none') for (const beam of e.beams ?? []) emit(`<beam number="${beam.number}"${beam.fan ? ` fan="${beam.fan}"` : ''}${colorXml(beam.sourceColor, beam.printObject !== false)}>${esc(beam.value)}</beam>`);
                        if (!ni) for (const slur of e.slurs ?? []) emit(slurXml(slur));
                        for (const glyph of [...(n?.symbols ?? []), ...(!ni ? e.symbols ?? [] : [])]) if (glyph.projection !== 'notehead-parenthesis') {
                            emit(`<notations${glyph.printObject === false ? ' print-object="no"' : ''}>${glyphXml(glyph,'notation',undefined,!rotatedGlyph(glyph))}</notations>`);
                        }
                        for (const { relation, start } of ornamentEndpoints.get(e.id) ?? []) {
                            if (relation.kind !== 'trill') return refuse('writer-ornament-relation', 'Unknown ornament relation.', relation.source);
                            if(start&&relation.ornament?.principal?n?.id!==relation.ornament.principal.noteId:!!ni)continue;
                            const sound = start ? ornamentSound(relation.ornament) : '';
                            const mark = !start || relation.form === 'prallprall' ? '' : relation.form === 'trill' ? `<trill-mark${sound}/>` : `<other-ornament smufl="${relation.form === 'upprall' ? 'ornamentBottomLeftConcaveStroke' : 'ornamentLeftVerticalStroke'}"/>`;
                            const accidentals = start ? relation.ornament?.accidentals ?? [] : [];
                            const line = relation.projection?.kind === 'point-ornament' ? '' : `<wavy-line type="${start ? 'start' : 'stop'}" number="${serializedNumber(relation.id)}"${sound}/>`;
                            if (relation.projection) emittedEndpoints.set(relation.id, (emittedEndpoints.get(relation.id) ?? 0) + 1);
                            emit(`<notations${relation.printObject === false ? ' print-object="no"' : ''}><ornaments>${mark}${line}${start?ornamentIntervals(relation.ornament):''}${accidentals.filter(a => a.printObject !== false).map(ornamentAccidentalXml).join('')}</ornaments></notations>`);
                            for (const accidental of accidentals.filter(a => a.printObject === false)) emit(`<notations print-object="no">${ornamentAccidentalXml(accidental)}</notations>`);
                        }
                        if (e.dynamic && display.hideDynamics && ni === 0) emit(`<notations print-object="no"><dynamics><${e.dynamic.toLowerCase()}/></dynamics></notations>`);
                        if (n) {
                            emit(frettedTechniqueXml(n, ni === 0 ? e.whammy : undefined));
                            for (const { relation, start } of noteLineEndpoints.get(n.id) ?? []) {
                                if (relation.kind === 'glissando') {
                                    const name = relation.form, label = start && relation.label.show ? relation.label.value : '';
                                    emit(`<notations${relation.printObject === false ? ' print-object="no"' : ''}><${name} type="${start ? 'start' : 'stop'}" number="${serializedNumber(relation.id)}" line-type="${name === 'glissando' ? 'wavy' : relation.lineType ?? 'solid'}"${relation.lineVisible === false ? ' color="#00000000"' : ''}>${esc(label)}</${name}></notations>`);
                                } else emit(`<notations${relation.printObject === false || relation.lineVisible === false && !(start ? relation.beginText : relation.endText) ? ' print-object="no"' : ''}><other-notation type="${start ? 'start' : 'stop'}" number="${serializedNumber(relation.id)}">${esc((start ? relation.beginText : relation.endText) ?? '')}</other-notation></notations>`);
                            }
                            if(n.dynamic){if(!/^(ppp|pp|p|mp|mf|f|ff|fff)$/.test(n.dynamic.value))refuse('writer-note-dynamic','Unknown component-owned dynamic.',n.dynamic.source);emit(`<notations><dynamics><${n.dynamic.value}/></dynamics></notations>`);}
                            for (const tie of n.tieNotations ?? []) emit(`<notations${tie.printObject === false || tie.relationId === crossValue?.tieId || n.tabTieVisibility?.some(view=>view.relationId===tie.relationId&&view.printObject===false) ? ' print-object="no"' : ''}><tied type="${tie.type}" number="${serializedNumber(tie.relationId)}"${tie.orientation ? ` orientation="${tie.orientation}"` : ''}${tie.lineType ? ` line-type="${tie.lineType}"` : ''}/></notations>`);
                            for (const slur of n.slurs ?? []) emit(slurXml(slur));
                            if ((!n.tieNotations && (n.tieStop || n.tieStart)) || n.hopoStart || n.hopoStop || n.fingering?.length || n.articulations?.length || n.technical?.length || (!ni && e.tupletBoundary?.length)) {
                                emit('<notations>');
                                if (!n.tieNotations && n.tieStop) emit('<tied type="stop"/>');
                                if (!n.tieNotations && n.tieStart) emit('<tied type="start"/>');
                                if (n.hopoStop) emit(`<slur type="stop" number="${hopoSlurNumber(p.id, n, false)}"/>`);
                                if (n.hopoStart) emit(`<slur type="start" number="${hopoSlurNumber(p.id, n, true)}"/>`);
                                if (!ni) for (const boundary of e.tupletBoundary ?? []) emit(tupletXml(boundary, e.timeModification ?? e.tuplet));
                                if (n.hopoStart || n.hopoStop) {
                                    emit('<technical>');
                                    if (n.hopoStop) emit(`<${n.hopoStop} type="stop" number="${n.hopoNumber}"/>`);
                                    if (n.hopoStart) emit(`<${n.hopoStart} type="start" number="${n.hopoNumber}">${n.hopoStart === 'hammer-on' ? 'H' : 'P'}</${n.hopoStart}>`);
                                    emit('</technical>');
                                }
                                if (n.fingering?.length) emit(`<technical>${n.fingering.map(f => tag('fingering', f)).join('')}</technical>`);
                                if (n.technical?.length) {
                                    const vocabulary = new Set(['up-bow', 'down-bow', 'harmonic', 'open-string', 'stopped', 'thumb-position', 'snap-pizzicato']);
                                    for (const technique of n.technical) if (!vocabulary.has(technique.kind)) refuse('writer-technical', 'Unsupported technical notation.', technique.source);
                                    emit(`<technical>${n.technical.map(t => t.kind === 'harmonic' && t.natural ? `<harmonic${anchorXml(t.anchor)}><natural/></harmonic>` : `<${t.kind}${anchorXml(t.anchor)}/>`).join('')}</technical>`);
                                }
                                if (n.articulations?.length) {
                                    emit(articulationsXml(n.articulations, n.source, n.strongAccentDirections, n.articulationAnchors));
                                }
                                emit('</notations>');
                            }
                            if (n.sourceStringNumber) {
                                if (!Number.isInteger(n.sourceStringNumber.value) || n.sourceStringNumber.value < 1 || n.sourceStringNumber.value > 32) refuse('writer-string-number','Explicit string number must be a bounded positive source position.',n.sourceStringNumber.source);
                                emit(`<notations><technical>${tag('string',n.sourceStringNumber.value)}</technical></notations>`);
                            }
                            if(!ni && e.tabRhythm?.halfNoteSlashes) emit(`<notations${e.printObject===false?' print-object="no"':''}><other-notation type="single" smufl="tremolo2">tablature half-note duration</other-notation></notations>`);
                            if (n.string !== undefined || n.fret !== undefined) emit(`<notations${carrier ? ' print-object="no"' : ''}><technical>${n.string!==undefined?tag('string', n.string):''}${n.fret!==undefined?`<fret${n.tabFret?.printObject===false || visualTabStaff&&!!(n.tabFretFont?.style!&12) ? ' color="#00000000"' : ''}${n.tabFretFont?.family?` font-family="${esc(n.tabFretFont.family)}"`:''}${n.tabFretFont?.size?` font-size="${n.tabFretFont.size}"`:''}${n.tabFretFont?.style!==undefined?` font-weight="${n.tabFretFont.style&1?'bold':'normal'}" font-style="${n.tabFretFont.style&2?'italic':'normal'}"`:''}>${n.fretDisplay?.value??n.fret}</fret>`:''}${n.kind === 'dead' ? '<other-technical>dead note</other-technical>' : ''}</technical></notations>`);
                        }
                        if (!n && e.tupletBoundary?.length) emit(`<notations>${e.tupletBoundary.map(boundary => tupletXml(boundary, e.timeModification ?? e.tuplet)).join('')}</notations>`);
                        if (!n && e.whammy) emit(bendXml(e.whammy));
                        if (!ni) for (const marking of e.hiddenMarkings ?? []) {
                            const vocabulary = marking.kind === 'articulation' ? articulationVocabulary : marking.kind === 'ornament' ? new Set(['trill-mark', 'turn', 'inverted-turn', 'mordent', 'inverted-mordent']) : new Set(['up-bow', 'down-bow', 'harmonic', 'open-string', 'stopped', 'thumb-position', 'snap-pizzicato']);
                            if (!vocabulary.has(marking.name)) refuse('writer-hidden-mark', 'Unknown hidden musical marking.', marking.source);
                            const container = marking.kind === 'articulation' ? 'articulations' : marking.kind === 'ornament' ? 'ornaments' : 'technical';
                            const direction = marking.strongAccentDirection;
                            if (direction && (marking.name !== 'strong-accent' || !['auto', 'up', 'down'].includes(direction.value))) refuse('writer-articulation-direction', 'Unverified hidden strong-accent direction ownership.', direction.source);
                            emit(`<notations print-object="no"><${container}>${marking.name === 'harmonic' && marking.natural ? `<harmonic${anchorXml(marking.anchor)}><natural/></harmonic>` : `<${marking.name}${marking.name === 'strong-accent' ? strongAccentType(direction?.value, marking.anchor) : ''}${anchorXml(marking.anchor)}/>`}</${container}></notations>`);
                        }
                        for (const ornament of [...(e.ornaments??[]).filter(mark=>mark.details?.principal?mark.details.principal.noteId===n?.id:!ni), ...(n?.ornaments ?? [])]) {
                            let mark: string;
                            if (ornament.kind === 'tremolo') {
                                if (!ornament.strokes || ornament.strokes < 1 || ornament.strokes > 8 || !['single', 'start', 'stop'].includes(ornament.type ?? '') || ornament.details) refuse('writer-tremolo', 'Unsupported tremolo notation.', ornament.source);
                                mark = `<tremolo type="${ornament.type}">${ornament.strokes}</tremolo>`;
                            } else if (['trill-mark', 'turn', 'inverted-turn', 'vertical-turn', 'inverted-vertical-turn', 'mordent', 'inverted-mordent', 'haydn', 'schleifer', 'other-ornament'].includes(ornament.kind)) {
                                const sign=ornament.details?.sign,mordent=['mordent','inverted-mordent'].includes(ornament.kind);
                                if(sign&&(sign.slash&&ornament.kind!=='turn'||(sign.long||sign.approach||sign.departure)&&!mordent||sign.approach&&!['above','below'].includes(sign.approach)||sign.departure&&!['above','below'].includes(sign.departure)||sign.smufl&&!canonicalSymbolVocabulary.has(sign.smufl)))refuse('writer-ornament-sign','Unqualified source ornament sign attributes.',sign.source);
                                if(ornament.kind==='other-ornament'&&!sign?.smufl)refuse('writer-ornament-sign','Other ornament requires an exact source glyph.',ornament.source);
                                const attrs=`${anchorXml(ornament.anchor)}${!['schleifer','other-ornament'].includes(ornament.kind)?ornamentSound(ornament.details):''}${sign?.slash?' slash="yes"':''}${sign?.long?' long="yes"':''}${sign?.approach?` approach="${sign.approach}"`:''}${sign?.departure?` departure="${sign.departure}"`:''}${sign?.smufl?` smufl="${esc(sign.smufl)}"`:''}`;
                                mark = `<${ornament.kind}${attrs}/>`;
                            } else return refuse('writer-ornament', 'Unsupported ornament.', ornament.source);
                            const accidentals = ornament.details?.accidentals ?? [];
                            emit(`<notations${ornament.printObject === false ? ' print-object="no"' : ''}><ornaments>${mark}${ornamentIntervals(ornament.details)}${accidentals.filter(a => a.printObject !== false).map(ornamentAccidentalXml).join('')}</ornaments></notations>`);
                            for (const accidental of accidentals.filter(a => a.printObject === false)) emit(`<notations print-object="no">${ornamentAccidentalXml(accidental)}</notations>`);
                        }
                        if (!ni) for (const glyph of e.techniqueGlyphs ?? []) {
                            if (!Object.hasOwn(techniqueGlyphNames, glyph.smufl)) refuse('writer-technique-glyph', 'Unverified performer technique glyph.', glyph.source);
                            emit(`<notations${glyph.printObject === false ? ' print-object="no"' : ''}><technical><other-technical smufl="${glyph.smufl}"${anchorXml(glyph.anchor)}>${esc(techniqueGlyphNames[glyph.smufl])}</other-technical></technical></notations>`);
                        }
                        if (!ni && (e.fermata || e.breath || e.articulations?.length || e.chordLines?.length)) {
                            emit('<notations>');
                            if (e.fermata?.printObject !== false && e.fermata) emit(`<fermata type="${e.fermata.inverted ? 'inverted' : 'upright'}">${e.fermata.shape === 'normal' ? '' : e.fermata.shape}</fermata>`);
                            if (e.breath) {
                                if (e.breath.placement && !['above', 'below'].includes(e.breath.placement.value)) refuse('writer-breath-placement', 'Unverified breath placement.', e.breath.placement.source);
                                emit(`<articulations><${e.breath.kind}${e.breath.placement ? ` placement="${e.breath.placement.value}"` : ''}${e.breath.printObject === false ? ' color="#00000000"' : ''}>${e.breath.shape ?? ''}</${e.breath.kind}></articulations>`);
                            }
                            if (e.chordLines?.length) {
                                for (const line of e.chordLines) if (!['falloff', 'doit', 'plop', 'scoop'].includes(line.kind)) refuse('writer-chord-line', 'Unknown chord-line articulation.', line.source);
                                emit(`<articulations>${e.chordLines.map(line => `<${line.kind}${line.straight !== undefined ? ` line-shape="${line.straight ? 'straight' : 'curved'}"` : ''}${line.wavy ? ' line-type="wavy"' : ''}${line.printObject === false ? ' color="#00000000"' : ''}/>`).join('')}</articulations>`);
                            }
                            if (e.articulations?.length) {
                                emit(articulationsXml(e.articulations, e.source, e.strongAccentDirections, e.articulationAnchors));
                            }
                            emit('</notations>');
                        }
                        if (!ni && e.fermata?.printObject === false) emit(`<notations print-object="no"><fermata type="${e.fermata.inverted ? 'inverted' : 'upright'}">${e.fermata.shape === 'normal' ? '' : e.fermata.shape}</fermata></notations>`);
                        const arpeggios = e.arpeggioGroups ?? (e.arpeggio ? [e.arpeggio] : []);
                        if (arpeggios.length > 16) refuse('writer-arpeggio-budget', 'Too many independently numbered arpeggio groups on one component.', e.source);
                        for (const arpeggio of ni < e.notes.length ? arpeggios : []) {
                            const endpoints = arpeggio.noteEndpoints?.filter(endpoint => endpoint.noteId === n?.id);
                            const number = arpeggio.number ? ` number="${arpeggio.number}"` : '';
                            const content = arpeggio.nonArpeggiate ? endpoints ? endpoints.map(endpoint => `<non-arpeggiate type="${endpoint.type}"${number}/>`).join('') : ni === 0 || ni === e.notes.length - 1 ? `<non-arpeggiate type="${ni === 0 ? 'bottom' : 'top'}"${number}/>` : ''
                                : `<arpeggiate${arpeggio.direction ? ` direction="${arpeggio.direction}"` : ''}${number}/>`;
                            if (content) emit(`<notations${arpeggio.printObject === false ? ' print-object="no"' : ''}>${content}</notations>`);
                        }
                        const captions = n?.lyrics ?? (!n ? e.lyrics : undefined) ?? [], stops = !ni ? lyricStops.get(e.id) ?? [] : [];
                        if (captions.length || stops.length) {
                            const lane = (lyric: NonNullable<NoteDetails['lyrics']>[number]): string => `${lyric.number}:${lyric.placement ?? 'below'}`;
                            const captionsByLane = new Map<string, number>(), stopsByLane = new Map<string, NonNullable<NoteDetails['lyrics']>>();
                            for (const lyric of captions) captionsByLane.set(lane(lyric), (captionsByLane.get(lane(lyric)) ?? 0) + 1);
                            for (const lyric of stops) { const key = lane(lyric), values = stopsByLane.get(key) ?? []; values.push(lyric); stopsByLane.set(key, values); }
                            const consumed = new Set<NonNullable<NoteDetails['lyrics']>[number]>();
                            for (const lyric of captions) {
                                const alignment = lyric.textAlignment;
                                if (alignment && (alignment.halign && !['left', 'center', 'right'].includes(alignment.halign) || alignment.justify && !['left', 'center', 'right'].includes(alignment.justify) || alignment.valign && !['top', 'middle', 'bottom', 'baseline'].includes(alignment.valign))) refuse('writer-lyric-alignment', 'Uninterpreted standard lyric alignment.', alignment.source);
                                const incoming = stopsByLane.get(lane(lyric)) ?? [], stop = incoming[0];
                                const coalesced = incoming.length === 1 && captionsByLane.get(lane(lyric)) === 1 && !lyric.extend && !lyric.melisma
                                    && (lyric.printObject !== false) === (stop.printObject !== false)
                                    && colorXml(lyric.sourceColor, true) === colorXml(stop.sourceColor, true);
                                if (coalesced) consumed.add(stop);
                                emit(`<lyric number="${lyric.number}"${colorXml(lyric.sourceColor, true)}${lyric.placement ? ` placement="${lyric.placement}"` : ''}${lyric.textAlignment?.justify || lyric.justify ? ` justify="${lyric.textAlignment?.justify ?? lyric.justify}"` : ''}${lyric.printObject === false ? ' print-object="no"' : ''}>${lyric.syllabic ? tag('syllabic', lyric.syllabic) : ''}${lyricTextXml(lyric)}${lyric.extend ? lyric.extendTo?.eventId ? '<extend type="start"/>' : '<extend/>' : coalesced ? '<extend type="stop"/>' : ''}</lyric>`);
                            }
                            if (!ni) { for (const lyric of stops) if (!consumed.has(lyric)) emit(`<lyric number="${lyric.number}"${colorXml(lyric.sourceColor, true)}${lyric.placement ? ` placement="${lyric.placement}"` : ''}${lyric.printObject === false ? ' print-object="no"' : ''}><extend type="stop"/></lyric>`); }
                        }
                        if (!ni) lyricStops.delete(e.id);
                        emit('</note>');
                    }
                    cursor = ticks(add(e.start, e.duration));
                }
                const span = ticks(m.duration);
                if (cursor < span) { emit(`<forward>${tag('duration', span - cursor)}</forward>`); cursor = span; }
                if (cursor > span) refuse('writer-measure-clock', 'Source voice exceeds its declared measure span.', m.source);
            }
            if (!cursor && ticks(m.duration)) emit(`<forward>${tag('duration', ticks(m.duration))}</forward>`);
            boundary('right', m.repeatEnd ? `<repeat direction="backward" times="${m.repeatEnd}"/>` : '');
            emit('</measure>');
        }
        emit('</part>');
    }
    if (lyricStops.size) refuse('writer-lyric-endpoint', 'Lyric extension lacks its resolved serialized endpoint.', lyricStops.values().next().value![0].source);
    for (const relation of relations) if (relation.kind === 'glissando' && emittedEndpoints.get(relation.id) !== 2) refuse('writer-relation-endpoints', 'Source glissando lacks two actual emitted components.', relation.source);
    if (openNumbers.size) { const id = openNumbers.keys().next().value!; refuse('writer-relation-endpoints', 'Source relation lacks its second serialized endpoint.', relationsById.get(id)!.source); }
    if (projectedOpenNumbers.size) { const id = projectedOpenNumbers.keys().next().value!; refuse('writer-relation-endpoints', 'Source dotted pedal lacks its second serialized bracket endpoint.', relationsById.get(id)!.source); }
    for (const relation of relations) if (relation.kind === 'trill' && emittedEndpoints.get(relation.id) !== (relation.projection ? 1 : 2)) refuse('writer-relation-endpoints', 'Trill lacks its actual emitted source event attachments.', relation.source);
    emit('</score-partwise>\n'); return out;
}

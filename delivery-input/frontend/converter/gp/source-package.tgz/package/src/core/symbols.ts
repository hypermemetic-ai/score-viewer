/** Scoped inline-caption and GP technique names, not bare native Symbol admission.
 * Bare glyphs use the complete canonical-symbols.ts identifier registry.
 * Observed canonical names verified against W3C SMuFL metadata
 * f9d12b22ea89978720ba9defb2f4df67fabd8564. No font or metadata payload is shipped.
 * Bare glyphs do not assert articulation, navigation or playback semantics.
 */
export const symbolVocabulary = new Set(['textTie', 'timeSigBracketLeft', 'accidentalNaturalFlat', 'coda', 'keyboardPedalPed', 'keyboardPedalUp', 'keyboardPedalSost', 'keyboardPedalS', 'segno',
    'articTenutoAbove', 'articStaccatoBelow', 'figbassSharp', 'figbassNatural', 'noteheadParenthesisLeft', 'noteheadParenthesisRight',
    'barlineFinal', 'fClef', 'gClef', 'graceNoteAcciaccaturaStemUp', 'noteQuarterUp', 'timeSigParensLeftSmall', 'timeSigParensRightSmall',
    'reversedBrace', 'accidentalNaturalArabic', 'timeSigCommon', 'accidentalParensLeft', 'accidentalParensRight', 'articStaccatoAbove', 'fermataAbove', 'fermataBelow', 'metNoteQuarterUp',
    'dynamicForte', 'dynamicPiano', 'lyricsElision', 'pictEdgeOfCymbal', 'guitarGolpe']);

/** Audited caption glyphs only. This does not extend bare Symbol admission. */
export const textRunSymbolVocabulary = new Set([...symbolVocabulary,
    'dynamicMezzo', 'dynamicSforzando', 'note8thUp', 'note16thUp', 'note32ndUp', 'augmentationDot', 'metNote8thUp']);

/** Performer technique glyphs with a standard text fallback; no engine realization is implied. */
export const techniqueGlyphNames: Readonly<Record<string, string>> = {
    guitarFadeIn: 'fade in', guitarVolumeSwell: 'volume swell', brassMuteOpen: 'open', stringsDownBowTurned: 'down-bow'
};

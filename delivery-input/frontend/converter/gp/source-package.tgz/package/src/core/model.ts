import type { Rational } from './rational.js';
import type { Location } from './report.js';
export interface KeySignature {
    fifths:number;mode:string;printObject?:boolean;sourceColor?:SourceColor;
    custom?:{source:Location;value:boolean;encoded?:boolean};
    customDefinitions?:{source:Location;glyph:string;degree?:number;octaveAlteration?:number;xAlteration?:number;position?:{x:number;y:number}}[];
    customTones?:{source:Location;step:string;alter:number;accidental:string;smufl?:{source:Location;name:string};octave?:number;nativeStateAlter?:number;components?:{source:Location;name:string}[]}[];
    customProjection?:'annotated-components';
}
export interface Pitch { step: string; alter: number; octave: number; midi: number; origin: 'source' | 'inferred' }
export type NativeHeadScheme = 'auto' | 'normal' | 'name-pitch' | 'name-pitch-no-acc' | 'name-pitch-german' | 'name-pitch-german-no-acc' | 'solfege-movable' | 'solfege-fixed' | 'shape-4' | 'shape-7-aikin' | 'shape-7-funk' | 'shape-7-walker';
/** Full capo, separate from non-capo open-string tuning and capo-relative source frets. */
export interface FrettedCapo { source: Location; fret: number }
export interface SourceImageResource { source: Location; mime: 'image/png' | 'image/jpeg' | 'image/gif' | 'image/svg+xml'; base64: string; sha256: string }
/** Explicit source channels, independent of visibility; occurrences locates every identical repetition. */
export interface SourceColor { source: Location; rgba: [number, number, number, number]; alphaOrigin?: 'native-default'; occurrences?: Location[] }
export interface Meter {
    beats: number; unit: number; symbol?: 'common' | 'cut' | 'single-number'; textBeats?: string; textUnit?: string;
    printObject?: boolean;
    senzaMisura?: { source: Location; text?: string };
    beamGroups?: { source: Location; position: Rational; breaks: [number, number, number] }[];
}
export interface GlyphFact {
    source: Location; id: string; name: string; parentId?: string; printObject?: boolean;
    projection?: 'notehead-parenthesis' | 'source-name' | 'empty' | 'font-character';
    fontCharacter?: { source: Location; code: number; origin: 'source-property' | 'native-default'; text?: string;
        pointSize?: { source: Location; rawValue: string; value: number } };
    sourceColor?: SourceColor;
    sourceFont?: { source: Location; value: string };
    sourceAppearance?: { source: Location; name: 'size' | 'symbolsSize' | 'symbolAngle'; value: number }[];
    rotation?: { source: Location; degrees: number };
    fontSize?: { source: Location; points: number; origin: 'source-staff-space'; millimeters: number; staffFactor: number; multiplier: number; sourceSpace?: Omit<NonNullable<NonNullable<TextFontSize['pointSize']>['scaling']>, 'lineSpatiumDependent'> };
}
export interface MarkAnchor { source: Location; encoded: number; role: 'top-staff' | 'bottom-staff' | 'top-chord' | 'bottom-chord' | 'top' | 'bottom' | 'auto'; placement: 'above' | 'below' | 'auto' }
/** Source curve uses normalized note time and absolute displacement from the unbent pitch. */
export interface BendFact {
    labels?: BendLabelFact[];
    sourceCurveFields?: { source: Location; name: string; value: Rational }[];
    source: Location; points: { source: Location; offset: Rational; semitones: Rational; vibrato?: { source: Location; value: boolean; speed?: 'fast' | 'average' | 'slow' } }[];
    sourceEndpoints?: { start: RelationEndpoint; end: RelationEndpoint };
    initialState?: { source: Location; semitones: Rational; origin: 'preceding-bend' };
    /** Known source endpoint state following a qualitative slack release; not the slack sentinel. */
    terminalState?: { source: Location; semitones: Rational };
    qualitative?: { source: Location; value: 'slack' | 'release-from-slack' };
    sourceHoldMode?: { source: Location; value: 0 | 1 | 2 };
    sourceVibrato?: { source: Location; value: number };
    holdProjection?: { source: Location; reason: 'system-dependent-top-note' };
    /** Original control points, separate from an exact derived bar-boundary projection. */
    sourceCurve?: { source: Location; points: BendFact['points']; segment: { start: Rational; end: Rational }; origin: 'derived-duration-segment' };
    sourceBendType?: { source: Location; value: 'bend' | 'pre-bend' | 'grace-bend' | 'slight-bend' | 'dive' | 'pre-dive' | 'dip' | 'scoop' };
    withBar?: { source: Location; text?: string }; printObject?: boolean; sourceColor?: SourceColor; sourceKind?: 'legacy-bend' | 'legacy-tremolo-bar';
}
/** Native generated bend-label presentation, separate from its musical amount and curve. */
export type BendLabelFact = { source: Location; printObject?: boolean; serializedText?: string }
    & Pick<Direction, 'sourceColor' | 'textFontFamily' | 'textFontSize' | 'textFontStyle' | 'textEmphasis' | 'textAlignment' | 'textFrameAppearance' | 'textEnclosure'>;
/** Role pitches use physical/sounding register. No absent role is inferred from a fret or printed note. */
export interface HarmonicFact {
    source: Location; type: 'natural' | 'artificial' | 'pinch' | 'tap' | 'semi' | 'feedback';
    pitchRole?: 'base' | 'touching' | 'sounding'; base?: Pitch; touch?: Pitch; result?: Pitch;
    harmonicFret?: { source: Location; value: Rational }; printObject?: boolean;
}
export interface GestureFact {
    source: Location; kind: 'vibrato' | 'wide-vibrato' | 'palm-mute' | 'let-ring' | 'tap' | 'slap' | 'pop' | 'pick-scrape' | 'whammy';
    hand?: 'left' | 'right'; text?: string; printObject?: boolean; sourceColor?: SourceColor;
}
/** Exact note-owned printed fingering/plucking text and supported presentation. */
export type FingeringFact = { source: Location; hand?: 'left' | 'right'; value: string; printObject?: boolean; placement?: 'above' | 'below' }
    & Pick<Direction, 'textRuns' | 'sourceColor' | 'textFontFamily' | 'textFontSize' | 'textFontStyle' | 'textEmphasis' | 'textAlignment' | 'textFrameAppearance' | 'textEnclosure'>;
export interface NoteDetails {
    /** Explicit component-owned dynamic, distinct from a shared chord/voice direction. */
    dynamic?: { source: Location; value: string };
    source: Location; id: string; string?: number; fret?: number;
    /** Explicit printed string-number instruction, independent of a hidden physical TAB carrier. */
    sourceStringNumber?: { source: Location; value: number };
    /** Native editor IDs can link objects; they are distinct from this musical occurrence's scoped ID. */
    sourceEid?: string;
    /** Fret-only display derived from native TAB policy; never whole-note visibility. */
    tabTieVisibility?: { source: Location; relationId: string; printObject: false; reason: 'bend-continuation' | 'source-style' }[];
    /** Encoded local-nut fret remains in fret; a short string can print its full-neck fret separately. */
    fretDisplay?: { source: Location; value: number; startFret: number; origin: 'short-string-notation' };
    tabFret?: { source: Location; printObject?: boolean; parentheses?: boolean;
        condition?: 'system-start' | 'same-system-tie';
        policy: 'ordinary' | 'legacy-tied' | 'modern-tied' | 'bend-continuation' | 'performer-mark';
        origin: 'native-tab-policy'; };
    tabFretFont?: { source: Location; family?: string; size?: number; style?: number; sourceFields?: { family?: Location; size?: Location; style?: Location } };

    bend?: BendFact;
    /** Encoded transition instruction; amount derives from explicit source endpoints, not a time curve. */
    bendTransition?: { source: Location; semitones: Rational; targetSource: Location; origin: 'derived-source-pitches' };
    whammy?: BendFact;
    harmonic?: HarmonicFact;
    trill?: { source: Location; target?: Pitch; fret?: number; speed?: string; printObject?: boolean };
    gestures?: GestureFact[];
    ornaments?: MusicalEvent['ornaments'];
    fingerings?: FingeringFact[];
    slides?: { source: Location; kind: 'into-from-below' | 'into-from-above' | 'out-up' | 'out-down' | 'pick-slide-up' | 'pick-slide-down'; printObject?: boolean; lineShape?: 'straight' | 'curved'; lineType?: 'solid' | 'wavy'; sourceColor?: SourceColor }[];
    tieStart: boolean; tieStop: boolean;
    /** Source notation remains exact; a clock gap does not establish continuous sounding duration. */
    tieSound?: { start?: false; stop?: false; reason: 'source-clock-gap' };
    tieNotations?: { type: 'start' | 'stop'; relationId: string; printObject?: boolean; orientation?: 'over' | 'under'; lineType?: 'solid' | 'dashed' | 'dotted' }[];
    hopoStart?: 'hammer-on' | 'pull-off'; hopoStop?: 'hammer-on' | 'pull-off'; hopoNumber?: number;
    hopoNotations?: { source: Location; type: 'start' | 'stop'; kind: 'hammer-on' | 'pull-off'; number: number; text?: string; printObject?: boolean; sourceColor?: SourceColor }[];
    sourceHopoOrigin?: boolean; sourceHopoDestination?: boolean;
    notehead?: string;
    noteheadSmufl?: { source: Location; name: string };
    /** Authored notehead RGBA, independent of note visibility and adjacent components. */
    noteheadColor?: SourceColor;
    printLedgerLines?: { source: Location; value: boolean };
    sourceNotehead?: { source: Location; value: string };
    sourceHeadType?: { source: Location; value: 'whole' | 'half' | 'quarter' | 'breve' };
    sourceHeadScheme?: { source: Location; value: NativeHeadScheme };
    noteheadText?: { source: Location; text: string; accidental?: 'sharp' | 'flat'; origin: 'native-pitch-name' | 'native-solfege' };
    headSchemeProjection?: { source: Location; scheme: NativeHeadScheme; nativeVersion: string; degree: number; alteration: number; origin: 'native-source-rule';
        key?: { source: Location; fifths: number; origin: 'source-key-change' | 'source-staff-state' | 'native-default' } };
    sourceDead?: { source: Location; value: boolean };
    noteheadFilled?: boolean;
    symbols?: GlyphFact[];
    noteheadParentheses?: { source: Location; value?: boolean; origin: 'source' | 'derived-symbol-pair'; hideGenerated?: boolean; hideGeneratedSource?: Location };
    printObject?: boolean;
    cue?: boolean;
    cueOrigin?: 'derived-small-unplayed';
    small?: { source: Location; value: boolean };
    attack?: Rational;
    release?: Rational;
    /** Located native octave line derives performed register; source written pitch stays unchanged. */
    octaveShift?: { source: Location; octaves: -3 | -2 | -1 | 1 | 2 | 3 };
    /** Native linked-note register inheritance, with the selected note's pre-inheritance pitches retained. */
    linkedOctaveShift?: { source: Location; peer: Location; octaves: -3 | -2 | -1 | 1 | 2 | 3; clock: Rational; written: Pitch; sounding?: Pitch; referenceSounding?: Pitch };
    /** Standard pitch projection follows the printed staff's octave line; baseline and native logical sounding facts stay separate. */
    printedOctaveShift?: { source: Location; octaves: -3 | -2 | -1 | 0 | 1 | 2 | 3; staff: number; relationId?: string; origin: 'source-line' | 'derived-no-line' | 'derived-visual-line' };
    performance?: { source: Location; play?: boolean; tuning?: { source: Location; value: number }; events?: { source: Location; pitchOffset: number; ontime: number; length: number }[] };
    technical?: { source: Location; kind: 'up-bow' | 'down-bow' | 'harmonic' | 'open-string' | 'stopped' | 'thumb-position' | 'snap-pizzicato'; natural?: boolean; anchor?: MarkAnchor }[];
    accidental?: string;
    accidentalSmufl?: {source:Location;name:string};
    accidentalColor?: SourceColor;
    accidentalSmall?: {source:Location;value:boolean};
    accidentalFontSize?: GlyphFact['fontSize'];
    sourceAccidental?: {source:Location;name:string;centOffset?:number};
    centOffset?: {source:Location;value:number;origin:'source-property'|'native-accidental'};
    microtonalPitch?: {source:Location;baseSounding:Pitch;cents:number};
    accidentalRole?: 'auto' | 'user';
    accidentalVisible?: boolean;
    accidentalCautionary?: boolean;
    accidentalParentheses?: boolean;
    accidentalBracket?: boolean;
    fixedPosition?: { source: Location; fixed: boolean; line?: number };
    sourceVelocity?: { source: Location; value: number; mode: 'offset' | 'absolute' };
    fingering?: string[];
    articulations?: string[];
    articulationAnchors?: { index: number; anchor: MarkAnchor }[];
    strongAccentDirections?: { source: Location; index: number; value: 'auto' | 'up' | 'down' }[];
    /** Ordered encoded dot objects; count/elapsed value remains owned by the source chord or rest. */
    dotFacts?: { source: Location; index: number; sourceEid?: string; printObject?: boolean }[];
    slurs?: { type: 'start' | 'stop'; number?: number; relationId?: string; printObject?: boolean; orientation?: 'over' | 'under'; lineType?: 'solid' | 'dashed' | 'dotted' }[];
    lyrics?: { source?: Location; number: number; text: string; sourceColor?: SourceColor; textFontSize?: TextFontSize; textFontStyle?: TextFontStyle; textFontFamily?: TextFontFamily; textEmphasis?: TextEmphasis; textRuns?: TextRun[]; textAlignment?: Direction['textAlignment']; syllabic?: string; justify?: 'left' | 'center' | 'right'; placement?: 'above' | 'below'; printObject?: boolean; extend?: boolean;
        melisma?: { source: Location; duration: Rational; editorPlaceholder?: boolean; projection?: 'rest-nbsp-backwards-placeholder' };
        extendTo?: { measure: number; position: Rational; eventId?: string } }[];
}
export interface PitchedOrDeadNote extends NoteDetails {
    kind: 'pitched' | 'dead'; sounding: Pitch | null; written: Pitch;
    /** A dead note's written guidance does not claim a sounding pitch. */
    referenceSounding?: Pitch;
}
export interface UnpitchedNote extends NoteDetails {
    kind: 'unpitched'; sounding: null;
    unpitched: { midi?: number; instrumentId?: string; sourceTpc?: number } & ({ displayStep: string; displayOctave: number; displayUnspecified?: never } | { displayStep?: never; displayOctave?: never; displayUnspecified: { source: Location; reason: 'unassigned-source-articulation' } });
    written?: never; referenceSounding?: never;
}
export type MusicalNote = PitchedOrDeadNote | UnpitchedNote;
/** GP callers retain their existing strong physical-field guarantees. */
export interface NoteFact extends PitchedOrDeadNote { string: number; fret: number; slurs?: { type: 'start' | 'stop'; number: number; relationId?: string }[] }
export interface StaffFact {
    number: number; source: Location; clef: string;
    clefOrigin?: { source: Location; origin: 'source' | 'native-default'; concert?: string; transposing?: string };
    clefBadge?: { source: Location; value: 'optional-octave-below' };
    key?: KeySignature;
    time?: Meter;
    kind?: 'pitched' | 'tablature' | 'percussion'; tuning?: number[]; lines?: number; capo?: FrettedCapo;
    /** Source displacement in half staff spaces; changes drum notation position, not pitch. */
    percussionStepOffset?: { source: Location; value: number };
    noteheadScheme?: { source: Location; value: NativeHeadScheme };
    stretch?: Rational;
    clefPrintObject?: boolean;
    printObject?: boolean;
    voicePlayback?: { source: Location; voiceId: string; play: boolean }[];
    staffSize?: { userMagnification?: { source: Location; value: number }; source: Location; small: boolean; percent: number; magnification: { source: Location; value: number; origin: 'source-style' | 'native-default' } };
    sourceColor?: SourceColor;
    lineVisibility?: { source: Location; value: boolean };
    cutaway?: { source: Location; value: boolean };
    showIfSystemEmpty?: { source: Location; value: boolean };
    notation?: { source: Location } & Partial<Record<'stemless' | 'showClef' | 'showKeySignature' | 'showTimeSignature' | 'showBarlines' | 'showLedgerLines' | 'showRests' | 'showBackTied' | 'showTabFingering' | 'upsideDown' | 'useNumbers', { source: Location; value: boolean; origin?: 'source' | 'native-default' | 'native-stemless-default' }>>;
    /** Native TAB conventions, independently located from physical tuning and frets. */
    tablature?: {
        source: Location;
        onLines: { source: Location; value: boolean; origin: 'source' | 'native-default' };
        linesThrough: { source: Location; value: boolean; origin: 'source' | 'native-default' };
        stemsDown: { source: Location; value: boolean; origin: 'source' | 'native-default' };
        stemsThrough: { source: Location; value: boolean; origin: 'source' | 'native-default' };
        durations: { source: Location; value: boolean; origin: 'source' | 'native-default' };
        minimStyle: { source: Location; value: 0 | 1 | 2; origin: 'source' | 'native-default' };
        symbolRepeat: { source: Location; value: 0 | 1 | 2 | 3; origin: 'source' | 'native-default' };
        durationFontName?: { source: Location; value: string };
        durationFontSize?: { source: Location; value: number };
        fretFontName?: { source: Location; value: string };
        fretPresetIdx?: { source: Location; value: number };
        fretFontSize?: { source: Location; value: number };
        fretUseTextStyle?: { source: Location; value: boolean };
        fretTextStyle?: { source: Location; value: string };
    };
    hideWhenEmpty?: { source: Location; rawValue: string; policy: 'auto' | 'always' | 'never' | 'instrument' };
}
/** Located native text emphasis, distinct from the text, typeface and visibility. */
export interface TextFontStyle {
    source: Location; value: number; origin: 'source' | 'source-style' | 'native-default';
}
/** Individually encoded text properties; absent properties have no guessed value. */
export interface TextEmphasis {
    bold?: { source: Location; value: boolean };
    italic?: { source: Location; value: boolean };
    underline?: { source: Location; value: boolean };
    strike?: { source: Location; value: boolean };
}
/** A source-qualified family is a rendering hint, not a resolved or available font. */
export interface TextFontFamily {
    source: Location; value: string; origin: 'source-property' | 'source-style' | 'native-default';
    qualification?: 'unverified-inline-context' | 'unrepresentable-inline-reset';
}
/** Requested native size is distinct from a source-qualified standard point-size hint. */
export interface TextFontSize {
    source: Location; rawValue: string; value?: number; origin: 'source-property' | 'source-style' | 'source-markup' | 'native-default';
    pointSize?: { value: number; origin: 'source-context'; context: 'musescore-3.3.4-default-text' | 'musescore-3.6.1-user-text-style' | 'musescore-3.6.2-text-line-default-text' | 'musescore-explicit-unscaled-text' | 'musescore-source-style-unscaled-text' | 'musescore-source-scaled-text';
        spatiumDependent: { source: Location; value: boolean; origin: 'source-style' | 'source-property' | 'native-default' };
        music?: { nativeVersion: string; rule: 'fragment' | 'tempo-ratio' | 'smufl-scale' | 'legacy-dynamic' | 'symbol-size'; factor: number };
        scaling?: {
            nativeVersion: string;
            scoreSpatium: { source: Location; millimeters: number; origin: 'source-style' | 'native-default'; rawValue?: string };
            referenceSpatiumMillimeters: number;
            lineSpatiumDependent?: { source: Location; value: boolean; origin: 'source-style' | 'source-property' | 'native-default' };
            staff: { source: Location; factor: number; origin: 'source-staff' | 'native-default' | 'score-scope' };
        } };
}
/** Ordered source text with emphasis derived from the native inline wrappers. */
export interface TextRun {
    source: Location; text: string; emphasis: number; origin: 'source-markup';
    /** Encoded font token; ambiguous properties do not establish an effective family. */
    /** role is converter qualification for a selected ordinary-text context. */
    sourceFont?: { source: Location; face: string; origin: 'source-markup'; qualification?: 'ambiguous-properties'; encodedSize?: string; role?: 'ordinary-family' };
    /** Persistent native formatter size; closing font does not restore it. */
    textFontSize?: TextFontSize;
    musicFontSize?: TextFontSize;
    /** Modern unscaled line layout resets all fragment sizes from the final cursor. */
    lineFontSize?: { source: Location; origin: 'derived-native-line-reset'; request: TextFontSize };
    /** Script state follows formatter tokens; closing either script resets normal. */
    script?: { source: Location; value: 'normal' | 'super' | 'sub'; origin: 'source-markup'; projection?: { origin: 'derived-readable-layout'; relativeY: 6 | -4 | 0; sizeFactor: .6 | 1 } };
    /** Literal private-use source glyph, separate from canonical naming/fallback. */
    sourceText?: string;
    /** Native closing wrappers explicitly disable a property, including inherited emphasis. */
    emphasisResets?: { source: Location; bit: 1 | 2 | 4 | 8 }[];
    /** Verified canonical glyph, with text retained as the semantic fallback. */
    symbolName?: string;
}
export interface ChordFrame {
    source: Location; strings: number; frets: number; firstFret?: number; unplayed?: 'x' | ''; printObject?: boolean; sourceColor?: SourceColor;
    markers?: { source: Location; string: number; kind: 'muted' | 'open' | 'none' }[];
    notes: { source: Location; string: number; fret: number; fingering?: string; fingeringVisible?: boolean; barre?: 'start' | 'stop' }[];
}
export interface ChordHarmony {
    sourceNoteNaming?: { nativeVersion: string; spelling: string; rootCase: number; bassCase: number; fields: { source: Location; name: string; value: string }[] };
    rootAlterPrintObject?: boolean; bassAlterPrintObject?: boolean;
    sourceAnalysis?: { source: Location; name: string; value: number }[];
    sourceBarStates?: { source: Location; value: string };
    source: Location; value: string; role: 'chord-symbol';
    root?: { step: string; alter: number }; bass?: { step: string; alter: number };
    kind?: string; kindText?: string; inversion?: number; rootText?: string; bassText?: string; additional?: ChordHarmony[];
    degrees?: { source: Location; value: number; alter: number; type: 'add' | 'alter' | 'subtract' }[];
    frame?: ChordFrame;
    /** Literal performer facts lacking a structured frame slot; never invent a played position. */
    annotations?: { source: Location; value: string; printObject?: boolean; sourceColor?: SourceColor }[];
}
export interface Direction {
    source: Location; position: Rational; staff: number; voiceId?: string;
    sourceColor?: SourceColor;
    textFontStyle?: TextFontStyle;
    textFontFamily?: TextFontFamily;
    textFontSize?: TextFontSize;
    musicFontSize?: TextFontSize;
    textRuns?: TextRun[];
    textEmphasis?: TextEmphasis;
    /** Explicit native text-frame shape, independently of frame metrics or defaults. */
    textEnclosure?: { source: Location; nativeFrameType: 0 | 1 | 2; value: 'none' | 'rectangle' | 'circle'; origin: 'source-property' | 'source-style'; inlineProjection?: 'whole-caption-format-limit' };
    /** Native frame colors are independent of text color; MusicXML text enclosure has no separate border/fill attributes. */
    textFrameAppearance?: { source: Location; foregroundColor?: SourceColor; backgroundColor?: SourceColor; width?: { source: Location; value: number } };
    kind: 'words' | 'rehearsal' | 'dynamic' | 'pedal' | 'wedge' | 'tempo' | 'symbol' | 'segno' | 'coda' | 'harmony'; text?: string;
    /** Literal source functional label; no tonal root, quality or inversion is inferred. */
    harmony?: { source: Location; value: string; role: 'literal-function' } | ChordHarmony;
    navigation?: { source: Location; kind: 'marker' | 'jump'; targetKind?: 'segno' | 'coda'; label?: string; jumpTo?: string; playUntil?: string; continueAt?: string; playRepeats?: boolean; glyph?: string;
        markerType?: { source: Location; value: string };
        /** Source-qualified navigation targets; empty means no guessed playback route. */
        standardSound?: Partial<Record<'segno' | 'coda' | 'fine' | 'tocoda' | 'dalsegno' | 'dacapo', string>> };
    positionOrigin?: 'native-measure-start' | 'native-measure-end';
    symbol?: GlyphFact;
    relationId?: string;
    action?: 'start' | 'stop' | 'change' | 'resume' | 'discontinue' | 'sostenuto' | 'crescendo' | 'diminuendo'; number?: number;
    quarterRate?: number; unit?: string; dots?: number; rate?: string;
    rhythmicFeel?: { source: Location; kind: 'triplet' | 'dotted' | 'scottish'; unit: 'eighth' | '16th' };
    showMetronome?: boolean;
    velocity?: number;
    velocityOrigin?: 'source' | 'native-default'; sourceVelocity?: number;
    dynamicSubtype?: string; customDynamic?: boolean; sourceText?: string;
    scope?: 'staff' | 'part' | 'system';
    voiceAssignment?: 'currentVoiceOnly' | 'allInStaff';
    playingTechnique?: { source: Location; kind: 'natural' | 'pizzicato' | 'arco' | 'tremolo'; play?: boolean; voiceId?: string };
    channelSwitches?: { source: Location; name: string; voiceId?: string }[];
    performance?: { source: Location; play?: boolean; velocityChange?: number; changeSpeed?: 'slow' | 'normal' | 'fast'; swing?: { source: Location; unit: 'disabled'; ratio: number } };
    printObject?: boolean;
    placement?: 'above' | 'below';
    /** Located inherited side; distinct from an explicit owner placement. */
    placementFact?: { source: Location; value: 'above' | 'below'; origin: 'source-style' };
    textAlignment?: { source: Location; origin?: 'source-style'; halign?: 'left' | 'center' | 'right'; justify?: 'left' | 'center' | 'right'; valign?: 'top' | 'middle' | 'bottom' | 'baseline'; halignOrigin?: 'source-position' | 'derived-legacy-align'; halignSource?: Location };
    system?: boolean;
    tempoWords?: { before: string; after: string };
    quarterRateOrigin?: 'source-tempo' | 'derived-follow-text';
    /** A hidden source tempo is not a performer instruction; only its playback rate is written. */
    playbackOnly?: true;
    /** Encoded engine tempo, independent of a recovered printed metronome. */
    sourceTempo?: { source: Location; quarterNotesPerSecond: string; followText?: { source: Location; rawValue: string } };
    line?: boolean;
    sign?: boolean;
    abbreviated?: boolean;
    niente?: boolean;
}
export interface OrnamentIntervalFact {
    source: Location; step: 'unison'|'second'|'third'|'fourth'|'fifth'|'sixth'|'seventh'|'octave';
    quality: 'auto'|'diminished'|'minor'|'major'|'perfect'|'augmented';
    encodedQuality?: string; active?: boolean; origin?: 'native-default';
}
export interface OrnamentDetails {
    source: Location; sourceSubtype?: string;
    sign?: { source: Location; slash?: boolean; long?: boolean; approach?: 'above'|'below'; departure?: 'above'|'below'; smufl?: string };
    play?: { source: Location; value: boolean };
    intervalAbove?: OrnamentIntervalFact;
    intervalBelow?: OrnamentIntervalFact;
    principal?: { source: Location; noteId: string };
    cueNote?: { source: Location; value: 'auto' | 'on' | 'off' };
    showAccidental?: { source: Location; value: 'default' | 'any-alteration' | 'always' };
    alwaysShowTrillCue?: { source: Location; value: boolean };
    accidentals?: { source: Location; name: string; sourceName?:string; smufl?: {source:Location;name:string}; sourceColor?:SourceColor; fontSize?:GlyphFact['fontSize']; placement: 'above' | 'below'; printObject?: boolean; role?: 'auto' | 'user'; small?: boolean; sourceTrack?: number }[];

}
export interface MusicalEvent {
    source: Location; id: string; start: Rational; duration: Rational;
    instrumentContextId?: string;
    sourceEid?: string;
    tabRhythm?: { source: Location; stem?: 'up' | 'down' | 'none'; halfNoteSlashes?: boolean;
        durationSymbol?: { source: Location; type: string; dots: number; repeat: boolean; condition?: 'system-start';
            form: 'ordinary' | 'grid'; fontName?: string; fontSize?: number;
            grid?: { source: Location; zeroBeamType: 'whole' | 'quarter'; lines: number; previous?: RelationEndpoint } };
        origin: 'native-tab-policy' };
    type: string; dots: number; tuplet?: { actual: number; normal: number };
    /** Cumulative displayed-to-elapsed ratio; staff-local meter changes are not invented tuplets. */
    timeModification?: { actual: number; normal: number };
    staffTiming?: { source: Location; stretch: Rational };
    notes: MusicalNote[]; fullMeasureRest: boolean; text?: string; dynamic?: string;
    symbols?: GlyphFact[];
    noteheadGroups?: { source: Location; id: string; members: { source: Location; sourceIndex: number; noteId: string }[]; sidesOrigin: 'native-default'; duplicateOf?: string }[];
    staff?: number; voiceId?: string;
    /** Derived performed music required by standard measure-repeat interchange, distinct from authored attacks. */
    measureRepeatProjection?: { source: Location; sourceMeasure: number };
    small?: { source: Location; value: boolean };
    stem?: 'up' | 'down' | 'none' | 'double';
    stemOrigin?: { source: Location; origin: 'source-chord' | 'derived-source-beam' };
    sourceStem?: { source: Location; value: 'auto' | 'up' | 'down' };
    sourceStemVisibility?: { source: Location; value: boolean };
    sourceHook?: { source: Location; name?: { source: Location; value: 'flag8thUp' | 'flag8thDown' | 'flag16thUp' | 'flag16thDown' }; printObject?: boolean };
    lyrics?: NoteDetails['lyrics'];
    tupletBoundary?: { type: 'start' | 'stop'; number: number; printObject?: boolean; source?: Location; sourceTrack?: number;
        actual?: number; normal?: number; numberType?: { source: Location; value: 'actual' | 'both' | 'none' };
        bracketType?: { source: Location; value: 'auto' | 'yes' | 'no' }; direction?: { source: Location; value: 'auto' | 'up' | 'down' };
        numberCache?: { source: Location; text?: string; printObject?: boolean; origin: 'renderer-cache' } }[];
    /** Grace chords retain written values but never advance the ordinary measure clock. */
    grace?: { source: Location; before: boolean; slash: boolean; index: number; hostId: string };
    writtenDuration?: Rational;
    whammy?: BendFact;
    /** Literal encoded elapsed override is distinct from the printed note value and a source tuplet. */
    durationOverride?: { source: Location; encoded: Rational; displayed: Rational };
    performerInstructions?: { source: Location; kind: 'barre' | 'rasgueado' | 'timer' | 'wah' | 'percussion-technique' | 'hammer-on-pull-off' | 'empty-slot-technique'; text: string; nativeValue: string }[];
    /** Source style joins a cross-bar tie visually while retaining both original rhythmic events. */
    crossMeasureValue?: { source: Location; role: 'start' | 'continuation'; partnerEventId: string; tieId: string;
        type: string; dots: number; duration: Rational; hideNotehead: boolean; origin: 'native-cross-measure-style' };
    figuredBass?: { source: Location; position: Rational; duration: Rational; durationSource: Location; onNote?: { source: Location; value: boolean };
        items: { source: Location; digit?: { source: Location; value: number };
            prefix?: { source: Location; value: string; encoded: number }; suffix?: { source: Location; value: string; encoded: number };
            brackets?: { source: Location; values: number[] }; continuation?: { source: Location; value: 0 | 1 | 2 } }[];
        parentheses?: boolean; literalBracketText?: string; sourceColor?: SourceColor;
        printObject?: boolean; placement?: 'above' | 'below'; projection: { hostEventId: string; offset: Rational } }[];
    printObject?: boolean;
    fermata?: { source: Location; shape: 'normal' | 'angled' | 'square' | 'double-angled' | 'double-square'; inverted: boolean; playbackStretch?: number; printObject?: boolean;
        placement?: { source: Location; value: 'above' | 'below' } };
    breath?: { source: Location; kind: 'breath-mark' | 'caesura'; shape?: 'comma' | 'tick' | 'upbow' | 'salzedo' | 'normal' | 'thick' | 'short' | 'curved' | 'single'; pause?: number; printObject?: boolean;
        placement?: { source: Location; value: 'above' | 'below'; origin: 'source' | 'native-default' };
        /** Derived exact source-track release ownership, independent of physical glyph placement. */
        ownership?: { source: Location; logicalStaff: { source: Location; number: number }; voice: { source: Location; id: string }; releasePosition: Rational;
            host: { source: Location; eventId: string; printedStaff: number }; origin: 'native-source-release-track' } };
    chordLines?: { source: Location; kind: 'falloff' | 'doit' | 'plop' | 'scoop'; straight?: boolean; wavy?: boolean; play?: boolean; printObject?: boolean }[];
    articulations?: string[];
    articulationAnchors?: NoteDetails['articulationAnchors'];
    strongAccentDirections?: NoteDetails['strongAccentDirections'];
    dotFacts?: NoteDetails['dotFacts'];
    /** Explicitly hidden native markings retain musical vocabulary and source visibility. */
    hiddenMarkings?: { source: Location; nativeSubtype: string; kind: 'articulation' | 'ornament' | 'technical'; name: string; natural?: boolean; play?: boolean; anchor?: MarkAnchor; strongAccentDirection?: { source: Location; value: 'auto' | 'up' | 'down' } }[];
    techniqueGlyphs?: { source: Location; smufl: string; printObject?: boolean; play?: boolean; anchor?: MarkAnchor }[];
    slurs?: NoteDetails['slurs'];
    ornaments?: { source: Location; kind: 'trill-mark' | 'turn' | 'inverted-turn' | 'vertical-turn' | 'inverted-vertical-turn' | 'mordent' | 'inverted-mordent' | 'haydn' | 'schleifer' | 'other-ornament' | 'tremolo'; type?: 'single' | 'start' | 'stop'; strokes?: number; printObject?: boolean; details?: OrnamentDetails; anchor?: MarkAnchor }[];
    arpeggio?: { source: Location; direction?: 'up' | 'down'; nonArpeggiate?: boolean; number?: number; span?: number; trackSpan?: number;
        groupId?: string; ownerEventId?: string; memberEventIds?: string[]; noteEndpoints?: { noteId: string; type: 'top' | 'bottom' }[];
        printObject?: boolean; straight?: boolean; playbackStretch?: number; play?: boolean };
    /** Derived membership references; independently authored overlapping groups retain their own source owner. */
    arpeggioGroups?: NonNullable<MusicalEvent['arpeggio']>[];
    beam?: { source: Location; mode: 'auto' | 'begin' | 'mid' | 'end' | 'no' | 'begin16' | 'begin32'; growLeft?: number; growRight?: number; visible?: boolean; sourceColor?: SourceColor; crossStaffMove?: number; stemDirection?: { source: Location; value: 'auto' | 'up' | 'down' } };
    beams?: { number: number; value: 'begin' | 'continue' | 'end' | 'forward hook' | 'backward hook'; fan?: 'accel' | 'rit'; printObject?: boolean; sourceColor?: SourceColor }[];
}
export interface Event extends MusicalEvent { notes: NoteFact[] }
export interface MusicalMeasure {
    source: Location; time: Meter; key: KeySignature;
    clef: string; pickup: boolean; duration: Rational; voices: MusicalEvent[][];
    /** Number suppression is separate from elapsed length and first-measure pickup inference. */
    implicit?: boolean;
    numbering?: { source: Location; irregular: boolean; origin: 'source' | 'native-default';
        sectionStart?: { source: Location; restart: boolean; origin:'source'|'native-default' };
        appearances?: ({source:Location;staff:number;printObject?:boolean;projection?:'words';cachedText?:{source:Location;value:string}} & Pick<Direction,'textFontFamily'|'textFontSize'|'textFontStyle'|'textEmphasis'|'sourceColor'|'textAlignment'|'textEnclosure'|'textFrameAppearance'>)[];
        offset?: { source: Location; value: number }; mode?: { source: Location; value: 'auto' | 'show' | 'hide' };
        /** Derived regular-bar label; independent of stable semantic measure index and clock. */
        displayNumber?: number; automatic: 'system' | 'measure' | 'none' };
    collapsedRests?: { source: Location; staff: number; count: number }[];
    measureRepeats?: { source: Location; staff: number; type: 'start' | 'stop'; count: 1 | 2 | 4; slashes?: 1 | 2 | 4; printObject?: boolean; sourceColor?: SourceColor; small?: {source: Location; value: boolean}; fontSize?: GlyphFact['fontSize'] }[];
    segmentFermatas?: { source: Location; position: Rational; staff: number; sourceVoiceId: string; fermata: NonNullable<MusicalEvent['fermata']>;
        projection: { kind: 'derived-event'; eventId: string } | { kind: 'direction-glyph'; glyph: string } }[];
    repeatStart: boolean; repeatEnd: number;
    staffs?: StaffFact[]; directions?: Direction[];
    changes?: StaffChange[];
    barlines?: { source: Location; origin?: 'source' | 'native-default'; position: Rational; location: 'left' | 'middle' | 'right'; style: 'regular' | 'light-light' | 'light-heavy' | 'heavy-light' | 'dashed' | 'dotted'; printObject?: boolean; fermata?: MusicalEvent['fermata'] }[];
}
export interface StaffChange {
    source: Location; position: Rational; staff: number; courtesy?: boolean;
    courtesyFact?: { source: Location; encoded?: boolean; origin: 'source-isCourtesy' | 'native-positive-clock-announcement' };
    clef?: string; key?: KeySignature; time?: Meter; stretch?: Rational;
    /** Qualified source header occurrence, separate from the staff's active clef. */
    clefRole?: { source: Location; value: 'header' | 'change'; origin: 'native-source-order' | 'source-isHeader' | 'native-default'; encoded?: boolean };
    transpose?: { diatonic: number; chromatic: number; octaveChange?: number };
    instrumentId?: string;
    tuning?: number[]; capo?: FrettedCapo;
    clefBadge?: StaffFact['clefBadge'];
    printObject?: boolean;
}
export interface RelationEndpoint {
    partId: string; measure: number; position: Rational; staff: number; voiceId?: string; eventId?: string; noteId?: string; graceIndex?: number;
}
/** Source-qualified ordinary Trill notation carrier, separate from logical endpoints. */
export interface TrillNotationAttachment extends RelationEndpoint {
    source: Location; origin: 'native-segment-anchor'; voiceId: string; eventId: string;
}
interface RelationDetails {
    source: Location; id: string; start: RelationEndpoint; end: RelationEndpoint;
    /** Verified duplicate serialized direction boundary; literal source coordinates remain distinct. */
    endpointAliases?: { source: Location; endpoint: RelationEndpoint; previous: RelationEndpoint }[];
    /** Encoded segment track, verified against an existing printed host rather than treated as geometry. */
    segmentTracks?: { source: Location; value: number; printedOwnerEventId?: string }[];
    beginText?: string; continueText?: string; endText?: string;
    textFacts?: Partial<Record<'beginText' | 'continueText' | 'endText', { source: Location; value: string; origin: 'source' | 'source-style' | 'native-default' }>>;
    textFontStyles?: Partial<Record<'beginText' | 'continueText' | 'endText', TextFontStyle>>;
    textFontSizes?: Partial<Record<'beginText' | 'continueText' | 'endText', TextFontSize>>;
    textMusicFontSizes?: Partial<Record<'beginText' | 'continueText' | 'endText', TextFontSize>>;
    textFontFamilies?: Partial<Record<'beginText' | 'continueText' | 'endText', TextFontFamily>>;
    textRuns?: Partial<Record<'beginText' | 'continueText' | 'endText', TextRun[]>>;
    lineType?: 'solid' | 'dashed' | 'dotted' | 'wavy'; lineVisible?: boolean;
    printObject?: boolean; system?: boolean;
    sourceColor?: SourceColor;
    orientation?: 'over' | 'under';
    placement?: { source: Location; value: 'above' | 'below'; origin?: 'source' | 'source-style' | 'native-default' | 'source-direction' };
    /** Literal modern source direction, separate from its normalized standard side. */
    sourceDirection?: { source: Location; value: 'auto' | 'up' | 'down' };
    pedalState?: { startHook: number; endHook: number; beginText: { value: string; origin: 'source' | 'source-style' | 'native-default'; source: Location }; endText: { value: string; origin: 'source' | 'source-style' | 'native-default'; source: Location } };
    startHook?: 'none' | 'up' | 'down' | 'both' | 'arrow'; endHook?: 'none' | 'up' | 'down' | 'both' | 'arrow';
    sourceDuration?: { source: Location; value: Rational };
    /** Calculated difference from first component's written release to the tied successor's onset. */
    clockGap?: Rational;
    /** Explicit performance-only source settings remain separate from standard notation. */
    performance?: { source: Location; velocityChange?: number; changeMethod?: string; play?: boolean; singleNoteDynamics?: boolean; scope?: 'staff' | 'part' | 'system'; voiceAssignment?: 'currentVoiceOnly' | 'allInStaff' };
}
export type MusicalRelation = RelationDetails & (
    { kind: 'slur' | 'tie' | 'pedal'; sourceTechnique?: { source: Location; kind: 'bend-continuation' | 'hammer-on-pull-off' } }
    | { kind: 'glissando'; slideTechnique?: { source: Location; kind: 'shift' | 'legato' }; form: 'slide' | 'glissando'; formFact: { source: Location; origin: 'source' | 'source-style' | 'native-default' }; label: { source: Location; duplicateSources?: Location[]; value: string; show: boolean; origin: 'source' | 'source-style' | 'native-default' } }
    | { kind: 'note-line'; sourceForm: 'text-line' | 'note-line'; diagonal?: { source: Location; value: boolean } }
    | { kind: 'trill'; form: 'trill' | 'upprall' | 'downprall' | 'prallprall'; ornament?: OrnamentDetails;
        notationAttachments?: { start: TrillNotationAttachment; end: TrillNotationAttachment };
        projection?: { source: Location; kind: 'point-ornament'; reason: 'zero-duration' } }
    | { kind: 'wedge'; diminuendo: boolean; niente?: boolean }
    | { kind: 'ottava'; octaves: -3 | -2 | -1 | 1 | 2 | 3; projection?: { source: Location; kind: 'words-bracket'; reason: 'printed-scope-tie-conflict' | 'zero-duration' | 'voice-local-scope' } }
    | { kind: 'text-line'; line: 'dashes' | 'bracket' }
    | { kind: 'ending'; numbers: number[]; sourceNumbers?: { source: Location; values: number[] }; closed: boolean; projection?: { source: Location; kind: 'words-bracket'; reason: 'interior-clock' } }
);
export interface Measure extends MusicalMeasure { voices: Event[][] }
export interface Tempo {
    source: Location; measure: number; position: Rational; rate: string; reference: number;
    unit: string; dots: number; quarterRate: number; visible: boolean;
}
export interface MusicalPart {
    sourceVisibility?: { source: Location; value: boolean };
    source: Location; id: string; name: string; instrument: string; midiProgram?: number;
    instrumentName?: string;
    /** Native printed names and editor track labels have distinct source roles. */
    names?: { track?: { source: Location; value: string }; long?: { source: Location; value: string }; short?: { source: Location; value: string }; instrumentTrack?: { source: Location; value: string } };
    namePrintObject?: boolean;
    nameOrigin?: 'source-long-name' | 'derived-track-fallback' | 'derived-placeholder';
    abbreviation?: string;
    instrumentAbbreviation?: string;
    /** Explicit source timbre, separate from catalog/display identifiers or MIDI. */
    instrumentSound?: { source: Location; value: string };
    playbackChannels?: { source: Location; name?: string; program?: number; midiChannel?: number; midiPort?: number;
        controllers: { source: Location; number: number; value: number }[];
        volume: { value: number; origin: 'source' | 'native-default' }; pan: { value: number; origin: 'source' | 'native-default' };
        bank?: number; synthesizer?: string; mute?: boolean; solo?: boolean }[];
    tuning?: number[]; capo?: FrettedCapo; transposeOctaves: number; measures: MusicalMeasure[];
    /** Actual instrument interval remains separate when a concert view projects zero transpose. */
    sourceInstrumentTranspose?: { source: Location; diatonic: number; chromatic: number; octaveChange?: number };
    staves?: StaffFact[];
    capoChanges?: { source: Location; measure: number; position: Rational; staff: number; active: boolean; fret: number; ignoredStrings?: { source: Location; values: number[] }; appliedStrings?: { source: Location; values: number[]; stringCount: number }; transposeMode?: { source: Location; value: 'playback-only' | 'standard-only' | 'tab-only' }; text?: string; printObject?: boolean }[];
    transpose?: { diatonic: number; chromatic: number; octaveChange?: number };
    percussionInstruments?: { source: Location; id: string; name: string; midi: number; line: number; notehead: string; noteheadGlyphs?: { source: Location; active: boolean; byType: Partial<Record<'whole' | 'half' | 'quarter' | 'breve', { source: Location; name: string }>> }; defaultVoice: number; defaultStem?: 'up' | 'down' }[];
    /** Source-clock changes; labels/catalog facts remain independent of their printed annotation. */
    instrumentChanges?: { source: Location; id: string; measure: number; position: Rational; staff: number;
        sourceInstrumentTranspose?: MusicalPart['sourceInstrumentTranspose'];
        transpose?: { diatonic: number; chromatic: number; octaveChange?: number }; tuning?: number[]; capo?: FrettedCapo; percussionInstruments?: MusicalPart['percussionInstruments']; midiProgram?: number;
        names?: MusicalPart['names']; instrumentId?: { source: Location; value: string };
        defaultClefs: { source: Location; staff: number; value: string }[]; text?: { source: Location; value: string };
        printObject?: boolean; placement?: 'above' | 'below' }[];
}
export interface Part extends MusicalPart { midiProgram: number; tuning: number[]; measures: Measure[] }
export interface MusicalScore {
    title: string; parts: MusicalPart[]; tempos: Tempo[]; relations?: MusicalRelation[];
    /** Explicit primary view selection; not inferred from playback pitch or instrument names. */
    sourceView?: { source: Location; concertPitch: boolean; origin: 'source-style' };
    /** Explicit file-scoped source selection, distinct from written/concert pitch display. */
    sourceSelection?: { id: string; source: Location; identityOrigin: 'source-location'; primary: boolean; mainSource: Location; name?: { source: Location; value: string };
        styleDefaultSelectors: { source: Location; name: string; value: string; origin: 'primary-default-selector' }[];
        objectLinks: { source: Location; owner: Location; kind: string; form: 'legacy-membership' | 'eid-membership';
            status: 'grammar-checked-membership' | 'located-eid-peer';
            targetEid?: { source: Location; value: string; target: Location }; score?: { source: Location; value: 'same' };
            indexDiff?: { source: Location; value: number }; coordinates?: { source: Location; fields: { source: Location; name: string; value: string }[] } }[] };
    measureNumbering?: { show?: { source: Location; value: boolean }; system?: { source: Location; value: boolean };
        showFirst?: { source: Location; value: boolean }; interval?: { source: Location; value: number } };
    /** Located resource references; no ambient path is resolved or image content fabricated. */
    sourceImages?: { source: Location; partId: string; staff: number; beforeMeasure?: number; frame?: 'VBox' | 'HBox' | 'FBox' | 'TBox'; viewSource?: Location;
        attachment?: {source:Location;measure:number;position:Rational;voiceId?:string;eventId?:string;noteId?:string;sourceKind:'Note'|'Chord'|'Rest'|'MeasureRepeat'|'RepeatMeasure'|'voice';parentSource?:Location};
        appearance?: {source:Location;name:string;value:string}[];
        placement?: {source:Location;track:number;partId:string;staff:number;voiceId:string};
        path?: { source: Location; value: string }; linkPath?: { source: Location; value: string }; printObject?: boolean;
        size?: { source: Location; width: number; height: number }; autoScale?: { source: Location; value: boolean }; offset?: { source: Location; x: number; y: number }; resource?: SourceImageResource; contentStatus: 'unavailable' | 'retained-member-unprojected' | 'embedded-standard' }[];
    /** Exact useful source metadata, independently located from printed title/credits. */
    metadata?: { source: Location; name: string; value: string }[];
    sourceObjectLinks?: { source: Location; owner: { source: Location; kind: 'BarLine' | 'Tuplet'; partId: string; staff: number; measure: number; position: Rational; voiceId: string; sourceEid?: string };
        targetEid?: { source: Location; value: string }; relativeStaff?: { source: Location; value: number };
        target?: { source: Location; kind: 'BarLine' | 'Tuplet'; partId: string; staff: number; measure: number; position: Rational; voiceId: string; sourceEid?: string }; status: 'located-primary-peer' | 'unresolved-source-reference' }[];
    /** Global native page text has no invented frame, part or staff owner. */
    sourcePageText?: { source: Location; field: string; raw: string; text: string; role: 'header' | 'footer'; parity: 'odd' | 'even'; side: 'left' | 'center' | 'right';
        conditions: { enabled: { source?: Location; value: boolean; origin: 'source-style' | 'native-default' }; firstPage: { source?: Location; value: boolean; origin: 'source-style' | 'native-default' }; oddEven: { source?: Location; value: boolean; origin: 'source-style' | 'native-default' } };
        substitutions: { token: string; role: 'metadata' | 'pagination' | 'source-origin' | 'literal' | 'unresolved'; source?: Location; value?: string }[];
        projection: 'generic-credit' | 'metadata-only' | 'pagination-only' | 'unresolved' }[];
    cachedMeasureViews?: { source: Location; partId: string; staff: number; startMeasure: number; count: number; span?: Rational;
        encodedSpan?: { source: Location; raw: string }; restValues: { source: Location; raw: string }[]; contentStatus: 'verified-rest-alias' | 'unverified-cache-content' }[];
    /** Printed frame text, independent of descriptive metaTags and native layout geometry. */
    credits?: { source: Location; text: string; sourceStyle?: { source: Location; value: string }; role?: 'title' | 'subtitle' | 'composer' | 'lyricist'; printObject?: boolean; textAlignment?: Direction['textAlignment']; textFontSize?: TextFontSize; textFontFamily?: TextFontFamily; textFontStyle?: TextFontStyle; textEmphasis?: TextEmphasis; textRuns?: TextRun[]; sourceColor?: SourceColor; textEnclosure?: Direction['textEnclosure']; textFrameAppearance?: Direction['textFrameAppearance'];
        visibility?: { source: Location; value: boolean; origin: 'source-text' | 'derived-frame' }; symbol?: GlyphFact;
        frame: 'VBox' | 'HBox' | 'FBox' | 'TBox'; partId: string; staff: number; beforeMeasure: number }[];
    /** Linked native part views are retained independently of the primary event stream. */
    alternateViews?: { source: Location; name?: { source: Location; value: string }; metadata: NonNullable<MusicalScore['metadata']>;
        credits: NonNullable<MusicalScore['credits']>;
        parts: { source: Location; names: MusicalPart['names']; sourcePartId: string; sourcePartIdOrigin: 'derived-staff-links';
            staffs: { source: Location; viewStaffId: number; sourceStaffId: number; sourceStaffNumber: number }[] }[];
        contentStatus: 'linked-content-unverified' }[];
}
export interface NeutralScore extends MusicalScore { parts: Part[] }

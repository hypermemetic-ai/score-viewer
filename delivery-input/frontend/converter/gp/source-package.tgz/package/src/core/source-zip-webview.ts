import { Refusal, refuse } from './report.js';
import { checkWork, inflate, supportsFraming, type StreamDeadline } from './webview-inflate.js';
import { checkZipMember, scanZip, zipDecodeFailure, zipPayload } from './source-zip.js';

/** WebView inflater host for the shared strict ZIP admission: native `deflate-raw` only, in a Worker. */
export async function captureZipWebView(bytes: Uint8Array, deadline: StreamDeadline, crc: (bytes: Uint8Array) => number): Promise<Map<string, Uint8Array>> {
    const members = new Map<string, Uint8Array>();
    for (const entry of scanZip(bytes)) {
        checkWork(deadline);
        const payload = zipPayload(bytes, entry);
        let decoded: Uint8Array;
        if (entry.method === 0) decoded = payload.slice();
        else {
            const ctor = globalThis.DecompressionStream;
            if (typeof ctor !== 'function' || !await supportsFraming(ctor, deadline)) refuse('runtime-codec', 'Native deflate-raw is missing or fails the bounded exact-output/truncated/trailing framing gate; no compressed input is admitted.', { member: 'container' });
            // One byte above the declaration mirrors Node: a slight overrun reaches the CRC/length check.
            try { decoded = await inflate(ctor, payload, entry.decoded + 1, deadline); }
            catch (error) { if (error instanceof Refusal) throw error; return zipDecodeFailure(entry); }
        }
        checkWork(deadline);
        members.set(entry.name, checkZipMember(entry, decoded!, crc));
    }
    return members;
}

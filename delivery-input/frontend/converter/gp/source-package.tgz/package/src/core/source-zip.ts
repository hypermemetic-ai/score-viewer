import { refuse } from './report.js';

/** Little-endian reads over the caller's exact byte range; portable to Node and WebView hosts. */
function littleEndian(bytes: Uint8Array) {
    const data = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
    return { length: bytes.byteLength, readUInt16LE: (at: number) => data.getUint16(at, true), readUInt32LE: (at: number) => data.getUint32(at, true),
        subarray: (start: number, end: number) => bytes.subarray(start, end) };
}
const sameBytes = (a: Uint8Array, b: Uint8Array) => a.length === b.length && a.every((value, i) => value === b[i]);

/** Routing only: read the bounded directory without inflating any member. Admission remains adapter-owned. */
export function zipMemberNames(bytes: Uint8Array): string[] {
    const b = littleEndian(bytes);
    let end = -1;
    for (let i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) if (b.readUInt32LE(i) === 0x06054b50 && i + 22 + b.readUInt16LE(i + 20) === b.length) { end = i; break; }
    if (end < 0) refuse('zip-identification', 'ZIP directory cannot identify a source adapter.');
    const count = b.readUInt16LE(end + 10), offset = b.readUInt32LE(end + 16);
    const size = b.readUInt32LE(end + 12);
    if (!count || count > 2048 || size > 4 * 1024 * 1024 || offset + size !== end) refuse('zip-identification', 'ZIP routing directory bounds exceed the budget.');
    const names: string[] = []; let pos = offset;
    for (let i = 0; i < count; i++) {
        if (pos + 46 > end || b.readUInt32LE(pos) !== 0x02014b50) refuse('zip-identification', 'Malformed ZIP routing directory.');
        const length = b.readUInt16LE(pos + 28), extra = b.readUInt16LE(pos + 30), comment = b.readUInt16LE(pos + 32);
        if (length > 960 || pos + 46 + length + extra + comment > end) refuse('zip-identification', 'ZIP member identity exceeds the routing budget.');
        try { names.push(new TextDecoder('utf-8', { fatal: true }).decode(b.subarray(pos + 46, pos + 46 + length))); }
        catch { refuse('zip-identification', 'Non-UTF-8 ZIP routing identity.'); }
        pos += 46 + length + extra + comment;
    }
    if (pos !== end) refuse('zip-identification', 'Unaccounted ZIP routing directory data.');
    return names;
}

export interface ZipEntry { name: string; start: number; end: number; payload: number; compressed: number; decoded: number; crc: number; method: number }
const zipFail = (message: string): never => refuse('native-zip', message, { member: 'container' });

/** Bounded bytes-only ZIP structure. No extraction, external access, ZIP64, encryption or symlinks.
 * Every member is admitted structurally before any host inflates one; inflation is a host codec boundary. */
export function scanZip(bytes: Uint8Array): ZipEntry[] {
    if (bytes.length > 32 * 1024 * 1024) refuse('input-size', 'Source archive exceeds 32 MiB.');
    const b = littleEndian(bytes);
    const fail = zipFail;
    if (b.length < 22 || b.readUInt32LE(0) !== 0x04034b50) fail('Expected a local ZIP archive.');
    let end = -1;
    for (let i = b.length - 22; i >= Math.max(0, b.length - 65557); i--) {
        if (b.readUInt32LE(i) === 0x06054b50 && i + 22 + b.readUInt16LE(i + 20) === b.length) { end = i; break; }
    }
    if (end < 0) fail('Missing ZIP end directory.');
    const count = b.readUInt16LE(end + 10), offset = b.readUInt32LE(end + 16), size = b.readUInt32LE(end + 12);
    if (!count || count > 2048 || b.readUInt16LE(end + 4) || b.readUInt16LE(end + 6) || b.readUInt16LE(end + 8) !== count || offset + size !== end)
        fail('Split/ZIP64 archive or directory budget/bounds failure.');
    const extra = (start: number, length: number) => {
        let p = start;
        while (p < start + length) {
            if (p + 4 > start + length) fail('Truncated ZIP extra field.');
            const id = b.readUInt16LE(p), size = b.readUInt16LE(p + 2);
            if (p + 4 + size > start + length || ![0x5455, 0x000a, 0x7875].includes(id)) fail('Unsupported ZIP extra field.');
            p += 4 + size;
        }
    };
    const entries: ZipEntry[] = [];
    const names = new Set<string>();
    let pos = offset, total = 0;
    for (let i = 0; i < count; i++) {
        if (pos + 46 > end || b.readUInt32LE(pos) !== 0x02014b50) fail('Malformed central directory.');
        const flags = b.readUInt16LE(pos + 8), method = b.readUInt16LE(pos + 10), crc = b.readUInt32LE(pos + 16);
        const compressed = b.readUInt32LE(pos + 20), decoded = b.readUInt32LE(pos + 24), nl = b.readUInt16LE(pos + 28);
        const xl = b.readUInt16LE(pos + 30), cl = b.readUInt16LE(pos + 32), start = b.readUInt32LE(pos + 42);
        if (pos + 46 + nl + xl + cl > end || flags & ~0x0808 || ![0, 8].includes(method) || b.readUInt16LE(pos + 34)) fail('Unsupported ZIP encoding/method/disk.');
        const rawName = b.subarray(pos + 46, pos + 46 + nl);
        let name: string;
        try { name = new TextDecoder('utf-8', { fatal: true }).decode(rawName); } catch { return fail('Non-UTF-8 member identity is unsupported.'); }
        if (!name || name.length > 240 || /[\x00-\x1f\\:]/.test(name) || name.startsWith('/') || name.split('/').some(p => p === '.' || p === '..' || !p)) fail('Unsafe or ambiguous archive member.');
        const folded = name.normalize('NFC').toLowerCase();
        if (names.has(folded)) fail('Duplicate or normalized/case-ambiguous members.');
        names.add(folded);
        const unixType = (b.readUInt32LE(pos + 38) >>> 16) & 0xf000;
        if (unixType && unixType !== 0x8000) fail('Nonregular archive member.');
        extra(pos + 46 + nl, xl);
        total += decoded;
        if (decoded > 32 * 1024 * 1024 || total > 64 * 1024 * 1024 || decoded > Math.max(1, compressed) * 256) fail('Archive expansion budget exceeded.');
        if (start + 30 > offset || b.readUInt32LE(start) !== 0x04034b50) fail('Invalid local member offset.');
        const localNl = b.readUInt16LE(start + 26), localXl = b.readUInt16LE(start + 28), payload = start + 30 + localNl + localXl;
        const dataEnd = payload + compressed;
        const descriptor = !!(flags & 8);
        const signed = descriptor && dataEnd + 4 <= offset && b.readUInt32LE(dataEnd) === 0x08074b50;
        const memberEnd = dataEnd + (descriptor ? signed ? 16 : 12 : 0);
        if (memberEnd > offset || localNl !== nl || !sameBytes(b.subarray(start + 30, start + 30 + localNl), rawName) ||
            b.readUInt16LE(start + 6) !== flags || b.readUInt16LE(start + 8) !== method) fail('Local and central member identities disagree.');
        extra(start + 30 + localNl, localXl);
        const local = [b.readUInt32LE(start + 14), b.readUInt32LE(start + 18), b.readUInt32LE(start + 22)];
        if (!(descriptor && local.every(n => n === 0)) && (local[0] !== crc || local[1] !== compressed || local[2] !== decoded)) fail('Local and central CRC/lengths disagree.');
        if (descriptor) {
            const p = dataEnd + (signed ? 4 : 0);
            if (b.readUInt32LE(p) !== crc || b.readUInt32LE(p + 4) !== compressed || b.readUInt32LE(p + 8) !== decoded) fail('ZIP descriptor disagrees with directory.');
        }
        entries.push({ name, start, end: memberEnd, payload, compressed, decoded, crc, method });
        pos += 46 + nl + xl + cl;
    }
    if (pos !== end) fail('Unaccounted central directory content.');
    let next = 0;
    for (const e of entries.slice().sort((a, c) => a.start - c.start)) {
        if (e.start !== next) fail('Overlapping or unaccounted local archive content.');
        next = e.end;
    }
    if (next !== offset) fail('Unaccounted local archive bytes.');
    return entries;
}

/** The compressed or stored member bytes, in the caller's input range. */
export const zipPayload = (bytes: Uint8Array, entry: ZipEntry): Uint8Array => bytes.subarray(entry.payload, entry.payload + entry.compressed);
/** A host decoder failure has one located meaning, whatever the codec reports. */
export const zipDecodeFailure = (entry: ZipEntry): never => zipFail(`Member ${entry.name} could not be decoded within its budget.`);
/** Exact declared length and CRC-32; `crc` is the host's checksum of the decoded bytes. */
export function checkZipMember(entry: ZipEntry, decoded: Uint8Array, crc: (bytes: Uint8Array) => number): Uint8Array {
    if (decoded.length !== entry.decoded || crc(decoded) !== entry.crc) zipFail(`Member ${entry.name} has invalid CRC/length.`);
    return decoded;
}

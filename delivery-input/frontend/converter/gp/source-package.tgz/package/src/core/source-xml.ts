import { SaxesParser } from 'saxes';
import { freeze, refuse, type Location } from './report.js';

/** An immutable syntactic capture, before defaults or musical interpretation. */
export interface SourceElement {
    name: string; attrs: Record<string, string>; text: string; children: SourceElement[]; location: Location;
    /** Child insertion points within direct text; only native inline text needs this extra ordering. */
    textOrder?: { child: number; afterText: number }[];
    /** Literal self-closing syntax; effective native formatter input is producer-qualified. */
    selfClosing?: true;
    /** Inline text has a direct inert comment child; no comment body is retained. */
    hasComment?: true;
    /** Direct character data contains CDATA alone or mixed with PCDATA. */
    cdata?: 'only' | 'mixed';
}
const inlineText = new Set(['text', 'beginText', 'continueText', 'endText', 'longName', 'shortName', 'trackName', 'pedalText', 'pedalHookText', 'pedalEndText', 'pedalRosetteEndText', 'b', 'i', 'u', 's', 'font', 'sup', 'sub']);
const scalarSyntax = new Set(['family', 'style', 'user1FontSize', 'user1FontSpatiumDependent', 'user1Align', 'user2FontSize', 'user2FontSpatiumDependent', 'user2Align', 'bold', 'italic', 'underline', 'defaultsVersion', 'usePre_3_6_defaults', 'tempoFontStyle', 'tempoFontFace', 'Tempo', 'tempo', 'visible', 'followText', 'beginFontStyle', 'continueFontStyle', 'endFontStyle', 'beginFontSize', 'continueFontSize', 'endFontSize', 'defaultFontSpatiumDependent']);
// Private native qualification only: direct parent syntax, plus descendant
// propagation to Chord/TimeSig only. Serialized capture keys stay unchanged.
const opaqueSyntax = new WeakSet<SourceElement>();
export const hasCommentOrCdata = (element: SourceElement): boolean => opaqueSyntax.has(element);
/** Name/parent counts of subtrees the caller chose not to retain, in document order. */
export interface PrunedConstruct { name: string; parent: string; count: number; first: Location }
const prunedConstructs = new WeakMap<SourceElement, Map<string, PrunedConstruct>>();
export const prunedInventory = (root: SourceElement): ReadonlyMap<string, PrunedConstruct> => prunedConstructs.get(root) ?? new Map();
export interface CaptureXmlOptions {
    /** Returns true for an element whose whole subtree is counted but not retained. */
    prune?: (ancestors: readonly SourceElement[], name: string) => boolean;
}
export function captureXml(bytes: Uint8Array, member: string, options: CaptureXmlOptions = {}): SourceElement {
    let xml: string;
    try { xml = new TextDecoder('utf-8', { fatal: true }).decode(bytes); }
    catch { return refuse('xml-encoding', 'Expected well-formed UTF-8 XML.', { member }); }
    const parser = new SaxesParser({ xmlns: false, defaultXMLVersion: '1.0', forceXMLVersion: true });
    const emptyAttrs: Record<string, string> = Object.freeze({}), emptyChildren = Object.freeze([]) as unknown as SourceElement[];
    const stack: SourceElement[] = [], siblings: Map<string, number>[] = [new Map()];
    const commentParents = new WeakSet<SourceElement>();
    const characterKinds = new WeakMap<SourceElement, { cdata: boolean; pcdata: boolean }>();
    const markSyntax = () => {
        const parent = stack.at(-1); if (parent) opaqueSyntax.add(parent);
        for (const owner of stack) if (owner.name === 'Chord' || owner.name === 'TimeSig') opaqueSyntax.add(owner);
    };
    let root: SourceElement | undefined, nodes = 0, text = 0, pathCodeUnits = 0;
    // Pruned subtrees keep only transient path state; their constructs are counted.
    const pruned: { name: string; path: string; counts: Map<string, number> }[] = [], prunedCounts = new Map<string, PrunedConstruct>();
    const fail = (message: string): never => refuse('xml', message, { member, line: parser.line, column: parser.column });
    parser.on('error', e => fail(e.message));
    parser.on('doctype', () => fail('DTD and entity declarations are not admitted.'));
    parser.on('processinginstruction', () => fail('Processing instructions are not admitted.'));
    parser.on('xmldecl', d => {
        if (d.version !== '1.0' || d.encoding && d.encoding.toLowerCase() !== 'utf-8') fail('Expected XML 1.0 UTF-8.');
    });
    parser.on('opentag', tag => {
        if (++nodes > 640_000 || stack.length >= 64 || tag.name.length > 128 || Object.keys(tag.attributes).length > 32 || Object.values(tag.attributes).some(value => value.length > 65536)) fail('XML structural budget exceeded.');
        if (tag.name.includes(':') || Object.keys(tag.attributes).some(n => n.includes(':') || n === 'xmlns')) fail('Namespaced native XML is not admitted.');
        if (pruned.length || options.prune?.(stack, tag.name)) {
            const owner = pruned.at(-1), counts = owner?.counts ?? siblings.at(-1)!, index = (counts.get(tag.name) ?? 0) + 1;
            counts.set(tag.name, index);
            const parentName = owner?.name ?? stack.at(-1)!.name, path = (owner?.path ?? stack.at(-1)!.location.path ?? '') + `/${tag.name}[${index}]`;
            if (path.length > 4096) fail('XML source-location budget exceeded.');
            const key = `${parentName}/${tag.name}`, entry = prunedCounts.get(key);
            if (entry) entry.count++;
            else prunedCounts.set(key, { name: tag.name, parent: parentName, count: 1, first: { member, path, line: parser.line, column: parser.column, ...(tag.attributes.id ? { id: String(tag.attributes.id) } : {}) } });
            pruned.push({ name: tag.name, path, counts: new Map() });
            return;
        }
        const parent = stack.at(-1), counts = siblings.at(-1)!, index = (counts.get(tag.name) ?? 0) + 1;
        counts.set(tag.name, index);
        const path = (parent?.location.path ?? '') + `/${tag.name}[${index}]`;
        // Bound each retained locator and aggregate UTF-16 payload before allocating its node.
        pathCodeUnits += path.length;
        if (path.length > 4096 || pathCodeUnits > 64 * 1024 * 1024) fail('XML source-location budget exceeded.');
        const element: SourceElement = { name: tag.name, attrs: Object.keys(tag.attributes).length ? { ...tag.attributes } : emptyAttrs, text: '', children: emptyChildren,
            ...(tag.isSelfClosing && ['b', 'i', 'u', 's', 'sup', 'sub'].includes(tag.name) && parent && inlineText.has(parent.name) ? { selfClosing: true as const } : {}),
            location: { member, path, line: parser.line, column: parser.column,
                ...(tag.attributes.id ? { id: String(tag.attributes.id) } : {}) } };
        if (parent) {
            if (inlineText.has(parent.name)) (parent.textOrder ??= []).push({ child: parent.children.length, afterText: parent.text.length });
            if (parent.children === emptyChildren) parent.children = [];
            parent.children.push(element);
        } else root = element;
        stack.push(element); siblings.push(new Map());
    });
    const append = (value: string, cdata = false) => {
        text += value.length;
        if (text > 16 * 1024 * 1024) fail('XML text budget exceeded.');
        if (pruned.length) return;
        const parent = stack.at(-1);
        if (parent) {
            parent.text += value;
            if (inlineText.has(parent.name) || scalarSyntax.has(parent.name)) {
                const kinds = characterKinds.get(parent) ?? { cdata: false, pcdata: false };
                if (cdata) kinds.cdata = true; else if (value) kinds.pcdata = true;
                characterKinds.set(parent, kinds);
            }
        }
    };
    parser.on('text', value => append(value)); parser.on('cdata', value => { if (!pruned.length) markSyntax(); append(value, true); });
    parser.on('comment', () => { if (pruned.length) return; markSyntax(); const parent = stack.at(-1); if (parent && (inlineText.has(parent.name) || scalarSyntax.has(parent.name))) commentParents.add(parent); });
    parser.on('closetag', () => {
        if (pruned.length) { pruned.pop(); return; }
        const element = stack.pop();
        // Current native noChildren observes comment nodes, even though the
        // comments themselves are neither displayed nor captured as text.
        if (element && commentParents.has(element)) element.hasComment = true;
        const kinds = element && characterKinds.get(element);
        if (element && kinds?.cdata) element.cdata = kinds.pcdata ? 'mixed' : 'only';
        // Indentation between child elements carries no source meaning outside
        // inline text and scalar syntax; dropping it bounds large-score memory.
        if (element && element.children.length && element.text && !inlineText.has(element.name) && !scalarSyntax.has(element.name) && !/[^ \t\r\n]/.test(element.text)) element.text = '';
        siblings.pop();
    });
    for (let i = 0; i < xml.length; i += 4096) parser.write(xml.slice(i, i + 4096));
    parser.close();
    if (!root) fail('Missing XML document root.');
    if (prunedCounts.size) prunedConstructs.set(root!, prunedCounts);
    return freeze(root!);
}
export const children = (e: SourceElement, name: string): SourceElement[] => e.children.filter(c => c.name === name);
export function child(e: SourceElement, name: string, required = false): SourceElement | undefined {
    let found: SourceElement | undefined;
    for (const candidate of e.children) if (candidate.name === name) {
        if (found) refuse('native-structure', `Expected ${required ? 'one' : 'at most one'} ${name}.`, e.location);
        found = candidate;
    }
    if (required && !found) refuse('native-structure', `Expected one ${name}.`, e.location);
    return found;
}
export const text = (e: SourceElement, name: string, required = false): string => child(e, name, required)?.text.trim() ?? '';
export function integer(value: string, min: number, max: number, location: Location): number {
    if (!/^-?\d{1,9}$/.test(value) || Number(value) < min || Number(value) > max) refuse('native-number', `Expected integer ${min}..${max}.`, location);
    return Number(value);
}

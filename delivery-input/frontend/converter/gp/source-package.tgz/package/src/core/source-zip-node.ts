import { crc32, inflateRawSync, type InflateRaw } from 'node:zlib';
import { checkZipMember, scanZip, zipDecodeFailure, zipPayload } from './source-zip.js';

/** Node inflater host for the shared strict ZIP admission. */
export function captureZip(bytes: Uint8Array): Map<string, Uint8Array> {
    const members = new Map<string, Uint8Array>();
    for (const entry of scanZip(bytes)) {
        const payload = zipPayload(bytes, entry);
        let decoded: Uint8Array;
        try {
            if (entry.method === 8) {
                const result = inflateRawSync(payload, { maxOutputLength: entry.decoded + 1, info: true }) as unknown as { buffer: Buffer; engine: InflateRaw };
                if (result.engine.bytesWritten !== entry.compressed) throw new Error('Incomplete or trailing compressed member.');
                decoded = result.buffer;
            } else decoded = Buffer.from(payload);
        } catch { return zipDecodeFailure(entry); }
        members.set(entry.name, checkZipMember(entry, decoded, crc32));
    }
    return members;
}

import { GeneralMidi } from '../midi/GeneralMidi.js';

import { ScoreImporter } from './ScoreImporter.js';
import { UnsupportedFormatError } from './UnsupportedFormatError.js';

import { IOHelper } from '../io/IOHelper.js';
import { OverflowError, type IReadable } from '../io/IReadable.js';
import { AccentuationType } from '../model/AccentuationType.js';
import { Automation, AutomationType } from '../model/Automation.js';
import { Bar, BarLineStyle } from '../model/Bar.js';
import { Beat, BeatBeamingMode } from '../model/Beat.js';
import { BendPoint } from '../model/BendPoint.js';
import { BrushType } from '../model/BrushType.js';
import { Chord } from '../model/Chord.js';
import { Clef } from '../model/Clef.js';
import { Color } from '../model/Color.js';
import { Duration } from '../model/Duration.js';
import { DynamicValue } from '../model/DynamicValue.js';
import type { Fingers } from '../model/Fingers.js';
import { GraceType } from '../model/GraceType.js';
import { HarmonicType } from '../model/HarmonicType.js';
import type { KeySignature } from '../model/KeySignature.js';
import type { KeySignatureType } from '../model/KeySignatureType.js';
import { Lyrics } from '../model/Lyrics.js';
import { MasterBar } from '../model/MasterBar.js';
import { Note } from '../model/Note.js';
import { NoteAccidentalMode } from '../model/NoteAccidentalMode.js';
import { PickStroke } from '../model/PickStroke.js';
import { PlaybackInformation } from '../model/PlaybackInformation.js';
import { Score, ScoreSubElement } from '../model/Score.js';
import { Section } from '../model/Section.js';
import { SlideInType } from '../model/SlideInType.js';
import { SlideOutType } from '../model/SlideOutType.js';
import type { Staff } from '../model/Staff.js';
import { Track } from '../model/Track.js';
import { TripletFeel } from '../model/TripletFeel.js';
import { VibratoType } from '../model/VibratoType.js';
import { Voice } from '../model/Voice.js';

import type { IWriteable } from '../io/IWriteable.js';
import { Logger } from '../Logger.js';
import { AccidentalType } from '../model/AccidentalType.js';
import { Direction } from '../model/Direction.js';
import { FadeType } from '../model/FadeType.js';
import { ModelUtils } from '../model/ModelUtils.js';
import { Ottavia } from '../model/Ottavia.js';
import { Rasgueado } from '../model/Rasgueado.js';
import { TremoloPickingEffect } from '../model/TremoloPickingEffect.js';
import { WahPedal } from '../model/WahPedal.js';
import { BeamDirection } from '../rendering/utils/BeamDirection.js';

/**
 * @internal
 */
export class Gp3To5Importer extends ScoreImporter {
    /** Observe decoded source before consolidation/finishing can synthesize or repair facts. */
    public onBeforeFinish?: (score: Score) => void;
    /** Raw numeric field observer runs before source values can be normalized or ignored. */
    public onSourceField?: (name: string, value: number, byteOffset: number, byteLength: number) => void;
    private sourceField(name: string, value: number, bytes = 1): void {
        this.onSourceField?.(name, value, this.data.position - bytes, bytes);
    }
    private static readonly _versionString: string = 'FICHIER GUITAR PRO ';

    // NOTE: General Midi only defines percussion instruments from 35-81
    // Guitar Pro 5 allowed GS extensions (27-34 and 82-87)
    // GP7-8 do not have all these definitions anymore, this lookup ensures some fallback
    // (even if they are not correct)
    // we can support this properly in future when we allow custom alphaTex articulation definitions
    // then we don't need to rely on GP specifics anymore but handle things on export/import
    private static readonly _gp5PercussionInstrumentMap = new Map<number, number>([
        // High Q -> GS "High Q / Filter Snap"
        [27, 42],
        // Slap
        [28, 60],
        // Scratch Push
        [29, 29],
        // Scratch Pull
        [30, 30],
        // Square Click
        [32, 31]
    ]);

    private _versionNumber: number = 0;
    private _score!: Score;
    private _globalTripletFeel: TripletFeel = TripletFeel.NoTripletFeel;
    private _lyricsTrack: number = 0;
    private _lyrics: Lyrics[] = [];
    private _barCount: number = 0;
    private _trackCount: number = 0;
    private _playbackInfos: PlaybackInformation[] = [];
    private _doubleBars: Set<number> = new Set<number>();
    private _clefsPerTrack: Map<number, Clef> = new Map<number, Clef>();
    private _keySignatures: Map<number, [KeySignature, KeySignatureType]> = new Map<
        number,
        [KeySignature, KeySignatureType]
    >();
    private _beatTextChunksByTrack: Map<number, string[]> = new Map<number, string[]>();

    private _directionLookup: Map<number, Direction[]> = new Map<number, Direction[]>();
    private _initialTempo: Automation | undefined;

    public get name(): string {
        return 'Guitar Pro 3-5';
    }

    public readScore(): Score {
        this._directionLookup.clear();

        this.readVersion();
        this._score = new Score();
        // basic song info
        this.readScoreInformation();
        // triplet feel before Gp5
        if (this._versionNumber < 500) {
            const globalTripletFeel = this.data.readByte();
            this.sourceField('global-triplet-feel', globalTripletFeel);
            this._globalTripletFeel = globalTripletFeel !== 0 ? TripletFeel.Triplet8th : TripletFeel.NoTripletFeel;
        }
        // beat lyrics
        if (this._versionNumber >= 400) {
            this.readLyrics();
        }
        // rse master settings since GP5.1
        if (this._versionNumber >= 510) {
            // master volume (4)
            // master effect (4)
            // master equalizer (10)
            // master equalizer preset (1)
            this.data.skip(19);
        }
        // page setup since GP5
        this._initialTempo = Automation.buildTempoAutomation(false, 0, 0, 0);
        if (this._versionNumber >= 500) {
            this.readPageSetup();
            this._initialTempo.text = GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );
        }
        // tempo stuff
        this._initialTempo.value = IOHelper.readInt32LE(this.data);
        this.sourceField('initial-tempo', this._initialTempo.value, 4);
        if (this._versionNumber >= 510) {
            const hideTempo = this.data.readByte();
            this.sourceField('hide-tempo', hideTempo);
        }
        // keysignature and octave
        const initialKey = this._versionNumber >= 500 ? IOHelper.readSInt8(this.data) : IOHelper.readInt32LE(this.data);
        this.sourceField('initial-key', initialKey, this._versionNumber >= 500 ? 1 : 4);
        if (this._versionNumber >= 400) {
            const initialOctave = this._versionNumber >= 500 ? IOHelper.readInt32LE(this.data) : this.data.readByte();
            this.sourceField('initial-octave', initialOctave, this._versionNumber >= 500 ? 4 : 1);
        }
        this.readPlaybackInfos();
        // repetition stuff
        if (this._versionNumber >= 500) {
            this._readDirection(Direction.TargetCoda);
            this._readDirection(Direction.TargetDoubleCoda);
            this._readDirection(Direction.TargetSegno);
            this._readDirection(Direction.TargetSegnoSegno);
            this._readDirection(Direction.TargetFine);

            this._readDirection(Direction.JumpDaCapo);
            this._readDirection(Direction.JumpDaCapoAlCoda);
            this._readDirection(Direction.JumpDaCapoAlDoubleCoda);
            this._readDirection(Direction.JumpDaCapoAlFine);

            this._readDirection(Direction.JumpDalSegno);
            this._readDirection(Direction.JumpDalSegnoAlCoda);
            this._readDirection(Direction.JumpDalSegnoAlDoubleCoda);
            this._readDirection(Direction.JumpDalSegnoAlFine);

            this._readDirection(Direction.JumpDalSegnoSegno);
            this._readDirection(Direction.JumpDalSegnoSegnoAlCoda);
            this._readDirection(Direction.JumpDalSegnoSegnoAlDoubleCoda);
            this._readDirection(Direction.JumpDalSegnoSegnoAlFine);

            this._readDirection(Direction.JumpDaCoda);
            this._readDirection(Direction.JumpDaDoubleCoda);

            // unknown (4)
            this.data.skip(4);
        }
        // contents
        this._barCount = IOHelper.readInt32LE(this.data);
        this.sourceField('bar-count', this._barCount, 4);
        this._ensureLoopBoundary(this._barCount, Gp3To5Importer._maxBarCount, 'bar count');

        this._trackCount = IOHelper.readInt32LE(this.data);
        this.sourceField('track-count', this._trackCount, 4);
        this._ensureLoopBoundary(this._trackCount, Gp3To5Importer._maxTrackCount, 'track count');

        this.readMasterBars();
        this.readTracks();
        this.readBars();

        // To be more in line with the GP7 structure we create an
        // initial tempo automation on the first masterbar
        if (this._score.masterBars.length > 0) {
            const automation = Automation.buildTempoAutomation(false, 0, this._score.tempo, 2);
            automation.text = this._score.tempoLabel;
            this._score.masterBars[0].tempoAutomations.push(automation);
        }

        this.onBeforeFinish?.(this._score);
        ModelUtils.consolidate(this._score);
        this._score.finish(this.settings);
        if (this._lyrics && this._lyricsTrack >= 0) {
            this._score.tracks[this._lyricsTrack].applyLyrics(this._lyrics);
        }
        return this._score;
    }

    private _readDirection(direction: Direction) {
        let directionIndex = IOHelper.readInt16LE(this.data);
        this.sourceField(`navigation:${direction}`, directionIndex, 2);
        // direction not set
        if (directionIndex === -1) {
            return;
        }

        // indexes are 1-based in file
        directionIndex--;

        let directionsList: Direction[];
        if (this._directionLookup.has(directionIndex)) {
            directionsList = this._directionLookup.get(directionIndex)!;
        } else {
            directionsList = [];
            this._directionLookup.set(directionIndex, directionsList);
        }
        directionsList.push(direction);
    }

    public readVersion(): void {
        let version: string = GpBinaryHelpers.gpReadStringByteLength(this.data, 30, this.settings.importer.encoding);
        if (!version.startsWith(Gp3To5Importer._versionString)) {
            throw new UnsupportedFormatError('Unsupported format');
        }
        version = version.substr(Gp3To5Importer._versionString.length + 1);
        const dot: number = version.indexOf(String.fromCharCode(46));
        this._versionNumber =
            100 * Number.parseInt(version.substr(0, dot), 10) + Number.parseInt(version.substr(dot + 1), 10);
        Logger.debug(this.name, `Guitar Pro version ${version} detected`);
    }

    public readScoreInformation(): void {
        this._score.title = GpBinaryHelpers.gpReadStringIntUnused(
            this.data,
            this.settings.importer.encoding,
            this.settings.importer.maxDecodingBufferSize
        );
        this._score.subTitle = GpBinaryHelpers.gpReadStringIntUnused(
            this.data,
            this.settings.importer.encoding,
            this.settings.importer.maxDecodingBufferSize
        );
        this._score.artist = GpBinaryHelpers.gpReadStringIntUnused(
            this.data,
            this.settings.importer.encoding,
            this.settings.importer.maxDecodingBufferSize
        );
        this._score.album = GpBinaryHelpers.gpReadStringIntUnused(
            this.data,
            this.settings.importer.encoding,
            this.settings.importer.maxDecodingBufferSize
        );
        this._score.words = GpBinaryHelpers.gpReadStringIntUnused(
            this.data,
            this.settings.importer.encoding,
            this.settings.importer.maxDecodingBufferSize
        );
        this._score.music =
            this._versionNumber >= 500
                ? GpBinaryHelpers.gpReadStringIntUnused(
                      this.data,
                      this.settings.importer.encoding,
                      this.settings.importer.maxDecodingBufferSize
                  )
                : this._score.words;
        this._score.copyright = GpBinaryHelpers.gpReadStringIntUnused(
            this.data,
            this.settings.importer.encoding,
            this.settings.importer.maxDecodingBufferSize
        );
        this._score.tab = GpBinaryHelpers.gpReadStringIntUnused(
            this.data,
            this.settings.importer.encoding,
            this.settings.importer.maxDecodingBufferSize
        );
        this._score.instructions = GpBinaryHelpers.gpReadStringIntUnused(
            this.data,
            this.settings.importer.encoding,
            this.settings.importer.maxDecodingBufferSize
        );
        const noticeLines: number = IOHelper.readInt32LE(this.data);
        this._ensureLoopBoundary(noticeLines, Gp3To5Importer._maxNoticeLines, 'notice line count');
        let notice: string = '';
        for (let i: number = 0; i < noticeLines; i++) {
            if (i > 0) {
                notice += '\r\n';
            }
            notice += GpBinaryHelpers.gpReadStringIntUnused(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            )?.toString();
        }
        this._score.notices = notice;
    }

    // very generous thresholds for values which control loop boundaries
    // prevents DoS or resource exhaustion for corrupt files or files with malicious intent
    // not configurable, as realistically GP3-5 files will not exceed these values,

    // I don't hink anyone is that verbose in the small GP5 box where you can add notices
    private static readonly _maxNoticeLines = 1000;

    // I haven't encountered such a long song in the wild. beyond 1000 bars something is clearly off
    private static readonly _maxBarCount = 1000;
    
    // I think GP5 itself limits already to ~10. 100 tracks is just unrealistic, proof me wrong
    private static readonly _maxTrackCount = 100;

    // nobody reallistically writes that many beats in one bar either.
    private static readonly _maxBeatCount = 100;

    // I think GP5 already limits this to way less, very generous to allow 4 times more than likely the UI supports
    private static readonly _maxBendPointCount = BendPoint.MaxPosition * 4;

    private _ensureLoopBoundary(value: number, maximumValue: number, label: string) {
        if (value > maximumValue) {
            throw new OverflowError(
                `'${label}' with value ${value} has exceeded the internal safety threshold of ${maximumValue}`
            );
        }
    }

    public readLyrics(): void {
        this._lyrics = [];
        this._lyricsTrack = IOHelper.readInt32LE(this.data) - 1;
        this.sourceField('lyrics-track', this._lyricsTrack, 4);
        for (let i: number = 0; i < 5; i++) {
            const lyrics: Lyrics = new Lyrics();
            lyrics.startBar = IOHelper.readInt32LE(this.data) - 1;
            this.sourceField(`lyrics-start:${i}`, lyrics.startBar + 1, 4);
            const textStart = this.data.position;
            lyrics.text = GpBinaryHelpers.gpReadStringInt(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );
            this.sourceField(`lyrics-present:${i}`, lyrics.text.trim() ? 1 : 0, this.data.position - textStart);
            this._lyrics.push(lyrics);
        }
    }

    public readPageSetup(): void {
        // Page Width (4)
        // Page Heigth (4)
        // Padding Left (4)
        // Padding Right (4)
        // Padding Top (4)
        // Padding Bottom (4)
        // Size Proportion(4)
        this.data.skip(28);

        const flags = IOHelper.readInt16LE(this.data);
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Title).isVisible =
            (flags & (0x01 << 0)) !== 0;
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Title).template =
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );

        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.SubTitle).isVisible =
            (flags & (0x01 << 1)) !== 0;
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.SubTitle).template =
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );

        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Artist).isVisible =
            (flags & (0x01 << 2)) !== 0;
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Artist).template =
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );

        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Album).isVisible =
            (flags & (0x01 << 3)) !== 0;
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Album).template =
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );

        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Words).isVisible =
            (flags & (0x01 << 4)) !== 0;
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Words).template =
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );

        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Music).isVisible =
            (flags & (0x01 << 5)) !== 0;
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Music).template =
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );

        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.WordsAndMusic).isVisible =
            (flags & (0x01 << 6)) !== 0;
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.WordsAndMusic).template =
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );

        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Copyright).isVisible =
            (flags & (0x01 << 7)) !== 0;
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.Copyright).template =
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );

        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.CopyrightSecondLine).isVisible =
            (flags & (0x01 << 7)) !== 0;
        ModelUtils.getOrCreateHeaderFooterStyle(this._score, ScoreSubElement.CopyrightSecondLine).template =
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );
        // page number format
        GpBinaryHelpers.gpReadStringIntByte(
            this.data,
            this.settings.importer.encoding,
            this.settings.importer.maxDecodingBufferSize
        );
    }

    public readPlaybackInfos(): void {
        this._playbackInfos = [];
        let channel = 0;
        for (let i: number = 0; i < 64; i++) {
            const info: PlaybackInformation = new PlaybackInformation();
            info.primaryChannel = channel++;
            info.secondaryChannel = channel++;
            info.program = IOHelper.readInt32LE(this.data);
            this.sourceField(`channel-program:${i}`, info.program, 4);
            info.volume = this.data.readByte();
            info.balance = this.data.readByte();
            this.data.skip(6);
            this._playbackInfos.push(info);
        }
    }

    public readMasterBars(): void {
        for (let i: number = 0; i < this._barCount; i++) {
            this.readMasterBar();
        }
    }

    public readMasterBar(): void {
        let previousMasterBar: MasterBar | null = null;
        if (this._score.masterBars.length > 0) {
            previousMasterBar = this._score.masterBars[this._score.masterBars.length - 1];
        }
        const newMasterBar: MasterBar = new MasterBar();
        if (!previousMasterBar && this._initialTempo!.value > 0) {
            newMasterBar.tempoAutomations.push(this._initialTempo!);
        }

        const flags: number = this.data.readByte();
        this.sourceField('master-flags', flags);
        // time signature
        if ((flags & 0x01) !== 0) {
            newMasterBar.timeSignatureNumerator = this.data.readByte();
            this.sourceField('meter-numerator', newMasterBar.timeSignatureNumerator);
        } else if (previousMasterBar) {
            newMasterBar.timeSignatureNumerator = previousMasterBar.timeSignatureNumerator;
        }
        if ((flags & 0x02) !== 0) {
            newMasterBar.timeSignatureDenominator = this.data.readByte();
            this.sourceField('meter-denominator', newMasterBar.timeSignatureDenominator);
        } else if (previousMasterBar) {
            newMasterBar.timeSignatureDenominator = previousMasterBar.timeSignatureDenominator;
        }
        // repeatings
        newMasterBar.isRepeatStart = (flags & 0x04) !== 0;
        if ((flags & 0x08) !== 0) {
            const repeatCount = this.data.readByte();
            this.sourceField('repeat-count', repeatCount);
            newMasterBar.repeatCount = repeatCount + (this._versionNumber >= 500 ? 0 : 1);
        }
        // alternate endings (pre GP5)
        if ((flags & 0x10) !== 0 && this._versionNumber < 500) {
            let currentMasterBar: MasterBar | null = previousMasterBar;
            // get the already existing alternatives to ignore them
            let existentAlternatives: number = 0;
            while (currentMasterBar) {
                // found another repeat ending?
                if (currentMasterBar.isRepeatEnd && currentMasterBar !== previousMasterBar) {
                    break;
                }
                // found the opening?
                if (currentMasterBar.isRepeatStart) {
                    break;
                }
                existentAlternatives = existentAlternatives | currentMasterBar.alternateEndings;
                currentMasterBar = currentMasterBar.previousMasterBar;
            }
            // now calculate the alternative for this bar
            let repeatAlternative: number = 0;
            const repeatMask: number = this.data.readByte();
            this.sourceField('alternate-ending-count', repeatMask);
            for (let i: number = 0; i < 8; i++) {
                // only add the repeating if it is not existing
                const repeating: number = 1 << i;
                if (repeatMask > i && (existentAlternatives & repeating) === 0) {
                    repeatAlternative = repeatAlternative | repeating;
                }
            }
            newMasterBar.alternateEndings = repeatAlternative;
        }
        // marker
        if ((flags & 0x20) !== 0) {
            const section: Section = new Section();
            section.text = GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );
            section.marker = '';
            GpBinaryHelpers.gpReadColor(this.data, false);
            newMasterBar.section = section;
        }
        // keysignature
        if ((flags & 0x40) !== 0) {
            const key = IOHelper.readSInt8(this.data);
            this.sourceField('key-fifths', key);
            const mode = this.data.readByte();
            this.sourceField('key-mode', mode);
            this._keySignatures.set(this._score.masterBars.length, [key as KeySignature, mode as KeySignatureType]);
        }
        if (this._versionNumber >= 500 && (flags & 0x03) !== 0) {
            for (let i = 0; i < 4; i++) this.sourceField(`beam-group:${i}`, this.data.readByte());
        }
        // better alternate ending mask in GP5
        if (this._versionNumber >= 500) {
            newMasterBar.alternateEndings = this.data.readByte();
            this.sourceField('alternate-endings', newMasterBar.alternateEndings);
        }
        // tripletfeel
        if (this._versionNumber >= 500) {
            const tripletFeel: number = this.data.readByte();
            this.sourceField('triplet-feel', tripletFeel);
            switch (tripletFeel) {
                case 1:
                    newMasterBar.tripletFeel = TripletFeel.Triplet8th;
                    break;
                case 2:
                    newMasterBar.tripletFeel = TripletFeel.Triplet16th;
                    break;
            }
            this.data.readByte();
        } else {
            newMasterBar.tripletFeel = this._globalTripletFeel;
        }
        const isDoubleBar = (flags & 0x80) !== 0;
        newMasterBar.isDoubleBar = isDoubleBar;

        const barIndexForDirection = this._score.masterBars.length;
        if (this._directionLookup.has(barIndexForDirection)) {
            for (const direction of this._directionLookup.get(barIndexForDirection)!) {
                newMasterBar.addDirection(direction);
            }
        }

        this._score.addMasterBar(newMasterBar);

        if (isDoubleBar) {
            this._doubleBars.add(newMasterBar.index);
        }
    }

    public readTracks(): void {
        for (let i: number = 0; i < this._trackCount; i++) {
            this.readTrack();
        }
        if (this._versionNumber >= 500) this.sourceField('track-separator', this.data.readByte());
    }

    /**
     * Guitar Pro 3-6 changes to a bass clef if any string tuning is below B1
     */
    private static readonly _bassClefTuningThreshold = ModelUtils.parseTuning('B1')!.realValue;

    public readTrack(): void {
        const newTrack: Track = new Track();
        newTrack.ensureStaveCount(1);
        this._score.addTrack(newTrack);
        const mainStaff: Staff = newTrack.staves[0];

        // Track Flags:
        // 1   - Percussion Track
        // 2   - 12 Stringed Track
        // 4   - Unknown
        // 8   - Is Visible on Multi Track
        // 16  - Unknown
        // 32  - Unknown
        // 64  - Unknown
        // 128 - Show Tuning

        const flags: number = this.data.readByte();
        this.sourceField('track-flags', flags);
        const nameStart = this.data.position;
        newTrack.name = GpBinaryHelpers.gpReadStringByteLength(this.data, 40, this.settings.importer.encoding);
        this.sourceField('track-name-length', newTrack.name.length, this.data.position - nameStart);
        if ((flags & 0x01) !== 0) {
            mainStaff.isPercussion = true;
        }
        if (this._versionNumber >= 500) {
            newTrack.isVisibleOnMultiTrack = (flags & 0x08) !== 0;
        }

        if (this._score.stylesheet.perTrackDisplayTuning === null) {
            this._score.stylesheet.perTrackDisplayTuning = new Map<number, boolean>();
        }
        this._score.stylesheet.perTrackDisplayTuning!.set(newTrack.index, (flags & 0x80) !== 0);

        //
        const stringCount: number = IOHelper.readInt32LE(this.data);
        this.sourceField('string-count', stringCount, 4);
        const tuning: number[] = [];
        for (let i: number = 0; i < 7; i++) {
            const stringTuning: number = IOHelper.readInt32LE(this.data);
            this.sourceField(`tuning:${i}`, stringTuning, 4);
            if (stringCount > i) {
                tuning.push(stringTuning);
            }
        }
        mainStaff.stringTuning.tunings = tuning;

        const port: number = IOHelper.readInt32LE(this.data);
        const index: number = IOHelper.readInt32LE(this.data) - 1;
        this.sourceField('channel', index + 1, 4);
        const effectChannel: number = IOHelper.readInt32LE(this.data) - 1;
        this.data.skip(4); // Fretcount

        if (index >= 0 && index < this._playbackInfos.length) {
            const info: PlaybackInformation = this._playbackInfos[index];
            info.port = port;
            info.isSolo = (flags & 0x10) !== 0;
            info.isMute = (flags & 0x20) !== 0;
            info.secondaryChannel = effectChannel;
            if (GeneralMidi.isGuitar(info.program)) {
                mainStaff.displayTranspositionPitch = -12;
            }
            newTrack.playbackInfo = info;
        }
        mainStaff.capo = IOHelper.readInt32LE(this.data);
        this.sourceField('capo', mainStaff.capo, 4);
        newTrack.color = GpBinaryHelpers.gpReadColor(this.data, false);
        if (this._versionNumber >= 500) {
            const staffFlags = this.data.readByte();
            mainStaff.showTablature = (staffFlags & 0x01) !== 0;
            mainStaff.showStandardNotation = (staffFlags & 0x02) !== 0;

            const showChordDiagramListOnTopOfScore = (staffFlags & 0x64) !== 0;

            if (this._score.stylesheet.perTrackChordDiagramsOnTop === null) {
                this._score.stylesheet.perTrackChordDiagramsOnTop = new Map<number, boolean>();
            }
            this._score.stylesheet.perTrackChordDiagramsOnTop!.set(newTrack.index, showChordDiagramListOnTopOfScore);

            // MIDI: Automatic
            //  0x01 -> always set (unknown)
            //  0x02 -> auto let ring
            //  0x04 -> auto brush
            const automaticMidi = this.data.readByte();
            this.sourceField('automatic-midi', automaticMidi);

            // RSE: Auto-Accentuation on the Beat
            // 0 - None
            // 1 - Very Soft
            // 2 - Soft
            // 3 - Medium
            // 4 - Strong
            // 5 - Very Strong
            this.sourceField('automatic-accent', this.data.readByte());

            newTrack.playbackInfo.bank = this.data.readByte();
            this.sourceField('sound-bank', newTrack.playbackInfo.bank);

            // RSE: Human Playing (1 byte, 0-100%)
            this.sourceField('humanize', this.data.readByte());

            // `12` for all tunings which have bass clefs
            const clefMode = IOHelper.readInt32LE(this.data);
            this.sourceField('clef-mode', clefMode, 4);
            if (clefMode === 12 || tuning[tuning.length - 1] < Gp3To5Importer._bassClefTuningThreshold) {
                this._clefsPerTrack.set(newTrack.index, Clef.F4);
            } else {
                this._clefsPerTrack.set(newTrack.index, Clef.G2);
            }

            // Unknown, no UI setting seem to affect this
            const secondaryClefMode = IOHelper.readInt32LE(this.data);
            this.sourceField('secondary-clef-mode', secondaryClefMode, 4);

            // Unknown, no UI setting seem to affect this
            // typically: 100
            IOHelper.readInt32LE(this.data);

            // Unknown, no UI setting seem to affect this
            // typically: 1 2 3 4 5 6 7 8 9 10
            this.data.skip(10);

            // Unknown, no UI setting seem to affect this
            // typically: 255
            this.data.readByte();

            // Unknown, no UI setting seem to affect this
            // typically: 3
            this.data.readByte();

            this._readRseBank();

            // this.data.skip(42);
            if (this._versionNumber >= 510) {
                // RSE: 3-band EQ
                // 1 byte Low
                // 1 byte Mid
                // 1 byte High
                // 1 byte PRE
                this.data.skip(4);

                // RSE: effect name
                GpBinaryHelpers.gpReadStringIntByte(
                    this.data,
                    this.settings.importer.encoding,
                    this.settings.importer.maxDecodingBufferSize
                );

                // RSE: effect category
                GpBinaryHelpers.gpReadStringIntByte(
                    this.data,
                    this.settings.importer.encoding,
                    this.settings.importer.maxDecodingBufferSize
                );
            }
        } else {
            if (tuning[tuning.length - 1] < Gp3To5Importer._bassClefTuningThreshold) {
                this._clefsPerTrack.set(newTrack.index, Clef.F4);
            } else {
                this._clefsPerTrack.set(newTrack.index, Clef.G2);
            }
        }
    }

    public readBars(): void {
        for (let i: number = 0; i < this._barCount; i++) {
            for (let t: number = 0; t < this._trackCount; t++) {
                this.readBar(this._score.tracks[t]);
            }
        }
    }

    public readBar(track: Track): void {
        const newBar: Bar = new Bar();
        const mainStaff: Staff = track.staves[0];
        if (mainStaff.isPercussion) {
            newBar.clef = Clef.Neutral;
        } else if (this._clefsPerTrack.has(track.index)) {
            newBar.clef = this._clefsPerTrack.get(track.index)!;
        }
        mainStaff.addBar(newBar);

        if (this._keySignatures.has(newBar.index)) {
            const newKeySignature = this._keySignatures.get(newBar.index)!;
            newBar.keySignature = newKeySignature[0];
            newBar.keySignatureType = newKeySignature[1];
        } else if (newBar.index > 0) {
            newBar.keySignature = newBar.previousBar!.keySignature;
            newBar.keySignatureType = newBar.previousBar!.keySignatureType;
        }

        if (this._doubleBars.has(newBar.index)) {
            newBar.barLineRight = BarLineStyle.LightLight;
        }

        let voiceCount: number = 1;
        if (this._versionNumber >= 500) {
            voiceCount = 2;
        }
        for (let v: number = 0; v < voiceCount; v++) {
            this.readVoice(track, newBar);
        }
        if (this._versionNumber >= 500) {
            // Some producer files omit only the terminal layout byte. All encoded
            // bars, tracks and voices must already be complete; never pad music.
            if (this.data.position === this.data.length && newBar.index === this._barCount - 1 && track.index === this._trackCount - 1) {
                this.sourceField('final-layout-absent', 1, 0);
            } else this.sourceField('bar-line-break', this.data.readByte());
        }
    }

    public readVoice(track: Track, bar: Bar): void {
        const beatCount: number = IOHelper.readInt32LE(this.data);
        this.sourceField('beat-count', beatCount, 4);
        // Keep encoded voice slots, including an empty secondary voice.
        const newVoice: Voice = new Voice();
        bar.addVoice(newVoice);
        if (beatCount === 0) {
            return;
        }

        this._ensureLoopBoundary(beatCount, Gp3To5Importer._maxBeatCount, 'beat count');
        for (let i: number = 0; i < beatCount; i++) {
            this.readBeat(track, bar, newVoice);
        }
    }

    public readBeat(track: Track, bar: Bar, voice: Voice): void {
        const newBeat: Beat = new Beat();
        const flags: number = this.data.readByte();
        this.sourceField('beat-flags', flags);
        if ((flags & 0x01) !== 0) {
            newBeat.dots = 1;
        }
        if ((flags & 0x40) !== 0) {
            const type: number = this.data.readByte();
            this.sourceField('beat-status', type);
            newBeat.isEmpty = (type & 0x02) === 0;
        }
        voice.addBeat(newBeat);
        const duration: number = IOHelper.readSInt8(this.data);
        this.sourceField('duration-exponent', duration);
        switch (duration) {
            case -2:
                newBeat.duration = Duration.Whole;
                break;
            case -1:
                newBeat.duration = Duration.Half;
                break;
            case 0:
                newBeat.duration = Duration.Quarter;
                break;
            case 1:
                newBeat.duration = Duration.Eighth;
                break;
            case 2:
                newBeat.duration = Duration.Sixteenth;
                break;
            case 3:
                newBeat.duration = Duration.ThirtySecond;
                break;
            case 4:
                newBeat.duration = Duration.SixtyFourth;
                break;
            default:
                newBeat.duration = Duration.Quarter;
                break;
        }
        if ((flags & 0x20) !== 0) {
            newBeat.tupletNumerator = IOHelper.readInt32LE(this.data);
            this.sourceField('tuplet', newBeat.tupletNumerator, 4);
            switch (newBeat.tupletNumerator) {
                case 1:
                    newBeat.tupletDenominator = 1;
                    break;
                case 3:
                    newBeat.tupletDenominator = 2;
                    break;
                case 5:
                case 6:
                case 7:
                    newBeat.tupletDenominator = 4;
                    break;
                case 9:
                case 10:
                case 11:
                case 12:
                case 13:
                    newBeat.tupletDenominator = 8;
                    break;
                case 2:
                case 4:
                case 8:
                    break;
                default:
                    newBeat.tupletNumerator = 1;
                    newBeat.tupletDenominator = 1;
                    break;
            }
        }
        if ((flags & 0x02) !== 0) {
            this.readChord(newBeat);
        }

        const beatTextAsLyrics = this.settings.importer.beatTextAsLyrics && track.index !== this._lyricsTrack; // detect if not lyrics track

        if ((flags & 0x04) !== 0) {
            const text = GpBinaryHelpers.gpReadStringIntUnused(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );
            if (beatTextAsLyrics) {
                const lyrics = new Lyrics();
                lyrics.text = text.trim();
                lyrics.finish(true);

                // push them in reverse order to the store for applying them
                // to the next beats being read
                const beatLyrics: string[] = [];
                for (let i = lyrics.chunks.length - 1; i >= 0; i--) {
                    beatLyrics.push(lyrics.chunks[i]);
                }
                this._beatTextChunksByTrack.set(track.index, beatLyrics);
            } else {
                newBeat.text = text;
            }
        }

        let allNoteHarmonicType = HarmonicType.None;
        if ((flags & 0x08) !== 0) {
            allNoteHarmonicType = this.readBeatEffects(newBeat);
        }
        if ((flags & 0x10) !== 0) {
            this.readMixTableChange(newBeat);
        }
        const stringFlags: number = this.data.readByte();
        this.sourceField('string-mask', stringFlags);
        for (let i: number = 6; i >= 0; i--) {
            if ((stringFlags & (1 << i)) !== 0 && 6 - i < bar.staff.tuning.length) {
                const note = this.readNote(track, bar, voice, newBeat, 6 - i);
                if (allNoteHarmonicType !== HarmonicType.None) {
                    note.harmonicType = allNoteHarmonicType;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(note.fret);
                }
            }
        }
        if (this._versionNumber >= 500) {
            // not 100% sure about the bits here but they look good in all test files.

            const flags2 = IOHelper.readInt16LE(this.data);
            this.sourceField('beat-flags2', flags2, 2);

            // beam flags indicate how to handle beams connected to the previous beat,
            // so we have to set the beaming mode on the previous beat!

            // 1 - Break Beams
            if ((flags2 & 0x01) !== 0) {
                if (newBeat.index > 0) {
                    voice.beats[newBeat.index - 1].beamingMode = BeatBeamingMode.ForceSplitToNext;
                }
            }

            // 2 - Force beams down
            // this bit also set if we 'invert' a down-stem, but bit 8 will force the direction to up as both bits are set
            if ((flags2 & 0x02) !== 0) {
                newBeat.preferredBeamDirection = BeamDirection.Down;
            }

            // 4 - Force Beams
            if ((flags2 & 0x04) !== 0) {
                if (newBeat.index > 0) {
                    voice.beats[newBeat.index - 1].beamingMode = BeatBeamingMode.ForceMergeWithNext;
                }
            }

            // 8 - Force beams up
            if ((flags2 & 0x08) !== 0) {
                newBeat.preferredBeamDirection = BeamDirection.Up;
            }

            // 16 - Ottava 8va
            if ((flags2 & 0x10) !== 0) {
                newBeat.ottava = Ottavia._8va;
            }

            // 32 - Ottava 8vb
            if ((flags2 & 0x20) !== 0) {
                newBeat.ottava = Ottavia._8vb;
            }

            // 64 - Ottava 15ma
            if ((flags2 & 0x40) !== 0) {
                newBeat.ottava = Ottavia._15ma;
            }

            // 128 - Unknown, upper bit of first byte, maybe a placeholder.

            // 256 - Ottava 15mb
            if ((flags2 & 0x100) !== 0) {
                newBeat.ottava = Ottavia._15mb;
            }

            // 512 - Unknown
            // 1024 - Unknown

            // 2048 - Break Secondary Beams info set? -> read another byte for flag
            if ((flags2 & 0x800) !== 0) {
                const breakSecondaryValue = this.data.readByte();
                this.sourceField('break-secondary-beams', breakSecondaryValue);
                const breakSecondaryBeams = breakSecondaryValue !== 0;
                if (newBeat.index > 0 && breakSecondaryBeams) {
                    voice.beats[newBeat.index - 1].beamingMode = BeatBeamingMode.ForceSplitOnSecondaryToNext;
                }
            }

            // 4096 - Unknown
            // 8096 - Force Tuplet Bracket
        }

        if (
            beatTextAsLyrics &&
            !newBeat.isRest &&
            this._beatTextChunksByTrack.has(track.index) &&
            this._beatTextChunksByTrack.get(track.index)!.length > 0
        ) {
            newBeat.lyrics = [this._beatTextChunksByTrack.get(track.index)!.pop()!];
        }
    }

    public readChord(beat: Beat): void {
        const chord: Chord = new Chord();
        const chordId: string = ModelUtils.newGuid();
        if (this._versionNumber >= 500) {
            this.data.skip(17);
            chord.name = GpBinaryHelpers.gpReadStringByteLength(this.data, 21, this.settings.importer.encoding);
            this.data.skip(4);
            chord.firstFret = IOHelper.readInt32LE(this.data);
            this.sourceField('chord-first-fret', chord.firstFret, 4);
            for (let i: number = 0; i < 7; i++) {
                const fret: number = IOHelper.readInt32LE(this.data);
                this.sourceField(`chord-fret:${i}`, fret, 4);
                if (i < beat.voice.bar.staff.tuning.length) {
                    chord.strings.push(fret);
                }
            }
            const numberOfBarres: number = this.data.readByte();
            this.sourceField('chord-barre-count', numberOfBarres);
            const barreFrets: Uint8Array = new Uint8Array(5);
            for (let i = 0; i < barreFrets.length; i++) { barreFrets[i] = this.data.readByte(); this.sourceField(`chord-barre-fret:${i}`, barreFrets[i]); }
            for (let i: number = 0; i < numberOfBarres; i++) {
                chord.barreFrets.push(barreFrets[i]);
            }
            for (let i = 0; i < 5; i++) this.sourceField(`chord-barre-start:${i}`, this.data.readByte());
            for (let i = 0; i < 5; i++) this.sourceField(`chord-barre-end:${i}`, this.data.readByte());
            for (let i = 0; i < 7; i++) this.sourceField(`chord-omission:${i}`, this.data.readByte());
            this.data.skip(1);
            for (let i = 0; i < 7; i++) this.sourceField(`chord-finger:${i}`, IOHelper.readSInt8(this.data));
            this.sourceField('chord-show-fingering', this.data.readByte());
        } else {
            if (this.data.readByte() !== 0) {
                // gp4
                if (this._versionNumber >= 400) {
                    // Sharp (1)
                    // Unused (3)
                    // Root (1)
                    // Major/Minor (1)
                    // Nin,Eleven or Thirteen (1)
                    // Bass (4)
                    // Diminished/Augmented (4)
                    // Add (1)
                    this.data.skip(16);
                    chord.name = GpBinaryHelpers.gpReadStringByteLength(this.data, 21, this.settings.importer.encoding);
                    // Unused (2)
                    // Fifth (1)
                    // Ninth (1)
                    // Eleventh (1)
                    this.data.skip(4);
                    chord.firstFret = IOHelper.readInt32LE(this.data);
                    this.sourceField('chord-first-fret', chord.firstFret, 4);
                    for (let i: number = 0; i < 7; i++) {
                        const fret: number = IOHelper.readInt32LE(this.data);
                        this.sourceField(`chord-fret:${i}`, fret, 4);
                        if (i < beat.voice.bar.staff.tuning.length) {
                            chord.strings.push(fret);
                        }
                    }
                    const numberOfBarres: number = this.data.readByte();
                    this.sourceField('chord-barre-count', numberOfBarres);
                    const barreFrets: Uint8Array = new Uint8Array(5);
                    for (let i = 0; i < barreFrets.length; i++) { barreFrets[i] = this.data.readByte(); this.sourceField(`chord-barre-fret:${i}`, barreFrets[i]); }
                    for (let i: number = 0; i < numberOfBarres; i++) {
                        chord.barreFrets.push(barreFrets[i]);
                    }
                    // Barree end (5)
                    // Omission1,3,5,7,9,11,13 (7)
                    // Unused (1)
                    // Fingering (7)
                    // Show Diagram Fingering (1)
                    // ??
                    for (let i = 0; i < 5; i++) this.sourceField(`chord-barre-start:${i}`, this.data.readByte());
                    for (let i = 0; i < 5; i++) this.sourceField(`chord-barre-end:${i}`, this.data.readByte());
                    for (let i = 0; i < 7; i++) this.sourceField(`chord-omission:${i}`, this.data.readByte());
                    this.data.skip(1);
                    for (let i = 0; i < 7; i++) this.sourceField(`chord-finger:${i}`, IOHelper.readSInt8(this.data));
                    this.sourceField('chord-show-fingering', this.data.readByte());
                } else {
                    this.sourceField('chord-analysis-sharp', this.data.readByte());
                    this.data.skip(3);
                    for (const name of ['root', 'type', 'extension', 'bass', 'tonality']) this.sourceField(`chord-analysis:${name}`, IOHelper.readInt32LE(this.data), 4);
                    this.sourceField('chord-analysis-add', this.data.readByte());
                    chord.name = GpBinaryHelpers.gpReadStringByteLength(this.data, 22, this.settings.importer.encoding);
                    for (const name of ['fifth', 'ninth', 'eleventh']) this.sourceField(`chord-analysis:${name}`, IOHelper.readInt32LE(this.data), 4);
                    chord.firstFret = IOHelper.readInt32LE(this.data);
                    this.sourceField('chord-first-fret', chord.firstFret, 4);
                    for (let i: number = 0; i < 6; i++) {
                        const fret: number = IOHelper.readInt32LE(this.data);
                        this.sourceField(`chord-fret:${i}`, fret, 4);
                        if (i < beat.voice.bar.staff.tuning.length) {
                            chord.strings.push(fret);
                        }
                    }
                    this.sourceField('chord-barre-count', IOHelper.readInt32LE(this.data), 4);
                    for (const field of ['fret', 'start', 'end']) for (let i = 0; i < 2; i++) this.sourceField(`chord-barre-${field}:${i}`, IOHelper.readInt32LE(this.data), 4);
                    for (let i = 0; i < 7; i++) this.sourceField(`chord-omission:${i}`, this.data.readByte());
                    this.data.skip(1);
                }
            } else {
                const strings: number = this._versionNumber >= 406 ? 7 : 6;
                chord.name = GpBinaryHelpers.gpReadStringIntByte(
                    this.data,
                    this.settings.importer.encoding,
                    this.settings.importer.maxDecodingBufferSize
                );
                chord.firstFret = IOHelper.readInt32LE(this.data);
                this.sourceField('chord-first-fret', chord.firstFret, 4);
                if (chord.firstFret > 0) {
                    for (let i: number = 0; i < strings; i++) {
                        const fret: number = IOHelper.readInt32LE(this.data);
                        this.sourceField(`chord-fret:${i}`, fret, 4);
                        if (i < beat.voice.bar.staff.tuning.length) {
                            chord.strings.push(fret);
                        }
                    }
                }
            }
        }
        if (chord.name) {
            beat.chordId = chordId;
            beat.voice.bar.staff.addChord(beat.chordId, chord);
        }
    }

    public readBeatEffects(beat: Beat): HarmonicType {
        const flags: number = this.data.readByte();
        this.sourceField('beat-effect-flags', flags);
        let flags2: number = 0;
        if (this._versionNumber >= 400) {
            flags2 = this.data.readByte();
            this.sourceField('beat-effect-flags2', flags2);
        }
        if ((flags & 0x10) !== 0) {
            beat.fade = FadeType.FadeIn;
        }
        if ((this._versionNumber < 400 && (flags & 0x01) !== 0) || (flags & 0x02) !== 0) {
            beat.vibrato = VibratoType.Slight;
        }
        if ((flags2 & 0x01) !== 0) {
            beat.rasgueado = Rasgueado.Ii;
        }
        if ((flags & 0x20) !== 0 && this._versionNumber >= 400) {
            const slapPop: number = IOHelper.readSInt8(this.data);
            this.sourceField('slap-pop', slapPop);
            switch (slapPop) {
                case 1:
                    beat.tap = true;
                    break;
                case 2:
                    beat.slap = true;
                    break;
                case 3:
                    beat.pop = true;
                    break;
            }
        } else if ((flags & 0x20) !== 0) {
            const slapPop: number = IOHelper.readSInt8(this.data);
            this.sourceField('slap-pop', slapPop);
            switch (slapPop) {
                case 1:
                    beat.tap = true;
                    break;
                case 2:
                    beat.slap = true;
                    break;
                case 3:
                    beat.pop = true;
                    break;
            }
            this.data.skip(4);
        }
        if ((flags2 & 0x04) !== 0) {
            this.readTremoloBarEffect(beat);
        }
        if ((flags & 0x40) !== 0) {
            let strokeUp: number = 0;
            let strokeDown: number = 0;
            if (this._versionNumber < 500) {
                strokeDown = this.data.readByte();
                this.sourceField('strokeDown', strokeDown);
                strokeUp = this.data.readByte();
                this.sourceField('strokeUp', strokeUp);
            } else {
                strokeUp = this.data.readByte();
                this.sourceField('strokeUp', strokeUp);
                strokeDown = this.data.readByte();
                this.sourceField('strokeDown', strokeDown);
            }
            if (strokeUp > 0) {
                beat.brushType = BrushType.BrushUp;
                beat.brushDuration = Gp3To5Importer._toStrokeValue(strokeUp);
            } else if (strokeDown > 0) {
                beat.brushType = BrushType.BrushDown;
                beat.brushDuration = Gp3To5Importer._toStrokeValue(strokeDown);
            }
        }
        if ((flags2 & 0x02) !== 0) {
            const pick = IOHelper.readSInt8(this.data);
            this.sourceField('pick-stroke', pick);
            switch (pick) {
                case 0:
                    beat.pickStroke = PickStroke.None;
                    break;
                case 1:
                    beat.pickStroke = PickStroke.Up;
                    break;
                case 2:
                    beat.pickStroke = PickStroke.Down;
                    break;
            }
        }

        if (this._versionNumber < 400) {
            if ((flags & 0x04) !== 0) {
                return HarmonicType.Natural;
            }
            if ((flags & 0x08) !== 0) {
                return HarmonicType.Artificial;
            }
        }

        return HarmonicType.None;
    }

    public readTremoloBarEffect(beat: Beat): void {
        this.sourceField('whammy-type', this.data.readByte());

        this.sourceField('whammy-value', IOHelper.readInt32LE(this.data), 4);

        const pointCount: number = IOHelper.readInt32LE(this.data);
        this.sourceField('whammy-point-count', pointCount, 4);
        this._ensureLoopBoundary(pointCount, Gp3To5Importer._maxBendPointCount, 'tremolo bar point count');
        if (pointCount > 0) {
            for (let i: number = 0; i < pointCount; i++) {
                const point: BendPoint = new BendPoint(0, 0);
                point.offset = IOHelper.readInt32LE(this.data); // 0...60
                this.sourceField(`whammy-offset:${i}`, point.offset, 4);

                const rawValue = IOHelper.readInt32LE(this.data);
                this.sourceField(`whammy-alter:${i}`, rawValue, 4);
                point.value = (rawValue / Gp3To5Importer._bendStep) | 0; // quarter tones

                this.sourceField(`whammy-vibrato:${i}`, this.data.readByte());

                beat.addWhammyBarPoint(point);
            }
        }
    }

    private static _toStrokeValue(value: number): number {
        switch (value) {
            case 1:
                return 30;
            case 2:
                return 30;
            case 3:
                return 60;
            case 4:
                return 120;
            case 5:
                return 240;
            case 6:
                return 480;
            default:
                return 0;
        }
    }

    private _readRseBank() {
        // RSE Banks on disk are having filenames like this: 033_2_002.ini
        // 033 is the RSE instrument (selected in the instrument list)
        // 2 seem to be some sort of style variation. e.g. bass has multiple variations (1,2), guitars have only 1, percussion has only 0
        //   likely for organizational purposes
        // 002 is the effective soundbank (selected in the soundbank dropdown)

        // RSE Instrument
        this.data.skip(4); // IOHelper.readInt32LE(this.data);

        // RSE Style/Variation
        this.data.skip(4); //IOHelper.readInt32LE(this.data);

        // RSE Soundbank
        this.data.skip(4); //IOHelper.readInt32LE(this.data);

        // Unknown, no UI setting seem to affect this
        // typically: -1
        this.data.skip(4); //IOHelper.readInt32LE(this.data);
    }

    public readMixTableChange(beat: Beat): void {
        const tableChange: MixTableChange = new MixTableChange();
        tableChange.instrument = IOHelper.readSInt8(this.data);
        this.sourceField('mix-instrument', tableChange.instrument);
        // NOTE: The UI shows a Midi Bank selection, but this information is not stored in the file
        // when reopening the file the bank is always 0

        if (this._versionNumber >= 500) {
            this._readRseBank();
        }
        tableChange.volume = IOHelper.readSInt8(this.data);
        this.sourceField('mix-volume', tableChange.volume);
        tableChange.balance = IOHelper.readSInt8(this.data);
        this.sourceField('mix-balance', tableChange.balance);
        const chorus: number = IOHelper.readSInt8(this.data);
        this.sourceField('mix-chorus', chorus);
        const reverb: number = IOHelper.readSInt8(this.data);
        this.sourceField('mix-reverb', reverb);
        const phaser: number = IOHelper.readSInt8(this.data);
        this.sourceField('mix-phaser', phaser);
        const tremolo: number = IOHelper.readSInt8(this.data);
        this.sourceField('mix-tremolo', tremolo);
        if (this._versionNumber >= 500) {
            tableChange.tempoName = GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );
        }
        tableChange.tempo = IOHelper.readInt32LE(this.data);
        this.sourceField('mix-tempo', tableChange.tempo, 4);

        // durations (in number of beats)
        if (tableChange.volume >= 0) {
            this.data.readByte();
        }
        if (tableChange.balance >= 0) {
            this.data.readByte();
        }
        if (chorus >= 0) {
            this.data.readByte();
        }
        if (reverb >= 0) {
            this.data.readByte();
        }
        if (phaser >= 0) {
            this.data.readByte();
        }
        if (tremolo >= 0) {
            this.data.readByte();
        }
        if (tableChange.tempo >= 0) {
            tableChange.duration = IOHelper.readSInt8(this.data);
            this.sourceField('mix-duration', tableChange.duration);
            if (this._versionNumber >= 510) {
                this.sourceField('mix-hide-tempo', this.data.readByte());
            }
        }

        if (this._versionNumber >= 400) {
            this.sourceField('mix-flags', this.data.readByte());
        }

        if (this._versionNumber >= 500) {
            const wahType = IOHelper.readSInt8(this.data);
            this.sourceField('mix-wah', wahType);
            // const showWahWah = (mixTableFlags & 0x80) !== 0;
            // -1 Off (when there is a mixtable but no wah-wah)
            if (wahType >= 100) {
                beat.wahPedal = WahPedal.Closed;
            } else if (wahType >= 0) {
                beat.wahPedal = WahPedal.Open;
            }
        }
        // unknown
        if (this._versionNumber >= 510) {
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );
            GpBinaryHelpers.gpReadStringIntByte(
                this.data,
                this.settings.importer.encoding,
                this.settings.importer.maxDecodingBufferSize
            );
        }
        if (tableChange.volume >= 0) {
            const volumeAutomation: Automation = new Automation();
            volumeAutomation.isLinear = true;
            volumeAutomation.type = AutomationType.Volume;
            volumeAutomation.value = tableChange.volume;
            beat.automations.push(volumeAutomation);
        }
        if (tableChange.balance >= 0) {
            const balanceAutomation: Automation = new Automation();
            balanceAutomation.isLinear = true;
            balanceAutomation.type = AutomationType.Balance;
            balanceAutomation.value = tableChange.balance;
            beat.automations.push(balanceAutomation);
        }
        if (tableChange.instrument >= 0) {
            const instrumentAutomation: Automation = new Automation();
            instrumentAutomation.isLinear = true;
            instrumentAutomation.type = AutomationType.Instrument;
            instrumentAutomation.value = tableChange.instrument;
            beat.automations.push(instrumentAutomation);
        }
        if (tableChange.tempo >= 0) {
            const tempoAutomation: Automation = new Automation();
            tempoAutomation.isLinear = true;
            tempoAutomation.type = AutomationType.Tempo;
            tempoAutomation.value = tableChange.tempo;
            beat.automations.push(tempoAutomation);

            if (
                !beat.voice.bar.masterBar.tempoAutomations.some(
                    a => a.ratioPosition === tempoAutomation.ratioPosition && a.value === tempoAutomation.value
                )
            ) {
                beat.voice.bar.masterBar.tempoAutomations.push(tempoAutomation);
            }
        }
    }

    public readNote(track: Track, bar: Bar, voice: Voice, beat: Beat, stringIndex: number): Note {
        const newNote: Note = new Note();
        newNote.string = bar.staff.tuning.length - stringIndex;
        const flags: number = this.data.readByte();
        this.sourceField('note-flags', flags);
        if ((flags & 0x02) !== 0) {
            newNote.accentuated = AccentuationType.Heavy;
        } else if ((flags & 0x40) !== 0) {
            newNote.accentuated = AccentuationType.Normal;
        }
        newNote.isGhost = (flags & 0x04) !== 0;
        if ((flags & 0x20) !== 0) {
            const noteType: number = this.data.readByte();
            this.sourceField('note-type', noteType);
            if (noteType === 3) {
                newNote.isDead = true;
            } else if (noteType === 2) {
                newNote.isTieDestination = true;
            }
        }
        if ((flags & 0x01) !== 0 && this._versionNumber < 500) {
            this.data.readByte(); // duration

            this.data.readByte(); // tuplet
        }
        if ((flags & 0x10) !== 0) {
            const dynamicNumber: number = IOHelper.readSInt8(this.data);
            this.sourceField('note-dynamic', dynamicNumber);
            newNote.dynamics = this.toDynamicValue(dynamicNumber);
            beat.dynamics = newNote.dynamics;
        }
        if ((flags & 0x20) !== 0) {
            newNote.fret = IOHelper.readSInt8(this.data);
            this.sourceField('note-fret', newNote.fret);
        }
        if ((flags & 0x80) !== 0) {
            newNote.leftHandFinger = IOHelper.readSInt8(this.data) as Fingers;
            this.sourceField('left-fingering', newNote.leftHandFinger);
            newNote.rightHandFinger = IOHelper.readSInt8(this.data) as Fingers;
            this.sourceField('right-fingering', newNote.rightHandFinger);
        }
        let swapAccidentals = false;
        if (this._versionNumber >= 500) {
            if ((flags & 0x01) !== 0) {
                newNote.durationPercent = IOHelper.readFloat64BE(this.data);
            }
            const flags2: number = this.data.readByte();
            this.sourceField('note-flags2', flags2);
            swapAccidentals = (flags2 & 0x02) !== 0;
        }
        beat.addNote(newNote);
        if ((flags & 0x08) !== 0) {
            this.readNoteEffects(track, voice, beat, newNote);
        }

        if (bar.staff.isPercussion) {
            newNote.percussionArticulation = Gp3To5Importer._gp5PercussionInstrumentMap.has(newNote.fret)
                ? Gp3To5Importer._gp5PercussionInstrumentMap.get(newNote.fret)!
                : newNote.fret;
            newNote.string = -1;
            newNote.fret = -1;
        }
        if (swapAccidentals) {
            const accidental = ModelUtils.computeAccidental(
                bar.keySignature,
                NoteAccidentalMode.Default,
                newNote.realValueWithoutHarmonic,
                false
            );

            if (accidental === AccidentalType.Sharp) {
                newNote.accidentalMode = NoteAccidentalMode.ForceFlat;
            } else if (accidental === AccidentalType.Flat) {
                newNote.accidentalMode = NoteAccidentalMode.ForceSharp;
            }
            // Note: forcing no sign to sharp not supported
        }
        return newNote;
    }

    public toDynamicValue(value: number): DynamicValue {
        switch (value) {
            case 1:
                return DynamicValue.PPP;
            case 2:
                return DynamicValue.PP;
            case 3:
                return DynamicValue.P;
            case 4:
                return DynamicValue.MP;
            case 5:
                return DynamicValue.MF;
            case 6:
                return DynamicValue.F;
            case 7:
                return DynamicValue.FF;
            case 8:
                return DynamicValue.FFF;
            default:
                return DynamicValue.F;
        }
    }

    public readNoteEffects(_track: Track, voice: Voice, beat: Beat, note: Note): void {
        const flags: number = this.data.readByte();
        this.sourceField('note-effect-flags', flags);
        let flags2: number = 0;
        if (this._versionNumber >= 400) {
            flags2 = this.data.readByte();
            this.sourceField('note-effect-flags2', flags2);
        }
        if ((flags & 0x01) !== 0) {
            this.readBend(note);
        }
        if ((flags & 0x10) !== 0) {
            this.readGrace(voice, note);
        }
        if ((flags2 & 0x04) !== 0) {
            this.readTremoloPicking(beat);
        }
        if ((flags2 & 0x08) !== 0) {
            this.readSlide(note);
        } else if (this._versionNumber < 400) {
            if ((flags & 0x04) !== 0) {
                note.slideOutType = SlideOutType.Shift;
            }
        }
        if ((flags2 & 0x10) !== 0) {
            this.readArtificialHarmonic(note);
        }
        if ((flags2 & 0x20) !== 0) {
            this.readTrill(note);
        }
        note.isLetRing = (flags & 0x08) !== 0;
        note.isHammerPullOrigin = (flags & 0x02) !== 0;
        if ((flags2 & 0x40) !== 0) {
            note.vibrato = VibratoType.Slight;
        }
        note.isPalmMute = (flags2 & 0x02) !== 0;
        note.isStaccato = (flags2 & 0x01) !== 0;
    }

    private static readonly _bendStep: number = 25;

    public readBend(note: Note): void {
        this.sourceField('bend-type', this.data.readByte());

        this.sourceField('bend-value', IOHelper.readInt32LE(this.data), 4);

        const pointCount: number = IOHelper.readInt32LE(this.data);
        this.sourceField('bend-point-count', pointCount, 4);

        this._ensureLoopBoundary(pointCount, Gp3To5Importer._maxBendPointCount, 'note bend point count');
        if (pointCount > 0) {
            for (let i: number = 0; i < pointCount; i++) {
                const point: BendPoint = new BendPoint(0, 0);
                point.offset = IOHelper.readInt32LE(this.data); // 0...60
                this.sourceField(`bend-offset:${i}`, point.offset, 4);

                const rawValue = IOHelper.readInt32LE(this.data);
                this.sourceField(`bend-alter:${i}`, rawValue, 4);
                point.value = (rawValue / Gp3To5Importer._bendStep) | 0; // quarter tones

                this.sourceField(`bend-vibrato:${i}`, this.data.readByte());

                note.addBendPoint(point);
            }
        }
    }

    public readGrace(voice: Voice, note: Note): void {
        const graceBeat: Beat = new Beat();
        const graceNote: Note = new Note();
        graceNote.string = note.string;
        graceNote.fret = IOHelper.readSInt8(this.data);
        this.sourceField('grace-fret', graceNote.fret);
        graceBeat.duration = Duration.ThirtySecond;
        const dynamic = IOHelper.readSInt8(this.data);
        this.sourceField('grace-dynamic', dynamic);
        graceBeat.dynamics = this.toDynamicValue(dynamic);
        const transition: number = IOHelper.readSInt8(this.data);
        this.sourceField('grace-transition', transition);
        switch (transition) {
            case 0:
                break;
            case 1:
                graceNote.slideOutType = SlideOutType.Legato;
                graceNote.slideTarget = note;
                break;
            case 2:
                break;
            case 3:
                graceNote.isHammerPullOrigin = true;
                break;
        }
        graceNote.dynamics = graceBeat.dynamics;
        this.sourceField('grace-duration', this.data.readByte());

        if (this._versionNumber < 500) {
            graceBeat.graceType = GraceType.BeforeBeat;
        } else {
            const flags: number = this.data.readByte();
            this.sourceField('grace-flags', flags);
            graceNote.isDead = (flags & 0x01) !== 0;
            graceBeat.graceType = (flags & 0x02) !== 0 ? GraceType.OnBeat : GraceType.BeforeBeat;
        }
        voice.addGraceBeat(graceBeat);
        graceBeat.addNote(graceNote);
    }

    public readTremoloPicking(beat: Beat): void {
        const effect = new TremoloPickingEffect();
        beat.tremoloPicking = effect;
        effect.marks = this.data.readByte();
        this.sourceField('tremolo-marks', effect.marks);
    }

    public readSlide(note: Note): void {
        if (this._versionNumber >= 500) {
            const type: number = IOHelper.readSInt8(this.data);
            this.sourceField('slide-type', type);
            if ((type & 1) !== 0) {
                note.slideOutType = SlideOutType.Shift;
            } else if ((type & 2) !== 0) {
                note.slideOutType = SlideOutType.Legato;
            } else if ((type & 4) !== 0) {
                note.slideOutType = SlideOutType.OutDown;
            } else if ((type & 8) !== 0) {
                note.slideOutType = SlideOutType.OutUp;
            }
            if ((type & 16) !== 0) {
                note.slideInType = SlideInType.IntoFromBelow;
            } else if ((type & 32) !== 0) {
                note.slideInType = SlideInType.IntoFromAbove;
            }
        } else {
            const type: number = IOHelper.readSInt8(this.data);
            this.sourceField('slide-type', type);
            switch (type) {
                case 1:
                    note.slideOutType = SlideOutType.Shift;
                    break;
                case 2:
                    note.slideOutType = SlideOutType.Legato;
                    break;
                case 3:
                    note.slideOutType = SlideOutType.OutDown;
                    break;
                case 4:
                    note.slideOutType = SlideOutType.OutUp;
                    break;
                case -1:
                    note.slideInType = SlideInType.IntoFromBelow;
                    break;
                case -2:
                    note.slideInType = SlideInType.IntoFromAbove;
                    break;
            }
        }
    }

    public readArtificialHarmonic(note: Note): void {
        const type: number = this.data.readByte();
        this.sourceField('harmonic-type', type);
        if (this._versionNumber >= 500) {
            switch (type) {
                case 1:
                    note.harmonicType = HarmonicType.Natural;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(note.fret);
                    break;
                case 2:
                    // C (0), D (2), E (4), F (5), G (7),A (9),B (11)
                    const harmonicTone: number = this.data.readByte();
                    this.sourceField('harmonic-tone', harmonicTone);
                    // b (255/-1), none (0), # (1)
                    let harmonicKey: number = this.data.readByte();
                    this.sourceField('harmonic-key', harmonicKey);
                    if (harmonicKey === 255) {
                        harmonicKey = -1;
                    }
                    // Loco (0), 8va (1), 15ma (2)
                    const harmonicOctaveOffset: number = this.data.readByte();
                    this.sourceField('harmonic-octave', harmonicOctaveOffset);

                    const harmonicPitch = harmonicTone + harmonicKey; // 0-11 pitch class
                    const playedPitch = (note.fret + note.stringTuning) % 12; // 0-11 pitch class

                    let targetHarmonic = harmonicPitch + harmonicOctaveOffset * 12;

                    // Adjust to ensure harmonic is higher than played note (single octave should be enough with 0-11 played pitch)
                    if (targetHarmonic < playedPitch) {
                        targetHarmonic += 12;
                    }

                    const deltaFrets = targetHarmonic - playedPitch;
                    note.harmonicType = HarmonicType.Artificial;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(deltaFrets);

                    break;
                case 3:
                    note.harmonicType = HarmonicType.Tap;
                    const tapFret = this.data.readByte();
                    this.sourceField('harmonic-tap-fret', tapFret);
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(tapFret);
                    break;
                case 4:
                    note.harmonicType = HarmonicType.Pinch;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(12);
                    break;
                case 5:
                    note.harmonicType = HarmonicType.Semi;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(12);
                    break;
            }
        } else if (this._versionNumber >= 400) {
            switch (type) {
                case 1:
                    note.harmonicType = HarmonicType.Natural;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(note.fret);
                    break;
                case 3:
                    note.harmonicType = HarmonicType.Tap;
                    // GP4 help: The tapped harmonic is an artificial harmonic obtained by tapping quickly on the string 12 frets higher.
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(12);
                    break;
                case 4:
                    note.harmonicType = HarmonicType.Pinch;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(12);
                    break;
                case 5:
                    note.harmonicType = HarmonicType.Semi;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(12);
                    break;
                case 15: // artificial + 5
                    note.harmonicType = HarmonicType.Artificial;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(5);
                    break;
                case 17: // artificial + 7
                    note.harmonicType = HarmonicType.Artificial;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(7);
                    break;
                case 22: // artificial + 12
                    note.harmonicType = HarmonicType.Artificial;
                    note.harmonicValue = ModelUtils.deltaFretToHarmonicValue(12);
                    break;
            }
        }
    }

    public readTrill(note: Note): void {
        const fret = this.data.readByte();
        this.sourceField('trill-fret', fret);
        note.trillValue = fret + note.stringTuning;
        const speed = this.data.readByte();
        this.sourceField('trill-speed', speed);
        switch (speed) {
            case 1:
                note.trillSpeed = Duration.Sixteenth;
                break;
            case 2:
                note.trillSpeed = Duration.ThirtySecond;
                break;
            case 3:
                note.trillSpeed = Duration.SixtyFourth;
                break;
        }
    }
}

/**
 * @internal
 */
export class GpBinaryHelpers {
    public static gpReadColor(data: IReadable, readAlpha: boolean = false): Color {
        const r: number = data.readByte();
        const g: number = data.readByte();
        const b: number = data.readByte();
        let a: number = 255;
        if (readAlpha) {
            a = data.readByte();
        } else {
            data.skip(1);
        }
        return new Color(r, g, b, a);
    }

    public static gpReadBool(data: IReadable): boolean {
        return data.readByte() !== 0;
    }

    /**
     * Skips an integer (4byte) and reads a string using
     * a bytesize
     */
    public static gpReadStringIntUnused(data: IReadable, encoding: string, maxDecodingBufferSize: number): string {
        data.skip(4);
        return GpBinaryHelpers.gpReadString(data, data.readByte(), encoding, maxDecodingBufferSize);
    }

    /**
     * Reads an integer as size, and then the string itself
     */
    public static gpReadStringInt(data: IReadable, encoding: string, maxDecodingBufferSize: number): string {
        return GpBinaryHelpers.gpReadString(data, IOHelper.readInt32LE(data), encoding, maxDecodingBufferSize);
    }

    /**
     * Reads an integer as size, skips a byte and reads the string itself
     */
    public static gpReadStringIntByte(data: IReadable, encoding: string, maxDecodingBufferSize: number): string {
        const length: number = IOHelper.readInt32LE(data) - 1;
        data.readByte();
        return GpBinaryHelpers.gpReadString(data, length, encoding, maxDecodingBufferSize);
    }

    public static gpReadString(
        data: IReadable,
        length: number,
        encoding: string,
        maxDecodingBufferSize: number
    ): string {
        if (length > maxDecodingBufferSize) {
            throw new OverflowError(`Detected string exceeding maxDecodingBufferSize at offset ${data.position}`);
        }
        const b: Uint8Array = new Uint8Array(length);
        data.read(b, 0, b.length);
        return IOHelper.toString(b, encoding);
    }

    public static gpWriteString(data: IWriteable, s: string): void {
        const encoded = IOHelper.stringToBytes(s);
        data.writeByte(s.length);
        data.write(encoded, 0, encoded.length);
    }

    /**
     * Reads a byte as size and the string itself.
     * Additionally it is ensured the specified amount of bytes is read.
     * @param data the data to read from.
     * @param length the amount of bytes to read
     * @param encoding The encoding to use to decode the byte into a string
     * @returns
     */
    public static gpReadStringByteLength(data: IReadable, length: number, encoding: string): string {
        // Fixed-width string field: 1 length byte + `length` data bytes, decoded
        // up to min(stringLength, length). Always consumes 1 + length bytes.
        const stringLength = data.readByte();
        const fieldBytes = new Uint8Array(length);
        data.read(fieldBytes, 0, length);
        const effectiveLength = Math.min(stringLength, length);
        return IOHelper.toString(fieldBytes.subarray(0, effectiveLength), encoding);
    }
}

/**
 * A mixtablechange describes several track changes.
 * @internal
 */
class MixTableChange {
    public volume: number = -1;
    public balance: number = -1;
    public instrument: number = -1;
    public tempoName: string = '';
    public tempo: number = -1;
    public duration: number = -1;
}

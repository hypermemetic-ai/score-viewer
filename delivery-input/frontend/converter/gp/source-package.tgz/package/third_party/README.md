# Incorporated material and proving tools

No top-level project license is selected. The exact npm closure is locked in `package-lock.json`; packages were installed with scripts disabled and no dependency is admitted for a public release by this proof.

| Material | Exact version | Scope | License/notices |
| --- | --- | --- | --- |
| alphaTab reader/model source | 1.8.4 / `022a45c8e42370f9e12e68949d11eada370da83d` | Separately maintained source component; no renderer/audio/assets/repertoire | MPL-2.0; Haxe in-file MIT; constants dependency TinySoundFont/SFZero MIT. [Inventory and source obligations](alphatab/README.md) |
| saxes | 6.0.0 | Runtime strict XML admission | ISC; exact tag license, including inherited sax notice, in `licenses/saxes-6.0.0-LICENSE`. Published npm package omitted the license file, so it is retained here |
| xmlchars | 2.2.0 | saxes runtime character predicates | MIT; `licenses/xmlchars-2.2.0-LICENSE` |
| TypeScript | 5.9.3 | Development compiler only | Apache-2.0 and third-party notices; files in `licenses/` |
| @types/node | 24.10.1 | Development declarations only | MIT; `licenses/types-node-24.10.1-LICENSE` |
| undici-types | 7.16.0 | Development transitive declarations, exactly overridden | MIT; `licenses/undici-types-7.16.0-LICENSE` |
| SMuFL canonical glyph identifiers | `f9d12b22ea89978720ba9defb2f4df67fabd8564` | Identifier-only standard vocabulary in original validation code; no font, metadata descriptions or runtime package | W3C FSA; [provenance and retained notice](../docs/research/native-symbol-vocabulary.md) |
| MusicXML schemas | v4.0 / `799e2defb2ece0ae7bafe08dcbcac25b2c631d53` | Offline development validation only | Original copyright/FSA notices retained in the schemas; [schema provenance](musicxml-4.0/README.md) |
| lxml | 6.0.2 | Optional external Python development environment, not shipped or incorporated | BSD-3-Clause; wheel bundles libxml2/libxslt under their MIT licenses. No runtime Python dependency |

Node's built-in ZIP inflation and CRC are used; no ZIP npm package is added. A Node runtime is required but is not bundled by this proof. Tested local runtime: Node 26.7.0. Package engine floor is Node 24; compatibility with other releases has not yet been exercised.

TinySoundFont notice source: <https://github.com/schellingb/TinySoundFont/blob/master/LICENSE>, retrieved 2026-10-08; the full grant and SFZero attribution are retained, not an assertion that the synthesis implementation is included. saxes license source: <https://github.com/lddubeau/saxes/blob/v6.0.0/LICENSE>. Other npm notice files are copied from the exact installed packages. Lockfile integrity identifies the fetched archives separately from their license evidence.

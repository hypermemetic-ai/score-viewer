# Performer conversion contract

Status: accepted product scope, 2026-10-13, including the MusicXML, version and annotation clarifications in D41–D43. This contract records the owner's requirements; it does not claim that the features below are implemented. See [current status](current-status.md) for evidence and [remaining work](completion-plan.md) for implementation and assessment tasks. D37–D43 in [the decision record](decisions.md) refine the earlier bounded proofs.

## Outcome and boundary

Convert the performer-relevant content of Guitar Pro and MuseScore scores into ordinary MusicXML 4.0. The notation scope is **traditional staff notation and tablature**. Standard percussion notation is included within staff notation; there is no requirement to add a third notation system. Other notation systems are outside this task, rather than material to reinterpret silently.

Guitar and bass are required, including common techniques and their meaningful combinations. Preserve the other notated parts of an arrangement too: piano/keyboards, vocals, percussion and other instruments expressed in the admitted notation scope. A keyboard part is an ordinary pitched score, not an invented keyboard tablature. The source's staff, voice, instrument and written/sounding relationships determine its meaning. Do not invent performing hands, missing music, fingerings, lyrics or physical positions.

The same musical requirement applies whichever adapter encounters it. Existing MuseScore repertoire cannot define the limits of MuseScore support. Conversely, a feature name in the shared model does not establish that the Guitar Pro adapter recovers it.

The version target is GP3–GP8 and MuseScore 3 and 4. MuseScore 1 and 2 are outside this milestone. The exact currently admitted native MuseScore profiles remain those described in [its API](musescore-api.md); the target does not automatically admit an unexamined serializer. Version/profile admission, authentic producer evidence and musical feature coverage are separate dimensions. Unsupported or unexamined versions must be identified; neither container recognition nor a producer version label certifies complete conversion.

Converter completion ends at verified musical recovery, standard output, usable public package/CLI and an accurate report. Viewer import, ISO preparation, native installation, rendering and repagination belong to a later consumer task. The converter must retain the information needed by consumers without depending on their current display coverage.

## Required performer information

These are required families, not permission to stop at one easy example of each. The assessment must inventory the actual source subtypes and combinations and connect each to independent acceptance evidence.

| ID | Family | Required result |
| --- | --- | --- |
| F01 | Score, parts and instruments | Preserve all selected source parts, printed/descriptive names, instrument identity, staff/voice ownership and source changes. Preserve useful work/creator/rights metadata separately. Default whole-score conversion must not silently discard accompaniment. |
| F02 | Pitch and physical position | Preserve written spelling/register, source-established actual sounding pitch/register, transposition, source string/fret choices, string count, alternate tuning and capo semantics. No automatic octave folding or bass-specific pitch normalization. Distinguish percussion, dead notes and notation reference positions from definite sounding pitch. |
| F03 | Time and voices | Preserve rational timing, rests, independent voices, chords, pickups, dots, tuplets, meter changes and simultaneous/cross-staff music. Written durations and elapsed spans remain distinct. |
| F04 | Guitar/bass bends | Preserve the indicated bend, pre-bend, release, amount and meaningful ordering/continuation, including tied and combined cases. Do not turn physical fret position into the altered pitch or reduce a bend to an ordinary attack. |
| F05 | Slides and legato | Preserve slide subtype/direction/endpoints and distinctions between legato and separately attacked notes; preserve hammer-ons/pull-offs, including simultaneous independent relationships. |
| F06 | Harmonics | Preserve encoded natural/artificial and other performer-relevant harmonic types, distinguishing base/fretted pitch, touch information and resulting pitch where the source establishes them. Do not invent missing touch positions. |
| F07 | Attack, sustain and expression | Preserve vibrato, palm mute, let ring, dead/ghost notes, tapping, slap/pop, tremolo picking, brush/arpeggiation, and other encoded performer gestures such as whammy-bar instructions. Preserve relevant combinations and spans, not only isolated flags. |
| F08 | General notation and ornaments | Preserve ties, slurs, articulations, accents, grace notes, trills/ornaments, tremolos, fermatas, breaths, cues, source fingering and instrument-specific performer instructions. |
| F09 | Dynamics and tempo | Preserve performer dynamics, hairpins, tempo words/metronome units, tempo changes and expressive instructions. Do not invent printed instructions from software-only automation. |
| F10 | Structure and navigation | Preserve repeats, repeat counts, alternate endings, D.C./D.S., Coda, Fine and related navigation, rehearsal marks/numbers/letters and meaningful measure references. These are written directions, not a requirement to synthesize playback. |
| F11 | Chords and lyrics | Preserve performer chord symbols and source chord diagrams; preserve lyrics, verse/syllable structure, melismas and attachment to the correct notes/voices. Do not generate diagrams or vocal melody from absent source facts. |
| F12 | Keyboard and pitched instruments | Preserve ordinary multi-staff/voice notation, clefs, transposition, pedal instructions and instrument changes without imposing guitar positions or inferred piano hands. |
| F13 | Percussion | Preserve instrument/kit identity, meaningful noteheads and staff positions, rhythms, articulations and changes. Do not treat a drum's notation position as ordinary pitched music. |
| F14 | Performer presentation and views | Preserve meaningful visibility, cue/size distinctions, source grouping and explicit instructions whose appearance changes interpretation. Preserve source-authored colors, highlights and other annotations through supported standard mechanisms without requiring proof of the author's purpose, under the preservation policy below. Existing selected-part/view support must preserve its own source meaning; it does not merge distinct source views. Exact visual geometry is excluded. |

All families require correct ownership, rational location, relation endpoints and origin. Merely retaining an opaque source blob is not recovery into usable musical facts. Merely recovering a fact is not proof that the MusicXML communicates it. A located warning does not satisfy a missing required feature.

## MusicXML capability and preservation policy

Use MusicXML 4.0's supported representations for required source content. A missing converter implementation is our responsibility; a verified inability of the interchange format to represent a source feature is an agreed output limitation, not a requirement to invent substitute notation or extend MusicXML. Establish the limitation against the standard's available mechanisms: an absent dedicated element or an unimplemented reader/writer path alone does not prove it. Report the exact source feature and limitation. An unresolved capability question remains a verification gap.

Additional source information may optionally be retained for another consumer to extract, using a standards-compatible optional carrier or separate metadata/capture. Such retention must preserve validity and ordinary MusicXML interpretation, must not change unrelated music, and must not require a custom reader to understand the standard musical content. It is useful preservation, not proof that MusicXML expresses the unsupported feature. No custom extension protocol or bespoke text/symbol fallback is required by this milestone.

For source-authored colors, highlights and unfamiliar annotations, assume the person converting the file wants their information carried over. Where MusicXML supports the property, make the smallest preservation change: retain the source value and attachment without inventing intent, musical meaning or behavior. Unknown purpose alone is not a reason to drop it. If no reliable preservation route avoids compromising the standard file or other music, a documented omission may be justified; record the attempted route, affected source information and reason, with optional separate retention where practical. This is not a blanket waiver for unsupported required musical techniques, nor a requirement to reproduce excluded page geometry or unused style defaults.

## Deliberate exclusions

- Synthesizer choice, sample libraries, mixer/effects settings and other settings that affect only software playback are outside performer conversion acceptance. A field that also carries a performer instruction retains that instruction. Instrument identity, transposition and musical techniques are not excluded just because they affect sound. A valid score must not be refused solely because the converter cannot reproduce an excluded playback-only setting.
- Exact native page geometry, font metrics, spacing, line breaks and pagination need not be reproduced. Preserve useful musical meaning and presentation roles; the consumer repaginates.
- Source features that MusicXML 4.0 demonstrably cannot represent are subject to the format-limit policy above. This does not exclude features merely missing from our implementation. MuseScore 1 and 2 are outside the version target.
- New notation systems beyond traditional notation and tablature, audio transcription, optical recognition, new unrelated input families, generated instrumental arrangements and calculated fingering are outside this task.
- Viewer/ISO implementation, installation and human acceptance of that consumer remain separately owned. A converter claim must not imply those have happened.

Useful metadata and exact source/provenance may remain available independently of performer MusicXML. Absence from normal print, or an unfamiliar native field, is not sufficient evidence that something affects only playback or can be excluded.

## Gap disposition and completion

Every observed gap must have an evidence-backed disposition:

1. **Required capability missing or incorrect:** a converter defect or implementation task. It remains open until fixed and verified, or until the owner explicitly changes the contract.
2. **Verification missing:** behavior or source interpretation is not yet established. It is neither a proven defect nor a pass; specify the missing evidence.
3. **Agreed exclusion:** identify the policy above, the source role and why the exclusion applies. For a verified MusicXML limit or justified annotation omission, describe the exact information not expressed; do not label optional capture as musical preservation. A new substantive exclusion beyond these policies needs an owner decision, not a quiet downgrade to a warning.
4. **Malformed source:** record the actual contradiction or invalid relation and its location. Do not invent repairs or remove the file from the assessment denominator. Source repair is separate from faithful conversion.

Partial conversion of required, representable content is **not completion**. Existing APIs and diagnostic outputs are not changed by this documentation task, but `ok: true`, schema validity or an omission report alone cannot certify the contract. A verified MusicXML capability limit is already an agreed exclusion under D41; document it without requiring a new owner decision for every instance. Optional auxiliary retention does not replace a supported standard representation. New scope reductions beyond these policies still require an owner decision.

Completion requires a versioned feature/evidence matrix, no unresolved required musical losses within the claimed scope, resolved acceptance-relevant unknowns, and independent checks of source facts and ordinary MusicXML. Require targeted technique/combination fixtures plus representative complete scores. Corpus outcomes must retain every selected input and use one identified production/checker epoch. Coverage gaps cannot be hidden behind a large success percentage.

Claims must distinguish package/API tests, schema validity, semantic fidelity, independent notation interpretation and downstream consumer acceptance. The last is outside this converter milestone; its absence does not permit an unsupported claim about what the converter emits.

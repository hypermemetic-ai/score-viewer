# MuseScore WebView public entry

Status: implemented on the reviewed task branch on 2026-10-15; merge, private delivery and receiving-platform acceptance remain separate. This adds an asynchronous native MuseScore host to the existing private package for consumers that run the converter inside a WebView with no Node runtime. It adds no musical reader, writer, codec dependency or consumer integration. It supersedes D33's exclusion of a native MuseScore WebView route; the Guitar Pro entry is unchanged.

## Public surface and local assets

The additive import is `score-converter-proof/musescore/webview`. Its functions are `convertMuseScore(bytes, options?)` and `inspectMuseScore(bytes, options?)`. They have the same signatures, options, results and exported declarations as the Node package root: `MuseScoreOptions` with `signal` and `sourceView`, `MuseScoreInspectionOptions`, discriminated `MuseScoreResult` and `MuseScoreInspectionResult`, `SourceViewInfo`, `SourceViewSelection`, `NativeCapture` and the readonly musical model types. Declarations come from the shared `dist/src/musescore-contract.d.ts`.

The export is `{types: './dist/src/webview/musescore.d.ts', import: './dist/webview/musescore.js'}`. The host constructs its Worker with the literal local asset expression:

```js
new Worker(new URL('./musescore.worker.js', import.meta.url), { type: 'module' });
```

Ship `dist/webview/musescore.worker.js` beside the host, with `musescore.worker.js.LEGAL.txt` and `musescore-NOTICE.txt`. `musescore-runtime-graph.json` records the input-source digests, the emitted asset digests and the esbuild metafile. The Worker is one bundled ES module with no runtime imports. It contains no Node, alphaTab, Guitar Pro reader or MuseScore application code. The Guitar Pro assets (`index.js`, `guitar-pro.worker.js`, `NOTICE.txt`, `runtime-graph.json`) are separate and unchanged in behavior. Bundler handling is the same as for the [Guitar Pro entry](guitar-pro-webview-entry.md#public-use-and-exact-package-manifest): a consumer bundler must handle the literal Worker URL or copy the Worker beside its bundled host.

Host prerequisites are the same as for Guitar Pro: dedicated ES-module Workers, typed arrays and TextDecoder/TextEncoder, a monotonic clock, AbortSignal and asynchronous Web Crypto SHA-256. Only the Worker needs native `DecompressionStream('deflate-raw')`, and only for compressed MSCZ members. A missing host prerequisite rejects with TypeError before a request starts. A missing or unadmitted Worker codec returns the located `runtime-codec` refusal for compressed input, while plain MSCX and stored members still convert.

```js
import { inspectMuseScore, convertMuseScore } from 'score-converter-proof/musescore/webview';

const inventory = await inspectMuseScore(bytes, { signal });
if (!inventory.ok) throw new Error(inventory.report.findings.at(-1).message);
// The main score is the default; select another discovered view explicitly.
const sourceView = { id: inventory.views[0].id, inputSha256: inventory.report.inputSha256 };
const result = await convertMuseScore(bytes, { sourceView, signal });
if (!result.ok) throw new Error(result.report.findings.at(-1).message);
consumeMusicXml(result.musicxml, result.report.convertedParts);
```

## Shared source and host boundary

The reader follows the Guitar Pro pattern: one portable core with Node and WebView hosts.

1. `src/adapters/musescore/{capture,convert,inspect}-core.ts` hold the unchanged admission, capture, inventory and conversion logic. They take a `NativeHost` with three capabilities: SHA-256, strict ZIP member capture, and optionally process peak RSS. The existing `capture.ts`, `convert.ts` and `inspect.ts` are now the Node host: `node:crypto`, `node:zlib` and `process.resourceUsage()`. Their exported functions and signatures are unchanged.
2. `src/core/source-zip.ts` now holds only the portable ZIP structure scan and the member length/CRC check. Inflation is the host codec boundary. `source-zip-node.ts` uses zlib, and `source-zip-webview.ts` uses the native stream pump in `src/core/webview-inflate.ts`. That pump was moved unchanged from the Guitar Pro WebView container host and is shared by both Workers. Decoder failures keep one located meaning in both hosts. The WebView output allowance mirrors Node's one-byte overrun, so the CRC/length and could-not-decode refusals agree.
3. Base64 encoding/decoding and the UTF-8 byte count use standard portable helpers in `src/core/portable-bytes.ts`. Native `Uint8Array` base64 is used where available. Timing uses the global monotonic `performance`.
4. `src/webview/musescore.ts` is the public host and `musescore.worker.ts` the dedicated Worker. The protocol is `score-converter-musescore-worker/1`.

Each request snapshots the caller's exact byte range with the same intrinsic mechanics as Node, before any copy or hash. Invalid options, `sourceView` on inspection and malformed selections reject TypeError. Input over 32 MiB rejects RangeError. `trackIds` returns the same `native-scope` refusal as Node. The host binds protocol, operation, request ID, the complete input digest and the requested source scope. It also checks report identity and result shape, then deeply freezes the result. A wrong, late, duplicate or cancelled response yields no useful output. The Worker independently recomputes the portable SHA-256 and refuses an unbound or duplicate request without any result. Cancellation rejects with the original reason, including falsy reasons, terminates the Worker and removes the listener. Every request owns one Worker; consumers own concurrency.

## Parity and resource contract

For the same input and scope, the WebView result equals the Node result in every field except `telemetry`. This covers MusicXML bytes, canonical report and findings, score, native capture, inventory and part mapping. Telemetry is noncanonical in both hosts. The WebView omits `peakRssKiB` because a WebView exposes no process RSS, so the shared `MuseScoreTelemetry.peakRssKiB` type is now optional. Node always supplies it.

The deadline is the shared native Worker budget, currently 20 seconds. The host timer starts before asynchronous hashing, and elapsed time is checked again on response. Input, decoded-archive, XML, event, report, capture, output and message limits are the shared native limits, enforced in the Worker before posting. As with Guitar Pro, a WebView Worker has no configurable heap ceiling, and native decoder queues are opaque. The Node 384 MiB V8 old-generation setting has no WebView equivalent. These are accepted/retained-data and finite-work limits, not allocation ceilings. The Worker computes SHA-256 in portable JavaScript. In Node 26 this costs about 0.5 s per 32 MiB of hashed bytes, which is well inside the deadline but not free for maximum-size archives.

## Exercised package evidence and remaining gates

`npm test` runs `test/musescore-webview.test.ts`. It loads the built public host and executes the built `musescore.worker.js` in a fresh `node:vm` realm that has only WebView globals: no `Buffer`, `process`, `require` or Node modules. The test checks complete Node parity for inspection, default conversion and a selected source view on all 38 original MSCX/MSCZ fixtures. It also checks malformed container and XML refusals, offset snapshots, scope rules, falsy cancellation, a missing native codec and response identity.

[The installed-package browser runner](../scripts/check-webview.mjs) installs the packed archive and builds an ordinary consumer of `score-converter-proof/musescore/webview`. It runs actual module Workers in headless Chromium 151 under a `default-src 'self'` CSP. All 41 MuseScore cases passed with complete Node inventory and result digest parity and identical MusicXML. The cases are 38 fixtures, one selected view, and truncated and CRC-damaged archives. The runner also exercises active cancellation, the missing-codec refusal with plain-MSCX success, and actual Worker refusal of wrong-hash, wrong-operation and duplicate requests. The existing 32 Guitar Pro cases pass unchanged in the same run. Single-run Chromium timings were 35–95 ms per inspection and 48–132 ms per conversion; the first page request took 445 ms including Worker startup. These are local observations, not performance bounds.

`npm run check:package` confirms that the new assets are packed and that consumer declarations compile. The WebView `convertMuseScore`/`inspectMuseScore` types are assignable to the Node functions'.

Receiving-engine acceptance remains consumer and platform work. That includes WebView2, WKWebView and WebKitGTK codec behavior, hosting, CSP, asset delivery and memory on representative scores. The earlier Windows WebView2 raw-DEFLATE capability receipt covers the shared pump, not this entry.

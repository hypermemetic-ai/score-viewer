# Current converter status

Status updated 2026-10-15. The latest corpus epoch is the [range, hidden-Tempo and memory epoch](#range-hidden-tempo-and-memory-epoch-at-b629fe4). Current contract work is being integrated; the implementation ledger records the inspected branch checkpoints and remaining duties. The completed historical corpus assessment below is still pinned to main `6ba334a2309735317f76a074cce4d18c2b9a2067` (PR127). This page is the entry point for current claims. Historical proof records retain their original source/checker epochs; later subset fixes do not rewrite earlier totals.

**Both adapters are implemented and merged. Neither is certified complete against the [performer contract](feature-contract.md).** The private Node API/CLI offers Guitar Pro and MuseScore conversion to plain MusicXML 4.0. Guitar Pro also has a public WebView Worker entry. Compressed output is not implemented by this assessment. The [MuseScore WebView entry](musescore-webview-entry.md) was added after this assessment and is recorded separately.

## Guitar Pro and bass

The GP3–GP8 implementation now recovers traditional pitched, fretted and percussion arrangements, rather than only the earlier fretted slice. The [implementation ledger](implementation-ledger.md) separates delivered capabilities from remaining source semantics and independent verification; the [historical proof](guitar-pro-proof.md) retains its original fixture/producer epochs.

| Contract families | Implemented during contract work | Remaining acceptance work |
| --- | --- | --- |
| F01, F12, F13: arrangements | Actual pitched/percussion identities, source staffs/voices and selected parts; GPIF multistaff/sound/pedal state. | Binary instrument-change fields, percussion technique transitions and full genuine-cohort combinations. |
| F02: pitch, bass, tuning and capo | Separate source tuning/fret/capo and actual pitch roles; reentrant binary 1–7 / GPIF 1–16 strings and raw tuning MIDI 0–127. Bass is not normalized by an invented octave. | GPIF partial capo/beam final integration, 12-string-course/banjo rules, changed-state combinations and genuine bass evidence. |
| F03: rhythm/voices | Rational clocks, source voices, grace/chords, sparse slots and exact source-supported final short bars. | Binary independent-duration bytes, some secondary beam/tuplet/ottava semantics and full combination coverage. |
| F04–F07: techniques | Source bends/whammy, slides, H/P, harmonics, vibrato, mute/ring, tap/slap/pop, dead/ghost notes and related source instructions. | Remaining source subtype gates and simultaneous/tied/grace/tuplet/capo combinations; implementation alone is not family certification. |
| F08–F11: instructions/structure | Source lyrics, literal/structured chord content and diagrams/barres, repeats/endings/navigation, tempo/dynamics and performer instructions. | Enhanced GP3 chord semantics, binary tempo-ramp/Wah and empty-voice annotations, independent source/standard-output coverage. |
| F14: presentation | Shared source-owner/color/visibility/presentation carriers, with source provenance and one musical event stream. | All applicable owner/style/selection combinations, exact standard limits and later performer acceptance. |

A frozen **203-input genuine GP cohort** is now available for the final assessment, separately from original miniatures and synthetic version controls. At the landing epoch for `069a159` and again at the [wrap-up epoch](#wrap-up-epoch-at-758aa90) it converts 202 of 203 inputs and all 202 outputs are MusicXML 4.0 schema-valid; the one refusal is the known out-of-range source pitch format limit. Conversion and schema counts are not repertoire certification. Targeted genuine GP5 percussion checks establish all 61 source MIDI identities 27–87; low unused tunings retain exact source facts and a readable standard instruction when MusicXML's octave range cannot express an individual tuning entry. Actual out-of-range written pitches remain a located standard-format limit, never clipped or octave-folded.

## MuseScore

The accepted milestone targets MuseScore 3 and 4; versions 1 and 2 are excluded (D42). Every 3.x and 4.x producer is in range (D45): behaviour follows the native format family and its per-version defaults, never the exact saving build, and anything that cannot be converted is dropped with a located report. A hidden Tempo is not a performer instruction and keeps only its playback rate (D44). Serializer admission and exercised musical coverage remain separate. D41–D43 clarify standard-format limits and preservation of unfamiliar annotations.

### Fresh PR127 baseline

A new once-only original500 collection uses production and unchanged independent checker source `6ba334a2309735317f76a074cce4d18c2b9a2067`, tree `56672f509bb88b2abab0725194ce253acf4bd635`, on Node **24.0.0**. The additive assessment controller is from `874e856` (integrated as `7bb9e77`); all 353 frozen runtime/checker/controller files are hash-bound. Epoch SHA-256 is `5c084ef95d5072b86ede8d21af255197b1243611bc7652cc9ff47267187cb57e`. Source identities/order and the 500-original denominator are unchanged. Inputs, full envelopes, reports, capture, XML, public facts and operational receipts remain outside Git.

| Fresh outcome | Result |
| --- | --- |
| Public default-main/all-parts calls | 500; once per input, no replay or success filtering |
| Converted | 497 |
| Diagnosed source refusals | 3; the same orphan/backwards-relation identities as the historical run |
| Emitted MusicXML passing offline schema | 497 / 497; zero invalid outputs |
| Reported product timeout/Worker/resource/identity/runtime failures | 0 |
| Harness failures / unattempted inputs | 0 / 0 |

The refusal reports retain one `native-spanner` and two `writer-relation-clock` outcomes. They remain in the denominator, rather than being repaired or filtered out. Both saved-source audit passes completed. The first exposed a collector omission; the corrected, separately pinned result is described below. Neither schema validity nor the audit is a performer-completeness certificate.

Collection takes **692.576 seconds**. Among the 497 converted outputs, API median / upper nearest-rank p95 / maximum are **355.715 / 3,570.408 / 10,210.059 ms**. No response is classified as a product timeout; the maximum is the observed complete public return, including settlement, not a claim that every return finishes within ten wall-clock seconds. Fresh-process pre-retention RSS median / p95 / maximum are **155,152 / 439,116 / 1,052,796 KiB**; cumulative retention peaks are **156,068 / 609,404 / 1,335,952 KiB**. These single-run observations include process/import/preflight/Worker work and do not isolate algorithm cost or establish a memory cap. This is not a causal performance comparison to PR104.

Saved-only schema validation takes **7.390 seconds**, using the frozen official MusicXML 4.0 schemas with existing **lxml 5.2.1 / libxml 2.9.14**. It makes no conversion calls and downloads nothing. The previous proof's validator version is not silently attributed to this run.

### Independent source audit and collector correction

The initial saved audit completed all 497 outputs in **806.273 seconds**, with the three source refusals retained and zero audit failures. It recorded 6,468 candidate occurrences across 242 identities, 58,831 unresolved occurrences across 496, and 83,413 projection-limit occurrences across 219. **Those candidate totals are collector-limited, not a product regression measurement.**

The repository's exported fact collector omitted five event-owner fields present in the retained public score: `grace`, `timeModification`, `printObject`, `sourceStemVisibility` and `sourceHook`. The earlier private collector supplied these fields. Their absence contaminated clock/reference, Trill and edited-owner checks. The complete conversion envelopes allow correction without another conversion call.

Controller correction `0a14530` (integrated as `20375a9`) copies these five fields verbatim with owner/order checks, adds a regression control, and freezes a separate saved-only audit manifest. Its SHA-256 is `9835a16b6635ff81e2e2db266496fdf2bc056ee6c79f42761c22a09905999f32`. Original epoch, collection, facts, raw audit and production/checker code remain unchanged; corrected facts and audit receipts are stored separately. Normal future collection also uses the complete projection. The corrected saved audit completed all **497 outputs**, retained all **three refusals**, and had **zero failures or unattempted inputs**, in **738.272 seconds**. Its summary SHA-256 is `e897c33939e3b2eaf88125bad202e1cb08195e226ed4493aa2e1dba275348f0d`.

| Corrected candidate family | Occurrences / identities | Next action |
| --- | --- | --- |
| Source member/header stem direction | 216 / 34 and 67 / 27; combined 283 / 39 | Check source-authored musical grouping/voice meaning and output interpretation; distinguish it from excluded physical drawing. |
| Metronome boundary words | 47 / 1 | Resolve caption composition and expected standard words at the exact source locations. |
| Performer-direction content/visibility | 6 / 6 | Inspect source ownership/visibility and independently expected performer output. |
| Line-caption size report accounting | 23 / 18 | Reconcile report count, location and message with the checker; this alone does not prove lost notation. |
| Rich-dynamic report accounting | 2 / 1 | Reconcile the located report with the independent expectation. |
| Reference/clock, positive Trill and edited-beam owner candidates | 0 | The initial candidates in these groups depended on missing collected facts, not new conversion behavior. |

There are **361 candidate occurrences across 61 identities**. Identities overlap between families; occurrences are not unique defects. The same saved-envelope comparison removes 6,107 collector-dependent candidate occurrences and 3,559 unknown occurrences without any production change. This controlled collector correction is distinct from comparing historical PR104 totals with current code.

The corrected audit also retains **55,272 unresolved occurrences across 496 identities** and **83,413 projection-limit occurrences across 219**. Its strict source-check flag is positive for one identity; that is not a product completion percentage. The 23 callback streams retain their own evidence and overlap with the aggregate groups.

The remaining ledger needs source-role attribution under the accepted contract:

- Musical verification gaps include beam joining/rest bridges (7,641 occurrences), unqualified default beam membership (2,333), explicit compound beam modes (1,093), and edited membership/timing contexts. Retained physical stem limits do not establish musical group correctness.
- Instruction checks still include metronome glyph/caption composition (2,802), unfamiliar dynamic captions (1,426), and line, Trill, Ottava, lyric and other source duties. These remain verification tasks where expected meaning is unproved, rather than automatically proven loss.
- The raw checker inventories many style/default fields, including unused styles, font sizes/families, colors and frame presentation. Those counts do not establish that a performer-bearing source owner uses the field. Resolve source ownership/use and distinguish required cues/visibility/instructions from excluded typography, geometry or playback. Under D43, preserve source-authored colors/highlights and unfamiliar annotations through supported MusicXML mechanisms even when their purpose is unknown, without inventing meaning. Do not turn every raw default into a release blocker or silently waive authored material as decoration.
- The largest recorded projection-limit group is generated physical beam stems (81,086 occurrences). The checker qualifies that limit only after proving its musical group; unresolved membership and authored instructions remain separate. Other recorded limits likewise need their exact qualified source role, not blanket exclusion by name.

Saved-audit checker time median / upper nearest-rank p95 / maximum is **351.004 / 5,429.615 / 13,293.150 ms** across 497 outputs. Process peak RSS median / p95 / maximum is **193,388 / 755,256 / 1,593,556 KiB**. These are separate research costs, not converter latency or memory figures.

### Earlier consolidated evidence

The latest previously consolidated original500 run is **PR104**, `dd14bd761db0ab73e5ed0524f27361163a86c458`, rather than the PR127 baseline. Its [full record](research/musescore-current-primary-audit.md#current-original500-performer-milestone) distinguishes conversion from independent source duties:

| PR104 outcome | Recorded result |
| --- | --- |
| Once-only public default-main calls | 500 |
| Emitted and schema-valid outputs | 497 |
| Diagnosed malformed-relation refusals | 3 |
| Deadline/invocation failures | 0 |
| Grouping/stem candidate occurrences | 654 across 64 identities; not a defect count |
| Useful unresolved source duties | 55,855 across 496 identities; not a proven-loss count |
| Complete positive source-check flag | 1; this checker flag is stricter than product acceptance, not a completion percentage |

Subsequent merged proofs address grouping, stems, Trill carriers, HairPin requests, Tempo formatting and named dynamics. They do not establish a fresh whole-corpus total. The PR127 proof records 523 passing coupled cases and finite affected-output checks. These are historical verification results, not tests rerun by the initial status inspection.

**The corpus is not a tablature or general-instrument acceptance suite.** Original500 consists principally of songs/keyboard and string quartets, with legacy native 3.01/3.02 originals. Current-version migrations are the same score identities, not 500 more independent pieces. Only four song/guitar inputs have tuning and none has note string/fret positions. Percussion, fretted techniques and rare instrument changes require supplemental cohorts. See [the source-map limitation](research/musescore-source-map.md) and [corpus identity](research/musescore-corpus.md#corpus-identity-and-rights).

The current reader can represent broad staff/voice notation and many source-bound instructions, but its fretted pitch check, narrow harmonic marking and refusal of certain fretted/percussion/transposing instrument changes expose specific assessment/implementation work. No MuseScore feature is excluded merely because original500 does not use it.

## Changes after the assessed baseline

Main subsequently merged PR129 (default stretched-beam topology) and PR130 (qualified rich Dynamic content/family/drawing contexts). Their finite tests and source proofs are retained in [the corpus record](research/musescore-corpus.md). The original500 results above remain pinned to PR127; they have not been restamped or recomputed for these later changes. The previously active topology change is now merged.

The contract implementation has advanced beyond the initial capo/note-color batch:

- GP arrangement and common technique recovery now includes the families in the table above; exact remaining binary/GPIF duties live in the [ledger](implementation-ledger.md).
- Native MuseScore now has clocked capo/instrument/tuning state, concert-view pitch spelling, legacy/modern bend primitives, slides/H/P and timed techniques, structured harmony/diagrams, source image resources, percussion identity and staff-type/visibility timelines. Modern bend variants, H/P display flags, broader TAB presentation and changed-capo combinations remain active work.
- Native text, lyrics and credits retain source-owned fonts, masks, color, size requests and supported alignment/frame facts. Versioned scope/selector precedence, 4.4 field aliases, opaque default alpha and unresolved inline font changes stay explicit. Specialized owner hooks, line-caption bindings, scaled-size authority and independent used-style audits remain required. [Precise text limits](research/musescore-inherited-text-presentation.md) include independent frame border/fill and lyric block anchors unsupported by their MusicXML carriers.
- The [common beam graph](research/native-beam-source-graph.md) replaces isolated source-shape rules. Independent attribution of the frozen 283 candidates found 146 required source stems, 80 physical-layout cases and 57 inactive-header/nonmembers; source reconstruction agreed on all 283 memberships. The 39 containing scores have 135,268 source rows and 70,979 beamed rows with no primary-endpoint or eligible authored-stem disagreement at that supplemental epoch. This does not certify all secondary levels or the whole corpus.
- [Figured-bass recovery and independent audit](research/native-figured-bass.md) preserve source numbers/modifiers/intervals/continuations/brackets/visibility/color. A supplemental genuine score has 84 source objects / 133 rows with all figure-specific duties passing. Unrelated score defects/unknowns remain separate.
- The 47 metronome, six Dynamic and 25 report-accounting candidate causes have independent checker corrections and controls. The historical 361-candidate receipt remains immutable; new results must be measured at a new exact epoch.

### Landing assessment at `069a159`

One frozen production/checker epoch per cohort was prepared at `069a159` and run with fresh bounded per-input processes. Inputs and outputs stay outside Git.

| Cohort | Converted | Not converted | Schema-valid | Source audit |
| --- | --- | --- | --- | --- |
| Native original500 (3.01/3.02) | 496 | 3 adapter refusals (`native-spanner` 1, `writer-relation-clock` 2); 1 worker resource budget on a 26 MB string quartet | 496/496 | 496 audited; candidates below |
| Genuine GP 203 | 202 | 1 exact out-of-range source pitch format limit | 202/202 | Collection facts retained; no native checker applies |

The same three native inputs were refused at the intermediate epoch. One input that timed out there now converts. The resource failure is the same input that timed out earlier.

The frozen native checker reports 19,039 candidate rows in 333 scores, against 43 at the intermediate epoch. The rise follows this branch writing more source text than before: hidden tempo captions, rich dynamic runs, split mixed-format credits, and projected glyph/text point sizes. Sampled rows in every category were compared with the PR127 main outputs. None showed lost visible performer content relative to main:

- 13,160 rows: inline ordinary family on Tempo text after a ScoreText note glyph. Of the 10,446 retained example rows, about 9,450 are on hidden tempos, where the family is deliberately withheld. The rest are on visible tempos whose other formatting is now written; main wrote no formatting there.
- 5,553 rows: tempo-component, rich-dynamic and qualified-text matches. The output carries every expected component plus newly located size and alignment-source facts. The checker's exact comparison predates those facts.
- 153 frame-text, 61 pedal-caption and 6 lyric-visibility rows: the content is written through split credits, words plus pedal glyph, or a visible superscript carrier with a hidden typed lyric.
- 84 line-caption sizing rows reflect the newer scaled-size model, which assigns a point size where the frozen checker expects none. 22 rows expect a `music` family hint on a tempo glyph that main also omitted.

These rows remain **missing verification**, not passes. The independent checker must learn the new presentation facts before it can certify them. This is not a completion declaration.

**Correction (wrap-up epoch below):** the "no lost visible performer content" sentence was too strong. Comparing with main does not show what the source says. Against the source, three kinds of visible content were still lost at `069a159`:

- A framed Dynamic mixing a sign with prose, such as a boxed `p dolce`, was flattened.
- Some qualified Tempo captions lost a superscript or an inline size change.
- Visible Tempo marks from producers other than 3.6.2 dropped an explicit font family after the note glyph.

All three are fixed in the [wrap-up epoch](#wrap-up-epoch-at-758aa90).

The full regression suite passes 1272/1272 at the landing commit, and the package, webview, vendor and offline MusicXML schema (736 outputs) checks pass.

Earlier passing counts (562 regression, 736 schema and related finite checks) belong to the first follow-up epoch. They remain historical evidence and cannot certify the substantially expanded implementation. No whole feature family is declared complete from a conversion or schema count.

### Wrap-up epoch at `758aa90`

The wrap-up branch follows the landing merge. It fixes the losses noted above, extends the checker and adds a few smaller performer features:

- **Guitar Pro:** different source dynamics on individual chord notes are kept on those notes.
- **MuseScore ornaments:** slashed and vertical turns, Haydn, schleifer and the long/approach/departure mordents now map to MusicXML ornaments. Other canonical ornament glyphs use `other-ornament` with the exact SMuFL name; unknown names are still refused.
- **MuseScore text:**
  - Style-saved pedal captions keep their emphasis and glyph runs.
  - Framed rich Dynamics keep their ordered runs. The shared-frame limit of mixed-format words (W3C MusicXML issue 519) is reported, and a hidden typed dynamic is kept.
  - Qualified Tempo captions keep a plain superscript and inline size changes.
  - Inherited style origins are settled before inline runs copy the owner size.
  - Visible Tempo marks keep explicit ordinary font faces for every producer, including beside superscripts.
- **Checker:**
  - Text sizes and script projections are derived independently from source.
  - Harmony naming fields are checked.
  - Line captions are scaled from source spatium.
  - Run sizes and SystemText system scope are compared separately.
  - Framed named signs and exact hidden captions follow the product's documented carriers.
- **Tests:** corpus-runner tests remove their temporary roots.

| Cohort | Converted | Not converted | Schema-valid | Source audit |
| --- | --- | --- | --- | --- |
| Native original500 (3.01/3.02) | 496 | 3 adapter refusals (`native-spanner` 1, `writer-relation-clock` 2); 1 worker resource budget on the 26 MB string quartet | 496/496 | 496 audited; 9,885 candidate rows in 140 scores |
| Genuine GP 203 | 202 | 1 exact out-of-range source pitch format limit | 202/202 | No native checker applies |

The same inputs fail as at the landing epoch. Candidate rows fall from 19,039 to 9,885:

- 9,798 rows in 138 scores are explicit font faces on **hidden** Tempo marks. Every retained example row is on a hidden Tempo (8,249 rows). Uncapped recounts of the 20 scores that reach the per-file example limit also find no visible rows.
- 87 rows in five scores belong to the named open items below: `lc6137985` (58 rows), `lc6243836` (18), `lc6621051` (7), `lc6620571` (2) and `sq7354505` (2).

These rows remain **missing verification** or owner decisions, not passes. This is not a completion declaration.

The regression suite passes 1290/1290 at `758aa90`. The 266 research tests and the six corpus-runner tests pass. The package, webview, vendor and offline MusicXML schema (736 outputs) checks pass.

Remaining open items at that epoch (see the [next epoch](#range-hidden-tempo-and-memory-epoch-at-b629fe4) for the current list):

- **Hidden Tempo family (owner question).** A hidden Tempo's explicit face is not projected; its printed carrier stays hidden. Whether hidden instructions should carry typography for an editor or show-invisible view is a source-role decision for the owner.
- **Empty `<sup/>` before private glyphs** (`lc6243836`). This caption stays outside the qualified Tempo script profile and keeps its located limits.
- **Framed superscript.** A framed white StaffText superscript is flattened into one enclosed words element under the issue-519 policy, with its runs reported (`lc6620571`).
- **3.01 SystemText size** (`lc6137985`). Its older-producer SystemText sizes are reported rather than projected.
- **Private-glyph run alignment** (`sq7354505`). One trailing-space run is aligned differently by the checker and the product inside an already unexamined private-glyph caption.
- **Lyric visibility checker limit** (`lc6621051`). The checker does not yet model the hidden typed lyric with a visible carrier.
- **Large-score memory.** The 26 MB quartet `sq9631717` always exceeds the 384 MiB worker heap. The 24 MB `sq8811375` sits at that edge: it converts at this epoch but failed at an intermediate run. The older runtime also fails it in a direct worker test, so this is not a regression. Raising the budget is a resource-policy decision.
- **Other producer families.** Qualified text profiles still centre on producer 3.6.2; other producers keep located limits where their behaviour has not been examined.

### Range, hidden-Tempo and memory epoch at `b629fe4`

This branch settles three open items from the wrap-up epoch:

- **Hidden Tempo ([D44](decisions.md#accepted-direction)).** A hidden Tempo is not a performer instruction. Its caption, metronome display and typography are no longer carried. Its rate stays as one measure-level `<sound tempo>`, so playback timing is unchanged, and each occurrence is reported as `native-hidden-tempo-playback-only`. This removes the 9,798 hidden-Tempo rows.
- **Producer range ([D45](decisions.md#accepted-direction)).** Every MuseScore 3.x and 4.x producer is in range, and format `4.30` is now admitted. Behaviour follows the native format family and its per-version defaults, never the build or revision that saved the file. There are three text loader families: legacy `3.01`/`3.02`, paired `4.00`–`4.60` and current `4.70`. A construct that cannot be interpreted for its format is dropped with a located finding naming what was lost. Versions 1 and 2 stay excluded (D42).
- **Memory.** About 55% of the 26 MB quartet `sq9631717` is embedded part views. These are linked part scores that repeat the primary music. Whole-score conversion reads only their headers, staff links, measure counts and frames. Their voice subtrees are now counted for the construct inventory without being kept in memory. It now converts in about 6 seconds within the unchanged 384 MiB worker heap, and so does the 24 MB `sq8811375` that previously sat at the limit. Output, findings and construct counts are unchanged.
- **Tempo Bold base.** Text before the first inline emphasis token of an ordinary Tempo caption now keeps the Tempo style's Bold base, because MuseScore's text cursor starts from that style. Before this fix, it was written as normal weight.
- **Checker.** The independent corpus checker now keys its MuseScore 3 source roles on the same format families instead of exact producer builds. It also composes Tempo inline tokens against the native Bold base.

| Cohort | Converted | Not converted | Schema-valid | Source audit |
| --- | --- | --- | --- | --- |
| Native original500 (3.01/3.02) | 497 | 3 adapter refusals (`native-spanner` 1, `writer-relation-clock` 2); no resource failure | 497/497 | 497 audited; 88 candidate rows in 5 scores |
| Genuine GP 203 (at `00c1fcc`; no Guitar Pro source changed since) | 202 | 1 exact out-of-range source pitch format limit | 202/202 | No native checker applies |

Epoch SHA-256 is `623bb1f9340bf66ff4f84d1e9d427953b055d7297d5ac24a6435879be2138f7f`. All 88 candidate rows belong to the named open items below: `lc6137985` (58 rows), `lc6243836` (18), `lc6621051` (7), `sq7354505` (3) and `lc6620571` (2). These rows remain **missing verification** or owner decisions, not passes. This is not a completion declaration.

Three intermediate epochs are superseded. The `00c1fcc` epoch had the same conversion results but 676 candidate rows; 527 of them came from checker roles still gated on producer builds. A main-build comparison confirmed that these were checker staleness, not product regressions. The `9eba3e9` epoch had 91 rows in six scores. Its three new `sq7330550` rows were the checker missing the Tempo Bold base that the product had just started applying. The `5bedaf3` checker added that base but also demanded a native-default provenance fact on captions whose words were already correct, giving 31 extra rows in 13 scores (119 in total). It now checks such an unstated base through its effect on every run.

The regression suite passes 1292/1292. The 269 research tests and the six corpus-runner tests pass. The package, webview, vendor and offline MusicXML schema (736 outputs) checks pass.

Remaining open items:

- **Empty `<sup/>` before private glyphs** (`lc6243836`). This caption stays outside the qualified Tempo script profile and keeps its located limits.
- **Framed superscript** (`lc6620571`). A framed white StaffText superscript is flattened into one enclosed words element under the issue-519 policy, with its runs reported.
- **3.01 SystemText size** (`lc6137985`). Its SystemText sizes are reported rather than projected.
- **Run alignment** (`sq7354505`). Inside an already unexamined private-glyph SystemText caption, the checker and the product align one trailing-space run's size differently. Separately, the checker expects one metronome-caption suffix label where the product writes `)` and the following words as two visible words elements.
- **Metronome caption emphasis.** A visible metronome caption's inline-emphasis prefix (for example `<i>Allegro </i>` before the note glyph) is written without its emphasis, reported as `native-tempo-emphasis-context`. No corpus row isolates this; it was found while updating a hand-authored checker fixture.
- **Lyric visibility checker limit** (`lc6621051`). The checker does not yet model the hidden typed lyric with a visible carrier.

## Assessment and cleanup delivery

The current cleanup establishes the accepted contract and one status/backlog entry point, plus a [reusable assessment runner](research/corpus-assessment-runner.md). It builds and freezes exact source rather than reusing an active checkout's compiled output. Its four controls cover actual public success/refusal, saved schema/source audit, failure classification, source-capture independence, identity tampering and replay prevention. All four pass, including the collector correction and saved-only provenance/replay controls. The frozen baseline's full existing regression suite passes **523/523** on Node 24. An initial test invocation used the wrong working directory and failed three CLI module lookups; the corrected run passes, and both logs remain retained separately.

The fresh immutable-baseline collection and schema results are recorded above; the initial source audit and collector correction are distinguished explicitly. The old PR104 preparation has hardcoded hashes and file counts and cannot honestly be rerun as a current-main assessment unchanged. The runner now handles public MSCX/MSCZ conversion, schema validation and independent bounded ZIP source selection/extraction. Container controls cover root selection, malformed/ambiguous archives and source binding without borrowing converter selection. That closes the container-audit route, not the musical duties of every decoded source. The runner also supports the separate GP cohort collection; its final genuine assessment remains pending.

Reader helpers now separate text/style, source beam graph, staff type, harmony and technique responsibilities. Native regression suites are split by musical family with visible source fixtures; independent beam, figured-bass and container/checker modules retain independent expectations. Further extraction remains subordinate to preserving actual source/default semantics and required coverage. The current GP module boundaries are useful; feature coverage takes priority over a rewrite.

The initial worktree audit found 122 registered worktrees: 121 clean and one then-active dirty MuseScore topology checkout. Most correspond to merged history, including squash merges; they are not 122 undelivered changes. That topology change has since merged. Other worktrees and proof artifacts remain intact; this historical inventory is not a current count or authorization to delete their contents.

## Consumer and release boundary

The [bass handoff](bass-display-handoff.md) records historical ISO/Viewer source merges and pending native delivery at that checkpoint. It is not a current audit of those repositories or installations. The owner will arrange Viewer integration separately. Public publication, final product licensing and distribution approval remain separate decisions.

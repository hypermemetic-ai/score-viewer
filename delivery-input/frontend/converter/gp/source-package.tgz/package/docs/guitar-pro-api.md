# Private Guitar Pro converter contract

The public Node entry is `score-converter-proof`, an ESM private package requiring Node24 or later. It exposes `convertGuitarPro`, `inspectGuitarPro`, options/results/mapping/inspection types, Finding/Location, the fretted model and named capture types. One converter produces ordinary MusicXML4.0 with complete admitted tuning/string/fret facts. Consumers own importing, storing and presenting that output; no display profile or consumer adapter is required.

Build and pack locally with `npm run build` and `npm pack --ignore-scripts`. Install the resulting private archive into a Node project with `npm install /path/to/score-converter-proof-0.0.0.tgz`. `npm run check:package` exercises the packed entry, declarations and CLI from an isolated temporary installation. The archive includes the exact separately licensed alphaTab source, patches/inventory/notices and original converter source; it excludes musical fixtures, test output and temporary research material. Private packaging does not publish to npm or choose a project-wide license.

```js
import { readFile } from 'node:fs/promises';
import { inspectGuitarPro, convertGuitarPro } from 'score-converter-proof';

const bytes = await readFile('local-score.gp');
const inventory = await inspectGuitarPro(bytes);
if (!inventory.ok) throw new Error(inventory.report.findings.at(-1).message);
const sourceId = inventory.tracks[0].sourceId; // A source identity, not a label or output ID.
const result = await convertGuitarPro(bytes, { trackIds: [sourceId] });
if (!result.ok) throw new Error(result.report.findings.at(-1).message);
console.log(result.musicxml, result.report.convertedParts);
```

## Public calls and failure behavior

`inspectGuitarPro(bytes, {signal?})` returns a deeply frozen compact inventory after bounded container/structure/reference discovery. `ok` means useful structural discovery succeeded. Observed source names, family/reference/program facts and their provenance, complete tuning/order/count/locations and `metadataEligibility: eligible|ineligible|unknown` do not certify musical constructs. An unsupported known instrument can be listed; malformed or ambiguous source structure returns `ok:false` without tracks. Inspection produces no MusicXML, raw capture or converted part mapping.

`convertGuitarPro(bytes, {signal?, trackIds?})` independently admits selected musical graphs. Omitted trackIds requests all tracks. IDs must be unique existing source IDs: binary IDs are zero-based encoded track ordinals; GPIF IDs are encoded Track IDs. Selected output retains source order regardless of argument order; `Part.id` remains the source ID. Excluded tracks retain reference validation and are explicitly reported; binary globally effective tempo in an excluded track remains global.

Inputs are Uint8Array views. The exact byteOffset/byteLength range and requested IDs are snapshotted before the first yield, so later caller mutation cannot change the request. Over8MiB rejects **RangeError before snapshot, hash, worker or decoding**. Invalid JavaScript arguments reject TypeError. Cancellation rejects the original AbortSignal reason (including null/false/0), terminates the worker and delivers no late output. A signal registration race is rechecked. A decoder/feature/work refusal on an admitted-size request returns deeply frozen `ok:false` with a truthful whole-input SHA-256 and located report; it has no XML, score/capture or converted mapping. The five-second deadline/worker failure returns the same source-bound refusal shape. Each caller invocation owns one worker; consumers control concurrency.

Both public hosts use captured TypedArray intrinsic brand/buffer/offset/length getters and copying, so a caller's iterator, shadow bounds, species or methods cannot substitute bytes or bypass the true input cap. Genuine Buffer and Uint8Array subclasses, including nonzero offsets, are accepted. Byte proxies, detached views and shared backing reject TypeError; shared memory cannot guarantee a coherent copy while another agent writes it. A non-shared resizable buffer is accepted when the captured range remains available. Selection snapshots at most 32 own data entries, without calling some/slice/iteration; holes, inherited entries and accessors reject TypeError. This is not a promise that arbitrary options getters or array Proxy traps are side-effect-free.

## Successful identities and facts

A success contains `musicxml`, source-bound `report`, a `scoreKind`-discriminated `score` (see [arrangement results](#arrangement-results-and-consumer-upgrade-notes)), immutable original `inputSource` and available GPIF/container/binary/GPX captures plus pre-/post-reader occurrences. `report` has schema, inputSha256, adapter build, encoding/feature profile, requestedScope and preserved/inferred/omitted/excluded/blocking findings. Profile identifies the attempted/admitted rules; only successful conversion establishes admitted instrument authority.

Success alone adds the immutable bounded mapping:

```ts
interface ConvertedPart {
  readonly sourceTrackId: string;
  readonly sourceLocation: Readonly<Location>;
  readonly musicxmlPartId: string;
  readonly admission: {
    readonly instrumentFamily: 'guitar' | 'bass' | 'keyboard' | 'vocal' | 'percussion' | 'other';
    readonly profile: string;
    readonly evidenceFindingIndices: readonly number[];
  };
}
```

`report.convertedParts` is derived from the writer's actual assignment, with one source track per actual XML part. Evidence indices address located family/register/physical admission findings in that same frozen report. The enclosing inputSha256/adapter/profile/requestedScope bind mapping to the successful input. Selected/reordered/mixed-family cases are checked; excluded tracks, inspection and every later writer/result-budget refusal expose no mapping. Names, tuning count and a guitar/bass-looking program with an unknown reference never manufacture authority.

Written pitch/spelling/register, physical sounding MIDI, rational clocks, voices, staff and instrument remain distinct. Source positions are preserved even when the same pitch has another valid position. Empty declared secondary voices create no artificial rests/attacks. Written and sounding MIDI satisfy the explicit transpose relationship; binary/GP6 generated register/spelling rules are located inferences, while binary tie-placeholder recovery is source encoding semantics. Generated hidden alternate staff/tuning spelling are reported separately from source facts. No playing hand/finger solver is supplied.

Full capo is admitted for the bounded GP3–GP8 profiles. Inspection adds optional `track.capo: { fret, sourceLocation }`; successful model parts add optional `capo: { fret, source }`. Both retain the located encoded integer from 0 through 24, including explicit zero. Absent source capo remains absent. Tuning remains the non-capo open-string pitches, and source frets remain relative to the capo: ordinary sounding MIDI equals tuning plus full capo plus fret. Written octave transpose is applied separately. The standard MusicXML TAB carrier carries `<capo>` after its unchanged `staff-tuning` entries. Active partial capo and unsupported techniques still refuse; this increment does not establish general bend/harmonic support or independent app display acceptance.

## Runtime and safety boundary

Node worker caps: input8MiB, wall5s, V8 old generation96MiB, young16MiB, stack4MiB. These are not whole-process native RAM caps. Container budgets:32members,4MiB/member,8MiB decoded,total compression ratio100. GPX validates declared sizes/sectors/backreferences/progress during expansion. ZIP verifies safe identity/path/spans/CRC, exact actual decoded sizes and complete compressed input. XML lexical/value/text/path bounds apply before tree growth. Maximum32tracks,512measures,20000expanded events/notes,200000binary capture records; capture24MiB, report8MiB, output/result32MiB; exact MusicXML divisions≤65536. Exceeding a limit refuses rather than rounds or silently drops facts. See [proof](guitar-pro-proof.md) for precise profile coverage and producer gaps.

CLI: `score-converter input-file new-output-directory [--tracks=source-id,...]`. It atomically publishes `score.musicxml`, `report.json`, `source-capture.json` on success; admitted-input refusal publishes only report.json. An existing destination refuses. Argument/I/O/pre-admission errors exit without a result directory. Exit0success,1refusal/failure,2usage. No input execution/network upload/extraction occurs. Captures can contain the caller's private music.

The additive GP-only asynchronous [WebView entry](guitar-pro-webview-entry.md) is `score-converter-proof/guitar-pro/webview`, with the same public declarations and an adjacent bundled local module Worker. Its native DecompressionStream host reuses the same musical/container admission; runtime prerequisites, pre-hash timeout rejection and opaque allocation limits are explicit. Installed-package Chromium/Vite checks are distinct from consumer-owned actual WebView hosting/CSP/platform acceptance. No new runtime codec dependency or native bridge is selected.

## Arrangement results and consumer upgrade notes

Recorded 2026-10-15 from the code at `ef1a0a3`, for consumers upgrading from the earlier `aea081ed` package. The `convertGuitarPro`/`inspectGuitarPro` signatures, the WebView protocol, Worker request validation, the package export, the adapter string, report schema, `requestedScope`, and the `ConvertedPart` keys `{sourceTrackId, sourceLocation, musicxmlPartId, admission: {instrumentFamily, profile, evidenceFindingIndices}}` are unchanged. The result contract widened as follows. No field was removed or renamed.

- Success has a required `scoreKind: 'fretted' | 'arrangement'`. `fretted` keeps a fretted `NeutralScore`. `arrangement` has a `MusicalScore` whose parts may lack `tuning` and `midiProgram` and may contain `kind: 'unpitched'` notes. Branch on `scoreKind` before reading tuning, program or string/fret data.
- `admission.instrumentFamily` is `'guitar' | 'bass' | 'keyboard' | 'vocal' | 'percussion' | 'other'`. Non-guitar/bass and mixed files that were previously refused can convert as arrangements. Profiles can end in `-arrangement/0`, for example `gp7-arrangement/0`, alongside `-guitar/`, `-bass/` and `-fretted/`.
- `instrument-admitted` keeps its code, `preserved` disposition and fact keys. Its message text changed, and `fact.midiProgram` may be `undefined`. Parts without tuning have no `tuning-export`, `tuning-spelling`, `tuning-carrier-staff` or `hidden-physical-guidance` findings. `tuning-export` `fact.sourceOrder` is now `'source-string-order'`.
- Up to 32 tracks are admitted, previously 8. The track-ID TypeError message still says "1–8".
- Inspection `SourceTrackInfo` additively gains optional `instrument.family`, `capo` and `staves[]` (with per-staff `tuning`/`capo`). A track with several tunings now has per-staff tuning and no `track.tuning`. Non-fretted tracks carry no tuning or capo.
- Model types gain optional fields such as part `capo`/`staves` and `Location.staff`. Dead strokes appear as occurrence `kind: 'dead'`.

## Performer technique fields (2026-10-14 implementation increment)

Source note facts may additionally contain exact rational bend curves, harmonic roles, source gestures/fingerings, standalone slides and explicit trill targets. Beat whammy curves remain separate from note bends. Connected slides and mute/ring instruction spans use located relations. Harmonic result pitches derived from an established source node rule have inferred pitch origin; a missing definite result remains `null`, never an invented octave. See the dated [proof checkpoint](guitar-pro-proof.md#performer-techniques-implementation-checkpoint-2026-10-14) for finite support and remaining work.

Binary structural recovery adds located credits/metadata, navigation/endings/rhythmic feel, lyrics and independent chord diagram instructions. Literal chord captions remain distinct from analyzed harmony; all-muted diagrams retain explicit string instructions without invented played positions. The dated proof records the exercised encoding branches and remaining work.

Binary empty string slots do not acquire fabricated main notes. An explicit dead stroke with source fret−1 has no physical fret or sounding pitch; its additive occurrence `kind: 'dead'` retains `rawFret: -1` and any applicable string separately from pitched/fretted occurrences. See [empty-slot and dead-stroke semantics](research/guitar-pro-empty-note-slots.md).

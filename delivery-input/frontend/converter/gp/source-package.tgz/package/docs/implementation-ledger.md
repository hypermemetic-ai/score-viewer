# Performer contract implementation and evidence ledger

Ledger version **2026-10-14.5**. This reconciles the implementation integrated
through `742a422`, with delivered but not yet integrated checkpoints identified
separately below. The
PR127 corpus epoch remains unchanged; the landing assessment at `069a159` and the wrap-up epoch at `758aa90` are recorded in [current status](current-status.md#wrap-up-epoch-at-758aa90). This is a
versioned breakdown of the accepted [F01–F14 contract](feature-contract.md), not
a completion declaration. [Current status](current-status.md) owns assessment
claims and [the completion plan](completion-plan.md) owns delivery sequencing.
Later production commits must update their source and verification evidence before any row is closed.
The finite remaining-duty table at the end is the actionable queue. Coverage axes
require representative positive and discriminating controls for each source rule,
not an unlimited Cartesian product of all notation features.

**No whole feature family is certified complete for either adapter.** A working
subtype, passing schema, successful conversion, retained raw source, omission
report, or lack of a feature in original500 cannot close the containing family.
The owner requires guitar, bass and all notated parts, independently of the
limited corpus. Viewer integration, a third notation system, playback-only
synthesis/mixing and exact native page geometry remain outside this milestone.

## Reading and updating the matrix

Each row separates **I** (bounded implementation evidence), **M** (known missing
required capability), and **V** (verification still needed). They are not
percentages. A row may contain all three. An **X** exclusion requires a specific
contract basis and evidence that it applies to the actual source role; absence
of code is never that evidence. A **S** malformed-source disposition must bind
the contradictory original facts and remain in its input denominator.

To close a row, record its production commit, native version/producer and source
subtype, source-owned expected facts, independent standard output expectations,
original positive and discriminating mutation controls, schema result, and
representative real producer evidence. Record combinations explicitly. Visual
readability and performer acceptance are separate evidence, not consequences of
schema validity. Preserve source metadata, source provenance, selected views,
written and actual pitch, rational clocks and stable public API behavior while
adding capabilities. Unrecognized versions, valid settings and musical features
must be classified instead of silently admitted or dropped.

The standard mechanisms below are candidates supported by the repository's
[pinned MusicXML 4.0 schema](../third_party/musicxml-4.0/musicxml.xsd), not proof
that every native subtype has an exact standard equivalent. D41 accepts a
*verified* format limit. Prove that limit at the relevant semantic subtype and
keep any independently required representable content; optional auxiliary source
retention does not replace a standard notation carrier.

## Requirement, subtype and combination matrix

GP evidence anchors: [profile](../src/adapters/guitar-pro/profile.ts),
[binary admission](../src/adapters/guitar-pro/binary.ts),
[recovery](../src/adapters/guitar-pro/recover.ts),
[genuine GP profiles](../src/adapters/guitar-pro/gp8.ts),
[family tests](../test/gp-family.test.ts), [GP8 tests](../test/gp8.test.ts),
[tuning tests](../test/tuning.test.ts), [capo tests](../test/capo.test.ts), and
[the proof's producer/fixture distinctions](guitar-pro-proof.md).

MS evidence anchors: [native reader](../src/adapters/musescore/read.ts),
[text qualification](../src/adapters/musescore/text.ts),
[core musical tests](../test/musescore.test.ts),
[text tests](../test/musescore-text-directions.test.ts),
[view tests](../test/musescore-views.test.ts),
[rich caption contexts](../test/musescore-rich-content-contexts.test.ts),
[notehead colors](../test/musescore-note-colors.test.ts), and
[native fixture provenance](../test/fixtures/musescore/README.md).
The [shared model](../src/core/model.ts) and
[writer](../src/core/musicxml.ts) are reuse anchors; their primitives alone do
not prove either adapter recovers a source feature.

| ID | Required subtype / combinations | Guitar Pro at inspected baseline | MuseScore at inspected baseline | Standard mechanism and next acceptance evidence |
| --- | --- | --- | --- | --- |
| F01.a | Default whole arrangement; all selected parts, names and identity | I GP3–8 pitched, fretted and percussion arrangement recovery with source staff/voice ownership and selection. I genuine GPIF 146 traversal, including a 21-track GP6 arrangement; the fixed GP 203 intermediate epoch converts 202, with one standard pitch-range limit. V final unified epoch. | I native multi-part and percussion/instrument state. V mixed-arrangement and source-view combinations. | `score-part`, `score-instrument`, part/staff ownership; guitar+bass+keyboard+voice+percussion in one independent fixture, default versus explicit selection. |
| F01.b | Work/creator/rights metadata; instrument changes | I source metadata and GPIF sound automation. I binary timed source program contexts and literal tempo/Wah instructions (`d25b888`); these do not invent physical instrument replacement from a synthesis patch. | I part-wide clocked instrument/transposition/tuning changes and source metadata. I changing percussion/concert-view state integrated; V independent instrument-state audit named below. | `work`, `identification`, instrument definitions and note `instrument`; preserve source strings and clocked changes, no synthetic identity. |
| F02.a | Written spelling/register versus actual sounding pitch; bass octaves | I actual source pitches, capo and harmonic roles without bass normalization. I source-key spelling and actual bass identities in genuine GPIF studies; combined original pitch/capo/technique controls. V final fixed-cohort source comparison. | I source/concert-view TPC and actual instrument intervals, capo/tuning timelines. V bass and combined view/technique coverage. | `pitch`, `transpose`, clef octave and tuning; independently establish source actual pitch, with no bass-specific octave normalization. |
| F02.b | Four through eight strings and wider source instruments; alternate/reentrant tuning, string/fret choices | I binary 1–7 and GPIF 1–16 strings, reentrant order, MIDI 0–127 source tuning. X documented binary twelve-string sound simulation does not create extra encoded courses. M binary short-string banjo physical fret rule remains source qualification work. | I source tuning and instrument changes. I timed tuning/capo masks and source string ownership; V independent StringData state audit named below. | `staff-details`, `staff-tuning`, technical `string`/`fret`; preserve exact source positions rather than calculate replacement fingering. |
| F02.c | Full, partial and changing capo; capo plus transposition/techniques | I full static GP3–8 capo with separate raw tuning/frets. I GPIF partial capo with two authored GP7.5 originals (76/60 notes), separate mask/orientation and open-string rules. Source GPIF capo/tuning are static; no timed change is invented. | I legacy staff-text and modern full/partial capo with timed state. I ignored-string masks and applied-string sets validated over StringData timelines, including rest-only scopes. V final source comparison of each selected view. | Standard `capo` plus tuning and source physical facts; apply displacement once and distinguish unsupported partial-capability limits from absent implementation. |
| F03.a | Rational time, independent voices, chords/rests, pickups/dots, tuplets/meter changes | I source rational voices/chords/rests/tuplets/pickups, sparse GPIF slots and exact final short-bar source extents. I GP3/4 independent note durations, derived serialization lanes, held-note ties and exact cross-bar bend fragments (`3df27af`); source tuplet bracket/ottava facts remain separate from playback. | I rational source clocks and broad tuplets. V unqualified timing, multi-measure-rest and courtesy/custom meter duties. | `duration`, `backup`/`forward`, voice/staff, `time-modification`/tuplet; independent attack/release and written-duration expectations. |
| F03.b | Simultaneous/cross-staff music and source grouping | I actual multistaff arrangements. I source GPIF/binary beam groups, authored stems and source secondary cuts integrated. V final independent cohort expectations; unknown binary display flags retain qualification. | I common source beam graph, rest bridges, moved members, source modes and cross-measure continuation. I independent graph checks over 135,268 source rows in 39 historical candidate scores; current final cohort must exercise secondary cuts/hooks and source membership controls. | Staff movement, beams/hooks, voice ownership; complete neighborhood checks, tied/grace/tuplet/rest and cross-measure combinations. |
| F04.a | Bend amount, pre-bend, release and ordered path | I ordered source bend/whammy curves, pre-bend/release and independent physical pitch roles. V final fixed-cohort source/output assessment; combined original controls are documented in the GPIF review. | I legacy curves and all eight modern bend forms, independent finger/bar roles, hold/predecessor graph, slack and vibrato source facts; original controls in musescore-modern-bend.test.ts. V genuine producer subtype coverage remains distinct from hand-authored controls. | `bend`/`bend-alter`/`pre-bend`/`release`; prove physical base fret and independently altered pitch roles, fractional amounts and source ordering. |
| F04.b | Bend continuations/ties, multiple notes, simultaneous and combined techniques | I continuous legato curve carriers and source endpoint ownership. V final fixed-cohort assessment against the independently tested ownership rules. | I note endpoint ownership separate from attack/tie. I modern subtype/hold graph and TAB top-component ownership; unresolved system-dependent display cannot choose a competing hold owner. | Determine standard representation per continuation/path; discriminate attacks versus sustained changes and multiple bent strings. |
| F05.a | Shift/legato slide, direction, endpoints; entering/leaving slides | I shift/legato/open-ended slides with actual source endpoints, including same-fret cases. V source version/combination breadth. | I Glissando and source note-owned ChordLine slides with form/color/visibility. V source subtype/combination coverage. | `slide` versus `glissando`, endpoint numbers/line shape; don't infer one from another or invent missing endpoints. |
| F05.b | Hammer-on/pull-off; independent simultaneous pairs, tie/slide combinations | I source H/P and continuous legato relations. V independent simultaneous pairs and source combinations. | I source HammerOnPullOff adjacent component rules. I source view/showAll/uppercase flags and authored H/P text integrated; independent numbered transition ownership remains in original controls. | `hammer-on`/`pull-off`, separate numbered endpoints; mixed techniques cannot alias one pair. |
| F06.a | Natural/artificial/tapped/pinch and other encoded harmonics | I source harmonic types/tuples and verified node-derived base/touch/result roles; no arbitrary octave addition. V final cohort against the separately identified harmonic type/node rules. | I generic harmonic sign and timed HarmonicMark source instructions. V exact broader source harmonic type/base/touch/result facts. | `harmonic` natural/artificial, base/touch/sounding pitch indicators; retain absent versus established source facts. |
| F06.b | Harmonic plus capo/alternate tuning/bend/slide/tie; bass register | I distinct pitch/technique primitives and combination controls. V final cohort; original combined pitch-role controls and genuine bass identities remain separately recorded. | I separate source pitch/capo/technique facts. V independent combined-family and bass evidence. | Separate physical, written and sounding roles with independent per-note expectations; no invented touch point or octave correction. |
| F07.a | Dead/ghost notes, vibrato, palm mute and let ring spans | I dead/ghost, vibrato, palm-mute/let-ring and source spans; dead grace has no fabricated fret. V final fixed-cohort source/output assessment. | I dead/ghost and timed palm-mute/let-ring/vibrato instructions. V complete view/owner/subtype combinations. | Noteheads/parentheses, technical instructions and suitable standard spans; dead pitch is not a definite sounding pitch. |
| F07.b | Tap/slap/pop, tremolo picking, brush/arpeggio, whammy | I tap/slap/pop, tremolo/trill/pick strokes, source brush/arpeggio and whammy curves. I ordinary percussion identity and techniques; delivered `c1779c4` adds unpitched slide/harmonic/trill/H/P and grace-transition instructions without fabricated definite pitch. Integration/final proof pending for that checkpoint. | I technical gestures, arpeggios, tremolo and whammy. V source stroke/ornament neighborhoods and modern bend variants. | Technical/ornament/arpeggiate/other standard instructions; preserve direction, string subset, rate, span and independent note ownership. |
| F07.c | Distinguish written techniques from automatic playback strum/accent/let-ring | I source-qualified engine-only settings separated from printed techniques. I GPIF source-role review and binary mixer/12-string simulation qualification; remaining unfamiliar binary display operands stay specific verification duties. | I finite documented playback roles and disabled swing. V remaining source-role attribution; a field name alone is not an exclusion. | No invented notated attacks. Excluded playback-only settings cannot alone block otherwise valid performer content. |
| F08.a | Ties/slurs, grace placement, ornaments/trills, tremolo, accents/articulations | I ties, grace notes/chords, ornaments/trills/tremolo/accents and qualified parallel lanes. I binary independent-duration/ottava and GPIF grace+lyric+fermata+legato combinations. V final cohort and any specifically unqualified source display operand. | I broad primitives, source-owned bends/H/P and common beam graph. V reciprocal/cardinality/register and lyric/ornament neighborhood duties. | Tied/slur/grace/ornament/tremolo carriers; grace+tie+ottava, multi-voice and cross-staff mutation controls. |
| F08.b | Fermata, breath, cues, source fingering and instrument instructions | I source fingering, accents/ghosts and ordinary performer instructions. V source schema/version and percussion transitions. | I source fermata/breath/cue/fingering content. I source-owned Fingering font/style/color/visibility through public conversion and standard technical carriers; original controls plus offline schema. No hand inferred from staff. | Fermata/breath/caesura/cue/technical and directions; separate required timing/ownership from qualified drawing-only limits. |
| F09.a | Dynamics, hairpins and expressive text; exact content/visibility | I discrete dynamics, source expressive instructions and text with current GPIF helper controls. V final cohort with exact source caption and line endpoint expectations. | I exact directions, rich captions/hairpins and broader scalar presentation. V independent ordered caption/style/graph audit and frame limits. | `dynamics`, `wedge`, words and standard typography/color; exact owner/clock and one complete carrier, no cross-direction text pooling. |
| F09.b | Tempo words, units/dots/rates, changes; software-only automation | I source tempo changes, printed instructions and separated engine facts. I binary literal tempo/visibility and displayed Wah state; numeric transition duration is source-qualified playback in beats, with no invented accelerando caption. | I native metronome/rate/words and source presentation. V unfamiliar glyphs, active defaults and same-clock independent association. | `metronome`, words, appropriate `sound`; distinguish printed rate from engine scheduling and preserve hidden captions. |
| F10.a | Repeats/counts, alternate endings, nested/nontrivial structure | I repeats/endings, navigation and GPIF simile notation. V nontrivial/nested boundaries and version breadth. | I repeats/Volta and source graph primitives. V simultaneous/overlapping endings, labels and ambiguous neighbors. | `repeat`, `ending`; independently recover source boundaries and count; playback traversal is separate. |
| F10.b | D.C./D.S., Coda/Fine, rehearsal and measure references | I source navigation/swing/double bars and literal directions. V exact target/label combinations across versions. | I marker/jump/rehearsal content and presentation. I independent Jump/Marker source audit: 99 original500 source objects in 34 inputs, no remaining family candidates in targeted fresh-process proof. V final unified run; measure-number/section policies remain separate work. | Segno/coda/words/rehearsal and sound navigation attributes; confirm destinations and printed text together. |
| F11.a | Chord names, roots/quality/degrees/inversions and source diagrams | I literal chord symbols, frames/barres and GPIF helper recovery. I enhanced GP3 source chord analysis/barres (`f0f4679`), original controls and literal fallback; no generated replacement chord or diagram. | I structured/literal harmony, source catalogs/degrees/bass, modern/legacy diagrams/barres/fingering vectors. I independent ordinary Harmony audit plus genuine native 4.70 two-chord producer fixture. V catalog/polychord/extended grammar audit; frame-shape limits remain explicit. | `harmony`, root/kind/degree/bass and `frame`/frame-note/barre; capo/tuning/left-handed source facts, no generated diagrams. |
| F11.b | Lyrics, verses/syllables, melismas and note/voice ownership | I source lyrics/verses and note ownership. I GPIF verse/blank-beat/first-staff ownership controls and six explicitly upstream-authored lyric owners. V untouched nonempty producer lyric/melisma verification; empty templates are not that evidence. | I source lyrics/melisma endpoints and verse style justification. V ambiguous starts/stops/fixups/negative spans; separate lyric block-anchor format limit. | `lyric`, syllabic/elision/extend; repeated text cannot be borrowed from another voice or verse. |
| F12.a | Keyboard/other pitched multi-staff, clefs/transposition and pedal | I nonfretted source parts and GPIF physical staves/sound/pedal state. I binary timed program contexts preserve physical notation and register. V final 203 epoch; standard low/high register limits retain exact source pitch. | I keyboard/transposing/concert-view parts and instrument timelines. V full pedal/default-clef/tuning source audit. | Staff/clef/transpose, pedal and instrument carriers; source staff does not imply performing hand. |
| F12.b | Figured bass and instrument-specific notation | I general traditional part recovery. V instrument-specific source vocabulary and full arrangements. | I expanded FiguredBass numbers/modifiers/continuations/brackets/color. Independent 84 genuine objects / 133 rows pass; V final epoch and other instrument-specific subtypes. | `figured-bass`, technical and directions; original keyboard/bass accompaniment fixture and independent expectation. |
| F13.a | Drum/kit identity, unpitched positions/noteheads and rhythms | I legacy percussion MIDI 27–87 and GPIF source local/catalog identities. Targeted genuine GP5 checks all 61 identities. V final 203 and changing-kit combinations. | I source drum identity separate from display/voice, instrument changes and original percussion evidence. V general repertoire/kit-change breadth. | `unpitched`, `instrument`, notehead and MIDI-unpitched identity; notation line is not pitched MIDI. |
| F13.b | Percussion articulation/visibility/cues and mixed arrangement | I shared source techniques/visibility carriers. I mixed-source arrangement controls; delivered unpitched transition checkpoint `c1779c4` requires integration/final verification. | I staff line visibility/size/type timelines and mixed arrangements. I alphabetic frets, reversed/interline string rows, source TAB defaults and independent staff/line visibility. M duration/fret font and rhythm-symbol selectors still require standard projection; this is distinct from percussion identity. | Preserve part/staff/voice and owner-specific notehead/mark color; test with simultaneous pitched parts. |
| F14.a | Source colors/highlights, frames, annotations and cue/size distinctions | I ordinary source presentation and note/technique facts. V all authored owner/style combinations and standard limits. | I text/lyric/credit fonts/color/size/alignment, note/staff colors, image resources and frame facts. I Fingering/Harmony presentation and ordinary source-scaled sizes integrated. Delivered line-caption helper `d13f7b9` needs reader integration. M music-glyph size, inline size/super/subscript and remaining TAB font/duration projection; verified carrier limits remain separate. | Standard color/enclosure/font-size/cue/image or suitable annotation; D43 does not require proving author intent. |
| F14.b | Hidden music/marks, grouping, source views and selected parts | I one musical event stream with source staff/voice/part selection and hidden facts. V whole-cohort selection/presentation. | I selected views, part/line/component visibility and source graph ownership. V all used-style consumers and independent selected-view verification. | `print-object`, grouping/part visibility and standard notation; do not merge distinct views or drop hidden source meaning. |

## Coverage axes and required supplemental cohorts

Each applicable row must cover GP3, GP4 (including admitted variants), GP5,
GP6/GPX, GP7 and GP8, and MuseScore 3 and 4 producer/native forms. Source versions
1 and 2 are excluded only for MuseScore (D42). A synthetic normalized GPIF file
is not a genuine GP6/7 export; a migrated MuseScore file is the same score
identity, not an independent repertoire sample.

The acceptance set needs both guitar and bass, ordinary and alternate tunings,
capo, multi-string/chord techniques, ties/grace/tuplets and simultaneous voices;
also keyboard, vocal/lyric, non-fretted pitched and percussion parts. Include
whole arrangement and each existing selection/view route, XML and compressed
containers, hidden/cue/colored examples and malformed-source negatives. Public
miniatures must be original or rights-cleared. Private technical studies and
repertoire stay outside Git; freeze identity, provenance, denominator and
feature inventory separately. The parent owns the genuine GP cohort research.

Original500's 497 converted outputs do not test fretted technique completeness:
only four song/guitar inputs have tuning and none has note string/fret choices.
General percussion and rare instrument changes need separate evidence. The
native fixture manifests cover selected producer exports, not every accepted
feature on every version. Do not estimate progress by multiplying format count
by fixture count.

## Historical diagnostics and their dispositions

The corrected PR127 saved audit is immutable: 500 public calls, 497 outputs,
three diagnosed source refusals; 361 candidate occurrences, 55,272 unresolved
occurrences and 83,413 recorded projection-limit occurrences. These are
historical, overlapping diagnostics, not distinct musical defects. See
[current status](current-status.md) for exact epoch and denominators.

| Historical group | Disposition at this ledger version | Required next evidence |
| --- | --- | --- |
| 283 member/header stem candidates, union 39 identities | Source reconstruction attributed 146 required source stems, 80 physical-layout cases and 57 inactive-header/nonmembers; all 283 memberships agree | Independent assessment of 135,268 source rows / 70,979 beamed rows in the 39 scores found no primary endpoint or eligible authored-stem disagreement. See [bounded graph proof](research/native-beam-source-graph.md). Secondary cuts/hooks and final unified epoch remain distinct. |
| 47 metronome boundary candidates | Diagnosed checker false positives; bounded correction merged before this ledger | Retain [attribution and controls](research/musescore-metronome-boundary-audit.md); fresh unified assessment supplies current totals. |
| Six Dynamic content/visibility candidates | Diagnosed checker representation mismatch; independent correction in this delivery | See [finite Dynamic/report correction](research/musescore-dynamic-report-audit.md). Styling and unfamiliar captions remain separate open duties. |
| 23 line-size and two rich-Dynamic report candidates | Report contributor census needed correction | Same finite proof; correct aggregate accounting does not prove complete caption appearance or standard size units. |
| Three source refusals | S previously diagnosed orphan/backwards relations, retained in denominator | Recheck the exact original inconsistency if newer recovery changes the disposition; do not fix source or exclude identity to improve totals. |

### Every historical unresolved reason remains accountable

The [machine-readable disposition inventory](research/musescore-unknown-dispositions.json)
contains **all 378 reason categories**, their historical occurrence and identity
counts, required contract families and concrete next-evidence workstream. Its
sum is 55,272. It includes no private input names, paths, payloads or excerpts.
Each row now distinguishes implementation, independent verification, exact
source-role exclusion and remaining work. An assigned workstream or newly
implemented helper is not a resolution of its entire source family. IDs refer to this ledger version's sorted reason vocabulary and
must not be silently reassigned in later versions.

The 13 workstreams separate beam membership, relation graphs, lyrics, chord and
figured-bass meaning, pitch/instrument timelines, rhythm/note roles, navigation,
dynamics/tempo, annotations, used styles, owner presentation, playback boundary,
and remaining source-role determination. Shared duties can overlap even though
the inventory assigns each reason to one workstream. A used-style field cannot
be closed merely because it looks like a default; establish actual usage first.
An unfamiliar annotation cannot be waived because its purpose is unknown.

### Recorded limits also require the correct source role

| Recorded role groups | Historical occurrences | Contract disposition and remaining condition |
| --- | ---: | --- |
| Generated, edited, compound, moved, 6/8 and mixed physical beam stems | 81,834 | X only for generated physical layout after independently proving musical grouping, source instructions, visibility and ownership; unresolved beam membership stays V. |
| Measured tremolo native stroke style/length and drawing offset | 661 | X for exact drawing metrics; preserve tremolo count/type, notes, duration, voice, visibility and authored annotations. |
| Metronome separator appearance and family reset | 664 | Review exact semantic/glyph/format capability evidence; separator text and representable family/color remain required. |
| Line dash pattern and system-break continuation layout | 106 | X for exact native geometry only; retain line style, performer labels, endpoints and continuation meaning through available standard mechanisms. |
| Rich-Dynamic scaled size/family reset; Tempo family reset; text-size units/metrics | 97 | Source unit/default qualification and standard capability proof required. Raw retention alone cannot discharge representable size/emphasis/color duties. |
| Segment fermata standard/derived attachment | 31 | Verify source timing/part/voice and useful attachment first; only the documented non-isomorphic attachment remainder can be X. |
| Pedal closing angle/connection | 18 | Exact native angle is outside geometry scope; any re-pedalling/connection instruction remains required or needs a verified standard capability limit. |
| Cross-staff breath physical placement | 2 | X only for qualified physical placement; breath identity, clock, voice and source staff remain required. |

The limit rows sum to 83,413. They are not blanket exclusions of their containing
features. Their underlying source qualification and standard capability claims
must survive the current implementation; this inventory does not independently
re-certify every historical limit occurrence.

## Assessment and cleanup delivery gates

| Gate | State / concrete work |
| --- | --- |
| ASSESS1 — independent source/container authority | I immutable main collection and complete saved-fact correction. I independent bounded MSCZ selection/decompression and source/capture binding with original controls; see [runner evidence](research/corpus-assessment-runner.md). V complete musical and used-style verification remains separate; container extraction alone cannot certify source fidelity. |
| ASSESS2 — fixed musical cohorts | I fixed 203-input GP inventory and GPIF 146 source review, plus original mixed arrangements and native producer fixtures. V final 203, final 500, untouched producer nonempty lyric evidence and the finite supplemental duties below. |
| ASSESS3 — causal diagnostics and final unified run | V close candidate attribution and useful unknowns with source roles, scoped fixes/verification or evidenced X/S dispositions; then freeze one unified production/checker baseline and run all fixed denominators once. No rolling subset arithmetic presented as a new full run. |
| CLEAN3 — independent checker organization | I separate Dynamic semantic-caption and HairPin size-contributor helpers, original mutation controls. V further cohesive extraction only where it improves independent proof and preserves source/producer semantics; never import production musical decisions into the checker. |
| DOC1 — final evidence reconciliation | I this matrix and complete historical unknown inventory. V update each changed row with integrated commit and acceptance evidence, reconcile current status/plan/API proof, and verify all required subtype/combination and operational gates before claiming completion. |

The parent controls production integration and the final package/schema/regression
checks. No changes in this ledger alter public APIs, source-admission policy,
contract scope or Viewer delivery. Keep historical receipts immutable and retire
an open item only with its specific evidence or an explicit contract decision.

## Historical explicit-presentation checkpoints (superseded by current matrix)

Commit `2004fe1` adds supported standard presentation for directly authored text
properties across directions, lyrics and credits, plus plain caption frame
shapes. Its helper/writer checkpoint passes 593 regression tests, package checks
and five original schema carriers. At that checkpoint, native reader hooks and inherited-style
selection were separate integration requirements; this does not complete F11
or F14. See [the exact scope and frame limits](research/musescore-text-presentation.md).

The historical unknown registry first gained role dispositions at version `2026-10-14.2`; its current version is `2026-10-14.4`. U157, U173 and
U199 have [qualified playback field dispositions](research/musescore-playback-field-roles.md).
Their containing instruments, captions, scope and visibility remain performer
obligations. Explicit scalar and frame rows identify implemented routes and
remaining context evidence separately. All 378 historical reason IDs and all
55,272 occurrence counts remain intact. No new full-assessment totals are
inferred from these finite source checks.

### Inherited text presentation implementation checkpoint

The [source-bound style resolver](research/musescore-inherited-text-presentation.md) now preserves active source font/mask/color/size/frame facts across explicit style selection, implicit text-owner styles and selected score scopes. Its initial 24 original controls covered source 3/4 names, ordered resets and source/style size dependencies. That helper checkpoint did not establish adapter integration. The current matrix records the subsequently integrated hooks and the remaining line/glyph duties.

## Current evidence and explicit remaining work

The matrix above replaces the initial `db3966a` capability inventory. Its earlier
absence claims are historical, not descriptions of the current adapters. Key
source/control records are [shared standard mappings](research/performer-standard-mappings.md),
[GPIF instructions](research/gpif-performer-instructions.md), [native techniques](research/native-performer-techniques.md),
[harmony/frames](research/musescore-harmony-frames.md), [staff timelines](research/musescore-staff-type-timeline.md),
[common beam graph](research/native-beam-source-graph.md), [figured bass](research/native-figured-bass.md),
and [text/style presentation](research/musescore-inherited-text-presentation.md).

The source role inventory is not a waiver. The initial missing-feature list is
superseded by these concrete checkpoints and remaining duties:

| Duty | Current evidence and next action |
| --- | --- |
| Modern native techniques and physical state | All eight bend forms, finger/bar overlap, held curves, H/P view/text flags and capo masks over tuning changes are implemented. The reader's actual integrated controls—not the earlier first-tranche proof paragraph—establish this scope. Complete the owner's final finite source-role review and retain explicit system-dependent hold ambiguity. |
| Ordinary source text typography | `112035e` + `a9f003c` bind source millimeters, version-specific reference and active staff/score magnification. Fingering public/schema controls pass. Two old annotation assertions need exact new point values; an old User-frame size report must be reconciled only for the same recovered source fact. |
| Line captions | Delivered `d13f7b9` and shared-scale extraction `e9b10dc`: TextLine/HairPin/Pedal face/size/emphasis inheritance, independent temporary-text and line dependencies, endpoint contexts, 31 helper/writer controls and one offline schema document. Native endpoint hook and source-owned stale-report reconciliation remain pending. Continuation typography does not imply invented system breaks. |
| Remaining text representation | Mixed custom Dynamic needs visible styled words plus a hidden typed dynamic (parent implementation active). Metronome/music-symbol size and inline font-size/super/subscript need independently qualified standard carriers. Missing attributes on one element alone are not a format impossibility. Glyph owner is implementing standalone Symbol size using the shared source-space resolver. |
| Remaining TAB presentation | Letter frets, physical string order, tied-fret policy, interline rows and source defaults are implemented. Native duration-font/glyph selection, duration repetition and custom fret-font presentation remain concrete mapping duties; owner is working them. Mixed-staff end-barline policy has a separately documented standard staff-selector limitation. |
| Remaining binary physical rule | Independent durations, tuplet/ottava facts, enhanced GP3 chords, timed programs, tempo captions and displayed Wah are implemented. Twelve-string playback simulation is qualified as such. Short-string banjo physical fret interpretation remains source qualification work; delivered percussion transition checkpoint requires integration. |
| Independent source audits | FiguredBass 84 genuine owners/133 rows pass; Jump/Marker 99 owners across 34 inputs pass targeted audit; ordinary Harmony has independent mutation controls and genuine native 4.70 producer proof. Remaining specifically named audit families are Harmony catalogs/polychords/extended grammar, active StaffType/StringData/clef state, measured Tremolo/Trill ownership, lyric endpoint/fixup rules, and used-style/inline presentation consumers. Existing beam proof covers the 39 historical candidate identities; final whole cohort remains necessary. |
| Final operational acceptance | Wrap-up epoch `758aa90`: native 496/500 converted and schema-valid (3 refusals, 1 resource budget); GP 202/203 converted and schema-valid (1 pitch format limit); 1290/1290 regression and 266 research tests plus package, webview, vendor and schema checks pass. The remaining native checker rows and open items are listed in [current status](current-status.md#wrap-up-epoch-at-758aa90). The landing epoch `069a159` remains recorded there with a correction. Human readability/performer acceptance remains separate from schema. |

The GPIF [final source-role review](research/gpif-performer-contract-review.md)
records 65 coupled controls, five schema documents and 146/146 technical-study
traversal, plus separately labelled supplemental lyric inputs. The binary
[independent-duration record](research/guitar-pro-binary-note-durations.md),
[mixer record](research/guitar-pro-binary-mixer.md) and
[enhanced chord record](research/guitar-pro-enhanced-chords.md) replace the old
missing-byte/mixer/chord claims. The intermediate fixed GP 203 assessment at
`247e338` has 202 converted/schema-valid inputs and one exact out-of-range pitch
format limit; it is not the final unified epoch. The native 500 intermediate
assessment has 495 converted outputs, 491 schema-valid at its frozen baseline;
four attribute-order defects were subsequently corrected. These historical
results are not silently rewritten as current results.

The 43 text candidates in the native intermediate saved outputs have finite
checker attribution: 30 later-family reset cases, six inherited emphasis cases,
five decorated rich-Dynamic report contributors and two native 3.6.1 caption
cases. Saved-output-only reevaluation clears all 43 across 11 affected identities.
This changes checker evidence, not the frozen public output, and does not certify
unrelated unknowns. The parent full regression checkpoint at `1413222` passed
952/952 tests. The independent research suite at `f3a06af` passes
213/213 controls; newer typography and other delivery checkpoints require the next
integrated run.

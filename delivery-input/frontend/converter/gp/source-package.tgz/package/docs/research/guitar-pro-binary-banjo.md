# Binary short-string banjo

The GP3–5 short-fifth-string flag now establishes a five-string fretted banjo independently of its MIDI patch. It preserves the encoded reentrant tuning, capo and source-relative fret. Sounding pitch continues to use **encoded open pitch + capo + encoded fret**, exactly once.

The fifth string starts at the fifth physical fret. Guitar Pro stores its frets as0,1,2… relative to that string's own nut. Displayed full-neck numbers are0,6,7… . The model keeps the original local-nut number in `note.fret` and separately records the derived `note.fretDisplay` with its source flag, five-fret offset and origin. Standard MusicXML technical fret notation uses the display value; auxiliary metadata preserves both values. Other strings are unchanged. Grace transitions, ties, bends and harmonic nodes continue to calculate with the original local-nut operands. Literal chord-frame coordinates remain independent source diagram fields; they are not silently transformed by the note-fret rule.

This distinction follows the original MuseScore importer fix author's [source-semantics report](https://musescore.org/en/node/316896), which explicitly distinguishes Guitar Pro's stored numbering from normal banjo display numbering. It agrees with Arobas's GP4/5 manual description of the short fifth string. No licensed importer implementation was copied.

## Evidence boundaries

Two independent contributor-published GP5/PDF/MIDI pairs provide targeted producer evidence outside the fixed203-study corpus:

- [Composer's original paired submission](https://www.banjohangout.org/tab/browse.asp?m=detail&v=16328), GP5.00 SHA256 `fd1f215a97315997d7f55a608faf25cbc7c3a46c0524f61cd7ec16c77d99b94d`: source tuning has fifth-string G4, its raw open fret is0, paired MIDI is67, and the printed staff places it at G5 with octave-transposing notation. This independently qualifies the banjo written-register convention.
- [Contributor's paired arrangement](https://www.banjohangout.org/tab/browse.asp?m=detail&v=12928), GP5 SHA256 `8910823719fc32b4b5e3dfc21223514df7466d32a3f12341e8a48ce62336cff5`: source capo2 gives an open fifth-string A4 in paired MIDI while written notation is A5. The capo is not silently omitted from the drone.

Both convert through the public API and their outputs are checked against the bundled MusicXML4 schema. Their payloads and reference material remain outside Git. Neither pair contains a positive fifth-string fret; the positive-fret rule is qualified by the importer author's explicit format account and original controls, not misrepresented as a paired producer comparison.

Original GP3/4/5 controls cover raw0/1/12, displayed0/6/17, capo2, the nonascending tuning vector, physical family preservation, source capture, MusicXML display, natural harmonic node12 and a grace bend whose interval remains10 rather than absorbing the display offset. A four-string source contradicting the short-fifth-string flag refuses. A third genuine composer source with a positive short-string fret exposed a separate connected-slide destination case; its result belongs to that independent technique verification, not to a silently removed sample.

The third composer source now also converts: its measure7 shift slide joins the next note on the same string across an intervening open-string attack. Slide recovery follows source voice/staff/string identity instead of requiring adjacent attacks; written durations and attacks are unchanged. The pinned reader's `Note.nextNoteOnSameLine` corroborates that destination convention. A backwards destination index keeps recovery linear. Original GPIF shift/legato controls independently exercise that arpeggio case, while missing or dead destinations still refuse rather than inventing a target. The composer source yields15 slide relations and schema-valid MusicXML; the input stays private. This is a targeted genuine supplement, not an expansion of the fixed203 corpus denominator.

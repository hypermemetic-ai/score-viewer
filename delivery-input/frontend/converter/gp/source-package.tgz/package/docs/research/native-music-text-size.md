# Native musical text size

Ordinary text and musical text are separate source roles. `TextRun.textFontSize`
retains the formatter request; `musicFontSize` records the independently qualified
glyph projection. Standard Dynamic and Pedal carriers can also carry that fact.
Each calculated point size retains its source request, native version, unit
dependency, score spatium, active staff scale and music-font multiplier.

| Source epoch and owner | Music-font size law |
| --- | --- |
| Native 3 ordinary musical text, including Tempo and Dynamic | Formatter font size, with source spatium dependency and script ratio |
| Native 4.0–4.5 Tempo | Formatter font size multiplied by 5/3 |
| Native 4.0 Dynamic | Formatter font size multiplied by 2 |
| Native 4.1–4.6 Dynamic | `dynamicsSize` times 20 points, always scaled by source spatium |
| Native 4.4–4.6 Pedal-style music text | Selected `pedalMusicalSymbolsScale` times 20 points, subject to source text unit dependency |
| Native 4.6 Tempo | Independent `musicSymbolSize`; its constructor default uses score `tempoFontSize` times 5/3, rather than a later local ordinary size |
| Native 4.6 staff/system/marker musical text | Independent `musicSymbolSize`, default 18 points |
| Native 4.7 ordinary musical text | Independent selected style `MusicalSymbolSize` or explicit `musicSymbolSize` |
| Native 4.7 Dynamic/Pedal-style music text | Independent `musicalSymbolsScale` times the native four-spatium SMuFL em, converted to points |

Source dependencies are qualified in [the ordinary size record](native-text-size.md).
Modern independent symbol-size and scale properties are not changed by a line
caption's later ordinary formatter `setSize` cancellation. Original inline
requests remain available even when the native glyph law overrides them.
Unknown selectors, malformed requests and missing unit authority do not acquire
an invented default. Native-version defaults remain explicitly marked as defaults.

Tempo output retains the standard metronome and sound semantics. Where a single
metronome font cannot describe the located caption, visible ordered standard
words/symbols accompany a hidden typed metronome. This preserves separate glyph,
ordinary text and script presentation without changing printed rate or source
engine tempo. It does not promise native font availability or page geometry.

The implementation follows `TextFragment::font` in the
[native 3 renderer](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/textbase.cpp),
[4.0 renderer](https://github.com/musescore/MuseScore/blob/v4.0/src/engraving/libmscore/textbase.cpp),
[4.1 renderer](https://github.com/musescore/MuseScore/blob/v4.1.0/src/engraving/dom/textbase.cpp),
[4.4 renderer](https://github.com/musescore/MuseScore/blob/v4.4.0/src/engraving/dom/textbase.cpp),
[4.6 renderer](https://github.com/musescore/MuseScore/blob/v4.6.0/src/engraving/dom/textbase.cpp),
and pinned [4.7 renderer](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/textbase.cpp).
The independent 4.6 Tempo initialization comes from its
[constructor](https://github.com/musescore/MuseScore/blob/v4.6.0/src/engraving/dom/tempotext.cpp).
The pinned [style definitions](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/style/styledef.cpp)
and [SMuFL point constant](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/style/styledef.h)
establish current defaults. Endpoint properties and generic setter behavior are
specified by [TextLineBase](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/textlinebase.cpp)
and its [property registry](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/property.cpp).

Original controls in `test/musescore-music-text-size.test.ts` separate versions,
ordinary/music sizes, selected style and explicit source authority, invalid
values and writer mutation. The independent schema control validates eight
original Tempo/Dynamic documents against pinned MusicXML 4.0. These are original
controls, not additional untouched producer corpus examples. Corpus coverage and
independent source-size audit coverage remain separately tracked by the ledger.

The native playing-technique annotation constructor inherits `STAFF` text style
([pinned header](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/playtechannotation.h#L36)).
Its literal inline scripts therefore use the same source-selected staff font size
as ordinary staff instructions; no playback technique is inferred from the text.
An original public control verifies the default 10-point request and readable
6-point superscript carrier at the default 1.75 mm staff space.

Rich Dynamic captions retain separate ordinary and musical component sizes.
Different prose and glyph sizes do not invalidate a source-qualified `mf`, `sf`,
`p` or `f`. Consecutive dynamic glyphs may share a typed standard carrier only
when their effective source typography agrees. Source interval and glyph identity
mutation controls remain active.

The independent corpus checker now has a separate source-only numeric expectation
module, `scripts/research/musescore-text-size-source.mjs`. It takes parsed source
owners, source styles and independently parsed text runs; production score facts
and MusicXML are comparison targets, never expectation inputs. The active role
checks cover explicit/inherited ordinary size requests, ordered first-property
`font` tokens, source staff magnification, script size/baseline resets, and the
versioned Tempo music-size laws. Original controls mutate size, script baseline,
source scope and public request ownership. Unknown selectors, malformed values
and attributed script grammar retain explicit unknown dispositions.

This does not certify every historical typography unknown. Line-caption source
graphs, component-only metronomes, rich Dynamic profile accounting and inactive
style fields have separate obligations. The old corpus receipts remain immutable;
a fresh integrated epoch must identify which source roles were actually checked.

# Qualified playback fields in the historical unknown inventory

The independent source-role helper classifies three exact source fields, not
entire musical owners. It imports no converter decisions or emitted output.
The existing D34/performer-contract playback exclusion applies only after these
field, profile and shape checks pass.

- `Instrument/singleNoteDynamics`: one plain Boolean in a primary Part's
  Instrument. The examined producers are 3.4.2, 3.5.0, 3.5.1, 3.6.1 and 3.6.2.
  The [3.4.2 reader](https://github.com/musescore/MuseScore/blob/148e43fe7534a9916ff77cfa28ca13257d64fdca/libmscore/instrument.cpp#L260)
  assigns the instrument's synthesis switch. The same consumer remains in
  [3.5.0](https://github.com/musescore/MuseScore/blob/43c5553/libmscore/instrument.cpp#L1082),
  [3.5.1](https://github.com/musescore/MuseScore/blob/12ab1d94dcd18ecf576f919b748cfbdc6a21c47f/libmscore/instrument.cpp#L1082)
  and [3.6.1](https://github.com/musescore/MuseScore/blob/d0fc8e9739092fd1a5a28b69c598917f7dae88ec/libmscore/instrument.cpp#L1148).
  The [MIDI consumer](https://github.com/musescore/MuseScore/blob/3224f342d12f4af8ea782e929c49f5ce85f97da6/libmscore/rendermidi.cpp#L752)
  selects synthesis controller behavior. Printed Dynamic/HairPin content,
  instrument identity, clefs and written/sounding register remain independent.
- `SystemText/swing`: only the examined 3.02/3.6.2 primary owner with an empty
  or zero unit and bounded ratio. The [source reader](https://github.com/musescore/MuseScore/blob/3224f342d12f4af8ea782e929c49f5ce85f97da6/libmscore/stafftextbase.cpp#L130)
  assigns a disabled scheduler unit. This does not classify an active swing
  instruction, its displayed caption, scope, staff, clock or visibility.
- `Score/Synthesizer`: only primary 3.02/3.6.2 with bounded known processor groups
  and scalar `val` entries indexed by integer `id`. The [state reader](https://github.com/musescore/MuseScore/blob/3224f342d12f4af8ea782e929c49f5ce85f97da6/libmscore/synthesizerstate.cpp#L39)
  and [synthesis consumer](https://github.com/musescore/MuseScore/blob/3224f342d12f4af8ea782e929c49f5ce85f97da6/audio/midi/msynthesizer.cpp#L315)
  establish the engine role. Unknown processors, structured values, duplicate
  groups and nested source views do not receive this exclusion.

Original controls include malformed/duplicate/foreign fields and an integration
mutation where the disabled swing setting is classified but a missing printed
SystemText instruction still fails the independent content check. Exact original
source bytes were rechecked against saved input hashes; no converter calls or
historical receipt changes were made. U157's six historical occurrences and
U173's one occurrence match the qualified roles. U199's saved source contains one primary disabled-swing field and five
alternate-view counterparts. A complete owner census qualifies only the primary
field; the five alternate-view fields remain explicitly unqualified. This census
was necessary because the historical detailed example array did not retain the
single unknown's locator; no source view is inferred from its similar payload.

The historical 55,272 unknown occurrences and 378 categories remain unchanged in
the immutable assessment. These later dispositions do not manufacture a new
whole-corpus total or claim that the surrounding scores are complete. Final
unified assessment must execute the integrated checker against its fixed input
selection and preserve any newly exposed categories.

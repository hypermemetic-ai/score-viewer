# Native figured bass

The source item is a stack of components, not a chord symbol or an inferred harmony. Its exact rational duration and position belong to the source staff and voice. Standard MusicXML figures precede their actual regular note owner; hidden blank duration intervals preserve figure changes inside a sustained note without adding attacks.

The reader retains optional numbers (including multi-digit values), all eight native modifier enums, five bracket boundaries, continuation enums, visibility, placement and color. Native absent-digit sentinel -1 does not invent a number. The standard projection uses figure-number, prefix, suffix and extend. `CROSS` uses the standard `plus` spelling; `BACKSLASH` uses `back-slash`. Exact encoded modifiers and bracket/continuation data also appear in compatible miscellaneous fields.

Uniform whole round enclosures use the standard stack-wide parentheses switch. MusicXML 4.0 has no per-component or per-row square/mixed bracket boundary vocabulary. Those cases use literal standard words with hidden structured figures and report the limitation; they do not falsely enclose every row. Native extension-line geometry in that textual fallback is not reconstructed. This is a qualified format limitation, not a general permission to drop other figure content.

Primary definitions: MuseScore commit `3654226c2e99289916916953a98e585a3d3b315a`, [figuredbass.h](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/figuredbass.h), [figuredbass.cpp](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/figuredbass.cpp), and the repository-pinned [MusicXML 4.0 schema](../../third_party/musicxml-4.0/musicxml.xsd), figure/figured-bass/extend types. Native SIMPLE continuation is a single extension; EXTENDED carries source start/continue semantics independently of the numeric component.

Verification separates production and checker:

- Six original production controls cover numeric/modifier vocabulary, absent digits, continuations, brackets, color, visibility and malformed enums. The existing interior-note ownership control remains.
- Nine original combined figure forms validate against the pinned MusicXML 4.0 schema.
- An independent source/output checker uses the source voice clock and standard note owner. Mutation controls detect altered figures/modifiers, intervals, visibility, ownership and extra stacks, plus forged public carrier ownership, changed literal bracket words and corrupted auxiliary boundaries.
- The unchanged original500 score with SHA-256 `56d0db5528a2e6f55c25af26ae46af5558bff414c5b293cc0ebab2d78b05749e` contains84 figured-bass objects and133 rows. All84 exact owner, duration, component, visibility/placement and public carrier obligations pass, with exact overall stack cardinality. No score bytes are committed. This supplemental result does not replace the final committed corpus epoch or certify unrelated features in that score.

The independent bracket gate verifies the separate literal words and exact auxiliary boundaries as well as the hidden structured figures. Schema validity alone does not establish those semantics.

# Native beam source graph

Implemented source rules are separated from native page layout. The native reader now runs one bounded graph pass after event clocks and ties are complete. The former per-voice admission microprofiles and unused callback kernel have been removed.

## Source authority

The graph uses logical staff and voice tracks, exact written durations and elapsed clocks, source beam modes and headers, active staff meter and custom Groups, nested Tuplet identity, grace hosts, and explicit system/page/section boundaries. Performer text, source links, tie reciprocity, producer revision strings and incidental serialization whitespace do not determine whether a musical beam can be recovered. Original modes, source stem preferences, note attacks, pitch, source bytes and event clocks remain separate from derived beam notation.

The governing primary sources are MuseScore's pinned [3.6.2 layout](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/layout.cpp), [3.6.2 Groups](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/groups.cpp), [3.6.2 Beam](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/beam.cpp), [4.7.5 Groups](https://github.com/musescore/MuseScore/blob/v4.7.5/src/engraving/dom/groups.cpp), [4.7.5 beam layout](https://github.com/musescore/MuseScore/blob/v4.7.5/src/engraving/rendering/score/beamlayout.cpp), and [4.7.5 reader](https://github.com/musescore/MuseScore/blob/v4.7.5/src/engraving/rw/read460/tread.cpp). These references establish source behavior; no upstream implementation is incorporated as a dependency.

Rules qualified by the source include:

- Forming an initial pair with END differs from adding END to an already open beam. The same source distinction applies to grace beams.
- Explicit MID/END can continue across measures; modern secondary-break modes can also continue the primary beam. A native page/system/section break prevents that continuation. Rests can bridge an explicitly requested beam; automatic rests interrupt it.
- A real staff TimeSig is necessary for the quarter-denominator beat-minimum prepass. An absent TimeSig still has a default meter but does not acquire that extra prepass.
- Secondary cuts and hooks use complete membership, neighboring written values, nested Tuplet edges, source meter cuts and source version rules. Grace before/after groups retain performed order independently of ordinary groups.
- A Beam header owns the source event immediately following it. It governs direction only when that event actually starts the recovered group. An interior header or isolated event does not gain authority over another group.
- For an ordinary unmoved pitched group without a forced Beam direction, legacy native files use the first Chord's authored preference; modern files use the first custom Chord preference, after visible secondary-voice precedence. This recovers authored instructions without computing physical stem direction from note geometry.
- Serialized Fragment coordinates modify the direction slot active when they are read. An inactive slot does not prevent a later explicit direction from being projected. Obsolete l1/l2 fields do not activate a modified drawing.
- Beam visibility and source RGBA accompany every projected beam level. Hidden beams retain membership through transparent standard beam notation.

Modern version differences are explicit: position-based duration grid lookup exists from native4; anacrusis offset begins in4.4; relative measure-clock grid alignment is used for4.7. The referenced profiles were compared with pinned4.0,4.1,4.2,4.3,4.4 and4.6 source snapshots. Unknown physical automatic layout is not substituted for an authored preference.

## Independent evidence

`musescore-beam-source-graph.mjs` imports no converter code, public facts or output XML when it builds its expectations. It uses the research reader's separately decoded source clocks and a distinct source-row algorithm. Its comparison stage then checks public source ownership, primary endpoints, original header and mode facts, authored effective stems, standard beam/stem ownership, visibility and color. An unqualified inherited meter is propagated until a fresh source declaration; it cannot silently become default4/4 evidence.

Original positive and counterfactual controls include complete groups, source mode changes, inactive headers, moved members, cross-measure continuation, initial-pair END, after-grace ordering, malformed timing, authored Chord preferences, absent/explicit meter and active/inactive Fragment slots. Output mutations independently demonstrate detection of missing primary beams, wrong endpoints, borrowed origins and wrong standard stems. The historical native beam fixture families retain their concrete musical assertions and now also run this independent primary/stem audit for each admitted conversion. Removed assertions concerned obsolete internal callback/report namespaces or intentionally incomplete old output, rather than musical requirements.

A private assessment of the frozen283 candidate stem observations classified146 as required source-derived stems,80 as physical layout cases and57 as inactive-header/nonmember cases. An independent source reconstruction agreed on all283 complete group memberships. Expanding that comparison across the39 containing scores checked135,268 source event rows and70,979 beamed rows with no primary endpoint or eligible authored stem disagreement at the recorded assessment epoch. This is bounded evidence, not a claim about unseen inputs. Purchased source files, source-specific receipts and historical epoch artifacts remain outside Git and unchanged.

The large comparison establishes primary topology and authored stem projection. Secondary cuts and hooks have original source-qualified controls; they are not represented as independently exhaustively assessed across the135,268 rows. Schema validity, musical semantics and human rendering acceptance remain distinct checks.

## Physical layout boundary

A mixed moved group's displaced member and an actively edited beam can require native page geometry to determine the individual physical stem. Those authored preferences and complete musical membership are retained, while the converter reports the precise layout boundary. Unmoved members with a qualified authored direction remain obligations. This boundary does not excuse a missing primary beam, an incorrectly scoped header, a lost hidden beam, or an omitted source instruction.

## Cross-measure duration display

An explicit native `crossMeasureValues=1` style is musical notation, not a page-geometry exclusion. The converter now qualifies the same single-note cross-bar tie pairs as native `Chord::crossMeasureSetup`: the original written type/dots of both chords must sum to one duration representable with zero through four dots. Same-bar ties, multiple-note chords and unrepresentable sums retain their original display. A continuation cannot begin another combined pair. The effective selected score style is used, including the primary score's archive style defaults; explicit false remains false.

The derived `crossMeasureValue` fact names both source events, their tie and the style location. Original event types, dots, rational elapsed duration, pitches, source stems and tie facts remain intact. The first event prints the combined type and dots. The continuation prints no stem, flags, dots or ledger lines; pitched notation uses the standard `none` notehead, while TAB retains its fret. Its accidental and other attached performer instructions remain visible according to their own source facts. The connecting displayed tie is hidden, while MusicXML timing ties continue to describe the original sustained notes. A subsequent tie in a three-note chain remains visible.

Beam grouping uses the combined displayed duration and excludes the continuation. The quarter-beat subdivision prepass uses the original source values: native layout performs that prepass before establishing cross-measure display. Tuplet-neighbor duration comparisons then use the effective displayed type/dots. This changes displayed beam topology without changing either event's elapsed clock.

Source authority:

- [MuseScore 3.6.2 chord.cpp](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/chord.cpp), `Chord::crossMeasureSetup`, and [chordrest.h](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/chordrest.h), `durationType`, `dots` and `actualDurationType`, distinguish stored and displayed durations.
- [MuseScore 3.6.2 layout.cpp](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/layout.cpp), `Score::createBeams`, establishes the prepass order and continuation beam exclusion.
- [MuseScore 3.6.2 note.cpp](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/note.cpp), `Note::draw`, exempts TAB from suppression of the continuation head. Stem, hook, ledger-line, dot and tie drawing each suppress the relevant cross-measure continuation separately. Accidentals remain independently drawn.
- [MuseScore 4.7.5 chordlayout.cpp](https://github.com/musescore/MuseScore/blob/v4.7.5/src/engraving/rendering/score/chordlayout.cpp), `ChordLayout::crossMeasureSetup`, and [tdraw.cpp](https://github.com/musescore/MuseScore/blob/v4.7.5/src/engraving/rendering/score/tdraw.cpp), the note/stem/hook/ledger/tie drawing functions, retain this distinction.
- MusicXML 4.0's bundled schema supports independent `duration` and `type`, `stem=none`, `notehead=none`, note `print-leger=no` and notation visibility. No extension is needed for this projection.

Original controls cover legacy and modern native versions, a combined breve and dotted whole, beam changes, unchanged clocks, retained accidentals and lyrics, TAB frets, a three-note tie chain, non-combinable pairs and malformed styles. An independent source-only implementation derives pairs from reciprocal native tie coordinates and detects altered standard duration, exposed continuation heads and exposed connecting ties. The complete performer checker uses these independently established display facts for its ordinary type/dots and tie-visibility obligations. The standalone schema calibration validates the resulting MusicXML. The independent route explicitly leaves unsupported legacy direct-Tie grammar or incomplete source coordinates unqualified; it never repairs source authority using converter facts.

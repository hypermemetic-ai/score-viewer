# Dynamic content and report-accounting audit correction

This finite independent-checker correction follows the immutable corrected
PR127 source assessment. It changes no converter behavior or source fixture and
makes no conversion calls against private repertoire. The contract remains
open; [the implementation ledger](../implementation-ledger.md) distinguishes
missing required features from verification and qualified exclusions.

## Source-bound content instead of one literal label

The six historical Dynamic content/visibility candidates retain their intended
semantic signs in the saved MusicXML: two captions with prose and paired `mf`/`sf`,
one explicitly qualified ScoreText piano glyph with prose, and three named signs.
The old fallback only accepted a single original-subtype or whole-caption
`other-dynamics` representation. Its narrower rich-caption route did not own all
six contexts. This was a checker representation mismatch, not lost dynamics.

The [independent caption matcher](../../scripts/research/musescore-dynamic-caption.mjs)
recognizes a bounded, source-qualified 3.02/3.6.2 vocabulary, preserves ordered
prose/whitespace and independently established signs, and compares one complete
standard direction at the exact part, measure, staff and rational clock. It checks
inherited visibility, carrier multiplicity and the public source owner, literal,
clock and visibility. No converter text or style helper is imported. Existing
atomic `other-dynamics` checks retain their established duty; the added semantic
route repairs their fallback mismatch. It does not certify full typography,
frames, unfamiliar glyphs or unqualified default contexts.

In the explicit legacy family/size context, adjacent source `m`/`s` plus `f`
glyphs now participate in the existing stronger rich-caption owner, formatter,
standard-component and located-report duties. Qualification retains exact
source glyph adjacency, effective decoration and bounded producer/style rules.
Ordinary named signs outside that explicit context do not acquire a requirement
for richer public formatter facts that their existing conversion did not promise.

## Aggregate reports count all independently qualified contributors

The 23 line-caption report candidates arose because the checker counted explicit
captions while the converter's report also counted qualified default HairPin
captions. The [independent contributor helper](../../scripts/research/musescore-line-size-contributions.mjs)
qualifies only the examined default crescendo/diminuendo begin/continuation
captions, exact producer/default context and bounded raw size requests. Explicit
captions retain the prior census. Context, unknown payload, duplicate fields,
invalid sizes, nested views and comments cannot borrow this qualification.

This correction verifies the **aggregate report**, its count, source location,
disposition and message. It does not claim that every default caption has an
independently proved relation graph or point-unit size. Those separate output,
owner and unit/default unknowns remain open. The accounting controls intentionally
isolate the report duty rather than manufacture complete source certificates.

The two rich-Dynamic report candidates likewise counted four qualified `p`/`pp`
contributors but omitted a fifth qualified `sf` pair from the source census. The
expanded legacy pair qualification includes its component and raw-size report
contributions while retaining the existing report and source-owner checks.

## Finite retained evidence and original controls

A saved-only reread covers the union of **23 inputs** containing the six Dynamic,
23 line-report and two rich-report candidates. Every input, original capture,
MusicXML and corrected public-fact artifact is verified against its retained hash.
All **31 target candidates become zero**, with no new candidate category or count.
This subset also contains the 47 metronome candidates already addressed by the
[earlier correction](musescore-metronome-boundary-audit.md). Consequently its total
is 79 before and one after, with the unrelated beam-header candidate unchanged.
These are subset observations, **not new original500 totals**. Older receipts and
all original bytes remain immutable; new research receipts stay outside Git.

The [Dynamic controls](../../scripts/research/musescore-dynamic-caption.test.mjs)
and [report controls](../../scripts/research/musescore-report-accounting.test.mjs)
contain **60 passing original cases**. They cover split words, hidden inheritance,
wrong/missing/reordered signs or prose, altered whitespace, wrong part/staff/clock,
source/public identity changes, duplicate carriers, cross-direction borrowing,
unqualified private glyph/font contexts, raw-size/default qualification, incorrect
counts, locations, messages and report dispositions. They contain no acquired
score excerpts. Positive and mutation expectations are authored independently of
production conversion.

```bash
qq-job -- node --test --test-concurrency=1 scripts/research/musescore-dynamic-caption.test.mjs scripts/research/musescore-report-accounting.test.mjs
```

Existing performer (387), current-primary (364), shared-beam (75), clock-reference
(96), pedal (48), rich-Dynamic (106) and line-role (74) calibrations also pass. These are
checker controls, not a newly run production regression suite, schema evidence,
visual acceptance or feature completion percentage. The next full assessment
must freeze the integrated production and checker together.


The content-only Dynamic route also admits native 3.02 / producer 3.6.1 with an absent or empty revision. This is independently bound to the pinned [3.6.1 XML caption loader](https://github.com/musescore/MuseScore/blob/d0fc8e9739092fd1a5a28b69c598917f7dae88ec/libmscore/xmlreader.cpp#L351) and [TextBase formatter](https://github.com/musescore/MuseScore/blob/d0fc8e9739092fd1a5a28b69c598917f7dae88ec/libmscore/textbase.cpp#L1628): outer literal whitespace survives; nested whitespace-only XML fragments are discarded; font selectors persist; canonical symbols and exact qualified ScoreText piano/forte glyphs have ordered musical content. Two original controls preserve exact prose spacing after a semantic forte and reject a changed sign. An adjacent unexamined producer remains outside this rule. This verifies content, ownership and visibility, not complete typography or source default families.

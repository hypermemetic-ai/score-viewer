# Binary Guitar Pro mixer facts

GP3–5 mixer program changes now retain their exact source clock as timed instrument contexts and standard MusicXML instrument declarations. They are synthesis patches, so a piano patch on a source guitar does not remove its strings, change written register or create a printed instrument-change caption. Concurrent contradictory patches at the same source clock refuse. Program values outside the encoded −1/no-change or 0–127 range refuse.

GP5 initial and changed tempo captions retain their original bytes, decoded literal text and visibility. The outer string length determines the captured caption extent. Numeric tempo targets remain standard metronome/sound facts. Mixer transition duration is retained in its exact native **beats** unit; no quarter-note duration, linear curve or authored accelerando words are inferred. This numeric mixer transition is excluded playback behavior, independently of the required printed target/caption. Negative durations refuse.

GP5 Wah values retain the explicit display bit and exact position. Standard words distinguish off (−2), open (0), closed (100) and intermediate positions; −1 declares no change. Hidden source instructions remain hidden. Intermediate positions use a derived readable numeric instruction rather than treating every value below100 as a literal fully-open state. Unknown values refuse.

The twelve-string track flag is a documented sound simulation; conversion keeps the actual encoded tuning vector and notes, without inventing a second set of physical courses. The distinct short-string banjo flag still requires qualified physical fret semantics.

## Source evidence

- The original Arobas Guitar Pro4 manual, printed page26, describes mixer changes and transition durations in beats; printed page15 describes twelve-string sound simulation separately from short-string banjo: [manual mirror](https://medias.audiofanzine.com/files/guitarpro-fr-477223.pdf).
- [PyGuitarPro GP5 source](https://pyguitarpro.readthedocs.io/en/latest/_modules/guitarpro/gp5.html) independently describes tempo captions, hidden tempo, the Wah display bit and value byte. Its [WahEffect model](https://pyguitarpro.readthedocs.io/en/stable/_modules/guitarpro/models.html) distinguishes −2/off, −1/no change and0–100 positions.
- The pinned borrowed reader captures the raw numeric fields; the original adapter captures exact caption spans before normalization. No upstream implementation was copied into the new projection helper.

## Finite verification

Original fixture mutations cover GP3 andGP5 timed program changes, unchanged physical pitch/register, standard instrument declarations, hidden tempo plus nonzero transition duration, negative-duration refusal, four Wah states and an invalid state, literal initial/changed captions, and the twelve-string simulation flag. Two combined mixer outputs exercise visible and hidden source states against the bundled MusicXML4 schema. These controls establish the exercised source-to-model/output mappings; they are separate from producer corpus coverage or human engraving acceptance.

# Metronome boundary audit correction

This is a finite checker correction following the frozen main assessment at
`6ba334a`. It changes no converter, model or MusicXML writer behavior. The
historical corrected audit still records 361 candidate diagnostics across 61
inputs; this note does not replace that epoch or claim a new corpus total.

## Attribution from retained evidence

All 47 `source-metronome-standard-boundary-words` candidates in the one affected
input were examined using the pinned original input, emitted MusicXML and saved
complete public facts. Each source-expected prefix agreed with the retained
literal prefix. Each had one matching metronome carrier at the source part,
measure, staff and rational clock. Its ordered before/after words reproduced the
exact prefix/suffix, and the metronome and words remained hidden as authored.

All 47 prefixes consisted of whitespace split across multiple styled words
nodes. The checker already accepted their exact concatenation in its stronger
ordered-boundary duty, but its additional boundary duty incorrectly required a
single words node to contain the entire prefix. The same structural error could
affect a suffix. This is a diagnosed checker false positive, not evidence that
hidden material may be discarded or whitespace normalized.

The [checker](../../scripts/research/musescore-corpus-performer.mjs) now compares
exact concatenation within the before/after words of the unique metronome
carrier and checks effective inherited visibility. Other directions cannot
supply missing text. The existing ordered payload, printed unit/dots/rate,
source owner/clock, public literal and visibility duties remain in place.
Ambiguous carriers do not receive this boundary pass.

## Original controls and verification

The [focused controls](../../scripts/research/musescore-metronome-boundary.test.mjs)
use independently authored source, output and facts. Both positive controls failed
under the old checker and pass after the correction. Sixteen controls cover split
prefix/suffix whitespace, explicit and inherited hidden visibility, missing and
reordered chunks, revealed text, incompatible payload, text borrowed from another
direction, wrong staff/clock/part, changed public literal/source owner and a
duplicate metronome carrier. No private repertoire is embedded in the controls.

Run with the project's supported Node >=24 runtime and existing dependencies
(this correction was checked on Node 26.7.0):

```bash
qq-job -- node --test --test-concurrency=1 scripts/research/musescore-metronome-boundary.test.mjs
```

All 16 focused controls passed. Existing performer (387), shared-beam (75),
clock-reference (96) and pedal (48) calibration controls also passed. The
current-primary calibration entry point initially failed at its existing `default6/8 MID
then AUTO groups retain source membership` control, with the same four
`source-shared-beam-*` diagnostic categories in both an untouched `983b962`
checker snapshot and the changed checker. The subsequent [fixture-scope
correction](musescore-default-beam-calibration.md) resolves that independent issue;
the initial metronome-only run was not reported as a wholly passing suite.

No production build, corpus conversion or corpus re-audit was performed for this
correction. Historical manifests, outputs, diagnostics and totals remain intact.

## Separate Dynamic visibility attribution

The six saved `performer-direction-content-visibility` candidates were also
examined at their source-owned clocks and staves. Two retained prose plus canonical
`sf`/`mf` components, one retained a qualified private ScoreText piano glyph plus
prose, and three retained canonical `mf`, `sf` or `ff` signs. Their semantic labels
and visibility are present in the saved MusicXML.

The fallback checker demands the original `other-dynamics` subtype or one
whole-caption `other-dynamics` string, so these valid semantic-sign/component
representations do not match. Its stronger rich-Dynamic route admits fewer
vocabularies and style contexts: the two paired captions use the 3.6.2 legacy-206
Edwin context, the private-glyph caption uses the legacy-301 FreeSerif context,
and the three named signs use 3.6.2 main-score style context without Dynamic font
overrides. These observations diagnose the six content/visibility false positives;
they do not resolve remaining font, frame or default-role unknowns.

A later bounded checker change should independently qualify the source glyphs
and ordered prose, then bind the complete semantic caption to one direction with
exact part/staff/clock and visibility. It must reject arbitrary text equivalence,
reordered or missing components, unqualified private glyphs and cross-direction
pooling. Existing original Dynamic fixtures in `test/musescore.test.ts` provide
starting shapes. This patch does not implement that separate checker change or
infer current corpus counts after the later rich-Dynamic production changes.

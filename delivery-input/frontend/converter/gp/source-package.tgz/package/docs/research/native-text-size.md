# Source text sizes and staff space

This implements ordinary text point-size projection and a separate source
presentation helper for TextLine, HairPin, and Pedal captions. It is not evidence
that musical glyph sizes or all source carriers are complete. Ordinary inline
size changes and script projection are covered separately below.
The source size request remains separate from the calculated interchange value.

## Source rule

The native text renderer multiplies a spatium-dependent size by the owning
element's staff space divided by a version-specific reference. Native 3 through
4.6 use `SPATIUM20`, five typographic points (127/72 millimeters). Native 4.7 uses
the style registry's default staff space, 1.75 millimeters. Source staff space
is serialized in millimeters. A staff-owned element also uses that staff's
active small/user magnification; a system-owned element uses score space.

Primary source anchors:

- [Native 3.6.2 text renderer](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/textbase.cpp), `TextFragment::font`; [unit constants](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/mscore.h), `SPATIUM20`, `DPI`, `DPMM`.
- [Native 3 staff ownership](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/element.cpp), `Element::spatium`; [staff scale](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/staff.cpp), `Staff::spatium` and `Staff::mag`.
- [Native 3 defaults loading](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/scorefile.cpp), `readStyleDefaultsVersion`; [registry and legacy resources](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/style.cpp), `resolveStyleDefaults`, `Sid::spatium`, and `MStyle::load`.
- [Native 4.6 renderer](https://github.com/musescore/MuseScore/blob/v4.6.0/src/engraving/dom/textbase.cpp), `TextFragment::font`, retains the five-point denominator.
- [Native 4.7.5 renderer](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/textbase.cpp), `TextFragment::font`; [registry](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/style/styledef.cpp), `Sid::spatium`; [style units](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/style/style.cpp), `defaultSpatium` and `Spatium` loading.

`text-size.ts` receives only the selected score's style scopes, in loading order,
and an explicit active staff or score context. It never derives staff scale from
an adjacent note, another part, or the parent of an independently selected view.
It records the source field, native unit dependency, reference, and staff scale.
The writer validates that those facts reproduce the calculated point size.
Default dependency flags establish units only; they do not invent a font family
or a size absent from the source. An explicit unscaled request keeps its original
decimal spelling.

The native renderer separately sizes music-font fragments, notably dynamics and
metronome symbols. This ordinary-text rule therefore withholds scaled Dynamic
or explicitly symbol-bearing captions. Their exact requests and located gaps
remain. Source inline size overrides have their own run-level treatment below; the
ordinary base-size projection alone does not establish that additional coverage.

## Line captions

The line helper binds BEGIN/CONTINUE/END face, size, and emphasis independently.
An explicit endpoint property overrides its selected line style. The temporary
TextLineBase caption starts as DEFAULT Text, including that style's size-unit
dependency; selecting the line's text style later only changes its identifier.
From native 4.1, a second line property can cancel the staff-space multiplier.
Both dependencies remain explicit in the calculated-size evidence. System text
lines lack the normal line dependency binding, so their value-initialized line
property is false; a similarly named unused style field supplies no authority.

Primary consumer and binding evidence:

- [Native 3 TextLineBase](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/textlinebase.cpp), constructor and `layout`; [TextLine bindings](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/textline.cpp), [hairpin bindings](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/hairpin.cpp), and [pedal bindings](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/pedal.cpp).
- [Native 4.0 TextLineBase](https://github.com/musescore/MuseScore/blob/v4.0/src/engraving/libmscore/textlinebase.cpp), caption layout retains the original temporary-text rule.
- [Native 4.1 layout](https://github.com/musescore/MuseScore/blob/v4.1.0/src/engraving/layout/v0/tlayout.cpp), `layoutTextLineBaseSegment`, adds the inverse staff-space factor when `textSizeSpatiumDependent` is false. The 4.2–4.6 layout consumers retain this rule.
- [Native 4.7.5 layout](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/rendering/score/tlayout.cpp), `layoutTextLineBaseSegment`; [TextLine style maps](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/textline.cpp); [plain style-identifier setter](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/textbase.h), `setTextStyleType`; [value initialization](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/property.h), `M_PROPERTY`.

The adapter must supply each endpoint's active staff context after resolving the
line. A staff change inside an interval cannot lend the beginning's scale to
its ending caption. Continuation typography is retained separately; this does
not invent system-break positions or repeated captions. Font families reach
standard words at the corresponding endpoints, with source ownership preserved.

## Verification

Original controls in `test/musescore-text-size.test.ts` cover old/new references,
small staff scale, score scope, selected style precedence, explicit unscaled
sizes, absent sizes, invalid units, legacy defaults, and tampered writer facts.
Existing style/presentation/font controls verify compatibility. Adapter contexts
and final corpus evidence are separate integration duties; no corpus receipt is
superseded by these unit controls.

## Ordered inline typography

Ordinary runs now retain inline font-size requests and script state separately
from their derived point-size projection. The native formatter reads only the
first property in a `font` token; closing `font` does not restore previous state.
Both native XML loaders preserve source attribute order. Closing either `sup`
or `sub` sets normal baseline, including inside another script wrapper.

Primary anchors are `createBlocks` and `TextFragment::font` in the native 3.6.2
and pinned 4.7.5 text renderer links above; native 3
[`XmlReader::htmlToString`](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/xml.cpp)
and native 4
[`XmlReader::htmlToString`](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/rw/xmlreader.cpp)
retain ordered attributes. The native 4
[attribute iterator](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/framework/global/serialization/xmlstreamreader.cpp)
walks `first_attribute` / `next_attribute`.

The exact source script size multiplier is 0.6. Native vertical displacement
also depends on the chosen font's x-height. The converter preserves script
meaning with an explicitly **derived readable layout**: +6 MusicXML tenths for
superscript, -4 for subscript, and 0 for a normal reset. These values are not
claimed as recovered native geometry. Absent base requests use named, located
native registry defaults only when needed to express a script's size ratio;
ordinary captions still do not acquire invented source size requests.

MusicXML words carry per-run point size and relative-y. Lyric text has no
relative-y attribute: the ordinary lyric lane retains transparent syllable text
and its standard syllabic/extension data, while located visible words carry the
scripted caption at the same staff, voice, and source clock. This does not claim
pixel identity or verse placement acceptance in a particular consumer.

Original controls in `musescore-inline-typography.test.ts` cover attribute order,
persistent size, nested script reset, default versus explicit size, source
staff scaling, ordinary versus music glyph runs, invalid requests, tiny decimal
serialization, and standard direction/lyric carriers. Music-font sizing and
adapter retention/report integration remain separate duties until verified.

Modern line size cancellation also has an ordered formatter effect. After
`layoutText`, the native line renderer calls `TextBase::setSize` when the line
is not spatium-dependent. `TextCursor::setFormat` selects all fragments outside
editing, so that reset uses the final cursor size for the entire caption. The
converter keeps original per-run requests and records a separate
`derived-native-line-reset` with the final source request. The ordinary script
ratio remains independent. This does not override modern independent musical
symbol size/scale properties, which have their own source rule.

# GPX terminal sector padding

The private, fixed GP technical-study cohort contained 13 BCFZ containers that
stopped in terminal padding. Twelve omitted one zero byte at the end of sector
storage. One completed its declared filesystem but stopped partway through an
extra zero literal. These are container compatibility observations, not evidence
that their musical features all convert.

The bounded decoder permits at most two absent terminal sector bytes and at most
seven zero terminal bits. It subsequently proves that every absent byte lies
outside all declared member data and directory metadata, in unused terminal
storage. It still rejects truncated member bytes, nonzero partial literals,
larger missing spans, invalid pointers and trailing compressed bytes. A second
reader, the pinned alphaTab `GpxFileSystem`, reads the **original compressed
input** and must return byte-identical members. No absent musical byte is filled.

`inputSource` retains the exact input and hash. `gpxSource` separately reports
`omittedSectorPaddingBytes` and/or `incompleteFinalLiteralPaddingBits`; its decoded
hash describes the sector buffer completed with unused zeros. The located
`gpx-terminal-sector-padding` finding explains that derivation. Existing complete
literal padding remains a separate fact.

Four original byte-authored tests cover complete members, literal-boundary and
within-literal termination, an incomplete extra literal, and refusals when the
same absent zero is actually a declared member byte. All 13 observed containers
pass this container check and agree with the independent reader. Their private
source bytes are not repository fixtures, and this does not waive later musical
admission or source-fidelity checks.

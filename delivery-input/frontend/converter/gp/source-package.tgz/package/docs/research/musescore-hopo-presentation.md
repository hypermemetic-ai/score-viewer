# Native H/P presentation

Explicit native `hopoUpperCase`, `hopoShowAll`, `hopoShowOnStandardStaves` and `hopoShowOnTabStaves` styles now control the located H/P captions. The selected source view supplies its own style scope. Lowercase labels remain lowercase; consecutive same-kind regions can share one visible label while retaining each technical connection. Per-view caption suppression does not hide source notes or the original slur. Source visibility and color still apply independently.

Authority is the pinned MuseScore 4.7.5 [region calculation and caption construction](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/hammeronpulloff.cpp) and [style defaults](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/style/styledef.cpp). All four default booleans are true. Exact native system-break label repetition remains consumer layout rather than invented musical endpoints.

Thirty focused native H/P, genuine producer and shared technique controls passed. New original controls distinguish case, repeated-label suppression and view-specific text visibility from the source slur; malformed/duplicate style definitions refuse. This does not yet certify arbitrary user-edited H/P segment text presentation or every TAB tied-fret display context.

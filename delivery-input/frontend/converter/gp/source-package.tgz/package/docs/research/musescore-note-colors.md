# Authored notehead colors

This bounded D43 implementation preserves explicit native MuseScore `Note/color`
RGBA values and source locations. It does not assign a musical meaning to the
color or infer highlights from unused style defaults.

The public note fact gains optional `noteheadColor`, using the existing located
`SourceColor` representation. The writer uses the standard MusicXML
[`notehead` color attribute](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/notehead/),
with alpha followed by red, green and blue. An otherwise ordinary head receives
the standard `normal` value. Existing shaped/dead heads keep their shape. The
note, stem, adjacent chord components and rests are not recolored.

Source visibility and source alpha are independent: a hidden note retains its
RGBA values while its MusicXML note still has `print-object="no"`. Identical
repeated colors retain every source location and project once; contradictory
repetitions or malformed channel data refuse rather than choosing a value.

[Original controls](../../test/musescore-note-colors.test.ts) cover native
serializer profiles 3.01, 3.02, 4.00 and 4.70, chord-component ownership, untouched
pitch/timing, hidden diamond heads, explicit alpha, independent neighboring
colors, immutable public facts and malformed/contradictory inputs. These are
independently authored source studies, not genuine producer exports or a visual
acceptance result. Other authored-color owners and annotations remain separate
contract work; this does not certify general color/highlight coverage.

Verification on Node 26.7.0: all four focused tests passed; the integrated suite
passed 562/562. The four color source variants also passed the offline MusicXML
4.0 schema check within 736 validated outputs using existing lxml 5.2.1.
Packed public API/CLI/type checks passed. No native viewer rendering was checked.

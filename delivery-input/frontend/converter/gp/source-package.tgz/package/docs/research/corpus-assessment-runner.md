# Reproducible private corpus assessment

The [assessment runner](../../scripts/research/corpus-assessment.mjs) freezes one
production and independent-checker epoch, then records one asynchronous public
`convertMuseScore(bytes)` call per selected input with default main view and all
parts. An explicit selection `"format": "guitar-pro"` instead records one public
`convertGuitarPro(bytes)` call with all tracks. An omitted format retains the
MuseScore route. It adds no converter behavior, dependency, application export or source
checker interpretation. Candidate diagnostics need source attribution; they are
not automatically converter defects. Schema validity and strict source-checker
flags are separate from performer acceptance.

## External selection

Keep inputs, manifests and outputs outside every Git checkout. Supply a JSON file:

```json
{
  "schema": "score-converter-corpus-selection/1",
  "coverage": "Describe repertoire, producer versions and missing feature coverage.",
  "cases": [
    {
      "id": "original-001",
      "input": { "path": "/private/corpus/source.mscx", "bytes": 123, "sha256": "64 lowercase hex characters" }
    }
  ]
}
```

IDs and input hashes must be unique. Order and denominator stay fixed. A newer
serialization of a score belongs in a separate compatibility selection; it does
not add a unique score to the repertoire count. Retain the established original500
selection when assessing that milestone. Conversion success cannot establish
missing guitar/bass techniques, percussion or other coverage absent from a corpus.

## Run one epoch

Use Node 24 or later and existing installed dependencies matching the repository
lockfile. Preparation requires the chosen commit to be checked out with unchanged
tracked source, tests and research checker. It copies those files, records existing
dependency bytes, builds the copied source with the installed TypeScript/esbuild,
and freezes production, runtime dependencies, schemas, independent checker and
assessment controller. Existing `dist` is never reused. The assessment runner may
be an additive research change beyond the chosen production commit; its exact
bytes are separately pinned. No package installation or download occurs.

Run every heavy stage through the host resource launcher when available. These
commands use shell variables assigned to your private paths:

```bash
qq-job -- "$NODE" scripts/research/corpus-assessment.mjs prepare "$SELECTION" "$NEW_EPOCH" "$COMMIT"
# Save the printed epoch path and SHA-256, then use its frozen controller.
qq-job -- "$NODE" "$NEW_EPOCH/runtime/scripts/research/corpus-assessment.mjs" collect "$NEW_EPOCH/epoch.json" "$EPOCH_SHA"
qq-job -- "$NODE" "$NEW_EPOCH/runtime/scripts/research/corpus-assessment.mjs" schema "$NEW_EPOCH/epoch.json" "$EPOCH_SHA" "$SCHEMA_PYTHON"
qq-job -- "$NODE" "$NEW_EPOCH/runtime/scripts/research/corpus-assessment.mjs" audit "$NEW_EPOCH/epoch.json" "$EPOCH_SHA"
```

`SCHEMA_PYTHON` is an absolute path to an existing Python with lxml. The schema
observer resolves only the pinned local MusicXML schemas, disables network and
external entity loading, and records actual Python/lxml/libxml versions. It makes
no conversion calls. A schema failure remains in its results and does not become
a successful validation.

Collection and audit are sequential fresh processes, with a 120-second outer
process guard and unchanged product Worker limits. Full returned envelopes and
available XML/public facts are retained before identity assertions, schema checks
or source audits. Refusals remain in the denominator. Product timeouts, Worker
failures, resource refusals, generic unclassified refusals, runtime exceptions,
outer timeouts and harness/identity failures remain distinct retained outcomes.
Returned product failures remain in the cohort and collection continues; thrown
invocation, outer-process and harness failures stop with the unattempted count.
Existing epoch/stage directories
are rejected even after partial failure: there is no automatic retry, resume,
overwrite, input substitution or success filtering. Investigate failures before
authorizing a separately named epoch.

Guitar Pro collection retains the entire score as its facts artifact, validates
the captured original bytes and explicit fretted/arrangement score kind, and uses
the same immutable collection and offline schema stages. Its musical study must
separately bind source expectations to output; the native MuseScore source checker
cannot certify Guitar Pro. Calling that checker for a Guitar Pro epoch fails
before creating an audit stage. Neither schema success nor retained source facts
alone establishes performer fidelity.

The audit uses `auditCurrentPrimarySource` from the frozen checker epoch. Its compact public facts
start with `publicPerformerFacts`, adding five verbatim event-owner fields from the
complete score: grace, time modification, print visibility, source stem visibility
and source hook. This closes omissions in the exported compact collector; it
does not change the checker or infer musical facts. The runner
retains its complete objects and the existing 23 source-role callback streams,
and reports candidate, unknown and projection-limit groups separately. Plain source
bytes come from the independently hash-pinned input; the returned primary member
must agree with that input. Callback
counts overlap and must not be summed as distinct musical duties.

For MSCZ, the [independent container reader](../../scripts/research/musescore-independent-container.mjs)
reads the hash-pinned original archive, checks central/local records, descriptors,
CRC, decompression consumption and resource limits, and selects the primary from
its original `META-INF/container.xml`. Returned converter bytes never supply
source authority. Every captured member and the selected primary must agree with
the independently decoded original. A uniquely declared `score_style.mss` must
have the primary native version; its exact bytes reach the independent checker's
existing external-style/embedded-style precedence. Undeclared style members do
not become applied defaults. The receipt records archive, declaration, primary,
all member and applied-style hashes without writing extracted files into the
source tree. Missing/ambiguous declarations, unsupported archives or altered
capture produce an audit failure, not successful source verification. Boundaries
are 32 MiB input/member, 64 MiB total expansion, 2,048 members, a 256:1 expansion
ratio and separately bounded declaration/style XML; ZIP64, encryption, symlinks
and ambiguous member names are not admitted.

This removes the old runner's blanket `audit-unsupported-container` for admitted
MSCZ. It establishes source extraction and binding, not complete musical fidelity
or general style-default verification. Unknown effective style roles remain
unknown. Original500 is plain MSCX and its historical results are unchanged.
Original-bound application exports can remain secondary evidence; this runner
does not repeat or reinterpret them.

Use `collect-summary.json`, `schema/results.json` and `audit-summary.json` together,
always naming `epoch.json`'s source/checker/controller identities. Never splice
later subset proofs into a fresh global count. API timing excludes retention;
fresh-process RSS includes imports/preflight/Worker and retention RSS is cumulative.
Research audit and schema costs are separate. Budget disk space for complete
envelopes, facts and callback streams; original500 previously required several GB.

## Runner controls

```bash
qq-job -- "$NODE" --test --test-concurrency=1 scripts/research/corpus-assessment.test.mjs scripts/research/corpus-assessment-mscz.test.mjs
qq-job -- "$NODE" --test --test-concurrency=1 scripts/research/musescore-independent-container.test.mjs
```

These controls build and freeze actual source, exercise an original TAB fixture
and unsupported serializer refusal, validate emitted XML, run the independent
saved-source audit, and reject duplicate IDs/hashes, input mutation, manifest
tampering, frozen-runtime mutation and replay. The tests require existing build
dependencies and schema Python; they do not download anything. The MSCZ controls
also freeze original producer archives, audit their independent primary/style
selection, preserve the old audit during a zero-conversion saved correction and
reject mutation of the separately frozen extraction helper. The independent ZIP
controls use an original test encoder plus committed original producer archives;
they test stored/deflated streams, signed/unsigned descriptors, central order,
source substitution, malformed identities, resource bounds and style precedence.

The independent container suite passes **45 controls** and the combined frozen
runner suites pass **5 controls** on Node 26.7.0. These original fixture runs do
not replace the historical private corpus epochs or certify musical completeness.

## Correcting saved audit facts without conversion replay

When a collector omission is found after collection, preserve the entire original
epoch, collection and raw audit. Freeze a separate additive controller and manifest:

```bash
qq-job -- "$NODE" scripts/research/corpus-assessment.mjs prepare-saved-audit "$EPOCH" "$EPOCH_SHA" "$CORRECTION_DIR"
qq-job -- "$NODE" "$CORRECTION_DIR/corpus-assessment.mjs" audit-saved "$CORRECTION_DIR/correction.json" "$CORRECTION_SHA"
```

Use the manifest hash returned by preparation. The saved-only manifest pins the
original epoch and complete collection summary, the new controller, original
denominator and zero public calls. The extraction helper is copied and hash-pinned
beside the corrected controller; its XML parser comes from the original frozen
runtime dependencies. It uses the original pinned Node, source runtime
and independent checker. Each fresh process verifies the original input, envelope,
XML and old facts pins, derives complete facts from the retained score, saves them
under the correction directory, and audits against the separately pinned original
source. Refusals remain in the denominator. Outputs cannot overwrite or replay an
existing correction stage; report both the initial collector-limited audit and
corrected audit identities. This path does not import or call the converter.

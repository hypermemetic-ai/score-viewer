# Native font-character preservation

This is minimal source-field preservation for `FSymbol`, separate from canonical
SMuFL `Symbol` recovery. It does not assert a musical role or successful native
owner reload. The source character, literal font label, explicit point size,
visibility, color, parent group and note/rest/direction/frame ownership remain
inspectable. No font assets, codepoint-to-SMuFL table or dependency is added.

## Source authority

MuseScore 3.6.2 commit `3224f342d12f4af8ea782e929c49f5ce85f97da6`,
[`libmscore/symbol.cpp`](https://github.com/musescore/MuseScore/blob/3224f342d12f4af8ea782e929c49f5ce85f97da6/libmscore/symbol.cpp),
`FSymbol` constructor/read/write/draw/layout, establishes code default zero,
`font` as the literal family, `fontsize` as font point size and `code` as a signed
integer read into the character-code field. Supplementary codepoints are drawn
as UTF-16 surrogate pairs; this is one character, not two musical symbols.

MuseScore commit `3654226c2e99289916916953a98e585a3d3b315a` retains the same fields:

- [`read460/tread.cpp`](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/rw/read460/tread.cpp), `TRead::read(FSymbol*)`, assigns literal family with font type Unknown, font point size and integer code.
- [`dom/symbol.cpp`](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/symbol.cpp), `FSymbol::toString`, converts the one codepoint to text; constructor default is zero.
- [`write/twrite.cpp`](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/rw/write/twrite.cpp), `TWrite::write(FSymbol*)`, serializes the three fields.
- [`rendering/score/tdraw.cpp`](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/rendering/score/tdraw.cpp), `TDraw::draw(FSymbol*)`, draws its font and character with source color. This explicit point-size field is independent of the four-staff-space `Symbol` em law.

An important source inconsistency prevents a producer preservation claim:
`TRead` parses a nested FSymbol and calls `BSymbol::add`, but
[`dom/bsymbol.cpp`](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/dom/bsymbol.cpp)
only accepts `isSymbol()` or `isImage()` children. Modern measure/note/rest/box
read branches likewise name Symbol rather than FSymbol. These facts qualify
our recovered annotation; they do not justify dropping its unambiguous fields.
Every recovered FSymbol receives `native-font-character-preservation` explaining
that native owner reload is not asserted.

## Standard output and limits

[MusicXML words](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/words/)
and [other-notation](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/other-notation/)
carry the literal Unicode character with independent font-family, point size and
color. Initial frame annotations use credit-words. Exact source facts also remain
in standard miscellaneous fields. A PUA character stays that character in its
source font; it is never interpreted as a standard clef, articulation or action.
The source font is a hint, not an asset or a promise that the receiving machine
has it. No font default is invented when the source omits one.

MusicXML font-family is a comma-separated list; a source literal containing a
comma stays auxiliary with a located finding rather than becoming several
invented fallback families. Nonpositive stored point sizes remain auxiliary
without selecting a runtime default. XML 1.0 cannot represent NUL, surrogates,
U+FFFE/U+FFFF or out-of-Unicode codes: these retain their exact signed source code,
font and owner in auxiliary facts plus a hidden U+ annotation, never a fabricated
visible replacement glyph. Carriage return is a numeric character reference so
XML newline normalization cannot change its identity. Nested Symbol/FSymbol
order and parent IDs remain explicit; exact group offsets are excluded geometry.

## Verification and provenance

Four original helper/writer controls independently specify supplementary and PUA
characters, literal family, point size (unaffected by staff magnification)
and visibility/parent ownership, XML-sensitive scalars, native default zero,
invalid/unrepresentable codes, malformed scalar controls and contradictory model
facts. Together with the eight canonical glyph controls they pass. Five combined
standard documents exercise directions, attached notes, rests and initial credits;
all pass MusicXML 4.0 XSD validation with lxml 5.2.1. These establish semantic and
schema behavior, not consumer font availability or visual equivalence.

A bounded search found no FSymbol in the frozen 500 native originals or five
pinned upstream studies (`symbol-1`, `symbol-2`, `symbol-size`,
`music-symbol-scale`, `parts_data/part-symbol`). This is not evidence of general
native absence. No acquired payload was committed.

An original three-character study (SHA-256
`1e8d70c14892f9f77e97e19d11205261d4e77a898a8839b5902e1db519b7453f`)
used Edwin/A/18.25pt, Bravura/U+E050/24pt and FreeSerif/U+1D11E/21pt as nested
FSymbols. MuseScore 4.7.5 save, reload and exports exited successfully but the
saved MSCX retained only the parent coda Symbol and discarded all three FSymbols.
That is negative round-trip evidence consistent with the source attachment rule;
it is not a positive producer fixture or visual preservation proof. Operational
receipts and producer outputs remain private outside Git.

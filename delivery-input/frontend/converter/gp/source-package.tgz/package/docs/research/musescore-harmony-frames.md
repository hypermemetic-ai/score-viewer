# Native harmony and chord-frame recovery

This is a finite implementation proof for `src/adapters/musescore/harmony.ts`, not a whole-corpus or native-application acceptance claim. The parent MuseScore reader owns admission, source accounting, clocks, profiles and the public conversion path. The helper receives those services; it never parses another score, changes note pitch or estimates a chord from played notes.

## Encoded source facts

The independent reader uses these primary format facts:

- [MuseScore 3.6.2 Harmony serialization](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/harmony.cpp) owns root/base tonal pitch classes, a name, optional catalog extension and degree operations. Root and bass spelling use the native circle-of-fifths TPC encoding. The hidden leading `=` qualifier means minor; it is not printed literally.
- [Current pinned Harmony serialization](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/rw/write/twrite.cpp) permits ordered `harmonyInfo` components and uses `bass` inside each component. Components remain separate; they are not merged into a guessed chord.
- [MuseScore 3.6.2 FretDiagram serialization](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/fret.cpp) writes a lowercase `fretDiagram` as the authoritative newer body, followed by compatibility data for older readers. Native string zero is the leftmost, lowest string. Dot fret numbers are relative to `fretOffset`; the first displayed fret is offset plus one. Modern dots and barres are separate objects. Older direct strings use integer dot positions and ASCII marker values.
- [Pinned modern frame layout](https://github.com/musescore/MuseScore/blob/3654226c2e99289916916953a98e585a3d3b315a/src/engraving/rendering/score/tlayout.cpp) places `fretFingering` vector entry zero on the highest string, independently of the dot-index order. The source display flag is separate from the encoded numbers. Missing frame dimensions use effective native styles, then the documented six-string/four-fret defaults.
- [Source chord definitions](https://github.com/musescore/MuseScore/blob/v3.6.2/libmscore/chordlist.cpp) can supply an explicit MusicXML kind and degree strings. These source definitions take precedence over conventional label recognition. A numeric identifier alone does not generally establish a quality; stock identifier 1 with the stock chord files is the verified major exception.

No upstream implementation or style resource is copied into the package. Tests are original XML studies, not files saved by an application or corpus material.

## Preservation

The helper preserves root and bass spellings, common explicitly named qualities, custom literal quality labels, degree operations, functional labels, root/bass letter case, whole-label parentheses, component ordering and source staff/voice/clock placement. Unknown quality text remains literal performer text instead of acquiring an invented tonal analysis. Explicit source chord definitions may establish a structured quality independently of its displayed name. Source playback realization settings are excluded.

Frame facts retain string count, fret count, first fret, source dot positions, open and muted markers, ordinary fingerings, and barres. Barre interior strings have actual fretted positions supported by the encoded barre, so an `unplayed="x"` frame cannot accidentally print mute marks inside a barre. Nested chord visibility and frame visibility/color are independent facts. The shared writer owns standard MusicXML projection, including independent hidden fingerings and mixed muted/unmarked strings.

[MusicXML frame](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/frame/) has one shared unplayed-string mark. Mixed explicitly muted and unmarked unused strings therefore need a plain muted-string instruction alongside a frame with blank unplayed markers; no fictitious open string is added. [Frame notes](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/frame-note/) also require at least one played note. Empty or wholly muted native diagram geometry has no faithful standard frame representation; the helper records that limit, preserves any chord label and explicit muted-string instruction, and does not invent a frame note. MusicXML has no frame-dot shape vocabulary for native square/triangle/cross dots; positions survive and the shape limitation remains located.

Unresolved external catalog identifiers, conflicting bass identities, duplicate string owners, out-of-range frets, contradictory muted/sounded strings and malformed barres refuse. A fingering attached only to an unplayed string is preserved as an independent string-numbered performer instruction, including source visibility and color; no played note is fabricated. Empty-frame annotations do not replace the nested chord quality. Native layout style, source catalog and unknown-element accounting remain the parent reader's responsibility.

## Verification

`test/musescore-harmony-reader.test.ts` contains eleven original positive/control tests. They exercise flat/sharp spelling, slash bass, degree operations, hidden/below ownership, Roman versus literal labels, ordered components, modern and legacy frames, shifted frets, reverse string numbering, frame styles, custom source catalog kinds, high-string-first fingering vectors and empty/all-muted frames. Negative controls include invalid TPC, unresolved catalog quality, multiple bass definitions, invalid degrees, out-of-range dots/strings, duplicate string owners, muted/sounded contradiction and reversed barre endpoints.

TypeScript build and the eleven focused tests pass in the isolated implementation checkout. Public-route integration, coupled suite and output schema validation belong to the integrating parent task and must be recorded separately after they run. These tests do not establish native application import/rendering acceptance or corpus coverage.

## Independent catalog and component audit

The follow-up `scripts/research/musescore-harmony-extended-audit.mjs` derives
expectations from the original score's ChordList, Harmony and ordered harmonyInfo
records. It imports no production parser, model rule or writer. The primary
score root supplies the actual catalog; a catalog from another selected view is
never substituted. The source format authority remains `ChordDescription::read`
and `write` in the pinned 3.6.2 chordlist source, and `readHarmonyInfo`,
`TRead::read(Harmony*)`, `writeHarmonyInfo` and `TWrite::write(Harmony*)` at modern
commit `3654226c2e99289916916953a98e585a3d3b315a`. Catalog `xml` and degree records
establish tonal semantics independently of a possibly misleading lexical name.
Modern component order comes from repeated harmonyInfo records; owner-level
legacy degree records remain separate from each catalog's degree list.

Thirteen new independent controls exercise ten source/public/output combinations
and three mutation/negative families: numeric catalog authority, named aliases,
ordered structured polychords, unknown-quality literal polychords, functional
analysis, Roman text with explicit analysis type, parentheses and explicit
native degrees, qualified stock major, decorated labels and hidden RGBA.
Mutations change root/case/quality text, degree amount/type/cardinality, component
identity/order and public source origins. Unfamiliar catalog grammar remains
explicitly unexamined, so a successful conversion cannot certify unseen fields.
Together with the four existing ordinary/producer controls, all 17 pass. Five
combined MusicXML 4.0 schema documents also pass. The existing two-chord native
4.70 producer fixture supplies genuine ordinary-harmony evidence; the extended
catalog/polychord combinations are original studies, not additional producer
exports. Spelling/capitalization style rules and broad consumer visual acceptance
are separate from this finite source grammar audit.

## Native chord note names and capitalization (2026-10-14)

`harmony-naming.ts` now projects native standard, German, full German,
solfège and French chord note names. The tonal root/bass spelling remains
independent of its printed name. Full German suffixes (Cis, Es, B, Heses)
occupy MusicXML `root-step/@text` / `bass-step/@text`; the corresponding
numeric alter remains present with `print-object="no"`. Other language
names retain ordinary printed alterations. Literal fallback captions use the
same source language and case rules, including every ordered chord component.

Authority is pinned MuseScore 3.6.2
`3224f342d12f4af8ea782e929c49f5ce85f97da6` (`libmscore/harmony.cpp`,
`pitchspelling.cpp`, `style.cpp`) and modern
`3654226c2e99289916916953a98e585a3d3b315a`
(`src/engraving/dom/harmony.cpp`, `pitchspelling.cpp`, `chordlist.cpp`,
`src/engraving/layout/harmonylayout.cpp`, `src/engraving/style/style.cpp`
and `styledef.cpp`). `ChordDescription::complete` derives capitalization
quality from its first caption, independently of a catalog's explicit XML kind;
this distinction is tested with a deliberately conflicting augmented XML kind
and minor caption. MusicXML 4.0's `harmony-alter` documentation explicitly
permits alterations in the preceding step text with hidden numeric alters.
No source implementation, font, rendering list or asset was incorporated.

The native default is automatic capitalization on. Explicit typed case only
controls display when it is off. Minor, diminished and half-diminished lexical
qualities, bass lowercasing and all-capital solfège labels follow the source
rules. Pre-4.60 styles use the original fixed-priority Boolean spelling flags;
4.60+ migrate true legacy flags in source order into `chordSymbolSpelling`.
Later style scopes override earlier fields. Duplicate, malformed or unknown
style values refuse. `sourceNoteNaming` retains located authored fields,
resolved profile/language/case, and standard miscellaneous metadata, separately
from the unchanged tonal identities. Custom catalog glyph positioning remains
outside the accepted exact-page-geometry scope; a font shape is not tonal proof.

Original controls cover all five spelling systems, double flats/sharps,
language-specific accented names, source/default capitalization, first-catalog
caption authority, scope precedence, version migration and negative style
controls. The independent audit imports no production naming logic and checks
literal captions, tonal spelling, step text and alter visibility separately;
it leaves unfamiliar custom capitalization grammar unexamined. Mutation
controls change language text and remove hidden-alter flags while preserving
pitch, proving that tonal equality alone is insufficient. Genuine producer
coverage for these new styles is separate from the existing two-chord ordinary
4.70 producer fixture; no broader producer claim follows from the original
controls.

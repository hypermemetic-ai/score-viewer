# Native conversion work budget

The public native worker retains its 384 MiB JavaScript heap limit and all existing input, node, event, capture and output limits. Its finite elapsed-time allowance is 20 seconds. Single-child XML lookup scans without allocating a temporary filtered array and retains the same duplicate/missing-child refusals.

The unchanged original-500 assessment at `0f05a88` exposed two valid large quartets timing out at the previous 10-second deadline. The largest input is 26,290,351 bytes, SHA-256 `bfe863a25879245f4847ca08f6d382d85c9c7d9166c8d5d7fddd763b72c8d9f8`, with 616,684 XML nodes and 22,759 events. A separately recorded public-boundary diagnostic with the revised deadline converted it in 13,483 ms, producing 8,577,200 bytes, with reported peak RSS 963,984 KiB. RSS includes native buffers and is not the JavaScript heap limit. This is an admitted finite workload, not evidence for removing resource bounds or for a causal speedup from one timing sample.

The original timeout receipts remain unchanged. A fresh committed corpus epoch must supply final conversion and fidelity evidence. Twenty-one native boundary, malformed-input, cancellation, producer and figured-bass checks pass with the revised budget.

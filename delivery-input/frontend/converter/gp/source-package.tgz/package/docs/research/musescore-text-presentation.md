# Explicit text presentation and remaining style duties

This implementation follows D41–D43. It does not certify all text styles or the
whole performer contract. The reader integration and final unified corpus remain
separate evidence from the helper/writer controls below.

`readNativeTextPresentation` recovers explicit owner family, font emphasis,
boolean emphasis, color, requested size and plain-caption frame shape without
requiring a recognized caption meaning or an exact producer build. Source
properties remain located. Native 4 strike vocabulary stays separate from the
older emphasis mask. A later full mask supersedes earlier individual flags;
later flags change their own bits. Conflicting or structured properties remain
reported instead of selecting an arbitrary value.

`applyNativeTextPresentation` preserves existing inline-family uncertainty and
stronger source-qualified unit evidence. Source scalars are counted before being
consumed, so the caller can avoid counting already recovered fields twice.
An explicitly unscaled size supplies a nominal point-size hint; absent/scaled
units retain the request without inventing an effective point size. Font hints
are requested families, not promises that the receiving application has them.
The source size calculation and independent staff magnification are visible in
[pinned TextFragment::font](https://github.com/musescore/MuseScore/blob/3224f342d12f4af8ea782e929c49f5ce85f97da6/libmscore/textbase.cpp#L783).

Standard words, rehearsal marks, named dynamics, lyrics and first/between-measure
credits carry their supported font properties. Lyric RGBA stays on the lyric,
including its extension stop; unequal endpoint colors cannot coalesce. Hidden
lyrics retain alpha separately from `print-object`. For direction/credit text,
which lacks that visibility switch, transparent standard color hides the text
while the model keeps the source RGBA.

## Frames are not text color

A native border and background are separate from caption color. The source draws
a frame only when enabled, uses foreground color for its pen and nontransparent
background for its brush, then draws the caption with text color. See the pinned
[draw operation](https://github.com/musescore/MuseScore/blob/3224f342d12f4af8ea782e929c49f5ce85f97da6/libmscore/textbase.cpp#L2865).

MusicXML 4.0 `enclosure` supplies a shape. Its `text-formatting` and `dynamics`
types supply text color but no independent enclosure border or fill color:
[local schema](../../third_party/musicxml-4.0/musicxml.xsd). Global engraving
`line-width` can request enclosure width, but cannot associate a differently
colored border/fill with one caption. An external image is a graphic carrier,
not these independent attributes on standard text; rendering a replacement
native frame and its font metrics is not required by D41. Exact border/fill
colors therefore remain separately located facts with an explicit standard-text
presentation limit; they never recolor the caption. This conclusion does not
waive shape, text, font, color, visibility or ownership.

Plain words/rehearsals/dynamics/credits can preserve an authored none/rectangle/
circle enclosure. A zero-width or transparent outline does not become a visible
box. A single frame around mixed words/symbols needs separate capability evidence:
we do not manufacture separate boxes around each run or call that whole-caption
preservation. The writer rejects that accidental multiplication.

The independent audit now leaves embedded and external frame colors unresolved
unless actual effective-source evidence handles them. A lexical `FrameFgColor`
or `FrameBgColor` suffix no longer establishes a geometry exclusion. An embedded
property can supersede an external property without proving emitted fidelity.

## Evidence and remaining work

Original helper/writer controls cover ownership, RGBA and hidden alpha, melisma
colors, requested and unscaled sizes, first and later credits, explicit mask/flag
ordering, repeated/conflicting properties, plain frame shapes, suppressed outlines
and split-frame refusal. Independent checker controls exercise embedded/external
frame colors and precedence without importing the converter.

Effective inherited style selection, scaled font units, rich-caption frame
association, superscript/subscript, and source glyph/font interpretation retain
their own obligations. Unknown caption meaning alone does not justify dropping
literal text or explicit supported presentation. Final source-to-standard
verification must exercise the integrated reader hooks and selected source views;
helper-level passing tests do not establish that integration.

At the helper/writer checkpoint, 593 production tests and the package check pass.
The separate original schema control validates five new text carriers using
`SCORE_CONVERTER_SCHEMA_PYTHON=/usr/bin/python3`; it does not add Python or lxml to
the ordinary package-test requirements. The integrated native-reader tests and
final assessment must be recorded at their own later epoch.

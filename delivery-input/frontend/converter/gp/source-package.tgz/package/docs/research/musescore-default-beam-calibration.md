# Historical default-beam calibration scope

The historical `defaultBeamMembershipCalibrationControls` family uses sparse
public event facts to exercise its finite 6/8 default-grouping audit. Later,
`auditCurrentPrimarySource` also enabled the independent shared-beam graph audit,
which requires complete event locations, duration/type, note-component owners,
beam graph and source-mode/stem provenance. Those facts were absent from this
older fixture family.

The first fixture consequently produced 18 diagnostics in four
`source-shared-beam-*` categories despite its correct authored MusicXML. This
failure reproduced with the untouched `983b962` checker before the separate
[metronome boundary correction](musescore-metronome-boundary-audit.md). It was a
fixture/audit scope mismatch, not evidence of a production beaming regression.

The fixture base now explicitly selects `sharedBeamGrouping: false`, an existing
audit option, for this historical family only. Its intended source grouping,
clock, ownership, stem and negative controls remain active. Production behavior
and ordinary/full audit defaults are unchanged. The separate complete-fact
shared-beam calibration retains all 75 controls.

## Evidence and controls

Four [regression tests](../../scripts/research/musescore-default-beam-calibration.test.mjs)
verify the scoped historical fixture, rejection of its incomplete facts by the
ordinary full audit, the complete current-primary control entry point, and the
separate shared-beam calibration. In particular, the full audit still requires
all four previously failing evidence categories; this correction does not waive
missing public provenance in real assessments.

After correction, all existing calibration entry points pass:

| Calibration | Passing controls |
| --- | ---: |
| Current primary | 364 |
| Performer comparison/source | 387 |
| Shared beam grouping | 75 |
| Clock reference | 96 |
| Pedal closing | 48 |
| Total | 970 |

The four focused regression tests also pass. Run them with Node >=24 and existing
dependencies (this correction was checked on Node 26.7.0):

```bash
qq-job -- node --test --test-concurrency=1 scripts/research/musescore-default-beam-calibration.test.mjs
```

Separately, the unchanged production source at `983b962` was compiled with the
existing locked tools and given this one original miniature through the public
`convertMuseScore` default route. Conversion succeeded. The complete returned
facts and emitted MusicXML passed the full independent source audit with zero
candidate diagnostics and zero unknowns: six eighth-note owners retained their
3+3 beam groups, the first group's source-forced upward stems, exact clocks and
six note-component owners. This is fresh finite production evidence, separate
from the authored calibration expectations; it is not a new corpus baseline or
a general physical-layout certification.

No private corpus input was reconverted or re-audited. Historical assessment
manifests, results and totals remain unchanged.

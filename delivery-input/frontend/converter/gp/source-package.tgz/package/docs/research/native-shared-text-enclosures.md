# Shared text enclosure qualification

One source frame around mixed text is a distinct requirement from one frame per
run. The converter preserves the complete literal caption, a single source
enclosure, ordered source runs and a located qualification. Uniformly formatted
ordinary runs can use one standard words carrier with their exact formatting.
A single canonical symbol can use one enclosed symbol carrier.

For heterogeneous runs, MusicXML 4.0 does not define a portable way to assert one
shared box around differently formatted siblings. The standard permits multiple
formatted words/symbol children, but the enclosure attribute belongs to the
children. The specification group's [discussion 518](https://github.com/w3c-cg/musicxml/discussions/518)
and [issue 519](https://github.com/w3c-cg/musicxml/issues/519) explicitly identify
the undefined single-box versus multiple-box interpretation and differing
consumer results. The issue remains open at this review. This is a specific
format/consumer ambiguity, not a lack of an attribute on just one carrier.

The bounded fallback emits one complete literal caption with its one enclosure.
Exact ordered emphasis, family, size, script and glyph facts remain in the public
model and a standard `miscellaneous-field` keyed to that caption. The report
states that the mixed formatting inside the frame is not portably projected.
It does not duplicate the caption or manufacture a separate box per run.
Frame border/background colors remain separate from caption color; no source
border color is reassigned to the text.

Relevant standard definitions are
[words](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/words/),
[direction-type](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/direction-type/),
and [credit-words](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/credit-words/).
They use scalar formatted content, rather than an inline rich-text container.
Image embedding would require a separate font/layout renderer and would replace
editable text with artwork; it is not evidence that the current interchange
defines an equivalent text grouping rule.

Original public controls cover a uniformly bold framed caption, three mixed
runs inside one frame, and a framed custom Dynamic with its separate hidden
semantic carrier. A writer mutation control continues to reject unqualified
mixed-frame data. This qualification does not assert exact native rendering or
that auxiliary metadata alone completes the visual formatting duty.

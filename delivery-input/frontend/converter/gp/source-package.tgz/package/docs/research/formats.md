# Structured input formats

Research carried over from 2026-10-07, with automatic-route and version-coverage findings updated on 2026-10-09. Sources below establish format or tool capabilities, not tested local adapter fidelity. **Bounded GP3–GP8 conversion is implemented; the authorized independent native MuseScore reader remains in implementation. Other families remain candidates.** Candidate status must not appear as supported-format product copy. See the [proof record](../guitar-pro-proof.md) for admitted scope and the [family trials](guitar-pro-family-trials.md) for historical candidate evidence.

## Input families

| Family | Candidate inputs | Route and value | Main open work |
| --- | --- | --- | --- |
| MusicXML | `.musicxml`, legacy `.xml`, `.mxl`; partwise/timewise forms | Converter destination. Existing MusicXML input belongs to consumers, outside this task | Downstream version/profile coverage and MXL unpacking are separate consumer work; no XML-to-XML adapter is planned |
| MuseScore native | `.mscx`, `.mscz` | Authorized independent versioned reader being implemented; the application remains a comparison oracle | Native versions/defaults, excerpts/assets, full repertoire fidelity and performance validation remain open |
| MEI | `.mei` and MEI XML | Explicit musical and editorial encoding; consider a defined Basic/CMN profile | Broad schema modularity; profile, export mapping and editorial-information preservation |
| Finale native | `.musx`; historical `.mus` separately | Denigma is a concrete MUSX-to-MusicXML candidate, including a WASM-oriented route | Exact build/distribution rights, mapping-data provenance and conversion fidelity. Do not extend MUSX claims to all older MUS files |
| ABC | `.abc` | Compact notated text; abcjs is a candidate reader | ABC version/dialect, voices, repeats and mapping to MusicXML; no trial performed |
| Humdrum | `**kern` text, commonly `.krn` | Rich timing/pitch/voice relationships; humlib is a candidate parser/tool library | Spine interpretation and notation/expression mapping; exported output fidelity |
| Guitar Pro | `.gp3`, `.gp4`, `.gp5`, `.gpx`, `.gp` | Bounded GP3–GP8 fretted conversion through one private package with Node API/CLI and a GP-only public WebView Worker entry; shared admission includes genuine GP8 Guitar evidence | Exact encoding/feature admission, GP6/GP7 bass producer/display gaps, MPL source delivery and consumer WebView/platform gates remain explicit |
| LilyPond | `.ly` | A bounded static reader could recover an explicitly supported syntax subset | General files can run Scheme/includes. Never execute acquired source; reject constructs outside a static subset. An arbitrary file is not a declarative data contract |
| NoteWorthy text | `.nwctxt` | A documented text representation is a plausible independent reader target | No selected parser or verified complete musical decoding |
| MIDI | `.mid`, `.midi` | Timing/pitch performance events can yield useful inferred notation | Written rhythm, spelling, voices, hands, bar structure and expression are often underdetermined; report all inference |
| Sibelius native | `.sib` | Original-app export or a future verified native decoder | Standalone semantic decoding and commercial host/service route unproven; see [feasibility](native-sib-dorico.md) |
| Dorico native | `.dorico` | Original-app export or a future verified native decoder | Existing discovered project reader extracts metadata, not notes; see [feasibility](native-sib-dorico.md) |

File extensions help discover routes but do not establish completeness or quality. A semantic file converted through a helper is still in the structured tier. A generated PDF/SVG encodes visual drawing operations and belongs to the graphical-recovery tier even when its parent app could have exported MusicXML.

The 2026-10-08 [Guitar Pro investigation](guitar-pro.md) identified a headless reader but no MusicXML writer, original tempo-unit loss in normalization and truncation in derived tuplet ticks. The current [implementation proof](../guitar-pro-proof.md) records source preservation, exact written clocks, feature admission and one original exporter across bounded GP3–GP8 profiles. The [earlier family trials](guitar-pro-family-trials.md) remain separate candidate evidence. A candidate reader opening a file does not establish the converter's musical support.

The [GP WebView entry](../guitar-pro-webview-entry.md) exposes that same conversion through a public asynchronous package subpath and local ES-module Worker. Native raw-DEFLATE is a host codec, with complete-stream/size/CRC refusal and the disclosed data/work/time policy. Converter package checks do not certify consumer WebView hosting or every platform, and this entry adds no input format or standalone browser product.

## App exports and native projects

### Sibelius

The native project family is `.sib`. MusicXML export is available, with edition/version/platform differences; current materials cover `.musicxml` and compressed `.mxl`, alongside legacy `.xml`. MIDI, graphical and audio exports have different information content. A `.sib` file may preserve app-specific relationships that an interchange export does not, which justifies feasibility work rather than a permanent export-only input restriction. [Avid product comparison](https://www.avid.com/sibelius/comparison), [Avid August 2026 release](https://www.avid.com/resource-center/sibelius-august-2026-release), [ManuScript guide](https://resources.avid.com/SupportFiles/Sibelius/2024.8/ManuScript_Language_Guide.pdf).

### Dorico

Dorico keeps native `.dorico` projects and can export MusicXML and MIDI. Flow/project selection and version matter to export scope; do not treat a successful export as proof that all source constructs survive. [Steinberg MusicXML export documentation](https://www.steinberg.help/r/dorico-pro/6.1/en/dorico/topics/project_file_handling/project_file_handling_export_musicxml_dialog_r.html?contentId=phzRyYpvQd8AqpiNCTt_9A), [Dorico documentation](https://www.steinberg.help/r/dorico-pro/6.2/en?contentId=FmCs6XEpy0VsoF9lS8oVuA).

### MuseScore

Native `.mscx` is XML score data and `.mscz` is a compressed native container. MusicXML and MIDI exports are established routes; current documentation also lists MEI, graphical and audio output. MuseScore documents interoperability limits, including differences in visual layout. Its GPL application code and the possibility of an independently implemented native reader are different licensing questions. [Export handbook](https://handbook.musescore.org/file-management/file-export), [native format explanation](https://musescore.org/sr/node/36111), [MusicXML workflow](https://handbook.musescore.org/file-management/working-with-musicxml-files).

MuseScore documents local automatic conversion with `mscore -o output.musicxml input.mscz`; `.mscx` is also a native input. This makes it a concrete next proof and a comparison route for a future independent reader. An optional pinned local application helper and an independent versioned native reader have different runtime and incorporation boundaries. The documented CLI page includes legacy options, so verify the selected executable's behavior before promising a deployment. [CLI handbook](https://handbook.musescore.org/appendix/command-line-usage). Neither this capability claim nor source availability selects the GPL implementation as a shipping dependency. A new source adapter must retain source facts and report export gaps; non-fretted scores must not be forced into the current fretted proof model.

The [automatic import proof](musescore-automatic-import.md) exercises official MuseScore 4.7.5 on two independently authored miniature sources imported to genuine native files. Both their compressed MSCZ and extracted plain MSCX variants export automatically to MusicXML 4.0, preserving the tested exact timing, written/sounding pitch, voices, relations and altered fretted tuning/positions. This bounded roundtrip establishes a practical route for one selected build, not general native-version/feature coverage or an incorporated product adapter.

The subsequent selected route is an [independently implemented reader](../musescore-reader-plan.md), with MuseScore used only as a temporary comparison oracle. Shared model/writer generalization, continuous version evidence, at least 500 unique-source comparisons, native-construct inventory and performance/complexity review are implementation requirements. No MuseScore runtime, code, fonts or assets are being selected for incorporation.

### Finale

Finale's MUSX/MUS and export catalog is useful even though Finale development and technical support ended. MakeMusic documents MusicXML export and later availability of existing-user downloads/authorization. That makes MUSX conversion useful for legacy collections, not a reason to assume Finale must be installed in our pipeline. [MusicXML export](https://makemusic.zendesk.com/hc/en-us/articles/25868952458519-Exporting-MusicXML-Files-from-Finale), [post-support FAQ](https://makemusic.zendesk.com/hc/en-us/articles/33668410024343-What-Happens-Now-That-Finale-Technical-Support-Has-Ended).

Denigma version 4.0.0 at `c321d7741af13a3e945591071c5144cf778f33d0` provides MusicXML library and WASM routes without Finale. Its current MusicXML backlog records dropped TAB-specific meaning and incomplete percussion, instrument-change and mid-score transpose coverage. Its MusicXML build still requires classification/font-name support using the mapping resources already flagged in [licensing screening](licensing.md#denigma-code-license-is-not-complete-data-clearance); selecting a smaller exporter does not remove that concrete question. This remains a technically credible `.musx` proof candidate, with no local conversion trial or shipping selection. [Pinned coverage backlog](https://github.com/openmusx/denigma/blob/c321d7741af13a3e945591071c5144cf778f33d0/src/formats/musicxml/roadmap.md), [dependency pins](https://github.com/openmusx/denigma/blob/c321d7741af13a3e945591071c5144cf778f33d0/cmake/Dependencies.cmake), [utility dependency chain](https://github.com/openmusx/denigma/blob/c321d7741af13a3e945591071c5144cf778f33d0/src/utils/CMakeLists.txt).

## Candidate format/tool evidence

| Candidate | Primary sources | What the initial evidence establishes |
| --- | --- | --- |
| MusicXML 4.0 | [Specification](https://www.w3.org/2021/06/musicxml40/), [file structure](https://www.w3.org/2021/06/musicxml40/tutorial/structure-of-musicxml-files/), [MXL](https://www.w3.org/2021/06/musicxml40/tutorial/compressed-mxl-files/) | Partwise/timewise forms, interchange semantics, `.musicxml`/`.mxl` conventions and ZIP container contract |
| MEI | [Schemas](https://music-encoding.org/resources/schemas.html), [MuseScore integration](https://music-encoding.org/musescore-doc/) | Established encoding ecosystem and a MuseScore MEI Basic route; not an implemented converter profile |
| Denigma | [Repository](https://github.com/openmusx/denigma), [online frontend](https://github.com/openmusx/denigma-online) | Concrete MUSX conversion implementation with MusicXML/MNX routes; advertised scope, not local fidelity or legal clearance |
| ABC / abcjs | [ABC 2.1 standard](https://abcnotation.com/wiki/abc%3Astandard%3Av2.1), [abcjs](https://www.abcjs.net/index.html) | Documented notation language and a usable parser/library candidate |
| Humdrum / humlib | [kern documentation](https://github.com/humdrum-tools/humdrum-documentation/blob/master/rep/kern.md), [humlib Convert](https://humlib.humdrum.org/doc/class/Convert/) | Defined spine/token notation and conversion utilities; exact source-to-MusicXML route needs a trial |
| Guitar Pro / alphaTab | [Guitar Pro file management](https://www.guitar-pro.com/docs/gp8/basics/first-steps/file-management), [alphaTab formats](https://www.alphatab.net/docs/formats/guitar-pro-8) | Native format families and parser support claims, not complete notation mapping |
| LilyPond | [MusicXML conversion manual](https://lilypond.org/doc/v2.26/Documentation/usage/invoking-musicxml2ly), [safe-mode removal](https://gitlab.com/lilypond/lilypond/-/merge_requests/1522) | Some conversion paths exist; graphical losses and executable-source risks remain. Do not compile imported `.ly` |
| NoteWorthy text | [Text-format FAQ](https://noteworthycomposer.com/faq/32.md), [format discussion](https://forum.noteworthycomposer.com/?topic=6094.msg49843) | Text representation exists; no ready adapter was verified |
| MNX | [W3C CG project](https://github.com/w3c-cg/mnx) | A next-generation interchange effort worth tracking; not the initial output contract |

## MIDI is a distinct useful route

MIDI can supply absolute pitches, onset/duration events and tempo/meter events when present. It cannot uniquely establish enharmonic spelling, written ties, phrasing, notated rests, logical voices or a performer's intended hands. Some files are clean notation exports; others are expressive performances with different quantization needs. [MusicXML's notation/performance distinction](https://www.w3.org/2021/06/musicxml40/tutorial/notation-basics/).

Accepting MIDI therefore means producing an explicitly inferred score, not pretending it was a full score encoding. A reference MIDI can also cross-check selected pitches/timing against a richer source. It must not override printed notation or become ground truth for features it never contained.

The first MIDI route should demonstrate how a useful limited result is explained. It need not solve every performance-transcription ambiguity to prove the architecture.

## Support and fidelity policy

An adapter's support statement should name format/version, tested constructs, known omissions, required host/service and evidence level. Distinguish:

1. Specification/producer documentation.
2. Source inspection of an existing reader.
3. An actual authorized conversion trial.
4. Regression coverage for a shipped exact build.

The initial seed reached the first two levels for selected candidates. The subsequent bounded GP proof has conversion trials and original regression fixtures; the additional family trials state their own specimen provenance and limits. This does not establish a general format benchmark or shipping clearance. Other families remain documentation/source findings unless a separate trial record says otherwise. Licensing is a separate admission criterion described in [licensing screening](licensing.md).

# GPIF performer contract review

This review supplements the versioned implementation ledger. It concerns GPIF 6–8 source forms, not binary GP3–5. A passing conversion count establishes traversal, not full musical correctness. The independent original source studies are authored test encodings; only separately identified acquired examples establish producer evidence.

## Corrections found after the 146-study traversal

The official [Track Sound manual](https://www.guitar-pro.com/docs/gp8/audio/soundsetup/sound-settings) identifies Sound Label as the caption printed at sound changes. Sound automation changes an engine preset; its label remains performer information. The converter now resolves the selected Path/Name/Role identity and emits the exact label as standard words at its clock and visibility. An absent Label follows the documented Name default; an explicitly empty Label stays empty. Separately authored Automation Text also survives. Source program changes do not relabel the physical instrument. Genuine GP7 technical studies including `all-percussion`, `basic-bend`, and `bend` contain this label/automation source form. Original controls independently specify custom, default, empty and hidden labels alongside piano pedal and two-staff ownership.

The official [Lyrics manual](https://www.guitar-pro.com/docs/gp8/score/lyrics) defines syllable separators, blank beats, comments, word joining and first-staff placement. Track lyrics now remain on the first physical staff; repeated hyphens consume blank beats, dispatched per-beat verses receive independent standard syllabic states, and literal underscores are retained without assigning an unverified melisma meaning. Original controls combine two verses, syllabic starts/ends, blank beats, source comments, joined words and two physical piano staves. The current 146-study technical cohort contains no nonempty track lyric text. The supplemental upstream authored beat-lyric study below independently exercises six explicit lyric owners, while untouched nonempty producer lyric syntax remains separately unverified. A raw string or a passing empty lyric container does not establish melisma support.

Source dead-note ties and physical hammer-on/pull-off endpoints no longer face an arbitrary subtype refusal. Exact explicit tie identity must agree, including dead versus definite pitch; same-string contiguous H/P endpoints retain known frets while sounding pitch stays unknown. Original controls require standard tied/technical endpoints without inventing definite dead-note sound, and reject mixed dead/pitched tie identity.

## Requirement review and evidence boundaries

| Contract | GPIF implementation and independent evidence | Producer evidence / remaining qualification |
| --- | --- | --- |
| F01 | Original six-part default/selected arrangements, source metadata and names, two physical piano staves; exact sound-change caption timeline independent of presets. | Genuine 21-track GP6 percussion arrangement, all-part GP7 companion, existing GP8 fixture. Sound labels verified in genuine GP7 forms. No synthetic program-to-physical-instrument change is asserted. |
| F02 | Complete physical source tuning order, 1–16 strings, reentrant/low tuning; independent written/sounding/physical roles; partial/full capo controls and source pitch contradictions. | Two authored GP7.5 partial-capo examples convert with established mask orientation and absolute positions. Separate course/short-string physical semantics need source facts; flat string counts do not prove courses. Native track/staff tuning and capo are static source settings; no timed retuning is invented. |
| F03 | Exact rational clocks, sparse voices, source occurrence reuse, simultaneous staves, irregular extents without padding, Long through 256th/triple dots, authored beam groups and stems. | Genuine beaming, tuplets, incomplete/overfull measures and reused source definitions supplement original clock controls. Conflicting active extents refuse; they are not silently padded. |
| F04 | Exact bend/prebend/release and ordered fractional paths; independent note bends and whammy, continued curves and multi-voice ownership. | Genuine bend studies plus original GP6/7/8 combined bend/mute/tap/vibrato/ghost/fingering controls. Schema is not native visual acceptance. |
| F05 | Connected and open slides, same-fret endpoints, H/P and independent numbered connections; dead physical endpoints retain unknown sound. | Original simultaneous ownership and contradictory/orphan controls; genuine slide/legato cohorts. |
| F06 | Natural/artificial/tap/pinch/semi/feedback roles distinguish base, node, result and displayed pitch; source node inference is reported. | Genuine artificial/natural examples and independent harmonic-role controls. Unknown node results stay unknown; no automatic octave repair. |
| F07 | Dead/ghost, palm mute/let ring, tap/slap/pop, tremolo picking, brush/arpeggio, vibrato and whammy; engine interpretation remains distinct. | Original source combinations plus genuine performer studies. Source-qualified playback exclusions are not missing notation exemptions. |
| F08 | Explicit ties/slurs, before/on-beat grace groups, ornaments/trills, accents, fingering, fermatas and source instructions. | Exact event owner, source clocks and standard technical/ornament assertions; no inferred performing hands from staff order. |
| F09 | Dynamics/hairpin spans, exact text, tempo units/dots/rates/visibility, rational change clocks and linear-rate text-line projection. | Genuine dynamics/tempo studies and original tempo-unit/hidden/linear controls; continuous synthesized ramps are excluded while printed instructions remain. |
| F10 | Repeats/counts/endings, measure repeats, rehearsal, Fine/Coda/Segno/jumps, free time and swing instructions. | Original structure and simile controls plus genuine source studies. Navigation markers and labels remain explicit; conversion does not certify traversal playback. |
| F11 | Source chord captions/frames, note/verse lyric ownership and independently recovered syllabic controls. | Parent owns chord source analysis and frame evidence. Six explicit upstream authored lyric owners and original verse/blank-beat controls exercise source syntax. Untouched nonempty lyric/melisma producer verification remains distinct. |
| F12 | Piano/keyboard/vocal/other traditional notation, physical staves/voices, clefs/transposition, pedal and source captions, no editor grid exported as piano fingering. | Original band fixture and genuine keyboard/clef scores. Engine sound changes preserve visible labels without inventing physical instrument replacement. |
| F13 | Source catalog drum MIDI/line/head/technique, GP6 local selectors, mixed arrangement; explicit unassigned sentinel preserved without fallback sound. | Genuine percussion studies and original independent native-selector controls. Empty unpitched default display is an explicitly reported projection, not source placement proof. |
| F14 | Source-owned caption visibility, selected part identity, source beaming/grouping, technique appearance and safe auxiliary unknown fields. | Exact native page geometry and mixer UI remain exclusions. Unqualified native styles cannot be assumed faithfully rendered merely because the music converted. |

See [partial capo and final arrangement controls](guitar-pro-partial-capo.md) for source identities, 146-study epoch, low-register format limits, irregular-clock correction and qualified unassigned percussion. Standard output controls use the pinned MusicXML 4.0 schema. This record does not replace whole-family verification or consumer rendering acceptance.

## Bounded final review controls

The final review adds independent combinations for two simultaneous numbered hammer-on connections and for ottava, before-beat grace, lyric, fermata and legato ownership. The latter preserves base pitch and rational clocks while using a standard octave-shift; it does not apply the octave twice. Source user stem orientation takes precedence over the automatic orientation, while Automatic/Undefined remain without a fabricated absolute override. Explicit ShowStringNumber becomes a visible standard technical string instruction independently of the physical string/fret carrier.

A source `InstrumentSet/Type=banjo` with explicit string/fret/tuning is admitted as a fretted physical instrument in the public `other` family. Its playback program does not supply instrument identity. Neither a short fifth-string offset nor doubled-course semantics are inferred. The genuine 146-study cohort separately contains electric-bass source identity in `high-pitch.gp` and `slur-notes-effect-mask.gp`, and acoustic-piano identity in `clefs.gp`, `chordnames_keyboard.gp` and `grace.gp`; source display names do not override those identities.

Compact inspection now recognizes the same qualified active partial capo as conversion. A GP7 revision 12020 empty-state encoding with `PartialCapoFret/Fret=0` and `PartialCapoStringFlags/Flags=0` is also accepted. It supplies no evidence for interpreting an active scalar mask: positive scalar Flags and a nonzero fret paired with that empty scalar still refuse. Original controls preserve this distinction.

### Supplemental lyric and container evidence

The following private research inputs come from [alphaTab's pinned test source](https://github.com/CoderLine/alphaTab/tree/022a45c8e42370f9e12e68949d11eada370da83d/packages/alphatab/test-data). No acquired payload is committed.

| Path under test-data | SHA-256 | Evidence |
| --- | --- | --- |
| `guitarpro7/beat-lyrics.gp` | `b93c02cd33539f28523e16e0776c3ac4dc6df2538305f92f37a9ef1c5d9f26a7` | GP7 revision 12025 native packaging with an explicitly upstream-authored mutation. Its track text says it was manually modified to exercise beat lyrics. Six beat captions survive exactly as `This`, `is`, `a`, `test file`, `for`, `lyrics`; twenty-four empty verse slots produce no invented lyrics. This is semantic fixture evidence, not an untouched producer lyric export. |
| `guitarpro7/lyrics-template.gp` | `4f7f04b3b3846284a146de3df4ba92573fda7706dd2fd74d99616a241e325c44` | GP7 revision 12020 baseline with empty lyric containers, Undefined automatic stems and inactive scalar capo flags. It proves baseline source/container admission, not lyric content fidelity. |
| `guitarpro6/lyrics-template.gpx` | `1ce9cf7a7246fdbb751bffaf9cabe1b4ad40d5b8058cade618a82bb9c0ad8222` | GP6 baseline with empty lyric containers; no lyric content claim. |

All three original containers convert. Timestamp-only NTFS ZIP extras follow [PKWARE APPNOTE section 4.5.5](https://pkware.cachefly.net/webdocs/casestudies/APPNOTE.TXT): reserved zero, attribute tag 1 and exactly three 64-bit timestamps. The reader admits only that bounded metadata shape and rejects duplicate, malformed or unknown extras; CRC, local/central identity, actual decoded lengths and descriptor source qualification remain enforced. The observed revision 12020 descriptor alias is qualified to its exact GP7 encoding tuple, not every revision. Original controls independently construct metadata and contradictory forms.

Validation for this review: 65 coupled source/admission/inspection/beam/ZIP controls, plus five MusicXML 4.0 schema documents including the original upstream beat-lyric container and the visible string-number projection. Schema acceptance is separate from consumer visual acceptance. The final GPIF traversal converts 146/146 technical studies after these changes; its count does not replace the field-specific controls above.

### Explicit H/P endpoints across intervening attacks

The final endpoint review removes a converter-only adjacent-beat restriction.
Pinned alphaTab `Note.findHammerPullDestination` searches subsequent beats for
an attack on the same string. Within one candidate beat, it prefers the same
string, then searches numerically lower strings, then higher strings; the first
occupied string in either direction is a candidate only when left-hand-tapped.
This is recorded in the pinned [primary Note source](https://github.com/CoderLine/alphaTab/blob/022a45c8e42370f9e12e68949d11eada370da83d/packages/alphatab/src/model/Note.ts).
Its GPIF parser reads HopoOrigin but calculates destinations, so its inferred
endpoint alone is insufficient authority for our accepted source pair.

The converter instead requires an explicit HopoDestination on that first
source-ordered candidate. Other-string attacks and barlines do not shorten a
same-string pair. A same-string changed fret yields derived H or P and a
connection slur at the exact original clocks. Equal frets retain the combined
H/P instruction and slur. An explicitly destination-marked left tap on another
string also retains combined H/P, slur and the separate left-hand tap; comparing
frets across different strings does not establish a direction. A tap alone
cannot create an endpoint. Missing/unpaired destinations, competing origins or
unconsumed explicit destination flags still refuse rather than choosing a later
convenient pair. No note, duration, voice or physical position is repaired.

The source search is independently implemented with bounded per-string maps;
there is no repeated whole-score search. Eleven original controls cover GP6,
GP7 and GP8 public conversions, intervening strings, barlines, equal frets,
explicit cross-string left taps, lower-before-higher candidate order and
contradictory/unmarked/cross-voice destinations. Existing simultaneous numbered
pairs, dead-note physical endpoints and combined techniques remain covered.
The coupled set has 81 passing controls; nine output combinations pass the
MusicXML 4.0 XSD. This adds original semantic proof, not a claim that these exact
combinations were observed in a genuine Guitar Pro producer export.

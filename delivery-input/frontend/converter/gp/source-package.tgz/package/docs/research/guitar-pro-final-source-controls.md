# Final binary source controls

These controls remove specific implementation assumptions. They do not establish new producer coverage merely because byte-authored fixtures pass.

## Chord diagram coordinates

Binary chord note and first-fret fields use encoded integers; GP3 enhanced barre frets use integers and GP4/5 barre frets use bytes. No source-format evidence establishes the previous arbitrary ceiling of48. The adapter preserves nonnegative frets and positive first-fret positions, independently of sounding-note pitch. Standard MusicXML `fret`, `first-fret` and `frame-frets` are integer coordinates, not a guitar fret-count policy. The writer emits each value once and does not allocate storage proportional to its magnitude. Encoded bounds, string endpoints, paired barres, invalid negative positions and resource limits remain checked. Original fret100 controls exercise both a high first-fret diagram and a wide frame beginning at1, leaving actual note pitch/fret unchanged; the combined schema check validates the wide frame.

## Component-owned dynamics

The [Arobas GP4 note record](https://dguitar.sourceforge.net/GP4format.html) stores each note's dynamic under its own presence flag. Differing values in a chord are retained on those exact note owners as `NoteDetails.dynamic`; a single common value keeps the existing event-level projection. MusicXML4 explicitly allows `dynamics` inside note `notations`, so different literal marks need not become one misleading chord direction or a conversion refusal. Exact source locations and values remain auxiliary. Original GP3/4/5 fretted and drum chords independently carry `pp` and `f`, preserve their note identities and timing, and reject invalid dynamic9. Schema controls exercise both fretted and unpitched note-owned marks. This does not claim that every producer UI offers per-component editing or that source velocity differences without these encoded marks establish visible instructions.

# Mixed custom Dynamic captions

A custom Dynamic may combine differently emphasized ordinary words. MusicXML's `other-dynamics` string cannot put separate font attributes on each run, but that is not a whole-format limitation: one direction can contain ordered `words` plus a hidden `dynamics` carrier. The writer now uses that representation for differing source emphasis or ordinary font families. It preserves one source direction, staff, clock, complete literal semantic caption and velocity instruction. Source-hidden captions stay hidden, and the semantic carrier does not duplicate visible text.

Uniform captions retain their ordinary typed dynamic projection. Canonical musical Dynamic glyph components use their separately qualified existing route. Shared frames, source font availability and formatter cases remain governed by their specific source and standard capabilities; this change does not infer a musical glyph from ordinary prose.

Original controls inspect the visible bold/plain/italic runs, complete hidden semantic string, source visibility/color and single velocity carrier. Independent checker controls recover the source runs separately and detect lost emphasis, changed captions and a falsely visible semantic duplicate. One mixed-caption output passes the pinned MusicXML 4.0 schema.

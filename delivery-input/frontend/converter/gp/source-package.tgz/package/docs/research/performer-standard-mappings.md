# Shared performer projections

The common model keeps located source technique facts separate from physical
string/fret, written pitch, sounding pitch and elapsed timing. Adapter recovery
and genuine producer acceptance remain separate from these writer checks.

## Bends and bar gestures

A curve consists of normalized note offsets and absolute semitone displacements.
The writer preserves its ordered changes as MusicXML `bend` elements: an initial
nonzero displacement at zero time is a `pre-bend` with the inverse displacement
sign required by the standard. Motion back toward neutral carries `release`; a
bar dip away from neutral remains a bend, even when its amount is negative. A release from +2 to zero is
therefore -2, not zero. Crossing neutral decomposes into a release and an
oppositely directed bend. The official pre-bend example keeps the physical
Bb3/string-3/fret-3 pitch and writes -2 with `pre-bend`; no printed pitch change
is introduced here. `with-bar` distinguishes a bar gesture; an event-level bar
curve can coexist with individual string bends. Neither curve changes the source
fret or the note's separately established pitches.

Finite exact percentages use `first-beat`/`last-beat`; inexact percentages are
omitted because these attributes control playback rather than performer notation.
The exact source curve is retained in ordinary `miscellaneous-field` metadata.
Nonterminating semitone amounts are refused rather than rounded. Source point
vibrato has a performer instruction in addition to exact point retention.
[MusicXML bend](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/bend/),
[bend amount](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/bend-alter/).

## Harmonics and other techniques

Natural/artificial classification and an explicitly established printed pitch role
use standard `harmonic` children. Pinch, tap, semi and feedback subtypes accompany
the harmonic sign as ordinary `other-technical` instructions. Independently
established base/touch/result pitches stay located in the model. Additional known
roles use nonprinting, silent standard chord components with the corresponding
harmonic pitch-role child, at the same original onset and duration. Existing
source-notated components with that role are not duplicated. Fractional
harmonic-fret parameters also remain in auxiliary metadata; absent touch pitches
are never invented. Pinch/tap/semi/feedback names do not by themselves invent an
artificial classification.
[Harmonic](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/harmonic/),
[other technical](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/other-technical/).

Palm mute, let ring, vibrato, slap/pop and pick scrape use readable standard
technical instructions. Tapping uses `tap` with its source hand. Left-hand
fretting and right-hand plucking use `fingering` and `pluck`. Note-local incoming
and outgoing slide gestures use the standard straight `scoop`, `plop`, `doit` and
`falloff` marks; connected slides retain the existing numbered relation mechanism.
[Tap](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/tap/).

## Chords and diagrams

Established root/quality/bass/degrees use standard harmony components. An authored
caption with unexamined analysis remains ordinary words: the converter does not
invent a tonal interpretation. Frames retain string count, fret range, open and
muted strings, fingerings and barre endpoints. MusicXML requires a harmony wrapper
for a frame. A standalone frame uses an empty function with `kind=none`; the schema
explicitly states that the function has no meaning in this case. No tonal root is
fabricated. Full caption text remains independently readable.
[Harmony](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/harmony/),
[kind](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/kind/),
[frame](https://www.w3.org/2021/06/musicxml40/musicxml-reference/elements/frame/).

## Finite evidence

`test/fretted-techniques.test.ts` uses original model studies with independently
stated expectations for combined bends, release amount, source pitch/fret
invariance, harmonic types, simultaneous gestures, handed fingering, note-local
slides, chord degrees, standalone frames, open/muted strings and paired barres.
Malformed curves, unknown marks and unpaired barres refuse. These tests do not
establish any source adapter's recovery or contemporary producer acceptance.

## Timelines, images and mixed instruments

Located capo instructions retain full/partial string scope and source pitch policy.
Explicit tuning/full-capo changes use real TAB staff attributes or the nonprinting
alternate TAB carrier, never change a pitched staff into a six-line staff. A part
can declare pitched instrument contexts and mapped percussion together. The
adapter owns source pitch interpretation and creates the timed attribute facts.

Qualified embedded PNG/JPEG/GIF/SVG resources use standard `direction-type/image`
with a data URI at the source frame's musical boundary. Exact native page size and
position are not imposed. MusicXML image/direction has no visibility attribute;
hidden source images retain their resource as metadata without being revealed.
Source resource qualification, byte validation and unavailable external resources
remain adapter responsibilities.

H/P technical pair numbers are independent of visual slur numbers. Visual H/P
connections share the same occupied slur-number pool as phrasing relations, so a
simultaneous phrase cannot collide with an H/P connection. Explicit source swing
feel has readable words and standard `sound/swing`; no audio synthesis is required.

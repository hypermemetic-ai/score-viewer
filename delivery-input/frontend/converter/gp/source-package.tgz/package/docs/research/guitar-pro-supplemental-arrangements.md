# Supplemental Guitar Pro arrangement evidence

The 2026-10-14 supplemental cohort adds five pinned upstream inputs without changing the original203 denominator. Inputs and full receipts remain private. These are upstream source files, not independently authenticated original application exports; a format extension alone does not establish producer provenance. No acquired score content is committed.

All paths below are relative to [alphaTab's pinned test-data tree](https://github.com/CoderLine/alphaTab/tree/022a45c8e42370f9e12e68949d11eada370da83d/packages/alphatab/test-data).

| Source | SHA256 | Evidence |
| --- | --- | --- |
| `conversion/full-song.gp5` | `3226e44088279aa4e3f268308d6cb505d8c6af0c9ea1ac8736afe0b25a24fb7e` | Eleven-part arrangement; public conversion and MusicXML4 validity. Independent source comparison below. |
| `guitarpro4/fade-to-black.gp4` | `51712a4e61b017da00b4cb37d6c6382cf6ef97ff0ed9f477de61756c20cb05f6` | Selected source bass part7 converts and validates. Whole arrangement's legacy empty note-slot case is separately tracked. |
| `guitarpro4/effects.gp4` | `36a1023288fe35c624bf77f5d3fe1f2172cfed3ed322904cf952110ab9801b46` | Public conversion and schema pass after reserved-bit and combined H/P recovery. |
| `guitarpro5/effects.gp5` | `e364cf882db1d849653183d8aa52ca73e5af104ba6dd535d6273a7565ab81455` | Same source-qualified recovery and schema result. |
| `guitarpro5/bass-tuning.gp5` | `e6e98ca1e62ebb8b90958d71feda797e4676709f9f1309a516e3908f730eab2c` | Four tuning/metadata parts convert and validate, but contain no notes; this is not bass note evidence. |

## Independent arrangement comparison

The existing research-only PyGuitarPro0.11 reader independently reconstructs source parts, note ownership, string/fret grid, tie-destination types and percussion identities. No shipping dependency is added. The eleven-part source has 4,565 nongrace note owners: named voice parts378 and282, choir144, acoustic guitar522, distorted guitar600, keyboard513, bass415, strings446, pipe72, timpani/brass87 and drums1,106. Every source owner matches the converter, with zero differences in checked facts. Eleven additional pipe grace notes are excluded from that nongrace count and require their separate grace evidence.

Part names and MIDI programs match exactly. All pitched source notes retain tuning plus source fret/capo pitch; fretted guitar/bass strings and frets match. Source destination-only ties remain destinations. Percussion retains source drum identity without invented pitched notes. Named voice tracks retain their encoded programs73/64 rather than being reclassified solely from their names; the encoded choir uses the existing vocal-family route. The actual bass tuning is `[24,31,36,41]` low-to-high. No octave normalization is applied to its source pitch grid; qualified written-register representation remains separate.

The selected GP4 bass has1,017 nongrace source notes plus five separately represented graces. Independent source ownership, pitch, string/fret and tie checks find zero differences. Its encoded program33 and tuning `[28,33,38,43]` low-to-high remain intact. Selecting this part is evidence for GP4 bass conversion, not a whole-arrangement pass while another part's empty-slot case is unresolved.

These comparisons establish the stated source facts. They do not independently establish every timing, engraving, lyric or technique detail, and schema validity is not visual acceptance. Initial failures and additive correction receipts retain their distinct runtime identities; the final frozen assessment must state its own epoch.

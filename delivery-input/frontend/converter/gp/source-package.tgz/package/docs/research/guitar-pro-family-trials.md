# Guitar Pro family trials and continuous coverage plan

Historical investigation checkpoint recorded2026-10-09, before decoder implementation. **GP3 is the selected support floor, with continuous version coverage through GP8.** Tables below record the then-current gate/candidate trials, not today's acceptance matrix. Implemented bounded coverage, genuine Guitar, safety checks and producer gaps are in the [proof](../guitar-pro-proof.md) and [public contract](../guitar-pro-api.md). Version support remains separate from selected musical features. [D29](../decisions.md) records the decision.

## Exercised results

| Family/header | Original specimen and provenance | Converter at the historical trial | Temporary full alphaTab 1.8.4 candidate |
| --- | --- | --- | --- |
| GP3 `v3.00` | Invented miniature encoded by PyGuitarPro 0.11 | Refuses `zip`, before musical recovery | Recovers all independently specified binary-study facts below |
| GP4 `v4.00`, `v4.06` | Two encodings of the same invented miniature | Refuses `zip` for both | Recovers all specified facts for both |
| GP5 `v5.00`, `v5.10` | Two encodings of the same invented miniature | Refuses `zip` for both | Recovers all specified facts for both |
| GP6 / GPX | Synthetic BCFS and literal-only BCFZ wrappers containing unchanged **constructed GPIF 7.0**, not authentic GP6 exports | Refuses `zip` for both | Reads one track, three bars, complete tuning and first MIDI 26 from both; wrapper interoperability only |
| GP7 / ZIP | Existing original constructed GPIF 7.0/revision 0 and original ZIP helper | Converts under `constructed-gp7-fretted/0` | Reads track/bars/tuning/first MIDI; genuine GP7 producer acceptance remains absent |
| GP8 / ZIP | Existing original GP8-shaped miniature; separately authorized private bass input in the earlier proof | Converts exercised `gp8-scientific-physical/0` scope | No new independent GP8 application trial |

At this historical checkpoint, the vendored component contained the GPIF parser/model graph, not GP3–5 binary or GPX decoders. Its then ZIP-only entry rejected older encodings before looking for music. Candidate recovery does not establish converter support or shipping approval.

The five committed binary files total 6,968 bytes of newly invented music. Their [independent specification](../../test/fixtures/gp-family/original-study.json), [manifest](../../test/fixtures/gp-family/manifest.json) and [fixture explanation](../../test/fixtures/README.md) distinguish library encodings from real app exports. Existing music-app inventory found no available Guitar Pro/TuxGuitar producer; no app was installed or used. No acquired repertoire, producer implementation or private operational receipts are committed.

Expected facts were authored before encoding: three 4/4 bars, quarter=120, MIDI program 33, high-to-low tuning `[43,38,33,26]`, 14 beats/14 note components, G2 at string 1/fret 0 and string 2/fret 5, altered low D1, a rest, seven eighths in the time of four, a chord with a dead-note reference, a hammer origin and a tie destination. Dead-note MIDI 34 is physical reference, not definite sounding pitch.

The optional probe verifies candidate tuning/program/meter/tempo, every beat/rest, physical string/fret/reference MIDI and dead/tie-destination/hammer-origin flags. It reconstructs exact onset/duration/bar-end clocks from written denominator/tuplet fields with integer cross-multiplication. Candidate numbering is reversed: source string = N − candidate string + 1. Candidate septuplet playback is seven 274-tick values, totaling **1,918 rather than exact 1,920** at 960 ticks/quarter. Those ticks must not become score clocks. Raw binary offsets, unknown flags, reader repairs and written spelling/register are not independently preserved by these trials.

[PyGuitarPro 0.11](https://github.com/Perlence/PyGuitarPro/blob/39c5571222d54c49b081fcce2f920ccdd6f6fe64/README.rst) provides GP3–5 read/write tooling with historical alphaTab/TuxGuitar lineage. This compares different implementations, not wholly independent format histories or human app acceptance. PyGuitarPro 0.11/attrs 25.4.0 and full `@coderline/alphatab@1.8.4` (commit `022a45c8e42370f9e12e68949d11eada370da83d`) were temporary tooling outside the repository. They are not new converter dependencies; [shipping/source obligations](guitar-pro.md) remain separate.

## Exporter label and directory finding

The full candidate's `Gp7Exporter`, seeded with the original GP5.10 miniature, produces ZIP `VERSION=7.0` but embedded `GPVersion=8.1.3`, revision `13007`, `required=12024`, `recommended=13000`. The [pinned exporter](https://github.com/CoderLine/alphaTab/blob/022a45c8e42370f9e12e68949d11eada370da83d/packages/alphatab/src/exporter/Gp7Exporter.ts) and [GPIF writer](https://github.com/CoderLine/alphaTab/blob/022a45c8e42370f9e12e68949d11eada370da83d/packages/alphatab/src/exporter/GpifWriter.ts) expose the different identifiers. Candidate rereading recovers one track from its own export: a self-roundtrip, not genuine GP7 proof.

Its empty `Content/` directory triggers current `zip: Unsafe or ambiguous member path.` before GPIF admission. Future GP7/8 ZIP intake should admit validated directory entries as directories, separately from payload files, while retaining path safety, local/central identity, CRC/size and duplicate/case ambiguity checks. Directory compatibility alone does not prove musical coverage. This increment leaves gates unchanged.

## Proposed implementation

Three bounded container families should feed **one** source-capture, recovery, neutral-score and ordinary MusicXML/report path: GP3–5 binary; GP6 BCFS/BCFZ with GPIF; GP7–8 ZIP with GPIF. Retain complete tuning, physical positions, distinct written/sounding facts and exact clocks. Do not transcode through an upstream writer or add display-dependent export modes.

A pinned source dependency walk adds **ten upstream files, 107,006 bytes**, to the existing 86-file graph if our narrow settings boundary replaces full `Settings`:

| Role | Additional paths under `packages/alphatab/` |
| --- | --- |
| Binary reader/base | `src/importer/Gp3To5Importer.ts`, `src/importer/ScoreImporter.ts` |
| GPX container | `src/importer/GpxFileSystem.ts` |
| IO | `src/io/IReadable.ts`, `src/io/IWriteable.ts`, `src/io/ByteBuffer.ts`, `src/io/IOHelper.ts`, `src/io/TypeConversions.ts`, `src/io/BitReader.ts` |
| Instrument tables | `src/midi/GeneralMidi.ts` |

This is a measured proposed import/type closure, not compiled incorporation. Extend `ReaderSettings` only with fixed importer encoding, bounded decoding size and `beatTextAsLyrics=false`; update exact hashes, source patches and applicable MPL/notices. Reuse our ZIP/XML adapter and GPIF parser, avoiding full `ScoreLoader`, upstream exporters, ZIP codecs, renderer/audio graph and assets. See the [pinned binary reader](https://github.com/CoderLine/alphaTab/blob/022a45c8e42370f9e12e68949d11eada370da83d/packages/alphatab/src/importer/Gp3To5Importer.ts) and [GPX filesystem](https://github.com/CoderLine/alphaTab/blob/022a45c8e42370f9e12e68949d11eada370da83d/packages/alphatab/src/importer/GpxFileSystem.ts).

Capture immutable bytes/consumed spans and decoded fields **before** assignment, skipping or normalization. Add byte offset/length and stable track/measure/voice/beat/note locations beside XML locations. Hook header/song/channel/track/master-bar/voice/beat/note/effect/mix-table readers: retain raw flags/enums, tuning order, string masks, duration/dot/tuplet integers, capo/register fields, dynamics, tie/effect flags and tempo. Bind captures before `ModelUtils.consolidate`/`Score.finish`, then reconcile endpoint inference/repairs with raw facts. Preserve empty GP5 secondary-voice identity. The existing normalized comparison cannot substitute for these hooks.

Derive rational clocks from encoded rhythm and physical numbering from source masks/tuning. Generated spelling or version-specific register interpretation must be located inference with producer evidence when source fields are absent. The reader's low-tuning clef heuristic is not source clef, performing hand or proof of octave transposition.

Apply input/decoded-size, count, sector, backreference and cancellation budgets **before and during** GP6 expansion, plus existing track/measure/occurrence/divisions/worker limits. Require complete bounded decoding; reject truncated streams, invalid/zero-progress backreferences, cyclic/overlapping/out-of-range pointers and ambiguous filenames. Preserve member bytes without disk extraction and classify interpretation settings. Candidate allocation from declared sizes and toleration of incomplete decompression are not sufficient admission rules.

| Version admission | Acceptance evidence still required |
| --- | --- |
| GP3 | Exact `v3.00`; source spans and one-voice facts; original app/independent byte verification alongside library specimen |
| GP4 | `v4.00`, `v4.06`, documented `L4.06`; first two exercised here, alternate header still needs evidence |
| GP5 | `v5.00`, `v5.10`; both exercised here; raw flags/version fields/two-voice preservation. Whole-file 5.2 writer request maps to `v5.10`, not a new invented `v5.20` |
| GP6 | Genuine original producer GPX/GPIF tuple, BCFS/BCFZ, real backreferences and settings; synthetic GPIF7 wrappers cannot establish these |
| GP7 | Genuine original GP7 app export/header/revision tuple, directory records and retained settings; candidate exporter name is insufficient |
| GP8 | Retain existing profile/private-source regression; add original producer material for broader producer/revision coverage |

[Pinned PyGuitarPro IO](https://github.com/Perlence/PyGuitarPro/blob/39c5571222d54c49b081fcce2f920ccdd6f6fe64/guitarpro/io.py) identifies these binary variants. Clipboard payloads are a distinct artifact class requiring explicit initial refusal. Unknown/future versions and unverified minor headers need explicit diagnostics, rather than silent interpretation as 5.10 or omission from the continuous milestone. [GP6](https://alphatab.net/docs/formats/guitar-pro-6/) and [GP7](https://alphatab.net/docs/formats/guitar-pro-7/) have different containers with evolving GPIF content; there is no established universal producer schema here.

Keep the selected fretted-bass vocabulary consistent across versions. Refuse unknown musical flags/enums and current unexercised techniques, percussion/non-string tracks, active capo, unsupported navigation/repeats/free-time/ramps, register/microtonal conflicts and unresolved ties/HOPO in requested scope. Source fingers/beaming require explicit mapping or admission outcomes. Selected parts remain declared scope; omit only reviewed nonessential metadata with consequences. Different binary string/voice capacities do not promise encodings that the format lacks.

Validate each header/container with independent pitch/position/clock/relation expectations, source bytes before normalization, original producer specimens where missing, and malformed lengths/EOF/flags/endpoints. Include GPX size/pointer/backreference/cancellation and ZIP directory/ambiguity cases. Verify public API/atomic CLI behavior, MusicXML complete tuning and exact clocks without a report, and official schemas. Independent app display/audio is separate. Binary work can land first, but **the GP3–GP8 milestone stays incomplete until every family and GP6/GP7 producer gap is resolved**.

## Reproduction and checks

`npm test` passes **33 tests**, including nine new specimen/default-API checks, without optional producer/candidate dependencies. `npm run check:vendor` verifies the shipping component is unchanged. The eleven-output MusicXML schema baseline is unchanged; no successful output/exporter changed here.

To regenerate, use temporary `PyGuitarPro==0.11 attrs==25.4.0` outside the repository and run the original [generator](../../scripts/research/generate-gp-family.py) through qq-job, with a temporary output directory before comparing hashes/manifest. To repeat candidate trials, install pinned alphaTab outside the repository, build, then supply its core-module path:

```sh
/home/qqp/.local/bin/qq-job -- npm test
/home/qqp/.local/bin/qq-job -- node scripts/research/probe-gp-family.mjs /absolute/temporary/node_modules/@coderline/alphatab/dist/alphaTab.core.mjs
/home/qqp/.local/bin/qq-job -- npm run check:vendor
```

The [probe](../../scripts/research/probe-gp-family.mjs) checks candidate version/commit and does not install tooling. Python's standard library inspects only its bounded generated ZIP. Binary assertions establish this miniature's recovered facts; GPX/GP7 assertions deliberately cover less. No parser gates, shipping dependencies, consumers or deployments changed.

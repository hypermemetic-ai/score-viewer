# Score converter

An independent pipeline for converting musical scores into an established interchange format. **MusicXML 4.0 is the first reference output**; the current proof emits plain `.musicxml`. Compressed `.mxl` packaging remains part of the intended interchange contract. Other notation systems and applications should be able to use the result without ISO notation or a TUNA viewer.

The private Node package exposes `convertScore(bytes)` for content-based Guitar Pro or MuseScore conversion, `convertGuitarPro(bytes)` and `convertMuseScore(bytes)` for explicit selection, and the `score-converter` CLI. It produces plain MusicXML 4.0, a located conversion report and source facts through one common writer. See the [native API](docs/musescore-api.md) for a minimal example, exact admitted profiles, error/cancellation behavior and resource limits.

**Guitar Pro GP3–GP8 and native MuseScore MSCX/MSCZ conversion are merged, with substantial feature and acceptance work still open.** The agreed target is performer-relevant traditional notation and tablature, including common guitar/bass techniques and the other notated parts of an arrangement. The current Guitar Pro profile does not yet meet that target; the MuseScore repertoire evidence does not cover all required instrument and technique families.

- [Feature contract](docs/feature-contract.md): what must survive, deliberate exclusions, and what counts as complete.
- [Current status](docs/current-status.md): exact assessed revision, implemented coverage, corpus outcomes and evidence gaps.
- [Remaining work](docs/completion-plan.md): assessment, musical capability and maintainability tasks.

These three documents are the current entry points. Detailed API and proof records below retain their own source/checker epochs. Successful conversion and schema validity do not certify performer completeness. Viewer integration and display acceptance are separately owned.

Later merged follow-ups include [default stretched-beam topology](docs/research/musescore-corpus.md#unheaded-default-groups-at-stretched-clocks) and [rich Dynamic contexts](docs/research/musescore-corpus.md#qualified-dynamic-family-and-frame-contexts). Their finite proofs remain distinct from the frozen corpus assessment in current status.

## Direction

- Start with structured musical inputs, then generated digital PDFs, then scanned scores.
- Support many useful input routes rather than requiring everyone to export MusicXML first.
- Keep pitches, written timing, voices, ties, phrasing and other recoverable musical information distinct from inferred or editorial choices.
- Account for each gap as a required capability, verification gap, agreed exclusion or malformed source; partial output is not completion.
- Preserve recoverable information even when the current ISO renderer cannot display it.
- Carry supported tuning and source string/fret choices through the single default output, independently of a consumer's notes or TAB presentation.
- Produce ordinary MusicXML without mandatory proprietary extensions. The project does not own the interchange standard or the music in its outputs.
- Select dependencies compatible with the intended source-available, free-personal/paid-commercial product model. Final licensing terms are still pending.

## Start here

| Document | Purpose |
| --- | --- |
| [Decisions](docs/decisions.md) | Accepted direction, proposals and unresolved choices |
| [Architecture](docs/architecture.md) | Product boundaries, stages and viewer integration |
| [Input-format research](docs/research/formats.md) | Candidate families, app exports and evidence limits |
| [Bass display handoff](docs/bass-display-handoff.md) | Approved common consumer model/C2 display, implemented stem policy and remaining delivery checks |
| [Guitar Pro reader proof](docs/guitar-pro-proof.md) | Exercised private harness, exact profile, local usage and remaining acceptance gates |
| [Guitar Pro public API](docs/guitar-pro-api.md) | Private package imports, source-track inspection/selection, output identities, errors and cancellation |
| [Guitar Pro WebView entry](docs/guitar-pro-webview-entry.md) | Public async GP Worker entry, local assets, shared admission and host resource policy |
| [MuseScore WebView entry](docs/musescore-webview-entry.md) | Public async native MSCX/MSCZ Worker entry, Node parity and host resource policy |
| [Fretted information contract](docs/fretted-information-contract.md) | Single-output tuning/string preservation and the downstream retention boundary |
| [Guitar Pro local conversion](docs/research/guitar-pro.md) | Pinned reader findings, preservation gaps and a bounded bass-oriented proving plan |
| [Guitar Pro family trials](docs/research/guitar-pro-family-trials.md) | Exercised GP3–8 recognition/reader trials, specimen provenance and the GP3–GP8 coverage plan |
| [MuseScore native-conversion proof](docs/research/musescore-automatic-import.md) | Pinned local MSCX/MSCZ-to-MusicXML trial, preserved miniature facts and proposed integration |
| [MuseScore public API](docs/musescore-api.md) | Native/generic Node conversion, source facts, limits and tested package usage |
| [MuseScore corpus verification](docs/research/musescore-corpus.md) | Fixed 500-original denominator, paired current inputs, source audit and measured costs |
| [Corpus assessment runner](docs/research/corpus-assessment-runner.md) | Reproduce an immutable private-input baseline with separate conversion, schema and source-audit stages |
| [Standalone MuseScore reader plan](docs/musescore-reader-plan.md) | Selected independent adapter, common-model work, large-corpus comparison and performance checks |
| [Sibelius and Dorico feasibility](docs/research/native-sib-dorico.md) | Native input routes that remain unproven |
| [Digital PDF and scan research](docs/research/digital-pdf-scans.md) | Deferred acquisition tiers and evaluation criteria |
| [Licensing screening](docs/research/licensing.md) | Business constraints and bounded dependency findings |
| [Existing ISO foundations](docs/research/existing-foundations.md) | Code-audited starting points and extraction gaps |
| [Initial roadmap](docs/roadmap.md) | Historical sequencing; current work is in the completion plan |

## Relationship to ISO notation

Viewer integration is a separate follow-up, not a completion gate for the present converter work. The intended viewer Import action will invoke this reusable converter, then pass the MusicXML result to ISO score tools to prepare a `.tuna` score. ISO notation's meaning, TUNA specification, editorial workspace, engraving, pagination and publication remain a separate downstream project. A human-review frontend may combine both projects; the converter core must remain independently usable.

Existing MusicXML already has the destination representation. Its import, including `.mxl` unpacking, belongs to the consumer and is outside this converter task. The merged [independent MuseScore reader](docs/musescore-reader-plan.md) adds native conversion through the same Node package and common musical boundary. Finale and other native-format candidates remain research.

The user approved replacing the legacy piano-only model across all active ISO/Viewer consumers with common pitched/unpitched events, with instrument policy applied late. Shared C2 bass engraving and additive reading-package admission are implemented downstream. The selected presentation uses curved H/P connections with labels and outward stem preference, with rhythmic groups intact across C2 and genuine piano hand authority preserved. The [consumer handoff](docs/bass-display-handoff.md) records exact source checkpoints, verification, landing and delivery state. General legibility optimization and replacement pagination remain separate work. No downstream code is copied into this converter.

The fingering calculator is a separate project. Calculated piano fingerings are a requirement of our viewer experience, not a universal prerequisite for producing valid MusicXML. The learning app has its own application and release lifecycle and does not need the whole conversion pipeline.

## Research and rights status

Links identify primary sources and the scope of each finding. The GP adapter incorporates a separately licensed pinned bounded reader component. The MuseScore adapter is independently implemented; official GPL reader/exporter source was studied for format and default facts, and temporary official applications supplied reference exports. No MuseScore application code, runtime, fonts or soundfonts ship. Original project-authored miniatures and two explicitly attributed CC-BY-4.0 Guitar Pro specimens are committed; the rights-cleared large corpus, application artifacts and private operational receipts remain outside Git. See the individual proof records for exercised behavior and limits.

Source availability is the intended eventual policy. This private seed does not grant a software or documentation license, approve a dependency for distribution, finalize commercial terms, or change existing third-party rights. See [licensing screening](docs/research/licensing.md) before selecting an implementation dependency.
